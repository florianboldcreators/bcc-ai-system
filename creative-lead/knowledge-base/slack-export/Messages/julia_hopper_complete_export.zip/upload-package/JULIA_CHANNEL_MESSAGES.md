# Julia Hopper - Slack Export
    
**User ID:** U09D64LA420
**Email:** julia.hopper@boldcreators.club
**Export Date:** 2026-02-16 19:31:28

---

## Summary

- **DM Conversations:** 0
- **Channels with Activity:** 46
- **Total Messages Sent:** 6063

---

## Direct Messages

## Channel Messages

### #D08UY0A0CNP (1 messages)

**2025-09-17T11:25:45.307029** - Julia H. mentioned Julia:
> <@U09D64LA420> bitte schau dir das auch mal an. Ich find's noch nicht so, dass ich es rausschicken würde. Es endet mir zu abrupt und irgendwie fehlt mir hier auch der Kontext. Also vielleicht UT mit: Leonie Beck - etc.?

<https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1210556034500746?focus=true>


---

### #D09CX8LTPGB (257 messages)

**2025-09-02T06:46:44.451979** - Julia:
> Julia Hopper accepted your invitation to join Slack — take a second to say hello.

**2025-09-04T10:18:40.384469** - Julia:
> Hi Flo! Ich hoffe du hast einen schönen Urlaub – trotz der Nachrichten gestern!

Ich wollte einmal schon ein Thema für nächste Woche vormerken:
Es würde meiner Meinung nach sehr viel Sinn machen in Zukunft mit Figma zu arbeiten. Hier können wir den benötigten Still Content super schnell erstellen und müssen keine einzelnen Dateien anlegen, erstellen usw usw. Oder wie jetzt gerade mit Mert uns mit den Abobe Lizensen teilen. Hier kann man einen Benutzen anlegen und teilen &amp; vor allem gleichzeitig darin arbeiten – das einiges erschnellt :slightly_smiling_face:

**2025-09-04T11:37:25.412809** - Julia:
> Okay super :slightly_smiling_face: Dann können wir das ja am Montag besprechen

**2025-09-04T11:37:53.709829** - Julia:
> auf jeden Fall! Ist super spannend &amp; so ganz blicke ich noch nicht durch, aber das kommt ja eh mit der Zeit

**2025-09-04T20:36:31.652689** - Julia:
> Ich wollte dir eben noch den Personalfragebogen schicken. Hatte hier noch gesehen, dass das Gehalt tatsächlich falsch eingetragen ist. Also ich sag nicht  natürlich Nein haha! Aber sollte evtl. angepasst werden :)

**2025-09-08T08:07:25.835829** - Julia:
> Guten Morgen Flo! :slightly_smiling_face: Die Anmeldung bei Teams klappt mit der Adresse irgendwie nicht wirklich. Da kommt immer eine Fehlermeldung

**2025-09-08T08:50:03.947969** - Julia:
> Gerne. Ich fahre jetzt auch los

**2025-09-08T09:30:50.720609** - Julia:
> Würde hier "Professional" empfehlen: <https://www.figma.com/de-de/pricing/#features>

**2025-09-08T22:51:19.735649** - Julia:
> Hallo! Magst du mir das nochmal neu schicken oder soll ichs anpassen?

**2025-09-10T09:00:34.954429** - Julia:
> Guten Morgen, sorry es ging gestern dann doch wieder länger. Ich meld mich wenn ich gleich auf dem Weg bin

**2025-09-14T13:31:03.955479** - Julia:
> Hello! Wir sind heute doch nochmal am arbeiten &amp; am Content finalisieren für morgen. Warten gerade auf Feedback.
Porsche will nochmal ein paar Recap Slides für morgen etc. etc. Die meisten Assets werden dann heute schon gescheduled, ansonsten denke ich wird Julia morgen den Rest posten.
Ich würde mir dann morgen schon mal als Ausgleich für Samstag nehmen und je nachdem was dir lieber ist, direkt Dienstag oder Freitag dann den halben Tag von heute – hoffe es bleibt dabei

**2025-09-14T17:52:11.519559** - Julia:
> Ja wirklich etwas nervig... sind noch dran. Versuchen sie von unserer Empfehlung zu überzeugen

**2025-09-14T17:52:36.852279** - Julia:
> Passt! Bin dann Mittwoch wahrscheinlich auch im Büro

**2025-09-18T16:33:47.931759** - Julia:
> Jaaa. Hab auch immer Probleme mit der Anmeldung :smile:

**2025-09-18T16:33:59.721209** - Julia:
> Kannst du als Admin das anpassen?

**2025-09-18T16:35:08.409039** - Julia:
> okay, danke :smile:

**2025-09-23T09:13:59.186839** - Julia:
> Hi Flo, ich bin leider garnicht fit. Hab nachts Migräne bekommen, die immer noch etwas da ist. Ich versuch das Reporting auf jeden Fall fertig zu bekommen, sobald es mir besser geht.

**2025-09-23T12:38:43.913209** - Julia:
> daanke dir

**2025-09-23T12:39:27.557499** - Julia:
> Ich versuch gerade wenigstens das Reporting fertig zu stellen. Aber noch eine Frage: Haben wir denn für den BS schon irgendwelche KPIs/ Ziele definiert? Das hatte ich gestern vergessen zu fragen

**2025-09-23T12:43:09.980039** - Julia:
> ich würde es jetzt so erstellen wie gestern besprochen und dann schicke ich es dir eh zum checken. daraus entsteht dann wahrscheinlich der Blueprint, oder?

**2025-09-23T12:57:34.784049** - Julia:
> ach danke dir, das ist wirklich sehr lieb

**2025-09-23T12:57:42.637909** - Julia:
> Warte ich schick dir auch schon mal was ich anfangen hab

**2025-09-23T13:01:41.073839** - Julia:
> 

**2025-09-23T13:02:42.180819** - Julia:
> 

**2025-09-23T14:17:54.154419** - Julia:
> 

**2025-09-24T07:47:45.513939** - Julia:
> cool, das hilft mir auf jeden Fall für die nächsten Male! :pray: 

**2025-09-24T07:50:19.435919** - Julia:
> Leider nein, wollte mich deshalb auch gerade melden, mich hats dann komplett zerlegt. Hab abends hohes Fieber bekommen. Bin leider  immer noch fiebrig.. :sob: ich würde mich heute dann komplett krankmelden, damit ich morgen wieder voll am Start sein kann 

**2025-09-26T08:38:13.269349** - Julia:
> Hello!

**2025-09-26T08:38:46.249009** - Julia:
> Vielleicht vor unserem Huddle? Oder bist du da garnicht dabei?

**2025-09-26T08:53:59.928089** - Julia:
> perfekt

**2025-09-26T09:17:09.372779** - Florian Listl mentioned Julia:
> Kannst du auf den Link zugreifen und die PPT bearbeiten? <https://porsche.sharepoint.com/:p:/r/sites/PDMK/Shared%20Documents/General/UMZUG/Digitales%20Marketing/Social/Insta/09_Reporting/02_Sonderreportings/2025/Gipfeltreffen/250926_PD_Social-Reporting_Gipfeltreffen.pptx?d=w3cafe52939c24a3f84b7d6395760c8e3&amp;csf=1&amp;web=1&amp;e=M3sFHU|250926_PD_Social-Reporting_Gipfeltreffen.pptx> <@U09D64LA420>

**2025-09-26T09:30:31.502369** - Florian Listl mentioned Julia:
> bist du ready für den Call? <@U09D64LA420>

**2025-09-26T09:39:33.176019** - Julia:
> Nee hab leider keinen Zugriff

**2025-09-26T09:39:39.943459** - Julia:
> Bin jetzt ready!

**2025-09-26T09:40:22.916459** - Julia:
> welche mail?

**2025-09-26T09:40:39.705089** - Julia:
> hab den Zugriff angefordert

**2025-09-26T09:40:58.931059** - Julia:
> Aber kann sein, dass das wieder nicht klappt – Julia meinte Marie muss mich hier freigeben

**2025-09-26T09:41:10.900719** - Julia:
> Hab auf viele Sharepoint Dateien keinen zugriff

**2025-09-26T09:41:30.350989** - Julia:
> 

**2025-09-26T09:42:29.082419** - Julia:
> okay, moment

**2025-09-26T09:43:09.996499** - Julia:
> ah moment, jetzt hat mich irgendwer freigegeben und ich kanns öffnen

**2025-09-26T10:41:02.835969** - Julia:
> <https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1211465610715674?focus=true>

**2025-09-26T14:49:34.962669** - Julia:
> Eine Frage: soll ich Hanna später Bescheid geben, wenn Post/ Story Vorschläge in der BS Präsi ablegen oder machen wir das erst ab Montag?

**2025-09-26T14:49:41.919889** - Julia:
> Mert und ich sind dran :slightly_smiling_face:

**2025-09-26T17:34:44.238769** - Julia:
> habs ihr jetzt mal geschickt, hoffe das war okay

**2025-09-29T10:21:49.830679** - Julia:
> Also insider posts + alltagsdrive sagt mir leider garnichts

**2025-09-29T17:21:34.363229** - Julia:
> irgendwie bin ich noch als Schmid drin :smile:

**2025-09-30T09:55:16.944889** - Julia:
> Danke 

**2025-09-30T10:07:29.033279** - Julia:
> ich kanns nicht teilen wegen sharepoint

**2025-09-30T10:55:01.535299** - Julia:
> okay

**2025-09-30T18:23:32.900759** - Julia:
> Hello! Bist du noch da?

**2025-09-30T18:26:08.146039** - Julia:
> 

**2025-09-30T18:27:36.319509** - Julia:
> okay!

**2025-10-07T14:12:07.541389** - Julia:
> Hello! Klar, schreib ich dir runter

**2025-10-07T15:03:47.543349** - Julia:
> ganz grob mit Tasks, Mails usw.:

*IAA*
1.9. - 7.9.: 7 Std. (Grid, IG Highlight, Captions für alle Assets)
8.9. - 14.9.: so wie Julia 70-75 Std. (Vor Ort + Sonntag Nachbereitung GIF Vorschläge)

*Gipfeltreffen*
15.9. - 21.9.: 4 Std. (Grid, IG Highlight Vorschläge)
22.9. - 28.9.: 3 Std. (Textbausteine für Captions, Grid Anpassungen, Postings aushelfen)
29. - 30.9.: 0
1.10. - 5.10.: 4 Std. (Carousels…)
6.10. - 7.10.: 3 Std. (2x neue Carousels, tbd.)

**2025-10-10T11:09:54.090849** - Florian Listl mentioned Julia:
> Hey :slightly_smiling_face: <@U09D64LA420> lass uns gern kurz sprechen, wenn du vom Hundespaziergang wieder da bist :slightly_smiling_face: über das was heute ansteht

**2025-10-10T11:22:44.549699** - Julia:
> Hello! bin wieder da

**2025-10-10T11:32:40.674479** - Julia:
> Aufgaben sind klar:
• Porsche Points vom Gipfeltreffen für DE – macht Mert fertig und ich schicke sie gleich Charly, inklusive Captions
• Story Antworten Leonie Beck: Abstimmung gleich per Mail, kann dann geposted werden
• der größte Brocken ist heute die Bearbeitung des Contents von Event im Brand Store gestern: Content ist nicht gut, Hanna ist garnicht happy. versuchen das beste rauszuholen aber der Fotograf ghosted mich jetzt gerade auch

**2025-10-10T11:56:24.773139** - Julia:
> ich glaube alles was "gelb" ist meine Julia – habe es aber noch nicht geschafft, wirklich durchzugehen

**2025-10-10T11:56:46.670709** - Julia:
> ja gerne. Aber wie gesagt, es ist echt schwierig. Der Fotograf reagiert auf keine einzige Nachricht

**2025-10-10T12:00:34.009119** - Julia:
> hab ich schon probiert

**2025-10-10T14:44:10.829079** - Julia:
> 

**2025-10-13T12:40:53.132929** - Julia:
> Hi Flo, das können wir sehr gerne machen. Morgen direkt? :slightly_smiling_face:

**2025-10-15T11:15:41.511109** - Julia:
> Hey, ich wollte jetzt nochmal nachfragen, ob es denn generell schon ein Update von Porsche gibt? Du meintest ja letzte Woche bis spätestens Mitte dieser Woche sollte es eine Info geben oder du meldest dich bei uns.
Mert, Julia und ich hängen schon echt sehr in der Luft und selbst, wenn es kein Update gibt weil ihr noch in den Verhandlungen seid, wäre es schon fair zu erfahren, "dass es kein Update gibt".  Porsche hat schon paar mal Andeutungen gemacht, dass es wohl nur noch bis Ende Oktober geht bezüglich Prios etc., das ist natürlich dann schon ein komisches Gefühl, wenn wir das von dir aber noch nicht erfahren haben. Und generell müssten wir uns ja dann auch in 2 Wochen nach einem neuen Job umsehen oder auch nicht..? Hast du hier eine Info für uns? Danke dir

**2025-10-15T11:55:02.912229** - Julia:
> okay, das sind doch schöne nachrichten

**2025-10-15T11:55:08.712569** - Julia:
> danke!

**2025-10-17T15:42:20.586749** - Julia:
> schau ich mir an

**2025-10-17T15:47:12.791069** - Julia:
> Keine Ahnung, was da war

**2025-10-17T15:47:30.276869** - Julia:
> klar gerne, hatte mein Handy nur gerade nicht bei mir

**2025-10-17T15:53:47.587089** - Julia:
> Ja, ich bin auch fähig ein Reel hochzuladen ohne komischen Rand haha

**2025-10-21T11:13:32.457789** - Julia:
> Hello! Die Rechnungsadresse für den Fotografen vom 60Y Targa Event ist die Mandlstraße oder?

**2025-10-30T13:47:25.905909** - Julia:
> danke dir! Okay, alles klar. Kann man sonst ja auch aufteilen je nach Kapa

**2025-10-30T13:47:53.178979** - Julia:
> super danke! Hast du auch noch die für September?
Eigentlich kommen diese per Post oder? Also so kenne ich das

**2025-10-30T13:48:36.501979** - Julia:
> ahh sorry :smile: falsch gelesen

**2025-10-30T13:48:41.807019** - Julia:
> perfekt, danke :slightly_smiling_face:

**2025-10-30T14:07:39.823189** - Julia:
> FYI beim Brand Store hatten wir für die Rundgang Stories 4 Iterationen – falls du das für die Abrechnung brauchst

**2025-10-30T14:08:07.312169** - Julia:
> Waren immer wieder Textanpassungen, die inhaltlich gleich geblieben sind aber sie einfach die Texte umgestellt haben :no_mouth:

**2025-10-30T14:27:41.955309** - Julia:
> Bin übrigens schon 31 – aber Danke fürs jünger machen :innocent:

**2025-10-31T10:06:23.799449** - Julia:
> danke!

**2025-11-03T10:35:50.988659** - Julia:
> Hi Flo, können wir hier sprechen? Mein Handy funktioniert leider nicht gerade

**2025-11-03T14:31:02.369249** - Julia:
> Das meinte ich vorhin, bei Figma ist der Admin Account noch der Porsche Account. Sollen wir diesen weiterhin nutzen?

**2025-11-03T14:33:51.985889** - Julia:
> ah perfekt. checke ich gerade

**2025-11-03T14:39:44.812549** - Julia:
> yes, klappt

**2025-11-03T14:39:56.077939** - Julia:
> soll ich die neue Mail direkt übernehmen oder ist das noch nicht final?

**2025-11-03T14:41:34.642499** - Julia:
> okay super, danke

**2025-11-03T14:42:01.883609** - Julia:
> ja stimmt

**2025-11-03T14:42:31.739159** - Julia:
> okay. ich versuchs mal

**2025-11-03T14:44:01.200839** - Julia:
> 84

**2025-11-03T14:44:33.648439** - Julia:
> yes, mach ich. Stelle nur gerade auf ein neues Handy um und des backup lädt seit heute morgen, deshalb kann ich hier noch nichts umstellen

**2025-11-03T14:44:44.539789** - Julia:
> jetzt ist es Nummer 28

**2025-11-03T14:53:58.306759** - Julia:
> Hat geklappt, Figma ist umgestellt :slightly_smiling_face: danke dir

**2025-11-04T14:45:17.956129** - Julia:
> Hi Flo! Hier ab Slide 17 haben wir neue Content Ideen und Reihen gesammelt, die eben auf die Content Säulen des Strategie Papers einzahlen, sowie eine grobe "Roadmap" erstellt. Das ist gerade noch etwas schwierig ohne wirklich zu wissen, wie die Produktionen sonst laufen.
Freu mich über Feedback:
<https://docs.google.com/presentation/d/1hCn3KbyAlmOzdpS0aAdcerl52U-l4EYm/edit?slide=id.g39fbe07ff9b_0_162#slide=id.g39fbe07ff9b_0_162>

**2025-11-10T10:11:22.367509** - Julia:
> Hi Flo! Ich bin heute wieder mehr oder weniger da und mache zumindest schon mal die Übergabe mit Julia &amp; fange die Ausarbeitungen der Content Ideen an

**2025-11-12T14:40:46.671099** - Julia:
> Evlt. macht das Tiny House dann garkeinen Sinn und wir suchen lieber Creator/ Studios die schon perfekt gestyled sind

**2025-11-12T14:41:08.720719** - Julia:
> oder direkt in Berlin

**2025-11-12T14:41:18.200739** - Julia:
> ja das auf jeden fall

**2025-11-13T09:51:49.005859** - Julia:
> Hello! :slightly_smiling_face: Wann sollen wir wegen den KI Videos sprechen? Und wenn du mir noch die Infos zum Termin morgen gibst, wäre super :slightly_smiling_face:

**2025-11-13T11:48:11.449809** - Julia:
> yes, passt

**2025-11-13T11:54:32.000659** - Julia:
> okay, schau ich mir an

**2025-11-13T11:54:43.461089** - Julia:
> Tobias ist von BCC?

**2025-11-13T11:56:29.520469** - Julia:
> Ahja genau, okay

**2025-11-13T12:11:38.608299** - Julia:
> okay :slightly_smiling_face:

**2025-11-13T13:02:01.537889** - Julia:
> haha okay

**2025-11-13T13:02:04.067999** - Julia:
> bin im meeting

**2025-11-13T14:12:23.838689** - Julia:
> ah cool, perfekt :slightly_smiling_face:

**2025-11-13T16:19:55.998069** - Julia:
> noch eine Frage zu Bitpanda: alles auf deutsch oder englisch?

**2025-11-13T16:25:22.418819** - Julia:
> ja genau

**2025-11-13T16:25:43.469229** - Julia:
> weil sie auf ihrem TikTok Account auch beides mixen, deshalb frag ich

**2025-11-14T15:20:32.365289** - Florian Listl mentioned Julia:
> Kannst du da rein? :slightly_smiling_face: <https://meet.google.com/sqt-cfga-irb?authuser=0> <@U09D64LA420>

**2025-11-17T12:45:11.168969** - Julia:
> Hello! Hast du zufälligerweise den Kontakt von Rückenwind würde mal nachfragen, ob sie Infos haben

**2025-11-17T12:47:22.423429** - Julia:
> super danke

**2025-11-18T11:54:25.345559** - Julia:
> 

**2025-11-18T13:35:19.788349** - Julia:
> Hier auch nochmal, falls WhatsApp spinnt :slightly_smiling_face:

**2025-11-21T16:45:50.394029** - Julia:
> FYI: Anna und Marie sind noch an der Liste dran

**2025-11-21T17:13:49.922499** - Julia:
> yes, es lädt alles so lange scheinbar

**2025-11-21T17:14:24.789859** - Julia:
> ansonsten schicke ich dir den onepager morgen früh direkt, wenn das jetzt noch etwas dauert

**2025-11-22T11:10:23.520669** - Julia:
> Hello Flo!
Hier die Zusammenfassung und Storyline:
<https://docs.google.com/document/d/1SByofKhnwxNEQS8nKwrzm-wT7L5-qAubuA9JX6N6XGo/edit?tab=t.0>

Hier noch die Super Fans Ausarbeitungen + Content der Konkurrenz von Marie &amp; Anna als Ergänzung:
<https://docs.google.com/document/d/1t04tJSyVL0e2TAE2H277MDg7mhF4fi3uN5bBYDQCAgs/edit?tab=t.0>

Hier die Median Likes sortiert:
<https://boldcreators-my.sharepoint.com/:x:/g/personal/marie_gottschall_boldcreatorsclub_com/ET4BSKx62fhMpiswGgNC9sEBDR16D0Kim2f3GmQsqcmgrQ?rtime=TaLwKhQp3kg|https://boldcreators-my.sharepoint.com/:x:/g/personal/marie_gottschall_boldcreatorsclub_com/[…]MpiswGgNC9sEBDR16D0Kim2f3GmQsqcmgrQ?rtime=TaLwKhQp3kg>
Hier haben mir tatsächlich die Views gefehlt, um die Engagement Rates ausrechnen zu können --&gt; bitte ich sie am Montag nochmal drum.
Happy weekend :slightly_smiling_face:

**2025-11-22T11:14:31.923389** - Julia:
> so wie ich es gesehen die Anzahl der Videos. Amy zB kommentiert jedes Video - aber kann ich gerne nochmal nachfragen. Habe auf die Schnelle nicht gesehen, dass es doppelte Kommentare gibt

**2025-11-22T11:14:57.304339** - Julia:
> klar, hier sind die Folder:
<https://drive.google.com/drive/folders/1jxccnuQ8RY-et_z6thNXnixY-TvkHDio>

**2025-11-22T11:15:03.945719** - Julia:
> <https://drive.google.com/drive/folders/16XoGvShB_HogZBtipVE7hw4oYY0vmrub?usp=drive_link>

**2025-11-22T11:16:01.648729** - Julia:
> gerne. Das Thema ist echt spannend, weil da eigentlich soo viel Potenzial drin ist.
bin gespannt, was du zur Storyline sagst

**2025-11-22T11:18:38.839699** - Julia:
> insgesamt haben sie ca. 520 videos gepostet

**2025-11-22T11:18:49.726769** - Julia:
> 522

**2025-11-22T11:19:31.481469** - Julia:
> ja

**2025-11-22T11:21:34.351159** - Julia:
> gerne! Happy weekend und viel Spaß beim Skifahren

**2025-11-24T11:55:17.633149** - Julia:
> Hi Flo! Leider kann uns Marvin die Info zur damaligen Heimkinoraum Buchung nicht geben, deshalb wollte ich dich nochmal fragen, ob du  wegen einer alten Rechnung oÄ schauen könntest?

**2025-11-24T12:02:28.434069** - Julia:
> für die Kostenaufstellung

**2025-11-24T12:09:03.393839** - Julia:
> ah das ist das Model – bräuchten vom Raum selbst

**2025-11-24T12:09:39.914679** - Julia:
> genau

**2025-11-24T12:09:59.072909** - Julia:
> ne weiß er leider nicht

**2025-11-24T12:10:06.193759** - Julia:
> haben schon 2 mal gefragt haha

**2025-11-24T12:10:52.277019** - Julia:
> hab ich schon

**2025-11-24T12:11:23.763859** - Julia:
> das ist leider super nervig, der EINE Ansprechpartner antwortet mir nicht und alle anderen können keine auskunft geben – ich ruf da schon täglich an

**2025-11-24T12:11:41.599089** - Julia:
> Marvin meinte halt es kann auch sein, dass es umsonst war. deshalb

**2025-11-24T15:50:40.602359** - Julia:
> alright

**2025-11-24T15:50:47.539049** - Julia:
> Muss ich noch irgendwas vorm Meeting jetzt wissen?

**2025-11-24T16:47:59.191979** - Julia:
> sehr spannend!

**2025-11-25T10:33:05.169919** - Julia:
> ja gerne. hab um 11 das meeting mit Hisense. also gerne jetzt oder danach?

**2025-11-25T10:33:55.821309** - Julia:
> passt, done!

**2025-11-25T10:39:10.389049** - Julia:
> da hatte ich Marie gestern erstmal nur um die wichtigsten Accounts gebeten

**2025-11-25T10:39:15.547829** - Julia:
> Ah krass, den kannte ich auch nicht!

**2025-11-25T10:39:46.516779** - Julia:
> Ja und dieses Dr. Jart vom Meeting gestern haben wir auch noch nicht drin

**2025-11-25T13:58:30.587989** - Julia:
> Hey Flo, danke dir! Also im Moment überfordert mich dieser Input noch sehr, also ja lass uns da gerne zu sprechen :smile: Ich muss jetzt allerdings mal kurz mit dem Hund raus.
Aber auch generell komme ich da wie gesagt gerade etwas an meine bisherigen "Grenzen", wie du ja merkst. Ich bin super kreativ und kann dir 100 Content Ideen/ Konzepte entwickeln die super fürs Brand Building sind; dieses analytische und pure "zahlenbasierte" ist einfach 100% neu für mich. Deshalb bin ich gerade sehr unsicher, ob ich das überhaupt kann? Also für mich ist es super schwer, die für dich logischen Rückschlüsse aus den Zahlen zu ziehen. Wie zB mit dem vermeintlichen Fehler in der Excel-Tabelle: wäre mir nicht aufgefallen, weil ich damit einfach nicht vertraut bin. Ich muss hier erstmal noch das Basic Grundverständnis aufbauen gefühlt, damit ich dich da so unterstützen kann wie du es gerne hättest

**2025-11-25T14:48:26.330629** - Julia:
> okay, sehr gerne. Das klingt gut 

**2025-11-25T14:52:06.885409** - Julia:
> also ich schau mir jetzt deine instructions in ruhe an und dann können wir gerne sprechen. Oder macht es Sinn, dass wir uns morgen einmal im Büro zusammensetzen und das alles durchgehen? Auch in Bezug auf die Estée Lauder Task?

**2025-11-25T16:03:48.443299** - Julia:
> Kurze Frage: ich bin gerade dabei die TikTok Shops der Beauty Brands zu vergleichen. Geht allerdings nur für DE, für UK, US usw. hab ich keinen Zugriff bzw. wird einem der TikTok Shop nicht angezeigt. GPT sagt, mit VPN + neuem TikTok Account klappt das.
Ich hab aber keinen VPN, haben wir hierfür eine Lösung?

**2025-11-25T16:04:09.464429** - Julia:
> + das wäre ein Thema für What to fix oder? :slightly_smiling_face:

**2025-11-25T18:13:47.778949** - Julia:
> So, hier einmal ein Update des One Pager's (Tab: One Pager Update)
<https://docs.google.com/document/d/1SByofKhnwxNEQS8nKwrzm-wT7L5-qAubuA9JX6N6XGo/edit?tab=t.phidpfv5zl1i>

Ist noch nicht das, wo wir am Ende hin müssen aber mit meinem jetzigen Verständnis/ Skills der Status Quo, ich taste mich ran :slightly_smiling_face:
Hab natürlich deinen Input aus dem Loom Video auch einbezogen. Marie hat mich super unterstützt und gute Punkte mit reingebracht! Wir sind beide morgen im Büro, dann wäre es super, wenn wir uns das einmal zusammen anschauen. Infos zu den Super Fans kommen morgen noch

**2025-11-26T11:30:27.645269** - Julia:
> hier schon mal das KI Tool:
<https://higgsfield.ai/>

--&gt; Hier kauft man Credits die bei jedem Draft aufgebraucht werden

**2025-11-26T11:31:14.128869** - Julia:
> das weiß ich tbh nicht

**2025-11-26T15:43:57.540659** - Julia:
> setze ich auf die to do liste

**2025-11-26T15:46:38.828979** - Julia:
> wie lange sollen die Lidl Videos ca. sein?
Wenn es aus mehreren Snippets bestehen soll (Close Up auf Lidl Logo auf Wohnmobil, zoom out, Karawane zu sehen, fahren los, in Hamburg rum/ Drohnenaufnahme", Leute drehen sich um "WOW", Ankunft OMR) usw. usw.

**2025-11-26T17:48:32.688049** - Julia:
> ich hab die besprochenen Cases jetzt strukturiert und mit Proofs versehen: <https://docs.google.com/document/d/1SByofKhnwxNEQS8nKwrzm-wT7L5-qAubuA9JX6N6XGo/edit?tab=t.vxamqr41n8zq>

Für die finalen Content/ Format Ideen muss ich mich mit frischem Kopf morgen früh dran setzen – aber das geht ja bei mir schneller, als dieser One Pager :smile:

**2025-11-26T17:50:04.985539** - Julia:
> bei One Pager 26.11.

**2025-11-26T18:49:13.015369** - Julia:
> juhu :partying_face:

**2025-11-27T11:22:05.074399** - Julia:
> Hi! Die Content Ideen liegen jetzt auch jeweils mit ab :slightly_smiling_face:
Im nächsten Schritt erstellt ihr eh das Pitch Deck oder? Hier kann ich gerne die Content Ideen ausformulieren/ visuelle Beispiele suchen usw.

**2025-11-27T11:22:55.190419** - Julia:
> genau, bei Content Formate

**2025-11-28T09:34:31.609069** - Julia:
> Hi Flo. FYI Ich hab Anna an Mert übergeben, weil sie bei Hisense/Gorenje viel besser unterstützen kann. Die MockUps (Zeitungsartikel wahrscheinlich, oder?) erstelle ich wenn machbar direkt mit AI, da kann sie mir nicht helfen

**2025-11-28T09:36:12.614899** - Julia:
> Oder kannst du mir kurz sagen was du genau willst, dass sie erstellt? Ich hab keine Ahnung was ich ihr briefen soll wenn ihr scheinbar schon was besprochen habt

**2025-12-01T12:19:43.680969** - Julia:
> Du meinst bezüglich der neuen Credits? mach ich, bisher reicht es noch

**2025-12-01T12:20:27.734829** - Julia:
> achso, ja klar. leite ich dir weiter

**2025-12-01T12:21:20.959039** - Julia:
> alright. Hatte sie vorhin schon an Moni weitergeleitet

**2025-12-03T10:00:49.181309** - Julia:
> bin im warteraum

**2025-12-04T10:14:09.780099** - Julia:
> Hi Flo! FYI wegen morgen Büro: Mert und ich müssen morgen die ganzen Erledigungen für die Shootings am Mo/Di machen. Heißt ich kann nicht genau sagen, wann wir im Büro sind und wenn dann wahrscheinlich nur kurz um die Geräte abzuholen. Sollen wir sonst in Ruhe am Mittwoch sprechen?

**2025-12-05T08:25:06.217809** - Julia:
> Hi Flo! Könntest du mir hier die Vollmacht unterschreiben? Rest fülle ich dann gleich aus. Die Ikea Bestellung läuft auf deinen Namen, sonst kann ich sie nicht abholen

**2025-12-05T09:07:46.549119** - Julia:
> Vielen Dank :pray: 

**2025-12-05T16:28:42.305939** - Julia:
> Hello! Ich müsste Batterien und Verlängerungskabel bei Amazon bestellen und würde dafür die Karte nochmals nutzen

**2025-12-05T16:33:30.236809** - Julia:
> hat geklappt, danke

**2025-12-15T09:53:31.491739** - Julia:
> Guten Morgen! Für das IKEA Regal bekommen wir noch 87 € zurück, wenn wir es zurück zu IKEA bringen. Jetzt hatte ich überlegt, ob ich es BCC einfach für 100€ abkaufe, da ich tatsächlich ein Neues brauche! Ist das eine Option für dich? :slightly_smiling_face:

**2025-12-15T11:24:09.951969** - Julia:
> Oh wow, dankeeeee! Das ist ja super lieb :star-struck:

**2025-12-15T14:05:46.278089** - Julia:
> noch eine andere Frage die vorhin aufkam: gibt es denn Betriebsurlaub über Weihnachten? Oder sollen wir individuell Urlaub nehmen?

**2025-12-15T14:07:28.406989** - Julia:
> Ah okay!

**2025-12-15T14:07:31.496469** - Julia:
> danke schon mal :slightly_smiling_face:

**2025-12-15T14:07:57.030269** - Julia:
> dann könnten wir das Laureen auch schon am Donnerstag sagen, da sie danach nämlich weg ist

**2025-12-15T14:08:38.771279** - Julia:
> ja klar, nur wegen der Post-Produktion

**2025-12-15T14:09:43.206919** - Julia:
> hatten ihr heute gesagt, dass wir bis Ende der Woche noch ein paar Videos mit weihnachtlichem Content und für EOY cutten, das passt ja dann perfekt

**2026-01-07T20:05:17.944349** - Julia:
> Hey Flo! Ich hab gerade noch den Weihnachts-Urlaub eingetragen in clockify. War das richtig so? Wollte eben noch weiteren Urlaub für dieses Jahr eintragen, aber es sind nur 8 Tage freigeschaltet bisher

**2026-01-08T08:57:57.913669** - Julia:
> Guten Morgen, ja klar kein Stress

**2026-01-08T15:37:09.768499** - Julia:
> bin da

**2026-01-08T15:59:06.296559** - Julia:
> ja voll

**2026-01-08T15:59:43.902039** - Julia:
> es könnte auch witzig sein, wenn man sonst einen Typ nimmt der ganz anders aussieht und quasi "Pitbull" Style ihn als SSIO verkleidet. So wie im Sommer alle (frauen und männer) als Pitbull zu den konzerten sind

**2026-01-08T17:02:40.247849** - Julia:
> okay super danke

**2026-01-08T17:03:07.677129** - Julia:
> Also lieber SSIO Double oder absichtlich "Normalo" den wir dann so hinstylen? das müsstest du entscheiden

**2026-01-08T17:08:23.169019** - Julia:
> okay

**2026-01-09T10:33:01.530519** - Julia:
> hab kurz Meeting mit Julia &amp; Mert, wollen wir danach die next steps besprechen?

**2026-01-13T11:28:00.453149** - Julia:
> Hi, ich bräuchte bitte noch einmal den Brandguide für Sixt

**2026-01-13T12:16:49.439959** - Julia:
> danke!

**2026-01-14T10:39:26.285819** - Julia:
> noch eine Info, die Marie mir gegeben hat – das "ignorieren" wir für das Video?

**2026-01-14T11:28:34.440449** - Julia:
> <@UNUQV5R08> ich müsste Figma wieder aktivieren. Passt das?

**2026-01-14T11:58:25.828069** - Julia:
> Ich bestelle jetzt mal die Props für den Lidl Dreh – falls du hier ein paar Codes bekommst

**2026-01-14T11:59:09.424729** - Julia:
> ah okay!

**2026-01-14T12:07:53.367699** - Julia:
> jetzt

**2026-01-14T13:07:25.796979** - Julia:
> hab jetzt den 2. Teil bei Amazon bestellt

**2026-01-14T15:19:19.745649** - Julia:
> ich reaktiviere gerade figma

**2026-01-14T15:19:38.756579** - Julia:
> da solltest du etwas aufs handy bekommen

**2026-01-14T15:20:05.888549** - Julia:
> 

**2026-01-14T15:20:10.406119** - Julia:
> hab ich. auch VAT etc.

**2026-01-14T15:20:18.563769** - Julia:
> clients als mail

**2026-01-14T15:20:47.770969** - Julia:
> oh wurde abgelehnt

**2026-01-14T15:21:22.840599** - Julia:
> gibts leider nicht, nur SEPA-lastschrift

**2026-01-14T15:22:44.264049** - Julia:
> danke, ich probiers!

**2026-01-14T15:26:34.793919** - Julia:
> okay, sollte geklappt haben. Da war dauernd ein Bug

**2026-01-15T08:15:38.961219** - Julia:
> Guten Morgen, nee weiß ich leider nicht! 

**2026-01-15T15:58:23.253289** - Julia:
> Also tatsächlich klappt es nicht. Mir fehlt die normale SIM-Pin aus 4 Ziffern. Steht leider auch nirgends im Konto. normalerweise so wie ich das noch kenne, kommt das auch mit der Post

**2026-01-15T16:08:26.998459** - Julia:
> ich muss jetzt los und die restlichen sachen einkaufen und alles vorbereiten. Wenn du morgen früh kurz Zeit hast, könnten wir das ja zusammen machen? Du bekommst dann nämlich auf deine Mail adresse einen code, glaube ich hab einen Trick gefunden

**2026-01-16T09:41:56.801319** - Julia:
> Hi! hast du jetzt Zeit?

**2026-01-16T10:17:20.885259** - Julia:
> kannst du mich hiermit nochmal einladen? der Link klappt nicht

**2026-01-16T10:19:05.270359** - Julia:
> perfekt danke

**2026-01-20T12:22:00.754159** - Julia:
> wegen sprout: da werden sie sich bei dir melden, weil du der billing address Kontakt bist

**2026-01-27T13:16:20.608389** - Julia:
> Hello! Ja, passt es dir um 15 Uhr?

**2026-01-27T14:55:39.724019** - Julia:
> Können wir 15.15 machen?

**2026-01-27T14:55:47.790909** - Julia:
> okay, danke!

**2026-01-27T14:56:05.003309** - Julia:
> perfekt

**2026-01-28T11:54:06.623299** - Julia:
> Hello!

**2026-01-28T11:54:12.194549** - Julia:
> ich antworte die gleich in whatsapp

**2026-01-28T11:54:33.807219** - Julia:
> Aber kurz hier weil Jana parallel super stresst und wir im SIXT meeting sitzen :smile:

**2026-01-28T11:55:13.808729** - Julia:
> Die Videos/ MockUps für den Workshop werden nicht bis morgen alle fertig. ich bin dran aber das dauert einfach. Zudem die Ideen auch teilweise noch nicht final sind

**2026-01-28T11:55:29.506639** - Julia:
> Also damit du schon mal weißt, ich bin dran aber ich kann das nicht bis morgen alles fertig machen

**2026-01-28T11:56:20.588979** - Julia:
> okay

**2026-01-28T11:56:21.932099** - Julia:
> ja gerne

**2026-01-28T11:56:29.967899** - Julia:
> ich kläre es mit Marvin und Jana

**2026-01-28T11:57:02.653419** - Julia:
> Ne, wollte es nur mit dir absprechen bevor es wieder hin und her geht

**2026-01-28T12:01:03.008149** - Julia:
> danke!

**2026-01-28T12:02:04.515269** - Julia:
> ich hatte jetzt love is blind soweit fertig und es basti zum schnitt gegeben:
<https://app.asana.com/1/1199360402832734/project/1211046662010247/task/1212991424663406?focus=true>

Das für alle anderen Ideen ist zu aufwendig bis morgen. Aber ich spreche gleich mit dem Team

**2026-01-28T12:06:15.623769** - Julia:
> welche Gegenstände meinst du?

**2026-01-28T12:07:15.325399** - Julia:
> aso ja, das ist ja eine andere Idee nochmal!

**2026-01-28T12:08:32.005759** - Julia:
> achso meinst du

**2026-01-29T09:57:29.633719** - Julia:
> Hello! Wir hatten da schon mal drüber gesprochen aber ich weiß es gerade nichtmehr, ob ich die selbst irgendwo her bekomme oder du mir das zu schickst. Ich hab eben meine Lohnabrechnung von Januar bekommen, mir fehlen noch die von Nov, Dez und diese Anmeldung zum Jobstart. Soll ich Julia Hillmaier danach fragen?

**2026-01-29T10:01:13.454329** - Julia:
> Okay passt

**2026-01-29T10:01:24.810249** - Julia:
> Ja super, das kenne ich. Danke!

**2026-01-29T17:51:23.850899** - Julia:
> wegen MINI: Marie und ich haben ein paar Ideen ausformuliert. Ich schaff es allerdings nichtmehr das noch viel weiter zu spinnen bzw. hübsch zu visualisieren. Ich gliedere das Dokument für morgen noch, aber ich würds dir morgen eher mal "erzählen" als 1. Schritt. Passt das?

**2026-01-30T16:30:46.116829** - Julia:
> <https://docs.google.com/document/d/1NEnlqXtQv5wCwQTJwg87O0flVR4dX0z-fwHf1-nqxH8/edit?tab=t.y41r0wyaqkw6>

**2026-02-02T09:48:59.001359** - Julia:
> Hello! Ich kann die MINI Präsi leider nicht öffen, scheint "kaputt" zu sein

**2026-02-02T09:51:44.153939** - Julia:
> danke!

**2026-02-02T09:53:52.590519** - Julia:
> Ne klappt irgendwie nicht

**2026-02-02T09:55:23.330889** - Julia:
> bisher noch nicht. ich probier es gleich nach meinem Call

**2026-02-02T10:12:41.503739** - Julia:
> ja so klappt es

**2026-02-02T10:13:32.662229** - Julia:
> danke!

**2026-02-02T10:13:53.498599** - Julia:
> der Workshop bei SIXT findet schon statt oder?

**2026-02-02T10:14:03.254189** - Julia:
> Weil wir die Präsi ja immernoch nicht haben (fertig haben)

**2026-02-02T10:14:41.345599** - Julia:
> ah okay, super

**2026-02-02T10:15:14.094219** - Julia:
> passt, ich muss noch schauen wie ich am besten hinkomme mit dem Streik

**2026-02-02T10:25:01.798789** - Julia:
> da komme ich auch irgendwie nicht hin :smile: aber danke. Alles gut, ich find einen weg. Wann sollen wir uns dort treffen 14.45?

**2026-02-02T11:42:14.609779** - Julia:
> Ist Marie heute nicht da? Oder hab ich das falsch im Kopf?

**2026-02-02T11:43:01.839469** - Julia:
> ahh okay, schade! :smile:

**2026-02-02T11:43:03.419799** - Julia:
> danke

**2026-02-02T11:44:17.754909** - Julia:
> alles gut, ich hab mich nur gewundert, dass sie mir nicht antwortet :slightly_smiling_face: hatte ihr am Freitag 2 Tasks gegeben und wollte dazu heute sprechen

**2026-02-02T13:01:53.246139** - Julia:
> Haha okay

**2026-02-02T13:02:01.182809** - Julia:
> XS/S

**2026-02-02T20:38:47.886809** - Julia:
> Ich hab hier unsauber mitgeschrieben – hier wolltest du einfach 3 Bilder wie diese Challanges erarbeitet werden oder?

**2026-02-02T20:39:41.983019** - Julia:
> okay passt, danke für die schnelle Antwort!

**2026-02-02T20:40:51.125679** - Julia:
> ja passt, brief ich eben ein

**2026-02-03T12:43:08.256199** - Julia:
> FYI – eben gesehen, wurde gebucht

**2026-02-09T09:40:01.298599** - Julia:
> Hi Flo, hoffe dir geht’s gut! Ich bin etwas fitter aber noch immer nicht gesund und hab wieder diesen schlimmen Husten bekommen jetzt. Ich hab leider noch keine Antwort vom Arzt, warte da nur drauf. Ich brauch heute auf jeden Fall noch den Tag und meld sobald ich mehr weiß :crossed_fingers:

**2026-02-09T11:21:11.161959** - Julia:
> danke!!

**2026-02-16T13:50:39.465539** - Julia:
> Hi! :slightly_smiling_face: würde es dir um 4 passen? Dann stell ich uns kurz was ein

**2026-02-16T14:02:02.990089** - Julia:
> okay


---

### #D09CY8U2AGK (1486 messages)

**2025-09-02T13:13:21.309769** - Julia:
> Kurze Frage: ppt und Co. sind noch nicht auf meinem Laptop – haben wir hier Lizensen? Irgendwie kann ich es sonst nicht runterladen

**2025-09-02T13:31:17.089339** - Julia:
> ahjaa okay klappt. danke!

**2025-09-02T13:31:32.276989** - Julia:
> ich mich auch, aber bin noch etwas "überfahren" ha ha

**2025-09-02T14:51:42.598919** - Julia:
> nochmal kurz: soll ich mir zu der Präsi von Flo &amp; Alex Gedanken machen/ Ideen weiterspinnen oder ein neues Konzept überlegen?
Oder Fotografen usw. checken
Also für den Termin morgen

**2025-09-02T17:35:35.166719** - Julia:
> Ich weiß gerade nicht, wo ich das am besten ablegen soll. Deshalb erstmal hier - sorry!

Ich hab Kommentare &amp; Ideen abgelegt in Flo's Präsi. Wollte diese jetzt erstmal nicht zerschießen-
Unten hab ich noch 2 Kampagnenideen neben dem "La Famiglia" Thema reingelegt – welches ich super finde, allerdings mit kleinen Anpassungen (siehe Kommentare).

Ist natürlich noch komplett WIP, aber sollte als Grundlage für uns schon mal dienen :slightly_smiling_face:
Bezüglich Fotograf kommt es mMn total auf das Konzept am Ende an, denn Mario ist für mich eher beim Thema "Opera" (groß, bildgewaltig, dramatisch) aber sehe ihn nicht unbedingt bei einem nahbaren, menschlichen Content. Wie siehst du das?

**2025-09-02T20:16:59.258839** - Julia:
> Danke fürs Drübergucken! :slightly_smiling_face: Die Kommentare hast du gesehen? Die Idee mit Fahrzeuge = la Famiglia ist rqaus, oder?

Präsentation zieh ich glatt und formatier alles schön. Deine Punkte schau ich mir an und versuch so gut es geht schon einzubauen. Schicks dir dann natürlich sobald ich was anschauliches hab

**2025-09-03T08:55:52.899399** - Julia:
> Guten Morgen! Wie heißt nochmal die Aufgabe, bei der du alle Infos hinterlegt hast? Finde sie in Asana nichtmehr

**2025-09-03T09:00:47.701639** - Julia:
> Und vllt könntest du mir noch die aktuelle PPT Präsi schicken, die ich benutzen kann. Hatte gesehen, die von Roxanne war ohne Porsche Logo Tag unten

**2025-09-03T09:17:18.324149** - Julia:
> Ah die "Master Gipfeltrffen" ist die richtige, right?

**2025-09-03T09:33:39.452349** - Julia:
> Alles gut, ich arbeit mal in den Master rein, dann haben wir es zentral &amp; wir können später nur die einzelnen Slides ab "Konzept" präsentieren

**2025-09-03T09:33:40.270379** - Julia:
> Okay

**2025-09-03T09:43:04.056749** - Julia:
> hab zugriff angefordert

**2025-09-03T09:48:10.438589** - Julia:
> 

**2025-09-03T09:52:53.511519** - Julia:
> der Link in deiner Mail

**2025-09-03T09:54:59.585179** - Julia:
> Ahja genau

**2025-09-03T09:55:01.995739** - Julia:
> Bilder seh ich

**2025-09-03T09:58:08.148019** - Julia:
> yeees

**2025-09-03T09:58:08.937289** - Julia:
> danke

**2025-09-03T10:54:27.628909** - Julia:
> hab die. seite dupliziert und einen content vorschlag + caption reingelegt

**2025-09-03T10:56:45.796599** - Julia:
> okay jetzt hat sich alles abgeändert

**2025-09-03T10:58:51.300839** - Julia:
> okay wir müssen ganz dringend ein anderes tool finden, der löscht einfach alle inhalte raus :smile:

**2025-09-03T11:02:22.341859** - Julia:
> okay puh, liegt ab mit einer Note. Passt das für dich?

**2025-09-03T11:02:37.072739** - Julia:
> 

**2025-09-03T11:25:51.760679** - Julia:
> okay, bin gespannt :slightly_smiling_face:

**2025-09-03T12:04:06.038319** - Julia:
> schau ich mir an!

**2025-09-03T12:04:08.342689** - Julia:
> schick ich dir gleich

**2025-09-03T12:24:16.798219** - Julia:
> Soo, wo darf ich das nochmal ablegen?

**2025-09-03T12:25:39.320679** - Julia:
> habs! sorry, finde mich noch nicht soo gut zurecht

**2025-09-03T12:29:09.862479** - Julia:
> lädt hoch. schick dir gleich den Link

**2025-09-03T12:30:33.238819** - Julia:
> noch ein paar Fragen: Marie hat in die Präsi kommentiert – wie geh ich jetzt weiter vor? antwortest du?
Um 14Uhr sprechen wir intern oder schon mit Porsche? Soll ich das präsentieren? Kann Flos Ideen nicht 100% nachvollziehen, deshalb etwas schwierig teilweise
Kann ich bis dahin noch kurz Mittagspause machen mit Coco oder schwierig? :smile:

**2025-09-03T12:50:23.153779** - Julia:
> liegt ab!

**2025-09-03T12:51:10.747739** - Julia:
> die <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BC39F3BC9-57D0-49EF-88A5-B797BD28F00A%7D&amp;file=2025-08-22%20Konzept%20Golf%20%40porsche_de_LR.pptx&amp;action=edit&amp;mobileredirect=true|hier>

okay. Also ich kanns schon vorstellen. Frage wäre nur, ob ich ihm halt was wegnehme oder zu sehr ändere

**2025-09-03T13:24:08.973339** - Julia:
> oh okay :smile: hab ich jetzt

**2025-09-03T13:24:25.110209** - Julia:
> i try

**2025-09-03T13:24:36.792519** - Julia:
> :smile:

**2025-09-03T13:29:28.078089** - Julia:
> soll ichs abändern?

**2025-09-03T13:29:45.736639** - Julia:
> kannst du die präsentation direkt online öffnen? ich muss sie downloaden, anpassen und wieder hochladen

**2025-09-03T13:41:01.112899** - Julia:
> sollen wir nochmal kurz sprechen?

**2025-09-03T13:50:41.374519** - Julia:
> ich hatte nochmal ein paar Typo Fehler ausgebessert – Version 0309 lädt in den Drive hoch

**2025-09-03T14:05:06.301959** - Julia:
> puh, was heißt das denn genau? super viel budget weg oder?

**2025-09-03T14:18:19.693119** - Julia:
> ahhhh

**2025-09-03T14:18:34.168169** - Julia:
> manno :fearful:

**2025-09-03T14:19:11.792809** - Julia:
> okay

**2025-09-04T08:45:55.295899** - Julia:
> Hello!

**2025-09-04T08:47:48.052209** - Julia:
> Kurze Info und ich klopfe auf Holz – bin morgens mit einem riesigen Knubbel am Nacken aufgewacht, wunderbare Verspannung. Hab Voltaren drauf und intus. Nooormalerweise wenn ich das hab, wirds irgendwann so eklig, dass ich mich nimma bewegen kann. Wenns so schlimm wird (ich hoffe nicht..) muss ich dann evtl. zum Arzt heute und mir paar Spritzen reingeben lassen

**2025-09-04T08:54:28.643199** - Julia:
> Neee bin im Büro. Bisher gehts ja voll aber ich wollts nur mal vorwanen, es könnte passieren

**2025-09-04T08:57:54.623519** - Julia:
> oh wow

**2025-09-04T08:58:02.996179** - Julia:
> muss ich noch was wissen für unser meeting gleich?

**2025-09-04T09:17:46.849019** - Julia:
> 13. oder?

**2025-09-04T09:18:43.168429** - Julia:
> ja geht klar

**2025-09-04T09:19:37.591809** - Julia:
> bisher hab ich keine mail bekommen

**2025-09-04T09:20:49.054659** - Julia:
> glaub er ist noch im schlummerland

**2025-09-04T09:46:19.870059** - Julia:
> Habs jetzt

**2025-09-04T09:46:27.605679** - Julia:
> gibts ne asana task dazu?

**2025-09-04T09:46:30.861299** - Julia:
> sonst hier: <https://drive.google.com/drive/folders/1hyq-ZZIQcYFhrnpZMFVwPBScT9TdUvOF>

**2025-09-04T09:47:11.905329** - Julia:
> hab für die 1. slide zwei Versionen angelegt. weil ich nicht wusste, ob sie immer mit einer HL einsteigen oder nicht

**2025-09-04T09:47:34.825419** - Julia:
> hab das konzept nicht verstanden :smile:

**2025-09-04T09:48:01.102519** - Julia:
> jaa

**2025-09-04T09:48:28.405339** - Julia:
> passen die slides? dann meld ich mich wieder ab. Kann Flo uns da eine 3. Lizens anlegen?

**2025-09-04T09:53:10.285869** - Julia:
> das Reel kommt heute auch online. Zum Repost in die Story oder?

**2025-09-04T09:55:36.673109** - Julia:
> ahh okay perfekt

**2025-09-04T09:55:50.144469** - Julia:
> also ich hab das gefühl bezüglich IAA ich versteh garnichts :smile:

**2025-09-04T09:56:58.042939** - Julia:
> Okay

**2025-09-04T09:57:17.775779** - Julia:
> noch eine detaillierte frage, warum mussten die VBWs jetzt nicht in die Captions/ Slides?

**2025-09-04T10:01:47.980499** - Julia:
> ahh okay ja macht sinn

**2025-09-04T10:28:07.198539** - Julia:
> die slide mit einzeiligem Text ist abgelegt mit _v2

**2025-09-04T10:37:32.386609** - Julia:
> wann gibts die info ans team?

**2025-09-04T11:14:11.279409** - Julia:
> gipfeltreffen :slightly_smiling_face: hattest es dann schon gesagt

**2025-09-04T11:22:19.404039** - Julia:
> yees, moment

**2025-09-04T11:24:23.603389** - Julia:
> da gehts um die SoS richtig?

**2025-09-04T11:25:08.861509** - Julia:
> und wo finde ich das reel? würde es mir gerne kurz ans background anschauen

**2025-09-04T11:26:28.858439** - Julia:
> bzw. müsstest du mich in asana einmal zu der Dublin Überaufgabe freischalten, dann finde ich alles :slightly_smiling_face:

**2025-09-04T11:34:48.308469** - Julia:
> Hier mal Vorschläge:

Ein Meisterwerk, zweimal neu interpretiert: Der 911 Turbo S als Coupé und Cabriolet. Kraft, Eleganz und ikonische DNA in zwei faszinierenden Formen.
----

Zwei Ikonen, ein Statement. Der neue 911 Turbo S – als Coupé und Cabriolet, kraftvoll und elegant bis ins kleinste Detail.
----

Offen den Wind spüren oder geschlossen die volle Power genießen – der neue 911 Turbo S verwandelt jede Fahrt in ein unvergleichliches Erlebnis.

**2025-09-04T11:51:15.949599** - Julia:
> Alles guut, ich würds dann evtl auch mittags wieder heim packen. kann ich mich etwas gemütlicher auf die couch setzen

**2025-09-04T11:52:33.012089** - Julia:
> wenn du dann einmal noch kurz paar minuten hast wegen dem Sommer event Konzept, sag Bescheid

**2025-09-04T12:49:53.583699** - Julia:
> alles gut! sonst morgen? :slightly_smiling_face:

**2025-09-04T14:01:48.945449** - Julia:
> there you go!

**2025-09-04T14:25:19.354119** - Julia:
> gerne!

**2025-09-04T14:25:49.483199** - Julia:
> Soll ich Charly später einfach via Teams anrufen oder möchtest du dabei sein?

**2025-09-04T14:26:08.652199** - Julia:
> Styleguide sitze ich jetzt gleich dran

**2025-09-04T14:30:28.219259** - Julia:
> ich glaubs dir..

**2025-09-04T15:55:51.024439** - Julia:
> Ah okay :slightly_smiling_face: ist das dann von Porsche oder von dir?

**2025-09-04T16:39:43.120529** - Julia:
> es wird nicht schlimmer, das ist schon mal gut :slightly_smiling_face:

jaa es ist viel &amp; verstehe auch noch nicht alles aber wird.

**2025-09-04T16:39:49.472479** - Julia:
> All good, machen wir ja eh noch

**2025-09-04T16:39:53.884519** - Julia:
> mooment

**2025-09-04T16:40:24.962709** - Julia:
> okee

**2025-09-04T16:42:01.368329** - Julia:
> hier noch kurze eine Frage von mir: hattest du das dann angepasst? Weil ich das gerade in den Styleguide packen wollte und wenn Porsche die HL aber nicht so will wie wir sie setzen, schwierig :smile:

**2025-09-04T17:00:23.865279** - Julia:
> Okay PAG ist so wie geposted wurde?

**2025-09-04T17:00:36.308089** - Julia:
> Dann ist es in der Vorlage nämlich falsch :face_with_peeking_eye:

**2025-09-04T17:01:27.742489** - Julia:
> komme nichtmehr mit :smile:

**2025-09-04T17:02:20.698499** - Julia:
> weil Mert sagt in seiner Vorlage ist es wie bei PAG

**2025-09-04T17:03:13.401409** - Julia:
> okay got it

**2025-09-04T17:41:12.798089** - Julia:
> Ich muss tatsächlich um Punkt 18Uhr raus, ist das okay?

**2025-09-04T17:44:08.270719** - Julia:
> Mir ist noch nicht ganz klar, wo wir dabei sind und wo nicht

**2025-09-04T17:53:09.010269** - Julia:
> Ja, da bleib ich die ganze Nacht. Mein Jugendschwarm

**2025-09-04T17:53:50.930419** - Julia:
> :shushing_face:

**2025-09-04T18:04:29.981569** - Julia:
> 

**2025-09-04T20:35:23.716779** - Julia:
> Falls dus noch brauchst: <https://drive.google.com/drive/folders/1Uqfsv2dzOxUL2lpnQUGXIqSmga7tscPP>

**2025-09-05T09:49:05.541559** - Julia:
> Hello :slightly_smiling_face: yees

**2025-09-05T10:16:58.285149** - Julia:
> Soo war grad mit Mert im Meeting

**2025-09-05T10:17:13.739799** - Julia:
> oh ja klar, füg ich hinzu

**2025-09-05T10:18:00.709579** - Julia:
> ja das kann ich gerne machen.
Wäre jetzt wie gesagt erstmal so für Porsche intern gewesen

**2025-09-05T10:18:16.553599** - Julia:
> <mailto:julia.hopper@boldcreatorsclub.com|julia.hopper@boldcreatorsclub.com>

**2025-09-05T10:18:57.922109** - Julia:
> Ja da wollte ich dich jetzt nochmal fragen. Hast du vllt vor unserem Call kurz Zeit mit einen Überblick zu geben? Bin gerade etwas lost was alels dafür schon vorbereitet werden soll

**2025-09-05T10:19:09.103129** - Julia:
> haha alles gut

**2025-09-05T10:20:12.942259** - Julia:
> ja gerne, bin in 2 Minuten da

**2025-09-05T12:33:37.662099** - Julia:
> Styleguide lädt gerade hoch. Packs dann gleich wieder in ein pdf und schick dir den Link

**2025-09-05T12:33:49.141699** - Julia:
> Bei der Caption, hab ich keinen Zugriff mehr auf die Präsi..?

**2025-09-05T12:33:54.286629** - Julia:
> Wollte das Video nochmal anschauen

**2025-09-05T13:33:06.308109** - Julia:
> kann leider das Grid gerade noch bearbeiten weil Mert &amp; basti noch in Adobe sind.. ahh

**2025-09-05T13:49:19.212959** - Julia:
> okay jetzt. bin dran

**2025-09-05T13:52:02.871609** - Julia:
> hab keine bekommen :fearful:

**2025-09-05T13:52:03.860189** - Julia:
> moment

**2025-09-05T13:52:18.934699** - Julia:
> glaub das mit der Mailadresse klappt nicht so wie Flo sich das vorgestellt hat

**2025-09-05T13:53:10.942299** - Julia:
> das hier?

**2025-09-05T13:53:21.854809** - Julia:
> ne das geht nicht. er springt immer

**2025-09-05T13:53:48.203019** - Julia:
> AH nicee

**2025-09-05T13:54:04.567389** - Julia:
> Ja gut würde auch so passen. habe jetzt halt längere captions geschrieben. Sind in Asana

**2025-09-05T13:54:08.687079** - Julia:
> Soll ich einen Satz draus machen?

**2025-09-05T13:55:02.105779** - Julia:
> okay, danke fürs flaggen!

**2025-09-05T14:14:26.022849** - Julia:
> So?

IAA 2025: Porsche live.
Von Klassik bis Zukunft – im Open Space am Wittelsbacherplatz (WB200) erwartet euch ein Erlebnis, kein Messestand.

**2025-09-05T14:49:05.783109** - Julia:
> Aso ja klar:

*IAA 2025: Porsche live.*
*Von Klassik bis Zukunft – im Open Space am Wittelsbacherplatz (WB200) erwartet euch ein Erlebnis, kein Messestand.*

*Join the spectacle – Porsche at IAA'25*

Oder wollen sie den Abbinder als HL? Sorry ich checks nicht ganz.

*Join the spectacle – Porsche at IAA'25*
*Von Klassik bis Zukunft: im Open Space am Wittelsbacherplatz (WB200) erwartet euch ein Erlebnis, kein Messestand.*

**2025-09-05T14:54:41.688339** - Julia:
> 

**2025-09-05T15:09:50.840379** - Julia:
> PDF ist abgelegt: <https://drive.google.com/drive/folders/1Uqfsv2dzOxUL2lpnQUGXIqSmga7tscPP>

**2025-09-05T15:15:30.401809** - Julia:
> Noch eine Frage:

**2025-09-05T15:15:55.689149** - Julia:
> Soll ich die Hintergrundfarbe vom KV an das IG Highlight anpassen? Das ist ja heller. Oder muss ich bei der Farbe bleiben?

**2025-09-05T15:17:18.146249** - Julia:
> wie ist denn der code? komme nicht ins meeting

**2025-09-05T15:22:56.712669** - Julia:
> es geht nicht

**2025-09-05T15:23:25.133959** - Julia:
> standbild

**2025-09-05T15:23:34.866909** - Julia:
> ich versuchs noch dauernd

**2025-09-05T15:27:10.179819** - Julia:
> :face_with_peeking_eye: farbattacken super

**2025-09-05T15:34:27.328999** - Julia:
> ne ich komme einfach nicht rein

**2025-09-05T15:34:40.064919** - Julia:
> nee ich auch nicht

**2025-09-05T15:36:49.248269** - Julia:
> okay.. sorry!

**2025-09-05T15:42:00.917939** - Julia:
> Manno, wollte Karussell fahren

**2025-09-05T15:59:56.952039** - Julia:
> <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BE57B0967-DF14-4D65-A137-58646F317C64%7D&amp;file=250903_IAA_Hospitality_FD.pptx&amp;fromShare=true&amp;action=edit&amp;mobileredirect=true&amp;previoussessionid=3b44bf06-5a18-7b53-8dd8-95b1918d23dd&amp;wdOrigin=TEAMS-MAGLEV.p2p_ns.rwc&amp;wdExp=TEAMS-TREATMENT&amp;wdhostclicktime=1756982116144&amp;web=1|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BE57B09[…]wdExp=TEAMS-TREATMENT&amp;wdhostclicktime=1756982116144&amp;web=1>

**2025-09-05T16:00:49.414409** - Julia:
> Die Grafik fehlt uns leider. wir haben zwar die Indesign Datei aber ohne ins Detail gehen zu wollen: die Indesign Datei ist nicht verpackt (so nennt man das). Wodurch alle Verknüpfungen fehlen und diese nur pixelig sind.
Können wir die Grafik von der Agentur bekommen?

**2025-09-05T16:07:12.129319** - Julia:
> aber nur ab und zu oder?

**2025-09-05T16:55:46.192489** - Julia:
> bin dran. würde es mit orange markieren was ich verbessert hab

**2025-09-05T17:00:16.632189** - Julia:
> hier versteh ich den Inhalt nicht. Das ist ja nicht das Grid, das ich eben erstellt habe, oder?

**2025-09-05T17:10:50.077599** - Julia:
> bei den lila markierten weiß ich nicht von wem diese sind

**2025-09-05T17:17:03.532929** - Julia:
> okay bin durch

**2025-09-05T17:36:06.824849** - Julia:
> Mert legt seine Slides gleich ab

**2025-09-05T17:41:31.185039** - Julia:
> brauchst du noch was von mir? sonst würde ich mich langsam ausloggen

**2025-09-05T17:43:54.551199** - Julia:
> ah okay verstehe

**2025-09-05T17:44:24.595549** - Julia:
> mach ich!

**2025-09-05T17:57:24.732629** - Julia:
> Charly's Kommentare in der Präsi sind teilweise falsch, weils dann garnicht um Reel usw. geht :face_exhaling:

**2025-09-05T18:09:33.775709** - Julia:
> Seite 8

**2025-09-05T18:09:55.707449** - Julia:
> Antwortest du oder soll ich? Würde dann sagen, dass wir es nochmal überarbeiten und in Ruhe durchschauen

**2025-09-08T07:51:04.178219** - Julia:
> Hello! :slightly_smiling_face: Ne eben nicht. Das meinte ich damit:
Die Grafik fehlt uns leider. wir haben zwar die Indesign Datei aber ohne ins Detail gehen zu wollen: die Indesign Datei ist nicht verpackt (so nennt man das). Wodurch alle Verknüpfungen fehlen und diese nur pixelig sind.
Können wir die Grafik von der Agentur bekommen?

**2025-09-08T07:53:30.348199** - Julia:
> Würde mir jetzt die Caption Texte anschauen, oder hast du schon alle verbessert?

**2025-09-08T09:22:09.882389** - Julia:
> Bin durch :slightly_smiling_face: habs wieder in orange markiert.

**2025-09-08T09:26:16.510109** - Julia:
> hier <https://docs.google.com/spreadsheets/d/1BfBrmXqyH3hJpWj9pltp6rzgNouuSk0JTR1sLH3c5W0/edit?gid=506520990#gid=506520990>

**2025-09-08T09:26:43.066479** - Julia:
> Sitze im Bus und komme ins Büro :slightly_smiling_face: wollte heute morgen zuerst die Texte ready machen

**2025-09-08T09:27:07.140569** - Julia:
> Bin in ca. 20 Minuten im Office

**2025-09-08T11:26:14.819279** - Julia:
> ich weiß leider nicht welche das ist

**2025-09-09T11:46:43.538249** - Julia:
> Porsche @ IAA 2025: Unter einem überdimensionalen Wappen wartet ein *echtes Festival-Feeling* – Weltpremiere des 911 Turbo S, neue Cayenne & Taycan Black Edition, limitierter 911 Spirit 70, Probefahrten mit Taycan & Macan, Family-Area mit Karussell & Coffee-Bar, Sonderwunsch-Unikat & exklusive Lifestyle-Kollektion. *Wittelsbacherplatz wird zum Porsche-Playground für Groß & Klein*

**2025-09-09T11:50:00.701299** - Julia:
> Porsche macht den Wittelsbacherplatz zum Erlebnis: Unter dem ikonischen Wappen feiern wir die Weltpremiere des 911 Turbo S, zeigen Black Editions, exklusive Unikate &amp; laden zu Taycan- und Macan-Probefahrten ein. Mit Family-Area, Coffee-Bar &amp; Festival-Vibes wird die IAA zum Treffpunkt für alle Porsche Fans

**2025-09-09T18:39:54.175519** - Julia:
> <https://drive.google.com/drive/folders/1Uqfsv2dzOxUL2lpnQUGXIqSmga7tscPP>

**2025-09-09T18:54:49.853699** - Julia:
> Closing Dienstag: <https://drive.google.com/drive/folders/1wRGutm1H6dYpnA3OHCiiqF0LpldogWVR>

Daily Mittwoch: <https://drive.google.com/drive/folders/1w7yZgrv6YibPDeNBCIjEh1cRc23UfO2A>

**2025-09-09T20:41:32.789919** - Julia:
> CONTENT FÜR MORGEN FRÜH:
<https://drive.google.com/drive/folders/1w7yZgrv6YibPDeNBCIjEh1cRc23UfO2A>

**2025-09-10T10:40:34.581179** - Julia:
> 

**2025-09-10T11:16:31.207469** - Julia:
> TINS DAY Reminder

**2025-09-10T11:26:39.590149** - Julia:
> <https://drive.google.com/drive/folders/1r4jfvm_vTiPiAiCv0-YFPIHCNZpq6pWk>

**2025-09-10T12:12:25.686759** - Julia:
> 

**2025-09-10T12:16:24.008599** - Julia:
> 

**2025-09-10T12:19:28.952579** - Julia:
> 

**2025-09-10T13:58:09.119969** - Julia:
> Background Picture Repost Story

**2025-09-10T14:01:36.256779** - Julia:
> 

**2025-09-10T15:00:53.303939** - Julia:
> 

**2025-09-10T15:04:34.689129** - Julia:
> 

**2025-09-10T15:06:57.198669** - Julia:
> 

**2025-09-10T15:32:52.770669** - Julia:
> 

**2025-09-10T16:20:54.889109** - Julia:
> 

**2025-09-10T16:27:35.589539** - Julia:
> 

**2025-09-10T16:30:03.283169** - Julia:
> Vorschlag: Charly hier vorwarnen, dass es getrennt werden musste

**2025-09-10T16:30:58.358509** - Julia:
> 

**2025-09-10T17:02:38.082339** - Julia:
> ICH HAB ES MIR GERADE GEDACHT

**2025-09-10T17:02:47.119949** - Julia:
> "ich benutze nur bilder von flo"

**2025-09-10T17:37:14.321399** - Julia:
> Thumbnail Ersatz Vorschlag --&gt; Das dunkle geht nicht, auch nicht zum verlängern

**2025-09-10T17:38:51.613449** - Julia:
> Closing heute:

**2025-09-10T17:55:56.734689** - Julia:
> thumbnail reel

**2025-09-10T18:35:20.005989** - Julia:
> 

**2025-09-10T18:49:10.617959** - Julia:
> Die souveränste Art Porsche 911 zu fahren: der neue 911 Turbo S.
_
911 Turbo S (WLTP, vorläufige Werte) Kraftstoffverbrauch kombiniert: 11,8 – 11,6 l/100 km;
CO2-Emissionen kombiniert: 266 – 262 g/km; CO2-Klasse: G; Stand 09/2025

**2025-09-10T18:57:40.910559** - Julia:
> Der Einzige der sich mit einem 911 messen kann: der neue 911 Turbo S.
_
911 Turbo S (WLTP, vorläufige Werte) Kraftstoffverbrauch kombiniert: 11,8 – 11,6 l/100 km;
CO2-Emissionen kombiniert: 266 – 262 g/km; CO2-Klasse: G; Stand 09/2025

**2025-09-11T11:35:42.081989** - Julia:
> 

**2025-09-11T12:07:32.536389** - Julia:
> 

**2025-09-11T12:12:25.439109** - Julia:
> 

**2025-09-11T12:35:32.328849** - Julia:
> Überraschendes Feature zum neuen Cayenne Electric Prototyp.

**2025-09-11T15:02:29.835089** - Julia:
> 

**2025-09-11T17:07:00.463789** - Julia:
> zeigen wir jetzt am handy das Atmo Schnitt video? was wir gut fänden?

**2025-09-12T10:39:47.381619** - Julia:
> Pure Personality: Der 911 Spirit und der GT3 zeigen, was Sonderwunsch bedeutet. Aus Ikonen werden Unikate – und beweisen, dass Perfektion immer noch persönlicher geht.

**2025-09-12T10:48:31.536019** - Julia:
> Ob Tasten oder PS – Hauptsache Gefühl.

**2025-09-12T10:48:43.528229** - Julia:
> Performance hat viele Formen.
Keys &amp; Curves

**2025-09-12T14:36:10.845549** - Julia:
> 70s Vibes bis ins kleinste Detail.

-
911 Spirit 70 (WLTP): Kraftstoffverbrauch kombiniert: 10,9 – 10,7 l/100 km; CO₂-Emissionen kombiniert: 246 – 242 g/km; CO₂-Klasse: G; Stand 09/2025

**2025-09-12T14:38:23.727699** - Julia:
> Lackiert, bestickt, geprägt: Sonderwunsch at its finest.

-
911 GT3 mit Touring-Paket (WLTP): Kraftstoffverbrauch kombiniert: 13,8 l/100 km; CO₂-Emissionen kombiniert: 312 g/km; CO₂-Klasse: G; Stand 09/2025

**2025-09-12T15:25:26.317669** - Julia:
> Post Malone: (Intro too long) <https://www.tiktok.com/@lifeonfilm.27/video/7480270365785132319>

**2025-09-12T15:26:40.514119** - Julia:
> Ed Sheeran: <https://www.tiktok.com/@lifeonfilm.27/video/7415306562585054494>

**2025-09-12T17:45:03.690029** - Julia:
> Handwerkskunst trifft Handwerkskunst: Porsche x Steinway

-
911 Spirit 70 (WLTP): Kraftstoffverbrauch kombiniert: 10,9 – 10,7 l/100 km; CO₂-Emissionen kombiniert: 246 – 242 g/km; CO₂-Klasse: G; Stand 09/2025

**2025-09-12T17:50:14.022169** - Julia:
> WAS WAR MIT D

**2025-09-13T13:37:17.571809** - Julia:
> 911 Spirit 70 (WLTP): Kraftstoffverbrauch kombiniert: 10,9 – 10,7 l/100 km; CO₂-Emissionen kombiniert: 246 – 242 g/km; CO₂-Klasse: G; Stand 09/2025

**2025-09-13T15:51:12.612739** - Julia:
> #PorscheFamily Portrait @ PORSCHE. THERE IS NO SUBSTITUTE. DAY
POV: Giving a camera to a stranger.

-
911 Spirit 70 (WLTP): Kraftstoffverbrauch kombiniert: 10,9 – 10,7 l/100 km; CO₂-Emissionen kombiniert: 246 – 242 g/km; CO₂-Klasse: G; 911 Turbo S Cabriolet (WLTP, vorläufige Werte): Kraftstoffverbrauch kombiniert: 11,8 – 11,7 l/100 km; CO₂-Emissionen kombiniert: 267 – 265 g/km; CO₂-Klasse: G; Stand 09/2025

**2025-09-13T19:05:30.045759** - Julia:
> <https://www.figma.com/design/7P5fTRcISCX1xDyTeA0TCr/IAA-Content?node-id=129-91&amp;t=RQkcagZei8IkHDjj-1>

**2025-09-13T20:42:03.426219** - Julia:
> Im Rahmen der IAA beim Porsche. There is no substitute. Day. hat die #PorscheFamily gezeigt, was sie ausmacht.
Porsche Klassiker, gute Gespräche, Zusammenhalt. Einfach - good vibes only.

-
911 Spirit 70 (WLTP): Kraftstoffverbrauch kombiniert: 10,9 – 10,7 l/100 km; CO₂-Emissionen kombiniert: 246 – 242 g/km; CO₂-Klasse: G; 911 Turbo S Cabriolet (WLTP, vorläufige Werte): Kraftstoffverbrauch kombiniert: 11,8 – 11,7 l/100 km; CO₂-Emissionen kombiniert: 267 – 265 g/km; CO₂-Klasse: G;
Cayenne Turbo E-Hybrid (WLTP): Kraftstoffverbrauch gewichtet kombiniert: 5,3 – 4,8 l/100 km; Kraftstoffverbrauch bei entladener Batterie kombiniert: 11,9 – 11,3 l/100 km; Stromverbrauch gewichtet kombiniert: 20,4 – 20,0 kWh/100 km; CO₂-Emissionen gewichtet kombiniert: 119 – 108 g/km; CO₂-Klasse gewichtet kombiniert: D – C; CO₂-Klasse bei entladener Batterie: G; Stand 09/2025

**2025-09-14T09:01:21.077009** - Julia:
> GuMooo

**2025-09-14T18:30:31.301329** - Julia:
> <https://drive.google.com/drive/folders/1MzsPnc1S_2OJ68Em_3xM_jcbcjXmdrNO>

**2025-09-17T11:57:49.842659** - Julia:
> Hilfe, was soll ich hier machen?

**2025-09-17T12:01:12.936379** - Julia:
> Aso wegen Content entwickeln

**2025-09-17T12:01:17.699299** - Julia:
> Ja hab ich in der mail gelesen :slightly_smiling_face:

**2025-09-17T12:09:20.269349** - Julia:
> okee

**2025-09-17T12:30:45.684259** - Julia:
> Und was wir halt bei slide 1 haben - bitte achtet darauf dass das Bild ausgerichtet ist. Aktuell ist es links nicht parallel.

Was meint sie hier?

**2025-09-17T12:37:25.851349** - Julia:
> geklärt

**2025-09-17T12:41:15.739879** - Julia:
> Hier schon mal die Slides, je nachdem, ob Charly noch etwas angepasst haben will oder nicht:
<https://drive.google.com/drive/folders/1RNzMHprIul_wKUoMmvm8KHdLbuLVJPUQ>

**2025-09-17T13:44:17.286089** - Julia:
> Juliaaaa

**2025-09-17T13:44:25.405909** - Julia:
> Das ist der "normale" Cayenne oder?

**2025-09-17T13:44:36.120899** - Julia:
> 

**2025-09-17T13:49:32.959479** - Julia:
> hab dich gehört, oh maaan

**2025-09-17T13:50:32.877119** - Julia:
> okay ich frag ihn

**2025-09-17T13:51:10.010389** - Julia:
> Hatte sie in whatsapp geschrieben

**2025-09-17T13:52:24.338569** - Julia:
> ich sowieso :smile:

**2025-09-17T13:52:44.571839** - Julia:
> ich hab keine Ahnung

**2025-09-17T13:55:33.248979** - Julia:
> Soll ich es mal mit VBWs einfach reinschicken?

**2025-09-17T13:55:37.071949** - Julia:
> sicher ist sicher

**2025-09-17T13:59:12.974559** - Julia:
> dankeee!!

**2025-09-17T14:04:20.602959** - Julia:
> Hier nochmal mit den Updates: <https://drive.google.com/drive/folders/1RNzMHprIul_wKUoMmvm8KHdLbuLVJPUQ>

**2025-09-17T14:11:28.568909** - Julia:
> hier. hätte jetzt den Fragesticker genommen und geschrieben:

Dein Tipp:

**2025-09-17T14:13:00.327979** - Julia:
> Ne sie wollte den "offenen"

**2025-09-17T14:13:10.716769** - Julia:
> Also wo Leute ihre Antworten reinschreiben

**2025-09-17T14:13:59.587889** - Julia:
> "Umfragesticker offen"

**2025-09-17T14:17:02.932889** - Julia:
> das ist echt HART

**2025-09-17T14:17:05.416609** - Julia:
> Also

**2025-09-17T14:17:16.226309** - Julia:
> ich bin der deutschen Sprache mächtig

**2025-09-17T14:17:30.620569** - Julia:
> :smile:

**2025-09-17T14:18:56.376809** - Julia:
> ich glaubs nicht

**2025-09-17T14:22:32.304449** - Julia:
> ich glaube die brauchen mehr input.
Also sowas wie:

Visuell: Bildausschnitt wurde gedreht, Ansicht nur so möglich wegen Lesbarkeit
Slide 7: unserer Meinung nach keine VBWs notwendig, aber checkt das gerne nochmal
Texte: alle grammatikalisch durch GPT gejagt – passt alles

**2025-09-17T14:22:51.672869** - Julia:
> Also, dass man ihnen zu jeder einzelnen Slide erklärt wieso, weshalb, warum

**2025-09-17T14:23:07.485289** - Julia:
> Achsooo du bist off? Das hab ich nicht verstanden sorry

**2025-09-17T14:25:31.396039** - Julia:
> perfekt, danke!

**2025-09-17T14:25:42.879039** - Julia:
> Bist du morgen dann wirklich off, oder?

**2025-09-17T14:28:34.300009** - Julia:
> ich check garnichts mehr

**2025-09-17T14:28:38.697429** - Julia:
> das ist doch nicht ihr ernst

**2025-09-17T14:30:24.450629** - Julia:
> ich bin gerade wirklich, wirklich sprachlos

**2025-09-17T14:32:43.035519** - Julia:
> krass

**2025-09-17T14:32:49.340219** - Julia:
> wirklich krass

**2025-09-17T14:33:39.571709** - Julia:
> ja mach ich

**2025-09-17T14:33:44.931009** - Julia:
> bin wirklich schockiert :smile:

**2025-09-17T14:34:04.590129** - Julia:
> Also sorry to say: aber wir sind ja nicht nur irgendwelche Pixelschubser

**2025-09-17T14:34:33.046009** - Julia:
> puh

**2025-09-17T14:35:04.483679** - Julia:
> :exploding_head:

**2025-09-17T14:36:09.394769** - Julia:
> Vllt wäre es auch ganz smart, wenn ich sobald Charly wieder da ist, was zum Feedback Prozess sage und in einem meeting halt sage wie das sonst abläuft, eine Feedback Runde und nicht hin und her, da wir da garnicht die Kapazität haben..?

**2025-09-17T14:39:27.475509** - Julia:
> krass krass krass

**2025-09-18T09:50:34.816189** - Julia:
> Hello! ja klar

**2025-09-18T09:50:51.533379** - Julia:
> ich komme zum Termin jetzt evtl. 5 min später

**2025-09-18T10:38:56.681239** - Julia:
> jaaa

**2025-09-18T11:17:48.225249** - Julia:
> ja voll

**2025-09-18T11:19:50.392259** - Julia:
> ich muss mich bei den themen noch bisschen reinfinden – hab dann oft keine Ahnung wovon ihr sprecht :joy:

**2025-09-18T11:24:16.841529** - Julia:
> mach ich

**2025-09-18T11:25:38.981429** - Julia:
> ich würde jetzt mal die ganzen asana tasks bearbeiten und dann kann ich gerne mit den themen von gerade weitermachen (Konfiguration, Targa Geheimnisse, Grundrauschen --&gt; muss ich mir nochmal anschauen was das ist)

Retro Sunday macht wer? Da hatten wir doch eigentlich die Präsi mit 4 Wochen, oder?

**2025-09-18T11:27:45.061999** - Julia:
> kann ich auch – müsste nur wissen, wo so retro bilder usw. abliegen

**2025-09-18T11:27:48.192679** - Julia:
> oder was noch fehlt

**2025-09-18T11:28:28.782369** - Julia:
> und noch eine Frage – so diese caption (Malmedie Must Drives) die ich für Flo geschrieben hab, kommt das dann auch bei dir an? nicht, dass das jetzt unter gegangen ist

**2025-09-18T11:28:47.566319** - Julia:
> weil er hatte mich da in der mail drum gebeten, hab ihm geantwortet und aber nochmal im asana reingeschrieben

**2025-09-18T11:29:06.446509** - Julia:
> hab noch nicht ganz den Durchblick was Flo übernimmt und was eigentlich du etc. etc.

**2025-09-18T11:45:32.559839** - Julia:
> schau ich mir gleich an, versuch kurz Christo zu verstehen :smile:
War denn dieser Look (schwarzer Schatten-Rahmen) so gewollt?

**2025-09-18T11:51:22.695599** - Julia:
> ich erstelle mir jetzt mal kurz ein Asana Board – bin ich noch nicht dazu gekommen. muss mich mal sortieren

**2025-09-18T12:09:24.985979** - Julia:
> 

**2025-09-18T12:23:44.518779** - Julia:
> okeee

**2025-09-18T12:23:46.369049** - Julia:
> danke!

**2025-09-18T12:43:18.037099** - Julia:
> hab Christo gefeedbackt – kannst ja gerne mal schauen :slightly_smiling_face: bin bei Feedback geben nicht unsicher, aber muss die Leute dafür einschätzen können &amp; das konnte ich bisher noch nicht.

<https://app.asana.com/1/1199360402832734/project/1211393508341245/task/1210556034500746?focus=true>

**2025-09-18T12:49:01.312259** - Julia:
> weiß gerade nicht was es für eine aufgabe ist aber FYI:
Mache mit Mert gerade diese Posts ready + schreibe die Captions
<https://www.canva.com/design/DAGuwILJwac/V8FYbooOUuKrZbdwEwno7w/edit>

**2025-09-18T12:51:26.066089** - Julia:
> paaaasst danke :slightly_smiling_face:

**2025-09-18T12:55:00.295759** - Julia:
> alright! happy day :slightly_smiling_face:
Schau ich mir an

**2025-09-18T16:22:07.927489** - Julia:
> juhuu

**2025-09-18T16:22:15.615739** - Julia:
> hab dich in asana bei paar sachen markiert :)

**2025-09-18T16:22:51.191039** - Julia:
> perfekt :slightly_smiling_face:

**2025-09-18T16:23:14.323619** - Julia:
> ich vllt auch!

**2025-09-18T16:29:19.194859** - Julia:
> Ne ist wieder weg, bisher immer nur morgens

**2025-09-18T16:29:20.302849** - Julia:
> :smile:

**2025-09-18T16:43:26.069869** - Julia:
> hab retro sunday nochmal bissl angepasst – timing

**2025-09-18T17:28:52.545939** - Julia:
> ja

**2025-09-18T17:29:52.060539** - Julia:
> okay

**2025-09-18T17:30:21.993369** - Julia:
> okay moment

**2025-09-18T17:31:10.086789** - Julia:
> hab ihm parallel geschrieben und ich suche auch, ob ich es finde

**2025-09-18T17:31:43.641839** - Julia:
> okay moment

**2025-09-18T17:31:48.841559** - Julia:
> mert schaut auch

**2025-09-18T17:34:12.800889** - Julia:
> tasten uns ran

**2025-09-18T17:35:20.274729** - Julia:
> HABS

**2025-09-18T17:35:27.024569** - Julia:
> 

**2025-09-18T17:36:01.023329** - Julia:
> das wars, nur das hier fehlt

**2025-09-18T17:36:43.564339** - Julia:
> das weiß ich nicht, hier ist nur das Asset in Drive ahhh

**2025-09-18T17:37:35.581799** - Julia:
> ja passt doch da voll rein

**2025-09-18T17:38:00.962909** - Julia:
> kannst du es posten? ja oder? zum brand store hab ich nämlich keinen zugriff damals bekommen

**2025-09-18T17:38:50.328189** - Julia:
> okay

**2025-09-18T17:38:53.086799** - Julia:
> puh

**2025-09-18T17:39:13.498099** - Julia:
> Wie kann ein Kunde so viel Druck ausüben auf uns hahah

**2025-09-18T17:39:42.389259** - Julia:
> ja vollkommen verständlich

**2025-09-18T17:40:11.650959** - Julia:
> wahrscheinlich eine kombi :disappointed:

**2025-09-18T17:45:41.723739** - Julia:
> Passen die Sachen soweit von heute? Modelle der Woche, Retro Sunday, Captions für Malmedie Teaser?

Grid und Cayenne Extreme bin ich noch dran. Beim Cayenne Extreme aber unsicher, ob Mert hier mit 3 Posts geplant hat

**2025-09-19T09:40:26.848139** - Julia:
> Guten Morgen hier nochmal :slightly_smiling_face: GIbt es eine Teams Gruppe in die ich nochmal bezüglich des Sharepoints Zugriff fragen kann? Bei mir ist da keine oder wem soll ich am besten schreiben?

**2025-09-19T09:41:02.012679** - Julia:
> bekomme nach wie vor diese Meldungen und wollte eben die Präsi fürs Gipfeltreffen (Highlight und Grid --&gt; hab die Version trotzdem schon fertig) ablegen

**2025-09-19T09:42:04.047819** - Julia:
> okay schade

**2025-09-19T09:42:14.609409** - Julia:
> dann schick ich dir unseren Drive link:

**2025-09-19T09:43:45.408099** - Julia:
> mit heutigem Datum: <https://drive.google.com/drive/folders/1XrdiqskAo9Ql_hkYkH3MbaFym7L36bzM>

**2025-09-19T09:43:46.935579** - Julia:
> danke!

**2025-09-19T09:47:41.133869** - Julia:
> Also liegen ja schon seit Beginn drin und eigentlich auch genau das was Denise gestern meinte "starten wieder rein, mit der Family"
Deshalb war ich mir nicht sicher, was sie anders haben möchten. Hast du eine Idee?

**2025-09-19T09:55:48.126599** - Julia:
> Achso!

**2025-09-19T09:56:35.488079** - Julia:
> Ja kann ich gerne mit reinnehmen, aber dauert noch kurz

**2025-09-19T10:13:22.655879** - Julia:
> Also die "Task" von Flo versteh ich nicht ganz, aber sprechen wir ja gleich dazu :smile:

**2025-09-19T10:15:04.988429** - Julia:
> Ansonsten hab ich auf meinem Zettel:
• Brand Store: Grundrauschen anschauen
• TINS Konzepte 
• Brand Store: Konfiguration 3-4 Wochen Content
• Bezahlte Werbelabel bei Gipfeltreffen Personen checken


**2025-09-19T10:27:59.061609** - Julia:
> juhuu danke!

**2025-09-19T10:56:51.213419** - Julia:
> eine Frage beim Cayenne: es gibt noch keine VBWs weil der noch nicht draußen ist, oder?

**2025-09-19T11:01:40.038719** - Julia:
> okay super

**2025-09-19T11:01:58.253249** - Julia:
> also Mert hat glaub ich gerade keine Zeit zum gucken, deshalb kannst du es ja auch so rausschicken

**2025-09-19T11:04:15.920759** - Julia:
> höö? also wenn man drauf klickt dann gehts nicht?

**2025-09-19T11:04:53.259669** - Julia:
> das mit diesem online bearbeiten ist echt so doof

**2025-09-19T11:07:52.740799** - Julia:
> okay, sorry und danke!

**2025-09-19T11:27:31.662149** - Julia:
> also wegen brand store: es geht einfach um generelle content ideen. keinen bezug zum sommerfest, right?

**2025-09-19T11:33:45.750319** - Julia:
> okay okay

**2025-09-19T11:33:54.355569** - Julia:
> ich arbeite mal in der präsentation weiter, oder?

**2025-09-19T11:34:29.792019** - Julia:
> "ongoing konzepte"

**2025-09-19T11:57:47.107119** - Julia:
> okay got it. ja schau ich mir gerade an

**2025-09-19T12:47:03.722519** - Julia:
> 

**2025-09-19T13:00:29.182249** - Julia:
> yes

**2025-09-19T14:30:08.177539** - Julia:
> Kurze Frage

**2025-09-19T14:30:14.581799** - Julia:
> welches Buch wird nochmal im BS vorgestellt? :smile:

**2025-09-19T14:32:19.082429** - Julia:
> ahja

**2025-09-19T14:32:19.813259** - Julia:
> dankee

**2025-09-19T14:53:20.750219** - Julia:
> content der nicht stark ist --&gt; meinst du videos oder? <https://drive.google.com/drive/folders/1j4meRvzjK7Zm8UKYxHGQ_JVVk76t3qk7>

**2025-09-19T14:53:48.125709** - Julia:
> schau ich mir an

**2025-09-19T15:02:03.115549** - Julia:
> schau ich mir an, bin mit flo im call

**2025-09-19T16:14:29.742319** - Julia:
> posten wir jeden tag auf dem BS?

**2025-09-22T10:25:03.874059** - Julia:
> Hellooo :slightly_smiling_face:

**2025-09-22T10:26:05.845519** - Julia:
> Hast du die Captions von Laetitia schon gesehen? oder könntest du sie mir schicken? Würde ich jetzt mal direkt fertig machen

**2025-09-22T10:38:19.076889** - Julia:
> Ich hab da immer noch keinen Zugriff. Das kann dann nur Marie oder? Könntest du mir eine Kopie schicken oder so?

**2025-09-22T10:38:52.250409** - Julia:
> Ich habs totaaaal vergessen, dass wir unser Essen haben. Bin noch im Schlafi :joy: Also irgendwie nach mittags rum?

**2025-09-22T10:43:50.618359** - Julia:
> dankeee

**2025-09-22T10:44:10.062519** - Julia:
> Achso sie hats doch direkt bei uns rein, got it

**2025-09-22T10:55:25.754519** - Julia:
> nicht wirklich ne

**2025-09-22T10:59:49.538409** - Julia:
> Ehm okay?

**2025-09-22T11:00:20.454419** - Julia:
> Also ich kann natürlich gerne irgendwie helfen, aber ich weiß ja gefühlt garnicht von was

**2025-09-22T11:34:03.043269** - Julia:
> okidoki, mache kurz die gipfeltreffen captions fertig und dann schau ich rein

**2025-09-22T11:43:47.337009** - Julia:
> okay :slightly_smiling_face: dankee dir

**2025-09-22T11:44:35.295559** - Julia:
> 

**2025-09-22T11:46:34.951229** - Julia:
> neee :sleepy:

**2025-09-22T11:58:09.928019** - Julia:
> dankee, schau ich mir an!

**2025-09-22T11:58:19.043049** - Julia:
> Gipfeltreffen Captions: <https://drive.google.com/drive/folders/1XrdiqskAo9Ql_hkYkH3MbaFym7L36bzM>

**2025-09-22T12:08:18.650499** - Julia:
> Wann fährst du ins Büro?

**2025-09-22T12:08:39.706059** - Julia:
> Hast du sonst kurz paar Minuten, dass wir die Präsi nochmal kurz durchgehen?

**2025-09-22T12:09:59.203649** - Julia:
> gernee

**2025-09-22T12:10:29.405449** - Julia:
> bin da

**2025-09-22T12:43:22.766459** - Julia:
> ja klar, bitte

**2025-09-22T12:43:46.211969** - Julia:
> Die Tage haben bestimmte Themes laut Produktion

**2025-09-22T12:49:11.721109** - Julia:
> ja versteh ich

**2025-09-22T12:49:14.778719** - Julia:
> okay

**2025-09-22T12:49:36.810129** - Julia:
> also ich hatte sie schon super krass angepasst, wir hatten 3er Text Blöcke von Laetitia abliegen

**2025-09-22T12:49:41.364829** - Julia:
> soll ich nochmal drüber?

**2025-09-22T12:53:06.687659** - Julia:
> okay!

**2025-09-22T15:56:59.228079** - Julia:
> okay, wild :smile:

**2025-09-22T16:03:00.819289** - Julia:
> in unserem suchverlauf :smile:

**2025-09-22T16:03:04.272599** - Julia:
> also nicht meiner

**2025-09-22T16:04:01.010389** - Julia:
> Keine Ahnung – ist auch egal, aber ich würds mal löschen. Find ich schwierig, wenn das Flo sieht

**2025-09-22T16:10:07.466469** - Julia:
> kündigung ist raaaus

**2025-09-22T16:10:15.023489** - Julia:
> kommst du jetzt zum ppm ins büro?

**2025-09-22T16:17:04.631279** - Julia:
> ah okay, ja alles gut!

**2025-09-22T16:17:25.914919** - Julia:
> hat sie dir schon feedback zu den Grid Themen gegeben?

**2025-09-22T16:17:39.536749** - Julia:
> AH jetzt seh ich die Mail

**2025-09-22T16:33:28.485889** - Julia:
> Dateien liegen hier für dich zum Upload:
<https://drive.google.com/drive/folders/1tIQugcxuigtB1ukTFc55O-zUavxvx580>


Bezüglich der Caption: Ne die Reihenfolge ist so gewollt. Damit wir bei "Amore Motore" auch das Wort Gipfeltreffen in der Caption haben --&gt; ist ja der erste Post der rausgeht.
Beim Visual "Gipfeltreffen" haben wir dann analog auch wieder Amore Motore textlich aufgegriffen. So haben wir überall alles drin

**2025-09-22T16:50:42.630359** - Julia:
> ich glaube nicht, dass ich das bis Mittwoch schaffe tbh
<https://app.asana.com/1/1199360402832734/project/1210522556460296/task/1210703906249623?focus=true>

**2025-09-22T16:57:38.078099** - Julia:
> :fast_parrot:

**2025-09-22T17:06:14.144729** - Julia:
> ich glaube Hanna versteht das mit der Caption nicht. hier nochmal:
Wir posten ja zuerst das "Amore Motore" Visual – damit das nicht alleine steht, gehen wir textlich auf Gipfeltreffen.
Die Community liest natürlich erst die Caption 3 ("... seid gespannt"), wenn sie drauf klicken. Aber dadurch, dass es sich Visual erklärt, zieht sich inhaltlich ein roter Faden

**2025-09-22T17:11:53.462019** - Julia:
> total. das noch on top ciaaaao

**2025-09-22T17:36:04.502629** - Julia:
> zorri das ist halt das KV :smile:

**2025-09-22T17:36:10.486839** - Julia:
> Wegmachen dann einfach?

**2025-09-22T17:36:20.759269** - Julia:
> von wem kam das feedback?

**2025-09-22T17:40:32.434029** - Julia:
> okay

**2025-09-22T17:40:46.197199** - Julia:
> ich mach es sobald ich adobe nutzen kann

**2025-09-22T17:41:17.362609** - Julia:
> hungeeeeer :smile:

**2025-09-22T17:41:58.464139** - Julia:
> wir können ja beim essen den laptop aufhaben – porsche würde es lieben

**2025-09-22T18:04:04.734199** - Julia:
> <https://drive.google.com/drive/folders/1tIQugcxuigtB1ukTFc55O-zUavxvx580>

**2025-09-22T18:04:19.690299** - Julia:
> 

**2025-09-22T18:15:16.395809** - Julia:
> wooo?

**2025-09-22T18:15:19.902809** - Julia:
> im büro?

**2025-09-22T18:15:22.070919** - Julia:
> jaa

**2025-09-23T09:15:05.132799** - Julia:
> Guten Morgen, mich hats heute nacht mit Migräne erwischt :face_with_peeking_eye: ich bin immer noch nicht fit und hab soo starke Kopfschmerzen, aber versuche später wieder weiter zu machen mit Reporting, Social Media etc.

**2025-09-23T12:38:30.317339** - Julia:
> hallo :slightly_smiling_face: dankee, so ätzend.. aber ich versuch gerade das reporting wenigstens fertig zu bekommen mit flo's änderungswünschen. zwei Fragen kamen gestern bei Flo dann auf:
• ob die 33% wirklich stimmen
• was war am 14.8. --&gt; so viele Follower bekommen

**2025-09-23T14:21:50.110039** - Julia:
> I know, ich geb mein Bestes aber wird gerade nicht besser. Versuche heute abend noch was zu schaffen. Ich hab Mert versucht ales zu erklären, ob er schon erste Drafts machen kann. Ich bearbeite die Präsi nochmal mit dem Contenthaus Themen was Hanna wollte.
Wann ist der Termin? hab keinen im Kalender

**2025-09-23T17:06:08.381619** - Julia:
> hab die inhalte nochmal etwas angepasst, je nach feedback und eben diese contenthaus themen zugeordnet und gegliedert. die inhalte die ich als weekly inhalte sehe sind auch markiert. rest noch tbd :face_with_spiral_eyes:

**2025-09-24T07:47:10.558279** - Julia:
> Hello, mich hats dann komplett zerlegt. Hab plötzlich hohes Fieber bekommen abends. Bin immer noch fiebrig.. :sob: also kann heute eher nichts präsentieren - können wir den Call auf morgen legen?  

**2025-09-25T09:45:21.877929** - Julia:
> jaaa bitte. Um 10?

**2025-09-25T10:00:28.024849** - Julia:
> call von später?

**2025-09-25T10:45:36.027669** - Julia:
> so bad was ich gesagt habe? :smile:

**2025-09-25T10:46:32.279699** - Julia:
> mist

**2025-09-25T10:47:58.161879** - Julia:
> jaa, ich würde mal damit starten:

• Artur Kar Carousel/ Content check
• Intro Store: Grundriss bei Hanna anfragen
• Präsi BS | Präsi Porsche DE aufbauen
• UGC Prozess Asana angucken --&gt; Porsche Family challangen
• Targa Event --&gt; Fotografen/ Videografen checken

**2025-09-25T10:48:21.578219** - Julia:
> bestimmt :smile:

**2025-09-25T10:48:54.957359** - Julia:
> kannst du mir noch die Artur Kar Präsi schicken?

**2025-09-25T10:52:31.464799** - Julia:
> Und ist Marie wieder da? Wegen dem Sharepoint Zugriff..

**2025-09-25T10:58:06.925129** - Julia:
> doch?

**2025-09-25T10:58:08.571199** - Julia:
> komisch

**2025-09-25T10:58:25.860889** - Julia:
> dankee!

**2025-09-25T11:12:39.671099** - Julia:
> Süß, mach ich

**2025-09-25T11:13:30.590299** - Julia:
> Könntest du mir die einzelnen Arthur Kar Ordner schicken? Ich bau es grad in Figma, damit wir dann alles ready haben. Aber ich hab nur hierauf Zugriff:

**2025-09-25T11:13:43.851859** - Julia:
> 

**2025-09-25T11:13:46.381739** - Julia:
> und das video hab ich

**2025-09-25T11:17:10.046769** - Julia:
> ahh okay, also du lädst das dann auch immer direkt bei uns in den drive?

**2025-09-25T11:17:14.838149** - Julia:
> perfekt danke!

**2025-09-25T12:29:06.669129** - Julia:
> 

**2025-09-25T12:36:27.805519** - Julia:
> jaaa

**2025-09-25T12:36:39.759489** - Julia:
> ich weiß auch nicht wieso das manchmal geht und manchmal nicht

**2025-09-25T12:36:40.563189** - Julia:
> dankee

**2025-09-25T13:14:28.112669** - Julia:
> <https://www.instagram.com/svencich?utm_source=ig_web_button_share_sheet&amp;igsh=ZDNlZDc0MzIxNw==>

<https://www.nicolasbaer.de/projects>

<https://www.instagram.com/maxxholley?utm_source=ig_web_button_share_sheet&amp;igsh=ZDNlZDc0MzIxNw==>

<https://www.instagram.com/yannikmichael?utm_source=ig_web_button_share_sheet&amp;igsh=ZDNlZDc0MzIxNw==>

**2025-09-25T13:14:45.309269** - Julia:
> Fotografen/ Videografen. Super schwierig da gute für Events zu finden..

**2025-09-25T13:15:04.205179** - Julia:
> Yannik könnte cool sein

**2025-09-25T14:08:07.426659** - Julia:
> Okee 

**2025-09-25T14:21:18.449779** - Julia:
> Ich schreib gleich wegen caption 

**2025-09-25T14:41:02.294269** - Julia:
> Gipfeltreffen Tag 1 – Mehr als nur ein Wiedersehen. Das ist Herzblut auf vier Rädern mit @axelstein4real und @matthiasmalmedie
-

911 GT3 (PDK) (WLTP): Kraftstoffverbrauch kombiniert: 13,8 l/100 km; CO₂-Emissionen kombiniert: 312 g/km; CO₂-Klasse: G;
911 GT3 mit Touring-Paket (MT) (WLTP): Kraftstoffverbrauch kombiniert: 13,7 l/100 km; CO₂-Emissionen kombiniert: 310 g/km; CO₂-Klasse: G; Stand 09/2025

**2025-09-25T14:41:55.426689** - Julia:
> Oder soll ich posten?

**2025-09-25T14:42:53.864069** - Julia:
> ne das eine ist das thumbnail

**2025-09-25T14:44:45.487809** - Julia:
> ahh okay

**2025-09-25T14:44:59.706559** - Julia:
> nee lass das doch reinschreiben, oder? gut für uns :smile:

**2025-09-25T14:49:12.722859** - Julia:
> ne

**2025-09-25T14:51:46.906269** - Julia:
> :face_with_peeking_eye:

**2025-09-25T14:52:39.098569** - Julia:
> Wenn du morgen off bist: bezüglich Freigabe/ Feedback von Hanna usw. soll ich dann einfach über Mail machen, oder?

**2025-09-25T14:57:37.419149** - Julia:
> yes moment

**2025-09-25T14:58:10.387469** - Julia:
> Entwürfe sind nur bei dir am handy

**2025-09-25T14:58:44.433409** - Julia:
> ich kanns auch posten

**2025-09-25T14:58:57.659159** - Julia:
> bzw probieren, aber dann dürfen wir nicht gleichzeitig :smile:

**2025-09-25T14:59:29.609339** - Julia:
> yes, bin ready

**2025-09-25T15:00:44.362309** - Julia:
> bei mir auch!!!

**2025-09-25T15:00:53.991469** - Julia:
> komplett abgestürzt

**2025-09-25T15:01:31.738359** - Julia:
> weils wahrscheinlich riesig ist

**2025-09-25T15:01:43.520889** - Julia:
> 

**2025-09-25T15:02:19.012059** - Julia:
> 175 mb

**2025-09-25T15:02:56.234719** - Julia:
> nee hab geguckt. kann 4gb sein

**2025-09-25T15:02:56.999859** - Julia:
> okay

**2025-09-25T15:03:01.167789** - Julia:
> ich versuch auch weiterhin

**2025-09-25T15:04:03.575109** - Julia:
> bei mir liegts am titelbild

**2025-09-25T15:04:46.728629** - Julia:
> versuchs mal damit:

**2025-09-25T15:05:15.211859** - Julia:
> 

**2025-09-25T15:08:12.381289** - Julia:
> ja

**2025-09-25T15:10:38.486619** - Julia:
> vooooll

**2025-09-25T15:10:39.680659** - Julia:
> was ist das

**2025-09-25T15:10:45.236569** - Julia:
> kann flo es versuchen? ist der daß

**2025-09-25T15:13:46.251319** - Julia:
> okay

**2025-09-25T15:16:26.072999** - Julia:
> ja was weiß ich :smile:

**2025-09-25T15:16:32.152459** - Julia:
> die wissen ja alles besser haha

**2025-09-25T15:42:26.705099** - Julia:
> Klar

**2025-09-25T16:07:10.447699** - Julia:
> wenn du magst, gerne jetzt. fange danach den reminder an

**2025-09-25T16:40:06.512599** - Julia:
> yeees moment. hab reminder jetzt nochmal gemacht - legs jetzt in die Präsi ab und du schickst es an Hanna oder soll ich?

**2025-09-25T16:44:05.170229** - Julia:
> so reminder liegt ab :slightly_smiling_face:

**2025-09-25T16:44:23.918559** - Julia:
> slide 9

**2025-09-25T16:46:31.289409** - Julia:
> yes

**2025-09-25T17:18:02.350189** - Julia:
> danke!

**2025-09-26T12:06:25.680219** - Julia:
> hallooo, bist du da? Falls ja, hab ich nur eine kurze Frage

**2025-09-29T12:27:49.229149** - Julia:
> wann fliegst du heute? :face_holding_back_tears:

**2025-09-29T12:33:28.006529** - Julia:
> ahh krass

**2025-09-29T12:33:29.113719** - Julia:
> ja klar

**2025-09-29T13:28:01.456329** - Julia:
> das ist eine gute frage :smile:

**2025-09-29T13:28:32.817169** - Julia:
> ich glaube das UGC thema fällt bei mir heute runter

**2025-09-29T13:29:01.756949** - Julia:
> BS Stories hab ich Hanna jetzt das Update geschickt. Nach der Mittagspause kümmere ich mich um diese Insider Single Posts

**2025-09-29T13:29:05.319379** - Julia:
> für Charly

**2025-09-29T13:29:22.754799** - Julia:
> die hat zwar eh einen haufen an Content zum feedbacken, aber für uns ja auch mal nicht schlecht :slightly_smiling_face:

**2025-09-29T13:29:43.687089** - Julia:
> Modell des Monats hab ich noch nicht in die Präsi --&gt; wusste nicht, ob Flo das jetzt rausschicken wollte oder nicht

**2025-09-29T13:33:32.963859** - Julia:
> 

**2025-09-29T14:27:23.722629** - Julia:
> gerne

**2025-09-29T14:27:39.632619** - Julia:
> Bin wieder da!

**2025-09-29T14:36:51.524009** - Julia:
> Hab leider noch keinen Zugriff zur Präsi – könntest du es einfügen?

Caption 1:
Jeder Traum hat einen Ursprung. Die Sonderwunsch-Doku begleitet Persönlichkeiten von der ersten Idee bis zum einzigartigen Fahrzeug.
Mutige Farben, edle Materialien, feine Details – hier entstehen Unikate mit Charakter.
Sonderwunsch – wenn Träume fahren lernen.

Caption 2:
Episode 2: Aus Ideen werden Skizzen, aus Skizzen ein Konzept.
Kreativität trifft Präzision – der Beginn einer Vision startet hier: Sonderwunsch bei Porsche.

Caption 3:
Episode 3 der Sonderwunsch-Serie: Der nächste Schritt zum Unikat.
Wie aus Ideen Design wird – und aus Persönlichkeit ein Porsche.

Caption 4:
Aus Vision wird Realität: Das ist Sonderwunsch. Fahrzeuge, die zu 100 % Unikat sind: geprägt von Ideen, Präzision und Mut. Was als Traum begann, steht jetzt auf eigenen Rädern.

**2025-09-29T14:41:32.173509** - Julia:
> Finde nur den 2. etwas sehr hochgestochen "was die Welt noch nicht gesehen hat"
--&gt; Vllt eher so:

Etwas Einzigartiges entsteht: Ein Unikat nimmt Form an

**2025-09-29T14:43:24.942899** - Julia:
> Wie würdest du diese "Insider" Posts zusammenfassen? Das sind einfach coole, starke Schnappschuss-Single Posts oder?

Mir ist das "Insider" in dem Fall irgendwie noch unschlüssig :smile:

**2025-09-29T14:51:29.500869** - Julia:
> wunderbar haha

**2025-09-29T14:56:42.899069** - Julia:
> also ich bin da jetzt auf jeden Fall mal dran und mach ein paar vorschläge (inklusive Gipfeltreffen)

**2025-09-29T15:26:30.869269** - Julia:
> klar gerne: <https://www.figma.com/design/902cDjeQLIyg77xt49VdZg/Porsche-DE-%F0%9F%8F%8E%EF%B8%8F?node-id=20-2&amp;t=pzFNwcu432DhhC9W-1>
Unter "Insider"

**2025-09-29T15:27:01.996949** - Julia:
> 

**2025-09-29T15:27:07.601789** - Julia:
> schnapsschuss – bräuchte ich jetzt aus :smile:

**2025-09-29T15:42:11.660839** - Julia:
> wahrscheinlich das Format

**2025-09-29T15:42:56.928529** - Julia:
> und da meinte flo zu mir das sind so schnappschüsse.
Charly meinte da sind die captions ja immer auch etwas "lustig"

**2025-09-29T15:43:12.569709** - Julia:
> deswegen weiß ich jetzt nicht was da bei sylt lustig ist :smile:

**2025-09-29T15:43:53.796349** - Julia:
> ja

**2025-09-29T15:43:57.575439** - Julia:
> als ob das Prio hat

**2025-09-29T15:49:01.147179** - Julia:
> Ja "ISSO"

**2025-09-29T15:49:16.311589** - Julia:
> deswegen war ich auch kurz geschockt: DAILY? haha

**2025-09-29T15:52:25.406459** - Julia:
> joa, ich mach noch eine halbe std. und dann lad ichs in die präsi

**2025-09-29T16:33:31.777339** - Julia:
> ah okay, schau ich gleich

**2025-09-29T16:33:34.152649** - Julia:
> danke!

**2025-09-29T16:59:17.235239** - Julia:
> puh, das ist aber irgendwie alt. Da ist das Reel garnicht eingeplant. Ich sortier mal..

**2025-09-29T17:28:47.404669** - Julia:
> ich habs charly jetzt geschickt

**2025-09-29T17:28:50.296429** - Julia:
> hoffe das war okay

**2025-09-29T17:49:45.653199** - Julia:
> Guuuten Flug dann! :heart:

**2025-09-29T17:53:04.700769** - Julia:
> ahh okay gut

**2025-09-29T17:53:44.310979** - Julia:
> danke!

**2025-09-29T17:59:57.649369** - Julia:
> ja eben, ich auch nicht..

**2025-09-29T18:03:21.398369** - Julia:
> also Hanna hatte auch nochmal feedback zur BS Präsi.. sie hängt sich da gerade so am Wording auf. Ich passe das gleich nochmal an aber langsam raucht mir der kopf :smile:

**2025-09-29T18:06:24.459889** - Julia:
> jaa wollte dir nicht noch mehr Arbeit machen :smile:

**2025-09-29T18:07:25.896869** - Julia:
> ja unbedingt. ich hab einfach grad von allen folien 3 verschieden varianten? wegen den versionen

**2025-09-29T18:07:27.367779** - Julia:
> genau

**2025-09-29T18:07:54.180329** - Julia:
> ah willst dus auseinander ziehen? hatte gedacht so wärs kompakter

**2025-09-29T18:07:59.532729** - Julia:
> aber mach ich nächstes mal dann natürlich

**2025-09-29T18:09:02.148959** - Julia:
> okay got it

**2025-09-29T18:09:14.077119** - Julia:
> jaa bitte. hätte es erst ab 4. geschickt – rest muss ich noch machen

**2025-09-29T18:09:32.967429** - Julia:
> ja so doof, ich hab das nur noch als pdf :sob: ich weiß nicht wieso

**2025-09-29T18:09:48.420539** - Julia:
> 

**2025-09-29T18:13:54.221739** - Julia:
> kann ich dir da grad noch was helfen?
Sonst geh ich jetzt mal einkaufen etc. und mach danach noch die BS Slides

**2025-09-29T18:14:39.620779** - Julia:
> okay dankeee und sag mir das gerne auch in Zukunft, was du anpassen würdest, dann mach ich das

**2025-09-29T18:16:00.313849** - Julia:
> guten entspannten Flug und bis morgen! :heart_hands:

**2025-09-30T11:13:51.742549** - Julia:
> Wie fertig bist du? Hoffe es war alles okay!

**2025-09-30T11:28:07.685289** - Julia:
> ach sehr gut

**2025-09-30T11:33:57.192909** - Julia:
> schick dir gleich eine sprachi

**2025-09-30T11:34:10.560789** - Julia:
> ja.. die war heute wieder krass drauf auch

**2025-09-30T11:41:29.054359** - Julia:
> 

**2025-09-30T11:42:27.615489** - Julia:
> ja versteh ich voll!

**2025-09-30T11:43:01.435109** - Julia:
> Ne, da ist nix auf Augenhöhe und vor allem sind wir jetzt zu dumm auf nachrichten zu antworten?

**2025-09-30T11:44:09.611569** - Julia:
> und ich muss auch sagen mit Kunden/ Dienstleistern über WhatsApp UND Sprachnachricht zu kommunizieren, find ich auch ein no go

**2025-09-30T11:51:20.722119** - Julia:
> ja, sowas lässt einen halt auch nicht immer kalt

**2025-09-30T12:41:19.990329** - Julia:
> ja sie hatte mir auch schon geantwortet

**2025-09-30T12:41:27.430519** - Julia:
> Ich bastel jetzt so gut es geht. Danke fürs Anfragen!

**2025-09-30T12:41:53.351009** - Julia:
> Ehm TINS PAG kann ich heute nicht starten, das schaff ich alles nicht

**2025-09-30T12:43:30.290809** - Julia:
> okay danke. aber andererseits haben wir für Charly diese Insider Posts vorgezogen (Wollte sie am Donnerstag) also vllt beruhigt sie das :smile:

**2025-09-30T12:43:45.577849** - Julia:
> Sobald ich Leonie fertig hab, mach ich BS weiter und dann Anpassungen für Charly von allen Posts

**2025-09-30T13:27:41.530389** - Julia:
> yes!

**2025-09-30T14:59:57.950889** - Julia:
> okay danke

**2025-09-30T15:07:20.212629** - Julia:
> Hab die Leonie <https://drive.google.com/drive/folders/138q0OD_QNMJwZ_o2xd6yH8yOCT8ZdWcv|Bilder im Drive >abgelegt – das sind aber nicht alle die wir brauchen. Wir benötigen noch die vom PDF "CMP416_LeonieBeck_verwendet"

**2025-09-30T15:19:15.923429** - Julia:
> dankeee

**2025-09-30T15:20:28.526189** - Julia:
> oh manno, ich mag das VO aber eigentlich

**2025-09-30T15:20:57.235429** - Julia:
> Wenn wir es weglassen, brauchen wir halt "Untertitel"

**2025-09-30T15:21:41.729059** - Julia:
> ja

**2025-09-30T15:21:43.447279** - Julia:
> voll

**2025-09-30T15:23:14.622329** - Julia:
> ich schreibs ihm in die asana task noch dazu

**2025-09-30T15:25:26.258859** - Julia:
> dann antworte ich Charly auch gleich dazu

**2025-09-30T16:08:30.230129** - Julia:
> lieb ich auch: Charly hatte paar mal Feedback zu den ausgewählten Bildern der Insider Posts und meinte "da gibts viiiel bessere in Picdrop, sie hat die alle markiert"
Joa, ne hat sie nicht und gibts auch nicht :smile:

**2025-09-30T16:14:48.119889** - Julia:
> nene alles gut, ich hab paar *VIEL BESSERE* bilder gefunden :smile:

**2025-09-30T16:14:53.213259** - Julia:
> jaa klar, gerne

**2025-09-30T16:20:55.162429** - Julia:
> 

**2025-09-30T16:33:15.130609** - Julia:
> okay vllt bräuchte ich doch noch jetzt einmal deine Suchhilfe :smile:
--&gt; sie wollte stärkeren Tunnel Bilder v.a. mit Taycan

**2025-09-30T16:33:45.149309** - Julia:
> danke danke danke

**2025-09-30T16:38:36.582599** - Julia:
> das find ich einfach uncool :smile:

**2025-09-30T16:45:49.469179** - Julia:
> ahh

**2025-09-30T16:45:52.466699** - Julia:
> cool!

**2025-09-30T16:48:05.926499** - Julia:
> yes, schicks dir sobald ichs hab

**2025-09-30T16:57:28.981989** - Julia:
> ja oder? aber danke! ich nehme mal eins von denen

**2025-09-30T16:58:34.418259** - Julia:
> das eine hatte ich, wollte sie nicht :smile:

**2025-09-30T17:02:42.099239** - Julia:
> vorher - nachher NAJA :smile:

**2025-09-30T17:21:38.171619** - Julia:
> i daut it 2. aber ist als auswahl gedacht, nicht carousel

**2025-09-30T17:24:10.706289** - Julia:
> hab Basti die Mail von Charly weitergeleitet

**2025-09-30T17:31:27.779699** - Julia:
> hier das Update. Hab immer dazu geschrieben, wenn und was angepasst wurde oder ich es komplett neu hinzugefügt habe

**2025-09-30T17:33:14.437159** - Julia:
> VBWs noch tbd.

**2025-09-30T17:35:07.323819** - Julia:
> ehm nee. hab nur screenshots gemacht :face_with_peeking_eye: soll ich sie raussuchen?

**2025-09-30T17:37:42.602599** - Julia:
> ich suche

**2025-09-30T17:42:54.331879** - Julia:
> links auf slide 16 sind hinzugefügt

**2025-09-30T17:44:14.055939** - Julia:
> Das Reel von Slide 15 hab ich wieder rausgenommen – da hatte Charly heute noch paar mal erwähnt, dass es auf keinen Fall sein darf, dass die StVo nicht eingehalten werden. ok

**2025-09-30T18:01:56.212609** - Julia:
> Ist basti jetzt weg?

**2025-09-30T18:15:59.225449** - Julia:
> oh ne ich habs ihm ja gesagt..?

**2025-09-30T18:21:52.205929** - Julia:
> ja

**2025-09-30T18:22:00.796309** - Julia:
> sie hatte halt geschrieben sie will es heute EOB

**2025-09-30T18:22:34.015869** - Julia:
> ich kann Flo schreiben, aber will jetzt nicht "petzen"

**2025-09-30T18:25:04.694109** - Julia:
> ich schreib ihm. happy feierabend und hoffe du bist gedanklich jetzt auch wieder in kapstadt angekommen :slightly_smiling_face::heart:

**2025-10-01T07:40:40.159219** - Julia:
> Oh wie schön :heart_eyes: 

**2025-10-01T09:09:48.585569** - Julia:
> Hello! Kann ich machen, klar

**2025-10-01T09:10:18.824139** - Julia:
> bin nicht eingeladen

**2025-10-01T09:10:37.612179** - Julia:
> muss nur um 11.30 raus und los zum arzt

**2025-10-01T09:18:37.260219** - Julia:
> passt, danke!

**2025-10-01T09:35:39.962819** - Julia:
> hab die bilder von leonie wieder abgelegt

**2025-10-01T10:05:51.630139** - Julia:
> halloween hab ich auf dem schirm und bin ich eh für heute dran, da noch mehr zu machen. gestern nicht geschafft

**2025-10-01T10:06:19.830459** - Julia:
> kannst mich gerne kurz anrufen, wenn du vorm meeting sprechen willst

**2025-10-01T10:18:23.643439** - Julia:
> soll ich dann in den BS Call überhaupt mit rein?

**2025-10-01T10:46:58.506199** - Julia:
> sprechen wir nach 11 noch kurz?

**2025-10-01T11:01:58.423529** - Julia:
> joooa

**2025-10-01T11:24:16.830129** - Julia:
> was hat charly denn überhaupt gesagt zu den updates

**2025-10-01T11:25:53.467729** - Julia:
> oh sorry, das war noch meine nachricht von vorhin, wurde nicht abgeschickt :smile:

**2025-10-01T11:44:39.702709** - Julia:
> hab meine auch da raus. 
Cool danke! Ja bei manchnen war ich unsicher, ob orange dann „so lala“ ist, weil es ja auch grün markierte gibt 

**2025-10-01T14:19:36.577769** - Julia:
> so witzig --&gt; das hatte ich Charly gesagt wegen Halloween :smile:

**2025-10-01T14:48:07.047349** - Julia:
> Hast du die Themen von Hanna gesehen? Puh, das ist viel

**2025-10-01T17:18:58.394259** - Julia:
> ich muss kurz zum tierarzt, schicke das GIF heute noch raus! Da werden sie ja eh Feedback haben

**2025-10-01T17:19:19.175419** - Julia:
> Bezüglich der Foto/Videografen --&gt; was ist unser Budget?

**2025-10-01T19:59:29.047609** - Julia:
> jaa alles okay. Musste nur für Ersin gehen, weil der doch nicht konnte  

**2025-10-01T20:26:04.130569** - Julia:
> ich sehs leider nicht. du müsstest mir das morgen kurz schicken. dankee :slightly_smiling_face:

**2025-10-02T08:46:19.383099** - Julia:
> GuMooo

**2025-10-02T08:48:41.579059** - Julia:
> kannst du mir einen screenshot schicken?

**2025-10-02T08:50:09.808389** - Julia:
> okay danke! Und die notizen von oben sind von dir?

**2025-10-02T08:50:48.057869** - Julia:
> Bzw. ist die Auflistung von oben jetzt für das family carousel oder für das partner carousel?

**2025-10-02T08:51:12.801549** - Julia:
> ah okay. also sollen die partner dann auch ins family?

**2025-10-02T08:59:30.934799** - Julia:
> --&gt; aber jetzt nochmal:

PLX - <https://www.picdrop.com/porsche-deutschland/rR5RsPjgdg?file=44196005256ec7a424933cd0c085adf3|01_Charly Only_Posts>
-Mobil 1 - <https://www.picdrop.com/porsche-deutschland/rR5RsPjgdg?file=e100f4dd9514a4123a971604570de1e9|01_Charly Only_Posts> ODER <https://www.picdrop.com/porsche-deutschland/rR5RsPjgdg?file=c57154b1d24d4c302876f8f86f6e815a|01_Charly Only_Posts>
-Leica - <https://www.picdrop.com/porsche-deutschland/7VunB6Avw5?file=e105233c9f87ca0ef7106fb1ca517f87|Leica_Rest> ODER <https://www.picdrop.com/porsche-deutschland/7VunB6Avw5?file=b2f322b48722be2310cfc431afce4eef|Leica_Rest>
-OMR - <https://www.picdrop.com/porsche-deutschland/m4Fx865H8x?file=48e4953e3d1de9733544bf25257cd8d2|00_Rest Bilder und Red Flags> ODER <https://www.picdrop.com/porsche-deutschland/m4Fx865H8x?file=ea20eaaf8205e6ff3d9e14152d3568d2|00_Rest Bilder und Red Flags> (OMR muss auch nicht zwingend)
-Automotorsport

Die Bilder sind auch ohne Personen: die sind doch dann fürs Partner Carousel? Das macht ja keinen Sinn das 2x zu zeigen

**2025-10-02T09:01:22.345239** - Julia:
> was hat sie denn bei der 2. slide geschrieben? sonst schick mir das gerne auch mal

**2025-10-02T09:01:53.751569** - Julia:
> okay danke

**2025-10-02T09:02:08.462369** - Julia:
> ja beide/3 schaffe ich jetzt nicht

**2025-10-02T09:04:17.697349** - Julia:
> Ne da wollte sie dann quasi reine Collab-Posts 2x

**2025-10-02T09:11:43.130189** - Julia:
> ist das die gleiche Person? hahaha

**2025-10-02T09:14:10.893179** - Julia:
> glaube ja

**2025-10-02T09:15:16.781039** - Julia:
> jaa

**2025-10-02T09:15:24.745999** - Julia:
> war mir nur unsicher, weil den hatte ich schon drin

**2025-10-02T09:15:26.637889** - Julia:
> danke :smile:

**2025-10-02T09:15:28.939019** - Julia:
> es ist noch zu früh

**2025-10-02T09:18:28.838639** - Julia:
> Ich hab kein Bild von Heizr --&gt; weißt du wer das ist?

**2025-10-02T09:19:29.776699** - Julia:
> ah ne stop, hab ich. ist der dude im beigen

**2025-10-02T09:20:11.966569** - Julia:
> der :slightly_smiling_face: habs gegoogelt

**2025-10-02T09:20:13.272189** - Julia:
> genau!

**2025-10-02T09:23:52.827649** - Julia:
> dankeee

**2025-10-02T09:23:54.886129** - Julia:
> sind alle drin

**2025-10-02T09:24:09.063469** - Julia:
> also solala, gibt nicht von allen bildern

**2025-10-02T09:32:09.552819** - Julia:
> Also wir sind damit jetzt bei 22 Bildern --&gt; es gehen im Carousel nur 20. Deshalb würde ich die roten rauslassen. Können es ihr ja aber gerne so zeigen und sie entscheidet dann.
Titelbild 1 oder 2 hat sie nix gesagt oder?
Magst du das so reinlegen in die Präsi? Sonst liegen alle einzelnen Bilder hier: <https://drive.google.com/drive/folders/1SDKZJ6GBvTHM4sPRqWM29IHnzdCaKxZD>

**2025-10-02T09:32:56.131969** - Julia:
> verstanden. ich hab da auch nichtmehr drüber geguckt.
Ja von meiner Seite auch 100% einfach gerade die zeitliche Komponente

**2025-10-02T09:33:01.105809** - Julia:
> gerne!

**2025-10-02T09:33:02.900449** - Julia:
> dankee

**2025-10-02T09:34:46.965729** - Julia:
> Falls du noch Notes dazuschreiben willst:
Axel &amp; Malmedie --&gt; raus, weil eh scho Reel und viel Content
Leica --&gt; kommt dann nochmal im Partner Post
Basti --&gt; schon 2,5 mal drin

**2025-10-02T09:35:11.555279** - Julia:
> Wie gesagt wir können nur 20 Bilder nehmen, dann müssen andere raus und dann fehlt immer irgendwer

**2025-10-02T09:35:56.517899** - Julia:
> also das hier oder eins von der Porsche Crew?

**2025-10-02T09:37:26.656379** - Julia:
> ah okay

**2025-10-02T09:37:42.119089** - Julia:
> hmm ja vllt eher in den partner post?

**2025-10-02T09:38:13.983739** - Julia:
> 

**2025-10-02T09:41:13.751189** - Julia:
> dann ist es so
Stephan Bogner raus
Basti &amp; Robert raus (kein schönes Bild)

**2025-10-02T09:41:43.741339** - Julia:
> okay

**2025-10-02T09:41:54.766209** - Julia:
> wie gesagt rot müsste noch raus (oder andere) sonst passt es nicht

**2025-10-02T09:42:11.292899** - Julia:
> dankee

**2025-10-02T09:44:10.240159** - Julia:
> Ne

**2025-10-02T09:44:34.165709** - Julia:
> dann haben wir 4 posts zu menschen/ partner

**2025-10-02T10:07:15.655719** - Julia:
> <https://www.figma.com/design/902cDjeQLIyg77xt49VdZg/Porsche-DE-%F0%9F%8F%8E%EF%B8%8F?node-id=0-1&amp;t=pzFNwcu432DhhC9W-1>

**2025-10-02T10:11:55.247729** - Julia:
> 

**2025-10-02T10:15:30.988869** - Julia:
> 

**2025-10-02T10:16:36.479829** - Julia:
> 

**2025-10-02T10:37:39.417869** - Julia:
> --&gt; soundaholic mit rein

**2025-10-02T11:47:04.046189** - Julia:
> Julia, ich sags wie es ist: ich hab gerade erstmal geheult. Boah ich finde diese Zusammenarbeit (in dem Fall jetzt Charly) soo krass. Ich weiß nicht, ob und wielange ich das mitmachen kann, mal ganz transparant

**2025-10-02T12:14:03.957959** - Julia:
> Danke :heart: Ja ich weiß, ist auch tagesbedingt. Es macht mich einfach nur sehr sauer, wenn die eigene Expertise nicht gesehen wird und man mit Leuten wirklich über Basics diskutiert wie Bildfarben, Bildauswahl, Anschnitte etc. Und heute hatte ich echt den krassen Eindruck, dass sie uns dumm darstellt. Finde das so unverschämt! Alter du bist ungefähr die krasseste Frau die ich kenne und sie meint dir sagen zu müssen, wie du deinen Job machen sollst?
AHHH

**2025-10-02T12:36:34.696839** - Julia:
> Vllt noch für UGC? schon sehr cute

**2025-10-02T12:37:12.311809** - Julia:
> Moody.. Halloween?

**2025-10-02T12:39:13.062009** - Julia:
> auch halloween

**2025-10-02T12:39:36.690749** - Julia:
> ich such gerade dua lipa, deshalb :smile:

**2025-10-02T12:47:32.949939** - Julia:
> von UGC?

**2025-10-02T12:47:42.516739** - Julia:
> bei der Seite Reels direkt in den Text

**2025-10-02T12:47:55.719799** - Julia:
> ahh das geht dann nicht? verstehe

**2025-10-02T14:44:14.023009** - Julia:
> Das GIF :relaxed::heart:

**2025-10-02T14:53:12.809659** - Julia:
> Wahrscheinlich echt so

**2025-10-02T14:53:42.580499** - Julia:
> Soll ich bezüglich der Prio die GIFs heute noch erstellen oder Targa Event?

**2025-10-02T16:01:13.500079** - Julia:
> es sind einfach super viele neue bilder in picdrop wow

**2025-10-02T16:07:38.236949** - Julia:
> 

**2025-10-02T16:24:29.488399** - Julia:
> gernee

**2025-10-02T16:39:03.214339** - Julia:
> haha voooll

**2025-10-02T16:40:54.256179** - Julia:
> hab dir in Asana die BS Stories + Feedpost abgelegt

**2025-10-02T16:43:42.789649** - Julia:
> Ich weiß nur bei einer Slide nicht, welche Version sie will. Hatte ihr ne Mail dazu geschickt

**2025-10-02T16:43:53.215089** - Julia:
> aber ihre kommentare in präsi waren: finaler input

**2025-10-02T16:57:51.963179** - Julia:
> ich lösche die story variante schnell raus

**2025-10-02T16:58:50.495849** - Julia:
> ne wir nehmen das mit der headline: Willkommen im BS

**2025-10-02T16:58:55.381609** - Julia:
> genau

**2025-10-02T17:00:13.173909** - Julia:
> hat sie kein finales feedback gegeben, also ja

**2025-10-02T17:01:26.281629** - Julia:
> on it

**2025-10-02T17:03:23.604049** - Julia:
> okay passt

**2025-10-02T17:03:31.802449** - Julia:
> TINS dann ja erst nächste woche

**2025-10-02T17:07:36.018759** - Julia:
> Community Carousel wäre hier: <https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1211508608563798?focus=true>

**2025-10-02T17:10:09.021979** - Julia:
> Ich muss jetzt mit Coco raus, ich bin immernoch im Schlafi hier. Ich versuche später noch das für den Targa zu machen, aber ich brauche echt kurz eine Pause

**2025-10-02T17:16:58.577339** - Julia:
> ja genau, also ich würde halt in das Carousel evtl. kurze Video Snippets einbauen (wenn der videograf) das kann. Sonst nur Stills und mischen mit Buch Inhalten/ Zitaten für Story + Feed

**2025-10-02T17:23:22.844239** - Julia:
> 

**2025-10-06T10:57:08.645139** - Julia:
> Huhuu, ich hab hier von Folie 23 - 27 mal das Targa Konzept eingefügt
<https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/doc2.aspx?sourcedoc=%7BE33428F9-BF0F-4720-B9FE-D8EDF165E52E%7D&amp;file=250924_Porsche_BS_SoMe_Konzepte_JH.pptx&amp;action=edit&amp;mobileredirect=true|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/doc2.aspx?sourcedoc=%7BE3342[…]_BS_SoMe_Konzepte_JH.pptx&amp;action=edit&amp;mobileredirect=true>

**2025-10-06T13:14:03.632529** - Julia:
> Also die Partner Carousels sind schon sehr trocken.

1. das wäre mein Vorschlag zum PLX Post --&gt; hier könnte man halt nicht nur den Random Kaffeebecher zeigen, sondern mehr, was bedeutet Porsche Lifestyle eigentlich. 
Sneaker hier zu zeigen find ich witzig wegen Sypder + Sypder Cowboy abe

**2025-10-06T13:16:25.186209** - Julia:
> 2. Leica --&gt; Hier ist die Idee das Carousel mit Fotos die aus den Winkeln entstanden sein könnten anzureichern

**2025-10-06T14:20:14.339979** - Julia:
> 

**2025-10-06T14:23:18.827579** - Julia:
> hmm okay

**2025-10-06T14:24:02.003569** - Julia:
> Wir können es ihm ja mal zeigen und dann auch schauen wie er reagiert – wenn er jetzt komplett überfordert ist, gehts natürlich nicht

**2025-10-06T14:25:34.920449** - Julia:
> ahh okay, auch cool!

**2025-10-06T15:01:11.719079** - Julia:
> kommst du auch in den call oder soll ich alleine?

**2025-10-06T15:39:11.298539** - Julia:
> JA

**2025-10-06T15:39:13.803119** - Julia:
> ganz süß

**2025-10-06T15:39:20.062709** - Julia:
> glaube der gibt sich ganz viel Mühe

**2025-10-06T15:42:54.084109** - Julia:
> jaa

**2025-10-06T16:20:56.252209** - Julia:
> Ich hab dir gerade eine Präsentation geteilt --&gt; hat das geklappt? :smile:

**2025-10-06T17:19:59.672589** - Julia:
> <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/EZ7TLT66epNKhkXArtJqiLUBlTp7hkTKor54-WuvJrIDVQ?e=KbXyXH>

**2025-10-06T17:43:21.553139** - Julia:
> habs angepasst

**2025-10-06T17:43:24.318529** - Julia:
> siehst dus?

**2025-10-06T17:43:34.084379** - Julia:
> <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/EZ7TLT66epNKhkXArtJqiLUBlTp7hkTKor54-WuvJrIDVQ?e=pwBSGe>

**2025-10-07T10:01:22.472079** - Julia:
> Hö? Das meeting ist aus meinem Kalender

**2025-10-07T10:01:40.044439** - Julia:
> achso sehe es jetzt

**2025-10-07T10:02:03.002879** - Julia:
> sie hat gerade eine mail geschickt, ob wir es um 17 Uhr machen können

**2025-10-07T10:02:57.251309** - Julia:
> Ja, dann mache ich mittags länger Pause, bin schon so lange am PC

**2025-10-07T10:31:02.668569** - Julia:
> ohja!

**2025-10-07T11:16:05.382219** - Julia:
> 

**2025-10-07T11:16:09.697259** - Julia:
> glaube das müssen wir fast ohne sie machen

**2025-10-07T11:32:52.619979** - Julia:
> Also Nicolas:

**2025-10-07T11:34:15.389009** - Julia:
> 

**2025-10-07T11:34:42.023869** - Julia:
> 

**2025-10-07T11:50:42.443219** - Julia:
> Okay, ich schreib ihm

**2025-10-07T11:50:59.980389** - Julia:
> Okay, sag Bescheid wenn ich ihm fix zusagen kann/ soll

**2025-10-07T14:00:09.833959** - Julia:
> Hast du diese Mail von Flo gelesen (Hanna Abwesenheit) :smile:

**2025-10-07T14:00:19.284659** - Julia:
> Da ist ja jemand super motiviert haha

**2025-10-07T14:53:29.172109** - Julia:
> also ich erstelle das foto briefing oder?

**2025-10-07T14:53:33.778299** - Julia:
> oder hat Flo was anderes gesagt?

**2025-10-07T15:08:46.126439** - Julia:
> okay

**2025-10-07T15:09:09.619469** - Julia:
> ich glaube auch!

**2025-10-07T15:11:49.764459** - Julia:
> oh nein

**2025-10-07T15:11:56.749039** - Julia:
> im "drive"? :smile:

**2025-10-07T15:12:06.993699** - Julia:
> moment

**2025-10-07T15:12:25.243269** - Julia:
> 

**2025-10-07T15:12:43.938579** - Julia:
> ich ziehs bei uns in Porsche_DE rein, oder?

**2025-10-07T15:13:14.845319** - Julia:
> Das war eben das was wir so krass fanden, weil eigentlich ist das nur "lokal" bei mir gespeichert aber mit dem Link teilen verschiebt es sich in die Cloud. Frage ist nur WO genau

**2025-10-07T15:13:39.916859** - Julia:
> okay

**2025-10-07T15:14:46.322509** - Julia:
> geht nicht, über 1 GB ich legs bei uns ab

**2025-10-07T15:15:58.584459** - Julia:
> :fast_parrot:

**2025-10-07T15:16:14.624499** - Julia:
> lädt hier noch: <https://drive.google.com/drive/folders/1kKuzWBX1yGRm7oQWHkEPXRkvLk9ohjyG>

dauert noch paar minuten :smile:

**2025-10-07T15:20:44.861129** - Julia:
> 3 min nooooch

**2025-10-07T15:21:02.362249** - Julia:
> wahrscheinlich wegen den videos

**2025-10-07T15:25:30.412879** - Julia:
> okay ist oben

**2025-10-07T16:55:23.162109** - Julia:
> soo

**2025-10-07T16:55:29.278059** - Julia:
> magst du dir mal das Briefing anschauen:

**2025-10-07T16:57:20.795449** - Julia:
> <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/EX-T1XPpRrhKpPQAQa7gEg0BKf88QnAE8gI_lzJwoWZucg?e=kd2dwd>

**2025-10-07T17:03:06.687849** - Julia:
> du bist auch noch nicht im meeting oder?

**2025-10-07T17:04:21.609599** - Julia:
> ah okay

**2025-10-07T17:12:50.544809** - Julia:
> Hast du Porsche Points von Mert bekommen zum Gipfeltreffen?

**2025-10-07T17:13:33.792169** - Julia:
> ah sehe gerade, hat er noch nicht gestartet laut asana

**2025-10-07T17:42:41.950639** - Julia:
> Also wenn ich dir das abnehmen kann, kann ich Nicolas das briefing auch schicken. Wenn dir noch was super wichtiges einfällt, ergänze ich natürlich noch

**2025-10-07T17:45:54.096939** - Julia:
> ahh cool!

**2025-10-07T17:46:10.162139** - Julia:
> Soll ich das noch abwarten oder rausschicken?

**2025-10-07T17:53:30.001989** - Julia:
> Wenn du mich beim meeting morgen um 9 brauchst, sag gerne bescheid. Ich komme ungern gern dazu :smile:

**2025-10-07T17:54:49.559329** - Julia:
> :zipper_mouth_face:

**2025-10-07T17:54:57.793959** - Julia:
> 9Uhr oder?

**2025-10-07T17:55:27.763929** - Julia:
> ich werde da sein :saluting_face:

**2025-10-07T17:56:14.168309** - Julia:
> yeees! Dir auch! Und ein RIESIGES Danke für die immer gute Energie und das auf-uns-Aufpassen! :heart_hands:

**2025-10-08T09:00:47.999159** - Julia:
> GuMo! Teams spinnt gerade wieder..

**2025-10-08T09:00:50.308879** - Julia:
> dauert noch kurz

**2025-10-08T11:08:00.994599** - Julia:
> Red dot ist doch schon in der Präsi :slightly_smiling_face:

**2025-10-08T11:21:27.267149** - Julia:
> Ich auch nicht, hatte ich grad im pdf entdeckt :slightly_smiling_face:

**2025-10-08T11:22:32.748779** - Julia:
> Ja gerne --&gt; aber wegen den Videos wirds dann so groß :smiling_face_with_tear:

**2025-10-08T11:23:13.498109** - Julia:
> Also ich kann die Posts mit Dua usw. auch erstmal in der bestehenden TINS Präsi von "mir" bearbeiten und dir dann wieder die geupdateten Folien schicken?

**2025-10-08T11:23:31.824029** - Julia:
> cool danke!

**2025-10-08T11:24:13.719429** - Julia:
> wegen dem Dua Herbst Post --&gt; da gibts das Material ja leider nicht in der Datenbank. Ich kann das gerne anfragen, nur wo?

**2025-10-08T11:28:09.314129** - Julia:
> <https://www.instagram.com/p/DMmvTh6s0T3/?img_index=1>

**2025-10-08T11:30:03.395769** - Julia:
> ja hätte eigentlich schon mit videos geplant, wenn wir an den content kommen. das von mir waren eben nur screenshots weils nur aus IG gezogen ist

**2025-10-08T11:30:32.310389** - Julia:
> mega :heart_eyes:

**2025-10-08T11:31:11.777879** - Julia:
> hatten eben nur etwas die reihenfolge geändert und ein paar fotos rausgenommen

**2025-10-08T11:35:09.930899** - Julia:
> für wann wäre das eingeplant? dann erstell ich schnell den ordner

**2025-10-08T11:36:08.714509** - Julia:
> <https://drive.google.com/drive/folders/1bawyVNCvbVCQttJnBaSOS_IlHeE4EQk9?usp=drive_link>

**2025-10-08T13:44:13.018799** - Julia:
> PAG Teaser von Dua Lipa Post:
<https://www.instagram.com/p/C9sGMMWtpcZ/?img_index=1>

Originalpost bei PAG von Dua:
<https://www.instagram.com/p/C9xPmThsmxl/>


BTS bei PAG von Dua:
<https://www.instagram.com/p/C-F3grutWI4/?img_index=1>

mehr gibts garnicht --&gt; also wäre unseres garnicht so gesehen. ich passe es trotzdem an so gut es geht

**2025-10-08T14:38:29.148609** - Julia:
> Update Dua Lipa Slides Halloween:
<https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/EZhFNWYjtcNHs2uK9STo3ykBzWp2qycKxZGBNlpn8z13xw?e=hmgM7S>

**2025-10-08T14:39:05.150099** - Julia:
> Uhh nice, okay. Schau ich mir jetzt direkt an – dauert bisschen, muss noch die ganzen finalen Fotos einsetzen :slightly_smiling_face:

**2025-10-08T14:47:39.902399** - Julia:
> ich glaub das sind diese Malmedie Videos

**2025-10-08T14:48:32.410379** - Julia:
> :face_exhaling:

**2025-10-08T14:48:38.146449** - Julia:
> ich hab keine ahnung.. so doof

**2025-10-08T14:55:04.162849** - Julia:
> ich dreh durch. hast du hierauf zugriff?
<https://porsche.sharepoint.com/sites/PDMK/_layouts/15/AccessDenied.aspx?Source=https%3A%2F%2Fporsche%2Esharepoint%2Ecom%2F%3Ap%3A%2Fr%2Fsites%2FPDMK%2FShared%20Documents%2FGeneral%2FUMZUG%2FDigitales%20Marketing%2FSocial%2FInsta%2F08%5FRedaktionsplanung%2FContents%2F2025%2F09%5FSeptember%2FChristo%5FLeonie%20Beck%2F250930%5FCHRISTO%20X%20LEONIE%20BECK%5FSM%20ASSETS%5FJH%2Epptx%3Fd%3Dw7bdded1f44e94b6cb2287b372dcee960%26csf%3D1%26web%3D1%26e%3DfEA8cj&amp;correlation=0561cda1%2Df0c2%2De000%2D0c5a%2D2e788cb55751&amp;Type=item&amp;name=0cd39bae%2D6d68%2D48b4%2Dac8e%2Dbb7c2e24de30&amp;listItemId=234961&amp;listItemUniqueId=7bdded1f%2D44e9%2D4b6c%2Db228%2D7b372dcee960|https://porsche.sharepoint.com/sites/PDMK/_layouts/15/AccessDenied.aspx?Source=https%3A%[…]ItemUniqueId=7bdded1f%2D44e9%2D4b6c%2Db228%2D7b372dcee960>

**2025-10-08T14:55:31.488229** - Julia:
> 

**2025-10-08T15:15:26.197479** - Julia:
> :face_exhaling: ich versteh das einfach nicht

**2025-10-08T15:16:22.971659** - Julia:
> super danke!

**2025-10-08T15:16:58.386139** - Julia:
> Noch eine Sache – siehst du auch gleich, die eingesetzen Bilder sind ja die finalen von Lattke und haben die Bearbeitung von deren Lithografen drauf – ich finds pesönlich ganz furchtbar aber...

**2025-10-08T15:35:58.977399** - Julia:
> There you go: <https://app.asana.com/1/1199360402832734/project/1210522556460237/task/1211585708869497?focus=true>


Basti hab ich wegen dem Reel geschrieben

**2025-10-08T16:35:36.228759** - Julia:
> Meinten sie da nicht nur das TN? Weil sie hatten halt geschrieben "TN im Carousel"
Dachte sie reden da vom reel

**2025-10-08T16:38:45.491299** - Julia:
> Also ich hatte das Reel TN jetzt angepasst. Da hatten wir eigentlich das hier:

**2025-10-08T16:39:41.763439** - Julia:
> du meinst, wo sie hinterm steuer sitzt?

**2025-10-08T16:40:00.929179** - Julia:
> ja ist okay

**2025-10-08T16:40:40.885619** - Julia:
> 

**2025-10-08T16:41:55.918539** - Julia:
> FYI: Basti ist heute auf Dreh. evtl morgen wieder da?

**2025-10-08T16:43:26.785499** - Julia:
> oke

**2025-10-08T16:43:32.714779** - Julia:
> okay

**2025-10-08T16:43:53.772879** - Julia:
> dann leg ich dir das "alte" Reel TN nochmal ab, oder?

**2025-10-08T16:46:58.721439** - Julia:
> <https://drive.google.com/drive/folders/1smTGTryRlgR28HeZKZbRUWAPBn3EvR-R>

sorry für die Verwirrung

**2025-10-09T08:44:27.841959** - Julia:
> GuMo! ich hab noch 2 Trends gefunden. Euer Termin ist mittags ge? Bereite ich dir bis dahin auf, dann kannst du es einfügen :slightly_smiling_face:

**2025-10-09T09:21:02.980829** - Julia:
> Jaaa stimmt! Das hatten wir mal gesehen. Voll :smiling_face_with_3_hearts:

**2025-10-09T10:00:00.266299** - Julia:
> ne..

**2025-10-09T10:00:28.216819** - Julia:
> ja halt uncool

**2025-10-09T11:23:29.002409** - Julia:
> okay, passt ja

**2025-10-09T11:23:38.663259** - Julia:
> dann ich ihm gleich alles

**2025-10-09T11:41:19.910569** - Julia:
> ja. im briefing bei fokus

**2025-10-09T11:47:36.556109** - Julia:
> 

**2025-10-09T11:51:46.641389** - Julia:
> caption für playmobil hab ich angepasst

**2025-10-09T13:08:40.765969** - Julia:
> soll ich noch rein?

**2025-10-09T13:08:48.094859** - Julia:
> was ist das für ein termin? :slightly_smiling_face:

**2025-10-09T13:11:51.380489** - Julia:
> okay. hab eigentlich solche termine nicht im kalender, aber passt ja

**2025-10-09T13:35:31.362979** - Julia:
> unten ist halloween, das nicht zeigen

**2025-10-09T13:35:32.763419** - Julia:
> <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/ERREl-jY--RClqmGmwnOPWoBGZc7HXKQ63EHw9JKuy1MSg?e=f50V64&amp;nav=eyJzSWQiOjMwMSwiY0lkIjoyNTg2MTU0NDN9|https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/ERRE[…]MSg?e=f50V64&amp;nav=eyJzSWQiOjMwMSwiY0lkIjoyNTg2MTU0NDN9>

**2025-10-09T15:26:37.848039** - Julia:
> ich bin sooo auf die fotos/ videos gespannt

**2025-10-09T15:26:41.641359** - Julia:
> :face_with_peeking_eye:

**2025-10-09T15:26:43.974239** - Julia:
> vom event

**2025-10-09T15:26:59.743059** - Julia:
> :face_with_spiral_eyes:

**2025-10-09T16:21:15.127499** - Julia:
> schau ich mir an!

**2025-10-10T09:28:38.849549** - Julia:
> Hello! :slightly_smiling_face:

**2025-10-10T09:28:45.322209** - Julia:
> Cool danke

**2025-10-10T09:28:52.629099** - Julia:
> Muss ich das nochmal freigeben lassen oder einfach machen?

**2025-10-10T09:30:02.226829** - Julia:
> Okay mach ich

**2025-10-10T09:30:59.071939** - Julia:
> Also Event Content.. Bilder okay. Videos weiß ich noch nicht. Aber Reel Katastrophe --&gt; vllt wollte Hanna das so und die Statements/ Zitate der Speaker haben scheinbar alle nicht geklappt

**2025-10-10T09:33:05.737849** - Julia:
> Ne einfach die Idee nicht verstanden. Also es ist einfach nur ein Bildausschnitt der genau gleich bleibt und dann groß wird :smile:

**2025-10-10T09:34:34.579579** - Julia:
> ich schau gerade noch durch

**2025-10-13T09:32:29.018019** - Julia:
> Guten Morgen! :heart_hands:

**2025-10-13T09:35:50.507259** - Julia:
> ich würde den 10 Uhr Termin mit Porsche skippen, wenn das für dich auch passt? Ich denke Charly muss sich eh erstmal noch alles angucken

**2025-10-13T10:49:56.010739** - Julia:
> Ach Mist, das hatte ich nicht auf dem schirm

**2025-10-13T10:57:37.530599** - Julia:
> sorryyy

**2025-10-13T10:57:45.585159** - Julia:
> ich steh bissl neben mir :face_with_spiral_eyes:

**2025-10-13T16:38:49.889719** - Julia:
> Also mit Nicolas und der Rechnung bin ich mal gespannt :smile: da hat ja wirklich garnichts geklappt

**2025-10-14T09:50:08.300919** - Julia:
> dankeeee

**2025-10-14T09:56:56.337769** - Julia:
> ich komme nicht bei teams rein

**2025-10-14T09:56:58.449149** - Julia:
> es ist so zum kotzen

**2025-10-14T09:59:24.896269** - Julia:
> glaube jetzt geht es

**2025-10-14T10:02:04.193299** - Julia:
> bin im warteraum :slightly_smiling_face:

**2025-10-14T10:37:00.737779** - Julia:
> das bild von dem hund ist halt nicht cool :smile:

**2025-10-14T11:03:34.470349** - Julia:
> 

**2025-10-14T11:14:35.992359** - Julia:
> SYLT CONTENT MIT HUUUUUND!!!

**2025-10-14T14:49:06.916079** - Julia:
> hab noch einen gefunden :smile:

**2025-10-14T14:58:48.359269** - Julia:
> genau. Also Story Slides + Bildauswahl für das Image Carousel --&gt; yes (aber wie gesagt, wenn da eh noch Content kommt..?)
Carousel Reihenfolge hab ich jetzt nicht gesehen

**2025-10-14T14:59:42.932249** - Julia:
> deswegen dachte ich, dass man sagt: hey visuelle sachen kommen sobald wir die ganzen Fotos haben, aber hier sind schon mal unsere Anmerkungen + Caption Überarbeitungen

**2025-10-14T14:59:52.032329** - Julia:
> Soll ich das sonst einfach in eine Präsi packen?

**2025-10-14T15:03:11.131809** - Julia:
> Ah okay verstehe

**2025-10-14T15:03:16.958409** - Julia:
> danke!

**2025-10-14T15:03:18.604059** - Julia:
> mach ich dann

**2025-10-14T16:57:56.951299** - Julia:
> sie antwortet nicht :weary:

**2025-10-14T16:58:06.060689** - Julia:
> ich exportier aber tatsächlich gerade alles

**2025-10-14T17:04:10.419529** - Julia:
> <https://drive.google.com/drive/folders/1h54uGA71DwQjwOnnNk0bvayxR03DqEn5?usp=drive_link>

**2025-10-14T17:12:00.835549** - Julia:
> gerne

**2025-10-14T17:12:09.304109** - Julia:
> genau und teil 2 mit den varianten halt

**2025-10-14T17:20:42.355019** - Julia:
> das 3.

**2025-10-14T17:20:47.391959** - Julia:
> du?

**2025-10-14T17:20:55.776429** - Julia:
> juhuu

**2025-10-14T17:23:45.654349** - Julia:
> genau. also ich bin heute nichtmehr so lange da, bin von 18Uhr bis 19.30 unterwegs :smiling_face_with_tear: hoffe sie antwortet bald

**2025-10-14T17:26:36.026849** - Julia:
> sonst könnte man story direkt morgens machen

**2025-10-14T17:43:21.116319** - Julia:
> ja aber es gibt nix

**2025-10-14T17:44:27.943649** - Julia:
> es macht mich echt sauer

**2025-10-14T17:44:34.223559** - Julia:
> das liegt da seit tagen

**2025-10-14T17:44:36.791769** - Julia:
> seit freitag ab

**2025-10-14T17:45:03.068679** - Julia:
> ja

**2025-10-14T17:45:11.645109** - Julia:
> ich hab noch eins gefunden, das ist von der belichtung besser

**2025-10-14T17:45:36.655029** - Julia:
> grant finde ich kein anderes keine ahnung

**2025-10-14T17:46:02.628079** - Julia:
> obwohl auch nicht besser

**2025-10-14T17:47:09.042099** - Julia:
> 

**2025-10-14T17:47:25.254609** - Julia:
> unten ist neu

**2025-10-14T17:49:40.687879** - Julia:
> 

**2025-10-14T17:50:01.504439** - Julia:
> 

**2025-10-14T17:51:18.239089** - Julia:
> ich schicke dir das jetzt einfach mal

**2025-10-14T17:51:20.539209** - Julia:
> 

**2025-10-14T17:51:49.957419** - Julia:
> juhuuuu

**2025-10-14T17:52:25.293789** - Julia:
> hatte alles angepasst

**2025-10-14T17:52:52.333059** - Julia:
> 

**2025-10-14T17:54:32.105489** - Julia:
> genau

**2025-10-14T17:54:39.301159** - Julia:
> oder lieber

**2025-10-14T17:54:41.717759** - Julia:
> Wahr / Falsch

**2025-10-14T17:54:47.782459** - Julia:
> Lüge ist bisschen hart :smile:

**2025-10-14T17:55:09.960349** - Julia:
> ahhh sowas macht mich wahnsinnig

**2025-10-14T17:55:30.360929** - Julia:
> ja klar mach ich

**2025-10-14T17:56:32.759139** - Julia:
> bin dran und gucke

**2025-10-14T17:57:20.180559** - Julia:
> moment

**2025-10-14T17:57:32.740659** - Julia:
> also ich hatte die sticker eigentlich immer bei der frage direkt platziert

**2025-10-14T17:57:54.666329** - Julia:
> weißt du wie ich meine?

**2025-10-14T17:58:25.485899** - Julia:
> ja fand ich jetzt in dem fall nicht schlimm aber mach gerne wie du meinst

**2025-10-14T17:58:59.461309** - Julia:
> jaa ich weiß schon, hab ich auch gesehen leider

**2025-10-14T17:59:00.281879** - Julia:
> okay

**2025-10-14T18:01:10.587109** - Julia:
> läuft

**2025-10-14T18:03:03.567839** - Julia:
> Ich bin schon mit dem Handy drin. Dann das buch als Titelbild?

**2025-10-14T18:03:08.480109** - Julia:
> Das Bild ist scharf

**2025-10-14T18:03:22.304109** - Julia:
> Eigentlich das von Außen, weiß nicht was sie hier hat

**2025-10-14T18:03:27.361809** - Julia:
> Sonst kann ich es morgen früh machen

**2025-10-14T18:03:47.764779** - Julia:
> Oder später. Ich kann nicht jeden Termin wegen der ihren Feedbackprozessen verschieben

**2025-10-14T18:03:55.494469** - Julia:
> Finde Buch als Bild auch gut

**2025-10-14T18:05:10.467179** - Julia:
> Also Vorschlag 1: Buch als Titelbild nehmen
oder Vorschlag 2: morgen früh posten und wir schauen nochmal. Dann läuft das Quiz jetzt erstmal so – auch gut!

**2025-10-14T18:26:49.706769** - Julia:
> oke. Danke und ahhh

**2025-10-14T18:26:52.320809** - Julia:
> :heart_hands:

**2025-10-15T09:43:18.153549** - Julia:
> hello! legs jetzt auch nochmal in die Präsi rein. Es gibt sonst kein anderes Bild – das ist die Lichtstimmung, die streut natürlich Licht und macht diesen leichten "grisligen Effekt". Habs hier raus bekommen

**2025-10-15T09:43:39.243419** - Julia:
> Aber unscharf sind die Bilder nicht, ich würde wohl kein unscharfes Bild hochladen als studierte Grafikdesignerin

**2025-10-15T09:47:37.786529** - Julia:
> liegt ab slide 21 + 22

**2025-10-15T10:46:02.666209** - Julia:
> sehr gerne – danke fürs klären :heart:

**2025-10-15T11:12:04.606169** - Julia:
> juhuuu. hast dus schon in sprinklr rein? sonst kann ich

**2025-10-15T11:55:43.406419** - Julia:
> dankeee

**2025-10-15T11:55:57.814379** - Julia:
> war sonst alles oke in den Meetings?

**2025-10-15T12:08:24.259409** - Julia:
> ja versteh ich..

**2025-10-15T12:08:48.501679** - Julia:
> ich hab übrigens schon die präsi für Racing erstellt – ich muss jetzt noch die Stories machen

**2025-10-15T12:08:55.297939** - Julia:
> also bis 13 Uhr schaff ich das eh

**2025-10-15T12:11:02.240789** - Julia:
> so geil auch, die bilder sind alle so schlecht :smile:

**2025-10-15T12:51:40.566819** - Julia:
> so there you go:

**2025-10-15T12:54:14.515579** - Julia:
> <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/EVaeQqoPythFgsfrqdTs6w0BKdQL9bmpEdFaxE30pVeZHA?e=tgnwjl>

**2025-10-15T12:54:44.633559** - Julia:
> • captions angepasst
• Carousel Bildauswahl /ergänzt sich dann mit Story Slides
• 2x Varianten der Stories


**2025-10-15T15:35:02.243269** - Julia:
> Hab grad mit Flo gesprochen, er ist einfach ne Maus. Glaub dem war einfach nicht bewusst, dass wir auf Updates warten. Würde ja gerne sagen TYPISCH MANN...

**2025-10-15T15:35:45.313169** - Julia:
> ahh perfekt

**2025-10-15T15:36:04.605869** - Julia:
> schick dir eine Sprachi

**2025-10-15T16:28:00.651179** - Julia:
> dankeee

**2025-10-15T16:29:15.414269** - Julia:
> lieb ich ja, wenn das Feedback ist: einfach nur Sätze umdrehen

**2025-10-15T16:38:07.239719** - Julia:
> übrigens hat das mit dem Huddle Termin nicht geklappt – bin nicht drin :sleepy:

**2025-10-15T16:40:43.742699** - Julia:
> jaa vllt muss ich nochmal komplett raus gelöscht werden?

**2025-10-15T16:40:44.499719** - Julia:
> dankee

**2025-10-15T17:16:51.534499** - Julia:
> das ist doch so komisch

**2025-10-15T17:17:24.646789** - Julia:
> ne ich hab ihn nichtmehr drin :disappointed:

**2025-10-15T17:18:02.300719** - Julia:
> egal, ich leg mir den selbst rein als reminder

**2025-10-15T17:18:06.899649** - Julia:
> aber danke fürs probieren :slightly_smiling_face:

**2025-10-16T09:46:19.426729** - Julia:
> hello!

**2025-10-16T09:46:20.608069** - Julia:
> <https://drive.google.com/drive/folders/1H67fGzGr11_PAO3OczjRrRNUnjBXOAuR>

**2025-10-16T09:46:23.255269** - Julia:
> gerne hier, dankeee

**2025-10-16T09:55:58.663759** - Julia:
> Echt? Hä wie komisch 

**2025-10-16T09:56:14.425299** - Julia:
> Also ich hab keine Mail bekommen. Aber wollte ihn eh heute Feedback geben :melting_face:

**2025-10-16T10:01:52.683069** - Julia:
> okay dankeee.

**2025-10-16T10:03:31.394649** - Julia:
> finds einfach strange, dass er dir dann in whatsapp schreibt. ich hatte ja mit ihm kontakt

**2025-10-16T10:49:19.101719** - Julia:
> ah ja

**2025-10-16T10:49:39.640649** - Julia:
> dann antworte ich Nicolas jetzt? Würde schon ehrlich sein aber natürlich trotzdem nett

**2025-10-16T11:30:50.994089** - Julia:
> dankeee

**2025-10-16T15:09:33.586629** - Julia:
> gerneee

**2025-10-16T15:09:44.554069** - Julia:
> bin beim letzten :slightly_smiling_face: du kannst aber gerne durchschauen was du meinst

**2025-10-16T15:09:54.672159** - Julia:
> bezüglich Youtube hab ich vergessen was sie gesagt haben, ups

**2025-10-16T15:11:14.385099** - Julia:
> doch habs nur angepasst

**2025-10-16T15:11:30.196389** - Julia:
> Das Video ist halt auf englisch

**2025-10-16T15:11:55.080429** - Julia:
> hab das hier überlegt

**2025-10-16T15:13:39.709809** - Julia:
> ja ich finds auch cool. ich hatte nur im kopf (mit Dua zB) das Charly, dass halt garnicht mag mit englischen Videos auf dem Kanal

**2025-10-16T15:14:36.706059** - Julia:
> okay dann nehm ich es wieder mit rein

**2025-10-16T15:17:09.665879** - Julia:
> habs drin und wieder in den plan oben mit rein

**2025-10-16T15:24:25.699469** - Julia:
> Ne hör auf

**2025-10-16T15:24:44.157289** - Julia:
> das ist echt mit den Videos glaub ich

**2025-10-16T15:25:07.749019** - Julia:
> Was kann ich tun?

**2025-10-16T15:27:26.311259** - Julia:
> oh manno

**2025-10-16T15:27:27.456739** - Julia:
> ja klar

**2025-10-16T15:31:00.587429** - Julia:
> okay lädt hoch. wird dauern

**2025-10-16T15:33:28.491419** - Julia:
> 

**2025-10-16T15:38:45.765709** - Julia:
> juhuuuu

**2025-10-16T15:38:51.448979** - Julia:
> bin grad an den racing sachen dran

**2025-10-16T16:20:30.486009** - Julia:
> für Charly – ihre "Vorschläge" liegen noch mit drin

**2025-10-16T16:35:28.254359** - Julia:
> habs ihr geschickt

**2025-10-20T09:34:25.615109** - Julia:
> GuMoo

**2025-10-20T09:36:21.672849** - Julia:
> Puh VBWs am Freitag waren nochmal ein Highlight – Hanna hatte mir privat dann noch paar mal geschrieben wegen den Story Slides "sie hätte die ja garnicht gesehen in Sprinklr" etc.
Müssen wir aber händisch posten wegen Stickern. Dann hatte sie mich so verwirrt und ich bin am Samstag aufgewacht und war so: ne irgendwas passt nicht. Die Story ist erst heute bei der PAG, also für uns ja dann auch. Dann hab ich ihr das kurz geschrieben am Samstag, hat sie nicht verstanden :joy: Irgendwann dann doch und jetzt geht es normal wie geplant heute online

**2025-10-20T09:36:56.413679** - Julia:
> da hab ich richtig gemerkt, wieviel Druck da ist

**2025-10-20T09:58:08.598709** - Julia:
> ne alles gut, es war ja nur super nervig weil sie es nicht verstanden hat oder was auch immer

**2025-10-20T10:01:56.331059** - Julia:
> bin im warteraum

**2025-10-20T10:03:41.358079** - Julia:
> okay

**2025-10-20T10:04:01.031679** - Julia:
> ja also die ganzen SOS Postings können wir heute auf Sprinklr packen

**2025-10-20T10:04:54.307089** - Julia:
> Hanna hatte am freitag eben noch in die SOS Präsi (von Charly) kommentiert und wir haben angepasst – bei einem Posting hat sie geschrieben "Neue Caption" -&gt; Müssen sich die 2 jetzt drum streiten

**2025-10-20T10:05:49.849339** - Julia:
> aber weißt du, ob das meeting jetzt stattfindet?

**2025-10-20T10:06:20.835259** - Julia:
> Pauschal einfach immer zu spät kommen, ist auch eine Leistung

**2025-10-20T10:59:41.800489** - Julia:
> ja :smile:

**2025-10-20T11:39:34.985249** - Julia:
> 

**2025-10-20T11:45:04.328109** - Julia:
> sag ich ihm

**2025-10-20T11:49:34.811469** - Julia:
> liegt ab

**2025-10-20T12:38:44.469769** - Julia:
> Mert findet leider die neueste PP Präsi nicht, da ich dir eigentlich die Reihenfolge gerne nochmal schicken wollte (bin mir nichtmehr sicher, ob es analog Figma ist), aber dann leider nur so:

**2025-10-20T12:39:09.250819** - Julia:
> 

**2025-10-20T12:39:22.322409** - Julia:
> die 2 passen nicht

**2025-10-20T13:27:19.914409** - Julia:
> okay. ich würde jetzt in die pause – würdest du dann die story + repost reel posten? :slightly_smiling_face:

**2025-10-20T14:58:35.146439** - Julia:
> ich finde halt das 2. passt garnicht aber glaube Charly wollte das ja oder?

**2025-10-20T15:01:03.998909** - Julia:
> jaa find ich besser!

**2025-10-20T15:09:43.848329** - Julia:
> Also

**2025-10-20T15:09:54.480989** - Julia:
> Das hab ich dir damals geschickt und du an Charly:

**2025-10-20T15:10:12.599889** - Julia:
> 

**2025-10-20T15:12:34.165699** - Julia:
> also die texte die jetzt in dieser Präsi liegen: <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7B387B2853-0A04-42DC-8E07-D1D802AA1A6E%7D&amp;file=251016_Porsche_DE_Copenhagen_BCC-Intern.pptx&amp;nav=eyJzSWQiOjIxNDc0ODM1MzUsImNJZCI6MjEzMzQ5ODMwMX0&amp;action=edit&amp;mobileredirect=true|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7B387B28[…]UsImNJZCI6MjEzMzQ5ODMwMX0&amp;action=edit&amp;mobileredirect=true>
hab ich jetzt eingefügt

**2025-10-20T15:12:40.974319** - Julia:
> davor waren diese wieder englisch..?

**2025-10-20T15:12:56.721219** - Julia:
> Ich füge jetzt nochmal die alte Folie von oben rein, dann kann sie die texte aussuchen

**2025-10-20T15:13:02.858589** - Julia:
> das ist ganz komisch

**2025-10-20T15:13:22.601219** - Julia:
> kurz huddle? :smile:

**2025-10-20T15:38:52.280439** - Julia:
> falls Asana bei dir noch nicht geht: <https://drive.google.com/drive/folders/12XyomhvZuG-Vlnz60qlUF3DhD5Y6lULy>

**2025-10-20T15:43:00.411279** - Julia:
> hab 2 versionen der letzten Slide gemacht. Weil sich Porsche sonst doppelt

**2025-10-20T15:43:08.020079** - Julia:
> Aber wahrscheinlich will sie es so :new_moon_with_face:

**2025-10-20T16:26:16.047559** - Julia:
> spannend

**2025-10-21T10:00:26.532009** - Julia:
> there you go:

**2025-10-21T10:00:52.185229** - Julia:
> 

**2025-10-21T10:05:37.337079** - Julia:
> dankee :slightly_smiling_face: bis gleich!

**2025-10-21T10:52:51.518039** - Julia:
> oh okay, hier nochmal:

**2025-10-21T10:53:07.129499** - Julia:
> alles klar, passe ich an

**2025-10-21T10:53:07.204199** - Julia:
> 

**2025-10-21T11:36:43.974769** - Julia:
> die rechnungsadresse ist die mandlstr. oder?

**2025-10-21T11:36:53.068469** - Julia:
> für Nicolas

**2025-10-21T13:33:02.902669** - Julia:
> ich hab jetzt Figma angefangen aufzuräumen, können die Links dann easy in die Übergabe mit aufnehmen :slightly_smiling_face:

**2025-10-21T13:34:19.697579** - Julia:
> Ich schreib Flo noch aber sonst hatte ich mal überlegt, ob ich dann wegen nächster Woche oder der ersten November Woche wegen Urlaub frage – nur schon mal FYI

**2025-10-21T13:34:40.525279** - Julia:
> je nachdem wieviel jetzt noch ansteht

**2025-10-21T13:48:55.219829** - Julia:
> okay :slightly_smiling_face:

**2025-10-21T13:49:24.347639** - Julia:
> yes, ich frag ihn mal. Mir wäre auch egal wann - Hauptsache Ruhe :joy:

**2025-10-21T14:02:59.468759** - Julia:
> macht voll Sinn. Weißt du wann die ist?

**2025-10-21T14:07:55.129339** - Julia:
> okee

**2025-10-22T10:01:08.123769** - Julia:
> Genau, das hab ich dir in Asana reingelegt

**2025-10-22T10:01:22.471599** - Julia:
> Das ist ja nur das eine Bild das wir nutzen von diesem Post

**2025-10-22T10:01:36.450869** - Julia:
> bei den anderen nicht. Das eine ist vom Gipfeltreffen, das andere ist von der Datenbank

**2025-10-22T10:02:41.833279** - Julia:
> <https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1211381756541688?focus=true>

**2025-10-22T10:02:43.611799** - Julia:
> Okay

**2025-10-22T10:02:49.276359** - Julia:
> ja wie gesagt die anderen sind keine UGCs

**2025-10-22T11:54:44.708809** - Julia:
> ah okay. nichts so cooles, hatte alles dir haucht. Und muss sagen, das war sehr aufwendig mit den Augen 

**2025-10-22T13:17:05.647319** - Julia:
> Ich auch. Aber warum denn eigentlich?

Ich kann’s gerne probieren, wird mit der Perspektive aber nicht so leicht 

**2025-10-22T13:29:10.330779** - Julia:
> Ich probier beides einfach aus 

**2025-10-22T13:29:15.254629** - Julia:
> verständlich 

**2025-10-22T14:10:55.652479** - Julia:
> jooooa

**2025-10-22T14:17:01.329449** - Julia:
> hab dir die 2 hier reingelegt: <https://drive.google.com/drive/folders/1l6DgO7T8_SZmXVacAs0sL9n2QbZA9fsf>

**2025-10-22T14:28:13.931989** - Julia:
> ging meine Nachricht in Teams durch? Das spinnt schon wieder

**2025-10-22T14:43:16.746279** - Julia:
> super danke

**2025-10-22T16:03:12.904079** - Julia:
> oh ne, schau ich mir an 

**2025-10-22T16:27:04.862499** - Julia:
> ich crop grad alles. ich dachte tatsächlich bei den Videos kann man das auch in Sprinklr dann direkt machen

**2025-10-22T16:28:04.252389** - Julia:
> soweit war die AI dann nicht mit auch noch zuschneiden :smile:

**2025-10-22T16:46:56.773219** - Julia:
> lädt alles gerade rein. Beim Fledermaus Video reicht das TN ja aus dem Video oder?

**2025-10-22T17:02:50.314159** - Julia:
> ja also es wird bei IG als "Reel" behandelt

**2025-10-22T17:03:22.971179** - Julia:
> heißt es wird zwar in 1080x1350 gepostet und bleibt auch in dem Format aber wird in der Kategorie Reel angezeigt

**2025-10-22T17:03:26.327149** - Julia:
> super umständlich

**2025-10-22T17:03:41.024869** - Julia:
> hatte ich chatgpt damals auch nochmal gefragt

**2025-10-22T17:04:01.487109** - Julia:
> genau

**2025-10-22T17:04:11.039639** - Julia:
> eigentlich darf mit dem format nix passieren

**2025-10-22T17:04:57.380019** - Julia:
> 

**2025-10-22T17:06:34.964809** - Julia:
> ne das nicht. also ich kann sie auch in 9x16 anlegen – ich persönlich finde so kurze videos in dem format nicht gut

**2025-10-22T17:06:57.576369** - Julia:
> Also dann lieber in 9x16 oder was meinst du?

**2025-10-22T17:07:13.593969** - Julia:
> genau, das ist dieser reel tab

**2025-10-22T17:08:25.422119** - Julia:
> wir haben doch so einen BCC Fake account – da hatten wir das Gipfeltreffen Grid hoch geladen. Hast du den Zugriff?

**2025-10-22T17:08:46.437929** - Julia:
> Ich leg sie jetzt nochmal in 9x16 ab, dann haben wir es. ist ja egal

**2025-10-22T17:10:35.195829** - Julia:
> dann lieber so, bevor es ihnen dann so nicht gefällt

**2025-10-22T17:15:16.410699** - Julia:
> oke liegt wieder ab

**2025-10-22T17:15:27.209089** - Julia:
> es wird bei 9x16 halt immer so gequetscht

**2025-10-23T09:58:55.639619** - Julia:
> nee find ich cool :slightly_smiling_face: danke

**2025-10-23T10:28:09.581619** - Julia:
> • Gespenster jagen – bei XY km/h.
• Night drive, ghost mode on.
• Der Asphalt gehört Porsche.
• Schneller als jeder Schatten.
• Nachtschwärmer.
• Schattenflug auf Asphalt.
• Wenn der Asphaltjäger erwacht..

**2025-10-23T11:38:52.668349** - Julia:
> weils mir gerade aufgefallen ist: wir haben für den Rundgang 1x das Werkscafé und 1x die Poster Wall gemacht – nicht die Fitting Lounge :slightly_smiling_face:

**2025-10-27T10:38:29.420019** - Julia:
> Also von Hanna kam bisher echt keine Nachricht mehr

**2025-10-27T10:51:38.130809** - Julia:
> ne, hab angefordert

**2025-10-27T10:55:40.434989** - Julia:
> ah ich hatte nur die 3: <https://drive.google.com/drive/folders/1UAtEfDEuxK-DoqSDqF_LRzSALd_BTfpv>

**2025-10-27T10:56:37.974909** - Julia:
> dachte slide 3 ist raus tbh

**2025-10-27T10:56:52.087789** - Julia:
> die ab Slide 8 kenne ich nicht

**2025-10-27T10:57:34.225429** - Julia:
> okay passt, leg ich ab

**2025-10-27T11:05:14.686779** - Julia:
> liegt alles ab, habs nochmal in unterordner abgelegt

**2025-10-27T11:05:40.669369** - Julia:
> klaroo

**2025-10-27T13:29:35.044209** - Julia:
> Na klar, bin in 20 min wieder an PC

**2025-10-27T13:46:08.912589** - Julia:
> bin daaa

**2025-10-27T13:52:44.829049** - Julia:
> Ja klar

**2025-10-27T14:32:13.169299** - Julia:
> jaa gut! Evtl nur noch ergänzen: 2 Stills die thematisch zu den Gipfeltreffen Videos passen innerhalb dieser Kampagne

**2025-10-27T14:33:37.958209** - Julia:
> pörfekt

**2025-10-27T14:33:47.559129** - Julia:
> hoffe sie versteht es

**2025-10-27T14:33:51.287829** - Julia:
> aber es ist super erklärt

**2025-10-27T14:53:02.017569** - Julia:
> Ja macht Sinn. die safezone könnte man Mann weglassen, weil wir ja nie Text auf Bild als auf schalten werden (oder?) also somit werden k nur Bilder abgeschnitten die natürlich sowieso gut platziert sein müssen 

**2025-10-27T14:53:28.366219** - Julia:
> Ja die Info von 3. hat uns gefehlt :zany_face:

**2025-10-27T15:14:16.129329** - Julia:
> oh schön 

**2025-10-27T15:14:49.891339** - Julia:
> stills sind nicht dämlich :no_mouth: 

**2025-10-27T15:14:54.301489** - Julia:
> Leg ich ab 

**2025-10-27T15:16:24.565569** - Julia:
> können wir denn irgendwie an die video captions der Kampagne kommen? 

**2025-10-27T15:24:39.277639** - Julia:
> okay 

**2025-10-27T15:25:02.596509** - Julia:
> Ja voll, ich schau mal im ads Manager wie Porsche global das macht 

**2025-10-27T15:51:37.659969** - Julia:
> okay mach ich

**2025-10-27T15:51:43.607889** - Julia:
> ne alles gut

**2025-10-27T15:53:19.301719** - Julia:
> find ich super

**2025-10-27T15:54:20.872599** - Julia:
> Ahh wollte grad suchen

**2025-10-27T15:55:34.227259** - Julia:
> was ich bei Charly einfach liebe ist, dass sie es so hindreht mit "für mich ist das parallel jetzt echt schwer"
Als wären WIR schuld an dem ganzen hin und her. Weißt du wie ich meine? Wir unterstützen sie nur bei etwas netterweise und sie dreht es so hin als ob wir dumm sind :smile:

**2025-10-27T15:56:34.175449** - Julia:
> omg

**2025-10-27T15:56:55.578569** - Julia:
> ne geht keiner ran

**2025-10-27T15:58:48.239299** - Julia:
> habs jetzt mal versucht und jetzt auf die VM gesprochen

**2025-10-27T15:59:04.762609** - Julia:
> diese Katharina wird auch denken es brennt

**2025-10-27T15:59:44.641629** - Julia:
> ja voll

**2025-10-27T16:00:05.253259** - Julia:
> auch das "bleibt das Thema halt weiterhin liegen" ja okay, we dont care? :smile:

**2025-10-27T16:02:43.761939** - Julia:
> dann bereite ich jetzt aber keine assets vor, oder? :smile:

**2025-10-27T16:04:11.125879** - Julia:
> ja klar

**2025-10-27T16:04:20.796919** - Julia:
> sag bescheid, wenn ich noch etwas tun kann

**2025-10-27T16:04:39.398379** - Julia:
> wer??

**2025-10-27T16:04:48.638609** - Julia:
> schieb rüber, ich kann alles übernehmen

**2025-10-27T16:04:56.185519** - Julia:
> ah

**2025-10-27T16:05:24.207109** - Julia:
> okay

**2025-10-27T16:05:37.796819** - Julia:
> fühle mich so schlecht, wenn man so garnichts zutun hat :smile:

**2025-10-27T16:27:31.872129** - Julia:
> ja klar

**2025-10-27T16:30:27.224619** - Julia:
> ich bin dran

**2025-10-27T16:37:59.926239** - Julia:
> Hallo Dana,

wir haben euch leider telefonisch nicht erreicht und wollten uns deshalb kurz auf diesem Weg mit euch abstimmen. Ansonsten auch gerne direkt morgen in einem kurzen Meeting?

Konkret geht es um eine klare Empfehlung, wie wir die beiden noch offenen Posts der 911 Engagement Kampagne am schnellsten und sinnvollsten live stellen können – idealerweise so, dass das Budget effizient genutzt wird.
Charly’s Favorit wäre es organische Posts zu nehmen (am liebsten im Carousel-Format). Laut Asset Guide und den aktuellen Meta-Richtlinien scheint das grundsätzlich machbar aber muss getestet werden – könnt ihr uns sagen, wie schnell das realistisch umsetzbar wäre? Müssen wir hier mit der üblichen 3-Tage-Umsetzungszeit rechnen?

Falls das nicht praktikabel ist, bliebe als Alternative ja nur die Schaltung von 2 Still Dark Ads (in 1x1 und 9x16). Oder?
Könntet ihr uns bitte für die zwei fehlenden Assets der 911 Engagement Kampagne also zwei konkrete Varianten nennen, die ihr performance-seitig für am geeignetsten haltet?


Euer Asset Guide ist zwar technisch hilfreich, ist aber tatsächlich etwas knapp gehalten – uns fehlt die klare Einordnung, was für unsere aktuelle Situation tatsächlich am meisten Sinn macht, damit wir direkt entscheiden können und die Kampagne online gehen kann.

Falls wir kurz dazu sprechen sollen, könnt ihr gerne direkt morgens unter <tel:+15229018774|+15229018774> anrufen.

**2025-10-27T16:38:36.486929** - Julia:
> also ne

**2025-10-27T16:38:40.284069** - Julia:
> Charly hat doch keine ahnung

**2025-10-27T16:38:44.380909** - Julia:
> die bringt so viel verwirrung rein

**2025-10-27T16:40:12.018309** - Julia:
> frage ist "was ist die aktuelle"?
Weil dann müssen es ja die gleichen assets sein, die "in der aktuellen sind". dann brauchen wir auch nichts neues reinnehmen, sonst ist der Vergleich ja komplett vrefälscht

**2025-10-27T16:40:35.091349** - Julia:
> soll ich die Mail abschicken? Kann ich gerne maachen

**2025-10-27T16:41:52.509109** - Julia:
> moment ich vergleiche kurz

**2025-10-27T16:43:26.473769** - Julia:
> ja passt

**2025-10-27T16:43:58.208629** - Julia:
> vogelwild, dass du ihr jetzt performance marketing erklären sollst

**2025-10-27T16:45:43.186479** - Julia:
> genau

**2025-10-27T16:48:08.781749** - Julia:
> unglaublich

**2025-10-27T16:48:20.347199** - Julia:
> die soll doch einfach mal netflix anmachen und chillen

**2025-10-27T16:48:25.735179** - Julia:
> wenn sie schon krank ist

**2025-10-27T16:54:57.699769** - Julia:
> T -4 !!!

**2025-10-27T17:19:17.689159** - Julia:
> okay :smile:

**2025-10-27T17:19:44.479909** - Julia:
> mach ich haha

**2025-10-28T09:38:51.429959** - Julia:
> Hallooo

**2025-10-28T09:38:59.431419** - Julia:
> Ahh ich hab keinen Termin drin

**2025-10-28T09:43:50.908849** - Julia:
> 

**2025-10-28T10:26:35.414579** - Julia:
> Hast du hierauf zugriff?

**2025-10-28T10:26:37.369289** - Julia:
> <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/EaiOjQqrU7pGuG9Uh1HoPnYBcTMdT3cFpeBT1QC5Z3cmWw?e=TkNX08>

**2025-10-28T14:38:31.117349** - Julia:
> Hä aber genau deshalb liefert man ja 2 Formate an 

**2025-10-28T14:40:58.692349** - Julia:
> also weil sie meint ja, dass 9x16 auf 1x1 gecropped wird. Aber das stimmt ja nicht: wir liefern 2 fertige Formate an, da wird bei Meta nichts mehr gecropped

**2025-10-28T14:41:42.768779** - Julia:
> Deshalb gibt es ja 2 von euch Bänder unterschiedliche Formate 

**2025-10-28T14:42:03.683579** - Julia:
> Das besteht sie nicht. Es sind unterschiedliche einzelne Assets, das muss sie mal kapieren :zany_face:

**2025-10-28T14:43:03.372979** - Julia:
> Ja. Ich hab schon <tel:1000000|1000000> c ads in meinem Leben gemacht - bei 1x1 gibt es keinen Safe Space, hier kann nichts zugeschnitten werden und bei 9x16 ist es der gleiche Space wie bei einer story

**2025-10-28T14:43:28.731519** - Julia:
> Ja genau. Ich hab’s ja direkt für beide Kampagnen angelegt 

**2025-10-28T14:44:56.966039** - Julia:
> Ja 

**2025-10-28T14:45:48.373149** - Julia:
> Also mehr als das kann ich nicht sagen :joy: es wird bei 9x16 was ich in die Präsi gelegt habe NIX zugeschnitten weil das als Story ausgespielt wird  

**2025-10-28T14:49:13.221829** - Julia:
> ja genau

**2025-10-28T14:50:11.335879** - Julia:
> Du kannst ihr auch gerne sagen, ich kann ihr :sparkles:sehr sehr:sparkles: gerne morgen früh mal Paid Ads erklären und deren ausspielung 

**2025-10-28T14:50:18.690039** - Julia:
> Damit es klarer wird für sie 

**2025-10-28T14:50:49.819859** - Julia:
> ahhh die macht mich wahnsinnig :joy:

**2025-10-28T14:51:12.784899** - Julia:
> wenn sie uns dann damit in Ruhe lässt ja 

**2025-10-28T14:55:20.421339** - Julia:
> und wir dann auch einfach mal nicht dumm dastehen

**2025-10-28T14:55:38.220289** - Julia:
> sie ihn oder er dich? 

**2025-10-28T14:55:40.408589** - Julia:
> Oder beides 

**2025-10-28T15:05:29.385639** - Julia:
> ah noch was anderes: die Rechnung von :mouse: war ja schon in der Mail. Aber ich schicke es Flo lieber nochmal oder? 

**2025-10-28T15:24:27.963969** - Julia:
> puh

**2025-10-28T15:25:43.161539** - Julia:
> also wenn das so ist, dann ist das was neues

**2025-10-28T15:25:47.949819** - Julia:
> oder die agentur redet quatsch

**2025-10-28T15:26:10.577279** - Julia:
> Also ich hab wie gsagt bis vor 2 Monaten noch tagtäglich Ads gemacht und da liefert man 2 Formate an die nicht zugeschnitten werden oder sonst was

**2025-10-28T15:27:39.736289** - Julia:
> ahh danke!

**2025-10-28T15:27:41.699989** - Julia:
> wow

**2025-10-28T15:30:16.411899** - Julia:
> weißt ich würde das ja nicht so stocksteif behaupten, wenn ich nicht wüsste, dass es so ist ODER war

**2025-10-28T15:31:33.720399** - Julia:
> ich hab das auch noch nie gehört

**2025-10-28T15:31:51.756159** - Julia:
> ABER dann ist es 9x16 und bleibt 9x16, weil das wird ja von PHD empfohlen

**2025-10-28T15:33:29.148529** - Julia:
> ja, dann schieb ich das jetzt hoch + VBWs damit 9x16 auch für 1x1 zuschnitt passt (HAB ICH NOCH NIE GEHÖRT)
und die 1x1 assets liegen dann schon für die nächste Kampagne ab

**2025-10-28T15:39:45.909299** - Julia:
> <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/EaiOjQqrU7pGuG9Uh1HoPnYBcTMdT3cFpeBT1QC5Z3cmWw?e=bK4FuL>

**2025-10-28T15:39:49.321259** - Julia:
> liegen ab

**2025-10-28T15:41:51.040359** - Julia:
> 

**2025-10-28T15:42:21.019329** - Julia:
> das ist wirklich neu

**2025-10-28T15:42:53.063019** - Julia:
> hab dir den neuen ausschnitt in die präsi gelegt – sobald Go, leg ichs dann auch ab

**2025-10-28T17:10:07.118689** - Julia:
> kam nochmal was? 

**2025-10-28T17:10:40.354249** - Julia:
> finds aber auch krass, diese Katharina hat nicht zurück gerufen  

**2025-10-28T17:12:18.313059** - Julia:
> Aber dann ganz ehrlich: warum kackt Charly uns/ dich dann an, dann soll sie das doch mit denen direkt klären? anstatt komplette Verwirrung zu stiften :smile:

**2025-10-29T09:13:29.411769** - Julia:
> Guten Morgen! klar, kann reinkommen. Aber ohne Kamera – liege, das fände ich komisch :smile:

**2025-10-29T09:15:28.872739** - Julia:
> ich komme nicht rein

**2025-10-29T09:17:07.657289** - Julia:
> 

**2025-10-29T09:18:09.785569** - Julia:
> dann komm ich auf jeden fall und unterstütze dich. aber es lädt einfach nicht, ich probiere solange es geht!!

**2025-10-29T09:20:12.091079** - Julia:
> das ist so ein scheiß – kann nichts drücken, garnichts

**2025-10-29T09:20:52.734479** - Julia:
> Tut mir leid :fearful: aber ich bin da, wenn du was brauchst und ich so schnell helfen soll

**2025-10-29T09:25:54.315979** - Julia:
> oke

**2025-10-29T09:49:29.809469** - Julia:
> soo schlimm?

**2025-10-29T09:49:34.182839** - Julia:
> sollen wir kurz sprechen?

**2025-10-29T09:49:42.269039** - Julia:
> mach mir noch schnell einen kaffee und wäre da

**2025-10-29T09:55:27.965849** - Julia:
> okidoki

**2025-10-29T10:03:07.677149** - Julia:
> Träume sind kein Zufall. Sie sind Sonderwunsch.
--
Träume baut man nicht von der Stange.
 Man erschafft sie – mit Porsche Sonderwunsch.
--
Kein Mainstream. Kein Zufall. Porsche Sonderwunsch.

**2025-10-29T10:06:34.729159** - Julia:
> also ich komme immer noch nicht in teams, falls hanna was geschrieben hat

**2025-10-29T10:07:09.847559** - Julia:
> okee

**2025-10-29T10:10:40.359199** - Julia:
> was planen sie dann an Karneval? die 911/ 11.11.?

**2025-10-29T11:27:05.993939** - Julia:
> sonst gabs kein to do mehr wahrscheinlich oder?

**2025-10-29T11:51:44.316579** - Julia:
> okay ja

**2025-10-29T11:51:46.381119** - Julia:
> ja hab ich gesehen

**2025-10-29T11:51:57.743889** - Julia:
> wieso war sie dann blöd? also welchen grund gab es denn?

**2025-10-29T11:52:58.571539** - Julia:
> Oh gott

**2025-10-29T11:53:00.757859** - Julia:
> ne haben wir nicht

**2025-10-29T11:53:02.871339** - Julia:
> natürlich nicht

**2025-10-29T11:53:34.763559** - Julia:
> boah exy

**2025-10-29T11:53:43.968359** - Julia:
> schlimmer als jeder David L. dieser Welt

**2025-10-29T11:53:56.765349** - Julia:
> echt als wären wir dumm

**2025-10-29T11:54:03.215409** - Julia:
> tut mir leid :fearful:

**2025-10-29T12:17:41.938269** - Julia:
> jaa

**2025-10-29T12:17:47.449589** - Julia:
> versteh ich :face_exhaling:

**2025-10-29T14:29:31.413969** - Julia:
> okay

**2025-10-29T14:29:39.914289** - Julia:
> hab grad die Mail gelesen von Dana

**2025-10-29T14:29:45.206599** - Julia:
> in 9x16 dann?

**2025-10-29T14:29:59.176009** - Julia:
> und VBW von November?

**2025-10-29T14:32:16.073759** - Julia:
> haha oke

**2025-10-29T14:36:06.056119** - Julia:
> 

**2025-10-29T14:36:11.334089** - Julia:
> also ich hab nochmal alles probiert, laptop aus an aber ich komme nicht in teams

**2025-10-29T14:36:33.525969** - Julia:
> ob ichs Flo schon 15x gesagt hab? :melting_face:

**2025-10-29T14:39:30.571079** - Julia:
> ja klar

**2025-10-29T14:40:51.782089** - Julia:
> genau, sie hatte mich da auch mit eingeladen aber ich komme einfach nicht rein

**2025-10-29T14:41:08.580429** - Julia:
> klar

**2025-10-29T14:41:34.030039** - Julia:
> jetzt oder nach dem call mit hanna?

**2025-10-29T14:56:07.607459** - Julia:
> <https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1211465610715674?focus=true>

**2025-10-29T14:57:12.535419** - Julia:
> <https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1211408893442141?focus=true>

**2025-10-30T10:04:19.833679** - Julia:
> also bei den Rundgang Stories können wir halt nichts schedulen – die müssen alle händisch gepostet werden FYI

**2025-10-30T10:16:36.345709** - Julia:
> okay

**2025-10-30T10:17:01.980079** - Julia:
> sollen wir so um 12Uhr wegen reporting sprechen oder lieber nachmittags? :slightly_smiling_face:

**2025-10-30T10:17:05.224049** - Julia:
> mir ist es total egal

**2025-10-30T10:31:56.182449** - Julia:
> ich bin wieder in teaaaaams!

**2025-10-30T10:32:23.593159** - Julia:
> Weiß leider nicht was Hanna meint mit Leica Fotos sind quer..?
wollte eben ein update zu den stories geben

**2025-10-30T10:35:24.508129** - Julia:
> ah okay!

**2025-10-30T10:37:20.388009** - Julia:
> alright

**2025-10-30T12:00:52.478219** - Julia:
> klaro

**2025-10-30T13:06:33.183889** - Julia:
> done

**2025-10-30T13:06:43.632649** - Julia:
> also IG Insights sind bei mir jetzt WIEDER andere

**2025-10-30T13:07:12.001609** - Julia:
> deswegen, ob das stimmt i daut it

**2025-10-30T13:25:13.817549** - Julia:
> Falls du die Rundgang Carousels schon mal auf Sprinklr laden willst, die sind ja fertig
<https://drive.google.com/drive/folders/1Mzzke_INP34Rxgt-Z-Wwnbx05ZHZOr5Y|Poster Gallery>
<https://drive.google.com/drive/folders/1uXMnS32dr8KAL8s9eNeNA_O72G4h0Hri|Café>

Bei den Stories warte ich noch auf Hanna's Antwort in Teams

**2025-10-30T14:11:16.634009** - Julia:
> ich hab dir jetzt jeden Content den ich erstellt hab geschickt in asana. Wenn du heute zu busy bist, kann ich das morgen/ später auch gerne auf sprinklr stellen, garkein Problem :slightly_smiling_face: nur für das Übergabe Sheet kann ich das ja nicht machen

**2025-10-30T14:12:35.105339** - Julia:
> voll die gute antwort, danke :smile:

**2025-10-30T14:16:48.358919** - Julia:
> ja sag einfach bescheid!

**2025-10-31T09:06:29.555049** - Julia:
> Huhuu, falls du kurz da bist: was soll ich zu Flo sagen bezüglich Reporting? Was hattest du Hanna jetzt kommuniziert? Sonst würde ich einfach sagen "ne haben wir noch nicht" – weil das ist ja eh ein Witz, was wir da reingepackt haben.

**2025-10-31T12:28:09.099129** - Julia:
> das Blurry?

**2025-10-31T12:28:38.667569** - Julia:
> kann ich ihr schicken, ja. aber liegt ja auf picdrop?

**2025-10-31T12:32:54.117789** - Julia:
> done

**2025-10-31T12:34:11.910139** - Julia:
> warum schreibt sie dir da, die weiß doch, dass du off bist. ah nervig

**2025-10-31T12:50:09.252099** - Julia:
> :face_with_peeking_eye:

**2025-10-31T12:51:11.896209** - Julia:
> yeeees

**2025-11-10T09:56:17.038199** - Julia:
> <https://docs.google.com/document/d/1PbEVpTroRccqnCrtHg53hsJWhv4qibQldX2fX5jIRyY/edit?usp=sharing>

**2025-11-10T10:07:02.940549** - Julia:
> <https://applink.larksuite.com/client/chat/chatter/add_by_link?link_token=991o284b-52af-4104-a9d1-8582ecj085qd>

**2025-11-10T10:27:56.311749** - Julia:
> Hier wäre die Agenda für den Hisense-Termin.

*AGENDA HISENSE – Jour Fixe (heute)*
1. *Vorstellung neues BCC-Team*
    ◦ Einführung *Julia, Juli und Mert*
    ◦ Rollen &amp; Verantwortlichkeiten
    ◦ Ziel: volle Fokussierung auf Hisense &amp; effizientere Content-Prozesse
1. *Shoots 2025 – Planung &amp; Timeline*
• *BCC stellt heute* die *Timeline mit konkreten Terminen* für:
        ▪︎ 2x Shooting *Gorenje (Produktverfügbarkeit in München klären)*
        ▪︎ 2x Shootings *Hisense (Produktverfügbarkeit in München klären)*
        ▪︎ 1x Shooting mit *Pascal Hens (18.11., Berlin)*
        ▪︎ *1x Shooting Laser Studios (falls gewünscht 10.12. in München)*
1. *Konzept &amp; Highlight-Produkte*
    ◦ BCC stellt erste Konzepte für die Highlight-Ideen &amp; Shootings vor.
    ◦ *Nächster Schritt: Freigabe durch Hisense am 12.11.*
• Fokus-Produkte:
        ▪︎ *Hisense:* <http://RGB.TV|RGB.TV>, Crossdoor with Ice Maker, 5s Washing Machine, Microwave (Inverter without plate)

    ◦ *Gorenje:* Pizza Oven, Dishwasher
1. *Next Steps &amp; Verantwortlichkeiten*
    ◦ *Hisense:* Feedback zu Produktverfügbarkeit in München &amp; Freigabe der Shootings
    ◦ *Gemeinsam:* Feinschliff Shootingplanung + Vorbereitung Berlin-Shoot
    ◦ Hisense schickt BCC eine Standortübersicht der Laser Studios (07.11.)


**2025-11-10T10:47:06.580189** - Julia:
> habs ihr geschickt

**2025-11-10T11:44:44.635649** - Julia:
> ja die Daten sind von uns – gerade Antwort von Jana bekommen moment

**2025-11-10T11:45:02.220339** - Julia:
> der Produkionsplan für mich so auch noch keinen Sinn

**2025-11-10T11:45:54.533569** - Julia:
> Was ist die EHF? :face_with_peeking_eye:

**2025-11-10T11:46:40.360019** - Julia:
> Ich hab tatsächlich noch ein paar Fragen, die mir von letzter Woche noch fehlen:
• wie ist der Kommunikationsstand mit dem Kunden gerade --&gt; die letzte Mail von Ray am 5.11. noch aktuell? Wie sieht es mit Produktverfügbarkeiten aus? Falls nicht, könntest du uns bitte alle Mails weiterleiten :slightly_smiling_face:
• die Termine der Produktionen sind noch uns festgelegt oder woher kommen diese? Final und mit Kunden abgestimmt?
• Wie gehts weiter mit dem Content Upload? Wo liegen diese Dateien und wer postet? Die Ordner im Drive sind teilweise leer
• CI Unterlagen fehlen uns noch
• Reportings sind teilweise noch offen, finalisiert ihr diese noch bis Oktober?
• Ist Marvin wieder da? Bezüglich CM
• Wird der Pascal Hens Content auch auf TikTok geposted oder ist das komplett getrennt?
• noch eine detaillierte Frage zum Produktionsbudget: wie ist hier die Abstimmung, also sind wir komplett frei in der Aufteilung oder spricht der Kunde da mit? Gibt der Kunde alles frei oder haben wir freie Hand?
*Jana Antworten:*
• Ich schicke dir noch mal alles weiter
• Sind von uns, Feedback von Kunden steht noch aus, ob tiny House und Produkte verfügbar sind
• Content Upload ist ja im Editorial Plan, da kannst du es dann hochladen.
• CI und CM spreche ich gleich mit Marvin
• Pascal Hens wird mit uns gedreht dementsprechend auch für TikTok
• Produktionsbudget bitte mit Flo klaren


*Meine erneuten Rückfragen:*
Okay danke dir!
• du meinst über <http://Frame.io|Frame.io> downloaden? Bis wohin lädst du denn hoch oder ab wann sollen wir? Das müssten wir ja festlegen
• Pascal Hens: was heißt genau "wird mit uns gedreht"? Wir sollen ja nur noch eine Content Idee liefern – läuft die Kampagne nicht über die Instagram Agentur?
• Budget: yes, aber hast du in der Vergangenheit die anfallenden Kosten mit dem Kunden besprochen also zB Kosten für Statisten oder gabs einfach das Budget und macht was ihr wollt damit?


**2025-11-10T11:52:42.016969** - Julia:
> Ach quatsch

**2025-11-10T11:53:14.741749** - Julia:
> Shit, ich hab da mit dem neuen Benutzer auch keinen Zugriff  :melting_face: muss ich mich nochmal einloggen, dauert kurz

**2025-11-10T11:55:59.949789** - Julia:
> :joy: wow okay

**2025-11-10T11:56:05.173129** - Julia:
> ja verstehe, gute Idee!

**2025-11-10T11:59:29.339379** - Julia:
> die 2 Anfragen sind freigegeben

**2025-11-10T12:06:59.430149** - Julia:
> Reportings hab ich nochmal nachgehackt

**2025-11-10T12:07:46.876209** - Julia:
> also es gibt wirklich nicht viel was mich auf die Palme bringt, aber halbherzige Antworten/ Infos machen mich wortwörtlich zum Stier :triangular_flag_on_post:

**2025-11-10T12:22:43.495659** - Julia:
> 

**2025-11-10T13:35:20.277169** - Julia:
> nee, hab eh noch keine antworten. bin an dem Pascal ding dran

**2025-11-10T13:35:23.291289** - Julia:
> happy break :slightly_smiling_face:

**2025-11-11T10:30:35.869699** - Julia:
> Lark:
Julia Hopper hat Sie zu einer Gruppe in Lark eingeladen, klicken Sie auf <https://applink.larksuite.com/client/chat/chatter/add_by_link?link_token=befu6419-b9b0-4875-90e2-ab1326jcbal6>, um beizutreten！

**2025-11-11T10:36:37.873129** - Julia:
> Jana Kordt invited you to a group on Lark, click <https://applink.larksuite.com/client/chat/chatter/add_by_link?link_token=991o284b-52af-4104-a9d1-8582ecj085qd> to join!

**2025-11-11T11:32:39.765189** - Julia:
> ahh ich bin noch nicht in der Roadmap in Asana :slightly_smiling_face: magst du mich da noch hinzufügen?

**2025-11-11T11:38:24.538759** - Julia:
> also jetzt wollte mir Jana blöd kommen

**2025-11-11T11:38:35.126759** - Julia:
> wir sollen uns doch bitte mit dir abstimmen

**2025-11-11T11:38:45.726999** - Julia:
> weil du ja jetzt schon mit Marvin parallel alles abstimmst

**2025-11-11T11:38:53.186179** - Julia:
> :smile:

**2025-11-11T17:02:52.419649** - Julia:
> weißt du was dieser Slash Termin morgen ist? wahrscheinlich die IG Agentur?

**2025-11-11T18:17:59.709329** - Julia:
> echt meinst du? oh man ey

**2025-11-11T18:18:13.283429** - Julia:
> hätte man auch echt alles einfach letzte Woche machen können, versteh ich nicht

**2025-11-12T10:12:35.124949** - Julia:
> alsooooo

**2025-11-12T10:12:43.613899** - Julia:
> sie ist beim termin heute schon mal nicht dabei

**2025-11-12T10:13:07.735719** - Julia:
> :fast_parrot:

**2025-11-12T10:25:22.122949** - Julia:
> ich glaubs dir

**2025-11-12T10:25:31.198609** - Julia:
> hab ganz beifläufig gefragt :slightly_smiling_face:

**2025-11-12T10:28:56.800179** - Julia:
> auch so krass, dass manche Menschen echt so einen Stress bei einem auslösen können. also ich kenn das. ganz unangenehm

**2025-11-12T13:26:15.687169** - Julia:
> ach du alles gut. ich kanns einfach nur nicht verstehen, wie man so arbeiten kann und vorallem aber auch dauernd so tun, als wäre alles super und erledigt

**2025-11-12T13:26:33.490439** - Julia:
> jaaaa glaub ich dir

**2025-11-12T13:27:46.683499** - Julia:
> also ich könnte dir echt den ganzen chat schicken, sie antwortet mit einem kurzen satz. thats it. da ist weder meine frage beantwortet, noch irgendwas

**2025-11-12T13:29:26.673689** - Julia:
> :joy:

**2025-11-13T09:32:39.657119** - Julia:
> NEIN wieso???

**2025-11-13T09:33:16.236079** - Julia:
> die kotzt mich so an, kackt mich einfach in der gruppe mit flo an. aber arbeitet selbst nichts

**2025-11-13T09:41:37.855509** - Julia:
> ja vorallem wir wissen ja wieso

**2025-11-13T09:44:30.817729** - Julia:
> :rage:

**2025-11-13T09:48:21.907999** - Julia:
> ja alles so ätzend

**2025-11-13T16:36:09.730409** - Julia:
> Wenn du morgen off bist, soll ich dann antworten, falls Laureen/ Ray antworten auf unsere Fragen oder bis Montag liegen lassen?

**2025-11-13T16:38:16.497609** - Julia:
> okay :slightly_smiling_face:

**2025-11-18T16:02:03.179589** - Julia:
> alles gut soweit?

**2025-11-18T16:02:40.508069** - Julia:
> ja, hab ich mir auch gedacht

**2025-11-18T16:02:44.810289** - Julia:
> :melting_face:

**2025-11-18T16:02:54.921039** - Julia:
> ne

**2025-11-18T16:02:57.152349** - Julia:
> weiß er ja auch

**2025-11-18T16:07:30.220229** - Julia:
> ich weiß.. :face_with_spiral_eyes:

**2025-11-18T16:08:55.989209** - Julia:
> also ich versteh bis heute nicht wieso man in so einer menschlichen beziehung beim gleichen arbeitgeber startet

**2025-11-18T16:09:26.693459** - Julia:
> willst du lieber raus?

**2025-11-18T16:09:50.279909** - Julia:
> kann ja sagen, dein internet war weg oder so

**2025-11-18T16:09:53.173049** - Julia:
> okay

**2025-11-18T16:12:14.905689** - Julia:
> voll. Flo meinte vorhin BitPanda ist schon mega happy jetzt im ersten Schritt – also kann mir gut vorstellen, dass die auch noch dazu kommen

**2025-11-18T16:18:54.854469** - Julia:
> ich wollte es gerade sagen haha

**2025-11-18T16:19:16.254539** - Julia:
> ich auch nicht

**2025-11-18T16:19:23.458889** - Julia:
> also es ist ein Kummerkasten ohne Kummer?

**2025-11-18T16:20:40.443819** - Julia:
> ich glaube, das hat er extra schon geschrieben

**2025-11-18T16:20:46.882569** - Julia:
> PM oder CL

**2025-11-18T16:20:48.001769** - Julia:
> genau

**2025-11-18T16:21:24.784959** - Julia:
> ja voll

**2025-11-18T16:21:45.860609** - Julia:
> sie kackt Mert und mich auch fast täglich gerade an wegen Hisense noch. super unnötig

**2025-11-18T16:22:20.038659** - Julia:
> ich glaube bei ihm, muss man das echt oft sagen muss

**2025-11-18T16:27:26.087629** - Julia:
> weil das Video nur 70 views hat und wird es nicht gepusht haben. hab ihr dann natürlich gesagt, wir haben jetzt mit Flo gesprochen und alles geklärt
Ne reicht ihr nicht, sie meinte dann: ja aber das Video können wir nicht mit 700 Views stehen lassen!??!?!

Ja sorry, dann mach besseren Content

**2025-11-18T16:27:30.537739** - Julia:
> :smile:

**2025-11-18T16:27:48.840569** - Julia:
> ja ist ja eigentlich nur für die chefs

**2025-11-18T16:29:18.639869** - Julia:
> so, geh halt kurz – nobody will notice

**2025-11-18T17:04:09.028619** - Julia:
> glaub wir bleiben doch in kleinen teams

**2025-11-18T17:04:29.461109** - Julia:
> und ich kann ja freitags oder auch generell das immer übernehmen, ist ja garkein problem

**2025-11-18T17:08:05.413709** - Julia:
> Okay

**2025-11-18T17:08:09.501549** - Julia:
> ja ist doch klar

**2025-11-21T13:32:10.058349** - Julia:
> Kosten Heimkinoraum :melting_face:

**2025-11-24T12:11:50.725849** - Julia:
> also

**2025-11-27T14:50:30.444949** - Julia:
> JA :smile:

**2025-11-27T14:59:41.268089** - Julia:
> ja genau, aber da muss mert nochmal sagen, ob er die finalen schon abgelegt hat mit Emoji Austausch. ich frag

**2025-11-27T17:16:54.472269** - Julia:
> bevor ich es vergesse:

**2025-11-27T17:17:48.971699** - Julia:
> 

**2025-11-28T10:08:24.317309** - Julia:
> 

**2025-11-28T12:00:47.545289** - Julia:
> jap, männer i mean.. :smile:

**2025-11-28T12:02:18.668219** - Julia:
> 

**2025-11-28T13:20:44.733159** - Julia:
> ja total

**2025-11-28T13:21:10.954889** - Julia:
> das frag ich mich auch. Team MAC :point_up_2::point_up_2::point_up_2::point_up_2::point_up_2::point_up_2::point_up_2::point_up_2:

**2025-11-28T13:21:22.631699** - Julia:
> ahh wollen sie da noch ausschreiben? also müssen sie ja

**2025-11-28T13:42:05.843139** - Julia:
> uii oke

**2025-12-01T09:33:59.902119** - Julia:
> Hallo :blush:hättest du schon paar Minuten vor 10 Zeit? 

**2025-12-01T09:53:22.613379** - Julia:
> okeee

**2025-12-01T12:43:17.457389** - Julia:
> so krass, er versteht einfach nicht, dass weder Marie noch ich Ahnung davon haben. Oder will es nicht verstehen

**2025-12-01T12:43:25.771559** - Julia:
> Genau wie damals bei den Reportings

**2025-12-01T12:44:38.333759** - Julia:
> "einfach" ja ne, für uns nicht einfach

**2025-12-01T12:44:40.247439** - Julia:
> ich kotze :smile:

**2025-12-01T12:44:41.756389** - Julia:
> NAJA

**2025-12-01T12:46:32.877879** - Julia:
> schickt sie mir heute

**2025-12-01T12:48:54.779509** - Julia:
> bisher nur das – aber die anrichte ist quasi links

**2025-12-01T12:50:58.771509** - Julia:
> also es ist super hell, komplett Motel a Miio ausgestattet, beige, cosy

**2025-12-01T12:53:55.565939** - Julia:
> ja verstehe. also der tisch ist gegenüber der anrichte und neben dem ofen ist noch so eine anrichte – da kann man easy vorbereiten. ansonsten haben sie einen 2m langen Esstisch im Wohnzimmer, was wir 100% auch benutzen dürfen

**2025-12-01T12:54:21.756999** - Julia:
> mega! aber ja das glaub ich wirklich auch. denke bei dem aufwand ist es wirklich cool, wenn wir mit leuten drehen die wir kennen

**2025-12-02T08:55:37.033099** - Julia:
> Gestern wurde der Peak erreicht

**2025-12-02T08:55:43.574629** - Julia:
> Whatsapp um 23.30

**2025-12-02T08:55:48.257849** - Julia:
> :joy:

**2025-12-02T08:56:31.588379** - Julia:
> ja

**2025-12-02T08:57:40.256139** - Julia:
> ja ich sags im meeting. will nur die 2 pitches von heute und morgen abwarten, damit die stimmung etwas entspannter ist

**2025-12-02T08:57:43.572409** - Julia:
> danke :heart_hands:

**2025-12-02T11:01:36.264429** - Julia:
> jaa

**2025-12-02T11:02:58.395289** - Julia:
> ja klar

**2025-12-02T11:09:28.515199** - Julia:
> also sie wollen Tiny House

**2025-12-02T11:36:28.310179** - Julia:
> einfach süß

**2025-12-03T15:54:24.353729** - Julia:
> ah jetzt kam Teams - dann springen wir dort rein oder

**2025-12-03T15:57:22.310279** - Julia:
> ah ne sie haben google zugesagt

**2025-12-03T15:59:45.419779** - Julia:
> wurd wieder gelöscht :smile:

**2025-12-03T15:59:52.310649** - Julia:
> <http://meet.google.com/mfw-ahfi-ysx|meet.google.com/mfw-ahfi-ysx>

**2025-12-03T16:15:52.985059** - Julia:
> wieso spricht Conny eigentlich nicht mal mit uns?

**2025-12-03T16:26:18.873699** - Julia:
> du schreibst wahrscheinlich eine nachricht/ mail oder?

**2025-12-03T16:26:46.300519** - Julia:
> klar gerne

**2025-12-03T16:27:42.784779** - Julia:
> Ja mega!

**2025-12-03T16:28:13.682779** - Julia:
> ich denke nicht, dass es machbar ist von ihrer seite aber well :smile:

**2025-12-04T10:58:25.235049** - Julia:
> 

**2025-12-04T10:58:29.942789** - Julia:
> ich bin hier:
<https://docs.google.com/presentation/d/1hCn3KbyAlmOzdpS0aAdcerl52U-l4EYm/edit?slide=id.g3a92d12bed8_1_36#slide=id.g3a92d12bed8_1_36>

**2025-12-04T13:16:50.796269** - Julia:
> alles gut

**2025-12-04T13:16:56.952059** - Julia:
> also ich bin immer noch in der präsi oben drin

**2025-12-04T13:17:28.123429** - Julia:
> ach klar! aber bitte keinen Stress. Ich hab später ja auch noch Zeit

**2025-12-04T13:33:24.653539** - Julia:
> weißt du jetzt, ob die Technik ready im Büro ist?

**2025-12-04T13:33:34.331169** - Julia:
> alles gut, wir haben morgen ja auch noch

**2025-12-04T13:34:53.664789** - Julia:
> also ich

**2025-12-04T13:36:01.060739** - Julia:
> okay

**2025-12-04T13:47:46.262769** - Julia:
> ich bin jetzt kurz Pause machen!

**2025-12-04T14:34:50.971819** - Julia:
> soo bin wieder da und schau mal die Gorenje skripte an oder? da hast du ja eh schon mega viel!

**2025-12-04T14:48:32.859599** - Julia:
> also ich füge jetzt noch Kamera usw. hinzu

**2025-12-04T14:49:33.535479** - Julia:
> Weil das ist was ich auch gestern meinte:
wir haben ja video, bei denen man Sequenzen mit Julia hat (Start der Videos) und dann schneiden wir ja B-Roll rein, während sie weiterspricht. Heißt wir haben ja viele Videos nicht mit anschließendem VoiceOver sondern muss ja währenddessen passieren

**2025-12-04T15:03:48.445469** - Julia:
> boah da fällt es mir total schwer, weil ich gefühlt in den videos garnicht mit drin war

**2025-12-04T15:04:10.793779** - Julia:
> ich kümmere mich "kurz" um Ikea und kann dir dann mehr Infos zum Timing geben

**2025-12-04T15:22:19.323699** - Julia:
> okay

**2025-12-04T15:22:39.765749** - Julia:
> das eine talking head video ist extra, wo siehst du die anderen dann?

**2025-12-04T15:29:46.846759** - Julia:
> du hast ja von 17-17.30 Talking Head eingetragen. Aber wir haben ja noch mehr Takling Heads. Sind die dann im jeweiligen Themenblock? Das meinte ich

**2025-12-04T15:32:14.921339** - Julia:
> okay

**2025-12-04T15:32:23.780259** - Julia:
> ja gerne

**2025-12-04T15:36:50.874169** - Julia:
> also Abholung morgen Ikea geht klar – 10-11 Uhr

**2025-12-04T15:40:40.524329** - Julia:
> Hast du noch den Kontakt zu Julia? Oder magst du ihr unsere Kontaktdaten weiterleiten? Ich glaube morgen Nachmittag wird irgendwie super knapp aber idk :smile:

**2025-12-04T15:45:20.151199** - Julia:
> ahh sorry

**2025-12-04T15:45:22.075969** - Julia:
> perfekt danke

**2025-12-04T15:58:08.723199** - Julia:
> So IKEA ist mehr oder weniger bestellt. Warte noch auf Flo's pushTan und dann gehts looooos

**2025-12-04T15:58:12.024919** - Julia:
> danke!

**2025-12-04T15:59:04.002529** - Julia:
> hab irgendwie ein komisches Bauchgefühl für morgen mit den Besorgungen

**2025-12-04T16:03:18.522409** - Julia:
> ne keine Ahnung, weiß auch nicht warum :smile:

**2025-12-04T16:03:25.928689** - Julia:
> Hat man ja manchmal. Wird schon alles klappen :slightly_smiling_face:

**2025-12-04T16:03:42.919279** - Julia:
> Kann das immer nicht, wenn quasi noch so viel unerledigt ist

**2025-12-04T16:04:24.336199** - Julia:
> okay :slightly_smiling_face:

**2025-12-04T16:04:56.845169** - Julia:
> Hat er zufälligerweise Werkzeug? eigentlich braucht man bei Ikea meistens nix anderes außer diesen Schlüssel der eh dabei ist, aber who knows.
Unser ganzes Werkzeug ist in Berlin und Mert hatte nichtmehr geantwortet

**2025-12-04T16:06:30.235659** - Julia:
> okay, danke :heart_hands:

**2025-12-04T16:06:33.134749** - Julia:
> ja klar, bitte!

**2025-12-04T16:06:52.913179** - Julia:
> Also nochmal letzter Check: die Lebensmittel Bestellung machst/ hast du gemacht?
Flink bestellen wir dann am Montag morgen

**2025-12-04T16:07:16.973399** - Julia:
> alles guuut. Aber vllt sehen wir uns ja in der Weihnachtszeit dann mal? Content Xmas und soo

**2025-12-04T16:07:38.037879** - Julia:
> Danke für deine Hilfe und bis (hoffentlich nicht) morgen hehe :heart_hands:

**2025-12-04T16:08:33.687299** - Julia:
> ahh okay, good to know!

**2025-12-04T16:08:45.702609** - Julia:
> Easy, sonst machen wir das einfach morgen, falls das dann schon geht

**2025-12-04T16:08:52.283629** - Julia:
> happy weekend schon mal :slightly_smiling_face:

**2025-12-05T09:59:40.490289** - Julia:
> hello! :slightly_smiling_face: könntest du mich noch bei dem Vertrags Dokument freischalten? Dann kann ich das für David und Marina erstellen

**2025-12-05T16:20:30.196649** - Julia:
> Also irgendwie klappt das leider nicht. Würdest du das sonst am Montag an die beiden schicken? :slightly_smiling_face: dankeee

Ist ja doch nur der Name:
Marina Danner – <mailto:info@marinadanner.de|info@marinadanner.de>
David Heimann – <mailto:Heimann_david@web.de|Heimann_david@web.de>

**2025-12-08T10:28:59.011849** - Julia:
> 800 hatten wir!

**2025-12-08T10:29:00.759889** - Julia:
> danke dir

**2025-12-11T12:43:31.126379** - Julia:
> 800€, dass wir in der Küche unten drehen??? :smile:

**2025-12-11T12:44:09.582219** - Julia:
> Bodenlos

**2025-12-15T09:39:33.650969** - Julia:
> Hello! :slightly_smiling_face: Hab leider nichts gefunden..

**2025-12-15T14:27:26.173119** - Julia:
> hello! hast du mit Mert schon gesprochen wegen den Videos? sonst kann ich es dir auch kurz "erklären"

**2025-12-15T14:37:46.311019** - Julia:
> klaro

**2025-12-15T14:37:47.460379** - Julia:
> huddle?

**2025-12-17T15:31:56.006369** - Julia:
> Sorry, dass ich so doof nochmal fragen muss: die Schriften von HiGo haben wir per Mail Zugang bekommen, oder?

**2025-12-17T16:45:56.040029** - Julia:
> dankeeee

**2025-12-18T10:17:25.119039** - Julia:
> Hello :slightly_smiling_face:

**2025-12-18T10:17:37.018079** - Julia:
> Welches video hat Peru noch bearbeitet? Sehe nur das interactive Video tbh

**2025-12-18T10:17:55.972069** - Julia:
> ah habs!!

**2025-12-18T10:19:44.497539** - Julia:
> ui, die haben die Idee ja garnicht verstanden leider

**2025-12-18T10:23:09.152269** - Julia:
> ich glaube Mert ist grad im überlebenskampf mit Premiere :smile: welches Video bräuchten wir denn noch für Gorenje: Hummus und/oder Ginger Wellness oder?
Das Problem ist, ich hab die Dateien noch nicht mal im Drive.. glaub das schaffe ich dann nichtmehr

**2025-12-18T10:57:56.509809** - Julia:
> ja glaub alle sind schwer

**2026-01-07T16:39:05.017769** - Julia:
> glaub ich ja nicht:
<https://www.linkedin.com/jobs/view/4344776702>

**2026-01-08T10:06:47.459679** - Julia:
> Yay Powerdays auch da

**2026-01-08T10:06:51.552359** - Julia:
> :joy:

**2026-01-08T10:15:32.447629** - Julia:
> Oh neeeein

**2026-01-08T10:15:39.316889** - Julia:
> Boah das ist auch perfektes Timing

**2026-01-08T10:15:51.532959** - Julia:
> hoffe nicht so lange wie in berlin :face_with_spiral_eyes:

**2026-01-08T10:16:48.068879** - Julia:
> krank, die armen Leute

**2026-01-08T10:16:58.688689** - Julia:
> ne, sie hats 3mal verschoben und jetzt ist es heute Abend

**2026-01-09T12:45:17.343039** - Julia:
> hatte ein sehr krasses Gespräch mit Marvin :smile: also unsere Einschätzungen oder eindrücke sind alle 10000% richtig

**2026-01-09T12:48:40.829529** - Julia:
> ja genau

**2026-01-09T12:52:07.415619** - Julia:
> können gerne jederzeit in huddle

**2026-01-12T09:44:33.921519** - Julia:
> Huhuuu

**2026-01-12T09:44:56.316819** - Julia:
> Also wegen mir könnten wir auch jetzt schon ins Meeting. Bin mir nicht sicher, ob Mert dann heute arbeitet oder nicht

**2026-01-12T09:46:09.008439** - Julia:
> okay, ich schenk mir noch schnell meinen Kaffee ein und komme ins meet

**2026-01-12T09:47:23.415439** - Julia:
> :fearful:

**2026-01-12T10:48:57.281669** - Julia:
> hat sich Flo schon gemeldet?

**2026-01-12T10:56:21.255769** - Julia:
> ah, hat mir schon auf whatsapp geschrieben :no_mouth:

**2026-01-12T10:56:22.612769** - Julia:
> lieben wir

**2026-01-12T10:56:41.674899** - Julia:
> doch klar, immer

**2026-01-12T10:57:47.484769** - Julia:
> keine Ahnung

**2026-01-12T10:58:05.215159** - Julia:
> Ja, ich ignorier schon so viel :smile: Aber das passt jetzt eh, weil ich ihm jetzt sagen konnte, dass ich gleich sprechen will

**2026-01-12T11:39:59.398839** - Julia:
> gerne, bin in 2 min ready. einmal aushusten :smile:

**2026-01-12T11:43:16.706469** - Julia:
> yay!

**2026-01-12T11:43:26.285629** - Julia:
> bin im meeting

**2026-01-12T12:32:04.428889** - Julia:
> okay, konnte nichts teasern. war ein sehr unangenehmes gespräch

**2026-01-12T12:37:27.994389** - Julia:
> Ja

**2026-01-12T12:37:37.255009** - Julia:
> wie gut, dass es sowas wie probezeit gibt

**2026-01-12T12:37:56.861029** - Julia:
> ich solls trotzdem machen

**2026-01-12T12:38:10.367059** - Julia:
> ne hab ich jetzt nicht gesagt

**2026-01-12T12:49:17.318659** - Julia:
> 

**2026-01-12T14:45:04.561649** - Julia:
> vogelwild alles...

**2026-01-12T14:45:15.588079** - Julia:
> Hat er sich schon bei dir zurück gemeldet?

**2026-01-12T15:04:37.001239** - Julia:
> ja. Also heute hat mir auf jeden Fall gezeigt, dass meine Zeit hier noch begrenzter ist als ich dachte :smiling_face_with_tear: 

**2026-01-12T15:52:40.248539** - Julia:
> ja ich glaubs dir...

**2026-01-12T15:52:44.550589** - Julia:
> bin sehr gespannt!

**2026-01-12T15:53:16.393429** - Julia:
> hab marvin schon bescheid gegeben wegen nächster woche und er meinte nur so "ne das wird flo safe nicht zulassen" (also, dass ich da hin fahr)

**2026-01-12T15:53:18.926449** - Julia:
> lets see

**2026-01-12T15:54:40.197869** - Julia:
> klar aber fänd ich schon auch doof einfach

**2026-01-12T15:54:41.120519** - Julia:
> NAJA

**2026-01-12T16:06:25.711079** - Julia:
> Hast du kurz zeit? Huddle?

**2026-01-12T16:07:10.250789** - Julia:
> okay perfekt

**2026-01-13T09:00:37.306469** - Julia:
> Hello :slightly_smiling_face: du ich hätte was auf meiner To Do Liste was ich abgeben könnte, falls du sonst nix hast. Sag bescheid, wenns okay ist :slightly_smiling_face: will dir ungern einfach irgendwas rüber schieben

**2026-01-13T09:02:44.523129** - Julia:
> okay danke :smiling_face_with_3_hearts:

**2026-01-13T09:02:54.843079** - Julia:
> Ah okay, schade! dann lösche ich ihn aus der präsi haha

**2026-01-13T09:05:24.892159** - Julia:
> und zwar haben Marie und ich bei <http://fastmoss.com|fastmoss.com> ein Probeabo für. 10€ abgeschlossen für Estée Lauder damals. Habs eigentlich direkt gekündigt aber jetzt wurde es uns trotzdem abgebucht. Ich hab denen schon 2mal per Whatsapp Kundensupport geschrieben, dass ich den Account kündigen will aber es reagiert niemand.
Da gibts noch eine Mail, vllt könntest du es da mal versuchen?
<mailto:info.sea@fastmoss.com|info.sea@fastmoss.com>

Unsere Konto ID:
11418184

**2026-01-13T09:17:10.358149** - Julia:
> ja willst du den Login noch? Bzw es ist irgendwie komisch, weil ich da einfach angemeldet bin aber ohne Passwort?!

**2026-01-13T09:17:11.451989** - Julia:
> DANKE

**2026-01-13T09:17:14.432729** - Julia:
> Puh neee

**2026-01-13T09:17:34.787109** - Julia:
> Vllt weil sie verschoben wurden?

**2026-01-13T09:17:40.720349** - Julia:
> ich checke mal kurz

**2026-01-13T09:18:41.397509** - Julia:
> vllt so: <https://next.frame.io/share/237647d8-ead7-4345-8270-bd2b6c4bbbce/>

**2026-01-13T09:18:52.199429** - Julia:
> oder man schickt ihr alle links der videos einzeln?

**2026-01-13T10:31:41.054329** - Julia:
> hättest du Zeit und Lust gleich kurz zu sprechen? bräuchte einmal kreativen Support :face_with_spiral_eyes:

**2026-01-13T10:37:06.480859** - Julia:
> gerne

**2026-01-13T10:52:45.039679** - Julia:
> 

**2026-01-13T10:53:10.231349** - Julia:
> 

**2026-01-13T10:53:51.905989** - Julia:
> <https://docs.google.com/document/d/1dP3eV06628rlLYVp7UBVO4DnXHoUEDkJQSThJ2X3hYI/edit?tab=t.0>

**2026-01-13T11:03:55.135929** - Julia:
> hahaha

**2026-01-13T11:07:30.962649** - Julia:
> also GPT sagt es ist klar 90er Streetwear

**2026-01-13T11:09:55.158989** - Julia:
> okay ich finds immer wieder faszinierend wie GPT wirklich gedanken sammeln und weiterentwickeln kann, hat mir das hier jetzt zur Bravo Idee ausgespuckt:

Das Hero-Asset: *LIDL MAGAZIN (Print + Digital Scan)*
Ein echtes Heft (limitiert) + eine „abfotografierte/gescannte“ Digitalversion als Content-Engine.
*Heft-Rubriken (mit Kollektion eingebaut):*
• *„Festival-Urlaub Packliste“* (Outfit-Check: Bucket Hat, Weste, Bag, Schlappen, Gürtel)
• *„Crush-Alarm!“* Mini-Storys (Comedy-Skits wie eure Isar/FKK-Situation)
• *„Welcher Festival-Typ bist du?“* (Quiz → endet in Produktempfehlung)
• *„Hot or Not“* (90s Polaroid-Streetsnaps)
• *„Poster“*: 90s-Pose, großer Schriftzug „LOHNT SICH“ + Key-Look
• *„Kummerkasten: Festival-Fails“* (User-generated Storys)
*Twist:* Jede Doppelseite ist gleichzeitig ein *Shoppable Lookbook* (QR-Codes / Lidl Plus).

**2026-01-13T11:12:01.732689** - Julia:
> oh ja!

**2026-01-13T11:12:19.218009** - Julia:
> also ich glaub unter dem 90ies Thema bleiben ist schon mal sehr cool

**2026-01-13T11:12:27.430029** - Julia:
> voll

**2026-01-13T11:13:55.156789** - Julia:
> :smile:

**2026-01-13T11:13:57.926619** - Julia:
> geil lieb ich

**2026-01-13T11:14:06.491859** - Julia:
> ja okay mega, da haben wir doch schon eine Route

**2026-01-13T11:24:57.196639** - Julia:
> ich will Teil der Kampagne sein :rolling_on_the_floor_laughing:

**2026-01-13T12:42:27.443949** - Julia:
> 

**2026-01-13T13:08:04.680359** - Julia:
> ui okay :heart_eyes:

**2026-01-13T13:08:42.935429** - Julia:
> Das ist der Dips Content:
<https://drive.google.com/drive/u/0/folders/13OE-YrygC-y3BJ0j8_h7GG588kE9VKYj>

**2026-01-13T14:47:12.503729** - Julia:
> FYI. hab ich eben an Flo geschickt :slightly_smiling_face:

**2026-01-13T14:59:54.506079** - Julia:
> :joy:

**2026-01-13T15:00:05.770119** - Julia:
> dann wären wir schon mal zu 3. – perfekt!

**2026-01-13T15:01:17.644569** - Julia:
> stiiimmt

**2026-01-13T15:01:39.265769** - Julia:
> hahah

**2026-01-13T15:01:56.121809** - Julia:
> wenn Flo/LIDL die Kampagne nicht machen, pitchen wir sie an andere, das sag ich dir hahha

**2026-01-13T15:03:20.595329** - Julia:
> klaro

**2026-01-13T15:04:06.031269** - Julia:
> bin im meet

**2026-01-13T15:20:38.974329** - Julia:
> jaa?

**2026-01-13T15:20:43.297159** - Julia:
> okay, dann schau ich mir das später an

**2026-01-13T15:20:46.904719** - Julia:
> alles gut!

**2026-01-13T15:23:49.932749** - Julia:
> alles guuut

**2026-01-13T15:23:57.977819** - Julia:
> einige!

**2026-01-13T15:30:21.272039** - Julia:
> hier ist mir nur aufgefallen was wir gestern mit Laureen hatten: collab auf Tiktok?

**2026-01-13T15:36:10.944179** - Julia:
> ahh okay

**2026-01-13T15:52:18.270429** - Julia:
> Ich geh auch mal kurz raus. Mein Kopf raucht 

**2026-01-14T09:46:08.410199** - Julia:
> Hello :slightly_smiling_face: bin da

**2026-01-14T10:35:02.440569** - Julia:
> Hast du kurz zeit?

**2026-01-14T10:35:18.322709** - Julia:
> yees

**2026-01-14T10:41:57.798519** - Julia:
> komme!

**2026-01-14T12:24:12.137109** - Julia:
> JULIA

**2026-01-14T12:24:14.405449** - Julia:
> ich glaube es nicht

**2026-01-14T12:25:52.462689** - Julia:
> 

**2026-01-14T14:20:45.090639** - Julia:
> guck mal, das ist der Screenshot von Jana. Quasi wie und woher man welche Zahlen bekommt

**2026-01-14T15:04:29.620189** - Julia:
> ich liebs ja

**2026-01-14T16:50:52.696809** - Julia:
> okay moment

**2026-01-14T16:56:34.044739** - Julia:
> ne seh ich kein Problem

**2026-01-14T16:56:44.628669** - Julia:
> wir dürfen den content aber online lassen für ein jahr oder?

**2026-01-14T16:58:36.896879** - Julia:
> Ja schon und vorallem weil sie auch schreibt "komplikationen"

**2026-01-14T16:59:00.826329** - Julia:
> ich denke auch

**2026-01-14T16:59:18.307819** - Julia:
> also früher oder später wird sie uns die videos zukommen lassen, das glaub ich auf jeden fall :smile:

**2026-01-20T11:12:55.604679** - Julia:
> Also es wäre einmal <http://Fastmoss.com|Fastmoss.com> zu kündigen – da hattest du auch schon mal eine Mail hingeschickt.

Login ist hierrüber:
<mailto:clients@boldcreators.club|clients@boldcreators.club>
--&gt; Anmelden über Google und dann bekomme ich einen Code aufs Handy

**2026-01-20T12:03:16.144949** - Julia:
> yes!

**2026-01-20T12:03:28.500949** - Julia:
> danke dir!

**2026-01-20T12:11:02.901549** - Julia:
> okay moment, ichhab zugriff

**2026-01-20T12:11:14.076509** - Julia:
> uhh nice! ja :slightly_smiling_face:

**2026-01-20T12:11:25.329199** - Julia:
> vielen Dank:heart_eyes:

**2026-01-20T12:12:13.645089** - Julia:
> Das 2. wäre bei Sprout. Da hatte ich eine Anfrage gestellt und das wurde Flo als Mail geschickt (im November?) aber bisher keine Änderung

<https://sproutsocial.com/de>
Name/Mail: <mailto:porsche.deutschland@boldcreators.club|porsche.deutschland@boldcreators.club>
PW: vG.nZGi#E83a6jm

**2026-01-20T12:21:01.719999** - Julia:
> ja genau, das hatte ich auch. haben sie aber nicht

**2026-01-20T12:21:10.622379** - Julia:
> aber dann muss Flo das machen. das wird ja an seine mail geschickt ge?

**2026-01-20T12:21:22.631759** - Julia:
> ja, hatte ich ihm auch gesagt :smile:

**2026-01-20T12:21:25.408149** - Julia:
> gut, dankeee Julia

**2026-01-20T12:39:42.541979** - Julia:
> okay dankee!

**2026-01-20T12:41:25.734299** - Julia:
> Sehen wir es falsch oder wäre es nicht klar, dass wir einen ganzen Tag Ausgleich bekommen müssten?
Gestern von 7-23 Uhr unterwegs und heute von 10-23 uhr?

**2026-01-20T13:14:59.243839** - Julia:
> ja, doof einfach 

**2026-01-22T12:40:44.475189** - Julia:
> falls du was zur Aufmunterung willst, hab einen Rap für's SSIO Video geschrieben und mit AI vertont, packen wir ins Video :joy::joy:

**2026-01-27T14:55:42.125859** - Julia:
> 

**2026-01-27T15:05:50.784619** - Julia:
> okay, das ist gut

**2026-01-28T09:20:02.908219** - Julia:
> Es ist so deprimierend

**2026-01-28T09:31:28.990599** - Julia:
> ja oder? Also es kann doch nicht sein, dass das so ein riesiges Thema ist und uns so "stresst", also ich hab heute wirklich nur von der Arbeit geträumt

**2026-01-28T12:23:14.722519** - Julia:
> hat sich Flo bei dir gemeldet?

**2026-01-28T12:59:42.165209** - Julia:
> FINALLY

**2026-01-28T16:18:52.163949** - Julia:
> juhuuu

**2026-01-28T16:22:00.920839** - Julia:
> 

**2026-01-29T09:17:44.333729** - Julia:
> Neee

**2026-01-29T09:19:33.092699** - Julia:
> Also die sind wirklich nett, machen viele Späßchen und so. Problem ist nur, dass ich halt nicht viel sagen kann, weil ich Marvin's Themen nicht verstehe und ich auch ziemlich sicher bin, dass die das schon gecheckt haben. Ich hab ja von Anfang an gesagt "eher kreativ" als dieses analytische – weil Flo mich ja wieder ganz anders hinstellen wollte. Aber wenn die sofort merken, dass du jetzt bei dem Projekt ja voll den Durchblick hast und genau das dein Thema ist, dann sind die auch super froh und lassen einen machen.

**2026-01-29T09:19:36.972939** - Julia:
> Weißt wie ich meine? :slightly_smiling_face:

**2026-01-29T09:47:19.596079** - Julia:
> hab grad Zugang angefragt :slightly_smiling_face:

**2026-01-29T10:29:19.747249** - Julia:
> FYI: <https://docs.google.com/document/d/1fBRHzBk5TiKvimhN7A43kSC25LLpBsDyFcwDuP30R9A/edit?tab=t.0>

**2026-01-29T11:12:10.580739** - Julia:
> Hat sich Flo zu dem heimkinoraum vorfall geäußert?

**2026-01-29T11:14:23.139529** - Julia:
> :face_exhaling:

**2026-01-29T11:14:24.562559** - Julia:
> okay

**2026-01-29T11:25:05.318269** - Julia:
> 

**2026-01-29T11:26:46.792419** - Julia:
> ich weiß es nicht

**2026-01-29T11:27:43.159839** - Julia:
> 

**2026-01-29T11:27:43.783659** - Julia:
> NEIN

**2026-01-29T11:27:55.463889** - Julia:
> ja schau ma mal wielange sie "worked"

**2026-01-29T11:28:09.084899** - Julia:
> ja voll

**2026-01-29T11:28:39.633859** - Julia:
> also Girly (mit Wimpern), Fräsen (I LOVE SIXT) und Sticker overall (?) waren scheinbar freigegeben aber das weiß keiner so genau

**2026-01-29T11:29:07.958879** - Julia:
> total

**2026-01-29T11:36:19.653009** - Julia:
> ja vorallem soll ich den ja präsentieren?

**2026-01-29T11:36:24.500529** - Julia:
> das weiß sie aber noch nicht glaube ich

**2026-01-29T11:36:29.085069** - Julia:
> also alles vogelwild mal wieder

**2026-01-29T11:36:34.812049** - Julia:
> ich sag ja: Dramen über Dramen

**2026-01-29T11:38:10.866469** - Julia:
> denk ich mir :smile:

**2026-01-29T12:45:49.359279** - Julia:
> JA

**2026-01-29T12:45:54.217239** - Julia:
> hat mir grad geschrieben

**2026-01-29T12:45:55.360499** - Julia:
> UND?

**2026-01-29T12:46:11.947899** - Julia:
> hab ich 2 tage auf ihre Slides gewartet hab :smile: also sowas lieb ich ja

**2026-01-29T13:24:42.352599** - Julia:
> total

**2026-02-03T17:33:57.542009** - Julia:
> Hallo :slightly_smiling_face:

**2026-02-03T17:34:08.665949** - Julia:
> ah moment ich schreib in unseren Chat mit Marvin

**2026-02-11T14:21:45.750339** - Julia:
> :dotted_line_face:

**2026-02-11T14:21:47.439109** - Julia:
> haha

**2026-02-16T10:18:33.823379** - Julia:
> Hellooo!

**2026-02-16T10:18:38.925649** - Julia:
> Hast du evtl. nochmal kurz Zeit?

**2026-02-16T10:36:29.506169** - Julia:
> Jetzt bin ich unterwegs. Aber nach der Besichtigung evtl? :) 

**2026-02-16T12:23:11.448429** - Julia:
> war sehr cool! Hast du um 13 Uhr Zeit oder bist du da beim lunch? 

**2026-02-16T13:01:32.770509** - Julia:
> in huddle einfach?

**2026-02-16T16:25:16.054099** - Julia:
> kurze Frage nach zu Love is blind:

**2026-02-16T16:25:38.793649** - Julia:
> weißt du, ob die Agenturen schon an SIXT geschickt wurden oder was Marvin damit gemacht hat?

**2026-02-16T17:59:47.518779** - Julia:
> okeee. Also ich versteh nicht ganz wofür sie die Agenturen wollen, weil wir haben das ja intern schon ganz gut gelöst. Weißt du da mehr?
Sorry ich hab irgendwie gefühlt keine Infos :smile:

ABER ich hab kurz mit Ersin gesprochen und ihm auch die Clips gezeigt, er meinte für ihn ist das halt easy. Würde ihn jetzt auch mal mit aufnehmen? Marvin hatte ich schon mal erzählt, dass er das auch kann also why not?

**2026-02-16T18:29:08.125909** - Julia:
> Ja keine Ahnung :face_with_spiral_eyes: geht ja auch nicht anders, oder?


---

### #D09D0E0RP9B (1487 messages)

**2025-09-02T10:14:47.858929** - Julia:
> Hello :slightly_smiling_face:

**2025-09-02T16:38:57.942269** - Julia:
> du noch eine Frage

**2025-09-02T16:39:09.008499** - Julia:
> ist Chris auch dabei oder sind das fake news? :smile:

**2025-09-03T12:03:48.032489** - Julia:
> helloo :slightly_smiling_face: ich finds gerade nichtmehr: könntest du mir den Link zu den Fotos vom Gipfeltreffen letztes Jahr schicken? Das was wir gestern im Meeting gefunden haben

**2025-09-03T12:06:01.829509** - Julia:
> ah mist da hab ich doch noch keinen zugang

**2025-09-03T12:06:19.828729** - Julia:
> ah gefunden!

**2025-09-04T09:29:27.025989** - Julia:
> GuMo! :slightly_smiling_face: bin gleich ready. Nur kurz nochmal: diese Schriftgröße passt oder? 11pt

**2025-09-04T09:31:14.492419** - Julia:
> genau

**2025-09-04T09:31:18.553859** - Julia:
> Okay

**2025-09-04T09:31:21.009319** - Julia:
> Dankee :slightly_smiling_face:

**2025-09-04T09:33:10.586229** - Julia:
> und wir exportieren als png oder jpg?

**2025-09-04T09:49:27.584629** - Julia:
> okay schmeiß mich raus

**2025-09-04T10:14:32.761009** - Julia:
> du bist noch drin oder?

**2025-09-04T10:19:29.543719** - Julia:
> haha jaa gerne :smile:

**2025-09-04T10:19:41.624809** - Julia:
> ich hab Flo mal wegen Figma geschrieben – würde alles erleichtern im Still bereich

**2025-09-04T10:21:46.867399** - Julia:
> wie machst du das? im Call meinte Charly gerade sie würd den Text einfach runtersetzen --&gt; machen wir das?

**2025-09-04T10:24:19.372769** - Julia:
> ja okay, passt

**2025-09-04T10:24:21.089519** - Julia:
> danke :slightly_smiling_face:

**2025-09-04T11:22:08.686679** - Julia:
> Mert, könntest du mir einen Gefallen tun? Könntest du die Styleguide Keynote die ihr erstellt habt auf ppt zu exportieren oder "kurz" umzubauen?
Ich hab leider noch keinen Keynote Zugriff und die Porsche wills ja auch auf ppt haben

**2025-09-04T11:24:08.349289** - Julia:
> ich danke dir

**2025-09-04T11:28:17.854479** - Julia:
> dankeee

**2025-09-04T11:44:19.788919** - Julia:
> Hast du kurz 3 Minuten?

**2025-09-04T11:44:37.050519** - Julia:
> dann huddle ich dich schnell an

**2025-09-04T11:54:26.986069** - Julia:
> ja klar

**2025-09-04T12:16:03.069569** - Julia:
> irgendwie bin ich trotzdem in ps drin

**2025-09-04T16:31:45.645409** - Julia:
> haben wir irgendwo ein iphone mockup abgelegt?

**2025-09-04T16:37:32.427849** - Julia:
> ah okay

**2025-09-04T16:37:35.330149** - Julia:
> dankee

**2025-09-04T16:59:23.559489** - Julia:
> Nochmal kurz eine dringende Frage

**2025-09-04T16:59:37.379119** - Julia:
> Die HLs im Styleguide sind auch von der PAG übernommen?

**2025-09-04T17:00:14.622519** - Julia:
> ich hatte es nämlich so gemacht wie die PS Vorlage und online ging es dann anders

**2025-09-04T17:01:45.034829** - Julia:
> hab jetzt julia nochmal geschrieben

**2025-09-04T17:01:50.010339** - Julia:
> chaaaaos

**2025-09-04T17:03:05.909449** - Julia:
> ahh got it

**2025-09-04T17:03:24.173829** - Julia:
> das war dann quasi der sonderfall

**2025-09-04T17:04:27.982659** - Julia:
> :joy:

**2025-09-04T17:04:33.667579** - Julia:
> Oh je

**2025-09-04T17:05:35.564289** - Julia:
> lieben wir

**2025-09-05T11:39:24.357419** - Julia:
> ah jetzt wurde ich von PS abgemeldet :smile:

**2025-09-05T11:39:25.470109** - Julia:
> komisch

**2025-09-05T15:11:50.730349** - Julia:
> Cool danke!
1. Slide: Würde ich das Visual evtl noch größer machen?
2. Slide: Ort bei der Stecknadel hinzufügen
3. Vllt lieber: Highlights am 13.09.2025

**2025-09-05T15:12:32.759989** - Julia:
> Ja versteh was du meinst. Ich würde in dem Fall ehrlich eher dann auf das Design von der Agentur gehen als unsere CI, wenn es so nach nix aussieht.
Die hatten ja teilweise auch Orange benutzt oder?

**2025-09-05T15:14:01.102909** - Julia:
> Bei dem Foto Video Ding:
2x Nahaufnahmen Porsche
3x Event Porsche (letztes Jahr IAA?)
3x Fahrzeug Modelle --&gt; Taycan, Cayenne Electric Prototyp vllt sogar?
2x Menschen/ Emotionen

**2025-09-05T15:14:36.515369** - Julia:
> dann lass uns doch die HL auch Orange machen beim Programm

**2025-09-05T15:16:00.858469** - Julia:
> glaub ich dir

**2025-09-05T15:18:34.036689** - Julia:
> achsoo stimmt --&gt; München?

**2025-09-05T15:49:21.995619** - Julia:
> Mert kannst du mir dieses Visual schicken oder den Link zu den "Links" in Drive?

**2025-09-05T15:52:15.586439** - Julia:
> 

**2025-09-05T16:08:50.918139** - Julia:
> okay, mist

**2025-09-05T16:08:52.887929** - Julia:
> danke!

**2025-09-05T16:12:15.511519** - Julia:
> In dem was live haben sie die Tickets beworben. Also entweder das "Exklusive Tickets für unsere Community"
oder sowas wie "#PorscheFamily vereint" oder "Porsche live erleben"

**2025-09-05T16:44:35.102899** - Julia:
> Cool! :slightly_smiling_face: Könntest du noch eine Version machen mit Exklusive Tickets für unsere Community?

**2025-09-05T16:44:39.559659** - Julia:
> Dann können wir beides vorstellen

**2025-09-05T17:10:15.579659** - Julia:
> niiice

**2025-09-05T17:10:17.288469** - Julia:
> danke

**2025-09-05T17:10:22.219219** - Julia:
> find ich fast besser

**2025-09-05T17:10:24.351759** - Julia:
> du?

**2025-09-05T17:25:35.797089** - Julia:
> legst du alles in die präsi oder? :slightly_smiling_face:

**2025-09-08T09:33:44.945439** - Julia:
> Guten Morgen! :slightly_smiling_face:
Hier gabs schon Feedback: <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/doc2.aspx?sourcedoc=%7BE57B0967-DF14-4D65-A137-58646F317C64%7D&amp;file=250903_IAA_Hospitality_FD.pptx&amp;fromShare=true&amp;action=edit&amp;mobileredirect=true&amp;previoussessionid=77d20bb4-f210-877d-3c82-0f27d3e717a3&amp;wdOrigin=TEAMS-MAGLEV.p2p_ns.rwc&amp;wdExp=TEAMS-TREATMENT&amp;wdhostclicktime=1756982116144&amp;web=1|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/doc2.aspx?sourcedoc=%7BE57B0[…]wdExp=TEAMS-TREATMENT&amp;wdhostclicktime=1756982116144&amp;web=1>

**2025-09-08T10:57:58.060569** - Julia:
> yes, schau ich mir an

**2025-09-08T11:18:26.604069** - Julia:
> Slide 2: Welches Video meint sie denn, also ist das Visual das Richtige?
Text noch etwas kürzen:
_*Gemeinsam auf die IAA:*_
_*Mit 20 exklusiven Tickets wollen wir mit euch den "There is no substitute Day" am Samstag verbringen.*_ 
_*#PorscheFamily*_


*Video:* Würde ich noch 1 Bild vom Catering/ Drinks/ Feiern reinnehmen
*Slide 3:* 
*Exklusive Ticket Vorteile:* 
• Zutritt zur Porsche Standparty (+ Begleitungperson)
• kostenloses, ganztägiges Parkticket (Siemens Parkhaus)
• erhältlich über die My Porsche App


**2025-09-08T11:34:24.073929** - Julia:
> Magst du mir bescheid geben, wenn ich kurz in PS kann?

**2025-09-08T11:44:15.272759** - Julia:
> das war schlimm. aber wie ist es da, wenn dieses feedback kommt, setzen wir das dann auch immer 1x1 so um?

**2025-09-08T11:45:00.690029** - Julia:
> hast du bei Slide 2 einen dunklen Gradient rein? Hab das gefühl man kanns etwas schwer lesen

**2025-09-08T11:46:58.284809** - Julia:
> Okay

**2025-09-08T11:47:30.976819** - Julia:
> Und eins wo Menschen im Fokus sind &amp; die Fahrzeuge nur im Hintergrund oÄ?

**2025-09-08T11:47:47.346489** - Julia:
> glaube das ist zu Natur-lastig

**2025-09-08T11:52:04.248399** - Julia:
> ja!

**2025-09-08T11:54:06.627469** - Julia:
> true that. würde mal das mit den lachenden Menschen vorschlagen, da das noch mehr diesen Vibe hat "gemeinsam gute Zeit"

**2025-09-08T11:54:39.705609** - Julia:
> voll gut, danke!

**2025-09-08T11:54:53.639389** - Julia:
> bekommen gleich figma :partying_face:

**2025-09-08T12:02:55.078399** - Julia:
> Ah moment

**2025-09-08T12:03:06.511439** - Julia:
> Das war nochmal zum Feedback bei Porsche dachte ich aber idk

**2025-09-08T12:03:37.401729** - Julia:
> Auch heute heißt es: einsteigen, erleben, entdecken.
Eure Daily Highlights im Überblick:

"Nichts verpassen"-Sticker?
<https://porsche.click/IG_IAA2025>

**2025-09-08T12:05:02.486539** - Julia:
> Du Mert, Julia &amp; ich müssen gleich los. Ich würde dir noch eine Task in Asana geben. Wäre super, wenn du das erstellen kannst. Sobald ich dann wieder an den PC kann, kann ichs fertig stellen :slightly_smiling_face:

**2025-09-08T12:21:57.965219** - Julia:
> Beim Daily haben wir glaub ich alle aneinander vorbeigeredet :smile:

**2025-09-08T12:23:36.418069** - Julia:
> Also es soll quasi die Tagesprogramm Slide ersetzen, denn Porsche möchte es nicht so aufgelistet haben.
Eher in die Richtung die Julia schon in Asana gelegt hat
"1 Story Slide
HL: Porsche at IAA
SL: Programmhighlights &amp; Probefahrten
12-14.09.
- Bleib informiert
- Link: <https://porsche.click/IG_IAA2025>"

Also gerne Tagesprogramm Slide + Link Slide als 1 Slide

**2025-09-08T12:23:52.141249** - Julia:
> 

**2025-09-08T12:26:15.234989** - Julia:
> Weißt du was ich meine?

**2025-09-08T12:29:02.217429** - Julia:
> Okay danke :smile:

**2025-09-08T12:29:06.337649** - Julia:
> complicated

**2025-09-08T12:29:45.796699** - Julia:
> Müssen da noch einen Prozess finden, wo zentral die Infos dann auch wirklich alle abliegen

**2025-09-08T14:14:55.718309** - Julia:
> ja!

**2025-09-08T14:19:21.219309** - Julia:
> Bin bis 15Uhr da, falls du etwas brauchst

**2025-09-08T14:41:50.808229** - Julia:
> Soo guck mal, das daily müssten wir nochmal anpassen:
<https://www.figma.com/design/7P5fTRcISCX1xDyTeA0TCr/IAA-Content?node-id=0-1&amp;t=LCBxnA2S39ryRpkn-1>

**2025-09-08T14:42:01.159109** - Julia:
> Probier mal ob du Zugang hast? :slightly_smiling_face: Habs nur schnell gebastelt

**2025-09-08T14:56:51.642139** - Julia:
> gehen gerade die Story durch:
das und das letzte raus

**2025-09-08T15:00:00.689869** - Julia:
> Slide 2:
mit limitierten Tickets (keine Anzahl) wollen wir mit euch den
Porsche. There is no substitute. Day am Samstag verbringen.
#PorscheFamily


Slide4:
(inkl. Begleitperson)
Parkhaus raus

**2025-09-08T15:00:11.668299** - Julia:
> Die Bilder

**2025-09-08T17:13:38.901159** - Julia:
> Cool! Magst du mir hier kurz einen Screenshot schicken? :) 

**2025-09-08T17:14:13.729839** - Julia:
>  Ja aber war leider direkt Feedback von Hannah 

**2025-09-08T17:14:29.898619** - Julia:
> Juhuu

**2025-09-08T17:19:25.608769** - Julia:
> 2. slide müssten wir doch den Vorschlag von dir nehmen ohne Menschen mit orangenem Auto. Es lädt gerade nicht deshalb kann ich nicht kommentieren 

**2025-09-08T17:19:55.607069** - Julia:
> Daily bitte zu dem von figma anpassen, genau 

**2025-09-08T17:21:10.961169** - Julia:
> Wenn du sonst nichtmehr da bist, leg mir gern die verpackte indesign Datei ab :)

**2025-09-08T17:25:49.491819** - Julia:
> Okay danke. Sag einfach Bescheid 

**2025-09-08T17:26:03.005799** - Julia:
> Wir können sonst auch kurz telefonieren wenn du eine Frage hast 

**2025-09-08T17:26:08.716189** - Julia:
> <tel:015229018774|015229018774>

**2025-09-08T18:08:34.669689** - Julia:
> Ich hab das glaub ich noch nicht hochgeladen weil vorhin schnell schnell 

**2025-09-08T18:08:42.113899** - Julia:
> Aber so wie das Highlight 

**2025-09-08T18:09:12.425059** - Julia:
> Bezüglich Tins day story müssen wir textlich noch eine Sache hinzufügen, gerade Info bekommen. Legs mir gerne ab 

**2025-09-08T18:20:14.811759** - Julia:
>  Super. Auch nicht mit dem Zugang von Flo?

**2025-09-08T18:20:42.516449** - Julia:
> Aber egal erstmal. Hauptsache die offenen Dateien liegen ab

**2025-09-08T18:21:01.364609** - Julia:
> Ist noch nicht fix  

**2025-09-08T18:43:20.836999** - Julia:
> suuper danke

**2025-09-09T08:33:19.030609** - Julia:
> Guten morgen :slightly_smiling_face:

**2025-09-09T08:33:42.328089** - Julia:
> Sorry für dieses Hin &amp; Her gestern. Porsche stand halt neben uns und wollte live Design machen, puh

**2025-09-09T08:33:57.940159** - Julia:
> Wenn du dich mit dem Account von Flo in figma einloggst, geht es nicht?

**2025-09-09T10:00:53.250929** - Julia:
> perfekt

**2025-09-09T10:04:42.076739** - Julia:
> Ja keine Worte :smile:

**2025-09-09T10:04:55.581109** - Julia:
> Es kam dann die Frage woher jetzt eigentlich orange kommt? Was soll ich sagen hahaha

**2025-09-09T10:05:26.111679** - Julia:
> :joy:

**2025-09-09T10:05:27.363009** - Julia:
> same bro

**2025-09-09T10:30:48.891959** - Julia:
> Du eine Frage

**2025-09-09T10:31:09.056779** - Julia:
> wo finde ich eine Vorlage für diese IG Link Grafik?

**2025-09-09T10:31:40.045829** - Julia:
> Ahhh

**2025-09-09T10:31:41.186949** - Julia:
> smart

**2025-09-09T10:31:43.583749** - Julia:
> :slightly_smiling_face:

**2025-09-09T15:27:40.251159** - Julia:
> Hast du mein Asana Ticket gesehen? :slightly_smiling_face:

**2025-09-09T15:33:19.353239** - Julia:
> Okay, dann mach gerne erstmal das. Falls du irgendwie schneller durchkommst, sag gerne bescheid. Ist für morgen 11.30 Uhr geplant

**2025-09-09T15:40:31.118989** - Julia:
> Ne nur das was ich abgelegt hab

**2025-09-09T15:40:39.689769** - Julia:
> alles gut, vllt schaff ich es schon etwas anzufangen

**2025-09-09T18:00:25.843919** - Julia:
> Fraaaag mal. Yes, gestern bis 23

**2025-09-09T19:05:24.197229** - Julia:
> Sind noch in unserem Kabuff :smile:

**2025-09-10T10:44:49.286879** - Julia:
> GuMooo!

**2025-09-10T10:45:12.371639** - Julia:
> Ahh cool :slightly_smiling_face: hab gestern auch noch was angefangen, ich fügs mal hinzu

**2025-09-11T18:31:34.357539** - Julia:
> Hab dir eine Task rein, wäre mega, wenn du das direkt morgens anlegen kannst

**2025-09-12T10:18:39.938519** - Julia:
> Hello! :slightly_smiling_face:

**2025-09-12T10:20:39.420749** - Julia:
> Ich geb dir Bescheid sobald der Text final ist

**2025-09-12T11:23:50.618519** - Julia:
> uhh okay, moment

**2025-09-12T11:46:53.253579** - Julia:
> jaaaaa

**2025-09-12T11:46:55.296509** - Julia:
> danke danke danke

**2025-09-17T14:49:01.868909** - Julia:
> Meeert

**2025-09-17T14:49:06.158469** - Julia:
> ich bin schockiert

**2025-09-17T14:49:15.599539** - Julia:
> wie viel hast du schon mit Charly zusammen gearbeitet?

**2025-09-17T14:49:22.649099** - Julia:
> :fearful::joy:

**2025-09-17T14:52:48.502009** - Julia:
> Ne sie ist einfach, ich weiß garnicht wie ich das beschreiben soll

**2025-09-17T14:52:56.945639** - Julia:
> Dreh das Bild um 0,5°

**2025-09-17T14:53:39.665889** - Julia:
> "Ist das ein Leerzeichen zuviel?" - Nein, habs auch nochmal mit GPT gecheckt.
"warte ich checke nochmal"

...
passt!

Ah ne alles nochmal löschen: Das Bild ist zu angeschnitten

**2025-09-17T14:53:45.584179** - Julia:
> waaaaas

**2025-09-17T14:53:49.960259** - Julia:
> :face_with_peeking_eye:

**2025-09-17T14:54:39.783159** - Julia:
> das geht ja garnicht

**2025-09-17T14:54:59.595699** - Julia:
> Da muss ein Prozess her. Feedback gesammelt und ciao

**2025-09-17T14:58:04.550229** - Julia:
> kraaass wirklich

**2025-09-17T14:58:14.000829** - Julia:
> da reichen keine 4 iterationen

**2025-09-17T15:12:49.301699** - Julia:
> jetzt ist diese aufgabe nicht in asana mit der caption

**2025-09-17T15:12:58.312339** - Julia:
> kannst du mir da nochmal helfen?

**2025-09-17T15:19:47.496329** - Julia:
> Ah okay.
Aber ich dachte das von Flo mit dem Lieblingsstrecke oÄ

**2025-09-17T15:19:58.580409** - Julia:
> Hast du die Präsi für mich vom Grid? :slightly_smiling_face:

**2025-09-17T15:20:50.020459** - Julia:
> Nee, laut meiner Mails nicht :smile:

**2025-09-17T15:23:20.014329** - Julia:
> :smile: okay

**2025-09-17T15:23:42.310989** - Julia:
> Könnten wir die IG Highlights noch anpassen? Kannst mir auch gern die Datei schicken, dann mach ich das

**2025-09-17T15:24:57.595799** - Julia:
> :melting_face:

**2025-09-17T15:24:59.430319** - Julia:
> lieben wir

**2025-09-17T15:26:11.758679** - Julia:
> okay :smile:

**2025-09-17T15:26:12.791789** - Julia:
> dankee

**2025-09-17T16:15:53.072379** - Julia:
> sorry

**2025-09-17T16:15:57.132839** - Julia:
> hatte kurz IG Action

**2025-09-17T16:16:44.202509** - Julia:
> Ah verstehe. wo würdest du den namen hinpacken?

**2025-09-17T16:19:23.504249** - Julia:
> würde es unter das Datum

**2025-09-17T16:19:46.667829** - Julia:
> vllt "unter anderem mit ...."

**2025-09-17T16:22:31.928339** - Julia:
> u. a. eigentlich

**2025-09-17T16:23:00.156159** - Julia:
> dann könntest du probieren
u. a. mit
Matthias

**2025-09-17T16:23:11.471109** - Julia:
> Probiers gerne mal – aber finde es so auch schon stimmig

**2025-09-17T16:24:01.537699** - Julia:
> ne ih

**2025-09-17T16:24:02.044209** - Julia:
> :smile:

**2025-09-17T16:24:21.834589** - Julia:
> w/
wäre zu social für porsche oder?

**2025-09-17T16:36:43.387669** - Julia:
> wahrscheinlich

**2025-09-17T16:37:15.104389** - Julia:
> wooo ist es denn? :slightly_smiling_face:

**2025-09-18T09:27:49.531139** - Julia:
> all good, Dankee! Schau ich mir jetzt gleich an :) 

**2025-09-18T09:27:53.366769** - Julia:
> alles gut bei dir? 

**2025-09-18T09:34:26.463029** - Julia:
> Ja auch. Immer noch schockiert über diese Feedback Prozesse :joy: 

**2025-09-18T10:32:20.792759** - Julia:
> liebeeee die Idee

**2025-09-18T10:34:13.018559** - Julia:
> ja aber die Idee ist mega :heart:

**2025-09-18T11:39:46.306189** - Julia:
> moooment

**2025-09-18T11:40:54.496159** - Julia:
> ne, wenn nur das titelbild mit text

**2025-09-18T11:41:21.709099** - Julia:
> background info für dich: das Turbo Carousel von der IAA jetzt war unsere Initiative und ist der best best best performer

**2025-09-18T11:42:05.363049** - Julia:
> wir könnten also 2 versionen für das titelbild zeigen und sagen 1x ohne Text, 1x mit Text --&gt; mit Text wäre interessant um zu gucken, ob texte wirklich so einen großem Impact haben wie beim Turbo Carousel

**2025-09-18T11:42:47.285779** - Julia:
> Würde den Text dann visuell wie beim Carousel anlegen und vllt zweizeilig gehen
Rennlegende
911 GT3 R

**2025-09-18T11:44:31.598599** - Julia:
> genau!

**2025-09-18T11:44:42.904079** - Julia:
> Pack das gerne dann mit in die Asana Task oder Präsi :slightly_smiling_face:

**2025-09-18T12:17:26.362769** - Julia:
> Nee. Kannst du mir die Texte nochmal schicken? Dann kürze ich es :slightly_smiling_face:

Zum Titelbild: Die Typo so wie beim Carousel setzen, sah doof aus?
Würde gerne vermeiden, dass wir jetzt mit Text arbeiten im Feed und alles anders aussieht

**2025-09-18T12:20:17.014109** - Julia:
> canvaaaaa ahh

**2025-09-18T12:23:41.927989** - Julia:
> hab zugriff angefordert. weißt du wer das bekommt?

**2025-09-18T12:29:28.697199** - Julia:
> *Version "History":* 
*Seit 2006 über 100 Siege – und jetzt Kino-Star: der 911 GT3 R im Brad Pitt „F1“ Kinofilm.*

Version "Short":
Rennstrecke trifft Leinwand: Der 911 GT3 R.

Version "Legende":
Legende auf dem Asphalt, Star im F1-Film mit Brad Pitt: 911 GT3

*Version "Sieger":* 
*911 GT3 R – gebaut für Siege, gefeiert im Film: F1 mit Brad Pitt.*

**2025-09-18T12:29:37.369089** - Julia:
> hab meine Favoriten fett markiert – you decide

**2025-09-18T12:44:36.523249** - Julia:
> legst dus dann in die Präsi? :slightly_smiling_face:

**2025-09-18T12:48:26.451189** - Julia:
> 959 und taycan meinst du oder?

**2025-09-18T12:49:21.777759** - Julia:
> oder müssen alle Posts gemacht werden?

**2025-09-18T12:49:51.438839** - Julia:
> welche asana task ist das?

**2025-09-18T12:49:58.390349** - Julia:
> sorry so viele fragen, ich versteh so viel noch nicht :smile:

**2025-09-18T12:51:29.545759** - Julia:
> got it!

**2025-09-18T13:16:38.015149** - Julia:
> Hab Hanna geschrieben

**2025-09-18T13:17:42.466579** - Julia:
> bin dran

**2025-09-18T13:22:49.770769** - Julia:
> cool! Lass uns mal kurz abwarten bis zu den anderen 2, ob das alles dann passt

**2025-09-18T13:23:00.333259** - Julia:
> sonst war der turbo s einfach ein einzelgänger

**2025-09-18T13:26:46.058869** - Julia:
> 959:

_*Version Traumwagen:*_
_*Ob Rennstrecke oder Straße: Der 959 ist Kult, Ikone und Traumwagen zugleich.*_

Version Unicorn:
German Unicorn – so nennt Jerry Seinfeld den 959. Eine Ikone, die Rennsport und Traumwagen-Status vereint.

Version Details:
Rennsport-Performance mit Kultstatus: der 959. Mit 317 km/h einer der schnellsten Serienwagen der 80er und einer der begehrtesten Sammelstücke bis heute.

_*Version Wortwitz:*_
_*The Last Unicorn? Der 959. Einer der begehrtesten Sportwagen seiner Zeit – und bis heute eine lebende Legende.*_

**2025-09-18T13:31:52.116119** - Julia:
> Taycan:

Version Short:
Taqycan Turbo S: 911 DNA. Future Power.

Version Zukunft:
911-DNA trifft auf Elektropower: Der Taycan Turbo S bringt die Zukunft auf die Straße.

_*Version Feelings:*_
_*Zukunft fahren, Porsche fühlen: der Taycan Turbo S – Beschleunigung, die sich nach Zukunft anfühlt.*_

**2025-09-18T13:33:26.639249** - Julia:
> Würde beim Taycan tatsächlich nicht wieder Performance Pionier sagen. Was meinst du?
eher Innovationstreiber, Impulsgeber, Vorreiter..

**2025-09-18T13:36:48.455709** - Julia:
> Ja ich kanns leider nicht sehen.. so nervig

**2025-09-18T13:36:55.637049** - Julia:
> magst du mir screenshots schicken?

**2025-09-18T13:37:05.775089** - Julia:
> dann schau ich noch kurz, danach muss ich mit Coco raus :slightly_smiling_face:

**2025-09-18T13:40:05.946359** - Julia:
> Hmm ne da müssen wir gleich nochmal überlegen. würde max. 2 zeilig

**2025-09-18T13:41:28.770719** - Julia:
> ja genau, das meinte ich

**2025-09-18T13:41:40.610719** - Julia:
> hier :slightly_smiling_face: <@U093J779DAQ>

**2025-09-18T13:41:53.277359** - Julia:
> schau gerne mal was gut reinpasst. bis gleich! :slightly_smiling_face:

**2025-09-18T14:49:28.730729** - Julia:
> sehr cool!

**2025-09-18T14:49:30.765389** - Julia:
> Mag ich

**2025-09-18T14:51:43.301349** - Julia:
> Du eine Frage

**2025-09-18T14:51:50.546519** - Julia:
> wo sind denn noch mehr dieser Retro Bilder? <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/doc2.aspx?sourcedoc=%7BA5F304E8-09BC-47AB-A30A-5A86F7C81AD3%7D&amp;file=250904_Porsche_BS_RetroSunday.pptx&amp;action=edit&amp;mobileredirect=true|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/doc2.aspx?sourcedoc=%7BA5F30[…]rsche_BS_RetroSunday.pptx&amp;action=edit&amp;mobileredirect=true>

**2025-09-18T14:54:26.964659** - Julia:
> guck mal das hattest du gemacht oder?

**2025-09-18T14:55:47.531659** - Julia:
> schicks mir gerne, dann schreib ich ihr zurück

**2025-09-18T14:56:14.994939** - Julia:
> ach ne ich kann schauen :slightly_smiling_face: wo nochmal? :smile:

**2025-09-18T14:57:05.891809** - Julia:
> ahh okay perfekt!

**2025-09-18T14:57:10.570479** - Julia:
> juhuu

**2025-09-18T14:58:38.278119** - Julia:
> 

**2025-09-18T15:00:32.383679** - Julia:
> liegen da welche bei dir drin? bei mir ist alles leer

**2025-09-18T15:00:36.327799** - Julia:
> :face_exhaling: es nervt

**2025-09-18T15:01:16.798069** - Julia:
> ah habe keine berechtigung

**2025-09-18T15:01:53.365179** - Julia:
> ah okay, got it

**2025-09-18T15:01:56.828589** - Julia:
> wow :smile:

**2025-09-18T15:02:01.235529** - Julia:
> gut, dann mach ich neue

**2025-09-18T15:02:23.682629** - Julia:
> kannst du mir ein paar der fotos runterladen und schicken? sorry ey. irgendwie reagiert auch keiner auf die anfragen

**2025-09-18T15:02:35.667269** - Julia:
> okay got it!

**2025-09-18T15:02:48.676029** - Julia:
> dankeee für deine hilfe!

**2025-09-18T15:03:26.375309** - Julia:
> ach mist

**2025-09-18T15:03:34.820089** - Julia:
> oder kannst du mir den ordner runterladen und mit wetransfer schicken?

**2025-09-18T15:04:41.472169** - Julia:
> dankeee

**2025-09-18T15:06:30.138589** - Julia:
> okay got it

**2025-09-18T15:06:38.522239** - Julia:
> ich verarbeite mal Julia's Vorschläge und schau dann

**2025-09-18T15:07:01.978179** - Julia:
> Könntest du mir einen Gefallen tun? Bei "Asset link", könntest du da, dann die finalen Bilder ablegen?

**2025-09-18T15:10:49.721289** - Julia:
> ah okay

**2025-09-18T15:10:59.123519** - Julia:
> dachte da liegt dann immer das eine ab

**2025-09-18T15:20:50.369239** - Julia:
> weißt du wann die Turbo Woche ist?

**2025-09-18T15:33:17.522099** - Julia:
> schickst du das dann immer direkt an porsche oder macht das julia?

**2025-09-18T15:33:39.103669** - Julia:
> okay

**2025-09-18T16:09:44.739169** - Julia:
> so konnte endlich die Präsi öffnen und bin nochmal kurz durchgegangen. Gibts hier evtl noch ein anderes Bild? Finde dieses weiße Muster so aufdringlich :smile:

**2025-09-18T16:11:19.239019** - Julia:
> und hier: ist das 4. Bild stärker, oder?

**2025-09-18T16:22:05.117269** - Julia:
> das stimmt, aber da wir das beim turbo auch nicht hatten, finde ich es nicht schlimm

**2025-09-18T16:56:20.476279** - Julia:
> FYI: hatten gerade meeting mit porsche zum Gipfeltreffen. hatten 2 Anmerkungen zum Grid + Highlight --&gt; ich pass das schnell an, ja?

**2025-09-18T17:07:54.325919** - Julia:
> Amore Motore nicht so präsent links und lieber dort das Gipfeltreffen
Highlight: wollten hier Variante mit nur Schriftzug. Ohne Strecke im Hintergrund - also laaaangweilig

**2025-09-18T17:08:02.897529** - Julia:
> oh okay, schau ich mir gleich mal an :slightly_smiling_face:

**2025-09-18T17:08:24.393629** - Julia:
> ich weiß nur noch ausm stehgreif: dafür benötigt man ein plugin :smile:

**2025-09-18T17:25:11.980399** - Julia:
> diese Grid Datei macht mich richtig sauer :smile: wie konntest du da überhaupt drin arbeiten

**2025-09-18T17:30:33.686929** - Julia:
> ich brauch noch eine sekunde von dir

**2025-09-18T17:30:44.529069** - Julia:
> 

**2025-09-18T17:30:49.186199** - Julia:
> Ich kann ja nicht zugreifen

**2025-09-18T17:30:57.097939** - Julia:
> siehst du ob da noch was liegt

**2025-09-18T17:33:10.120339** - Julia:
> 

**2025-09-18T17:33:13.664419** - Julia:
> mehr hab ich nicht. ich schau gerade bei drive

**2025-09-18T17:33:22.920379** - Julia:
> walter und malmedie - gt3 talk

**2025-09-18T17:34:00.128919** - Julia:
> stories sind online

**2025-09-18T17:34:09.734479** - Julia:
> vllt kannst du es so zu ordnen?

**2025-09-18T17:35:04.072069** - Julia:
> geil!

**2025-09-18T17:35:28.842559** - Julia:
> jaa

**2025-09-18T17:35:30.365979** - Julia:
> perfekt

**2025-09-18T17:35:53.057119** - Julia:
> Brand Store nicht aber glaub das kann Julia jetzt machen. Sie konnte nur nicht auf den Drive zugreifen

**2025-09-18T17:36:20.509939** - Julia:
> habs ihr geschickt

**2025-09-18T17:36:22.096209** - Julia:
> DANKE :smile:

**2025-09-18T17:36:58.465389** - Julia:
> im sharepoint finden wir es nicht oder? bzw in einer präsi

**2025-09-18T17:37:24.613759** - Julia:
> okay :smile: super

**2025-09-18T17:38:28.884099** - Julia:
> happy feierabend!

**2025-09-19T09:41:12.354239** - Julia:
> Guten Morgen! :slightly_smiling_face:

**2025-09-19T09:41:55.062829** - Julia:
> Meinst du, du schaffst es mir die Styleguide Visualisierung fertig zu machen? Das wäre super, weil wir es vorm Gipfeltreffen nochmal an Porsche schicken müssen

**2025-09-19T09:50:33.467329** - Julia:
> juhuuuu

**2025-09-19T10:30:58.486929** - Julia:
> 

**2025-09-19T10:43:47.804389** - Julia:
> ja das stimmt. wäre mMn nicht schlimm, wenn das etwas verdeckt ist weil es ja nur ein detail ist

**2025-09-19T10:44:04.379739** - Julia:
> Vllt beommst du irgendwie unter stay tuned noch das auto?

**2025-09-19T10:51:49.380279** - Julia:
> würde den text noch etwas hochziehen. dann steht "stay tuned" sogar auf der straße, dann perfekt

**2025-09-19T10:57:00.598529** - Julia:
> ich mags!

**2025-09-19T11:26:51.071829** - Julia:
> oh manno

**2025-09-19T11:26:57.132929** - Julia:
> okay :face_with_peeking_eye: danke!

**2025-09-19T12:17:58.793579** - Julia:
> ja seh ich auch so

**2025-09-19T12:18:15.685239** - Julia:
> könntest du mir einen gefallen tun? magst du einmal einen Screenshot reinlegen, von den letzten reels der IAA?

**2025-09-19T12:18:41.895529** - Julia:
> Würde gerne kontrollieren, ob das passt. hatte nämlich das gefühl, dass hier einfach irgendwie reingesetzt wurde

**2025-09-19T12:22:30.219419** - Julia:
> puh, vbws passen ja garnicht :smile:

**2025-09-19T12:24:08.839249** - Julia:
> okay

**2025-09-19T12:24:18.707519** - Julia:
> Magst du dir das mal anschauen?

**2025-09-19T12:24:41.729539** - Julia:
> Das Thema ist wir sollten das fürs Gipfeltreffen jetzt einheitlich machen bzw. der Produktion liefern können

**2025-09-19T12:24:54.559239** - Julia:
> dafür benötigen die halt dann auch die richtigen Premiere Angaben

**2025-09-19T12:26:12.141389** - Julia:
> <https://drive.google.com/drive/folders/1Uqfsv2dzOxUL2lpnQUGXIqSmga7tscPP>

mit gestrigem Datum. schaus dir gerne mal an, weil dann müssten wir natürlich die screenshots alle nochmal austauschen für die premiere spezifikationen

**2025-09-19T12:33:03.945429** - Julia:
> puuh, okay got it

**2025-09-19T12:34:02.942569** - Julia:
> okay das ist echt smart von dir. danke, dass du es gecheckt hast!

**2025-09-19T12:34:40.313069** - Julia:
> also eigentlich bedeutet es die videos sind am ende länger als unsere vorlage, right?

**2025-09-19T12:38:36.794939** - Julia:
> 

**2025-09-19T12:43:06.608339** - Julia:
> :joy:

**2025-09-19T12:43:11.800299** - Julia:
> ich verstehs so

**2025-09-19T12:50:24.961979** - Julia:
> du meinst wegen caption usw.?

**2025-09-19T12:50:44.349249** - Julia:
> perfekt

**2025-09-19T12:56:00.413559** - Julia:
> ahh perfekt 

**2025-09-19T12:56:21.879999** - Julia:
> Ja stimmt 

**2025-09-19T12:56:44.595879** - Julia:
> weil praktisch wäre es wenn es von Instagram direkt so eine Vorlage gäbe 

**2025-09-19T12:57:43.731559** - Julia:
> :joy:  

**2025-09-19T12:57:47.763509** - Julia:
> auf jeden Fall 

**2025-09-19T13:00:43.794209** - Julia:
> okay also setzt du dann die neuen screenshots ein?

**2025-09-19T13:01:59.227929** - Julia:
> ja alles gut, sag einfach bescheid

**2025-09-19T13:02:24.658209** - Julia:
> bzw. ich kanns auch einsetzen, ich bräuchte nur von dir dann die ganzen premiere screenshots

**2025-09-19T13:39:30.049709** - Julia:
> hier <@U093J779DAQ>

**2025-09-19T13:41:43.580409** - Julia:
> oh gott das nervt so

**2025-09-19T13:41:52.125319** - Julia:
> ja magst du das machen und dann wieder hochladen?

**2025-09-19T13:42:07.391549** - Julia:
> ich check dann nochmal alles

**2025-09-19T14:08:53.431939** - Julia:
> omg

**2025-09-19T14:08:55.034549** - Julia:
> moment

**2025-09-19T14:12:40.377209** - Julia:
> ich weiß nicht warum aber das dauert gerade 300 jahre

**2025-09-19T14:13:50.163059** - Julia:
> liegt jetzt sonst mt heutigem datum auch nochmal ab: <https://drive.google.com/drive/folders/1Uqfsv2dzOxUL2lpnQUGXIqSmga7tscPP>

**2025-09-19T14:15:03.094769** - Julia:
> 

**2025-09-19T14:19:07.599149** - Julia:
> klappts?

**2025-09-19T14:30:04.337069** - Julia:
> ja klar, bitte mach das

**2025-09-19T15:15:38.236119** - Julia:
> du bist ein Schatz!!

**2025-09-19T15:15:48.452989** - Julia:
> WOW, danke!

**2025-09-19T15:17:21.312609** - Julia:
> :heart:

**2025-09-22T15:49:50.601379** - Julia:
> Helloo

**2025-09-22T15:50:05.959439** - Julia:
> Kommst du heute zum Dinner/ Drinks? :slightly_smiling_face:

**2025-09-22T15:51:23.834859** - Julia:
> juhuu

**2025-09-22T15:51:25.063059** - Julia:
> Ja

**2025-09-22T15:51:29.363309** - Julia:
> bin schon im Büro

**2025-09-22T15:51:56.172839** - Julia:
> Fast

**2025-09-22T15:52:00.866249** - Julia:
> Magst auch schon vorbeikommen?

**2025-09-22T15:54:18.888799** - Julia:
> Ja kein Stress

**2025-09-22T15:54:30.497459** - Julia:
> Warte ab, ich hab paar Sachen für dich :smile:

**2025-09-22T15:54:43.827919** - Julia:
> wir haben um 16.30 - 17.30 noch einen Termin

**2025-09-22T15:54:45.634789** - Julia:
> Ja eben

**2025-09-22T15:55:19.821069** - Julia:
> Denke der wird nicht bis 17.30 gehen, weil eh alle krank sind

**2025-09-22T15:59:21.069129** - Julia:
> juhuu oke

**2025-09-22T15:59:27.851199** - Julia:
> hab auch schon hunger hahaha

**2025-09-22T16:34:54.166359** - Julia:
> Mert, ich bräuchte morgen etwas von deiner Zeit. Hast du gerade Kapa?

**2025-09-22T16:38:28.728569** - Julia:
> Ja perfekt

**2025-09-22T16:38:30.294389** - Julia:
> jaa total!

**2025-09-22T16:38:38.905879** - Julia:
> Hab ich auch als nächstes auf dem Zettel stehen :slightly_smiling_face:

**2025-09-22T17:08:46.667829** - Julia:
> diese Kommentare hast du schon gesehen oder?
<https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BC17F1481-2ED8-47B7-857B-E389345FD62C%7D&amp;file=2025-07-25%20Wallpaper%20Fortsetzung%20nach%20It%60s%20911%20o%20clock.pptx&amp;action=edit&amp;mobileredirect=true|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BC17F14[…]0s%20911%20o%20clock.pptx&amp;action=edit&amp;mobileredirect=true>

**2025-09-22T17:21:42.589129** - Julia:
> Julia ist noch nicht da..

**2025-09-22T17:21:47.886859** - Julia:
> die wurde dauernd aufgehalten

**2025-09-22T17:21:51.758169** - Julia:
> sitzen aber leider noch im call

**2025-09-23T09:19:52.516209** - Julia:
> Hey, guten Morgen! Mich hats heute nacht mit Migräne erwischt :face_with_peeking_eye: ich bin immer noch nicht fit und hab soo starke Kopfschmerzen, deswegen werde ich die Calls ausfallen lassen müssen. Ich schau, dass ich später wieder fit bin.
Aber falls du sonst schon mal Zeit hast &amp; es für dich ohne eine Erklärung auch schon sinn ergibt:

Die Präsentation die ich dir angehängt hab, haben wir Hanna vorgestellt. Ideen für neue Postings und Posting Reihen, wie zB dieser Store Rundgang. Sie wollte jetzt natürlich, dass wir alles einmal checken bezüglich Content und auch schon was umsetzen. In dem Fall wäre der Store Rundgang aber wichtigsten. Ich würde mir hier für den Start der Reihe immer eine kleine eine Art Animation wünschen, bei der man den "Grundriss" vom Store als Illustration sieht und man mit einer Stecknadel/ Markierung erkennt, wo man sich befindet (Ich sag nur Karte des Rumtreibers von Harry Potter, falls du das kennst :smile:). Also die Markierung darf sich gerne zum Zielort bewegen. Dazu bräuchten wir natürlich Material von Hanna, evtl. könnte Julia das schon mal anfragen..

**2025-09-23T12:39:46.026799** - Julia:
> danke dir :heart:

**2025-09-23T12:41:23.520769** - Julia:
> Ja genau. Man müsste echt schauen was man davon jetzt schon umsetzen kann. Also zB diese Konfigurationsthemen oder die Turbo/ Targa Posts mit Splitscreens..

**2025-09-25T13:39:05.919029** - Julia:
> 

**2025-09-25T13:39:51.817769** - Julia:
> <https://www.figma.com/design/JrbypsbvDwTvRRgwvqhdvd/Porsche-BS-%F0%9F%9B%8D%EF%B8%8F?node-id=0-1&amp;p=f&amp;t=tYh4gyFkz2fsD73m-0>

**2025-09-25T13:39:58.956729** - Julia:
> <https://www.figma.com/design/902cDjeQLIyg77xt49VdZg/Porsche-DE-%F0%9F%8F%8E%EF%B8%8F?node-id=1-247&amp;t=AuTFbNdgZZuujMA3-0>

**2025-09-25T15:11:40.237379** - Julia:
> figma soweit klar? :slightly_smiling_face:

**2025-09-25T15:27:30.622999** - Julia:
> man kennts

**2025-09-25T15:43:17.280379** - Julia:
> Würde ich schon machen. Wir können uns dann überlegen, ob wir bei so Single posts das dann eher als "Lückenfüller" oder so benennen

**2025-09-25T15:46:08.477229** - Julia:
> genau

**2025-09-26T09:39:45.616999** - Julia:
> dankeee

**2025-09-26T09:39:55.909419** - Julia:
> ein traaaaaaum

**2025-09-26T09:42:17.539279** - Julia:
> 

**2025-09-26T09:43:54.037649** - Julia:
> <https://app.asana.com/1/1199360402832734/task/1210556034500746/comment/1211467593411918?focus=true>

**2025-09-26T09:48:28.915419** - Julia:
> Ja gute Frage. Kannst du einen Ordner anlegen im sharepoint? Ich kanns ja nicht sehen

**2025-09-26T09:50:00.264529** - Julia:
> ja verstehe. an sich ist es evtl auch erstmal egal, hauptsache sie sehen es :smile:

**2025-09-26T10:05:31.466259** - Julia:
> danke dir :heart:

**2025-09-26T10:24:33.848009** - Julia:
> Ja gerne. Bin schon mit Flo im Call

**2025-09-26T10:45:44.467999** - Julia:
> brauchen noch 5 min

**2025-09-26T11:23:01.762699** - Julia:
> liebs :smile:

**2025-09-26T11:34:33.972949** - Julia:
> <mailto:florian.listl@boldcreatorsclub.com|florian.listl@boldcreatorsclub.com>
vG.nZGi#E83a6jm

**2025-09-26T11:38:26.943009** - Julia:
> kommst du wieder rein? :smile:

**2025-09-26T11:50:14.216869** - Julia:
> haha okay wow

**2025-09-26T11:50:17.272579** - Julia:
> Mach das :slightly_smiling_face:

**2025-09-26T13:04:44.519529** - Julia:
> <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BD3204CB4-6946-46A9-896D-D1E414A316B4%7D&amp;file=250925_UGC_Vorschla%25u0308ge_Master.pptx&amp;action=edit&amp;mobileredirect=true|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BD3204C[…]hla%25u0308ge_Master.pptx&amp;action=edit&amp;mobileredirect=true>

**2025-09-26T13:16:39.179269** - Julia:
> uiuiui, obs viel ist?

**2025-09-26T13:58:46.331309** - Julia:
> hast du zugriff auf den Link in der mail?

**2025-09-26T14:03:00.478679** - Julia:
> :joy:

**2025-09-26T14:06:25.938809** - Julia:
> ja

**2025-09-26T14:06:51.717769** - Julia:
> würdest du Hanna das kurz schreiben? Ich hab ja eh wieder keinen Zugriff :smile:

**2025-09-26T14:48:12.147699** - Julia:
> Bei den BS stories hab ich gedacht, wäre es auch sinnvoll mit "driven by dreams" anzufangen

**2025-09-26T14:48:41.990579** - Julia:
> dann könnten wir evtl. den "Rundgang/ Grundriss" noch nach hinten ziehen

**2025-09-26T14:48:48.113559** - Julia:
> liegt in figma :slightly_smiling_face:

**2025-09-26T14:57:45.742019** - Julia:
> weekly rundgang

**2025-09-26T14:57:48.660909** - Julia:
> bin noch nicht fertig

**2025-09-26T15:33:03.029739** - Julia:
> hast du hierauf zugriff?
<https://porsche.sharepoint.com/sites/PDMK/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FPDMK%2FShared%20Documents%2FGeneral%2FUMZUG%2FKampagnen%2F%5FVKR%20MY%2025%2FTINS%2FAlte%20Anzeigen%2Fvon%20Museum&amp;viewid=6340b967%2Dd3d5%2D401d%2D9687%2D73af93fd1ecf&amp;csf=1&amp;web=1&amp;e=gUeQ59&amp;ovuser=56564e0f%2D83d3%2D4b52%2D92e8%2Da6bb9ea36564%2Cjulia%2Ehallhuber%40boldcreatorsclub%2Ecom&amp;OR=Teams%2DHL&amp;CT=1756120940332&amp;clickparams=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiI1MC8yNTA3MzExNzQxMCIsIkhhc0ZlZGVyYXRlZFVzZXIiOmZhbHNlfQ%3D%3D&amp;CID=3d32bfa1%2D60a3%2Dd000%2De737%2Daa92c95b626b&amp;cidOR=SPO&amp;FolderCTID=0x012000B0A40330D7B2464BB054061397BEF042|https://porsche.sharepoint.com/sites/PDMK/Shared%20Documents/Forms/AllItems.aspx?id=%2Fs[…]R=SPO&amp;FolderCTID=0x012000B0A40330D7B2464BB054061397BEF042>

**2025-09-26T15:34:06.692709** - Julia:
> jaa

**2025-09-26T15:34:09.762699** - Julia:
> habs eben gefunden :smile:

**2025-09-26T15:35:11.109529** - Julia:
> da ist das nämlich mehr oder weniger das TINS plakat drin hehe

**2025-09-26T15:41:08.258839** - Julia:
> liebe ich!

**2025-09-26T15:41:16.640889** - Julia:
> VBWs?

**2025-09-26T15:48:25.590489** - Julia:
> okay

**2025-09-26T15:48:31.862669** - Julia:
> ja, ich erkenn sowieso nichts deswegen :smile:

**2025-09-26T15:53:07.714469** - Julia:
> ich hab Flo vor 2 Stunden gefragt, ob wir hanna die BS Posts dann schon mal schicken sollen – keine Antwort

**2025-09-26T16:06:21.106109** - Julia:
> meinst du, du sdchaffst heute noch was mit Colour? ich frag nur, sonst würde ich warten bis ich Hanna das schicke

**2025-09-26T16:09:05.631269** - Julia:
> Neee

**2025-09-26T16:09:19.616039** - Julia:
> einfach so, dass wir es schon mal präsentieren können

**2025-09-26T16:24:15.814979** - Julia:
> 

**2025-09-26T17:11:17.734549** - Julia:
> find ich super!

**2025-09-26T17:11:26.367459** - Julia:
> ich ziehs mal hoch "zu approval"

**2025-09-26T17:11:40.458419** - Julia:
> Müsste noch anmerken: Feedpost wäre dann die Auflösung

**2025-09-26T17:13:46.009789** - Julia:
> wie meinst du?

**2025-09-26T17:13:49.033879** - Julia:
> ah moment!

**2025-09-26T17:14:02.435509** - Julia:
> jaa das kenn ich haha

**2025-09-26T17:15:31.797749** - Julia:
> 

**2025-09-26T17:17:53.835689** - Julia:
> jaa das ist super mit dem Video!

**2025-09-26T17:18:05.695279** - Julia:
> Hab Slide 19 erstellt. So meintest du, oder?

**2025-09-26T17:19:45.652629** - Julia:
> habs noch ergänzt haha

**2025-09-26T17:19:51.930829** - Julia:
> gerneeee

**2025-09-26T17:26:57.348109** - Julia:
> ahhh got it

**2025-09-26T17:26:58.657689** - Julia:
> nice!

**2025-09-26T17:27:09.597639** - Julia:
> ist das alles in diesem Konfigurator erstellt?

**2025-09-26T17:27:50.517419** - Julia:
> mega

**2025-09-26T17:27:56.529649** - Julia:
> hab noch das mit der farbe ergänzt

**2025-09-26T17:28:03.393689** - Julia:
> wäre smart das zu verbinden

**2025-09-26T17:29:12.084939** - Julia:
> voll!

**2025-09-26T17:29:14.176049** - Julia:
> mega gut

**2025-09-26T17:29:15.430659** - Julia:
> dankeeee

**2025-09-26T17:29:49.642919** - Julia:
> jaa :heart:

**2025-09-26T17:29:55.389369** - Julia:
> ich schicks jetzt gleich mal ab

**2025-09-26T17:35:04.025919** - Julia:
> jaaa please! happy weekend :slightly_smiling_face: Vielleicht sieht man sich ja auf der wiesn? haha

**2025-09-29T10:09:02.774819** - Julia:
> ich bin drin :slightly_smiling_face:

**2025-09-29T10:09:49.968249** - Julia:
> glaube BS wird hier nicht besprochen

**2025-09-29T10:44:23.466029** - Julia:
> sie hat in die präsi reingeschrieben :slightly_smiling_face:

**2025-09-29T10:55:57.300259** - Julia:
> feedback geben, kann auch nicht jeder :smile:

**2025-09-29T12:08:06.444779** - Julia:
> weißt du was sie meint mit "bleiben wir doch erstmal..."?

**2025-09-29T12:11:07.442759** - Julia:
> 

**2025-09-29T12:23:21.209509** - Julia:
> ja das ist das zitat von ihm aber halt zusammen gefasst

**2025-09-29T12:23:25.018449** - Julia:
> ja :smile:

**2025-09-29T12:26:32.286959** - Julia:
> hmm okay okay

**2025-09-29T12:26:57.775139** - Julia:
> ja sie kann erst ab 14uhr telefonieren, deswegen würde ich es gerne vorher fertig machen. sonst schaff ich wieder garnichts :smile:

**2025-09-29T12:27:06.736569** - Julia:
> aber ja kann sein, danke dir!

**2025-09-29T14:41:45.017569** - Julia:
> Nee

**2025-09-29T14:53:04.944249** - Julia:
> 

**2025-09-29T16:22:38.407519** - Julia:
> <https://www.porsche-brandstore.de/events>

**2025-09-29T16:23:20.585929** - Julia:
> looos gehts

**2025-09-29T16:26:33.947729** - Julia:
> okay sollte alles online sein

**2025-09-29T16:28:56.045019** - Julia:
> okay mom

**2025-09-29T16:30:55.129819** - Julia:
> okay done

**2025-09-29T16:31:04.923349** - Julia:
> Opening Hours hab ich jetzt bei Beratung..?

**2025-09-29T16:32:19.211909** - Julia:
> okee

**2025-09-29T16:36:06.852789** - Julia:
> oh nein

**2025-09-29T16:36:17.454909** - Julia:
> kannst dus in unseren drive hochladen?

**2025-09-29T16:49:05.470989** - Julia:
> sehr cool!

**2025-09-29T16:49:25.873209** - Julia:
> Man könnte sowas wie "Perspektivenwechsel" oder so als Caption nehmen

**2025-09-29T16:56:14.075069** - Julia:
> jaa!

**2025-09-29T16:56:16.204289** - Julia:
> find ich gut

**2025-09-29T16:57:54.757949** - Julia:
> ich finds super

**2025-09-29T16:58:03.101479** - Julia:
> lass uns denen mal paar coolere sachen vorschlagen

**2025-09-29T16:58:06.777539** - Julia:
> die sind so trocken :smile:

**2025-09-29T16:58:23.286519** - Julia:
> dafür sind wir ja eigentlich da

**2025-09-29T17:10:35.362169** - Julia:
> jetzt bräuchte ich auch nochmal deine hilfe bitte

**2025-09-29T17:11:32.448549** - Julia:
> 

**2025-09-29T17:11:34.771529** - Julia:
> 

**2025-09-29T17:12:57.623399** - Julia:
> 

**2025-09-29T17:17:22.048069** - Julia:
> dann eher für den turbo :slightly_smiling_face:

**2025-09-29T17:30:25.234519** - Julia:
> ach süß, danke dir. das problem ist, bei vielen hab ich auch zugriff aber es kommt halt IMMER das

**2025-09-29T17:30:43.365029** - Julia:
> Ich glaube es liegt einfach an meinem account wegen Julia Schmid. Aber Flo meint nein :smile:

**2025-09-29T17:34:30.925939** - Julia:
> aber ich kann auch keinen Zugriff anfodern

**2025-09-29T17:35:23.927099** - Julia:
> ne aber hier hab ich angefordert :smile:

**2025-09-29T17:35:32.380119** - Julia:
> Okay sorry aber könntest du sonst die fonts anpassen?

**2025-09-29T17:35:45.538159** - Julia:
> ja ist so. ich schreib Marie nochmal

**2025-09-29T17:38:09.085189** - Julia:
> fml

**2025-09-29T17:38:14.042489** - Julia:
> gut dann ohne porsche font :smile:

**2025-09-29T17:38:15.856919** - Julia:
> hahaha

**2025-09-29T17:38:49.596309** - Julia:
> ja ich würde eh ein pdf draus machen

**2025-09-29T17:38:50.494779** - Julia:
> moment

**2025-09-29T17:39:43.220609** - Julia:
> das stmmt

**2025-09-29T17:47:19.384219** - Julia:
> okay verstehe

**2025-09-29T17:47:33.289909** - Julia:
> das dauert für jetzt zu lange oder? also ein YT video zu nehmen?

**2025-09-29T17:47:45.812459** - Julia:
> bzw. ist für Turbo dann irrelevant oder?

**2025-09-29T17:49:02.786019** - Julia:
> i dont know

**2025-09-29T17:53:40.703059** - Julia:
> ja wahrscheinlich unnötig in dem fall

**2025-09-29T17:56:37.081479** - Julia:
> ja dann lassen wir es

**2025-09-29T17:57:08.442929** - Julia:
> okay! dann nehmen wir es doch da auf

**2025-09-29T17:57:16.597509** - Julia:
> könnten es ja bald mal zeigen, wenn Zeit ist

**2025-09-29T18:01:28.687159** - Julia:
> ahhh wie cool! ich wollte eben noch fragen, ob du unterschreibst oder wie der Stand ist? JUHUUUUU

**2025-09-29T18:01:50.676589** - Julia:
> also ich bin nicht im Büro – ich hab einfach immernoch halsweh :smile:

**2025-09-29T18:01:52.730629** - Julia:
> ja versteh ich

**2025-09-29T18:15:39.756649** - Julia:
> ich geh jetzt mal off. Mach später noch die BS Slides für Hanna – irgendwas passt ihr mit dem Wording nicht :melting_face:
Wir hören uns morgen :slightly_smiling_face::heart:

**2025-09-30T09:17:20.281279** - Julia:
> Hallooo, ich brauch deine kreative Hilfe :smile: hast du eine Idee, was wir hier im Feed machen könnten..?
Die "Driven by Dreams" Geschichte mit Bildern von Ferry Porsche...? auch nicht cool

**2025-09-30T09:21:30.181769** - Julia:
> Juhuuuu wie gut

**2025-09-30T09:21:35.875719** - Julia:
> Glückwunsch! :fast_parrot:

**2025-09-30T09:30:17.058669** - Julia:
> hast du dann auch schon einen Laptop bekommen?

**2025-09-30T09:47:54.103189** - Julia:
> oke

**2025-09-30T10:04:51.089659** - Julia:
> sorry, hatte mit flo geschrieben

**2025-09-30T10:04:57.157879** - Julia:
> bin jetzt im porsche call

**2025-09-30T10:05:16.257999** - Julia:
> gerne danach kurz?

**2025-09-30T10:33:02.215559** - Julia:
> ja..

**2025-09-30T10:37:18.124449** - Julia:
> geben gleich bescheid

**2025-09-30T10:46:51.382289** - Julia:
> okay können in den call

**2025-09-30T11:07:28.564059** - Julia:
> ich glaub du kannst raus

**2025-09-30T12:40:49.281899** - Julia:
> 4-5

**2025-09-30T13:23:07.375909** - Julia:
> sorry ich bin so im tunnel gerade mit dem leonie thema

**2025-09-30T13:23:11.633499** - Julia:
> :nauseated_face:

**2025-09-30T13:41:52.456609** - Julia:
> okay okay :face_with_peeking_eye: lieben wir

**2025-09-30T13:41:53.700809** - Julia:
> Mach das!

**2025-09-30T16:25:41.429939** - Julia:
> uh nice

**2025-09-30T16:25:48.450959** - Julia:
> ganz oben!

**2025-09-30T16:26:11.189349** - Julia:
> :fast_parrot:

**2025-09-30T16:27:47.435989** - Julia:
> ach super

**2025-09-30T16:27:55.536799** - Julia:
> okay, ich hab BS noch nicht geschafft :sob:

**2025-09-30T16:28:16.149509** - Julia:
> du kannst aber auch gerne einen kommentar reinschreiben und später, wenn alles ready ist schicke ich es hanna nochmal

**2025-09-30T16:29:47.620409** - Julia:
> ja sehr sehr gerne

**2025-09-30T17:33:48.021369** - Julia:
> uhh ich schau mal

**2025-09-30T17:34:36.220389** - Julia:
> mag ich sehr!

**2025-10-01T10:57:42.598639** - Julia:
> hello! :slightly_smiling_face: hattest du bei dem BS Rundgang schon das mit dem Grundriss gemacht?

**2025-10-01T11:25:27.364769** - Julia:
> 

**2025-10-01T11:27:49.929659** - Julia:
> BS Feedback:
• Story Highlight: Fächer bitte austauschen: <https://www.picdrop.com/roserbrothers/UcybkS1Ehk?file=9df8e108ed16e0be65f37b5f7c0a5cf6>
Müssen wir wahrscheinlich croppen und bissl bearbeiten wegen diesem Look
• Story Highlight: da haben sie und Denise nicht verstanden, dass es diese Sticker sein sollen --&gt; hier bitte neues Visual überlegen, was man für #PorscheFamily nutzen kann
• Weekly Highlights: den Instagram Sticker vom Link in komplett schwarz (das ist blau mit drin) :smile: 

**2025-10-01T11:27:53.225169** - Julia:
> daaanke dir

**2025-10-01T14:18:24.819799** - Julia:
> 

**2025-10-01T14:39:56.587519** - Julia:
> 

**2025-10-01T15:42:51.199219** - Julia:
> Mert, kannst du mir den BS Link nochmal sdchicken? :smile:

**2025-10-01T15:44:48.023049** - Julia:
> :heart:

**2025-10-02T11:45:19.673649** - Julia:
> Ja können wir

**2025-10-02T17:10:55.359569** - Julia:
> Hast du schon was zum Zeigen? :slightly_smiling_face:

**2025-10-02T17:12:04.067439** - Julia:
> Okay verstehe

**2025-10-02T17:12:19.389719** - Julia:
> Also ich hab auch eine Idee im Kopf. ich scribble es einfach mal runter

**2025-10-02T17:14:50.419229** - Julia:
> okay wooow

**2025-10-02T17:15:08.373959** - Julia:
> da hast du aber sehr detailliert dran gefeilt!

**2025-10-02T17:16:17.389039** - Julia:
> 

**2025-10-02T17:18:57.270579** - Julia:
> 

**2025-10-02T17:19:22.099299** - Julia:
> sollten wir einfach direkt so nehmen :smile:

**2025-10-02T17:20:01.451879** - Julia:
> das nimmt sie so oder so

**2025-10-02T17:21:47.460309** - Julia:
> 

**2025-10-02T17:22:10.134239** - Julia:
> <https://drive.google.com/drive/folders/1SDKZJ6GBvTHM4sPRqWM29IHnzdCaKxZD>

**2025-10-02T17:23:31.562309** - Julia:
> dankeee :heart:

**2025-10-02T17:23:39.038079** - Julia:
> ja ist auch einfach so, irgendwann reicht es

**2025-10-02T17:23:46.362229** - Julia:
> die haben mir heute echt den rest gegeben

**2025-10-02T17:24:24.796449** - Julia:
> danke dir und schon mal happy WEEEE! :slightly_smiling_face:

**2025-10-06T17:12:32.747939** - Julia:
> <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/EZ7TLT66epNKhkXArtJqiLUBlTp7hkTKor54-WuvJrIDVQ?e=RcfswU>

**2025-10-06T18:37:56.808719** - Julia:
> ich mach die restlichen Präsi Sachen morgen weiter

**2025-10-06T18:38:22.461359** - Julia:
> falls du morgens dann noch Zeit hast: vllt ein Story Highlight für TINS visualisieren wäre mega :heart_eyes:

**2025-10-06T18:38:29.125659** - Julia:
> Hab einen schönen Feierabend!

**2025-10-07T09:33:21.412779** - Julia:
> :face_with_spiral_eyes:

**2025-10-07T09:42:40.394479** - Julia:
> so unfair

**2025-10-07T10:33:52.921639** - Julia:
> kommst du auch? oder brauchst du noch? :slightly_smiling_face:

**2025-10-07T11:41:54.531729** - Julia:
> hmmm

**2025-10-07T11:42:39.032269** - Julia:
> 

**2025-10-07T11:42:51.408269** - Julia:
> es bekommt quasi nur ein neues Styling

**2025-10-07T11:43:22.949799** - Julia:
> advent drive :heart_hands:
Aber glaube das braucht es garnicht

wir haben übrigens 26 :slightly_smiling_face: wegen 26 buchstaben

**2025-10-07T11:46:35.615539** - Julia:
> was denkst du dazu?

**2025-10-07T11:55:46.708489** - Julia:
> damit machen wir es uns leichter

**2025-10-07T11:57:21.325109** - Julia:
> ja das 2. oder 3.!

**2025-10-07T11:57:51.853169** - Julia:
> man kann ja drunter dann schreiben als Text "Advents ABC"

**2025-10-07T13:33:07.747679** - Julia:
> Die 3. find ich gut. hashtag ist mir national glaub ich 

**2025-10-07T13:40:01.492429** - Julia:
> Fühl ich sehr 

**2025-10-07T13:40:08.956049** - Julia:
> Weil man so denkt, hat eh keinen Sinn 

**2025-10-09T11:52:47.106069** - Julia:
> 

**2025-10-09T11:54:47.576399** - Julia:
> Nee 11.11. tatsächlich

**2025-10-09T11:54:55.416289** - Julia:
> da ist ja quasi der startschuss

**2025-10-09T14:03:01.957719** - Julia:
> alles gut, kein stress. wenns dir eh nicht gut geht

**2025-10-09T15:40:41.041489** - Julia:
> magst du mir das reel sonst über slack schicken? :slightly_smiling_face:

**2025-10-09T15:48:57.164839** - Julia:
> ja alles gut, kenn ich

**2025-10-09T15:53:28.132149** - Julia:
> gibts irgendeinen trick die untertitel rauszubekommen? kann premiere das mit ai oder so?

**2025-10-09T15:55:38.321299** - Julia:
> naja, es wirkt schon sehr abgeschnitten und random, ich schau mal vllt fliegts bei 4x5 ja raus :sunglasses:

**2025-10-09T16:22:50.734149** - Julia:
> nur damit ich es weiß, machst du heute noch die PP? Dann würde ich dir die captions in figma legen. Kanns ja nicht in die Präsi packen :smiling_face_with_tear:

**2025-10-09T16:22:57.139699** - Julia:
> sonst morgen :slightly_smiling_face:

**2025-10-09T16:25:19.629509** - Julia:
> okay. dann leg ich dir die captions noch rein – kannst dus dann in die präsi (weißt du wo?) legen? Dann kann ich charly kurz schreiben liegt auf den seiten xy

**2025-10-09T16:27:38.921329** - Julia:
> okay

**2025-10-10T09:11:11.172689** - Julia:
> Helloo!

**2025-10-10T09:11:13.735219** - Julia:
> Wie gehts dir heute?

**2025-10-10T09:12:38.304339** - Julia:
> jaa? also nicht schlimmer geworden?

**2025-10-10T09:12:39.717489** - Julia:
> alles okay

**2025-10-10T09:18:54.240079** - Julia:
> okay guut

**2025-10-10T09:19:05.161769** - Julia:
> ey der Content vom Event gestern kam an..

**2025-10-10T09:20:10.704069** - Julia:
> jaa perfekt. sag gerne dann wenn du ready bist, ich schicke es Charly trotzdem rüber. Wäre super, wenn du dann die Captions einsetzen kann

**2025-10-10T09:21:34.768439** - Julia:
> genau, das mach ich dann

**2025-10-10T09:29:54.818539** - Julia:
> <https://www.picdrop.com/nicolasbaerphotographie/2HKCbTvDUg>

Das Reel kann schon mal garnichts, Briefing war kompeltt anders. Aber kann mir auch vorstellen, dass Hanna vor Ort einiges umgeschmissen hat

Fotos teilweise okayish.
Video hab ich noch nicht angeschaut

**2025-10-10T09:32:33.983529** - Julia:
> 

**2025-10-10T09:38:27.770839** - Julia:
> nicht wirklich

**2025-10-10T09:44:26.566779** - Julia:
> das wäre sooo wichtig gewesen:

**2025-10-10T09:44:27.616869** - Julia:
> <https://www.picdrop.com/nicolasbaerphotographie/VYQ8h76w7R?file=430f63200b5499dede1819a661df2a22>

**2025-10-10T09:47:24.401629** - Julia:
> ja ich versteh auch nicht warum das nie so eingebrieft wurde

**2025-10-10T09:47:44.642509** - Julia:
> also Julia meinte noch evlt. kann basti hin und den content shooten – Flo hatte scheinbar keine Äußerung dazu

**2025-10-10T09:48:06.729519** - Julia:
> jaa ist so

**2025-10-10T09:48:09.892399** - Julia:
> 100%

**2025-10-10T09:49:21.956219** - Julia:
> nene

**2025-10-10T09:49:41.429529** - Julia:
> das sind eigentlich nur stills geplant als details – aber vllt ergänzen wir mit videos

**2025-10-10T09:50:28.987679** - Julia:
> genau

**2025-10-10T09:50:55.582279** - Julia:
> ach manno echt, hoffe Hanna ist wenigstens mit den Stills schon mal happy. Hab ihr jetzt die orangenen geschickt

**2025-10-10T09:51:22.648889** - Julia:
> Aber das wird spannend mit dem 5120 Reel – glaube der Fotograf hats einfach nicht verstanden was das ist

**2025-10-10T09:58:39.200259** - Julia:
> ich auuuch

**2025-10-10T09:58:46.532539** - Julia:
> bin echt etwas geschockt :face_with_spiral_eyes:

**2025-10-10T09:59:19.852729** - Julia:
> 

**2025-10-10T10:00:34.058789** - Julia:
> Ne das war Hanna

**2025-10-10T10:00:34.914959** - Julia:
> Sorry

**2025-10-10T10:14:40.942399** - Julia:
> ja

**2025-10-10T10:14:55.323849** - Julia:
> manchmal versteh ich den geschmack nicht :smile:

**2025-10-10T10:24:40.837289** - Julia:
> Also Hanna hat mir gerade geschrieben: wie findest du die Fotos?

**2025-10-10T10:24:42.439609** - Julia:
> Na super

**2025-10-10T10:38:04.443359** - Julia:
> :melting_face:

**2025-10-10T10:39:36.884259** - Julia:
> ich geh kurz mit Coco raus – der Fotograf ghosted mich eh

**2025-10-10T10:39:54.045119** - Julia:
> ich hatte dir noch eine kleine task in Asana gelegt

**2025-10-10T11:20:50.628869** - Julia:
> ja dann lass uns gerne nur einmal Freiheit &amp; einmal Freiheitsgefühl nehmen

**2025-10-10T11:22:25.446319** - Julia:
> mach gerne :slightly_smiling_face:

**2025-10-10T11:22:29.406379** - Julia:
> Adrenalin?

**2025-10-10T11:22:38.727999** - Julia:
> Muss jetzt Flo anrufen

**2025-10-10T11:22:57.368049** - Julia:
> ja "was heute ansteht" hä

**2025-10-10T11:24:52.784559** - Julia:
> also wenn du mit PP etc. fertig bist, brauch ich denk ich auf jeden fall deine unterstützung mit dem event content – hanna findet alles grottig

**2025-10-10T11:35:18.905469** - Julia:
> 

**2025-10-10T11:36:34.670839** - Julia:
> ich hab jetzt schon 3mal geantwortet aber es erscheint nicht??

**2025-10-10T11:39:05.381999** - Julia:
> 

**2025-10-10T11:43:09.668209** - Julia:
> Stimmt. "Eure Antworten"? Oder was hast du da sonst dazu geschrieben?

**2025-10-10T11:50:10.308139** - Julia:
> ja gerne

**2025-10-10T11:52:51.281589** - Julia:
> oh hatten wir das beim letzten mal nicht einfach so untereinander? ich glaub das wollten sie so oder?

**2025-10-10T11:55:51.829629** - Julia:
> die nerven mich

**2025-10-10T11:55:53.473509** - Julia:
> :smile:

**2025-10-10T11:56:01.095229** - Julia:
> dann schicken wir ihnen doch beide varianten einfach

**2025-10-10T11:56:03.674899** - Julia:
> danke dir

**2025-10-10T12:00:55.466529** - Julia:
> danke dir

**2025-10-10T12:01:26.295619** - Julia:
> sollen wir kurz in den huddle? :slightly_smiling_face:

**2025-10-10T12:02:57.139599** - Julia:
> 

**2025-10-10T12:24:03.041339** - Julia:
> :face_with_spiral_eyes:

**2025-10-10T12:24:05.578769** - Julia:
> es ist so wild

**2025-10-10T12:27:51.370399** - Julia:
> ja

**2025-10-10T12:27:53.739339** - Julia:
> unbedingt

**2025-10-10T12:35:18.265219** - Julia:
> hab grad mit ihm telefoniert

**2025-10-10T12:35:23.445929** - Julia:
> er hat meine mail scheinbar nicht bekommen

**2025-10-10T12:35:25.160169** - Julia:
> AHJA

**2025-10-10T12:56:51.748159** - Julia:
> <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/doc2.aspx?sourcedoc=%7BE33428F9-BF0F-4720-B9FE-D8EDF165E52E%7D&amp;file=250924_Porsche_BS_SoMe_Konzepte_JH.pptx&amp;action=edit&amp;mobileredirect=true&amp;previoussessionid=3b2c90dc-2d08-64b7-17f6-e0d24a3f8d04|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/doc2.aspx?sourcedoc=%7BE3342[…]ue&amp;previoussessionid=3b2c90dc-2d08-64b7-17f6-e0d24a3f8d04>

**2025-10-10T12:57:10.238629** - Julia:
> ich leg hier jetzt die stills rein, magst du die video snippets – wenn es welche gibt, dazu packen? also 2 reichen pro fahrzeug

**2025-10-10T13:26:47.635199** - Julia:
> so eine scheiße echt

**2025-10-10T13:28:02.803489** - Julia:
> aber ist okay!

**2025-10-10T13:28:09.441479** - Julia:
> dankee

**2025-10-10T13:28:14.105069** - Julia:
> magst dus reinlegen?

**2025-10-10T13:29:25.972369** - Julia:
> ja!

**2025-10-10T13:33:22.787779** - Julia:
> kühler nicht einfach bearbeitet

**2025-10-10T13:33:28.105339** - Julia:
> das liegt auch etwas am screenshot

**2025-10-10T13:35:55.569299** - Julia:
> cool!

**2025-10-10T13:36:03.833849** - Julia:
> für den 2. hast dus noch nicht oder?

**2025-10-10T13:36:07.390489** - Julia:
> für den orangenen

**2025-10-10T13:37:41.751129** - Julia:
> 

**2025-10-10T13:45:25.739259** - Julia:
> nope

**2025-10-10T13:45:40.899519** - Julia:
> aber da meinte hanna schon das traut sie sich nicht weil das mit dem dach kompliziert st

**2025-10-10T14:01:53.477989** - Julia:
> okay

**2025-10-10T14:02:28.477049** - Julia:
> ich hasse diese online präsis

**2025-10-10T14:03:44.576269** - Julia:
> ich finds garnicht schlecht

**2025-10-10T14:03:49.106629** - Julia:
> ne ich habs schon online

**2025-10-10T14:03:52.778289** - Julia:
> ich antworte da gleich

**2025-10-10T14:05:52.264799** - Julia:
> omg

**2025-10-10T14:06:00.614469** - Julia:
> ja ich weiß

**2025-10-10T14:08:50.841839** - Julia:
> ich glaube ich bekomme heute noch einen herzinfarkt

**2025-10-10T14:10:52.721369** - Julia:
> Ne ich komm garnicht mit ihr klar

**2025-10-10T14:11:12.331459** - Julia:
> eine der schlimmsten Personen die ich je kennengelernt hab

**2025-10-10T14:11:23.349019** - Julia:
> vollkommen

**2025-10-10T14:11:32.734639** - Julia:
> ne

**2025-10-10T14:21:04.680219** - Julia:
> bitte die Frage so anpassen wie sie im Fragesticker auch gestellt wurde. Also „_Ihr wisst, was Fahren und Schwimmen gemeinsam haben. Hier sind eure Antworten:_“

**2025-10-10T14:21:15.984889** - Julia:
> es. ist. so. lächerlich.

**2025-10-10T14:22:24.628259** - Julia:
> ne

**2025-10-10T14:24:12.985609** - Julia:
> 100%

**2025-10-10T14:24:32.046659** - Julia:
> und vorallem das Hauptproblem ist ja, dass es keinen unterschied macht, ob da Wasser, schwimmen, fahren oder Straße steht

**2025-10-10T14:24:36.819079** - Julia:
> Straße klingt lockerer, cooler

**2025-10-10T14:24:38.164839** - Julia:
> Aber nein

**2025-10-10T14:26:10.331019** - Julia:
> ne ich auch nicht :smile:

**2025-10-10T14:26:16.765939** - Julia:
> vorallem ES WURDE FREIGEGEBEN

**2025-10-10T14:29:44.921029** - Julia:
> Danke, ist hiermit freigegeben und kann veröffentlicht werden.
Bitte danach dann die beiden Story Reposts von Leonie.

**2025-10-10T14:29:45.400319** - Julia:
> ja

**2025-10-10T14:29:53.755509** - Julia:
> und da denk ich mir auch: glaubst du ich bin dumm? :smile: ich habs verstanden

**2025-10-10T14:30:40.448229** - Julia:
> ich quch

**2025-10-10T14:30:43.322949** - Julia:
> auch

**2025-10-10T14:30:54.437299** - Julia:
> und der Nicolas übertreibt es gerade echt

**2025-10-10T14:32:19.931589** - Julia:
> ja mach das :slightly_smiling_face:

**2025-10-10T14:32:22.068639** - Julia:
> Ja nichts

**2025-10-10T14:32:38.045759** - Julia:
> 

**2025-10-10T14:45:42.340669** - Julia:
> okay ich hab Hanna alles geschickt was in der Präsi abliegt – ich muss jetzt auch kurz was essen.
Wielange bist du denn heute da eigentlich?

**2025-10-10T14:47:11.517069** - Julia:
> okay, ja ich auch.
Also ich würde noch die Stories gerne fertig machen die ich abgelegt hab und am Montag müsste man dann das Carousel machen.
Je nachdem was noch ansteht bei dir, könnten wir da noch zusammen dran arbeiten?

**2025-10-10T14:58:20.374659** - Julia:
> 

**2025-10-10T15:23:13.782929** - Julia:
> bin wieder da

**2025-10-10T15:25:08.235589** - Julia:
> 

**2025-10-10T15:53:20.354019** - Julia:
> bei PP?

**2025-10-10T15:53:26.481789** - Julia:
> ja

**2025-10-10T16:12:48.582569** - Julia:
> hanna liebt deine video snippets

**2025-10-10T16:13:02.075469** - Julia:
> warte ich schau auch mal rein, liegt in figma oder?

**2025-10-10T16:14:24.886629** - Julia:
> moment

**2025-10-10T16:14:28.807429** - Julia:
> mein laptop ist so langsam

**2025-10-10T16:14:42.502109** - Julia:
> halllooo LOB?! <@U093J779DAQ> :smile: von porsche, das muss man feiern

**2025-10-10T16:15:46.303569** - Julia:
> wollen wir kurz in den huddle?

**2025-10-10T16:16:30.387629** - Julia:
> 

**2025-10-10T16:17:09.561619** - Julia:
> bin gleich da

**2025-10-10T16:54:28.473999** - Julia:
> captions sind fertig :slightly_smiling_face:

**2025-10-10T16:57:34.419779** - Julia:
> dankeee

**2025-10-10T17:00:03.347939** - Julia:
> ja das weiß ich nicht

**2025-10-10T17:01:05.744509** - Julia:
> ich auch

**2025-10-10T17:01:22.067449** - Julia:
> Ansonsten kurz neue Präsi erstellen mit den 3 PP?

**2025-10-10T17:04:24.980129** - Julia:
> danke!

**2025-10-10T17:04:34.645769** - Julia:
> bin grad am Pooooosten – mehr oder weniger

**2025-10-10T17:24:19.609819** - Julia:
> gut, dass du es gesehen hast :smile:
hab bei den Dolomiten einen kleinen Fehler gefunden in der caption – hier nochmal richtig:

**2025-10-10T17:24:41.418669** - Julia:
> Caption Dolomiten:

Willkommen zurück zu #PorschePoints – in Teil 2 unserer Routen des diesjährigen Porsche Gipfeltreffens nehmen wir euch mit in die majestätischen Dolomiten.

Hier treffen endlose Serpentinen auf steil aufragende Felswände, Nebelschwaden ziehen über die Pässe und jeder Kilometer fühlt sich wie ein Postkartenmotiv an – die Dolomiten sind Bühne und Abenteuer zugleich.

Und das Beste: Die nächste Route wartet schon in den Startlöchern. Was glaubt ihr – wohin geht die Reise?

Habt ihr auch Lust bekommen auf eine eigene Ausfahrt? Dann folgt dieser Route in der ROADS by Porsche App. Mehr Infos dazu findet ihr in den Stories.

-
911 GT3 (WLTP): Kraftstoffverbrauch kombiniert: 13,8 – 13,7 l/100 km; CO₂-Emissionen kombiniert: 312 – 310 g/km; CO₂-Klasse: G; Stand 10/2025

**2025-10-10T17:30:24.853519** - Julia:
> ja

**2025-10-10T17:30:29.213099** - Julia:
> wenigstens sieht man den schnee :smile:

**2025-10-10T17:31:06.515599** - Julia:
> genau und reihenfolge ist:
• gardasee
• dolomiten
• sölden 

**2025-10-10T17:32:23.556559** - Julia:
> yaaay. ich lads runter

**2025-10-10T17:33:11.390779** - Julia:
> ich passe das titelbild und titel an

**2025-10-10T17:37:08.434539** - Julia:
> Mach das!

**2025-10-10T17:37:14.236759** - Julia:
> dankeee dir und happy weekend – so verdient

**2025-10-13T16:14:50.450529** - Julia:
> des war nur ein vorschlag, weil sie doch eigentlich dieses tunnelbild nicht so mochten aber kannst es auch gerne so lassen

**2025-10-13T16:20:42.072929** - Julia:
> ja

**2025-10-13T16:20:49.528569** - Julia:
> :melting_face:

**2025-10-14T10:39:34.272209** - Julia:
> ey ich sags dir

**2025-10-14T10:39:45.827119** - Julia:
> charly am morgen bereitet mir wirklich kummer und sorgen :smile:

**2025-10-14T10:39:49.660349** - Julia:
> ich bin so froh, wenn das vorbei ist

**2025-10-14T10:42:24.159879** - Julia:
> wir gehen gerade UGC durch und sie wurde LAUT, "WEIL WIR BEI DER HUNDE KATEGORIE ODER GENERELL NICHT DAS HUNDE BILD VERARBEITET HABEN AUS SYLT – DAS HATTE SIE JETZT MEHR ALS 5 MAL GESAGT...."
2 Sekunden später: "...aber kann ja auch sein, dass es sich vom Motiv nicht anbietet"

**2025-10-14T10:44:03.867049** - Julia:
> komplett

**2025-10-14T10:45:52.162839** - Julia:
> sind da

**2025-10-15T10:36:11.051049** - Julia:
> hello

**2025-10-15T10:36:20.407609** - Julia:
> hat dir Flo immernoch nicht geantwortet?

**2025-10-15T10:36:28.268059** - Julia:
> ich schreib ihm jetzt, ich finde das sooo frech

**2025-10-15T10:46:15.125749** - Julia:
> kein kommentar

**2025-10-15T11:15:47.769479** - Julia:
> so hab ihm jetzt geschrieben

**2025-10-15T11:15:56.359049** - Julia:
> *Juli*  [11:15 AM]
Hey, ich wollte jetzt nochmal nachfragen, ob es denn generell schon ein Update von Porsche gibt? Du meintest ja letzte Woche bis spätestens Mitte dieser Woche sollte es eine Info geben oder du meldest dich bei uns.
Mert, Julia und ich hängen schon echt sehr in der Luft und selbst, wenn es kein Update gibt weil ihr noch in den Verhandlungen seid, wäre es schon fair zu erfahren, "dass es kein Update gibt".  Porsche hat schon paar mal Andeutungen gemacht, dass es wohl nur noch bis Ende Oktober geht bezüglich Prios etc., das ist natürlich dann schon ein komisches Gefühl, wenn wir das von dir aber noch nicht erfahren haben. Und generell müssten wir uns ja dann auch in 2 Wochen nach einem neuen Job umsehen oder auch nicht..? Hast du hier eine Info für uns? Danke dir

**2025-10-15T13:10:14.999599** - Julia:
> wow

**2025-10-15T13:10:22.836139** - Julia:
> also Flo hat mir jetzt um 3 ein Meeting eingestellt

**2025-10-15T13:59:51.645699** - Julia:
> klar 

**2025-10-15T16:06:16.692079** - Julia:
> Ja find ich super

**2025-10-15T16:06:25.786559** - Julia:
> dankeee

**2025-10-15T16:29:25.629459** - Julia:
> ich schicke dir eine Sprachi

**2025-10-15T16:29:34.100669** - Julia:
> Aber gottseidank eyyyy

**2025-10-15T16:39:29.189499** - Julia:
> die Luganoblau Story ist noch nicht geupdated, oder? Weil ich grad mit Hanna schreibe und nicht, dass ich falsche Infos rausgebe

**2025-10-15T17:12:31.459089** - Julia:
> oder umdrehen? :slightly_smiling_face:
also LUGANOBLAU als HL und dann "Subline" quasi: Eure Wahl...

**2025-10-15T17:15:59.090499** - Julia:
> ja genau

**2025-10-15T17:16:05.581659** - Julia:
> dann ist es präsenter

**2025-10-16T16:37:18.464209** - Julia:
> hallo :slightly_smiling_face:

**2025-10-16T16:37:23.248789** - Julia:
> hast du jetzt was von flo gehört?

**2025-10-16T16:37:40.781459** - Julia:
> ach komm

**2025-10-16T16:37:44.064189** - Julia:
> das glaub ich nicht

**2025-10-16T16:38:27.465159** - Julia:
> das ist doch ganz komisch

**2025-10-16T16:38:39.223779** - Julia:
> ja mach das

**2025-10-16T16:39:01.090069** - Julia:
> weil wenn es jetzt echt vorbei wäre mit 2 wochen kündigungsfrist, dann müsste er ja heute oder morgen was sagen?!

**2025-10-16T16:41:01.388989** - Julia:
> also glaub ich eh nicht, weil dann bräuchtest du ja keinen Urlaub

**2025-10-16T16:41:06.218279** - Julia:
> das ist doch so wild alles

**2025-10-16T16:43:26.247109** - Julia:
> ja denke aber das wird dann auch der fall sein, weil er ja dann wieder voll in den themen drin ist. ich weiß ja nicht wie es am anfang war, aber ich denke er hatte einfach keine lust mehr auf die konfrontation mit porsche

**2025-10-16T16:43:27.746509** - Julia:
> ja total

**2025-10-16T17:20:53.273979** - Julia:
> ich geh jetzt auch mal offline. dann hören wir uns morgen :slightly_smiling_face: schönen abend!

**2025-10-16T17:22:36.542719** - Julia:
> anklingeln über huddle

**2025-10-16T17:22:41.506159** - Julia:
> dreistigkeit siegt

**2025-10-17T09:52:32.737789** - Julia:
> von hanna

**2025-10-17T10:07:36.232849** - Julia:
> :smile:

**2025-10-17T10:07:41.807359** - Julia:
> wo sind denn die kommentare?

**2025-10-17T10:07:47.026219** - Julia:
> Kannst du die Präsi doch öffnen?

**2025-10-17T10:10:25.999519** - Julia:
> asoo

**2025-10-17T10:10:31.861829** - Julia:
> ja ich kanns nicht öffnen

**2025-10-17T10:10:37.363039** - Julia:
> weil sie es scheinbar verschoben hat

**2025-10-17T10:10:40.455109** - Julia:
> kannst dus mir schicken?

**2025-10-17T10:10:45.797389** - Julia:
> das war ja das was ich gestern meinte haha

**2025-10-17T10:12:00.263449** - Julia:
> ah okay

**2025-10-17T10:12:05.794179** - Julia:
> aber die Texte sind teilweise unten angepasst

**2025-10-17T10:12:14.944509** - Julia:
> deswegen bräuchte ich bitte einmal alles :face_with_peeking_eye:

**2025-10-17T10:15:39.401969** - Julia:
> danke

**2025-10-17T10:15:46.913909** - Julia:
> es ist SO nervig

**2025-10-17T10:16:05.028439** - Julia:
> da müssen wir echt nochmal alles durchgucken, weil sie ja sogar die HLs angepasst haben will, die liebste Charly

**2025-10-17T10:16:58.213599** - Julia:
> ja

**2025-10-17T10:20:08.154529** - Julia:
> siehst du ob Hanna da Zugriff hat oder die Präsi geöffnet hat?

**2025-10-17T10:20:37.439359** - Julia:
> Weil wenn ja, wäre es ja perfekt we n du einfach das reel mit UT dort ablegst und sie kann es direkt dort approved 

**2025-10-17T10:24:50.531869** - Julia:
> Na wunderbar 

**2025-10-17T10:25:01.549059** - Julia:
> danke :smile:

**2025-10-17T10:25:37.813199** - Julia:
> Soll ich einfach das Halloween Assets nehmen, dass du uns geschickt hast. 
Oder möchtest du hier nochmal was neues machen? 

**2025-10-17T10:40:29.225109** - Julia:
> ja verstehe. und schwarze Schrift?

**2025-10-17T10:42:10.903539** - Julia:
> 

**2025-10-17T10:44:23.421379** - Julia:
> jaa voll

**2025-10-17T10:52:02.726809** - Julia:
> ja sieht dünner aus

**2025-10-17T10:52:10.087329** - Julia:
> kannst du eine kleine kontur drum machen?

**2025-10-17T10:52:48.546639** - Julia:
> jaa perfekt

**2025-10-17T10:54:40.044499** - Julia:
> schuf Porsche --&gt; entwickelte vllt besser?
"es hat neu definiert" --&gt; wer ist es? vllt eher Porsche oder GTS

Und hatte das Gefühl es endet abrupt

**2025-10-17T12:08:14.123739** - Julia:
> sorry war kurz mit coco draußen 

**2025-10-17T12:08:48.171979** - Julia:
> Da würde ich einfach ein Screenshot aus dem Video nehmen der passt 

**2025-10-17T12:09:45.533319** - Julia:
> ja! Sie wollte noch das mit dem Sonnenuntergang. Dann lass uns ihr 2 vorschlagen? :)

**2025-10-17T12:14:58.779909** - Julia:
> Ich weiß aber wir wissen, dass sie es am Ende dann trotzdem will :smile:

**2025-10-17T12:16:42.110939** - Julia:
> Perfekt 

**2025-10-17T12:26:57.483389** - Julia:
> SOS liegt alles ab oder?

**2025-10-17T12:28:14.241539** - Julia:
> Hanna fragt grad

**2025-10-17T12:28:34.812719** - Julia:
> super, danke

**2025-10-17T12:29:24.834679** - Julia:
> jaa mach das, danke

**2025-10-17T12:29:32.626089** - Julia:
> magst du mir bloß noch kurz das Reel schicken?

**2025-10-17T12:29:58.818379** - Julia:
> Also ablegen + TN - weil hanna ist irgendwie nur bis 14/15 Uhr da und ich muss es noch in Sprinklr hochladen

**2025-10-17T12:30:08.361549** - Julia:
> ja genau, aber für mcih

**2025-10-17T12:31:15.134439** - Julia:
> aber können auch noch ihre freigabe abwarten. denke mir nur, da wirds ja wohl kein feedback geben :smile:

**2025-10-17T12:32:32.319059** - Julia:
> sorry letzte Frage, weil ichs ja nicht sehe die ganzen Texte die Charly nochmal umgeschrieben hat, hast du in den Assets ersetzt oder? Also zB statt Legende --&gt; Versprechen usw.

**2025-10-17T12:32:49.395439** - Julia:
> okay super, danke

**2025-10-17T12:33:13.933579** - Julia:
> wie gesagt, falls sie direkt kommentiert musst du das bitte checken. ich hab ihr wegen der schwarzen Schrift bescheid gegeben :slightly_smiling_face:

**2025-10-17T12:33:18.698869** - Julia:
> dankee und happy lunch

**2025-10-17T12:33:56.716249** - Julia:
> alles gut, ich glaubs dir. Ich frag nur, weil ich keine Lust hab Hanna alles erklären zu müssen

**2025-10-17T13:21:51.596079** - Julia:
> Okay Hanna hat 3 Änderungswünsche beim Reel

**2025-10-17T13:22:09.166969** - Julia:
> Sie ist bis 15 Uhr da, lieben wir

**2025-10-17T13:23:45.895309** - Julia:
> sag mir dann gerne Bescheid, wenn du es wieder abgelegt hast in die Präsi. Hoffe es sind nur Kleinigkeiten

**2025-10-17T13:24:12.623309** - Julia:
> Für den Sprinklr Upload bräuchte ich dann bitte auch die Caption die jetzt in der Präsi liegt

**2025-10-17T13:37:17.519209** - Julia:
> ja keine Ahnung, hat PAG ja auch nicht?

**2025-10-17T13:37:36.285599** - Julia:
> dann packs gerne überall drauf

**2025-10-17T13:37:42.391879** - Julia:
> hauptsache das reel ist fertig

**2025-10-17T13:38:43.615579** - Julia:
> ja versteh ich auch nicht

**2025-10-17T13:38:52.616689** - Julia:
> dann kommentier das gerne, sie kanns ja von dir lesen

**2025-10-17T13:39:30.688699** - Julia:
> kannst du noch alle kommentare von Charly abhaken die du gemacht hast?

**2025-10-17T13:40:01.688069** - Julia:
> okay dankeee

**2025-10-17T13:40:03.263369** - Julia:
> ich sags ihr

**2025-10-17T13:40:15.308199** - Julia:
> auch in der Präsi oder?

**2025-10-17T13:40:24.548399** - Julia:
> caption please noch :slightly_smiling_face: dann kann ichs hochladen

**2025-10-17T13:41:46.999789** - Julia:
> ja easy, nur reel will sie jetzt

**2025-10-17T13:42:49.824779** - Julia:
> :heart:

**2025-10-17T14:03:28.682439** - Julia:
> danke dir

**2025-10-17T14:03:31.787619** - Julia:
> ja schon

**2025-10-17T14:03:38.716229** - Julia:
> die stehen alle oben auf der slide oder?

**2025-10-17T14:04:06.079309** - Julia:
> also das ist ja das hier

**2025-10-17T14:04:13.108229** - Julia:
> füg ich ein

**2025-10-17T14:05:55.872509** - Julia:
> 17 uhr ist das reel geplant?

**2025-10-17T14:06:11.624389** - Julia:
> danke :slightly_smiling_face:

**2025-10-17T14:16:01.472739** - Julia:
> so ist auf sprinklr

**2025-10-17T14:16:23.778209** - Julia:
> ist irgendwas für montag früh in der SOS präsentation geplant?

**2025-10-17T14:16:43.593789** - Julia:
> BS Präsi hatte ich ihr auch geschickt, aber hat sie scheinbar kein feedback reingelegt

**2025-10-17T14:18:13.064969** - Julia:
> ah okay

**2025-10-17T14:18:30.932309** - Julia:
> ja gut das muss ich eh händisch machen wegen flammen sticker

**2025-10-17T15:14:19.848519** - Julia:
> Hast du zufälligerweise die ganzen Assets schon abgelegt? Vllt lad ich sie doch nich hoch 

**2025-10-17T15:31:19.055459** - Julia:
> Ja genau

**2025-10-17T15:31:28.741179** - Julia:
> Aber kein Stress, Montag dann meinte Hanna jetzt auch

**2025-10-17T15:31:41.959689** - Julia:
> ja gut, da sollen sich Charly und hanna drum streiten :smile:

**2025-10-17T15:31:45.793789** - Julia:
> danke Mert :slightly_smiling_face:

**2025-10-17T15:31:53.622329** - Julia:
> Gobi würde ich noch rausschicken, thats it

**2025-10-17T15:42:40.128529** - Julia:
> ach dankeee

**2025-10-17T15:47:51.984329** - Julia:
> Also Mert das MUSST du doch von den Bildern erkennen

**2025-10-17T15:47:54.558429** - Julia:
> :joy:

**2025-10-17T15:48:03.307389** - Julia:
> Ich hab kA. Macan wahrscheinlich, oder?

**2025-10-17T15:52:22.215549** - Julia:
> GPT?

**2025-10-17T15:53:00.928749** - Julia:
> Brauchst du das fürs Wallpaper?

**2025-10-17T15:57:49.970609** - Julia:
> okay

**2025-10-17T15:57:52.267249** - Julia:
> danke dir

**2025-10-17T15:57:57.399419** - Julia:
> sag wenn ich mit suchen soll

**2025-10-17T15:58:12.097399** - Julia:
> Gab grad nochmal stress in whatsapp wegen reel, passt jetzt

**2025-10-17T16:13:41.869149** - Julia:
> sie meinten da wäre ein grauer rand drumrum – dachte schon sie meinen den verlauf :smile:
also nochmal alles löschen &amp; alles neu hochladen..
Immer noch grauer Rand bei ihrer Ansicht, bei mir nicht

**2025-10-17T16:13:52.623179** - Julia:
> Ne..

**2025-10-17T16:14:25.266239** - Julia:
> Aber kann ja den Link vllt einfach sharen? Und du sagst mir auf welchen Slides die Updates liegen

**2025-10-17T16:15:10.158209** - Julia:
> Ne das war mein Kommentar :slightly_smiling_face:

**2025-10-17T16:16:04.276299** - Julia:
> lieb ja Nr. 1

**2025-10-17T16:16:17.592729** - Julia:
> Welche Slides in der Präsi sind das? Dann schreib ich das dazu

**2025-10-17T16:17:10.326959** - Julia:
> haha cool

**2025-10-17T16:17:14.479379** - Julia:
> ah super!

**2025-10-17T16:18:46.872889** - Julia:
> ja das ist super, danke

**2025-10-17T16:19:28.527739** - Julia:
> mail ist raaaaus

**2025-10-17T16:27:14.670879** - Julia:
> dann wars das für heute

**2025-10-17T16:27:36.789099** - Julia:
> ja 100%

**2025-10-17T16:27:48.161299** - Julia:
> mir reichts mit diesem Drama für die woche haha

**2025-10-17T16:27:53.532599** - Julia:
> Hat sich Flo gemeldet???

**2025-10-17T16:27:56.724329** - Julia:
> wichtigste Frage

**2025-10-17T16:28:54.574669** - Julia:
> ich versteh das nicht

**2025-10-17T16:29:01.139149** - Julia:
> es kann doch nicht sein?

**2025-10-17T16:29:11.261909** - Julia:
> ich würde austicken

**2025-10-17T16:32:25.212189** - Julia:
> ne also echt...

**2025-10-17T16:32:50.558659** - Julia:
> Mert, schönes Wochenende und lass uns sonst doch am Montag wirklich Flo ins Meeting holen und das ansprechen, das geht nicht.

**2025-10-17T16:33:26.520289** - Julia:
> :heart_hands:

**2025-10-20T11:44:40.091119** - Julia:
> 

**2025-10-20T11:44:50.068139** - Julia:
> könntest du es in die präsi ablegen? :slightly_smiling_face:

**2025-10-20T11:45:06.660689** - Julia:
> dankee

**2025-10-20T11:45:18.733819** - Julia:
> hab 0,00032 grad gedreht

**2025-10-20T11:45:22.283619** - Julia:
> :new_moon_with_face:

**2025-10-20T11:48:26.209449** - Julia:
> perfekt

**2025-10-20T12:23:41.494819** - Julia:
> könntest du mir kurz einen screenshot vom gardasee PP schicken?

**2025-10-20T12:23:48.388929** - Julia:
> Also das was gerade in der Präsi liegt

**2025-10-20T12:35:03.463439** - Julia:
> echt?

**2025-10-20T12:35:25.612009** - Julia:
> also die version die Julia/ Charly immer präsentieren ist mit einigen Screenshots fürs titelbild auf jeden falll

**2025-10-20T12:35:49.130099** - Julia:
> aber gut, dann muss ich es Julia so schicken

**2025-10-20T12:35:51.491299** - Julia:
> danke!

**2025-10-20T12:36:26.440359** - Julia:
> lieb ich

**2025-10-20T12:48:01.229029** - Julia:
> oh man

**2025-10-20T12:48:07.009559** - Julia:
> aber wenigstens eine antwort

**2025-10-20T12:48:42.421439** - Julia:
> ich glaube er versteht nicht, dass kommunikation auch mal bedeutet einfach keine antwort zu haben

**2025-10-20T13:26:25.575759** - Julia:
> dann würde ich Nr. 2 nehmen

**2025-10-20T15:29:46.657349** - Julia:
> soll ich schnell?

**2025-10-20T15:30:33.397919** - Julia:
> alles so wild – die haben sie selbst umgeschrieben aber uns ja nicht bescheid gegeben und ich dachte das ist falsch, weil englisch

**2025-10-20T15:31:18.524649** - Julia:
> ja

**2025-10-20T15:31:53.496999** - Julia:
> ja versteh ich :smile:

**2025-10-21T12:54:04.226899** - Julia:
> ich hab angefangen Figma aufzuräumen und es immer mit Sektionen verdeutlicht: Grün --> final/ Ready, Rot logischerweise Iterationen oder nicht ready
Würdest du das bei Porsche Points + den Single Posts + Wallpaper machen? Da hab ich nicht so den überblick :slightly_smiling_face: dankee

**2025-10-21T13:05:47.359799** - Julia:
> gleiches Spiel beim Brand Store

**2025-10-22T14:39:34.044549** - Julia:
> Halloo

**2025-10-22T14:39:40.374899** - Julia:
> wie gehts dir?

**2025-10-22T14:39:46.149589** - Julia:
> zählst du auch die tage bis es rum ist? :smile:

**2025-10-22T14:41:27.842899** - Julia:
> ja voll

**2025-10-22T14:41:32.804619** - Julia:
> also ich meine jetzt nur Porsche

**2025-10-22T14:41:34.658939** - Julia:
> nicht generell

**2025-10-22T15:30:39.246049** - Julia:
> total

**2025-10-22T15:30:45.050479** - Julia:
> und so ein Drama um alles

**2025-10-22T15:31:01.283299** - Julia:
> einfach nur stress und anstrengend für alle beteiligten personen

**2025-10-22T15:38:37.748269** - Julia:
> ich sag Hanna Bescheid wegen Halloween

**2025-10-24T09:59:30.245789** - Julia:
> Guten Morgen!

**2025-10-24T09:59:32.181649** - Julia:
> WIe gehts dir?

**2025-10-24T09:59:51.821939** - Julia:
> Ehm glaube das ist egal, habs auch schon mit Schalotten probiert

**2025-10-24T10:00:23.413419** - Julia:
> Also ganz klein schneiden in Würfelchen und dann eine Socke zB, die Socke zu machen und dann in den Ofen für paar Minuten

**2025-10-24T10:00:53.551059** - Julia:
> Also die ganze Wohnung und du riecht danach nach Zwiebeln aber es hilft soo krass. Ich setze dann immer eine Mütze auf und steck diese Säckchen dann so fest :smile:

**2025-10-24T10:01:54.428679** - Julia:
> Wollen wir so um 11 sprechen? Müsste jetzt noch kurz mit coco raus, hab voll verschlafen

**2025-10-24T12:03:10.699729** - Julia:
> welcome back

**2025-10-24T12:03:24.319159** - Julia:
> ne das wäre tatsächlich die Prio soweit ich es sehe

**2025-10-24T12:03:56.521549** - Julia:
> das ist für den Brand Store ge?

**2025-10-24T13:43:58.138689** - Julia:
> magst du mir bescheid geben, wenn dus abgelegt hast in dr präsi? :slightly_smiling_face: dann schicke ich es Hanna

**2025-10-24T13:54:44.719429** - Julia:
> also da wir den Post in die Präsi nehmen "müssen" hätte ich sonst gesagt, packen wir beides rein

**2025-10-24T13:55:02.271069** - Julia:
> aber kannst die highlights ja trotzdem per mail schon verschicken

**2025-10-24T13:55:03.876099** - Julia:
> ja gerne!

**2025-10-24T14:06:33.703139** - Julia:
> okay moment :slightly_smiling_face:

**2025-10-24T14:10:14.596259** - Julia:
> cool! Hab 2 kleine Sachen kommentiert

**2025-10-24T14:20:41.384569** - Julia:
> ach mega, danke dir

**2025-10-24T14:21:50.822869** - Julia:
> ich sags Hanna, sobald ich meine Updates auch wieder abgelegt hab

**2025-10-24T14:21:54.566249** - Julia:
> Runde 14959392 :smile:

**2025-10-24T14:22:07.532329** - Julia:
> Weiß nicht, wie man sich textlich immer so versteifen kann

**2025-10-24T14:22:38.550209** - Julia:
> ja gute Idee! Du kannst es auch gerne als Info auf die Carousel Slides legen, ich pack das auch immer als Info nochmal dazu

**2025-10-24T14:31:29.983749** - Julia:
> habs ihr geschickt

**2025-10-27T14:24:51.552899** - Julia:
> Hallloo, kam nochmal was beim Arzt raus?

**2025-10-27T14:34:00.849259** - Julia:
> ach mensch

**2025-10-30T12:56:16.546229** - Julia:
> Mert bist du sehr busy heute?

**2025-10-30T13:07:17.663369** - Julia:
> uii oke :slightly_smiling_face:

**2025-10-30T13:07:26.838279** - Julia:
> hättest du Lust mir kurz hierbei zu helfen:

**2025-10-30T13:07:42.660229** - Julia:
> <https://app.asana.com/1/1199360402832734/project/1211017007394565/task/1211785877307249?focus=true>

**2025-10-30T13:09:05.031829** - Julia:
> Julia meinte "soll wie der lieblingspost sein" den wir schon mal gemacht haben. Würde mir gerade total helfen, wenn du eine kurze Bildauswahl triffst und die gerne einfach in figma ziehst. kann sie dann in 4x5 ablegen und caption etc.

**2025-10-30T13:14:01.259419** - Julia:
> der liegt da in diesem pdf - siehst dus?

**2025-10-30T13:17:11.955009** - Julia:
> jaa genau! gerne deine lieblingsbilder :slightly_smiling_face: und Hanna meinte am besten soll sich der content nicht doppeln (ist ja logisch)

**2025-10-30T13:17:27.782329** - Julia:
> _bei ein zwei sind mehrere Fotos drin, da würde ich dann zb auf den launch control knopf gehen und so wählen, dass sich bilder nicht doppeln_

**2025-10-30T13:17:35.432609** - Julia:
> na super

**2025-10-30T13:17:42.788629** - Julia:
> dankeee dir!

**2025-10-30T13:29:42.123909** - Julia:
> ich glaube nicht

**2025-10-30T13:30:37.890889** - Julia:
> gibts noch ein foto mit menschen drauf?

**2025-10-30T13:31:02.099949** - Julia:
> ach mist

**2025-10-30T13:31:03.179659** - Julia:
> okay :smile:

**2025-10-30T13:32:06.871509** - Julia:
> ist ja wild

**2025-10-30T13:32:15.022449** - Julia:
> aber dankeee Mert, schau ich mir jetzt an :heart_hands:

**2025-10-30T14:20:22.478279** - Julia:
> Wenn du morgen auch kannst, würden um 13Uhr den Übergabe Termin mit Jana machen

**2025-10-31T09:16:43.047829** - Julia:
> Hallooo

**2025-10-31T09:29:31.133759** - Julia:
> nee :slightly_smiling_face:

**2025-10-31T09:30:19.446289** - Julia:
> Also Jana hat sich auch nichtmehr zurückgemeldet

**2025-10-31T09:30:25.718199** - Julia:
> Keine Ahnung, wegen dem Übergabe Termin heute

**2025-10-31T09:30:29.243869** - Julia:
> lieb ich

**2025-10-31T09:34:11.617369** - Julia:
> hatten mal 13Uhr besprochen

**2025-10-31T09:53:07.644459** - Julia:
> yes

**2025-10-31T09:53:25.205899** - Julia:
> könntest du mir kurz sagen, welche Highlights ich hochladen soll? in porschecore :)

**2025-10-31T11:54:08.764099** - Julia:
> also Jana ist heute zu busy. Hab vorgeschlagen Montag 9.30 – weil um 10Uhr will Flo mit uns sprechen

**2025-10-31T12:32:56.635919** - Julia:
> ne

**2025-10-31T12:33:04.803459** - Julia:
> musste grad noch 2 Sachen verschicken aber sonst nixmehr

**2025-10-31T12:33:10.644639** - Julia:
> Sind ja heute eigentlich auch eh alle off

**2025-10-31T12:33:14.252359** - Julia:
> ganz wild

**2025-10-31T13:14:19.483129** - Julia:
> haha dir auch :heart:

**2025-11-03T09:10:36.788989** - Julia:
> Hello! :slightly_smiling_face:

**2025-11-03T09:10:40.469329** - Julia:
> Bisher weder noch

**2025-11-03T09:10:54.305589** - Julia:
> Hatte Jana drum gebeten den Termin um 9.30 einzustellen

**2025-11-03T09:10:55.477939** - Julia:
> Nichts

**2025-11-03T09:11:14.919719** - Julia:
> Ich hab kA. ILass uns um 9.30 mal bereit sein und dann lets see

**2025-11-03T09:11:56.993269** - Julia:
> Lieb ich schon wieder

**2025-11-03T09:31:27.271669** - Julia:
> Hab ihr jetzt nochmal geschrieben

**2025-11-03T09:31:49.427899** - Julia:
> Mert, wiesooooo können wir nicht mal mit normalen menschen arbeiten :smile:

**2025-11-03T09:34:01.260239** - Julia:
> geil sie lügt einfach

**2025-11-03T09:34:14.378859** - Julia:
> meint sie hat einen termin eingestellt mit der falschen julia. im kalender ist nichts

**2025-11-03T09:34:18.617269** - Julia:
> kommt jetzt gleich

**2025-11-03T09:37:09.148679** - Julia:
> termin ich von 10.30 - 11.30

**2025-11-03T09:52:36.044649** - Julia:
> hast du schon gehalt bekommen btw?

**2025-11-03T09:58:10.164539** - Julia:
> na super

**2025-11-03T10:00:23.674309** - Julia:
> Nee

**2025-11-03T10:00:42.592019** - Julia:
> hatte letzten Monat Flo auch dazu geschrieben und da kams dann paar Std. später

**2025-11-03T10:19:24.538809** - Julia:
> ja aber das geht ja trotzdem nicht

**2025-11-03T10:19:26.572269** - Julia:
> ne ich warte auch nur

**2025-11-03T10:19:51.129089** - Julia:
> wir können ja ohne übergabe auch garnichts machen

**2025-11-03T10:19:55.331739** - Julia:
> das muss Flo ja auch klar sein

**2025-11-03T11:17:34.251239** - Julia:
> guuuudde laune

**2025-11-03T12:54:51.313119** - Julia:
> puh

**2025-11-03T12:58:33.286249** - Julia:
> gernee

**2025-11-03T12:58:45.305229** - Julia:
> klappt es bei dir hier über slack?

**2025-11-03T14:26:51.711529** - Julia:
> Mert mit welcher Mail Adresse loggst du dich jetzt bei figma ein?

**2025-11-03T14:30:29.600779** - Julia:
> okay

**2025-11-03T14:30:34.645049** - Julia:
> ja glaub das sollten wir umstellen

**2025-11-03T14:31:06.180549** - Julia:
> ich schreibe flo

**2025-11-03T14:32:41.991929** - Julia:
> wie meinst?

**2025-11-03T14:35:55.367459** - Julia:
> aso

**2025-11-03T14:36:15.097759** - Julia:
> Flo möchte da einen zentralen benutzer haben. nicht mehr porsche

**2025-11-03T14:37:44.273559** - Julia:
> ja genau

**2025-11-03T14:37:55.106659** - Julia:
> ich versuch mal das zurückzusetzen

**2025-11-03T14:37:59.117019** - Julia:
> falls du raus geschmissen wirst

**2025-11-03T14:54:17.722529** - Julia:
> der google login ist:

**2025-11-03T14:54:29.711769** - Julia:
> Login via Google:
<mailto:clients@boldcreators.club|clients@boldcreators.club>
_clients@bcc2023!

**2025-11-03T14:54:52.780219** - Julia:
> Flo kriegt da einen Code aufs handy und bittet uns das dann via App umzustellen, sodass wir die Codes selbst aufs Handy bekommen

**2025-11-03T14:55:12.715039** - Julia:
> ich kann das gerade nicht machen, wegen meinem Update aber wenns bei dir klappt, wäre ja schon mal super

**2025-11-03T14:56:42.687669** - Julia:
> bitte log dich am besten an deinem handy in der gmail app auch mit <mailto:clients@boldcreators.club|clients@boldcreators.club> ein, dann kannst du's selbst verifizieren und brauchst nicht mich

**2025-11-03T14:56:46.786199** - Julia:
> von flo

**2025-11-03T15:01:43.042079** - Julia:
> bin übrigens hier:
<https://docs.google.com/presentation/d/1hCn3KbyAlmOzdpS0aAdcerl52U-l4EYm/edit?slide=id.g39fbe07ff9b_0_23#slide=id.g39fbe07ff9b_0_23>

**2025-11-03T15:02:17.726869** - Julia:
> echt?

**2025-11-03T15:02:25.712459** - Julia:
> der antwortet bestimmt gleich

**2025-11-03T15:39:06.272449** - Julia:
> ob Jana hilfsbereit ist?

**2025-11-03T15:39:08.283849** - Julia:
> i daut it

**2025-11-03T15:39:10.387359** - Julia:
> :smile:

**2025-11-03T15:41:01.468339** - Julia:
> wahrscheinlich

**2025-11-03T15:42:53.788449** - Julia:
> mit welchem account melden wir uns bei diesem lark an?

**2025-11-03T17:32:38.548399** - Julia:
> auf jeden Fall

**2025-11-04T09:54:31.560469** - Julia:
> Hi!

**2025-11-04T09:54:36.147259** - Julia:
> ja perfekt, danke :slightly_smiling_face:

**2025-11-04T10:37:48.936349** - Julia:
> lieb ich

**2025-11-04T10:40:57.030579** - Julia:
> Ne

**2025-11-04T10:41:01.374289** - Julia:
> ich weiß ja garnicht was wir da sagen sollen :smile:

**2025-11-04T10:41:54.944139** - Julia:
> jana hat in ihrem kalender den termin auch abgesagt

**2025-11-04T10:42:36.073659** - Julia:
> genau

**2025-11-04T10:50:29.481709** - Julia:
> yes

**2025-11-04T10:50:32.116379** - Julia:
> in der mail moment

**2025-11-04T10:51:36.442069** - Julia:
> okay perfekt! da hab ich die Sachen ja eh raus übernommen

**2025-11-04T10:51:56.867789** - Julia:
> die hasst glaube ich Menschen

**2025-11-04T10:54:51.722969** - Julia:
> ja wirklich

**2025-11-04T10:55:06.881609** - Julia:
> wollte Julia gestern schon schreiben, aber dachte mir: ne die braucht ruhe :smile:

**2025-11-04T11:41:00.984259** - Julia:
> Soo, schau gerne mal hier ab Seite 17 hab ich es neu erstellt:
<https://docs.google.com/presentation/d/1hCn3KbyAlmOzdpS0aAdcerl52U-l4EYm/edit?slide=id.g39fbe07ff9b_0_162#slide=id.g39fbe07ff9b_0_162>

Ich hab erste Ideen für verschiedene Content Reihen basierend auf den Content Säulen abgelegt. Daneben stehen teilweise noch Ideen für weitere Reihen. Hier hab ich entweder noch keine guten Videos gefunden oder ist noch nicht ausgereift. Magst du mal deine Ideen ergänzen/ erweitern?

**2025-11-04T11:41:29.889349** - Julia:
> Slide 27 mit der "Roadmap" bin ich noch komplett lost

**2025-11-04T11:42:53.302239** - Julia:
> Also dass man versteht was mit Content Reihen gemeint ist: hier zB kann man das ganze ja mit verschiedenen Rezeptideen verbinden, 3 verschiedene Belege und schon haben wir 3 Videos

**2025-11-04T11:48:47.878449** - Julia:
> bitte alles eintragen!

**2025-11-04T11:49:13.676739** - Julia:
> falls du für die offenen Ideen noch beispiele findest (wenn du sie auch gut findest) auch voll gerne. du bist der tiktok profi haha

**2025-11-04T11:49:35.627999** - Julia:
> zB wicked oder Wohnzimmer Upgrade hatte ich vom Call gestern ja nur notiert

**2025-11-04T11:53:47.954179** - Julia:
> Von den laser studios?

**2025-11-04T11:53:56.345969** - Julia:
> hab ich oben jetzt mal dringelassen

**2025-11-04T13:48:21.522799** - Julia:
> sieht doch gut aus :slightly_smiling_face:

**2025-11-04T13:50:56.492069** - Julia:
> ich fülle mal noch die "roadmap" etwas aus und schicke es dann flo

**2025-11-04T13:59:16.314359** - Julia:
> klaro, mach das

**2025-11-04T13:59:21.311059** - Julia:
> ja gerne. wo haben wir da was?

**2025-11-04T13:59:26.752299** - Julia:
> haha same

**2025-11-04T14:13:13.510649** - Julia:
> ahja also wirklich ein Call Sheet

**2025-11-04T14:13:15.402179** - Julia:
> ja denke ich auch

**2025-11-04T14:13:28.229279** - Julia:
> aber cool, wenn wir sowas ja schon mal als Vorlage haben :slightly_smiling_face:

**2025-11-04T16:25:29.266529** - Julia:
> nee

**2025-11-04T16:25:34.892189** - Julia:
> hab leider auch noch kein feedback

**2025-11-05T08:44:00.970649** - Julia:
> Guten Morgen, Mert mich hats total erwischt gestern Abend, ich liege mit Fieber im Bett. Ich spreche wahrscheinlich gleich noch mit Flo bezüglich der Präsi aber, dass du es schon mal weißt

**2025-11-05T11:00:48.547779** - Julia:
> dankee

**2025-11-05T11:00:50.320979** - Julia:
> ja

**2025-11-05T11:00:57.896579** - Julia:
> er meinte die ideen stellen wir nächstes mal vor

**2025-11-05T11:02:08.570839** - Julia:
> ich hab kA. ich weiß auch garnicht, ob Flo in das meeting kommt?

**2025-11-05T11:03:50.576299** - Julia:
> ich schreib dem kunden auf teams

**2025-11-05T11:03:53.975699** - Julia:
> wollte flo so

**2025-11-05T11:16:10.528559** - Julia:
> Nee

**2025-11-05T11:16:16.855509** - Julia:
> wir haben ja einen teams channel

**2025-11-05T11:16:19.023919** - Julia:
> bist du da drin?

**2025-11-05T11:20:46.409679** - Julia:
> Hallo zusammen!
Leider kann ich bei unserem Vorstellungstermin heute nicht dabei sein, da mich die Grippe überrascht hat. Ich wollte auf diesem Weg trotzdem schon mal „Hallo“ sagen und freue mich sehr auf die zukünftige Zusammenarbeit!
 Wir haben bereits an einigen neuen Content Ideen gearbeitet und würden euch diese gerne asap genauer vorstellen, sobald ich wieder fit bin. Mein Kollege Mert wird euch heute aber schon zu den zeitnahen Themen etwas vorstellen. LG Juli

**2025-11-05T11:20:49.906039** - Julia:
> hab ich abgeschickt

**2025-11-06T09:54:43.511459** - Julia:
> Hallo :slightly_smiling_face: was gäbe es denn heute zutun?

**2025-11-06T10:03:25.502619** - Julia:
> Oke

**2025-11-06T10:03:48.457799** - Julia:
> Sag bescheid, wenn ich unterstützen kann. Ich bin auf jeden Fall fitter als gestern :face_exhaling:

**2025-11-06T10:12:21.719819** - Julia:
> das stimmt

**2025-11-06T10:12:37.669249** - Julia:
> aber gib mir gerne später mal ein update oder können sonst auch gerne sprechen :slightly_smiling_face:

**2025-11-06T15:16:34.830869** - Julia:
> halloo, bin da

**2025-11-07T09:17:23.213629** - Julia:
> ob sie den Termin um 2.30 morgens rausgelöscht hat?

**2025-11-11T11:38:11.319899** - Julia:
> no more fucks given

**2025-11-11T11:38:14.822919** - Julia:
> :smile:

**2025-11-11T12:08:28.613159** - Julia:
> ja genau :smile:

**2025-11-11T12:08:31.114209** - Julia:
> die spinnt einfach

**2025-11-12T09:58:50.382199** - Julia:
> jaa

**2025-11-12T09:59:02.665689** - Julia:
> so ein quatsch

**2025-11-12T09:59:19.352549** - Julia:
> hab das mit julia auch schon besprochen, die sachen die da geplant sind, stimmen ja alle nicht

**2025-11-12T10:19:36.811579** - Julia:
> wie dieser kunde happy sein kann, versteh ich nicht

**2025-11-12T10:44:28.487739** - Julia:
> hast du notes gemacht? dann schreibe ich sie schnell zusammen

**2025-11-12T10:45:29.486509** - Julia:
> ja klar

**2025-11-12T10:46:00.703709** - Julia:
> <https://meet.google.com/obw-tidc-pwo?authuser=0>

**2025-11-13T17:50:16.694609** - Julia:
> beides :slightly_smiling_face:

**2025-11-13T17:50:22.622119** - Julia:
> aber tell me

**2025-11-13T17:52:53.173309** - Julia:
> KW37?

**2025-11-13T17:53:24.858429** - Julia:
> ich hab das bei der Asana Übersicht alles mit einbezogen

**2025-11-13T17:53:38.771979** - Julia:
> oder hab ich das übersehen? wenn video ist es denn genau?

**2025-11-14T07:48:12.160209** - Julia:
> GuMo! Ja das Video hab ich garnichtmehr mit rein genommen, weil das ja jetzt eh das nächste wäre und somit dann rausfällt

**2025-11-14T09:31:11.333189** - Julia:
> ne, das hatte ich gestern gefragt

**2025-11-14T09:31:23.214239** - Julia:
> ist nur das Video. M sollen wir ignorieren, das war von Marvin selbst

**2025-11-14T09:33:44.361439** - Julia:
> genau!

**2025-11-14T09:33:45.417499** - Julia:
> dankeee

**2025-11-14T09:33:59.273359** - Julia:
> also MINI Pitch wurde abgesagt.. so bitter

**2025-11-14T10:36:58.784309** - Julia:
> ja total krass, sie haben vorhin erst abgesagt, weil sie haben doch kein Budget mehr für eine neue Agentur

**2025-11-14T10:37:17.233979** - Julia:
> 1 Std. vorher. Da ist ja schon soo viel Arbeit reingeflossen, hab die Präsi usw gesehen. Puh echt bitter

**2025-11-14T10:56:48.158599** - Julia:
> ach super, schau ich mir an.
ja das ist sehr smart :slightly_smiling_face:

**2025-11-14T10:57:27.602729** - Julia:
> bist du noch in der alten präsi?

**2025-11-14T11:06:19.393539** - Julia:
> nee, ich wollte eine neue erstellen aber habs noch nicht geschafft. deshalb frag ich :slightly_smiling_face:

**2025-11-14T11:07:02.853879** - Julia:
> jaa hab ich mir gedacht, ey so nervig.
Sag einfach bescheid, dann würde ichs Laureen weiterleiten mit der Bitte um Freigabe etc.
dankeee dir :slightly_smiling_face:

**2025-11-14T11:07:29.926069** - Julia:
> ich warte gerade noch auf Flo's Rückmeldung wegen Bitpanda – das ist echt ein Brocken

**2025-11-14T11:08:02.849249** - Julia:
> Aber andere Frage, hast du Lust, dass wir uns nächste Woche mal im Büro treffen? :slightly_smiling_face: Dienstag, Mittwoch wenn wir eh Termine haben?

**2025-11-14T11:12:27.247679** - Julia:
> wegen mir gerne. Julia wollte eine neue – glaube wegen Jana :smile:

**2025-11-14T11:14:15.730909** - Julia:
> ja, lassen wir es so

**2025-11-14T12:11:44.215719** - Julia:
> jaa perfekt, so machen wir es

**2025-11-14T14:21:26.132739** - Julia:
> jaa find ich super

**2025-11-14T14:21:34.233989** - Julia:
> Hätte mir jetzt auch keine selbst ausgedacht tbh :smile:

**2025-11-14T14:21:49.972049** - Julia:
> also sehr gerne so wie du sagst

**2025-11-14T15:00:35.900729** - Julia:
> wie geil sieht eigentlich dieser frosty winter drink aus haha

**2025-11-14T15:01:58.635469** - Julia:
> ja perfekt

**2025-11-14T15:02:07.307569** - Julia:
> wir sagen dann einfach: Mhmmm so lecker :joy:

**2025-11-14T15:02:27.508329** - Julia:
> Dann schnapp ich mir den Rest der Ideen zum ausformulieren?

**2025-11-14T16:48:01.595369** - Julia:
> würde mir kühlschrank, waschmaschine und mikrowelle anschauen :slightly_smiling_face:

**2025-11-14T16:48:35.248369** - Julia:
> bzw. würde ich sonst mit gorenje starten, weil es ja sein kann, dass der Dreh schneller geplant werden muss

**2025-11-14T16:55:02.795939** - Julia:
> ja auch gerne

**2025-11-14T17:10:51.219639** - Julia:
> ich hab heute keine gehirnzellen mehr :smile: same here

**2025-11-14T17:10:56.167709** - Julia:
> Dir auch Mert! :slightly_smiling_face:

**2025-11-18T11:00:14.074459** - Julia:
> so eine blöde B

**2025-11-18T11:00:14.902299** - Julia:
> haha

**2025-11-18T11:52:58.085309** - Julia:
> Jana haha

**2025-11-18T12:28:16.378049** - Julia:
> Also morgen Büro? :slightly_smiling_face: Dann plane ich das ein

**2025-11-18T15:15:54.234659** - Julia:
> ich glaubs auch :smile:

**2025-11-18T15:15:59.987289** - Julia:
> Asooo ja okay verstehe

**2025-11-18T15:16:07.692409** - Julia:
> Können ja sonst morgen spontan gucken

**2025-11-18T17:04:52.449099** - Julia:
> was machen wir wegen dem 700 views video? packen wir das noch in das Ad Set mit Budget?

**2025-11-18T17:05:08.281249** - Julia:
> würde Jana gerne eine saftige antwort runtertippen :smile:

**2025-11-18T17:07:00.702349** - Julia:
> ach sorry, jetzt check ich erst, dass du garnicht in dem chat drin bist

**2025-11-18T17:07:12.422769** - Julia:
> 

**2025-11-18T17:09:34.138929** - Julia:
> ja perfekt

**2025-11-18T17:09:44.148759** - Julia:
> dann kann ich ihr das sagen

**2025-11-18T17:09:45.473959** - Julia:
> ja ist so

**2025-11-18T17:10:35.206379** - Julia:
> JA

**2025-11-18T17:10:41.166559** - Julia:
> Das hab ich vorhin auch gesehen hahahaha

**2025-11-18T17:11:00.265239** - Julia:
> aber schön in den chat mit Flo reingehauen die Nachricht. Blöde Kuh ey

**2025-11-18T17:11:05.521099** - Julia:
> naja, habs ihr jetzt geschriebenj

**2025-11-18T17:11:08.675529** - Julia:
> Danke Mert!

**2025-11-18T17:13:06.070549** - Julia:
> ja will sie

**2025-11-18T17:13:14.324699** - Julia:
> hab ich kurz überlegt, aber wir sind nicht so

**2025-11-18T17:15:17.378369** - Julia:
> :joy:

**2025-11-19T11:21:42.795169** - Julia:
> <https://docs.google.com/presentation/d/1rbYB7aLiZwdcgXMezmgL1kWXM0APEyGw64nXlBrXhpY/edit?usp=sharing>

**2025-11-19T11:59:49.933159** - Julia:
> ja genau. hab jetzt eine Slide fertig. die Übersicht können wir auch rausnehmen, wenn wir es umständlich finden, war noch wip

**2025-11-19T12:16:25.828919** - Julia:
> done!

**2025-11-19T12:16:41.298819** - Julia:
> also die die ich rausgesucht hab, sind doch alle eher nicht gut

**2025-11-19T12:16:49.083429** - Julia:
> find ich wirklich nicht leicht, wer da passen könnte

**2025-11-19T12:23:19.031199** - Julia:
> ja aber das wäre auf jeden fall eine coole options. nimm gerne die 2 coolsten mit rein!

**2025-11-19T12:24:47.891849** - Julia:
> ach echt?

**2025-11-19T12:25:01.243029** - Julia:
> puh ja, bin ich leider auch kein Fan von :smile:

**2025-11-19T12:49:53.549519** - Julia:
> jaa total! Trag gerne ein welche du gut findest, müssen ja nicht 4 sein, gerne mehr

**2025-11-19T12:50:00.425549** - Julia:
> smart you

**2025-11-19T13:41:10.726739** - Julia:
> das wäre ja perfekt

**2025-11-21T11:58:51.701959** - Julia:
> und die hier ist noch wip, oder?

**2025-11-21T13:05:40.217119** - Julia:
> Ja sie ist so voll gepackt :smile: aber das ist eigentlich gut für den Kunden zu sehen

**2025-11-21T13:08:05.679869** - Julia:
> aber du bist ready oder?

**2025-11-21T13:12:32.303279** - Julia:
> ah okay. soll ich das kurz machen?

**2025-11-21T13:12:54.729929** - Julia:
> okay :slightly_smiling_face:

**2025-11-24T14:19:27.214009** - Julia:
> ja

**2025-11-24T14:19:37.901289** - Julia:
> mehr oder weniger, steht irgendwo im münchner umland

**2025-11-25T08:51:49.282699** - Julia:
> Hi Mert, sorry ich habs nichtmehr gelesen!

**2025-11-25T08:52:24.083579** - Julia:
> ich antworte jetzt direkt, danke dir! ist ja jetzt eh die frage, ob wir Ray dann vorstellen sollen, dass wir das TH Shooting erstmal sein lassen

**2025-11-25T09:26:45.709289** - Julia:
> Ja genau

**2025-11-25T09:26:53.572799** - Julia:
> ich hab die 2 Models jetzt noch in unsere Präsi geladen

**2025-11-25T09:41:29.349489** - Julia:
> ja voll

**2025-11-25T09:41:32.512639** - Julia:
> manchmal macht er das

**2025-11-25T09:44:09.587689** - Julia:
> Ahh okay. Meinst du, du könntest dann kurz dazu kommen?

**2025-11-25T09:48:20.661979** - Julia:
> super danke :)

**2025-11-25T10:15:54.155889** - Julia:
> ich würde vorschlagen, wir starten dann kurz mit Gorenje, dann kannst du danach direkt raus

**2025-11-25T10:16:04.968669** - Julia:
> denke da gibts mehr Klärungsbedarf :smile:

**2025-11-25T10:28:47.120159** - Julia:
> Genau, Content würde ich heute garnichts vorstellen. Hisense haben sie ja schon bekommen --&gt; hier will ich nur Feedback, ob alles passt.
Also hätte quasi "beide Präsis" mit den jeweiligen neuen Inhalte gezeigt:
Hisense:
• Wohnungen
• Models
Gorenje:
• Modulare Küche + Mietstudio

**2025-11-25T10:30:20.665579** - Julia:
> ich finde die Gorenje Präsi nichtmehr. hast du den Link?

**2025-11-25T10:32:44.028089** - Julia:
> genau!

**2025-11-25T10:32:45.434059** - Julia:
> dankeee

**2025-11-25T10:35:36.322449** - Julia:
> Sollen wir noch kurz wegen den Videos von den Designern sprechen?

**2025-11-25T10:38:24.238349** - Julia:
> yes, bin in 3 min da!

**2025-11-25T10:43:13.932829** - Julia:
> bin daaa

**2025-11-25T10:52:24.613739** - Julia:
> :white_check_mark:

**2025-11-25T11:01:37.290719** - Julia:
> bin im warteraum. du?

**2025-11-25T11:06:57.542229** - Julia:
> ja ich kann nicht, komme ja auch nicht rein

**2025-11-25T11:07:09.007309** - Julia:
> aber smart :smile:

**2025-11-25T15:52:23.174629** - Julia:
> Du bezüglich der Zeitungsartikel usw. --&gt; kannst du gerne marie auch drauf ansetzen oder es aufteilen? dass sie schon mal für Gorenje startet zb?

**2025-11-25T15:54:30.295469** - Julia:
> briefst du sie dann? :slightly_smiling_face:

**2025-11-25T15:55:32.390279** - Julia:
> dankeschön :heart_hands:

**2025-11-25T15:56:02.823209** - Julia:
> ich fahr übrigens morgen ins büro, falls du auch Lust hättest :slightly_smiling_face:

**2025-11-25T16:35:29.656939** - Julia:
> das ist wirklich krass

**2025-11-25T16:35:39.654839** - Julia:
> ja Marvin wollte mir vorhin auch nicht wirklich helfen

**2025-11-25T16:41:42.143869** - Julia:
> und. will. ich. nicht.

**2025-11-25T17:08:18.216259** - Julia:
> juhuuu danke

**2025-11-25T17:16:03.718919** - Julia:
> hör auf

**2025-11-25T17:16:11.605099** - Julia:
> ich glaube das nicht!!!!

**2025-11-25T17:16:33.155899** - Julia:
> ich schreibe es gleich Flo in unsere gruppe

**2025-11-25T17:18:46.675369** - Julia:
> also wirklich

**2025-11-25T17:18:49.483449** - Julia:
> das ist SO krass

**2025-11-25T17:33:53.190599** - Julia:
> oh neeeein

**2025-11-25T17:33:54.525939** - Julia:
> ach mist

**2025-11-25T17:34:04.622919** - Julia:
> also du hast ihr auch nicht geantwortet?

**2025-11-25T17:34:20.143849** - Julia:
> schlimmer Tag? wegen Therapie meinst du oder Arbeit? oder beides? :sleepy:

**2025-11-25T17:36:40.929009** - Julia:
> scheiße. hat sie sonst eine Mail?

**2025-11-25T17:36:51.655449** - Julia:
> oder ist das da nicht drin? bin grad nicht im tool

**2025-11-25T17:38:32.532899** - Julia:
> sehr gut

**2025-11-25T17:48:31.647919** - Julia:
> mach :smile: das wäre mal ein smarter shortcut

**2025-11-26T10:29:16.699949** - Julia:
> ja oder?

**2025-11-26T12:04:25.611569** - Julia:
> 

**2025-11-26T13:59:51.445929** - Julia:
> Mert, warst dus? :smiling_imp:

**2025-11-26T14:01:03.335359** - Julia:
> haha

**2025-11-27T10:00:19.441949** - Julia:
> Hello!

**2025-11-27T10:00:25.065719** - Julia:
> Ne ich habs nur präsentiert

**2025-11-27T10:00:30.775429** - Julia:
> Liegt aber in der Hisense Präsi ab

**2025-11-27T11:37:01.895439** - Julia:
> Hast du Laureen diese Checkliste geschickt? Glaube das wäre mega

**2025-11-28T09:45:32.866139** - Julia:
> Mert

**2025-11-28T09:45:37.295699** - Julia:
> ich bin kurz vorm ausrasten :smile:

**2025-11-28T09:47:55.116349** - Julia:
> 

**2025-11-28T09:57:13.764019** - Julia:
> Danke :heart_hands:

**2025-12-03T18:04:22.765499** - Julia:
> Also ich muss Freitag ins Büro, Flo will irgendwas besprechen. Evtl könnten wir dann die Geräte mitnehmen oder zur Location bringen :)

**2025-12-04T10:16:59.121249** - Julia:
> Flo Weiss Bescheid :)

**2025-12-04T10:38:23.415149** - Julia:
> genau 

**2025-12-05T16:26:20.322379** - Julia:
> so ich bestelle jetzt mal die offenen sachen

**2025-12-05T16:27:41.327879** - Julia:
> lieferung am gleichen tag?? wahnsinn

**2025-12-05T16:38:16.670839** - Julia:
> Ich brauch eine Pause :face_with_peeking_eye: Aber ich setz mich entweder später oder Sonntag Abend an die UGC Skripte – wenn du einen Kopf dafür hast, wäre es mega, wenn du am Montag morgen dann nochmal drauf schaust und wir es Julia im Meeting zeigen und schicken können :slightly_smiling_face:

**2025-12-05T16:40:41.497219** - Julia:
> Ach komm, so lange?? Was gibts denn da so viel zu besprechen, puhh.

**2025-12-05T16:40:50.056369** - Julia:
> Ja easy. Will nur keinen Schmarn erzählen

**2025-12-05T16:41:23.267799** - Julia:
> danke Mert und ich hoffe du hast trotz allem ein schönes Wochenende! Und nächste Woche lenken wir dich schon mal gut ab :blush:

**2025-12-12T09:47:32.248769** - Julia:
> Mert, ganz anderes Thema aber :smile:

**2025-12-12T09:48:14.114199** - Julia:
> hast du evtl noch den Namen eures Putzmanns für mich?

**2025-12-12T09:53:04.865429** - Julia:
> Uh nice, gerne

**2025-12-12T10:06:53.112989** - Julia:
> Also da hatte Julia nur die Präsentationen geschickt

**2025-12-12T10:07:04.532169** - Julia:
> Hab nix anderes erstellt

**2025-12-12T10:07:08.729129** - Julia:
> oder was meinst du genau? :slightly_smiling_face:

**2025-12-12T10:25:35.908119** - Julia:
> jaa das war nur das 

**2025-12-15T11:28:44.108689** - Julia:
> yees

**2025-12-15T11:29:01.650929** - Julia:
> muss dazu aber zuerst den generellen File Stream downloaden, moment

**2025-12-15T11:31:01.261969** - Julia:
> lädt und lädt

**2025-12-15T11:31:07.928999** - Julia:
> hat das bei dir schon geklappt?

**2025-12-15T11:38:07.227539** - Julia:
> 

**2025-12-15T11:38:10.871689** - Julia:
> :no_mouth:

**2025-12-15T11:43:59.968089** - Julia:
> Okay wie?

**2025-12-15T11:45:46.741699** - Julia:
> ah okay

**2025-12-15T11:46:19.430279** - Julia:
> okaay nice! ach danke

**2025-12-15T11:46:53.487489** - Julia:
> Ist es bei dir unter geteilte Ablage oder Meine Ablage?

**2025-12-15T11:48:38.061849** - Julia:
> okay

**2025-12-15T11:48:45.654039** - Julia:
> ja bei mir lädt nix rein

**2025-12-15T11:48:52.969629** - Julia:
> ich starte den PC mal neu...

**2025-12-15T11:48:55.349249** - Julia:
> klassiker

**2025-12-15T12:03:27.532029** - Julia:
> also so einzelne andere Dateien von mir sind alle drin aber der Hisense Ordner nicht

**2025-12-15T12:03:34.676139** - Julia:
> vllt muss es jetzt nochmal laden

**2025-12-15T12:05:46.007669** - Julia:
> kurz in huddle?

**2025-12-15T12:06:07.292939** - Julia:
> dankee

**2025-12-15T16:07:49.801639** - Julia:
> ich starte jetzt mit POV Gaming night :face_with_peeking_eye:

**2025-12-15T17:57:51.017119** - Julia:
> Ne

**2025-12-15T17:58:31.404249** - Julia:
> morgen mittags könnte ich mit den Cuts fertig sein

**2025-12-15T18:00:27.407929** - Julia:
> du bist noch beim Hisense Upload oder?

**2025-12-15T18:08:04.736269** - Julia:
> okay super

**2025-12-15T18:08:11.994019** - Julia:
> ach man, das ist doch so ätzend

**2025-12-15T18:20:01.023149** - Julia:
> 

**2025-12-15T18:28:22.439619** - Julia:
> okay. Dann machen wir das so 

**2025-12-16T14:40:15.889029** - Julia:
> also dieser Mittags Termin morgen mit Flo passt mir garnicht rein :joy:

**2025-12-16T14:45:34.047229** - Julia:
> Ja voll 

**2025-12-16T15:05:03.656859** - Julia:
> okee. Aber du meinst gorenje oder? da bin ich eh noch nicht 

**2025-12-16T15:15:23.408829** - Julia:
> same :smile: es ist so viel

**2025-12-16T16:34:45.204539** - Julia:
> Ahh wie meinst du?

**2025-12-16T16:37:26.146339** - Julia:
> 

**2025-12-16T16:41:23.052569** - Julia:
> wenn du gute Tipps hast für Übergänge/ Effekte, ich hasse diese Premiere effekte haha

**2025-12-16T16:44:25.339689** - Julia:
> also einfach schwarzblende fertig? Ja schon, ich hab nur das Gefühl bei manchen Texten wären es gut aber lets see

**2025-12-16T16:45:19.304839** - Julia:
> ahja okay. weil hier haben wir teilweise reingequatscht. Hast du die Links oder Videos noch? Falls ja, würdest du sie in die Ordner mit reinlegen? Dann mach ich es auch so

**2025-12-16T16:45:25.892239** - Julia:
> ja meine ich

**2025-12-16T16:52:07.123439** - Julia:
> wir müssen uns auch bei der Lichtbearbeitung abstimmen

**2025-12-16T17:03:44.135759** - Julia:
> 

**2025-12-16T17:12:35.102999** - Julia:
> dankeeee

**2025-12-16T17:12:41.633549** - Julia:
> ich hasse eeeeees, alles hängt :smile:

**2025-12-16T17:13:25.050949** - Julia:
> danke, du bist ein Schatz!

**2025-12-16T17:19:52.134979** - Julia:
> ah mist, du hast einen youtube premium account oder? ich kann die videos nicht downloaden (legal)

**2025-12-16T17:20:11.594659** - Julia:
> Und ganz ehrlich: ich überlege ob ich zu Capcut wechsel :smile:

**2025-12-16T17:29:08.705309** - Julia:
> okay

**2025-12-16T17:29:12.462149** - Julia:
> ja hast recht

**2025-12-16T17:29:24.551519** - Julia:
> alles gut, wir hören uns morgen :slightly_smiling_face:

**2025-12-17T10:23:57.378919** - Julia:
> also

**2025-12-17T10:25:06.768739** - Julia:
> mit meinen 8GB Speicher komme ich grad nicht weit :smile: ich muss jetzt alle video snippets downloaden sonst geht garnichts mehr. vom drive klappt das nicht, premiere stürzt dauernd ab. heißt im nachgang (wenn du die dateien nochmal öffnets) müsstest du die clips erneut verknüpfen..

**2025-12-17T10:25:14.553869** - Julia:
> sooo nervig aber sonst kann ich garnicht schneiden

**2025-12-17T10:35:32.348549** - Julia:
> ja genau, das meinte ich

**2025-12-17T10:36:06.824229** - Julia:
> du alles gut, wir müssens ja aufteilen :new_moon_with_face: aber danke :slightly_smiling_face:

**2025-12-17T10:54:08.211239** - Julia:
> Aso ja aber Gorenje Xmas ist ja auch dringend

**2025-12-17T10:54:35.822019** - Julia:
> also das mein ich mit aufteilen. Würden ja eh nicht alles alleine schaffen oder? 

**2025-12-17T11:00:47.669389** - Julia:
> Spinnt es bei dir denn auch so? 

**2025-12-17T11:01:07.604819** - Julia:
> Also bei mir haben die Videos halt auch alle unterschiedliche fps

**2025-12-17T11:05:34.685279** - Julia:
> ja gorenje sind sogar mehr Videos :sweat_smile:

**2025-12-17T11:05:41.878219** - Julia:
> oh man ey 

**2025-12-17T11:05:59.256829** - Julia:
> es läuft wirklich garnicht 

**2025-12-17T11:06:12.551819** - Julia:
> Als wenn's hart auf hart kommt schneide ich gleich mit CapCut :joy:

**2025-12-17T11:08:21.917199** - Julia:
> 

**2025-12-17T11:08:55.527039** - Julia:
> Nee. Das müssen wir ja fertig machen bis Freitag, sonst haben wir bis 7.1. keine Freigabe zum Posten 

**2025-12-17T11:11:22.204429** - Julia:
> wenig aber vllt ist was beim broll dabei. Hab allerdings auch noch keine gorenje Dateien 

**2025-12-17T11:58:36.423449** - Julia:
> also ich schneide jetzt mit rush, sonst klappt es leider nicht. könnten wir uns in zukunft auch überlegen. brauchen für tiktok ja kein krasses premiere

**2025-12-17T12:05:20.856619** - Julia:
> 

**2025-12-17T12:05:49.518509** - Julia:
> eigentlich sehr gleich aber vom handling und aufbau viel simpler und basic

**2025-12-17T12:22:50.172159** - Julia:
> haha ja

**2025-12-17T12:23:02.168159** - Julia:
> ich koche/ backe und filme nichtmehr gleichzeitig :smile:

**2025-12-17T12:23:16.866069** - Julia:
> packst du typo mit drauf? oder machen wir das am ende?

**2025-12-17T12:28:03.272389** - Julia:
> ja gern

**2025-12-17T12:29:10.072109** - Julia:
> ne leider nicht

**2025-12-17T12:43:04.847349** - Julia:
> ja klar

**2025-12-17T12:43:19.474249** - Julia:
> bei den videos mit stativ gehts easy mit rush

**2025-12-17T12:48:29.760749** - Julia:
> hast du noch den Polarexpress für mich? :slightly_smiling_face:

**2025-12-17T13:00:52.230399** - Julia:
> ich finds so verrückt, dass teilweise die farben so unterschiedlich sind, obwohl es genau das gleiche setting ist

**2025-12-17T14:58:04.445309** - Julia:
> Mert

**2025-12-17T14:59:02.155809** - Julia:
> ich würde dir mal kurz in whatsapp eins der movie must watch schicken. magst du mal bitte auch am handy wegen der farben schauen?

**2025-12-17T15:00:14.149619** - Julia:
> obs auffällt, wie unterschiedlich die teilweise sind, wenn man es normal anschaut

**2025-12-17T15:43:16.950689** - Julia:
> no stress

**2025-12-17T15:43:19.517169** - Julia:
> same also :smile:

**2025-12-17T16:17:03.504209** - Julia:
> interactive warmup heißen die. moment ich kanns dir raussuchen

**2025-12-17T16:17:19.771689** - Julia:
> <https://www.youtube.com/watch?v=oRr5hxr_bRA>

**2025-12-17T16:29:21.350839** - Julia:
> jaa würde ich auch

**2025-12-18T10:02:45.951559** - Julia:
> Huhu :slightly_smiling_face:

**2025-12-18T10:02:53.493429** - Julia:
> bist du morgen eigentlich auch im büro dann?

**2025-12-18T10:03:24.285209** - Julia:
> juhuuu

**2025-12-18T11:10:22.505789** - Julia:
> liebs, dass sie nie auf mails antworten

**2025-12-18T18:10:40.386229** - Julia:
> Bis morgen :slightly_smiling_face: ich komme erst vormittags, wenn ich heute noch bissl weiter arbeite

**2025-12-18T19:11:14.518469** - Julia:
> Also ich bräuchte morgen deine Hilfe, einige Videos müsstest du mir stabilisieren. dann kann ich weiter schneiden mit rush

**2025-12-19T10:27:53.268599** - Julia:
> Ich denke ich kann so in 30 min los. Und brauch dann 45-60 min! 

**2025-12-19T10:27:59.868029** - Julia:
> Du? 

**2025-12-19T11:09:21.806219** - Julia:
> bin unterwegs :) 

**2025-12-19T12:45:56.683599** - Julia:
> <https://drive.google.com/file/d/1PvCnftxQisfxjtzfjXe0PWj8whVHy0te/view?usp=drive_link>

**2025-12-22T09:09:01.294819** - Julia:
> Hellooo :slightly_smiling_face: wie gehts dir?

**2025-12-22T09:15:51.621139** - Julia:
> Saaaame

**2025-12-22T09:15:54.158359** - Julia:
> also beides hahaha

**2025-12-22T09:15:58.539919** - Julia:
> es nervt

**2025-12-22T09:46:56.611139** - Julia:
> ja oder?

**2025-12-22T09:49:08.165729** - Julia:
> ah stimmt

**2025-12-22T09:49:24.049489** - Julia:
> Er meint da 2 unterschiedliche Fernseher, oder?

**2025-12-22T09:49:49.455429** - Julia:
> würde antworten "nein, das wäre ein Thema für den Brand Store Dreh – wir hatten ja nur den MiniLED beim Dreh"

**2025-12-22T09:49:52.455139** - Julia:
> :no_mouth:

**2025-12-22T09:57:47.427309** - Julia:
> Soll ich?

**2025-12-22T10:14:07.488809** - Julia:
> ah okay, dankeee

**2025-12-22T10:14:10.045249** - Julia:
> Oh no..

**2025-12-22T10:14:14.185869** - Julia:
> Das ist echt krass

**2025-12-22T10:14:25.755829** - Julia:
> Also ich weiß auch nicht, wieso Flo denkt, dass das mit AI dann funktioniert aber well

**2025-12-22T11:00:15.281309** - Julia:
> ja voll

**2025-12-22T11:00:40.434889** - Julia:
> wie sollen wir uns aufteilen? also ich muss heute auf jeden fall dann den "workshop" vorbereiten und mache ein PDF mit How-To

**2025-12-22T11:00:50.403759** - Julia:
> Aber sollen Marie und ich wieder briefings schreiben?

**2025-12-22T11:10:16.510589** - Julia:
> okay

**2025-12-22T11:10:29.799269** - Julia:
> yes, hab ich schon. dann feedbacke ich? per comments oder wie feedbackst du?

**2025-12-22T11:13:15.181549** - Julia:
> 

**2025-12-22T11:20:30.312629** - Julia:
> also ich finde den start und das ende mit cheers schon gut

**2025-12-22T11:48:11.934789** - Julia:
> boah ey

**2025-12-22T11:48:18.600329** - Julia:
> okay ja ich seh es genauso

**2025-12-22T11:50:49.699689** - Julia:
> 

**2025-12-22T11:51:42.257199** - Julia:
> ja mach das, ich schicke es auch ab

**2025-12-22T11:52:50.243709** - Julia:
> yes, da bin ich davon ausgegangen, dass sie das wissen aber

**2025-12-22T11:52:56.405749** - Julia:
> wir lernen hier ja gerade viel dazu

**2025-12-22T11:52:57.853299** - Julia:
> :smile:

**2025-12-22T11:56:56.400999** - Julia:
> ja versteh ich total

**2025-12-22T11:58:03.940319** - Julia:
> finds wirklich auch krass

**2025-12-22T11:58:22.662879** - Julia:
> Hast du immer mit untertitel gesagt? das haben wir bei hisense ja zB nicht gemacht

**2025-12-22T12:07:46.283419** - Julia:
> ah okay

**2025-12-22T12:08:08.804589** - Julia:
> also einfach unter uns: ich glaube wenn wir die Videos selbst schneiden, machen wir es besserr

**2025-12-22T12:33:09.402249** - Julia:
> Mert ne andere Frage: bist du überhaupt um 18 uhr heute noch da?

**2025-12-22T12:33:13.604469** - Julia:
> ich eigentlich nicht haha

**2025-12-22T12:35:31.227769** - Julia:
> :smile:

**2025-12-22T12:35:35.552429** - Julia:
> FÜHL ICH

**2025-12-22T12:35:41.759749** - Julia:
> Ja weil Flo den Workshop heute nach 18 Uhr will

**2025-12-22T12:39:10.172589** - Julia:
> 

**2025-12-22T12:39:15.187929** - Julia:
> es nervt mich einfach so, dieses Hin und Her

**2025-12-22T12:43:49.406719** - Julia:
> ja :smile:

**2025-12-22T12:44:14.076409** - Julia:
> der lässt da glaub ich nicht mit sich reden

**2025-12-22T12:49:08.513089** - Julia:
> fyi: *Marie Gottschall*
[12:48 PM] bei ACE haben Basti und so sich immer das Premiere Projekt in den Drive Ordner ablegen lassen um dann so Kleinigkeiten selbst zu verbessern falls euch das was hilft

**2025-12-22T13:33:34.217419** - Julia:
> 

**2025-12-22T13:49:24.595269** - Julia:
> ja auf jeden fall

**2025-12-22T14:55:02.265459** - Julia:
> da steht es liegt in deinem trash

**2025-12-22T14:55:07.049849** - Julia:
> kanns nicht anschauen leider

**2025-12-22T14:55:44.481009** - Julia:
> haha okay moment

**2025-12-22T14:55:45.186059** - Julia:
> danke

**2025-12-22T14:56:02.119359** - Julia:
> cool!

**2025-12-22T14:56:14.620569** - Julia:
> Ja ist besser, wenn man die Ausgagssituation nochmal sieht

**2025-12-22T15:48:02.327619** - Julia:
> 

**2025-12-22T15:49:51.686669** - Julia:
> Aso und noch eine Frage:

**2025-12-22T15:50:20.463449** - Julia:
> 

**2025-12-22T16:31:11.316809** - Julia:
> Nee es ist das hier: 1415: 3-6s (cut between video no. 1408)

**2025-12-23T16:22:27.034979** - Julia:
> ob niemand außer Flo motiviert ist und zugesagt hat :joy:

**2025-12-23T16:22:31.669909** - Julia:
> bin gespannt 

**2025-12-23T16:27:35.275439** - Julia:
> ne das geht ja nicht. Dann müssen wir ihnen zumindest sagen, dass fo Bearbeitung länger dauert und wir nach den Ferien Vollgas geben? 

**2025-12-23T16:36:23.354079** - Julia:
> Ja eigentlich hatten wir ja auch nicht so viel direkt für Januar geplant. Julia war etwas optimistisch haha

**2025-12-23T16:39:51.348489** - Julia:
>  Genau aber wlan geht grad nichtmehr. Bin auf der Suche nach Internet :weary:

**2025-12-23T16:40:03.550839** - Julia:
> ach manno schade 

**2026-01-07T15:03:30.311349** - Julia:
> okay super! Stimme allem zu noch das zusätzlich:
• Lautstärke ja super, würde noch ergänzen, dass es teilweise zu laut ist
• Schrift/ Typo immer gleiche Größe und Positionierung, außer es passt nicht in die Gesamtkomposition bezüglich Leserlichkeit etc. --&gt; gerne eigene Vorschläge
• Bildanschnitte: wenn es schief ist/ nicht ins Bild soll (zB unschöner Hintergrund) gerne so croppen, dass es ästhetisch aussieht
Man kanns ja mal versuchen mit diesem Feedback

**2026-01-07T15:47:32.412579** - Julia:
> da wolltest du den opener mit wackligem Seidentofu oder? Also das war so gewünscht?

**2026-01-07T15:47:42.584429** - Julia:
> finds leider so unsexy hahahah

**2026-01-07T16:02:39.131529** - Julia:
> okay, verstanden

**2026-01-08T12:08:05.446889** - Julia:
> hello :slightly_smiling_face:

**2026-01-08T12:08:23.812519** - Julia:
> du hast als Typo Größe auch immer 100 genommen oder?

**2026-01-08T12:09:52.222609** - Julia:
> okay, dankee

**2026-01-08T17:00:42.494929** - Julia:
> yees, den ginger shot feedbacke ich jetzt noch

**2026-01-08T17:00:45.489809** - Julia:
> voll gut!

**2026-01-09T13:49:48.072199** - Julia:
> 

**2026-01-09T13:51:05.241249** - Julia:
> boomer frage aber den Supertext erst später einblenden.. macht man das? Hab ich bewusst noch nie gesehen :smile:
<https://next.frame.io/share/98ab9768-d27e-498f-9637-c510663e3e60/view/154f5f36-4faa-498b-a366-297a0c095a2b>

**2026-01-09T14:37:38.659449** - Julia:
> ja total. ich sag nur, damit du bescheid weißt. weil ichs ja nicht öffnen kann

**2026-01-09T14:38:11.029119** - Julia:
> hää wie strange ist das. ich verstehs auch nicht

**2026-01-09T16:43:51.290559** - Julia:
> würde mich jetzt auch mal ausloggen

**2026-01-09T16:44:00.845769** - Julia:
> glaube da kommt heute eh kein fertiges Video mehr raus :sleepy:

**2026-01-09T16:48:49.001749** - Julia:
> okay

**2026-01-09T16:49:14.798859** - Julia:
> ja ich versteh nicht ganz, wie sie selbst nicht sehen können, dass es halt rotstichig ist. Also ja unsere Ansprüche sind höher aber die Basics..?

**2026-01-09T16:49:24.432359** - Julia:
> dankee dir!

**2026-01-09T16:49:37.429339** - Julia:
> Happy weekend und hoffentlich bis Montag! :smiling_face_with_3_hearts:

**2026-01-13T17:15:27.525689** - Julia:
> helloo, wie gehts dir?

**2026-01-13T17:15:48.976049** - Julia:
> Hab heute wirklich 0,0 für H/G geschafft. warte jetzt gerade auf Flo's Feedback :no_mouth:

**2026-01-13T17:16:31.563639** - Julia:
> ich würde morgen früh mal dieses 3 Dips für Handball Video einbriefen, damit du Bescheid weißt

**2026-01-13T17:36:03.749769** - Julia:
> ach mist.. das tut mir leid zu hören. gute besserung :bouquet:

**2026-01-13T17:36:28.289829** - Julia:
> dir auch und meld dich sonst krank, bringt ja nix

**2026-01-14T17:21:56.243529** - Julia:
> Nee glaub ich nicht

**2026-01-14T17:21:57.691229** - Julia:
> 20.30

**2026-01-14T18:02:00.229669** - Julia:
> ja können wir gerne. schauen wir uns morgen mal an, obs in den koffer passt?

**2026-01-15T10:47:26.773089** - Julia:
> Jaa

**2026-01-15T10:47:41.771229** - Julia:
> das hab ich mit Marina dann gedreht. sind 3 Dips

**2026-01-15T10:47:43.435569** - Julia:
> Oh echt?

**2026-01-15T10:48:35.235019** - Julia:
> okay, kann mich gerade auch nicht mehr erinnern. ich glaube ohne funktioniert es nicht, wäre schon viel text zum lesen. sonst machen wir einfach ein VO mit AI

**2026-01-15T10:52:53.885839** - Julia:
> ich glaube ich kann mich auch dran erinnern?

**2026-01-16T15:23:02.749809** - Julia:
> Flo hat mir geschrieben, dass “Mert dann einen ssio Beat drüber legen soll” 
Ich soll quasi nichts mit der Bearbeitung zutun haben 

**2026-01-16T15:23:32.795299** - Julia:
> Dann geben wir es Peru wegen Montag Dienstag. Ist das okay für dich? 

**2026-01-16T15:26:22.367489** - Julia:
> Dienstag wäre schon super

**2026-01-16T15:26:42.485329** - Julia:
> Denke da wirds ein paar Feedback Runden mit Flo geben 

**2026-01-16T15:51:48.528199** - Julia:
> Mist

**2026-01-16T15:51:51.699119** - Julia:
> Können wir

**2026-01-16T15:51:57.970419** - Julia:
> Hoffe ich bin dann nichtmehr verschnupft

**2026-01-16T15:52:07.438159** - Julia:
> sorry der uplpad dauert so lange, mein laptop ist wieder überfordert

**2026-01-16T16:08:18.710279** - Julia:
> videos sind oben, ich schreib schon mal die Reihenfolge mit in die Task rein

**2026-01-16T16:08:23.215749** - Julia:
> <https://app.asana.com/1/1199360402832734/project/1211206795229799/task/1212839388986275?focus=true>

**2026-01-16T16:36:50.617079** - Julia:
> okay ist alles ready. Können wir uns sonst ja am Montag dann im Flieger anschauen :smile:

**2026-01-20T15:55:06.445899** - Julia:
> <https://www.google.com/search?q=Manuellsen+SIXT&amp;oq=Manuellsen+SIXT&amp;gs_lcrp=EgZjaHJvbWUyBggAEEUYOTIKCAEQABiABBiiBDIHCAIQABjvBTIHCAMQABjvBTIHCAQQABjvBdIBBzU1NGowajeoAgCwAgA&amp;sourceid=chrome&amp;ie=UTF-8#fpstate=ive&amp;vld=cid:cd655258,vid:ZhPRD0-08rU,st:0|https://www.google.com/search?q=Manuellsen+SIXT&amp;oq=Manuellsen+SIXT&amp;gs_lcrp=EgZjaHJvb[…]vBTIHCAQQABjvBdIBBzU1NGowajeoAgCwAgA&amp;sourceid=chrome&amp;ie=UTF-8>

**2026-01-20T17:44:30.582899** - Julia:
> • video generell zu lange
• teil 1: musik muss uncool sein --&gt; muss klar werden, dass nur mit LIDL cool
• rewind sound effekt +  :rewind: Icon
• pixel kleiner/ enger setzen, quasi nur pikante stellen verdeckt

**2026-01-21T14:32:44.030009** - Julia:
> So hier kommen die Sounds:

**2026-01-21T14:40:37.348369** - Julia:
> Rewind:

**2026-01-21T14:46:41.493039** - Julia:
> Ich schick dir ein paar Varianten vom Rap, dann kannst du schauen was am besten passt. Es ist immer unter Vocals und Music unterteilt! Vllt passt es ja auf den ursprünglichen Beat?

Laut:

**2026-01-21T14:46:58.607979** - Julia:
> Tiefe Stimme:

**2026-01-21T14:47:34.056839** - Julia:
> Smooth:

**2026-01-21T14:53:02.529829** - Julia:
> "Fail" für's Ende - aber sehr übertrieben:

**2026-01-21T14:53:40.021369** - Julia:
> Als Background für Teil 1, so bisschen funny/ Cartoon Music – falls du hier eine andere Idee hast, gerne :smile:

**2026-01-21T15:00:05.684249** - Julia:
> klar

**2026-01-21T15:00:39.353709** - Julia:
> ich bin jetzt gleich mal weg und mache eine Runde mit Coco. hab schon 1 1/2 std. Meeting mit Marvin hinter mir :stuck_out_tongue:

**2026-01-21T15:00:47.604389** - Julia:
> Gute erneute Reise :smile:

**2026-01-21T17:52:50.124549** - Julia:
> Auf jeden Fall 

**2026-01-21T17:53:04.548809** - Julia:
> also soll ich oder kannst du es schneiden? 

**2026-01-21T18:08:24.538949** - Julia:
> Problem ist, dann ändert er wieder die Aussprache der Wörter 

**2026-01-21T18:08:33.639389** - Julia:
> Das klappt nicht so gut 

**2026-01-21T18:17:23.705849** - Julia:
> Warte ich glaub ich hab's 

**2026-01-21T18:23:37.385909** - Julia:
> moment

**2026-01-21T18:24:37.937579** - Julia:
> okay jetzt sagt der Strong auch besser:

**2026-01-21T18:25:22.230469** - Julia:
> Smooth neu:

**2026-01-21T18:25:42.914609** - Julia:
> Was meinst du wann du fertig wärst? Weil sonst, können wir es auch morgen früh direkt schicken? je nachdem

**2026-01-21T18:38:08.786079** - Julia:
> ah okay, ja moment

**2026-01-21T18:39:00.494369** - Julia:
> there you gooo

**2026-01-21T18:39:05.474249** - Julia:
> ah okay

**2026-01-21T18:51:05.854059** - Julia:
> okay mooooment

**2026-01-21T18:55:16.677669** - Julia:
> geil! Also bei den Pixeln werden sie noch Feedback haben
• beim 1. Teil sieht man direkt die Unterhose von David
• bei Sekunde 8 wollen sie die Pixel nur an den pikanten Stellen, also quasi 2 Balken. Weißt du wie ich meine?
• Teil 2: Sekunde 23 können wir hier die Szene mit David komplett mit Schlappen etwas länger lassen. Das sieht man fast garnicht, weil so schnell weg 
• beim 2. Teil ist das Oberteil von Toni noch nicht verpixelt

**2026-01-21T18:55:51.728609** - Julia:
> Willst du die Sachen noch anpassen oder soll ich es schicken mit dem Hinweis, dass wir das noch anpassen morgen früh? Für mich beides fein

**2026-01-21T18:56:18.926659** - Julia:
> liebs wie der Text zum Bild passt! :smile:

**2026-01-21T18:58:06.581439** - Julia:
> okay

**2026-01-21T18:58:16.713149** - Julia:
> die letzte Szene, wo sie die Isar entlang laufen

**2026-01-21T19:05:00.191769** - Julia:
> jaa genau

**2026-01-21T19:05:09.018749** - Julia:
> sie soll nackt wirken

**2026-01-21T19:08:20.413449** - Julia:
> ne aber so hat sie ja was an

**2026-01-21T19:08:22.804779** - Julia:
> weißt du was ich meine?

**2026-01-21T19:08:40.992709** - Julia:
> deswegen müssten wir es zensieren, damit sie nackt aussieht

**2026-01-21T19:09:18.171359** - Julia:
> Aber verstehe wie du es meinst

**2026-01-21T19:19:12.777719** - Julia:
> okay verstehe!

**2026-01-21T19:20:11.850589** - Julia:
> ja funktioniert auch so :slightly_smiling_face: ich schicks den beiden

**2026-01-21T19:20:22.407279** - Julia:
> feedback schicke ich dir morgen

**2026-01-21T19:20:33.696419** - Julia:
> kann mir vorstellen, dass sie noch ein Abschluss Bild oder so wollen

**2026-01-21T19:24:25.311309** - Julia:
> auf jeden!

**2026-01-21T19:24:34.739849** - Julia:
> danke dir und bis morgen :slightly_smiling_face: ausgeschlafen haha

**2026-01-22T09:52:58.734499** - Julia:
> Hello! Video finden sie super, einzig den Song wollen sie noch etwas anpassen! 
Zum 2. Video haben so noch nichts gesagt, frag ich gleich mal :)

**2026-01-22T10:33:21.101659** - Julia:
> 

**2026-01-22T10:59:18.821879** - Julia:
> Yes 

**2026-01-22T11:22:01.874859** - Julia:
> <https://next.frame.io/auth/refresh?state=0e81f80ab70d085aeece33dafccbce2072f96e634cd770057ddba132eb520023&amp;then=%2Fshare%2Fb21355d6-c989-4839-bdad-83285ec8966d&amp;soft=true|https://next.frame.io/auth/refresh?state=0e81f80ab70d085aeece33dafccbce2072f96e634c[…]then=%2Fshare%2Fb21355d6-c989-4839-bdad-83285ec8966d&amp;soft=true>

**2026-01-22T11:38:11.606089** - Julia:
> die Interview Videos hast du noch garnicht, oder? Dann lad ich sie in den Drive

**2026-01-22T12:03:51.383759** - Julia:
> Okay

**2026-01-22T12:03:58.448209** - Julia:
> Heißt, was kann ich genau tun?

**2026-01-22T12:04:46.879609** - Julia:
> okayy

**2026-01-22T12:04:56.824149** - Julia:
> Ja genau

**2026-01-22T12:05:19.298079** - Julia:
> Und lyrics (Vocals) vom bestehenden Video und nur den Beat von den alten Sounds, hast du probiert oder?

**2026-01-22T12:06:12.600689** - Julia:
> bzw. das meinst du, das nicht klappt oder?

**2026-01-22T12:06:52.318209** - Julia:
> 

**2026-01-22T12:07:02.110599** - Julia:
> ja okay, passt. dann erstell ich eins komplett neu

**2026-01-22T12:09:10.140239** - Julia:
> ja alles gut

**2026-01-22T12:09:14.826609** - Julia:
> hätte ja einfach sein können :smile:

**2026-01-22T12:30:29.010529** - Julia:
> habs gleich

**2026-01-22T12:32:57.659179** - Julia:
> okay

**2026-01-22T12:33:05.979859** - Julia:
> habs dir in Asana

**2026-01-22T12:33:18.868429** - Julia:
> <https://app.asana.com/1/1199360402832734/project/1212808160983275/task/1212807852658836?focus=true>

**2026-01-22T12:38:53.152319** - Julia:
> there you go:

**2026-01-22T12:45:51.215249** - Julia:
> einmal Vocals und Beat getrennt und einmal zusammen :slightly_smiling_face:

**2026-01-22T12:48:28.509559** - Julia:
> Haha okay geil. ne das ist eigentlich nur so ein Hintergrund Sound wie "wer"

**2026-01-22T12:49:59.672899** - Julia:
> ja ich weiß

**2026-01-22T12:50:07.558789** - Julia:
> aber sollte nur ein Background sein

**2026-01-22T12:50:56.694909** - Julia:
> lassen wir es so, bisher kam das Feedback nicht. wenn ichs wieder anfasse, passiert wieder irgendwas anderes

**2026-01-22T12:54:25.702179** - Julia:
> geil :smile:

**2026-01-22T12:54:43.645519** - Julia:
> sollen wir am Ende nochmal Close Up auf David machen mit dem Zwinkern? damit wir keine so lange Schwarzblende haben

**2026-01-22T12:55:10.503189** - Julia:
> ist ja egal, wenn wir das bei beiden videos drin haben

**2026-01-22T13:21:01.788769** - Julia:
> ist doch meeega

**2026-01-22T13:21:03.610359** - Julia:
> Dankee :slightly_smiling_face:

**2026-01-22T13:26:31.237259** - Julia:
> habs geschickt

**2026-01-22T13:31:01.910039** - Julia:
> FYI, dass du dich nicht wunderst: beim Video "dein Freund betrügt dich": in der Task steht keine Background Musik --&gt; finde es ohne aber relativ lame, würde Musik hinzufügen. Weiteres Feedback packe ich einfach rein

**2026-01-22T13:33:40.430969** - Julia:
> ah okay, got it!

**2026-01-22T13:33:44.256579** - Julia:
> ja können sie das?

**2026-01-22T13:34:06.383319** - Julia:
> einfach aus TikTok selbst oder was soll ich hier sagen, wo sie Musik finden?

**2026-01-22T13:40:43.515969** - Julia:
> ja cool! danke

**2026-01-22T14:01:55.599939** - Julia:
> Okay Flo hat nochmal Feedback gegeben zum Schlappen Video:
• Teil 1 etwas kürzen (Video noch etwas zu lange)
• Teil 2: "Oberteil der Frau hautfarben machen" --&gt; denke er meint hier die Pixel, die so bisschen grau sind. Geht das?

**2026-01-22T14:10:36.435679** - Julia:
> jaa..

**2026-01-22T14:16:47.101639** - Julia:
> ich bin jetzt mal unterwegs, ich bringe die Amazon Sachen vom Lidl Dreh zur Post

**2026-01-22T15:15:21.848289** - Julia:
> okay geb ich weiter 

**2026-01-22T15:45:04.262469** - Julia:
> hatte vorhin eine Nachricht von F bekommen: ich soll noch was für morgen Abend fertig machen. Hab gesagt, ich brauche den Ausgleich morgen (sobald alle Projekte fertig sind). sorry not sorry

**2026-01-22T15:47:52.587549** - Julia:
> hast du noch was wegen deinem meeting gesagt=

**2026-01-22T16:12:38.658489** - Julia:
> Ich habs mir schon gedacht!!

**2026-01-22T16:12:52.862769** - Julia:
> Dann sag ihm du musst morgen auch frei machen und das Meeting soll vormittags stattfinden

**2026-01-22T16:12:57.186859** - Julia:
> Wir müssen Grenzen setzen

**2026-01-22T16:26:27.572349** - Julia:
> nice, ich schicks rüber! :slightly_smiling_face:

**2026-01-22T16:28:43.825369** - Julia:
> bitte mach ne break!

**2026-01-22T18:23:13.033379** - Julia:
> Sind happy :) 

**2026-01-22T18:23:15.300809** - Julia:
> Bisher 

**2026-01-22T18:23:49.291109** - Julia:
> Der Schnitt ist echt sehr cool, danke dir :heart_hands:

**2026-01-23T15:58:01.919969** - Julia:
> 

**2026-01-23T15:58:14.759189** - Julia:
> 

**2026-01-23T15:58:22.260099** - Julia:
> there you go!

**2026-01-23T16:02:31.276279** - Julia:
> klaroo

**2026-01-23T16:05:36.991809** - Julia:
> falls nochmal was ist, ich bin bis 18 Uhr erreichbar (daheim) :slightly_smiling_face:

**2026-01-26T13:39:17.325889** - Julia:
> <https://www.linkedin.com/posts/carsten-maschmeyer_dienstreise-mitarbeiter-wertschaeutzung-activity-7421455914416750592-iYW1?utm_source=share&amp;utm_medium=member_desktop&amp;rcm=ACoAADKQUUcB3jeFwnfsLSELtQwW0gM_-NwcwF8|https://www.linkedin.com/posts/carsten-maschmeyer_dienstreise-mitarbeiter-wertschaeut[…]m=member_desktop&amp;rcm=ACoAADKQUUcB3jeFwnfsLSELtQwW0gM_-NwcwF8>

**2026-01-26T13:44:49.384409** - Julia:
> :joy:

**2026-01-26T13:46:18.795379** - Julia:
> Wünsche, Anregungen &amp; Kommerkasten

**2026-01-29T13:30:56.768389** - Julia:
> Hello!

**2026-01-29T13:31:12.703519** - Julia:
> hast du bei der Auslagenaufstellung dann jede einzelne Position nochmal angepasst oder nur gesamt?

**2026-01-29T13:32:51.204439** - Julia:
> :melting_face:

**2026-01-29T13:32:52.796769** - Julia:
> okee danke

**2026-01-29T13:33:48.457759** - Julia:
> smart, danke!

**2026-01-29T13:47:35.353709** - Julia:
> Mert :smile: I can't

**2026-01-29T13:51:03.333849** - Julia:
> JA

**2026-01-29T13:51:09.465519** - Julia:
> ich hab jetzt eine Ansage gemacht

**2026-01-29T16:56:52.100409** - Julia:
> glaub wir überziehen

**2026-01-29T16:57:05.903019** - Julia:
> :no_mouth:

**2026-01-29T16:58:01.590979** - Julia:
> genau!

**2026-01-30T11:54:06.507939** - Julia:
> eigentlich ja

**2026-01-30T11:54:12.161049** - Julia:
> lieb ich

**2026-01-30T11:54:40.230589** - Julia:
> Nene mit anderen Tasks meinte ich

**2026-02-03T10:44:38.374439** - Julia:
> 

**2026-02-16T13:59:55.252439** - Julia:
> Flo ruft mich evtl. gleich an – passt es dir wenn wir bisschen später/ spontaner sprechen?

**2026-02-16T14:00:04.503379** - Julia:
> weiß gerade nicht wann er anruft. er meinte "gleich"

**2026-02-16T14:00:52.687779** - Julia:
> okay dankee!

**2026-02-16T14:23:44.270089** - Julia:
> bin readyyy

**2026-02-16T14:36:16.321109** - Julia:
> 1 min


---

### #D09D64LFUS0 (1 messages)

**2026-02-02T10:28:11.781509** - Julia:
> Hi! Ich bin Juli &amp; als Creative Lead bei BCC und wie der Name schon sagt, ich bin für die Kreativleitung unserer Kunden verantworten. Das bedeutet ich verantworte die Entwicklung von Contentstrategien, Formaten und teilweise auch die Contentproduktionen. Hier hab ich zuletzt Porsche mit der gesamten Kommunikation bei der IAA betreut.
Ich komme aus der visuellen &amp; strategischen Markenkommunikation.
Also hab mich spezialisiert auf Marke vor allem im E-Com und die konzeptionelle Kommunikation, nicht nur visuell. Da hab ich bei everdrop eine Love Brand mit Social aufgebaut.


---

### #D09E76RSBNF (47 messages)

**2025-09-09T16:53:11.031439** - Julia:
> Hello! :slightly_smiling_face: Es gab beim Styleguide ja einen Kommentar bezüglich der VBWs. Könntest du diese für dieses Visual Template rausnehmen und mir kurz schicken? Würde es dann im Styleguide ersetzen

**2025-09-09T16:53:25.697019** - Julia:
> Julia möchte den Styleguide jetzt rausschicken

**2025-09-09T16:53:50.181249** - Julia:
> dankeee

**2025-09-09T17:26:31.013289** - Julia:
> nice! Ich brauch es allerdings in der IG Vorschau :slightly_smiling_face:

**2025-09-09T17:54:58.094799** - Julia:
> Bist du noch da? :slightly_smiling_face:

**2025-09-09T18:34:54.228409** - Julia:
> auch okay :smile: Dankeee

**2025-09-23T17:09:12.366039** - Julia:
> Hello :slightly_smiling_face:

**2025-09-23T17:10:16.482149** - Julia:
> also am 25.9. kommt die Zeitschrift mit ihr aus. Wenn wir es am gleichen Tag posten könnten, wäre mega --&gt; aber da eh Gipfeltreffen ist, denk ich wirds dann erst später zum Wochenende passend

**2025-09-23T17:12:00.349879** - Julia:
> Ja, morgen sollten wir Porsche mal unseren Vorschlag schicken aber die haben eh grad andere Themen :smile:

**2025-09-23T17:12:15.857639** - Julia:
> alles gut :slightly_smiling_face:

**2025-09-25T17:25:38.112589** - Julia:
> Hello! Sorry für meine späte Antwort, war etwas im Stress. Danke Basti! :slightly_smiling_face: Sieht super aus

**2025-09-25T17:26:12.514109** - Julia:
> Wo legt ihr die Videos normalerweise für Porsche ab? Würde ihnen gerne den Sharepoint Link schicken. Magst du mir diesen einmal schicken? (Ich hab teilweise noch keinen Zugriff) Dann leite ich es direkt weiter

**2025-09-26T09:41:35.352959** - Julia:
> Okay :slightly_smiling_face: Ich frag mal Mert

**2025-09-30T15:23:44.975869** - Julia:
> Hello! :slightly_smiling_face: Bezüglich dem Leonie Video:

**2025-09-30T15:24:58.294739** - Julia:
> Julia hatte dich ja schon gefragt wegen der Stimme. Charly gefällt diese nicht bzw. folgendes Feedback "Diese klingt aktuell noch etwas starr. Falls es nicht Leonie ist, können wir die Stimme ersetzen oder weglassen?"

Komplett weglassen würde ich nicht. Haben wir die Möglichkeit das zu ersetzen?
Würde es dann auch nochmal in Asana aufnehmen

**2025-09-30T15:30:43.900149** - Julia:
> ja denk ich mir. Aber soweit kommt Porsche natürlich nicht – als würden wir uns jemals Gedanken machen :smile:
Such du gerne aus, ich geb ihr Rückmeldung, dass wir es anpassen können

**2025-09-30T15:32:37.694919** - Julia:
> Heute hast du keine Kapa mehr oder? Haben morgens einen kleinen Einlauf von Charly bekommen, weil das Thema schon etwas liegt..

**2025-09-30T15:34:23.800809** - Julia:
> ja I know

**2025-09-30T15:34:53.479519** - Julia:
> genau das hab ich ihr jetzt auch geschrieben. Ob sie es Leonie so zeigen will oder schon mit neuer Stimme. Gebe dir asap ein Update

**2025-09-30T15:35:02.952269** - Julia:
> Danke :face_exhaling:

**2025-09-30T15:36:45.209329** - Julia:
> :joy:

**2025-09-30T15:36:48.535509** - Julia:
> Scheinbar nicht

**2025-09-30T17:23:47.805709** - Julia:
> Hab dir Charly's Mail weitergeleitet

**2025-09-30T17:31:23.258729** - Julia:
> ja wir hatten das heute auch schon mit Bildern die ich erstellt hatte – AI ist der Feind!!!

**2025-09-30T17:31:24.280309** - Julia:
> :smile:

**2025-10-01T09:21:55.450669** - Julia:
> cool danke!

**2025-10-01T09:22:22.507479** - Julia:
> Charly schickt heute alles an Leonie und holt ihre Freigabe. geb dir dann bescheid

**2025-10-08T15:35:41.451819** - Julia:
> Hello! :slightly_smiling_face: bist du heute da?

**2025-10-08T16:41:47.236449** - Julia:
> ah okay! Bist du morgen wieder da?

**2025-10-08T17:28:13.104339** - Julia:
> ach mist, dann halte gut durch! :heart_hands:

**2025-10-09T09:57:07.999999** - Julia:
> Hello! :slightly_smiling_face: okay gut

**2025-10-09T09:57:10.752709** - Julia:
> Wie war der Dreh?

**2025-10-09T09:57:21.072019** - Julia:
> Wir müssten heute das Leonie Video fertig bekommen

**2025-10-09T10:08:01.551469** - Julia:
> ja glaub ich dir sofort, total!

**2025-10-09T10:08:05.015729** - Julia:
> genau :slightly_smiling_face:

**2025-10-09T10:08:24.988589** - Julia:
> am besten verlinkst du dann in asana direkt Julia – sie übernimmt den Upload :slightly_smiling_face: danke dir

**2025-10-09T13:19:59.679179** - Julia:
> danke!

**2025-11-21T09:46:15.661669** - Julia:
> Hello! :slightly_smiling_face: Bist du heute im Büro? Würde mich sonst an deinen Platz setzen – ziemlich voll heute haha

**2025-12-05T15:46:02.189479** - Julia:
> Hello! 

**2025-12-05T15:46:14.403989** - Julia:
> Yes, hab’s eben gelesen: Mittwoch ist der Dreh. Ist jetzt final 

**2025-12-05T15:46:24.174909** - Julia:
> Haben dieses Licht unterm Schreibtisch bei dir gelassen 

**2025-12-05T15:58:24.863449** - Julia:
> Danke dir! 

**2025-12-11T10:43:58.856189** - Julia:
> Hello! Sind in paar Minuten im Büro mit der Technik 

**2026-02-10T15:28:39.176559** - Julia:
> Danke dir :heart_hands:

**2026-02-16T09:45:41.246449** - Julia:
> Hello! Findet der CheckIn statt? :slightly_smiling_face:

**2026-02-16T10:24:59.014289** - Julia:
> Marvin meinte du bist da mit drin, deshalb :slightly_smiling_face:
Aber alles gut. Ich hab 2 Themen die sie meinten, die offen sind und ich ihnen ein Update geben sollte:
• Car Edit Monstertruck
• Desicion Video BeamNG

**2026-02-16T12:22:05.009309** - Julia:
> ach Mist! Dann gute Besserung :crossed_fingers:


---

### #D09NZF18J2K (12 messages)

**2025-10-31T10:46:19.269009** - Julia:
> Hi Jana! Wie wäre es, wenn wir Montag dann einfach um 9.30 Uhr starten und Flo kommt dann einfach dazu ab 10Uhr?

**2025-10-31T14:06:10.830249** - Julia:
> Super :slightly_smiling_face: stellst du das Meeting ein?

**2025-11-03T09:31:18.295209** - Julia:
> Hi Jana, wie sieht es mit unserem Meeting aus?

**2025-11-03T09:33:46.779079** - Julia:
> <mailto:julia.hopper@boldcreators.club|julia.hopper@boldcreators.club>

**2025-11-03T09:33:55.452569** - Julia:
> <mailto:mert@boldcreators.club|mert@boldcreators.club>

**2025-11-03T09:37:05.597929** - Julia:
> okay

**2025-11-03T10:24:56.207699** - Julia:
> alles gut, danke fürs Bescheid geben

**2026-01-07T09:21:04.272989** - Julia:
> Hi Jana! Happy new year :slightly_smiling_face: Gerne morgen um 10Uhr? Passt dir das?

**2026-01-07T10:42:48.128579** - Julia:
> Dann machen wir es heute. 14.30?

**2026-01-07T10:53:32.078809** - Julia:
> yes, du kannst mir gerne einfach was einstellen

**2026-01-07T12:49:17.577639** - Julia:
> sehe grade bei Flo im Kalender, du hast die falsche Mail genommen. das ist meine richtige: <mailto:julia.hopper@boldcreators.club|julia.hopper@boldcreators.club>

**2026-01-09T10:57:50.039239** - Julia:
> Hi Jana! Kurze Frage: kannst du mir kurz sagen, wieviele Std. du schätzungsweise für SIXT in der Woche aufgewendet hast? Damit ich das Pensum grob einschätzen kann


---

### #D09TPJ3GMSN (259 messages)

**2025-11-24T10:33:39.040789** - Julia:
> Hello! Ich bin im Meeting, melde mich danach :slightly_smiling_face:

**2025-11-24T11:48:55.459799** - Julia:
> So, hat etwas länger gedauert

**2025-11-24T12:20:30.607999** - Julia:
> ja dann gerne die, danke dir!

**2025-11-24T12:28:11.454339** - Julia:
> 

**2025-11-24T12:40:43.035629** - Julia:
> Sorry, Freitag genau!

**2025-11-24T12:40:53.409639** - Julia:
> schade aber alles gut

**2025-11-24T12:45:30.527429** - Julia:
> klar, mach ich. wir haben jetzt eh einige geplant

**2025-11-24T12:45:39.479339** - Julia:
> super, danke! schau ich mir an

**2025-11-24T12:46:15.809529** - Julia:
> gib mir kurz 5 Minuten, ich organisiere kurz die Tasks

**2025-11-24T12:46:22.756509** - Julia:
> melde mich gleich :slightly_smiling_face:

**2025-11-24T12:50:49.068689** - Julia:
> alles gut

**2025-11-24T12:52:02.435479** - Julia:
> <https://docs.google.com/presentation/d/1rbYB7aLiZwdcgXMezmgL1kWXM0APEyGw64nXlBrXhpY/edit?slide=id.g3a64d1ec782_0_33#slide=id.g3a64d1ec782_0_33>

**2025-11-24T12:57:19.820069** - Julia:
> Hisense – Produktfokus (2025–2026)
*TV*
• RGB-TV
*Laser TV*
• PT1 (2025–2026)
• 
*Cooling*
• Crossdoor mit Ice Maker (RQ5P640SYKD / RQ5P470SYID / RQ5P470SYFD)
• 
• Crossdoor Smart Fridge (VIDAA Update) – TBD
• 
• KitchenFit (Q1 2026)
• 
• PureView Serie (Q3–Q4 2026)
• 
*Laundry*
• 5s (bis Q2 2026)
• 
• 3i (Q1 2026) + 5i (Mitte 2026)
• 
*Cooking*
• Einbaugeräte (XXXLutz, Q2 2026)
• 
*SDA*
• Mikrowelle (Inverter without Plate)
• 

Gorenje – Produktfokus (2025–2026)
*Cooling*
• KitchenFit (Q1 2026)
• 
*Laundry*
• Neue G600 Serie (2026)
• 
*Cooking*
• Pizzaofen &amp; Pizzaofen Matt (2026)
• 
• GEH8433BSRWF (Q2 2026)
• 
• GI6433SRWF
• 
*Dishwasher*
• GV16B
• 
• GV561C10 (Q2 2026)
• 
*SDA*
• Staubsauger NEO Series (Dez 2025)


**2025-11-24T15:41:08.158189** - Julia:
> kurze Rückfrage zum Median Post Engagement Wert: das ist auch pro Beitrag, oder?

**2025-11-24T15:53:20.601289** - Julia:
> super danke dir :slightly_smiling_face:
Kann sein, dass wir für eine Präsentation (wenn es soweit kommt) dann noch mehr Daten benötigen, aber da geben wir Bescheid

**2025-11-24T15:53:52.594059** - Julia:
> Cool danke dir!

**2025-11-24T15:54:09.391069** - Julia:
> ich übergebe hier schnell an meinen Kollegen Mert, da ich gleich wieder im Meeting bin

**2025-11-25T10:42:59.276129** - Julia:
> Hello! Gerne den noch hinzufügen. In unserem Meeting mit EL kam noch die Marke Dr. Jart auf – benötigen wir auch noch in unserer Tabelle (Global und DE)

+ Flo hätte gerne noch die restlichen fehlenden Engagement Rates
Danke dir :slightly_smiling_face:

**2025-11-25T12:59:28.620759** - Julia:
> Hello! :slightly_smiling_face: Hatte einen längeren Call mit Flo – meld dich gerne, wenn du Zeit hast, es gibt ein paar offene To Do's

**2025-11-25T13:15:28.218359** - Julia:
> hab dir einen invite geschickt!

**2025-11-25T13:40:13.938289** - Julia:
> <https://docs.google.com/document/d/1SByofKhnwxNEQS8nKwrzm-wT7L5-qAubuA9JX6N6XGo/edit?tab=t.0>

**2025-11-25T14:52:14.834109** - Julia:
> ach super, danke dir!

**2025-11-25T14:52:41.717879** - Julia:
> als die Global Accounts meinst du? sehr cool!

**2025-11-25T14:54:03.913579** - Julia:
> ja das macht voll Sinn

**2025-11-25T14:54:45.565659** - Julia:
> Bezüglich: Elf, das ist wirklich interessant! Lass uns aber gerne bei etwas "hochwertigeren" Marken bleiben für die Super Fans vorallem. Elf ist doch eher etwas zu "locker" im Vergleich zu Mac

**2025-11-25T15:06:13.990749** - Julia:
> ja genau, das hab ich auch gesehen

**2025-11-25T15:09:56.702639** - Julia:
> ich fuchse mich jetzt mal in das thema tiktok shop

**2025-11-25T15:47:55.864189** - Julia:
> das mach ich sehr gerne! Wie gesagt in diesem analytischen/ zahlenbasierten Fakten bin ich auch eher Newbie. Aber das schaffen wir zusammen :slightly_smiling_face:
Bist du morgen zufälligerweise im Büro? Ich komme rein und gehe alles einmal in Ruhe mit Flo durch

**2025-11-25T15:48:19.178259** - Julia:
> Wird auch Zeit, dass wir unser Vorstellungsmeeting dann haben, dann wissen wir auch mehr wer was macht und wo die Expertisen liegen

**2025-11-25T15:53:11.588669** - Julia:
> perfekt, dann sehen wir uns!

**2025-11-25T15:53:33.487569** - Julia:
> ja kann ich mir vorstellen. wurden ja auch direkt ins Projekt gekippt :slightly_smiling_face: dann machen wir morgen in Ruhe die Vorstellung

**2025-11-25T15:54:23.720149** - Julia:
> BTW: Mert meldet sich bei dir bezüglich einer Task, bei der wir gerne Unterstützung benötigen

**2025-11-25T16:20:22.014499** - Julia:
> gute beobachtungen! :slightly_smiling_face: ich hab auch noch ein paar dinge, ich trag alles einmal zusammen

**2025-11-25T16:43:46.804849** - Julia:
> eine Frage zu deiner These:
_Sehr niedrige Median Plays (923) im Vergleich zu Wettbewerbern_
• _- maybelline_de: 19.400_
• _- nyxcosmetics_de: 2.566_
• _- benefitgermany: 2.027_
 _→ Algorithmus verteilt kaum Reichweite, Inhalte gelangen nicht in die For You Page._

Du meinst hier, dass die Median Plays so gering sind, weil der Mac DE Account zB nicht hauptsächlich deutschsprachig ist?

**2025-11-25T16:46:32.203359** - Julia:
> ja verstanden

**2025-11-25T16:47:02.901969** - Julia:
> sehe ich auch so. MAC DE springt ja dauernd zwischen deutsch &amp; englisch

**2025-11-25T16:55:42.223649** - Julia:
> ah mist, wie ärgerlich

**2025-11-25T17:08:40.605059** - Julia:
> ich fasse gerade unsere Notizen zusammen auf der 1. Seite FYI

**2025-11-25T17:53:02.809679** - Julia:
> perfekt, schaue ich mir an

**2025-11-25T17:53:08.380079** - Julia:
> klar mach das

**2025-11-25T17:54:01.355699** - Julia:
> alles gut, keinen Stress. Ich schau was ich heute noch schaffe und dann können wir uns das morgen früh gerne zusammen im Büro direkt anschauen

**2025-11-25T17:56:14.352469** - Julia:
> Happy feierabend! danke dir für deine Hilfe :slightly_smiling_face:

**2025-12-01T10:20:00.258809** - Julia:
> Guten Morgen! :slightly_smiling_face: Sobald du da bist, benötige ich einmal deine Hilfe

**2025-12-01T10:36:23.890869** - Julia:
> Ich bin gerade im Meeting, evtl. schaffe ich es zwischen den 2 Meetings. Ich melde mich asap

**2025-12-01T11:05:33.896639** - Julia:
> Sind die Daten von TikTok shop auch schon drin?
Wie viel revenue man mit wie vielen followern/ Median views macht
Dass wir da eine kausalität suggerieren

**2025-12-01T11:05:47.115009** - Julia:
> Sonst wie besprochen Fokus auf den MAC case mit Beispielen und Zahlen, va. Bzgl TikTok shop und Zusammenhang mit followern und Live Zuschauern. Danke!!

**2025-12-01T11:32:09.823329** - Julia:
> wie gesagt, wenn du hier auch nicht weiter kommst, dann schreiben wir Flo und er hat bestimmt ein paar Minuten Zeit sich das mit uns anzuschauen

**2025-12-01T11:35:38.598839** - Julia:
> ja versteh ich

**2025-12-01T11:37:01.771769** - Julia:
> ne weiß ich leider nicht

**2025-12-01T11:37:49.172249** - Julia:
> Wenn du grad kannst, mach gerne einen Chat auf mit uns 3 und schreib Flo, dass wir hier einmal seine Hilfe benötigen, weil wir hier feststecken

**2025-12-01T11:42:06.028719** - Julia:
> okay und kommen/ haben wir diese ganzen Daten?

**2025-12-01T11:42:26.080399** - Julia:
> ja auf jeden Fall. Müssen es nur begründen

**2025-12-01T11:44:45.596009** - Julia:
> hab Chat GPT auch nochmal gefragt, keine Lösung ohne direkten Zugriff auf das Profil

**2025-12-01T11:57:13.708139** - Julia:
> ja!

**2025-12-01T12:04:55.909929** - Julia:
> super danke

**2025-12-01T12:26:02.711149** - Julia:
> ich schick dir mal ein paar Daten – außer du hast dich auch schon eingeloggt?

**2025-12-01T12:27:30.182699** - Julia:
> 

**2025-12-01T12:30:19.990629** - Julia:
> 

**2025-12-01T12:31:12.379709** - Julia:
> Mac Cosmetics DE TT Shop Sold Products:

**2025-12-01T12:31:52.646119** - Julia:
> Maybelline DE TT Shop Sold Products:

**2025-12-01T12:33:30.530699** - Julia:
> 

**2025-12-01T12:33:39.823079** - Julia:
> jaaa, da gibts wirklich alle daten

**2025-12-01T12:35:56.351119** - Julia:
> Wenn du mehr Daten benötigst, gib Bescheid :slightly_smiling_face:

**2025-12-01T12:39:20.654179** - Julia:
> 

**2025-12-01T12:39:27.403679** - Julia:
> <mailto:clients@boldcreators.club|clients@boldcreators.club>

**2025-12-01T12:55:06.792479** - Julia:
> ja, das könnte man super umformulieren zu "Potenzial ist auf jeden Fall da und es kommt schon da, da im vergleich zu Maybelline...."

**2025-12-01T12:56:06.494149** - Julia:
> Also alle Schlussfolgerungen die dir auffallen, gerne einmal festhalten in einem Dokument :slightly_smiling_face: danke dir!

**2025-12-01T13:30:12.656959** - Julia:
> Super schau ich mir gleich nach der Mittagspause an 

**2025-12-01T13:30:46.501629** - Julia:
> Hast du die US Marken auch angeschaut? Evtl findet man hier ein Beispiel 

**2025-12-01T13:40:01.917409** - Julia:
> die können wir uns gleich für einen Monat holen 

**2025-12-01T13:42:45.493269** - Julia:
> Bzw. sollen wir um 14.30 kurz sprechen? Passt dir das? 

**2025-12-01T13:50:04.350769** - Julia:
> Ja klar easy 

**2025-12-01T13:50:17.282139** - Julia:
> Meld dich einfach danach :blush:

**2025-12-01T14:28:31.598889** - Julia:
> okay danke schon mal für die Auswertung! Ich kann mich leider gerade nicht in den Account loggen, weil du noch angemeldet bist. Lass uns gerne gleich sprechen

**2025-12-01T15:12:16.681799** - Julia:
> *Conversion Rate = (Anzahl der Conversions ÷ Anzahl der Besucher / Klicks / Zuschauer) × 100*
Beispiele:
*1. TikTok Shop Conversion Rate*
Wenn 2.000 Live-Zuschauer reinschauen und 80 kaufen:
```
CR = (80 ÷ 2.000) × 100 = 4 %```
*2. Video → TikTok Shop Produktseite*
Wenn ein Video 10.000 Views hat und 300 Leute auf das Produkt klicken:
```
CR = (300 ÷ 10.000) × 100 = 3 %```


**2025-12-01T15:19:39.732819** - Julia:
> TT Shop Like CR: 0,4%

**2025-12-01T15:44:05.970709** - Julia:
> super danke :slightly_smiling_face: dann kopier ich das schon mal

**2025-12-01T15:45:14.716289** - Julia:
> ich hab gerade das hier raus bekommen:

**2025-12-01T15:45:55.355959** - Julia:
> also könnte man sagen, wenn sich die Views auf ca. 70k erhöhen, dann XY verkaufte Produkte: XY Umsatz
oder? :smile:

**2025-12-01T15:48:23.103209** - Julia:
> genau, das wären realistische ziele

**2025-12-01T15:51:20.217669** - Julia:
> was meinte GPT nochmal zur View to Sale Rate von 0,24% – ist das gut oder nicht gut?

**2025-12-01T15:55:09.231639** - Julia:
> okay

**2025-12-01T15:56:06.798839** - Julia:
> witzig bei mir sagt er das ist schlecht

**2025-12-01T15:56:07.830559** - Julia:
> :smile:

**2025-12-01T15:57:48.971149** - Julia:
> *Wenn MAC auf gutes Beauty-Live-Niveau kommt (2,0 %)*
→ 2 % schaffen sehr viele Marken, sobald ein Creator-Host dabei ist oder klare Live-Deals laufen.
Berechnung:
24.600 × 0.02 = *492 Verkäufe pro Live*
:arrow_right: *+423 zusätzliche Verkäufe pro Live*
 :arrow_right: *~7× mehr Verkäufe*

**2025-12-01T16:05:47.377699** - Julia:
> ah wir haben eine falsche zahl drin

**2025-12-01T16:05:48.762159** - Julia:
> moment

**2025-12-01T16:07:13.441419** - Julia:
> Proof 2: 69 Sold Units bei durchschnittlichen 24.6k Views → *View to Sale Rate: 0,28%* (zu niedrig für Beauty)

**2025-12-01T16:07:17.784389** - Julia:
> sogar etwas höher

**2025-12-01T16:10:48.628049** - Julia:
> ne obwohl bei den 18k als durchschnitt stimmt das nicht

**2025-12-01T16:14:23.964869** - Julia:
> ja genau

**2025-12-01T16:14:30.204479** - Julia:
> aber ich lass es wie du es schon berechnet hast

**2025-12-01T16:19:25.179159** - Julia:
> ja

**2025-12-01T16:24:22.952249** - Julia:
> 

**2025-12-01T16:27:38.682539** - Julia:
> so und welche Metrik hat uns jetzt nochmal gefehlt? :smile:

**2025-12-01T16:35:04.511359** - Julia:
> Ah okay verstanden

**2025-12-01T16:35:12.363229** - Julia:
> Ja gerne!

**2025-12-01T16:36:45.832169** - Julia:
> Würdest du das bei Proof dann direkt anpassen? :slightly_smiling_face:

**2025-12-01T16:37:08.731459** - Julia:
> muss leider noch ein supr wichtiges Lidl Video fertig bekommen

**2025-12-01T16:38:31.451419** - Julia:
> also wenn du kannst, pass gerne die Zahlen im Word Dokument an, das wäre mir eine riesige Hilfe gerade!

**2025-12-01T16:38:52.043749** - Julia:
> Müssten nur vermerken welche Average Live Zahl das dann ist (nur Account selbst oder mit Creatorn)

**2025-12-01T16:41:33.695049** - Julia:
> danke dir :heart_hands:

**2025-12-01T17:05:54.501469** - Julia:
> super, vielen vielen dank!

**2025-12-01T17:18:17.147289** - Julia:
> ich auch

**2025-12-02T09:46:13.884549** - Julia:
> Guten Morgen! Hoffe dir geht es gut :slightly_smiling_face:

Ich würde hier im Dokument die Zahl 2,4% auf 2% ändern. Wir haben ja die View to sale rate bei 0,39% angepasst. Da man realistisch auf 2% kommen kann, passe ich das an.

Für die restlichen Fragen von Flo, buche ich uns gleich die Pro Version, damit wir an die Zahlen kommen

**2025-12-02T10:05:42.911839** - Julia:
> okay haben jetzt den Zugriff :slightly_smiling_face: kommst du wieder rein?

**2025-12-02T10:35:03.821249** - Julia:
> true

**2025-12-02T10:35:19.127999** - Julia:
> schau mal hier: erste Daten damit wir die Vergleiche rausziehen können:

**2025-12-02T10:40:13.598469** - Julia:
> • MAC US: Live Zahlen für View to Sale Rate (Shop + Creator Lives)
• Elf US: Live Zahlen für View to Sale Rate
• MAC DE: User bei Live am 11.11. --> Evtl hier rausziehen wielange die Zuschauer da sind? 

**2025-12-02T10:42:50.801489** - Julia:
> • Maybelline US &amp; L'Oreals Paris machen keine eigenen Live Events --&gt; nur Creator


**2025-12-02T10:43:31.707119** - Julia:
> 

**2025-12-02T10:48:52.805909** - Julia:
> Hier Beauty &amp; Personal Care monatlicher Umsatz Top TT Shops

**2025-12-02T10:49:44.206579** - Julia:
> Würdest du Flo's Fragen einmal mit den Informationen füllen? Log dich auch gerne ein, dann springe ich raus. Danke dir! :slightly_smiling_face:
Bin ab 11.45 ca wieder erreichbar, habe jetzt das Meeting mit Hisense.

**2025-12-02T10:58:56.695019** - Julia:
> danke DIR :slightly_smiling_face:

**2025-12-02T11:49:09.433289** - Julia:
> Soo, kamst du schon voran und wie kann ich dir helfen?

**2025-12-02T11:52:45.984159** - Julia:
> alles gut. Ja logg dich gerne ein

**2025-12-02T11:53:49.884369** - Julia:
> oh no, ich hatte gedacht da sind alle zahlen. hab diese bei "live" insights runtergeladen

**2025-12-02T11:57:27.479789** - Julia:
> ah mist

**2025-12-02T11:58:03.216769** - Julia:
> ich bin auch ausgeloggt :smile:

**2025-12-02T11:58:15.325279** - Julia:
> bist du mit Flo im Büro zufälligerweise? Evtl einfacher dann

**2025-12-02T11:59:20.594269** - Julia:
> okay super, danke

**2025-12-02T12:00:43.809829** - Julia:
> oder so, wenn das für dich okay ist. ich logge mich dort nicht mit meinem privaten handy ein deshalb

**2025-12-02T12:01:04.090949** - Julia:
> dann nutze ich kurz die zeit und mache eine schnelle lunch break, bin gleich wieder da!

**2025-12-02T13:02:32.887569** - Julia:
> Mist. Okay also lass es uns so machen:

1. _*Zahlen/ Screenshots der View to Sale Ratio von anderen Brands*_
--&gt; Wir benötigen die fehlenden Zahlen in unserer Excel Tabelle für Maybelline DE als Vergleich.
--&gt; Wir nehmen noch 2 US Brands als Vergleiche dazu --&gt; wie gesagt Maybelline US und L'Oreal US machen nur Creator Lives. Also hier müssen wir noch andere finden
--&gt; daraus berechnen wir die View-to-sale
--&gt; in Excel Tabelle eintragen und Flo Screenshots schicken

_*2. Anzahl Live Zuschauer von anderen Brands - ich glaube 18k ist nicht so viel, weil da wahrscheinlich alle reinzählen die eine Sekunde zuschauen und dann weiterswipen*_
--&gt; Vergleich Maybelline

_*3. Haben wir zahlen dazu wie lange leute den MAC live stream schauen? Entweder Median oder Average. Haben wir Vergleichswerte?*_
--&gt; bisher nicht. Aber können mit dem Screenshot der Grafik berechnen, wenn wir hier noch die Metrik "Users Online" einstellen:
Die Standard-Formel lautet:
Durchschnittliche Watchtime = Anzahl der Zuschauer/ Gesamte gesehene Minuten
--&gt; Vergleich mit US Brand

_*4. DE Shops mit Umsätzen*_ 
--&gt;  schicke ich Flo

**2025-12-02T13:40:32.055329** - Julia:
> super, alles was du schon schaffst wäre toll! ich bin jetzt gleich im LIDL pitch, melde ich danach

**2025-12-02T14:58:12.447719** - Julia:
> ja klar, sollen wir gleich mal sprechen?

**2025-12-02T15:00:22.152519** - Julia:
> ich ruf dich gleich an :slightly_smiling_face:

**2025-12-02T15:07:12.420959** - Julia:
> 

**2025-12-03T11:34:01.956039** - Julia:
> Gut! Also LIDL war im Vergleich euphorischer und auch persönlicher. Aber kommt ja immer auf die Personen dahinter an, war also auch sehr gut. Bin sehr gespannt, was sie am Ende sagen

**2025-12-03T11:34:06.655449** - Julia:
> Bei dir alles okay? :slightly_smiling_face:

**2025-12-03T12:06:43.003739** - Julia:
> sehr gut

**2025-12-03T12:07:07.518579** - Julia:
> okay, good to know! Wir klären gerade noch ein paar Dinge bezüglich der Shootings. Wenn wir hier mehr wissen, gibts klare to-dos. ich melde mich :slightly_smiling_face:

**2025-12-04T16:29:27.878179** - Julia:
> Hi Marie :slightly_smiling_face: viel Spaß in Dublin!
Wir würden uns sehr freuen, wenn du am Dienstag mit zum Shooting kommst und uns unterstützt:

Treffpunkt: 8 Uhr (wenn du erst ab 10.30 kannst, auch kein Problem)
Die Adresse lautet:
Chris Hallhuber
Mauerkircherstr. 130, 81925 München

Wir werden sicherlich bis 19/20 Uhr vor Ort sein

**2025-12-17T12:25:02.855759** - Julia:
> Hi Marie! :slightly_smiling_face: sorry ich hatte leider einen kleinen Zwischenfall mit meinem Hund, deshalb war ich nicht am PC

**2025-12-17T12:25:07.672699** - Julia:
> Alles gut bei dir?

**2025-12-17T12:39:06.815939** - Julia:
> Sie hat sich heute morgen beim gassi gehen die Pfote aufgeschnitten :face_with_spiral_eyes: aber wird jetzt wieder

**2025-12-17T12:39:42.189389** - Julia:
> okay! :slightly_smiling_face:

**2025-12-17T12:40:07.122119** - Julia:
> Mert und ich schneiden gerade die Videos vom Shooting und müssen da teilweise noch den content sortieren bei den 700 videos :sweat_smile: das können wir aber gerne dann am Freitag durchgehen? :slightly_smiling_face:

**2025-12-17T12:41:55.528309** - Julia:
> yes! wollte heute eigentlich eben auch, aber bleib dadurch jetzt lieber daheim

**2025-12-17T12:42:21.547229** - Julia:
> danke! jaa, solange es sich jetzt nicht entzündet :face_exhaling:

**2025-12-17T18:56:16.991149** - Julia:
> Da habt ihr recht :slightly_smiling_face: dann sehen wir uns am freitag!

**2025-12-19T11:32:07.437699** - Julia:
> hello! Ich bin in den nächsten 20 Minuten da :) 

**2025-12-19T11:32:30.830389** - Julia:
> Können wir dann gerne gleich besprechen

**2025-12-19T12:04:10.933689** - Julia:
> <https://drive.google.com/drive/folders/1vPVCF7OjrfW2PtTRfZ-66nR1xRwHJqrf>

**2025-12-19T12:48:08.602689** - Julia:
> okay, mach ich! :slightly_smiling_face:

**2025-12-22T09:38:29.982939** - Julia:
> Hi Marie! :slightly_smiling_face: Hoffe dir gehts gut

**2025-12-22T09:38:47.491939** - Julia:
> Sag mal bekommst du die Codes für Gmail aufs Handy?

**2025-12-22T09:40:12.820659** - Julia:
> 40

**2025-12-22T09:41:15.519939** - Julia:
> jaaaa

**2025-12-22T09:41:18.853489** - Julia:
> vielen Dank!

**2025-12-22T09:41:27.989539** - Julia:
> Habs auch am Handy aber wurde irgendwie wieder ausgeloggt

**2025-12-22T09:44:15.858359** - Julia:
> danke dir :slightly_smiling_face:

**2025-12-22T09:44:23.655309** - Julia:
> bist du heute offline oder wärst du da?

**2025-12-22T09:45:01.342199** - Julia:
> Ahh okay, oh sorry

**2025-12-22T11:17:10.135719** - Julia:
> super danke dir!

**2025-12-22T11:18:21.847819** - Julia:
> ich hab dich bei 3 Asana Tasks markiert – hier wäre es suuuper, wenn du die briefings übernehmen kannst

**2025-12-22T11:18:31.844699** - Julia:
> wenn du Fragen hast, oder irgendwas nicht klappt, meld dich gerne!

**2025-12-22T12:45:19.327729** - Julia:
> Alles gut, garkein Stress

**2025-12-22T12:45:39.667569** - Julia:
> gerne wieder oben in die Beschreibung und dann Mert einmal taggen :slightly_smiling_face: dann kann er noch finale Anpassungen machen, wenn er möchte

**2025-12-22T12:45:47.527819** - Julia:
> Ja wir sind leider auch gerade überfragt

**2025-12-22T12:46:32.516789** - Julia:
> da sind so viele Fehler noch drin

**2025-12-22T12:46:55.621429** - Julia:
> ich kann das Hummus video gleich mal feedbacken. oder möchtest du? :slightly_smiling_face: das geht am besten direkt über <http://Frame.io|Frame.io>

**2025-12-22T12:48:56.193659** - Julia:
> ah okay, good to know! geb ich mal an Mert weiter

**2025-12-22T12:50:33.246939** - Julia:
> ja ist auch so. aber bei so vielen anpassungen :smile: puh

**2025-12-22T12:50:34.715379** - Julia:
> ja voll

**2026-01-12T12:35:36.628109** - Julia:
> Hi Marie! :slightly_smiling_face: Gehts dir guut?

**2026-01-12T12:35:48.275619** - Julia:
> Hast du heute etwas Kapa für mich?

**2026-01-12T12:37:03.867079** - Julia:
> auch!

**2026-01-12T12:37:16.562799** - Julia:
> hast du kurz Zeit, dann würde ich dich einmal anrufen?

**2026-01-12T12:56:00.271159** - Julia:
> <http://youtube.com/watch?si=WUN0h3LPnSfYqM0b&amp;v=rR4oIJiRp-g&amp;feature=youtu.be|youtube.com/watch?si=WUN0h3LPnSfYqM0b&amp;v=rR4oIJiRp-g&amp;feature=youtu.be>

**2026-01-12T13:02:12.641459** - Julia:
> Falls du noch Ideen hast zu Artists die cool passen könnten, außer:
• Cro
• SSIO
• Nina Chuba
• Ski Aggu
• Bill &amp; Tom (Georg + Gustav waren im Sommer bei ALDI)
• Marteria
• Zartmann
sag gern Bescheid :slightly_smiling_face: Solange sie nicht mit ALDI oÄ zusammenarbeiten

**2026-01-12T13:02:56.211619** - Julia:
> 

**2026-01-12T13:06:27.517969** - Julia:
> Tasks:
1) SSIO Video-Dreh: Komparsen??
2) Auswahl Artists + ggf. Konzept
3) Popcultural Moments (Späti Talk?)

**2026-01-12T13:06:56.429789** - Julia:
> Und hier das IT Piece das sich Flo &amp; Alex ausgedacht haben:
eine Kühltasche im Body Bag Look :smile:

**2026-01-12T13:13:44.355689** - Julia:
> in Bezug auf was? :slightly_smiling_face:

**2026-01-12T13:18:19.346709** - Julia:
> Achso ja klar, stell ich dir gleich zusammen. Gibts noch nicht sooo richtig

**2026-01-12T13:21:59.028249** - Julia:
> hab dir ein Dokument weitergeleitet, das waren meine ersten Ansätze/ Ideen.
Daraufhin hat Flo eine Datei erstellt --&gt; die frage ich gleich an, hab ich selbst noch nicht. (da steht auch diese Idee drin)
Du kannst bei diesem Worddokument von mir gerne weiterarbeiten und neue Tabs hinzufügen :slightly_smiling_face:

**2026-01-12T13:27:24.865229** - Julia:
> danke dir!

**2026-01-12T14:28:41.460429** - Julia:
> 

**2026-01-12T14:44:55.508589** - Julia:
> hier ist es von Flo:

**2026-01-12T18:06:27.555849** - Julia:
> Ich hab vorerst diese gewählt, gerne deinen Input noch dazu. In deiner Artist Liste habe ich ein paar Bemerkungen gemacht. Können wir gerne morgen früh direkt sprechen :slightly_smiling_face:

**2026-01-13T09:47:01.927029** - Julia:
> Hello! :slightly_smiling_face:

**2026-01-13T09:47:10.890629** - Julia:
> Ah okay :smiling_face_with_tear:

**2026-01-13T09:47:33.245019** - Julia:
> ich schreibs mal dazu

**2026-01-13T09:48:17.177339** - Julia:
> Hast du evtl eine Freundin oder Bekannte die Zeit und Lust hätte unser weibliches Model für den Videodreh zu sein? Wird natürlich vergütet und geht wie gesagt sehr schnell

**2026-01-13T09:51:22.459809** - Julia:
> • natürlich und "klassisch schöne"/attraktive Frau
• Mitte 20
• schlank/ sportlich, groß
• Haarfarbe oder Hauttyp spielt hier keine Rolle

**2026-01-13T09:54:49.815839** - Julia:
> also entweder wäre Donnerstag/Freitag super oder gleich Anfang nächsten Mittwoch

**2026-01-13T09:56:31.390729** - Julia:
> super danke! :slightly_smiling_face:

**2026-01-13T10:30:11.465089** - Julia:
> ah sorry :smile: getippt und währenddessen was anderes gedacht

**2026-01-13T10:30:47.238149** - Julia:
> Also entweder jetzt am Donnerstag/ Freitag (15. oder 16.1.) oder Mittwoch der 21.
am besten wäre Freitag

**2026-01-13T13:01:11.121049** - Julia:
> ach cool!

**2026-01-13T13:01:31.069349** - Julia:
> Super hübsch :slightly_smiling_face:

**2026-01-13T13:01:45.760129** - Julia:
> Also ginge bis 12.30 sowas?

**2026-01-13T13:02:06.880789** - Julia:
> Magst du mir ihren Namen noch verraten, dann packe ich sie mal in die Präsentation als Option

**2026-01-13T13:04:47.555319** - Julia:
> okay perfekt

**2026-01-13T13:04:50.242599** - Julia:
> danke dir! :slightly_smiling_face:

**2026-01-13T13:06:06.299709** - Julia:
> ich schicke Flo heute die Präsi und hoffe es kommt dann direkt Feedback

**2026-01-13T13:06:09.367319** - Julia:
> Also morgen auf jeden Fall

**2026-01-13T13:12:17.946619** - Julia:
> bin bei der LIDL Kampagne übrigens jetzt ein Stück weitergekommen

**2026-01-13T13:12:34.408729** - Julia:
> nicht Flo spoilern, falls du im Büro bist haha :shushing_face:

**2026-01-13T13:14:53.435339** - Julia:
> alles gut, ich schick dir hier gleich einen Auszug aus der Präsentation. ist leider eine offline Version, deshalb kann ich es nur so teilen

**2026-01-13T13:16:13.816229** - Julia:
> 

**2026-01-13T13:16:38.017699** - Julia:
> wie gesagt, wenn du noch Popcultural moments/ ideen hast: gerne her damit. Da bin ich momentan etwas lost :slightly_smiling_face:

**2026-01-13T13:23:39.265489** - Julia:
> ja? Okay das ist super. Weil genau das wär meine größte Sorge, es muss für Social passend sein 

**2026-01-13T13:23:47.301109** - Julia:
> Danke dir! 

**2026-01-13T13:34:55.780179** - Julia:
> Könnte deine Freundin auch Montag oder Dienstag? 

**2026-01-13T14:45:58.569919** - Julia:
> okay, danke!

**2026-01-13T14:46:18.293209** - Julia:
> FYI – ging eben an Flo raus, damit du auch up to date bist

**2026-01-13T15:14:34.288999** - Julia:
> ja genau, also ich würde so hautfarbene unterwäsche bestellen und wir legen dann im nachgang eh nochmal diese "Pixel" drüber :slightly_smiling_face:

**2026-01-13T15:14:58.430619** - Julia:
> leider keine Rückmeldung und ich gehe davon aus, dass es zu teuer ist wegen Drehgenehmigung

**2026-01-13T15:15:07.607449** - Julia:
> Ich geb dir bescheid, sobald ich Feedback von Flo hab

**2026-01-13T15:18:05.960599** - Julia:
> ja genau, das wäre von den Kosten wahrscheinlich genau das gleiche.
Also persönlich wäre auch für sowas, Flo wollte tatsächlich die leane/schnelle Variante an der Isar, let's see

**2026-01-13T15:20:31.942159** - Julia:
> 

**2026-01-13T15:24:50.836649** - Julia:
> alles gut, dann weiß ich Bescheid!

**2026-01-14T10:38:45.283999** - Julia:
> Hi Marie! Danke für die Info, die Videos hatte ich auch schon mal gesehen. Ich gebs mal an Flo weiter

**2026-01-14T10:38:52.617559** - Julia:
> danke für deine Aufmerksamkeit!

**2026-01-14T12:45:00.572439** - Julia:
> Du hast ja wahrscheinlich schon mit Marvin gesprochen oder?

**2026-01-14T12:45:14.888539** - Julia:
> Wir sind nämlich gerade dran neue Formate für SIXT zu überlegen

**2026-01-14T12:46:15.126489** - Julia:
> okay super

**2026-01-14T12:46:35.591029** - Julia:
> das wäre jetzt meine Task gewesen, ansonsten bin ich da auch gerade dran :slightly_smiling_face:

**2026-01-14T12:48:35.206269** - Julia:
> danke dir!

**2026-01-14T12:48:57.811589** - Julia:
> Könntest du mir die offene PPT Datei der Trendanalyse schicken?

**2026-01-14T12:49:05.380899** - Julia:
> Würde hier gerne was rauskopieren :slightly_smiling_face:

**2026-01-14T12:52:22.467329** - Julia:
> dankee!

**2026-01-14T12:52:25.522419** - Julia:
> Sehr cool aufbereitet

**2026-01-14T12:53:38.584659** - Julia:
> wir planen uns das jetzt gerade ein für Gorenje. Da wir spontan nach Dänemark fliegen am Montag/ Dienstag und hier die Handball EM begleiten. Also top!

**2026-01-14T12:53:53.175769** - Julia:
> bisher alles top :slightly_smiling_face: vielen Dank dir

**2026-01-14T12:56:32.297929** - Julia:
> gute Idee aber wir wollen es klar trennen

**2026-01-14T12:56:51.266489** - Julia:
> des mit den Wolken passt super, wenn wir ja auch im Flieger sitzen haha

**2026-01-14T13:39:42.712489** - Julia:
> Jaaa vooll!

**2026-01-14T13:39:57.740389** - Julia:
> Aber wir sind tatsächlich nichtmal 24 std. da also viel werden wir nicht sehen

**2026-01-14T13:40:15.119959** - Julia:
> Marie eine Kleinigkeit, die du mir vorbereiten könntest wäre super

**2026-01-14T13:42:40.453999** - Julia:
> ich würde gerne auf die Schlappen &amp; die Tasche jeweils das LIDL Logo kleben (einfach aus Papier). könntest du mir das im Büro schon mal ausdrucken? Ich komme morgen rein :slightly_smiling_face:
Größe: 1x 5cm und 1x ca. 8cm

**2026-01-14T13:44:50.322979** - Julia:
> danke dir!

**2026-01-14T13:52:46.091809** - Julia:
> das wäre ein traum!

**2026-01-14T13:58:10.893229** - Julia:
> ich danke dir :slightly_smiling_face:

**2026-01-27T16:11:25.366289** - Julia:
> Hello! :slightly_smiling_face: Also wenn du magst, fang gerne schon mal an. Ich bin gedanklich heute noch bei SIXT und würde morgen mal mit MINI weitermachen

**2026-01-27T16:11:33.051709** - Julia:
> Können gerne dann morgen dazu sprechen?

**2026-01-27T16:13:43.714859** - Julia:
> ja gerne erstmal trennen und für uns sortieren

**2026-01-27T16:18:26.924029** - Julia:
> danke dir!

**2026-01-28T09:05:35.041509** - Julia:
> Guten Morgen! Finde die Spread Smiles Idee wirklich super :slightly_smiling_face:

**2026-01-28T09:05:57.729829** - Julia:
> Human Mode finde ich sehr charmant gelöst – ich bin nur generell nicht von der Idee überzeugt, deshalb hänge ich hier noch etwas

**2026-01-28T09:24:12.280939** - Julia:
> ja genau

**2026-01-28T09:24:23.283839** - Julia:
> klar gerne, in 10 min?

**2026-01-28T09:31:40.078609** - Julia:
> okay bin ready. huddle oder lieber meet?

**2026-01-28T09:33:01.994559** - Julia:
> mit meet klappt es oft besser: <http://meet.google.com/wox-hqnm-mkh|meet.google.com/wox-hqnm-mkh>

**2026-01-28T11:30:37.441789** - Julia:
> Alles klar, ich schau es mir nach meinem Meeting an :slightly_smiling_face:

**2026-01-28T13:18:17.868499** - Julia:
> 

**2026-01-30T18:54:57.224039** - Julia:
> Marie, vielen lieben Dank für deine mega Arbeit für MINI! :heart_eyes: Ich hab sie hier und da noch etwas verfeinert und mit Flo besprochen – er weiß was von dir kommt &amp; ist super happy mit deiner Arbeit. Also vielen Dank dafür!

Ich bin jetzt dabei die Visuals dafür erstellen zu lassen, da ich es zeitlich auch nicht schaffe. Wenn du hier auch das ein oder andere Visual erstellen möchtest, lass uns gerne am Montag dazu sprechen.
Ansonsten hab ich dir noch eine weitere Asana Task erstellt – sag mir gern, ob du das kannst, sonst geb ich es weiter an Basti :slightly_smiling_face:

**2026-02-03T09:29:54.569869** - Julia:
> 

**2026-02-03T10:03:42.588659** - Julia:
> Gerne wo er spricht 

**2026-02-03T16:55:19.851229** - Julia:
> Uhhh, schau ich mir gleich in Ruhe an:heart_hands: Aber sieht so schon super aus, Danke dir! 

**2026-02-03T16:55:33.053989** - Julia:
> Mit was hast du es letzendlich geschnitten? 

**2026-02-03T16:56:55.198579** - Julia:
> Wow okay 

**2026-02-03T16:56:59.270859** - Julia:
> Danke dir! 

**2026-02-03T17:51:24.757439** - Julia:
> Ich bin morgen im Büro – bist du auch da? :slightly_smiling_face:

**2026-02-03T17:55:20.111899** - Julia:
> Ach mist, du Arme. Aber ja klar, das macht Sinn

**2026-02-04T10:46:30.236189** - Julia:
> Hi Marie! Sorry, mich hats heute morgen mit einer Migräne komplett zerlegt. Ich bin erstmal noch raus

**2026-02-04T10:46:32.033029** - Julia:
> aber danke dir!


---

### #D09U7C9S230 (328 messages)

**2025-11-20T17:54:47.125279** - Julia:
> Hi Marvin! :slightly_smiling_face:
Wir haben den Gorenje TikTok Account jetzt auch aufgesetzt und würden hier natürlich auch gerne den blauen Haken beantragen. Könntest du mir evtl. nochmal erklären, wie und wo ihr das gemacht habt? :smile:

**2025-11-20T17:54:49.500799** - Julia:
> danke dir!

**2025-11-20T17:56:56.634009** - Julia:
> ja easy, kein Stress!

**2025-11-21T13:27:32.462299** - Julia:
> Hello, hab noch eine weitere Frage: Julia meinte du hättest die Info nicht, Flo meinte doch :smile:
Es geht um die Kosten für den Dreh im Heimkinoraum. Könntest du mir hier grob sagen, wieviele Videos in welchem Zeitaufwand entstanden sind und was es ca. gekostet hat?
Danke

**2025-11-21T13:32:20.106309** - Julia:
> Okay, aber das hilft schon mal etwas weiter. ich danke dir!

**2025-11-21T13:33:27.975599** - Julia:
> alles gut, danke dir!

**2025-11-21T13:33:42.317479** - Julia:
> wegen blauen Haken können wir auch montags sprechen – hab auch noch genügend anderes

**2025-11-21T13:37:27.868179** - Julia:
> alles klar, meld du dich dann gerne einfach oder stell mir was ein. bin wahrscheinlich flexibler

**2025-11-25T10:49:22.253849** - Julia:
> Hey, hast du gegen 12.30 kurz Zeit?

**2025-11-25T11:01:22.103439** - Julia:
> okay super, dann huddle ich dich an

**2025-11-25T12:34:39.806179** - Julia:
> melde mich gleich

**2025-11-25T12:40:03.743439** - Julia:
> sorryy, Flo ist am Telefon

**2025-12-22T13:26:53.352349** - Julia:
> Hi Marvin! Hoffe dir geht es gut :slightly_smiling_face:

**2025-12-22T13:27:34.145849** - Julia:
> Flo möchte gerne, dass ich eine kleine Intro zum Thema Higgsfield/ AI gebe. Terminlich wäre heute 18Uhr sein Wunsch – da ich mir aber vorstellen kann, dass einige da schon nichtmehr available sind, frag ich lieber einmal nach

**2025-12-22T13:27:52.609779** - Julia:
> Sag gern Bescheid, ob dir das passt. Ansonsten würde ich morgen gegen 17 Uhr anpeilen

**2025-12-22T13:29:04.887179** - Julia:
> Okay, ja hab ich mir schon gedacht :smile: Mert passt es auch nicht und mir eigentlich auch nicht (weder heute noch morgen aber well)

**2025-12-22T13:29:12.388799** - Julia:
> er auch. Peru auch

**2025-12-22T13:30:33.701689** - Julia:
> ich hab noch keine Ahnung

**2025-12-22T13:31:19.075549** - Julia:
> 

**2026-01-07T09:12:13.095989** - Julia:
> Hi Marvin! Happy new year :slightly_smiling_face:
Yes, wahrscheinlich hast du auch mehr Infos als ich. Also gerne. Passt es dir um 12 Uhr?

**2026-01-07T09:15:37.791029** - Julia:
> lieb ich

**2026-01-07T09:15:41.007149** - Julia:
> ich stell schnell was ein

**2026-01-07T12:58:21.520059** - Julia:
> hab ich mir schon gedacht

**2026-01-07T13:51:12.015479** - Julia:
> Jana meinst du oder? :slightly_smiling_face:

**2026-01-07T13:51:17.856099** - Julia:
> Sie hat ihn jetzt auf morgen verlegt..?

**2026-01-07T13:51:35.844799** - Julia:
> ich kann da nicht, deshalb schwierig :smile:

**2026-01-07T13:53:10.852629** - Julia:
> sieht man ja eigentlich auch im Kalender aber okay

**2026-01-07T13:53:21.865249** - Julia:
> Wir können aber trotzdem gerne später kurz quatschen

**2026-01-08T14:58:13.014549** - Julia:
> Hi, kann dir in ca. 30 min weiterhelfen 

**2026-01-08T14:59:00.746929** - Julia:
> Bzw. Ist das dann meine Aufgabe? Oder wie lief das vorher bei euch ab?  

**2026-01-08T15:36:04.214079** - Julia:
> ah mist, sorry!

**2026-01-08T15:36:18.906189** - Julia:
> Flo wollte jetzt nochmal vorm Meeting mit mir sprechen

**2026-01-08T15:37:18.628109** - Julia:
> fingers crossed!

**2026-01-08T16:00:31.640579** - Julia:
> ah super, danke! :slightly_smiling_face: ja genau da haben wir eben drüber gesprochen

**2026-01-09T09:52:58.222449** - Julia:
> Hi! Hast du so gegen 11.30 nochmal kurz Zeit für mich bezüglich SIXT?

**2026-01-09T09:54:40.703259** - Julia:
> okay perfekt

**2026-01-09T14:39:45.184699** - Julia:
> okay

**2026-01-09T14:56:24.305659** - Julia:
> danke :slightly_smiling_face: ja ich muss das mal kurz sacken lassen über's Wochenende und meld mich dann am Montag direkt!

**2026-01-12T12:32:45.125039** - Julia:
> entschieden hab ich mich eigentlich nicht dafür, aber sieht Flo leider nicht so. also here I am

**2026-01-12T12:33:35.513589** - Julia:
> na super :smile:

**2026-01-12T12:34:09.414749** - Julia:
> ja hat er zu mir auch gesagt. aber ich hab 5 mal gesagt "ich will diese verantwortung nicht tragen, ich bin kein Projektmanager"

**2026-01-12T12:34:25.368839** - Julia:
> hat er nicht akzeptiert, weil er sagt das ist basic, das kann ich und hab ich ja auch schon gemacht

**2026-01-12T12:34:45.282939** - Julia:
> ich hab gesagt ich will nicht der Haupt-AP sein/ werden, soll ich aber nach und nach trotzdem

**2026-01-12T12:40:22.720319** - Julia:
> jetzt ruft er mich wieder an

**2026-01-12T12:46:59.393099** - Julia:
> 

**2026-01-13T12:01:28.425349** - Julia:
> bin in 2 min da!

**2026-01-13T14:48:05.311259** - Julia:
> klar, habs hier unter Videodreh – Skripte etc. sind noch nicht freigegeben von Flo, hab ich ihm eben geschickt. Die Grundidee mit dem FKK Video kam aber von Flo/ Alex

**2026-01-14T09:21:47.268639** - Julia:
> Hi! Yes, kam an :slightly_smiling_face: danke

**2026-01-14T09:22:08.172489** - Julia:
> Wissen sie denn schon von mir? Bzw. wurde ich schon in einer Form angekündigt? Bzgl. Vorstellung

**2026-01-14T09:23:10.149109** - Julia:
> Okay, ja gern. Würde es dann recht knapp halten und sagen ich unterstütze jetzt auch im Team – muss ja keinen Fokus nennen

**2026-01-14T09:23:49.755719** - Julia:
> Klar hat er das :smile:

**2026-01-14T09:23:51.804009** - Julia:
> So machen wir es

**2026-01-14T09:51:30.409809** - Julia:
> okay alles klar

**2026-01-14T09:51:44.206689** - Julia:
> sag mal wie heißt das Sixt Projekt in Clockify? Ich finde das nicht

**2026-01-14T10:46:56.380149** - Julia:
> kannst du um 11.45?

**2026-01-14T11:04:08.797179** - Julia:
> super, ich huddle dich dann gleich an

**2026-01-14T14:01:49.549079** - Julia:
> hänge im warteraum

**2026-01-14T15:03:07.902209** - Julia:
> perfekt

**2026-01-14T15:05:36.593619** - Julia:
> 

**2026-01-14T17:40:12.771169** - Julia:
> finde es sehr werblich

**2026-01-14T17:40:44.063849** - Julia:
> sie haben den pitch schon abgeschickt, also ändern wird eh schwierig

**2026-01-14T18:04:46.434709** - Julia:
> :smile:

**2026-01-14T18:04:54.963519** - Julia:
> Meinungen werden ja auch nicht unbedingt aufgenommen

**2026-01-14T18:05:11.861199** - Julia:
> Naja, ich muss jetzt pünktlich los! Ich meld mich morgen gleich bei dir :slightly_smiling_face: happy evening!

**2026-01-15T10:09:41.456229** - Julia:
> Hello! also ich hab jetzt die Präsi nochmal durchgelesen. Mein fav. Part wäre: 19-23 (also der Consistency Part)
Bezüglich Endslides hab ich tatsächlich das Gefühl, dass das eher bei Flo liegen sollte mit Versprechen usw. 

Hast du schon eine Meinung dazu? :slightly_smiling_face:

**2026-01-15T10:12:36.804469** - Julia:
> ja same :joy:

**2026-01-15T10:13:12.957019** - Julia:
> klaro 

**2026-01-15T12:49:47.531969** - Julia:
> hab ich mir schon gedacht. bin im büro und er hatte einmal deinen Namen gesagt. ist dann aber ins Nebenzimmer :smile:

**2026-01-15T13:10:52.818909** - Julia:
> oh wieso bad cop?

**2026-01-15T13:11:06.214039** - Julia:
> den schluss macht dann flo? oder sagen wir es ihm nochmal?

**2026-01-15T13:12:27.447339** - Julia:
> ich lande laut plan um 13.30. Wenn ich dazu kommen kann, klar. ich kann leider garnicht einschätzen wie es dort am Flughafen ist. Ist ein kleiner :smile:

**2026-01-15T13:12:41.333109** - Julia:
> also im Hotel oder so sind wir da noch nicht. Brauchen dort mit dem auto nochmal eine Std.

**2026-01-15T15:39:05.881729** - Julia:
> ja, ich probiers aber kanns wie gesagt nicht versprechen

**2026-01-15T15:42:48.462609** - Julia:
> wir könnten die option mit: wir wollen das nicht präsentieren auch mal noch versuchen :smile:

**2026-01-15T15:43:33.298879** - Julia:
> :sadblob:

**2026-01-16T09:32:23.295409** - Julia:
> Hello! Leider nein, wir drehen heute ab 11.30. Ich bin gleich nichtmehr am Laptop

**2026-01-16T09:32:37.948989** - Julia:
> ich weiß, dass Flo das super wichtig ist (und ist es ja auch) aber ich kann mich nicht 2teilen

**2026-01-16T09:33:34.314659** - Julia:
> okay, danke und sorry!

**2026-01-16T09:34:17.159859** - Julia:
> ja ich weiß. es ärgert mich einfach, dass da kein verständnis da ist bzw. die kapa planung einfach nicht bedacht wird oder whatever :smile: auch mit Montag

**2026-01-16T09:34:43.398459** - Julia:
> ja ich werd da nächste Woche auch nochmal was sagen

**2026-01-16T09:34:52.735659** - Julia:
> danke dir :heart_hands:

**2026-01-16T09:41:47.252399** - Julia:
> ja machen wir auch. aber trotzdem muss ich nach Dänemark hinfliegen und heute LIDL drehen, das meinte ich :slightly_smiling_face: manche Sachen muss man ja trotzdem machen

**2026-01-16T09:53:05.211959** - Julia:
> das ist meine neue Nummer: 015902014144
Für die whatsapp gruppen etc :slightly_smiling_face:

**2026-01-16T09:53:29.339889** - Julia:
> richte es gerade ein

**2026-01-16T09:55:27.449599** - Julia:
> 

**2026-01-16T09:55:42.465189** - Julia:
> okay cool! schau ich mir asap an :slightly_smiling_face:

**2026-01-16T16:46:39.764779** - Julia:
> Bin wieder da :slightly_smiling_face: Du hast mich noch zu keiner Gruppe eingeladen, oder? Nur falls es nicht geklappt haben sollte

**2026-01-16T16:47:40.995479** - Julia:
> alles gut haha

**2026-01-16T16:47:53.331509** - Julia:
> aber passt alles oder was passiert?

**2026-01-16T16:48:54.466359** - Julia:
> sehr witzig :joy:  hat alles gut geklappt und war nicht so kalt

**2026-01-16T16:49:40.576889** - Julia:
> richtig schön designt :smile:

**2026-01-20T11:26:12.478249** - Julia:
> Hello! Ne sind heute noch in Dänemark

**2026-01-20T11:49:09.516469** - Julia:
> wir können morgen davor sprechen. Du ich mach mir da garkeinen Stress, der soll ruhig merken, dass die Planung so nicht funktioniert

**2026-01-20T11:50:02.204639** - Julia:
> der wollte, dass Mert gestern im Flugzeug LIDL schneidet. obs ging oder ob er wie ein T-Rex dort saß? Also sorry, ich zieh ihm schon noch den Zahn von unrealistischen Erwartungen/ Timings

**2026-01-20T11:50:11.644719** - Julia:
> Ich weiß garnicht, für was der Termin morgen sein soll?

**2026-01-20T11:55:56.356519** - Julia:
> okay

**2026-01-20T11:56:15.791289** - Julia:
> ja dann lass uns gerne morgen vormittags sprechen?

**2026-01-20T11:58:41.110549** - Julia:
> Ah das hab ich noch nicht im Kalender :slightly_smiling_face:

**2026-01-20T12:12:55.246419** - Julia:
> yes! danke

**2026-01-20T13:00:10.567359** - Julia:
> btw: würdest du meine neue Nummer in die BCC Creative Whatsapp Gruppe reinnehmen?

**2026-01-20T13:11:34.946519** - Julia:
> Danke!

**2026-01-20T21:42:20.884699** - Julia:
> Für dich als Info: wir haben den Anschlussflug verpasst weil wir Verspätung hatten und sind jetzt in Amsterdam. der nächste Rückflug ist morgen Vormittag, kann also wieder nicht am Meeting um 11.30 Uhr teilnehmen. Lieben wir :face_exhaling:

**2026-01-21T07:16:09.898559** - Julia:
> Danke dir! 
Ja hat alles gut geklappt :) wenigstens das haha

**2026-01-21T13:20:21.056189** - Julia:
> Hi Marvin! Ich wäre jetzt am Laptop

**2026-01-21T13:20:25.878169** - Julia:
> Falls du etwas besprechen willst

**2026-01-21T13:20:54.847129** - Julia:
> Okay

**2026-01-22T15:32:33.532059** - Julia:
> Hello! Sollen wir morgen nach dem Check-In zum projektplan sprechen?

**2026-01-22T15:34:53.114669** - Julia:
> okay

**2026-01-22T15:34:59.401589** - Julia:
> alles klar

**2026-01-22T15:35:30.491029** - Julia:
> ich bin morgen ab 10 Uhr ca. am laptop, davor hab ich physio

**2026-01-22T15:45:49.066469** - Julia:
> ja wie gesagt von 10 irgendwas -11 garkein Stress

**2026-01-22T15:45:59.551899** - Julia:
> Oder danach, je nachdem was Jana einstellt haha

**2026-01-22T15:47:37.307199** - Julia:
> Mir ist beides Recht. Ich muss da nur etwas dagegen reden, weil er meine Anfrage ja komplett ignoriert und ich seh das nicht ein :smile: irgendwann reichts auch. Sowieso gestern wieder bis 20 Uhr

**2026-01-23T08:46:50.071949** - Julia:
> Hello! Es gibt noch keinen Termin von Jana oder? :sweat_smile:

**2026-01-23T08:47:12.337359** - Julia:
> Ja. Der Sinn würde mich da auch interessieren 

**2026-01-23T08:48:53.873049** - Julia:
> Ja hab ich mir schon gedacht. Hab eben alle Nachrichten durchgelesen 

**2026-01-23T08:49:42.979109** - Julia:
> Aber was sagt sie dazu? Oder ignoriert sie es? 

**2026-01-23T08:50:10.475649** - Julia:
> Das kann man einfach nicht machen 

**2026-01-23T08:50:28.313799** - Julia:
> Ahja oke 

**2026-01-23T08:50:32.165979** - Julia:
> :no_mouth:

**2026-01-23T09:52:24.244239** - Julia:
> okay ich beeile mich 

**2026-01-23T09:54:21.684059** - Julia:
> Alles gut. Macht Sinn :) 

**2026-01-23T09:54:47.950049** - Julia:
> Evtl bin ich 5 min später dran aber ich geb dir nochmal Bescheid 

**2026-01-23T10:12:26.973609** - Julia:
> oke, brauch noch paar Minuten! 

**2026-01-23T10:59:50.884359** - Julia:
> liebs auch einfach

**2026-01-23T11:00:17.547579** - Julia:
> Bin im Pitch mit drin, aber bekomme seit 2 Wochen keine Infos mehr, was die Kampagne ist oÄ. Aber den Content dazu musste ich erstellen :smile:

**2026-01-23T11:00:20.344209** - Julia:
> wegen montag

**2026-01-26T11:04:39.250939** - Julia:
> Hello! Mit 2 Std. Pitch schon etwas :smile: Aber können gerne um 11.30 sprechen?

**2026-01-26T11:24:05.002069** - Julia:
> Ich ruf dich gleich an, sobald der Call rum ist

**2026-01-26T12:03:40.966209** - Julia:
> Ah ganz vergessen!

**2026-01-26T12:03:56.348999** - Julia:
> hattest du noch mit Flo wegen Decathlon gesprochen?

**2026-01-26T12:04:02.158159** - Julia:
> Das kommt ja heute auch noch :face_with_peeking_eye:

**2026-01-26T12:05:11.184939** - Julia:
> Ah okay, aber das ist ja schon mal gut! Bzw. besser als die Hin-und Herfahrerei

**2026-01-26T12:44:12.823629** - Julia:
> Im Plan "Fahrer" sind die gemeint, die die Sixt Autos dann in den Videos fahren..?

**2026-01-26T12:44:25.538019** - Julia:
> oder wer soll das sein?

**2026-01-26T12:46:01.148969** - Julia:
> okay

**2026-01-26T12:46:09.323399** - Julia:
> aber sind das nicht die Creator dann?

**2026-01-26T12:46:15.270679** - Julia:
> verstehe den Punkt nicht ganz

**2026-01-26T12:46:26.509669** - Julia:
> ja

**2026-01-26T12:47:15.304039** - Julia:
> passt

**2026-01-26T15:52:46.092389** - Julia:
> Mir kam grad noch ein Gedanke für die sixt content reihen

**2026-01-26T15:53:26.075729** - Julia:
> ihr habt ja dieses Video gemacht mit der DB

**2026-01-26T15:55:20.177579** - Julia:
> Ah schade

**2026-01-26T15:57:53.407269** - Julia:
> Idee 1: DB Abklatsch: SIXT Serie mit Mitarbeitenden
Idee 2: Herzblatt/ Speed Dating in Auto

**2026-01-26T16:00:38.573849** - Julia:
> :no_mouth:

**2026-01-26T16:00:55.414459** - Julia:
> Okay okay

**2026-01-26T16:01:11.864649** - Julia:
> also Dating und Valentines Day wäre natürlich sehr passend

**2026-01-26T16:02:01.022209** - Julia:
> okay :smile: ich mach jetzt erstmal den Projektplan fertig

**2026-01-26T16:02:08.679019** - Julia:
> LIDL war leider nicht gut

**2026-01-26T17:39:57.284599** - Julia:
> So schau gerne mal in den Projektplan, obs für dich so Sinn ergibt

**2026-01-26T17:40:03.590479** - Julia:
> Timing ist SO KNAPP

**2026-01-26T17:41:45.537289** - Julia:
> ja können wir auvh

**2026-01-26T17:42:35.378599** - Julia:
> alles gut :smile: mache jetzt auch mal Decathlon

**2026-01-26T17:43:35.673049** - Julia:
> gut, dann mach ich meine eigene Präsentation :smile:

**2026-01-26T17:43:49.385109** - Julia:
> bau noch kurz eigene Slides ups :rolling_on_the_floor_laughing:

**2026-01-26T17:51:13.772629** - Julia:
> nicht wundern, das kann man alles aufklappen. würde es aber so gruppiert lassen, sonst erschlägt es einen

**2026-01-27T09:31:23.034689** - Julia:
> Guten Morgen!

**2026-01-27T09:31:30.399549** - Julia:
> Können wir unser Meeting um 11.30 starten?

**2026-01-27T09:31:42.876559** - Julia:
> Danke dir :slightly_smiling_face:

**2026-01-27T12:13:09.430509** - Julia:
> ich hab Marie Idee 2 mal geschickt für weitere Ideen7/ Skripte "Mittelweg von matcha und Haftbefehl"

**2026-01-27T12:17:19.813509** - Julia:
> hui

**2026-01-27T12:17:28.783609** - Julia:
> ist da immer so eine passiv aggressive stimmung?

**2026-01-27T12:20:09.270069** - Julia:
> 

**2026-01-27T12:27:19.639289** - Julia:
> okay

**2026-01-27T15:36:03.738979** - Julia:
> Marie hat die Ideen ausformuliert --&gt; Gibt es die Autos alle bei SIXT? Da hab ich keine Ahnung und sie hatte es nicht überprüft. Weißt du das?

**2026-01-27T15:38:46.696789** - Julia:
> oh nein, aber alles okay?

**2026-01-27T15:38:55.970779** - Julia:
> was meinst du welche Art und Weise?

**2026-01-27T15:39:19.594949** - Julia:
> Okay sehr gut, schau ich mir dann auch gleich an. Muss noch was anderes für Flo machen :no_mouth:

**2026-01-27T15:40:22.587539** - Julia:
> Oh nein, ja dann nimm dich bitte raus!

**2026-01-28T10:50:57.417159** - Julia:
> Hello! Hast du eine Idee wer der Moderator bei Carpool Karaoke sein könnte?

**2026-01-28T10:51:56.910539** - Julia:
> Ah okay, der auch als Moderator. dachte nur für den roast aber passt

**2026-01-28T10:52:47.812169** - Julia:
> du ich bin noch nicht mal so weit. ich bin bei der videoerstellung für Love is blind seit 2 std. also wie gesagt das dauert :smile:

**2026-01-28T10:54:49.243209** - Julia:
> 

**2026-01-28T10:55:24.888489** - Julia:
> oder so!

**2026-01-28T11:14:51.641769** - Julia:
> kurze Frage: bisher habt ihr auch noch kein proforma Asana Board?

**2026-01-28T11:16:41.569429** - Julia:
> okay ja da hab ich keinen Zugriff

**2026-01-28T11:16:51.306589** - Julia:
> okay verstehe

**2026-01-28T11:17:03.628409** - Julia:
> ja ich erstell die Tasks für Basti dann mal so

**2026-01-28T11:17:47.261209** - Julia:
> ne, hab sie auch schon 2 mal gefragt

**2026-01-28T11:18:00.768669** - Julia:
> dankee habs!

**2026-01-28T11:23:14.390279** - Julia:
> und der verlinkte Ordner in Drive ist leer :no_mouth:

**2026-01-28T11:23:23.898529** - Julia:
> oder ich kanns auch immer noch nicht sehen

**2026-01-28T11:23:41.151469** - Julia:
> okay dankee

**2026-01-28T11:23:57.778409** - Julia:
> ja genau, ich muss ihm ja die ganzen snippets ablegen

**2026-01-28T11:56:09.175649** - Julia:
> lass uns gleich noch sprechen, schreibe grad mit Flo

**2026-01-28T12:39:46.519539** - Julia:
> gibt es irgendeinen Promi den SIXT mega feiert? oder influencer?

**2026-01-28T12:45:34.481149** - Julia:
> Ah cool

**2026-01-28T12:46:14.642299** - Julia:
> also ich sags dir ehrlich: ich mach das so nicht weiter :smile:

**2026-01-28T12:47:01.401809** - Julia:
> Ja

**2026-01-28T12:48:12.618399** - Julia:
> Ne als Marvin sorry

**2026-01-28T12:48:16.766059** - Julia:
> Auf garkeinen Fall

**2026-01-28T12:48:32.319319** - Julia:
> Flo soll Leute einstellen die ihre Expertise ausleben können/ dürfen fertig

**2026-01-28T12:48:53.935679** - Julia:
> Ja aber das macht doch keinen Sinn?

**2026-01-28T12:50:41.725899** - Julia:
> Ja

**2026-01-28T12:52:32.316799** - Julia:
> • Anything or nothing --&gt; entweder mache ich das komplett, aber dann bin ich bei allen anderen Themen raus das SIXT betrifft oder Übergabe an Julia H.
• Werkstudentin --&gt; für was? Wir brauchen erfahrene Leute, niemanden den wir ein lernen müssen

**2026-01-28T12:53:40.582419** - Julia:
> ich kann und werde dich nicht covern mit Themen die ich sowieso nicht kann/ weiß + daily business + Kampagne

**2026-01-28T12:53:49.804199** - Julia:
> ganz genau

**2026-01-28T12:57:36.604319** - Julia:
> Punkt 1:

**2026-01-28T12:59:25.817819** - Julia:
> 

**2026-01-28T13:03:43.492449** - Julia:
> total

**2026-01-28T13:04:14.134519** - Julia:
> also in Summe ist es ja so:
Ein Kanal on top und du für einen bestimmten Teil down --> das geht nicht :D

**2026-01-28T13:04:40.530569** - Julia:
> muss kurz mit dem hund raus, bis gleich!

**2026-01-28T13:42:12.991289** - Julia:
> süß

**2026-01-28T14:23:25.873649** - Julia:
> ja wirklich!

**2026-01-28T14:23:48.240399** - Julia:
> total, wie gesagt die hat schon sooo viele Produktionen geleitet, da sind meine ein Witz dagegen und dann ist der Block einfach weg

**2026-01-28T14:26:27.140889** - Julia:
> genau

**2026-01-28T14:26:40.436549** - Julia:
> Oh je, Jana hat die Präsentation ja ganz anders aufgebaut :smile:

**2026-01-28T18:02:42.969269** - Julia:
> :joy:

**2026-01-28T18:02:52.217899** - Julia:
> Was zur Hölle, soll das für eine Sprache sein

**2026-01-28T18:03:40.376389** - Julia:
> jaa

**2026-01-28T18:03:47.248339** - Julia:
> deutsch kann die AI einfach noch nicht :smile:

**2026-01-28T18:35:21.586969** - Julia:
> So hier der Status Quo. Genauso hatten wir es damals bei Porsche. Siehst ja was noch frei ist bei den Content INhalten. Textlich gerne auch noch anpassen was dir fehlt etc.
Würde dann bei der finalen Version die Videos einbauen (Basti ist dran), macht jetzt mit dem Hin und Her schicken von Präsis keinen Sinn :slightly_smiling_face:

**2026-01-28T18:35:26.226429** - Julia:
> happy feierabend!

**2026-01-28T18:35:42.567699** - Julia:
> hier noch die Videos die basti noch bearbeitet: <https://drive.google.com/drive/folders/1ipOCItOdJLWuxEmdd24BM21TNdt5McKR>

**2026-01-28T18:36:30.232649** - Julia:
> würde Jana gegen mittags gerne die Präsi schicken, damit sie diese Slides in ihre Version baut bzw. anpasst. Sonst macht die Präsi keinen Sinn

**2026-01-29T09:36:41.994299** - Julia:
> Guten Morgen

**2026-01-29T09:47:40.255299** - Julia:
> Konntest du dir schon die Präsi anschauen?

**2026-01-29T09:48:31.649499** - Julia:
> Ja alles gut, kein Stress!

**2026-01-29T09:57:45.224349** - Julia:
> moment ich schau kurz

**2026-01-29T09:58:56.035769** - Julia:
> Das interaktive Quiz? Also sollen wir nur die Variante mit RSA nehmen?

Ja genau, würde da viel zu erzählen. Also die Beispiele dann einfach sagen. Können wir ja easy in die Besprechungsnotizen packen

**2026-01-29T09:59:20.619859** - Julia:
> Du kannst auch gerne einfach Kommentare hinzufügen und ich packe die restlichen Sachen noch rein

**2026-01-29T09:59:54.905529** - Julia:
> Ne, habs nur noch nicht visuell angepasst

**2026-01-29T10:00:13.022939** - Julia:
> mir auch noch nicht. aber setze ich mich jetzt dran :smile:

**2026-01-29T10:00:41.349539** - Julia:
> ahhhh

**2026-01-29T10:00:50.363989** - Julia:
> ist mir durchgerutscht

**2026-01-29T10:00:52.003269** - Julia:
> danke!

**2026-01-29T10:02:17.609009** - Julia:
> alright

**2026-01-29T10:02:20.878639** - Julia:
> Oh nein, Mist!

**2026-01-29T10:02:36.158049** - Julia:
> Ja klar, mach. Ich kümmere mich um die Slides

**2026-01-29T10:04:31.259509** - Julia:
> obs stressig ist :smile:

**2026-01-29T10:04:38.844139** - Julia:
> alles gut, ich schau mal und schicks dir dann wieder

**2026-01-29T10:04:40.454049** - Julia:
> danke!

**2026-01-29T10:42:22.312749** - Julia:
> Fällt dir eine Persönlichkeit ein, die krass wäre für den Carpool Roast mit Zach?

**2026-01-29T10:44:43.580449** - Julia:
> für den normalen Carpool Talk hätte ich Bill Kaulitz gewählt. Ist ja auch in USA bekannt.
Aber für den Roast wollte ich gerne noch jemand krasseren, genau

**2026-01-29T10:45:26.775369** - Julia:
> okay

**2026-01-29T10:46:04.074889** - Julia:
> Marvin!

**2026-01-29T10:46:07.248129** - Julia:
> Sell the dream!!

**2026-01-29T10:46:10.207169** - Julia:
> :smile:

**2026-01-29T10:46:29.840589** - Julia:
> Ja, hab's als Monthly rein

**2026-01-29T10:51:03.874079** - Julia:
> Jaa nehm ich mit auf

**2026-01-29T10:51:09.180469** - Julia:
> danke!

**2026-01-29T11:07:02.250379** - Julia:
> (Flo kennt das Video von LIB schon)

**2026-01-29T11:07:22.989469** - Julia:
> und ist ja leider auch nur paar Sekunden, dann wird es verhauen

**2026-01-29T12:44:28.836209** - Julia:
> hatte für Pranked jetzt noch eine andere Idee

**2026-01-29T12:45:35.210159** - Julia:
> Ja ich auch :smile:

**2026-01-29T13:28:34.378829** - Julia:
> puh

**2026-01-29T13:39:11.505959** - Julia:
> 

**2026-01-29T15:52:03.272569** - Julia:
> das wusste ich auch nicht

**2026-01-29T15:52:12.222899** - Julia:
> denke das geht auch nicht, weil Jana sicher die Präsi noch nicht fertig hat

**2026-01-29T15:53:26.663689** - Julia:
> Entweder abwechselnd oder ich stell alles vor oder du stellst "deine" ideen vor:
• beat the rsa
• AI tipps
• ride n roast
• Kesslers Knigge

**2026-01-29T15:53:28.461879** - Julia:
> you decide

**2026-01-29T15:54:57.385339** - Julia:
> okay. dann du deine?

**2026-01-29T15:55:07.638419** - Julia:
> passt!

**2026-01-29T15:55:24.382629** - Julia:
> liebs ja, dass man keine Sekunde Zeit hat irgendwas zu üben :smile:

**2026-01-29T15:58:12.913119** - Julia:
> ne

**2026-01-29T15:58:39.545979** - Julia:
> er wollte eigentlich auch, dass ich morgen Decathlon vor ihm nochmal präsentiere mit meiner Verbesserung – i doubt it :smile:

**2026-01-29T15:59:35.797339** - Julia:
> ja, weil er meinte, ob ich ins Büro kommen kann

**2026-01-29T15:59:37.265579** - Julia:
> ich auch nicht

**2026-01-29T16:13:26.738169** - Julia:
> aber wie unnötig ist es auch eine Präsentation zu präsentieren, die wir uns noch nicht zusammen angeschaut haben

**2026-01-29T16:40:00.793149** - Julia:
> haben wir eine strategie, wenn sie alle Formate scheiße finden? :smile:

**2026-01-29T17:16:59.844779** - Julia:
> Willst du jetzt nochmal sprechen oder lieber morgen früh direkt?

**2026-01-30T10:32:35.011869** - Julia:
> er versteht es einfach niiiicht :smile:

**2026-01-30T10:41:04.011359** - Julia:
> ja und das geht einfach nicht

**2026-01-30T10:41:14.135369** - Julia:
> auch die visuals in 5 minuten erstellen – nein das geht nicht

**2026-01-30T10:41:42.180709** - Julia:
> ja ich weiß

**2026-01-30T10:47:16.557739** - Julia:
> den IG Workshop vllt?

**2026-01-30T10:47:20.351939** - Julia:
> :smile:

**2026-01-30T10:48:29.738399** - Julia:
> ja whatever

**2026-01-30T10:48:42.746149** - Julia:
> "euer erster Pitch" Ja ich hab nie gesagt, dass ich das machen will? :smile:

**2026-01-30T10:48:54.778059** - Julia:
> Und ist auch nicht mein erster Pitch. Aber so wie er ihn gerne hätte

**2026-01-30T11:01:32.025619** - Julia:
> Ja versteh ich zu 10000%

**2026-01-30T11:01:33.795329** - Julia:
> Das ist so krank

**2026-01-30T11:01:43.192069** - Julia:
> Marvin kurze andere Frage:

**2026-01-30T11:02:01.409899** - Julia:
> sieht man hier schon, dass es kein BMW ist? ich kenne mich nicht aus :smile:

**2026-01-30T11:05:03.028039** - Julia:
> okay, ja wenn ich es anpasse dann richtig :smile:

**2026-01-30T12:07:21.316639** - Julia:
> Muss jetzt leider nochmal zum Tierarzt, meinem Hund gehts richtig schlecht. Also mache kurz "Lunch Break" Bis gleich!

**2026-01-30T13:19:11.590719** - Julia:
> Danke :heart_hands:

**2026-01-30T13:19:27.123979** - Julia:
> also Jana ist nicht ganz auf der Höhe oder? 

**2026-01-30T13:34:24.927229** - Julia:
> würd ich auch sagen :smile:

**2026-01-30T13:34:53.181529** - Julia:
> bisher nicht, aber hat jetzt alles mögliche gespritzt bekommen, sollte also bald besser werden. War aber auch einfach eine krasse OP, also verständlich

**2026-01-30T13:34:56.773259** - Julia:
> danke der Nachfrage!

**2026-01-30T14:41:22.985939** - Julia:
> hab mir Decathlon noch nicht durchgelesen :smile: du?

**2026-01-30T14:41:31.144909** - Julia:
> SIXT AoN – kann ich dir da schon was bauen?

**2026-01-30T15:11:41.469089** - Julia:
> Sorry bin grad kurz bei MINI

**2026-01-30T15:12:04.950019** - Julia:
> alles klar. Dann übernimmst du die Folie oder ich? Ich kann ja LIB erzählen und dann übernimmst du mit der Übersicht?

**2026-01-30T15:12:23.867639** - Julia:
> ja..

**2026-01-30T15:12:28.865539** - Julia:
> okay

**2026-01-30T16:30:41.729909** - Julia:
> ja hab ich mir auch gedacht

**2026-01-30T19:02:02.214719** - Julia:
> happy weekend trotz allem und hoffentlich ein bisschen Ruhe!

**2026-02-02T09:18:30.980839** - Julia:
> Guten Morgen :slightly_smiling_face:

**2026-02-02T09:28:04.387269** - Julia:
> Hattest du ein schönes Wochenende?

**2026-02-02T09:30:20.127479** - Julia:
> Ja same. Gefühlt war gestern erst Freitag :smile:

**2026-02-02T09:30:43.321579** - Julia:
> Wird langsam, waren jeden Tag beim Tierarzt/ Klinik aber heute sieht es ganz gut aus :slightly_smiling_face:

**2026-02-02T09:46:33.248759** - Julia:
> Dankeee

**2026-02-02T10:09:00.802979** - Julia:
> also ich weiß ja nicht, ob die Präsi heute was wird :smile:

**2026-02-02T11:29:51.194199** - Julia:
> ja genau

**2026-02-02T11:48:57.247789** - Julia:
> boah

**2026-02-02T11:49:05.359899** - Julia:
> sie hat ja quasi garnichts gemacht

**2026-02-02T11:49:25.626689** - Julia:
> slides alle noch alt vom look her

**2026-02-02T11:49:30.222689** - Julia:
> Texte einfach reinkopiert

**2026-02-02T12:49:08.634519** - Julia:
> wahnsinn

**2026-02-02T12:49:21.470259** - Julia:
> Marvin welches Auto hab ich bei Opa Werner nochmal? :smile: Bzw. was könnte das sein?

**2026-02-02T12:51:49.027549** - Julia:
> yes moment

**2026-02-02T12:52:12.887499** - Julia:
> <https://drive.google.com/drive/folders/1aLCz7CZkdJOu_PQiBQh9GxUdMamSHJdt>

**2026-02-02T12:52:34.742969** - Julia:
> also ich muss nur wissen, wenn ich jetzt sag: er wird dann im Benz zum oberrapper – nicht, dass es klar erkennbar der bwm x irgendwas ist

**2026-02-02T12:53:01.708939** - Julia:
> ach scheiße

**2026-02-02T12:53:07.454479** - Julia:
> sorry dachte da kommt direkt der link

**2026-02-02T12:53:10.851469** - Julia:
> okay

**2026-02-02T12:54:04.445909** - Julia:
> wunderbar

**2026-02-02T12:54:55.319289** - Julia:
> OKAY

**2026-02-02T12:54:58.236619** - Julia:
> sorry :smile:

**2026-02-02T12:55:02.785039** - Julia:
> okay, ja gerne

**2026-02-02T12:55:23.656009** - Julia:
> in 5min?

**2026-02-02T16:27:01.435329** - Julia:
> wie ist dein Gefühl?

**2026-02-02T16:35:45.007319** - Julia:
> yes machen wir

**2026-02-02T17:39:59.477429** - Julia:
> Danke dir 

**2026-02-02T17:40:14.231939** - Julia:
> Bin leider noch immer unterwegs 

**2026-02-12T10:53:50.652849** - Julia:
> Hello! :slightly_smiling_face: Also ich richte mich nach dir wegen der Übergabe. Morgen nachmittag passt für mich auch? Also sag du gerne wann es dir passt!

**2026-02-13T09:06:04.402929** - Julia:
> Guten morgen, magst du mir einfach in WhatsApp schreiben, sobald du was weißt? :slightly_smiling_face: Dann übersehe ich es nicht. Bin ja nicht dauernd am Laptop

**2026-02-13T09:10:15.981689** - Julia:
> Uhh hoffe es ist alles gut! :crossed_fingers:

**2026-02-13T09:10:46.023159** - Julia:
> Ja sag einfach bescheid, wenns heute zu stressig ist, können wir das natürlich auch am Sonntag oder so machen. Morgen bin ich nur (endlich wieder) nicht daheim und unterwegs :slightly_smiling_face:

**2026-02-13T09:12:12.398869** - Julia:
> Nenene ab nächster Woche bist du im Baby Fokus

**2026-02-13T09:43:48.218889** - Julia:
> okay

**2026-02-13T14:35:21.211509** - Julia:
> wie siehts bei dir aus? :slightly_smiling_face:

**2026-02-13T14:42:25.158709** - Julia:
> okay. was ist dir denn am liebsten? Sollen wir DI/ MI morgens gleich direkt halbe Tage dafür blocken?

**2026-02-13T14:51:10.298239** - Julia:
> okay

**2026-02-13T15:26:40.685679** - Julia:
> hat irgendwie nicht geklappt

**2026-02-13T15:26:41.313379** - Julia:
> moment


---

### #D0A05HAPK1R (106 messages)

**2025-11-28T09:28:32.281539** - Julia:
> Hi Anna! wollte mich gerade melden

**2025-11-28T09:30:10.157369** - Julia:
> Tatsächlich nein, ich weiß nicht genau was er damit meint, da kannst du mich leider nicht unterstützen. Allerdings benötigen meine Kolleginnen Julia Hallhuber und Mert Unterstützung beim Kunden Hisense/Gorenje, da ich hier heute nicht aushelfen kann

**2025-11-28T09:31:19.374459** - Julia:
> Ich connecte euch

**2025-11-28T09:35:14.461379** - Julia:
> ich ruf ihn an

**2025-11-28T09:50:07.271629** - Julia:
> 

**2025-11-28T09:56:42.565519** - Julia:
> Bevorzug gerne die Bilder bei denen man das OMR Logo auch sieht oder wir photoshoppen es dann nochmal rein

**2025-11-28T10:19:45.022299** - Julia:
> yes, erstelle ich dir gleich 

**2025-11-28T11:11:01.768209** - Julia:
> links müsste man wahrscheinlich etwas zuschneiden wegen den blau/gelben wohnmobilen

**2025-11-28T11:12:44.398349** - Julia:
> 

**2025-11-28T11:14:04.951349** - Julia:
> sehr gerne! bin bis 12 Uhr in einem Meeting, melde ich danach wieder :slightly_smiling_face:

**2025-11-28T11:14:08.427639** - Julia:
> danke dir!

**2025-11-28T11:27:19.545209** - Julia:
> hiermit könnten wir noch social Posts faken beispielsweise

**2025-11-28T12:46:10.355409** - Julia:
> Kommst du voran? Alles gut?

**2025-11-28T13:41:22.992499** - Julia:
> sehr cool! Eine Kleinigkeit "Lidl" schreibt sich selbst nicht in Caps also nicht "LIDL". Würde deshalb eher bei der Schreibvariante Lidl bleiben. Bei dem Visual kann ich es leider nicht gut austauschen, aber sollten es bei den Headlines der Zeitschriften richtig haben

**2025-11-28T13:41:51.634529** - Julia:
> von Anna Arndt vllt? :slightly_smiling_face:

**2025-11-28T13:41:58.620709** - Julia:
> 

**2025-11-28T13:43:03.858519** - Julia:
> als kleiner Schmunzler – solche Tricks kann man immer einbauen :slightly_smiling_face:

**2025-11-28T13:57:50.495889** - Julia:
> super cool!

**2025-11-28T13:58:11.295959** - Julia:
> leider noch nicht, aber ich schicke dir schon mal die anderen Bilder:

**2025-11-28T14:00:05.942029** - Julia:
> 

**2025-11-28T14:00:36.719229** - Julia:
> 

**2025-11-28T14:02:53.334439** - Julia:
> 

**2025-11-28T15:44:06.738939** - Julia:
> sehr cool! :slightly_smiling_face:

**2025-11-28T15:47:56.867829** - Julia:
> du könntest noch das "Gefällt" mir als aktiviert anzeigen. Glaube das ist dann blau

**2025-11-28T15:49:16.283209** - Julia:
> beim 2. würde ich schreiben "..Hamburg ist während der OMR komplett überlastet: nicht genügend Betten für den Ansturm

**2025-11-28T16:08:59.052249** - Julia:
> 

**2025-11-28T16:48:22.482749** - Julia:
> Was genau sind UGC Mockups?

**2025-11-28T16:48:33.402309** - Julia:
> Für IG, TikTok?

**2025-11-28T16:48:41.180019** - Julia:
> Stills oder Video?

**2025-11-28T17:02:32.183969** - Julia:
> Nene ich weiß was UGC ist aber ich meinte was UGC Mockups sein sollen :slightly_smiling_face: Instagram Handles also

**2025-11-28T17:04:40.389219** - Julia:
> wir können es probieren. Schwierigkeit liegt dabei, dass die Person von der 100% übernommen wird. Bei Matthias ist das das beste Ergebnis

**2025-11-28T17:05:37.283849** - Julia:
> das evtl noch, richtig zugeschnitten:

**2025-11-28T17:25:28.247899** - Julia:
> Hier Ben und Opa Werner

**2025-11-28T17:29:22.611149** - Julia:
> hier noch innen drin, das hatte erst nicht geklappt

**2025-11-28T17:36:10.299319** - Julia:
> danke dir! ein tolles wochenende :slightly_smiling_face:

**2025-12-04T08:43:03.210899** - Julia:
> Guten Morgen Anna! 
Hast du um 10 Uhr Zeit für ein kurzes Meeting? 

**2025-12-04T09:59:31.694749** - Julia:
> Ruf dich gleich an :slightly_smiling_face: Ne geht darum

**2025-12-04T10:07:41.612019** - Julia:
> 

**2025-12-04T10:12:46.409369** - Julia:
> *WOHNWÄGEN:*
• 40 (50) Stück während der OMR 2026 in Hamburg
• Anbieter: einer oder über mehrere? --&gt; Machbar? Kosten?
• Wie sehen diese Wohnwägen im Roh Zustand aus?
• Design: Folierung (Außen) --&gt; Machbar? Kosten?
• Design: Interieur/ Umbau --&gt; Machbar? Kosten?
• Campingplatz: wo können die Wohnwägen am Ende stehen?
• Alle Infos die du findest helfen uns schon weiter :slightly_smiling_face: 
• Benötigt man eine Genehmigung für die Stadtfahrten? Wenn eine 300m lange Wohnwagen Karavane den Straßenverkehr blockiert
Danke dir!

**2025-12-04T10:59:11.070909** - Julia:
> Könntest du bei Gelegenheit mal checken, ob ein Paket von Hisense angekommen ist? Gorenje müssten 3 Stück sein. Aber wir warten noch auf ein Produkt seitens Gorenje :slightly_smiling_face:

**2025-12-04T12:00:47.010839** - Julia:
> okay danke dir

**2025-12-04T12:01:21.753649** - Julia:
> ja frag  gerne an. Hier bitte beachten: keine konkrete Nennung von LIDL, sondern eher von einem großen Kunden sprechen

**2025-12-04T13:47:12.715719** - Julia:
> danke dir!

**2025-12-04T14:55:42.268289** - Julia:
> cool, danke dir!

**2025-12-04T14:56:15.470249** - Julia:
> Die Kosten für die Außenfolierung hattest du jetzt nicht nochmal extra recherchiert, sondern über die Wohnmobil Vermietungen angefragt?

**2025-12-04T14:56:31.903679** - Julia:
> klar verständlich

**2025-12-04T16:18:57.329839** - Julia:
> die erste Absage kam ja sogar schon rein

**2025-12-04T16:19:33.193709** - Julia:
> falls du es eh noch nicht gemacht hast: markiere gerne in dem Dokument die Absagen und den Status der Anfragen

**2025-12-04T16:22:02.906329** - Julia:
> Und könntest du nochmal zusammenrechnen (mit den Informationen die wir haben) wieviel grob ein Wohnmobil kostet mit allem (Folierung, Fahrer, Parkgebühren, generelle Gebühren...) danke! :slightly_smiling_face:

**2025-12-04T17:14:40.249959** - Julia:
> Ah magst du mir das einmal markieren/ mich kommentieren? Dann hab ich es übersehen. Danke dir!

**2025-12-05T09:05:57.292319** - Julia:
> Guten Morgen! Danke dir :) bin auch gleich da 

**2025-12-05T18:49:23.973059** - Julia:
> Hallo Anna, vielen Dank dir für die tolle Arbeit! Sehr sehr cool. Ich kann mir das alles nach unserem Shooting in Ruhe angucken

**2025-12-05T18:49:32.154579** - Julia:
> Hab ein schönes Wochenende :slightly_smiling_face:

**2026-01-08T17:08:47.027889** - Julia:
> Hi Anna! :slightly_smiling_face: Dankee, das wünsche ich dir auch

**2026-01-08T17:09:23.977559** - Julia:
> ja genau, sehr gut! War eben noch im Meeting deshalb kam ich nicht dazu

**2026-01-08T17:09:50.424409** - Julia:
> Sollen noch kurz sprechen oder lieber morgen?

**2026-01-08T17:12:25.117919** - Julia:
> dann gerne jetzt noch!
 <https://meet.google.com/rgm-vdeq-ord>

**2026-01-08T17:12:59.377559** - Julia:
> klaro

**2026-01-08T17:16:52.725469** - Julia:
> 

**2026-01-09T09:36:37.965179** - Julia:
> Guten Morgen!

**2026-01-09T09:38:57.901569** - Julia:
> Ne, sag gerne ein internes Pitch Video mit einer Länge von 30-40 Sekunden
Datum Mitte/Ende nächster Woche oder direkt Montag/Dienstag KW4
Dauer des Drehs schätze ich mal auf maximal 2 Std. (mit allem drum herum)

**2026-01-09T09:42:43.462969** - Julia:
> "Mandy" soll ja quasi stellvertretend für einen Crush sein, deshalb würde ich sagen eine natürlich und "klassisch schöne"/attraktive Frau, Ende 20, Blond oder Brünett spielt hier jetzt keine Rolle, schlank/ sportlich, groß

**2026-01-09T09:43:23.166659** - Julia:
> Wenn es bei den Seiten auch eine Auswahl gibt, kannst du mir sehr gerne auch ein paar Profile zur Auswahl schicken, dann suchen wir uns hier welche raus und können genau sagen, wen wir bräuchten

**2026-01-09T09:56:43.675919** - Julia:
> Ja hast du Recht aber ich seh was du meinst, würde sagen die sind alle "okay"

**2026-01-09T09:57:08.243379** - Julia:
> Bisheriger Favorit: Brian von Lachfalten

**2026-01-09T09:59:01.242249** - Julia:
> ich melde mich gleich nach meinem Meeting. Ich frage mich ob der Aufwand für zB Brian der aus Köln ist, für die 2 Std Dreh dann auch relevant ist
Also wenn wir Münchner finden, wäre super

**2026-01-09T12:23:16.669649** - Julia:
> super, schau mir jetzt alle an :slightly_smiling_face:

**2026-01-09T12:37:38.248639** - Julia:
> Lachfalten: Daria, Amelia
fameonme: Brian --&gt; der könnte genau den richtigen Humor mitbringen für diese Art von Video, Laura D., Caroline N.

--&gt; die gerne mal anfragen!

**2026-01-09T12:39:55.555119** - Julia:
> Eckdaten:
• Halber Drehtag in München
• KW3 oder KW4
• höchstwahrscheinlich Outdoor, evtl. Indoor (sowas wie Therme Erding könnte man überlegen)
• Dreh ist für einen internen Pitch
• Social Media Format// also gerne Humor mitbringen
• gerne schon vorab sagen: Badekleidung/ Unterwäsche (wird natürlich von uns gestellt)

**2026-01-09T12:42:18.841479** - Julia:
> danke dir!

**2026-01-09T13:08:00.128129** - Julia:
> Kam Aran über Flo? Brian ist raus?

**2026-01-09T13:10:11.304869** - Julia:
> ah sorry mein Fehler, habs verwechselt. Brian ist ja von Lachfalten

**2026-01-09T14:45:36.671719** - Julia:
> super danke

**2026-01-09T14:48:49.804289** - Julia:
> Magst du auf die Absage einmal antworten:
• dass der Dreh natürlich so kurz wie möglich statt findet und wir realistisch max. 2 Std benötigen
• wir natürlich für warme Mäntel, Heißgetränke usw. sorgen ("da wir ja auch nicht frieren möchten") und die Darsteller:innen immer nur kurz in Unterwäsche wären
• zudem wir gerade noch die Option mit Indoor klären
Bei fame on me:
• einmal erklären, dass das video nur für interne Zwecke genutzt wird und wir also keine SoMe Nutzung brauchen
• dann gerne einmal unverbindlich die Angebote einholen

**2026-01-09T14:50:20.368369** - Julia:
> Bezüglich Indoor:
Würdest du bitte hier einmal anfragen, ob ein Dreh möglich wäre und was es kosten würde für einen halben Tag?
<https://robertobeach.de/home/beach-area/>

Hätte das gerne als Back-Option für Indoor :slightly_smiling_face: Könnte man ja sonst auch draußen am Beach cool drehen

**2026-01-09T15:20:28.470359** - Julia:
> danke dir!

**2026-01-09T15:23:31.747599** - Julia:
> Falls du noch Ideen hast zu Artists die cool passen könnten, außer:
• Cro
• SSIO
• Nina Chuba
• Ski Aggu
• Bill &amp; Tom
• Marteria
• Zartmann 
sag gern Bescheid :slightly_smiling_face: Solange sie nicht mit ALDI oÄ zusammenarbeiten

Oder auch momentane "Trends" bzw. Themen die man überall mitbekommt wie Späti Talk mit Mo Douzi, auch super gerne. Weil wir daraufgehend die Kampagne bauen müssen

**2026-01-09T15:24:29.512289** - Julia:
> <https://www.youtube.com/watch?si=WUN0h3LPnSfYqM0b&amp;v=rR4oIJiRp-g&amp;feature=youtu.be>

**2026-01-09T15:25:23.958949** - Julia:
> Da wärs natürlich auch super einen Bezug zu Sommer/ Festival zu finden

**2026-01-09T15:41:56.892529** - Julia:
> Das kommt von Lidl selbst. Sie finden seine Memes und die Art der Launches so genial 

**2026-01-09T15:46:15.402899** - Julia:
> Ja hatte ich auch kurz überlegt. Können wir auf jeden Fall mal auf die Liste setzen :joy: krasser sollten wir jedenfalls nicht mehr werden 

**2026-01-30T09:57:41.969949** - Julia:
> Hello Anna!

**2026-01-30T10:01:04.569919** - Julia:
> Für Mini haben Marie und ich erste Ideen formuliert – allerdings habe ich diese noch nicht final gecheckt bzw. verfeinert. Du kannst es dir sehr gerne einmal durchlesen und deine Kommentare hinzufügen oder falls du andere Ideen hast einfügen!
<https://docs.google.com/document/d/1NEnlqXtQv5wCwQTJwg87O0flVR4dX0z-fwHf1-nqxH8/edit?tab=t.0>

Pepsi hab ich noch zu wenige Infos, um hier etwas kreatives zu erstellen. Falls Flo da schon was hat, kannst du auch gerne damit starten :slightly_smiling_face:
Ansonsten weiß ich, dass Mert viel auf dem Tisch hat, da ich ihn gerade nicht unterstützen kann durch SIXT. Sonst frag ihn doch gerne mal? Da geht es um Content Ideen für Instagram für die Marke Gorenje

**2026-01-30T10:07:16.488919** - Julia:
> danke dir :slightly_smiling_face:

**2026-01-30T10:07:35.180439** - Julia:
> ich meld mich auch nochmal, evtl. benötige ich für SIXT deine Photoshop Skills

**2026-01-30T10:10:44.687429** - Julia:
> Glaube den müsstest du anfragen

**2026-01-30T10:10:51.927169** - Julia:
> Dann kann ich dich freigeben

**2026-01-30T10:16:04.533719** - Julia:
> okay

**2026-01-30T10:16:08.159059** - Julia:
> also du hast Zugriff?

**2026-01-30T10:18:14.829439** - Julia:
> perfekt!

**2026-01-30T11:26:51.146659** - Julia:
> super, schau ich mir an :slightly_smiling_face: Ja mag die Idee auch sehr gerne

**2026-01-30T11:26:56.627859** - Julia:
> danke dir

**2026-01-30T11:32:34.365679** - Julia:
> Jetzt zur PS Task: Könntest du bei den Bildern die ich dir nach und nach schicke bitte das SIXT Logo austauschen? Ist nur ein minimaler Unterschied aber wichtig :slightly_smiling_face:

Bild 1: Too Hot too handle
Bild 2: Dschungelcamp
Bild 3: Are you the one?

Finale PNGs bitte in diesen Ordner mit folgendem Namen ablegen:
300126_SIXT_RealityTV_TooHot
300126_SIXT_RealityTV_IBES
300126_SIXT_RealityTV_TheOne

Sixt Logo:

**2026-01-30T11:32:51.855529** - Julia:
> 

**2026-01-30T12:02:42.799059** - Julia:
> und last one:

**2026-01-30T12:02:49.783889** - Julia:
> 

**2026-01-30T12:03:01.677849** - Julia:
> sag gerne Bescheid, wenn du Hilfe benötigst :slightly_smiling_face:

**2026-01-30T12:04:11.772269** - Julia:
> ah sorry beim Dschungelcamp gabs noch eine Anpassung:

**2026-01-30T12:06:51.635709** - Julia:
> 

**2026-01-30T13:07:06.136809** - Julia:
> Die großen reichen 

**2026-01-30T13:07:14.414909** - Julia:
> Ah mist, schicke ich dir gleich!

**2026-01-30T13:34:15.269459** - Julia:
> <https://drive.google.com/drive/folders/1aLCz7CZkdJOu_PQiBQh9GxUdMamSHJdt>

**2026-01-30T13:34:18.233219** - Julia:
> danke dir!!

**2026-01-30T13:53:08.113679** - Julia:
> genau "ready for presentation"

**2026-01-30T14:28:44.754089** - Julia:
> alles gut soweit? :slightly_smiling_face:

**2026-01-30T14:33:56.263639** - Julia:
> jaa super, vielen dank :slightly_smiling_face:


---

### #D0A57U5R90E (15 messages)

**2025-12-23T18:27:40.921419** - Julia:
> Hi!

**2025-12-23T18:27:47.129029** - Julia:
> What do you mean exactly? :slightly_smiling_face:

**2026-01-30T17:56:44.844189** - Julia:
> Hi Jose! :slightly_smiling_face: Hope you are doing fine

**2026-01-30T17:57:43.891199** - Julia:
> I just add some tasks into the new Asana Board &amp; will fill them now with detailed briefings! It would be awesome, if you and the team could work and that already today? :slightly_smiling_face:
We need the final assets on wednesday, so it's very tight!

**2026-01-30T17:59:24.774719** - Julia:
> I won't be able to feedback today, but I've you like I can give you a quick overview/ introduction about the project :slightly_smiling_face:

**2026-01-30T17:59:52.570829** - Julia:
> just the titles. I'll insert the briefings now asap

**2026-01-30T18:02:35.485779** - Julia:
> AI generated pictures

**2026-01-30T18:29:25.454109** - Julia:
> perfect! The first briefing for 3 pictures is in Asana

**2026-01-30T18:52:09.661479** - Julia:
> 3 briefings (out of 5) are ready. The rest will follow on monday

**2026-01-30T18:52:31.261809** - Julia:
> Everything okay for you or should we have a quick call now?

**2026-01-30T19:05:00.281869** - Julia:
> sure!

**2026-02-02T13:32:45.836109** - Julia:
> Hi! Thank you for the AI Content already :slightly_smiling_face: I commented one task and need one more iteration.
Another new task is in the Asana board. Today in the evening I will add briefing for the last task "Road Challange" in Asana

**2026-02-02T20:50:15.902309** - Julia:
> the last briefing is online now :slightly_smiling_face: thank you so much

**2026-02-03T15:41:41.999969** - Jose Pequeno mentioned Julia:
> Hi <@U09D64LA420>

we have finished our asana tasks :slightly_smiling_face:

**2026-02-03T16:54:44.150829** - Julia:
> Thank you! I’ll have a look asap 


---

### #ai-future (7 messages)

**2025-12-22T16:50:11.393409** - Julia:
> <@U09D64LA420> has joined the channel

**2025-12-23T18:12:22.551809** - Julia:
> it's the photodump option i just showed you :slightly_smiling_face:

**2026-01-07T16:37:24.631069** - Julia:
> Hi there! Happy new year :partying_face:
Wow, nice to see such a progress!

Just wanted to quickly check your priorities regarding Decathlon and other projects? Are you available this week for us and some videos for Hisense/ Gorenje? :slightly_smiling_face:

**2026-01-07T17:09:27.042229** - Jose Pequeno mentioned Julia:
> Hi <@U09D64LA420> 

Happy New Year :grin:

What ideas do you have for Hisense/Gorenje? To be able to estimate the complexity and order the team :saluting_face:

**2026-01-07T17:14:13.796649** - Julia:
> Nothing new! Just asking because we still have a lot of videos ready for editing and wanted to doublecheck for your capacities

**2026-01-07T17:37:04.578419** - Julia:
> nice, thank you :slightly_smiling_face:

**2026-01-28T11:04:20.566459** - Julia:
> Hi there, we don't have any credits left! <@UNUQV5R08> Can we buy another package or what did you guys bought?


---

### #barcelona (3 messages)

**2026-02-12T11:14:57.466049** - Julia:
> <@U09D64LA420> has joined the channel

**2026-02-12T16:45:49.582329** - Julia:
> Jaa! Gibt es schon grobe Zeiten für die Flüge? Ich hab am Samstag also am 9.5. um 10 Uhr einen Termin den ich nicht verpassen darf :face_with_peeking_eye:

**2026-02-12T16:46:51.804869** - Florian Listl mentioned Julia:
> wir fliegen am Donnerstag Nachmittag und am Samstag Nachmittag, aber wir können dir zur not am Samstagmorgen einen frühen flieger buchen :slightly_smiling_face: <@U09D64LA420>


---

### #client-feedback (2 messages)

**2025-11-18T15:49:52.256029** - Julia:
> <@U09D64LA420> has joined the channel

**2025-11-21T13:40:54.691659** - Julia:
> Hello zusammen!

Hier das Update von <@U08V6A47PKN> <@U093J779DAQ> und mir:
*Hisense/ Gorenje*
9/10
• Wir sind momentan an der Planung der bevorstehenden Produktionen dran und sind hier diese Woche extrem voran gekommen
• Die proaktiven Content Ideen kommen alle super bei den Kunden an und haben heute bereits die Produktionspläne mit detaillierten Video Konzepten rübergeschickt
• Herausforderung momentan: Logistik —&gt; einen TV mit 2m Durchmesser in eine geeignete Location zu bekommen —&gt; Asking for a friend: hat jemand ein großes, schönes Wohnzimmer? :nerd_face:


---

### #creative-lead (2 messages)

**2026-01-27T16:14:10.507529** - Julia:
> <@U09D64LA420> has joined the channel

**2026-01-27T16:18:34.440329** - Julia:
> alles klar, schauen wir uns an!


---

### #decathlon-pitch (9 messages)

**2026-01-14T16:58:47.797709** - Julia:
> <@U09D64LA420> has joined the channel

**2026-01-22T12:03:20.545789** - Florian Listl mentioned Julia:
> Hey :) könnt ihr bis Freitag Abend hier ein Video hochladen, wie ihr euren Teil des pitches vortragt?
Dann kann ich Feedback geben und meinen Teil ggf. anpassen.

<@U05LQB4GTC1> <@U09D64LA420> 

**2026-01-22T15:43:49.408799** - Julia:
> Hi Flo! :slightly_smiling_face: Ich schaffe es bis morgen nicht, würds dir aber Montag schicken bzw. mich Montag dann auch damit befassen?
Julia ist leider seit gestern schon krank und ich muss hier voll übernehmen. Morgen brauch ich unbedingt meinen Ausgleich zur Reise, sobald LIDL, der Gorenje Content und die SIXT Themen mit Marvin gemeinsam erledigt sind.

Marvin und ich hatten Slides 13-23 aufgeteilt. Bei den slides 50-52 sind wir der Meinung, dass das besser kommt, wenn du/ Alex das übernehmt. Was denkst du?

**2026-01-22T15:45:27.712969** - Julia:
> ah okay, good to know!

**2026-01-26T18:16:27.449499** - Julia:
> Wir können Präsentations-Notizen einbauen oder? Ganz ohne Stichpunkte bin ich lost

**2026-01-26T18:21:12.524949** - Julia:
> Hier mein Part: direkt im Anschluss zu dir Marvin :wink:
Muss auch noch üben aber inhaltlich wäre das meine Präsentation

**2026-01-26T18:41:57.594459** - Julia:
> <@UNUQV5R08> wie ist denn der logistische Plan? Jeder auf eigene Anreise?

**2026-01-26T20:35:07.822389** - Florian Listl mentioned Julia:
> <@U09D64LA420> eigentlich ist bei dir das gleiche Feedback wie bei Marvin, mach dir keine Gedanken um den Inhalt - sag es dir lieber ein paar mal vor ohne auf die slides zu schauen.

Inhaltlich kriegst du das hin - aber es muss noch nahbarer werden, dass man dir an den Lippen hängt

**2026-01-26T20:42:52.640159** - Florian Listl mentioned Julia:
> <@U09D64LA420> aber gilt auch für <@U05LQB4GTC1>

weniger Fokus auf details, mehr auf stichpunkten und die so verbinden, wie du's einem Freund erzählen würdest - so ist es viel authentischer


---

### #gipfeltreffen (3 messages)

**2025-09-02T10:43:30.086959** - Julia:
> <@U09D64LA420> has joined the channel

**2025-09-12T16:04:21.878619** - Julia:
> Liiiiebe das Grid! :slightly_smiling_face:

Beim Highlight – evtl. etwas zu kleinteilig und nicht lesbar? Je nachdem was ihr besprochen habt

**2025-09-12T19:21:36.302029** - Julia:
> Wie wä's mit 1x nur Gipfeltreffen (rosa Background + Straße) und 1x Auto auf Straße mit Bergen?


---

### #gore-sense (50 messages)

**2025-11-13T10:07:52.946409** - Julia:
> <@U09D64LA420> has joined the channel

**2025-11-13T12:12:33.189059** - Julia:
> Dankee :slightly_smiling_face: ja das wird gut

**2025-11-13T12:12:59.001789** - Julia:
> Sie waren ja auch wirklich super nett – kein Vergleich zu anderen :smile:

**2025-11-17T16:56:55.214289** - Julia:
> Nee, denke nicht

**2025-11-18T11:54:07.773779** - Julia:
> das macht ja garkeinen Sinn

**2025-11-20T18:20:50.795839** - Julia:
> Ich hab die Videos gecheckt, die End-Ergebnisse (also Gesichter der Jungs am Ende) hab ich ehrlicherweise nichtmehr kontrolliert – bin nicht auf die Idee gekommen, dass das falsch sein könnte, weil die Videos ja schon ewig dort abliegen. Aber ja, hast du Recht, hätte man mit checken müssen, mein Fehler!
Hatte den Inhalt, Ton und Bild gecheckt, weil die VoiceOver teilweise am Ende abgeschnitten oder das Bild unscharf war. Diese Dinge haben wir schon an die Designer weitergegeben wie Mert gesagt hat und da weiß Laureen auch Bescheid, dass diese Videos mit WIP gekennzeichnet sind

**2025-11-21T09:10:47.782889** - Florian Listl mentioned Julia:
> Könnt ihr mir eine kurze Übersicht schicken, was wir wann mit welcher Brand drehen und wie viel das jeweils kostet? <@U093J779DAQ> <@U09D64LA420> 

**2025-11-21T10:01:32.484899** - Julia:
> Hello! sind gerade dabei, das alles zu finalisieren (soweit es geht) schicken wir dir asap rüber

**2025-11-21T17:10:43.168569** - Julia:
> Hi, hier auch nochmal kurz ein Update für dich <@UNUQV5R08> bezüglich H/G (Hisense, Gorenje) Shootings:

G:
• Wir bekommen ein neues, günstigeres Angebot für das Tiny House von Rückenwind --&gt; sobald das da ist, teilen wir es mit Laureen
• Parallel sind wir dran den geplanten Content vs. Aufwand gegenzuchecken <@U093J779DAQ> 
• Für G können wir ein *Modul von Rückenwind* haben, das zumindest den Pizza Ofen eingebaut hat, das passt auch ins Studio oben bei uns ins Büro. Könnten wir 1-2 Tage dort aufbauen und stehen lassen. 
• Produkte die damit abgedeckt werden: Pizza Ofen, Staubsauger :white_check_mark:
• Was fehlt? Kühlschrank, Dishwasher, Waschmaschine :x: 
• Noch ein Punkt der seitens Rückenwind und Logistiker geflagged wurde: Das Tiny House wird eiskalt, da wir dort keine Heizung haben und es ja draußen steht --&gt; Sollten wir auf jeden Fall im Hinterkopf haben
H:
• Mikrowelle (H) könnten wir beim Modul auch mit drehen.
• habe das ganze Büro ausgemessen: die Kühlschränke passen leider nicht durch die Büro Türen (auch nicht durch den Garten) Also dieses Büro Not-SetUp können wir schon mal nicht aufbauen, leider
• Julia, Mert und ich haben jetzt noch einen Instagram Aufruf gemacht, bezüglich des großen Wohnzimmers für die Produktion der TV Geräte

**2025-11-21T17:16:55.200879** - Julia:
> Ne all good!

**2025-11-21T17:17:47.051429** - Julia:
> hier noch das Modul --&gt; sind Einzelteile

**2025-11-25T09:36:24.531479** - Julia:
> Das im Heimkinoraum? Hast du da inzwischen noch eine Info wegen den Kosten? Wie gesagt wir werden täglich von HKR vertröstet und wir benötigen ja die Info

**2025-11-25T09:37:39.786429** - Julia:
> ja jeden Tag

**2025-11-25T09:38:45.925419** - Julia:
> okay, das ist schon mal eine wichtige Info

**2025-11-25T09:39:40.010699** - Julia:
> ja ich weiß. Ich spreche täglich mit denen. Das "Problem" ist, dass der entsprechende AP sich nicht zurück meldet und die, die vor Ort sind können mir nicht weiterhelfen und sagen mir täglich "wir müssen leider auf die Rückmeldung von dem AP warten"

**2025-11-25T09:40:01.484799** - Julia:
> Das ist das problem. Inzwischen hab ich auch schon 3 Mails geschickt

**2025-11-25T09:40:39.123049** - Julia:
> Das hat nichts mit den Shootings zutun

**2025-11-25T09:41:24.532169** - Julia:
> Das sind mögliche Kooperations Partner/ Brands die wir schon mal sammeln wollen für spätere Zeitpunkte. Bei den Drehs sind unsere Models bei 800€

**2025-11-25T09:42:45.202559** - Julia:
> yes, wir haben unser meeting gleich

**2025-11-25T09:46:38.309019** - Julia:
> ah in den Zuge <@UNUQV5R08> könntest du den Hisense JF mittwochs raus löschen? Wir haben immer montags und donnerstags jetzt Abstimmungsmeetings mit Laureen/ Ray

**2025-11-25T11:03:32.136859** - Julia:
> Julia ist leider krank :pensive:
Spreche um 12.30 mit Marvin zu Gorenje, wie das genau geht
Hisense immer noch kein Update von TikTok. Mert hat heute Abend einen Call mit Julia (Lark AP) und macht hier nochmal Druck

**2025-11-25T11:04:19.014299** - Julia:
> danke!

**2025-11-25T14:45:43.107599** - Julia:
> haben schon mal ein Update: Hisense ist leider wieder nicht verifiziert worden. Wir versuchen es direkt erneut :exploding_head:

**2025-11-25T17:25:33.416429** - Julia:
> Hi Flo, hast du zufälligerweise die Mail schon gelesen von Laureen bezüglich des Heimkinoraums?
Jetzt weiß ich auch, warum ich geghosted wurde :no_mouth:

Was können wir hier machen? Wie gehen wir weiter vor? Das ist SUPER unangenehm, für Mert, Julia und mich. Da wir solche Infos einfach nicht bekommen haben und wir wirklich oft durch diese fehlenden Infos in komischen Situationen mit dem Kunden sind.
_Beispiel hier auch nochmal: der Redaktionsplan --&gt; uns wurde gesagt alle Inhalte sind final und ready für Feedback an den Kunden. Wir haben dann nur als Eigeninitiative nochmal alles gecheckt und teilweise rausgeschmissen (bis auf die Endstände die mir wie schon gesagt nicht in den Sinn gekommen sind zu checken)._ 

Die meisten Themen sind ja jetzt übergeben und wir sind sehr im engen und positiven Austausch mit Laureen aber, dass immer wieder solche Themen aufkommen ist echt nicht gut FYI

**2025-11-25T17:26:09.316089** - Julia:
> ah perfekt, danke

**2025-11-25T17:27:14.368809** - Julia:
> aber auch lustig, dass sich Felix in dem Fall, dann nicht einfach bei mir zurückmeldet und das nochmal anspricht

**2025-11-25T17:28:42.703739** - Julia:
> aber danke fürs direkt Antworten!

**2025-11-26T18:21:40.607429** - Florian Listl mentioned Julia:
> macht einen Verification Call mit Hisense - eskaliert die Themen, bei denen wir dependent sind.

Wir müssen den Kunden pushen, damit sie sehen, dass wir on top of things sind. Wir brauchen die Verifizierung bis EOY, das ist Grundvoraussetzung für das Community Mgmt 2026.

Außerdem: Sprich mit Marvin bzgl. eingereichter Dokumente/ News Artikel etc., kann nicht sein, dass da gar nichts vorhanden ist.

danke!!

<@U09D64LA420> <@U08V6A47PKN> <@U093J779DAQ>

**2025-11-27T11:04:28.356619** - Julia:
> ja es gäbe nur die Lösung in Form einer Plane/ Zelt bisher, die Rückenwind uns geklärt hat

**2025-11-27T11:05:57.877149** - Julia:
> Wir haben wirklich schon mehr als 5 mal nachgefragt – wir bekommen immer die gleichen Antworten "keine Ahnung". Aber ja wir sind dran...

**2025-11-27T11:28:06.358619** - Julia:
> klären wir ab!

**2025-11-27T12:03:15.608779** - Julia:
> <@UNUQV5R08> wir haben dir ein kurzes Meeting eingestellt für später, damit wir uns einmal absprechen können. Passt dir das?

**2025-12-01T18:08:17.211409** - Julia:
> Hi Flo! :slightly_smiling_face: Wir haben ein Update, das wir mit dir besprechen müssen.

Die Kosten für den *Gorenje Dreh im Tiny House Berlin* belaufen sich jetzt laut Angeboten von *Rückenwind + Halle* (complexion films) auf ca. 30k. (noch ohne Props, ohne Creator, ohne unsere Reisekosten).
--&gt; Gerade haben wir die Info von Laureen bekommen, dass diese Kosten in den 40k Budget abgedeckt werden müssen.
--&gt; Anfangs hatten sie uns gesagt die Kosten übernehmen sie
---&gt; wir planen 12-15 Videos dort zu drehen. Also Kosten/Nutzen sind hier katastrophal.

Der Kunde möchte zusätzlich noch einen *Dreh in einer Wohnungs Location* den wir gerade planen und hier haben wir auch nochmal Kosten um 5k.

Jetzt ist unsere Frage, der Tiny House Dreh kommt dann ja nicht in Frage, oder?

**2025-12-01T18:09:34.239589** - Julia:
> Ja gut, dachten wir uns

**2025-12-01T18:09:54.155259** - Julia:
> wir verstehen auch nicht, warum sie da so drauf bestehen

**2025-12-01T18:10:06.575079** - Julia:
> wir haben eh morgen uns Update Meeting und gehen nochmal alles durch. Danke Flo!

**2025-12-01T18:27:07.592309** - Julia:
> Kunde. Also “bestehen” darauf. Sie haben paar mal ihre Meinung geändert und wollten letztendlich unbedingt den Dreh im TH machen. Jetzt kamen die finalen Kosten 

**2025-12-01T18:28:21.927549** - Julia:
> Wir haben ihnen ja auch schon andere Ideen mit modularer Küche von Rückenwind gepitched

**2025-12-02T11:51:56.960799** - Julia:
> Also Laureen klärt das heute nochmal mit Conny ab, aber sieht es auch als unsinnig. Wir denken oder haben rausgehört, dass sie etwas unsicher ist, ob wir sonst auf die 40k kommen können

**2025-12-02T11:54:12.443439** - Julia:
> ja haben sie eh schon grob, aber finalisieren wir noch

**2025-12-02T13:59:11.968449** - Julia H. mentioned Julia:
> Logooo.

Hier die Infos <@U09D64LA420> <@U093J779DAQ> Please correct if I am wrong.
• *KVA Rückenwind:* was ja eigentlich für das Shooting beim Logistiger angedacht war, aber ja so eh nicht geht
• *KVA Halle/Studio:* Hier ist die Produktion über den Tag verteilt enthalten, Licht, Strom, Food, ein paar Posten darin benötigen wir an sich nicht, wie Maske, oder so viel Catering, aber diese Posten machen gesamt in den Kosten keinen riesen Unterschied.
Aber *on top kommt da ja noch der Transport des Tiny Houses* dort hin plus die PM Kosten von Rückenwind und dann noch alles, was wir seitens BCC brauchen. Reisekosten, Props, Creator....

**2025-12-02T17:05:37.817189** - Julia:
> a) Wir haben die Kosten auf Wunsch von den Kunden direkt bei complexion angefragt weil in der gleichen Halle vorletzte Woche ja mit pascal hens geshooted wurde. Nach deinem Gespräch mit Mark und dem Thema der Halle kam das auf.

B) da wir die SDA Produkte jetzt separat geht es hier nur um die großen Geräte wie den Pizzaofen —> Max. 10 Video
Kühlschrank, Waschmaschine, GeschirrSpüler sind scheinbar nicht die aktuellsten Modelle —> also hier kein Fokus. Vllt nochmal 10 Videos ohne klaren Fokus. Das haben wir aber eigentlich auch schon mit Laureen geklärt.

C) die Alternative Location ist ja schon fest. Wir drehen am Dienstag in einer Wohnung die SDA Produkte.
Die Alternative für den Pizzaofen wäre das modulare Kückenmodul von Rückenwind (findet Conny nicht gut) --> Kosten mit allem (Creator, Props) hierbei ca. 4k

D) Beim Küchenmodul mit Pizzaofen bleibt die Anzahl gleich, weil uns die großen Geräte fehlen

**2025-12-02T17:13:29.524909** - Julia:
> 2 doofe ein Gedanke :women-with-bunny-ears-partying:

**2025-12-04T14:18:24.726859** - Mert Koc mentioned Julia:
> Also die Kunden sind laufend informiert und kennen die Problematik dieser Prozesse selber von vorherigen Versuchen und Meta etc.
Ich schätze, dass wir den nächsten Versuch erst nächste Woche Mittwoch oder Donnerstag starten können, da wir gerade die Drehs am Montag + Dienstag priorisieren müssen. Wie immer gibt es auch keine Begründung zur Ablehnung, heißt, dass wir das selbst herausfinden müssen. Ich habe meine AD Manager AP mal gefragt, ob sie uns eine AP zur Verifizierung geben kann aber noch keine Antwort erhalten.

Fyi: <@U08V6A47PKN> <@U09D64LA420>

**2025-12-04T15:37:51.919719** - Julia:
> <@UNUQV5R08> wir müssten jetzt einmal die Deko + Sideboard Bestellung für die Shootings tätigen. Kann ich dafür die Kreditkarte nutzen? Sind ca. 600€

**2025-12-04T17:07:04.131109** - Julia:
> Hello!
Ja das stimmt.
*Hisense* findest du hier in der Präsentation Slide <https://docs.google.com/presentation/d/1hCn3KbyAlmOzdpS0aAdcerl52U-l4EYm/edit?slide=id.g3866134a371_0_0#slide=id.g3866134a371_0_0|6 & 7: Marina und David.>
Die beiden Kontakte kommen über uns direkt.
Marina ist Sprechexpertin:
• sie ist Traurednerin & Moderatorin
• Wir haben sie bei everdrop kennengelernt und hier war sie auch schon das Gesicht viele Ads und Kampagnen
• sie übernimmt 90% der Sprechanteile in den Videos (Skripte liegen <https://docs.google.com/spreadsheets/d/16asKjHfqeoKWliec5qV0cUYJ82Q59G8aj9Bd5QAsThM/edit?gid=1810259804#gid=1810259804|hier >schon final ab)
David ist Social Media Manager:
• Meister der Mimik und super sympathisch
• dreht selbst viele Reels/ Tik Toks, ist sich also für nichts zu schade
Wir haben super viel Couple Content. Die 2 kennen sich auch, deshalb sind wir super confident, dass hier alles super wird. Hisense hatte sich für die beiden entschieden

**2025-12-04T17:10:46.812409** - Julia:
> *Gorenje:* 
• hier hatten Ray & Laureen sich final für Julia entschieden. Sollen wir ihr absagen?
• hier geht es eher darum, jemanden zu haben der super confident mit Lebensmitteln/ Kochen ist. Deshalb Fokus hierauf. Hier die <https://docs.google.com/spreadsheets/d/16asKjHfqeoKWliec5qV0cUYJ82Q59G8aj9Bd5QAsThM/edit?gid=86113115#gid=86113115|Skripte>, noch nicht ganz final
• Wenn du ihre Stimme so schlimm findest, ist es kein Problem anschließend mit einem VO zu arbeiten. Wir haben eh viel Content der nur mit B-Roll gedreht wird und wir am Ende noch vertonen müssen
• bisher sonst keine Zusage so kurzfristig leider

**2025-12-04T17:13:02.323859** - Julia:
> Schon mal gesammelte Creator/ Angefragte sind <https://docs.google.com/spreadsheets/d/1laCXHPyMkHyH9WUIODD_CBdEjemdUypTcHiSdnZt3zo/edit?gid=0#gid=0|hier.>
Bezüglich generelle Creator Anfrage: da sind wir gut im Bilde, da ich davor auch mit Plattformen gearbeitet hab über die man Creator Kontakte bekommt und diese managed etc. Das würden wir gerne im nächsten Schritt angehen und haben wir heute mit Laureen besprochen, was sie auch super finden, wenn wir zusätzlich so Content generieren

**2025-12-05T09:14:44.781499** - Julia:
> Marina:
<https://www.tiktok.com/@marinastefanied?_r=1&amp;_t=ZN-91xm5VIbHEM|https://www.tiktok.com/@marinastefanied?_r=1&amp;_t=ZN-91xm5VIbHEM>

<https://www.instagram.com/marinastefaniedanner?igsh=MXBzZWlrcDJodG42aw==|https://www.instagram.com/marinastefaniedanner?igsh=MXBzZWlrcDJodG42aw==>

—&gt; Hier sind allerdings nicht die Videos zu sehen aus der Präsentation.

David hat leider sein Profil gelöscht, weil er einen neuen Handle aufbauen will mit dem Freund aus dem Video (in der Präsentation)

Julia: kennst du ja 
 <https://www.tiktok.com/@ugcwith.julia?_r=1&amp;_t=ZN-91xmSaQQrva|https://www.tiktok.com/@ugcwith.julia?_r=1&amp;_t=ZN-91xmSaQQrva>

**2025-12-19T17:36:36.111789** - Julia:
> das war das mit den Challange/ Tiny House Videos oder <@U08V6A47PKN> ? 


---

### #hardgore (1542 messages)

**2025-09-25T10:47:19.556069** - Julia:
> <@U09D64LA420> has joined the channel

**2025-09-25T10:48:11.673189** - Julia:
> :fast_parrot:

**2025-09-25T11:35:09.027959** - Mert Koc mentioned Julia:
> <@U09D64LA420> Hast du die Artur Kar Collection Fotos schon? :slightly_smiling_face:

**2025-09-25T11:35:21.471119** - Julia:
> Yes, danke :slightly_smiling_face:

**2025-09-25T11:35:30.716249** - Julia:
> Schneidest du die Video Snippets? Kann ich sonst auch machen

**2025-09-25T12:05:26.476989** - Julia:
> gerne! wie wärs mit
Video 1: 0:44 - 0:49
Video 2: 1:11 - 1:14
Video 3: 1:22 - 1:35
Video 4: 1:58 - 2:03 ca.

(ohne Ton alle)

**2025-09-25T12:14:25.948239** - Julia:
> würdest du die snippets dann bitte hier reinladen:
<https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7B7D85BAF2-D5AD-4927-9DD3-1A9CC246F422%7D&amp;file=2025_CarreraGT_Rollout_MARKET_DECK%20(1).pptx&amp;action=edit&amp;mobileredirect=true&amp;previoussessionid=bbaa610d-a214-87dd-79a2-71e0b103afcf|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7B7D85BA[…]ue&amp;previoussessionid=bbaa610d-a214-87dd-79a2-71e0b103afcf>

**2025-09-25T12:25:55.797469** - Julia:
> Ich hab Hanna geschrieben wegen Grundriss/ Skizze was auch immer sie hat

**2025-09-25T12:43:18.232309** - Julia:
> <@U08V6A47PKN> wegen der generellen Präsentationen:
• würde 2 gesonderte vorschlagen: 1x BS, 1x DE
• Aufbau: Content Säulen mit Content Haus | Verteilung | Weekly Trends als Zusatz | Redaktionsplan/ Kalenderansicht | geplante Posts für Freigabe | backlog Posts | Ideen 
• soll ichs kurz umsetzen? 

**2025-09-25T12:43:57.248259** - Julia:
> ah cool! Lass uns da gerne gleich mal sprechen was du für Ideen hattest usw :slightly_smiling_face: Kannst gerne anrufen, wenn du Zeit hast

**2025-09-25T13:41:30.497559** - Julia:
> habs bei der BS Präsi im Sharepoint jetzt angelegt, natürlich noch nicht komplett ausgefüllt

**2025-09-25T13:42:59.208259** - Julia:
> sagt mal, das sind doch 5 ziffern...? 6 und 5

**2025-09-25T13:46:02.104229** - Mert Koc mentioned Julia:
> <@U09D64LA420> Die Videos sind in der Präsi
Und liegen außerdem hier ab: <https://drive.google.com/drive/folders/1MXJmZbKNlUjyLlSuHSKUgJpuFtFN0Z90?usp=drive_link>

**2025-09-25T13:57:25.303679** - Julia:
> All good haha

**2025-09-25T13:57:41.895839** - Julia:
> Juhu <@U08V6A47PKN> Ready for you 

**2025-09-25T14:09:04.889319** - Julia:
> Dann würd ich eher machen: „addiert“ ergeben all diese Ziffern die 911 - fahren in der schönsten Form 

**2025-09-25T15:18:02.164459** - Julia:
> yes, hab die story für morgen schon angepasst

**2025-09-25T15:18:07.771859** - Julia:
> reminder schau ich mir gerade an

**2025-09-25T15:19:47.893589** - Julia:
> Maus Alarm :slightly_smiling_face: <@U093J779DAQ>

**2025-09-25T15:20:19.149739** - Julia:
> ob man eigentlich zu garnichts kommt mit diesem posting drama :smile:

**2025-09-25T15:37:30.070659** - Julia:
> Würde es nach oben setzen

**2025-09-25T15:39:22.216749** - Julia:
> <@U093J779DAQ> ich hab deinen Arthur Kar Video Ordner zum Brandstore Ordner verschoben

**2025-09-25T15:54:58.638579** - Julia:
> kann ich machen

**2025-09-25T16:01:39.920819** - Julia:
> kurze frage: was sind eig die saturday tunes?

**2025-09-25T16:01:40.784469** - Julia:
> :smile:

**2025-09-25T16:02:57.222419** - Julia:
> ahh okay, danke

**2025-09-25T16:05:38.066549** - Julia:
> 

**2025-09-25T16:06:37.464749** - Julia:
> oder das

**2025-09-26T09:02:35.093619** - Julia:
> bin ausgestiegen – aber du machst das :smile: hahaha

**2025-09-29T11:35:55.706119** - Julia:
> <@U08V6A47PKN> Haben wir eigentlich Feedback bekommen zum Cayenne Extreme Post? Ist mir gerade aufgefallen

**2025-09-29T11:50:10.596619** - Julia:
> Hier die Porsche DE Präsi: natürlich noch viel TBD aber hier können wir zumindest alles sammeln <https://docs.google.com/presentation/d/1hWclXKncOdWuzmNTzkG7dQ59wDFNNl0N/edit?usp=drive_web&amp;ouid=113547910377163828129&amp;rtpof=true>

**2025-09-29T12:21:14.456109** - Mert Koc mentioned Julia:
> <@U08V6A47PKN> hier: <https://drive.google.com/drive/folders/1641f3-mJuOIdi0UcgrE3K0FoPCb54DPx?usp=drive_link>
Mit allen drei "Lösungsslides" da wir uns noch für keine entschieden hatten oder? <@U09D64LA420>

**2025-09-29T12:26:02.828059** - Julia:
> Ob oben oder unten oder? Dann machen wir doch unten wie du meintest :slightly_smiling_face:

**2025-09-29T13:29:32.856099** - Julia H. mentioned Julia:
> <@U09D64LA420> könntest du vielleicht auch noch einen blick auf die captions werfen bitte?

**2025-09-29T13:30:02.646289** - Julia:
> hab zugriff angefordert!

**2025-09-29T14:38:57.216569** - Julia:
> Captions für Sonderwunsch hab ich dir geschickt <@U08V6A47PKN>

**2025-09-29T14:39:45.064679** - Julia:
> <@U093J779DAQ> die Brand Store Assets in der Präsi für Hanna sind noch die alten oder?

**2025-09-29T14:56:16.803979** - Julia:
> genau, Slide 18

**2025-09-29T15:14:50.839269** - Julia:
> okay, ja alles gut!

**2025-09-29T17:41:53.901679** - Julia:
> Hallo! Also wir könnte dann die DE Präsi mal an Charly schicken (aber erst ab 4_Approval needed):
• nochmal Wiesn
• nochmal Cayenne Extreme
• Turbo S 2x Posts --&gt; <@U093J779DAQ> sobald du ready bist :slightly_smiling_face: 
• Insider Posts
• Modell des Monats Post + Stories
<@U08V6A47PKN> falls du noch da bist, klappt das bei dir mit den Schriften? Bei Mert gehts auch nicht.. Vllt musst du es dann verschicken?

**2025-09-29T17:58:56.647719** - Mert Koc mentioned Julia:
> Ja und ich konnte auch die Videos für den Turbo S Post nicht rein laden!
Also da fehlen dann ja quasi auch 3 Videos... außer <@U09D64LA420> hast du sie rein gemacht?

**2025-09-29T18:00:12.993119** - Julia:
> ne ich hab bei deiner Slide nichts gemacht

**2025-09-30T10:47:59.148709** - Julia:
> Julia falls du rein willst, wären wir im daily

**2025-09-30T15:18:39.036929** - Julia:
> FYI --&gt; Falls wir es schon als Draft einplanen wollen auf Sprinklr? Feedback von Charly heute morgen

**2025-09-30T15:28:31.549779** - Julia H. mentioned Julia:
> Mert, wo finde ich denn den neuen UGC Aufruf? <@U09D64LA420> meinte das wäre schon upgedated?

**2025-09-30T15:58:02.324149** - Julia:
> Charly wollte hier unbedingt noch Content vom Gipfeltreffen dazu packen. Welches Bild findet ihr besser? Irgendwie muss man halt diesen Ice Q sehen..

**2025-09-30T17:49:19.779279** - Julia:
> omg ja klar

**2025-10-01T10:11:32.053869** - Julia:
> liebs auch :heart: ohje die arme.. kann ich übernehmen

**2025-10-01T13:16:02.684909** - Julia:
> <@U093J779DAQ> ich würde jetzt in die Präsi, die du gestern abend noch geschickt hast reinarbeiten. Schicke sie danach wieder hier rein, dann kannst du deine Sachen auch ablegen :slightly_smiling_face: Versuche bis 14.30 alles soweit ready zu haben!

**2025-10-01T13:24:35.638039** - Julia:
> Voll gerne. Ich dachte irgendwie das kann nur Marie..? Und die ist ja noch nicht zurück, deshalb

**2025-10-01T14:21:39.657139** - Julia:
> bin gleich durch und schicke es hier rein

**2025-10-01T14:43:14.599569** - Julia:
> So there you goooo:
• überall dazu geschrieben, ob Neu/ Update/ WIP
• Gipfeltreffen Carousels liegen ab --&gt; Julia ich hab einzelne Bilder reingelegt, also lösche gerne raus was du für unwichtig findest
• Cayenne Extreme mit Interieur Note
• Halloween Update
• dieses "aholic" GIF muss ich noch machen --&gt; Frage: müssen hier VBWs auf die Bilder oder in die Caption? Kann es als 4x5 oder als 9x16 anlegen
• <@U093J779DAQ>: Alltagsdrive, Red Dot (und noch was?) von dir müsste noch rein :slightly_smiling_face: 

**2025-10-01T14:48:44.787839** - Julia:
> okay dankee :slightly_smiling_face: ich werd das noch 100 mal fragen :smile:

**2025-10-01T15:16:12.602579** - Julia:
> dann lasst uns vllt eine folie mit "Red Dot" WIP reinlegen, oder? Dann sieht sie zumindest wir haben es nicht vergessen (fast)

**2025-10-01T15:19:54.668409** - Julia H. mentioned Julia:
> hier liegt der aktuelle Stand.
<@U09D64LA420> ich hab mal Daten ergänzt und nach Datum sortiert. so 100% übersichtlich finde ich das noch nicht.

**2025-10-01T15:22:05.009089** - Julia:
> Ja voll. Du meintest man kann so "Folder" machen oder?
Oder die Posting Timeline immer mit kleinen Vorschaubildchen erweitern (ist hier ja noch garnicht fertig)

**2025-10-01T15:30:37.834189** - Julia:
> so nervig

**2025-10-01T15:30:52.438429** - Julia:
> sagt bescheid, wenn ihr im call seid :slightly_smiling_face:

**2025-10-01T17:44:39.302919** - Mert Koc mentioned Julia:
> <@U09D64LA420> die BS Weekly + Profil Highlight Feedbacks sind umgesetzt und in der Präsi

**2025-10-02T10:29:44.196149** - Julia:
> Hello! Sind noch im Call mit Charly

**2025-10-02T13:33:31.454999** - Julia:
> Ich bin so in einer halben - Std. fertig mit TINS Konzept und den bisherigen Inhalten. <@U093J779DAQ> bist du gerade sehr busy? Falls nicht (I daut it) hast du Lust das Story ABC grob zu designen? Also maximal A und B?

**2025-10-02T14:14:59.972959** - Julia:
> ja ich brauch auch mal eine Pause.. bis gleich!

**2025-10-02T14:17:31.122699** - Julia:
> there you go:

**2025-10-02T14:36:28.091389** - Julia:
> <@U08V6A47PKN> fyi. Passt so?

**2025-10-02T14:51:00.637989** - Julia:
> • ich hab die bestehenden PAG Posts + Stories etwas umgebaut
• Dua Lipa ein neues Konzept erstellt und grobe Video Snippets erstellen
• die Säulen von TINS mit Formaten erklärt
• Adventskalender ABC erklärt 

**2025-10-02T14:52:42.482849** - Julia:
> GIF:
Ja man muss es nur als ein Video exportieren. Also GIF als visuelles bleibt gleich, das Dateiformat ändert sich

Halloween:
Puh ja, müssten wir halt beim Event dann shooten vorher. Die Sachen einsetzen kann man mit AI easy

Adventskalender: haben sie ja dann :slightly_smiling_face:

Rest: Probleme für die nächste Woche :smile:

**2025-10-02T15:16:55.391199** - Julia:
> Ne sorry, das ist jetzt die 4. runde an Text-Feedback. Es reicht

**2025-10-02T15:18:40.444119** - Julia:
> Ich hatte es so. Hanna war es dann zu "unformell"

**2025-10-02T15:24:00.864589** - Julia:
> • ich packs raus
• Aber dafür machen wir doch den extra Post mit den Design Bildern?
• ja mach ich
• <@U093J779DAQ> wenn du Bock hast

**2025-10-02T15:38:03.231109** - Julia:
> PAG hats "erst" vor paar wochen gepostet FYI

**2025-10-02T15:44:07.239259** - Julia H. mentioned Julia:
> Feedback Porsche_DE ist auch drin. <@U09D64LA420> Da wäre nur der Post für heute abend wichtig.

**2025-10-02T15:50:40.462109** - Julia:
> Kannst dus mir schicken? ich kann ja nicht drauf zugreifen - dankee

**2025-10-02T15:52:36.976939** - Julia:
> TINS Update: mehr schaff ich da heute nichtmehr

**2025-10-02T17:08:23.285759** - Julia:
> <@U093J779DAQ> die 18Uhr Story für den BS ist gleich geblieben? Link einfach der normale?

**2025-10-02T18:02:41.921069** - Julia:
> Happy weekend :heart_hands: :women-with-bunny-ears-partying: 

**2025-10-02T18:02:52.366769** - Julia:
> Wir sind toll :face_with_open_eyes_and_hand_over_mouth: 

**2025-10-06T09:00:06.182079** - Julia:
> Hello! :slightly_smiling_face:

**2025-10-06T09:00:17.988659** - Julia:
> :fast_parrot:

**2025-10-06T09:39:32.935379** - Julia:
> <@U08V6A47PKN> könntest du mir nochmal die Sharepoint Präsi zukommen lassen, mit dem aktuellesten Stand der Kommentare etc.?

**2025-10-06T10:22:46.906749** - Julia:
> genau

**2025-10-06T12:40:41.479159** - Julia:
> das hier könnte man ja auch als Porsche "Point" vom Gipfeltreffen nehmen

**2025-10-06T13:16:52.170989** - Julia:
> cool! danke :slightly_smiling_face: ich mach jetzt kurz mittagspause und schau es mir dann an

**2025-10-06T14:18:53.135859** - Julia:
> jaa mag ich auch so

**2025-10-06T15:42:57.573259** - Julia:
> Uh, ich glaube auf der Datenbank?

**2025-10-06T15:46:05.958839** - Julia:
> Ich hab die UGC Präsi bearbeitet :slightly_smiling_face:
• Übersicht UGC Kosmos mit den Formaten
• alle 3 Formate extra mit Abschnitten angelegt
• jeweils auf einer extra Slide erklärt, was, wieso, weshalb UGC + Format
• neu sortiert

**2025-10-06T15:57:55.611899** - Julia:
> Können wir unseren Call vllt auf 16.15 legen? bin noch voll im Tunnel :new_moon_with_face:

**2025-10-06T16:11:56.068419** - Julia:
> ich auch nicht

**2025-10-06T16:21:01.156529** - Julia:
> oh seid ihr schon im Call?

**2025-10-06T16:27:08.580459** - Julia:
> <https://www.instagram.com/p/DKSNNpCNuCu/>

**2025-10-06T16:29:46.619349** - Julia:
> <https://www.instagram.com/p/DOydAw-DNxB/?img_index=8>

**2025-10-06T16:31:38.199879** - Julia:
> 

**2025-10-06T17:15:24.635169** - Julia:
> Wir haben etwas krasses entdeckt, man kann Präsentationen zusammen bearbeiten, ohne diese blöde Online Version zu benutzen! :fast_parrot:
Schicke euch dann gleich einen Link rein und ihr könnt parallel dran arbeiten

**2025-10-06T17:20:25.975349** - Julia:
> <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/EZbn1ncbOa1HhhHQsi5WmMwB2lKUJswcIdni7XxgTXzuEA?e=9wxeVU>

**2025-10-06T17:53:17.101749** - Julia:
> oh maaaann, ich habe gerade noch einen dua lipa content gefunden der mega ist

**2025-10-06T17:53:21.288159** - Julia:
> <https://www.instagram.com/p/DMmvTh6s0T3/?img_index=1>

**2025-10-06T17:53:49.861039** - Julia:
> die Präsi schaffe ich heute nichtmehr komplett – können wir das morgen fertigstellen?

**2025-10-06T17:57:16.055479** - Julia:
> könnten beides vorschlagen. I try

**2025-10-06T18:08:34.732399** - Julia:
> ich finds cool! Ich hätte Video eigentlich auf die 3. gesetzt aber so ist auch cool – spannendere Auflösung! :slightly_smiling_face:
Ich denke man braucht noch den kleinen "Tag" mit TINS ABC

**2025-10-06T18:08:50.503359** - Julia:
> 

**2025-10-06T18:19:14.662859** - Julia:
> also ich bräuchte für die Präsi auf jeden Fall noch Hilfe für Slide 12: Umsetzung oder es "schön" formulieren

**2025-10-06T18:39:51.216339** - Julia:
> TINS Präsi mache ich morgen weiter. Hab die Posts/ Stories von Mark, Dua nochmal alle angepasst und zB schon Mert's punkt mit "einzigartigkeit" eingesetzt :slightly_smiling_face:

**2025-10-07T08:48:33.765899** - Julia:
> GuMo! Tins Präsi wäre von meiner Seite fertig – schaut gerne rein :slightly_smiling_face:
Mert das IG Highlight wäre noch toll!
<https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/EZbn1ncbOa1HhhHQsi5WmMwB2lKUJswcIdni7XxgTXzuEA?e=IHPoIy>

**2025-10-07T09:29:35.163919** - Julia:
> :face_exhaling:

**2025-10-07T09:39:42.761529** - Julia:
> Welcher Link?

**2025-10-07T09:49:06.560839** - Julia:
> ja klar

**2025-10-07T12:10:52.313759** - Julia:
> Also TINS wäre ready, je nachdem ob du noch was findest <@U08V6A47PKN>

**2025-10-07T12:46:40.758019** - Julia:
> sameeee 

**2025-10-07T14:08:01.988009** - Julia:
> schööööön

**2025-10-07T14:08:54.939629** - Julia:
> Vllt gibts die ja sogar zu kaufen? :smile:

**2025-10-07T14:36:12.053029** - Julia:
> nee das war auch ein witz von mir 

**2025-10-07T14:36:53.222319** - Julia:
>  Und wenn wir dann 2. Versicherung nen machen? Ihr konntet euch einfach nicht entscheiden :yum: 

**2025-10-07T14:51:39.767959** - Julia:
> nach tagen in Picdrop und im anhang ist eine Mail mit den Strecken. siehst du das?

**2025-10-07T14:52:11.997159** - Julia:
> ja die sollen sich mal nicht so anstellen :smile:

**2025-10-07T14:52:59.583659** - Julia:
> uhh 49 zu 51!

**2025-10-07T15:08:58.399709** - Julia:
> kündigung ist raus

**2025-10-07T15:09:03.674129** - Julia:
> :new_moon_with_face:

**2025-10-07T15:13:23.420769** - Julia:
> jaaa

**2025-10-07T15:13:31.540039** - Julia:
> was etwas herbstliches gibts nicht oder?

**2025-10-07T15:20:16.857179** - Julia:
> machen wir es uns einfach: blau mit einem leichten verlauf? bzw. reifen oder sowas verchwommen in den BG? :slightly_smiling_face:

**2025-10-07T15:26:14.571579** - Julia:
> ja das sieht doch homogen aus!

**2025-10-07T15:26:34.788779** - Julia:
> sie haben es freigegeben und sieht ja schon gut aus

**2025-10-07T15:44:35.827019** - Julia:
> Hatten den Text drunter eigentlich so geplant <@U093J779DAQ>

**2025-10-07T15:44:37.640999** - Mert Koc mentioned Julia:
> Genau, das war auch auch <@U09D64LA420> s Idee oder?

**2025-10-07T15:45:01.817199** - Julia H. mentioned Julia:
> <@U09D64LA420> Nochmal zu den Formaten und Säulen: Das sind ja alles erstmal grobe Ideen und Alternativen oder? Ich frage mich bisschen, ob man das so versteht

**2025-10-07T15:45:04.078549** - Julia:
> Also Idee war: Visuell das TINS Visual nur weihnachtlich zu machen, Text drunter: Advent ABC

**2025-10-07T15:46:09.452209** - Julia:
> Ist garnicht gewünscht oder wie?
Ja dann müssen wir es nochmal anpassen <@U093J779DAQ>

**2025-10-07T15:46:38.562709** - Julia:
> Wie meinst du? Das sind Format Ideen, die diese TINS Säulen aufgreifen

**2025-10-07T15:51:26.057069** - Julia:
> ne keine Alternativen, sondern einzelne Ideen – könnte ja mehrere davon umsetzen. Aber schmeiß gerne raus, was du Quatsch findest

**2025-10-07T15:56:13.331709** - Julia:
> Wir haben die Säulen, auf denen die Kampagne TINS basiert, in einzelne Bereiche aufgesplittet und daraus verschiedene Formate entwickelt – wie du auf den folgenden Seiten sehen wirst. Diese Formate greifen unterschiedlichste Content-Ideen und bestehende Formate auf und zahlen jeweils auf die bestimmte Säule ein. Zusammen bilden diese Säulen dann das große Ganze.

ja gerne ein Meeting

**2025-10-07T16:04:46.369129** - Julia:
> lass gerne mal das 2. nehmen --&gt; soll ja erstmal ein Mood sein

**2025-10-07T17:04:53.435579** - Julia:
> happy haarschnitt!

**2025-10-07T17:08:55.217239** - Julia:
> Sie hat aber nur bei Freigabe ausstehend kommentiert, oder?

**2025-10-07T17:48:19.964189** - Julia:
> gooooo

**2025-10-07T17:54:31.070239** - Julia:
> ich checke, passt!

**2025-10-07T17:57:10.278769** - Julia:
> ich geh erstmal zur massage :joy: happy abend euch und bis morgen! was ein tag.. ohne euch, würde ich (noch mehr) durchdrehen :kissing_heart:

**2025-10-08T09:48:23.560399** - Julia:
> Hallo! Ne da sind diese Bilder auch drin – komische Bezeichnung. Red Flags sind markiert

**2025-10-08T09:49:43.462169** - Julia:
> Ne Red Flags sind Red flags :smile: Grün, Orange sind okay. Schwarz schon geposted (da sind aber nicht alle drin, da hat Charly nur bissl was reingekommen)

**2025-10-08T09:50:56.617829** - Julia:
> danke dir! :slightly_smiling_face: Hattet ihr meinen Kommentar zu den Routen gesehen?

**2025-10-08T09:55:59.618969** - Julia:
> wir sind noch kurz im meeting, melden uns gleich ab 10

**2025-10-08T10:02:03.985039** - Julia:
> <@U08V6A47PKN> treffen wir uns um 10.05 im daily huddle von gestern? :slightly_smiling_face:

**2025-10-08T10:02:56.042719** - Julia:
> würde gerne mit den routen unseren gesammelten hirnschmalz reinstecken :smile:

**2025-10-08T10:19:30.335309** - Julia:
> wir sind im Meeting

**2025-10-08T12:13:42.158199** - Julia:
> Jaaa ausnutzen, wenn es mal nicht so stressig ist. Haben ja voll gut vorgearbeitet schon :heart_eyes:

**2025-10-08T12:42:04.611139** - Julia:
> ich finds super cool. Ich kann mir vorstellen, dass Bild 1 und Bild 4 zu ähnlich sind. Das sind ja die Dolomiten oder?
Da gibts echt keinen Drohnenshot? ich weiß, es ist schwierig aber sie will die safe drin haben, hat sie 3 mal betont

**2025-10-08T12:44:26.156849** - Julia:
> perfekt, dann gerne die variante mit drohnen shots und ciaaaao
das ist dann variante Dolomiten, right?
Magst du mir noch den figma link schicken? Dann schreib ich die caption daneben

**2025-10-08T13:03:56.590329** - Julia:
> ist schon in the making so wie ich das sehe :sunglasses:

**2025-10-08T13:20:13.095669** - Julia:
> das wäre eins, oder? lass es uns einfach erstellen, manchmal muss man  "beweisen", dass es nicht gut ist --&gt; kunde muss es visuell sehen

**2025-10-08T13:23:05.671189** - Julia:
> hör auf, die spinnen ja

**2025-10-08T13:34:02.625639** - Julia:
> Sprinklr war ich FYI

**2025-10-08T13:35:39.737039** - Julia:
> in diese gesamte Präsi denke ich

**2025-10-08T13:37:01.807799** - Julia:
> <@U093J779DAQ> hier vllt? kanns nicht öffnen

**2025-10-08T13:40:00.691869** - Julia:
> Ohh :christmas_tree: <https://www.instagram.com/p/DDucLn_o03f/?img_index=1>

**2025-10-08T15:02:16.393979** - Julia:
> das wäre für sölden? ne, eher dolomiten oder?

**2025-10-08T15:14:33.884839** - Julia:
> verstanden, ich denke das muss man einfach kurz mit Charly klären. Ob sie das 2. Bild trotzdem drin haben will oder nicht

**2025-10-08T15:15:15.278199** - Julia:
> beim 1. und der Headline gerne noch die leserlichkeit anpassen

**2025-10-08T15:36:28.737369** - Julia:
> vielleicht sollte ich daraus ein GIF erstellen.. :smiling_face_with_tear:

**2025-10-08T15:37:39.353429** - Julia:
> jaaa eben

**2025-10-08T15:37:51.665879** - Julia:
> ich glaube sobald jemand die verschiebt oder ändert vllt?

**2025-10-08T15:38:42.835839** - Julia:
> Ich mache jetzt auch nochmal eine Coco Runde. Bis gleich!

**2025-10-08T16:37:48.160429** - Julia:
> Ne auch nichts, was passen könnte --&gt; alles mit Ton

**2025-10-08T17:29:05.693289** - Julia:
> Guckt mal, ich hab 3 Halloween Ideen die ich versuche mit AI umzusetzen. Wenn ihr sagt eins ist vollkommener Quatsch, lass ich es :slightly_smiling_face:

**2025-10-08T17:30:35.629479** - Julia:
> 

**2025-10-08T17:53:45.409589** - Julia:
> okay, ich probier was geht :smile:

**2025-10-09T09:21:43.966219** - Julia:
> Ja, ich hab nur keine Ahnung wie das umsetzbar sein soll. Meinst du ich soll Nicolas schreiben? 

**2025-10-09T09:34:21.407439** - Julia:
> ich hab das Gefühl wir haben die Front schon soo oft jetzt gezeigt :face_with_spiral_eyes: vllt kann man ja was mit dem material von heute abend machen

**2025-10-09T10:04:36.158899** - Julia:
> ich weiß nicht, was ich Flo antworten soll :smile:

**2025-10-09T10:29:44.096119** - Julia:
> bin 5 min lateeee

**2025-10-09T10:45:21.461789** - Julia:
> <https://www.instagram.com/p/DMpmR8VpOzn/?utm_source=chatgpt.com&amp;img_index=1>

**2025-10-09T10:55:14.192319** - Julia:
> Trends: <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/ERREl-jY--RClqmGmwnOPWoBGZc7HXKQ63EHw9JKuy1MSg?e=q0WKAi>

**2025-10-09T12:19:38.704249** - Julia:
> oh neeein :sleepy:

**2025-10-09T14:04:17.631689** - Julia:
> Hier Halloweeeeeen: <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/ETPKeiOKbg1PlPHNVDUdGCIBWgFFjG6lXpaqObe6pdSssQ?e=6UlSuY>

**2025-10-09T15:03:29.019719** - Julia:
> :heart_eyes: magst du sie dann weiterleiten? 

**2025-10-09T15:25:15.943629** - Julia:
> kann ich helfen?

**2025-10-09T15:30:36.436729** - Julia:
> • _Sie würde gern noch in allen drei Captions dann irgendwie sowas ergänzen wie: Der Weg ist das Ziel, oder die Route lief über Bozen XX und XX bis hin zu XX --&gt; Ziel ist zweitrangig es geht ums Fahren_
--&gt; also so Teil 1 war XX über Teil 2 XX? Bei allen 3?
Und nur ergänzen oder komplett anpassen?

Dann mach ich das auf jeden fall

**2025-10-09T15:31:47.309239** - Julia:
> <@U093J779DAQ> soll ich die snippets erstellen? bräuchte nur das reel, bzw einen link den ich öffnen kann

**2025-10-09T15:36:48.371289** - Julia:
> angefragt

**2025-10-09T15:47:55.582089** - Julia:
> haaabs, dankee

**2025-10-09T15:59:33.984839** - Julia:
> also wenns ins carousel mit rein soll, 4x5.
Oder hab ichs falsch verstanden?

**2025-10-09T16:06:48.282319** - Julia:
> ich denke Julia meint Feedpost mit "funktionieren besser" als das lange Reel

**2025-10-09T16:08:22.625979** - Julia:
> Achsooo ich dachte die sollen ins Carousel

**2025-10-09T16:10:22.731069** - Julia:
> alles klar, verstanden!

**2025-10-09T16:19:08.399159** - Julia:
> <@U08V6A47PKN> <https://drive.google.com/drive/folders/1C0-gMoeYaIQXdCtL8HET-jUOPNLuXKGa?usp=drive_link>

**2025-10-09T16:20:03.533369** - Julia:
> Alles guuut :slightly_smiling_face: Ich würde auch bald Feierabend machen tatsächlich. Glaube morgen wird eklig mit den ganzen Event Content :melting_face:
Ich spreche dann direkt mit Hanna

happy weeeekend schon mal :heart_hands:

**2025-10-09T16:23:00.306079** - Mert Koc mentioned Julia:
> Bis morgen <@U09D64LA420> :slightly_smiling_face:

**2025-10-09T17:43:31.917009** - Julia:
> genau

**2025-10-09T17:43:40.794109** - Julia:
> hab ihn deswegen vorne und am ende raus genommen

**2025-10-10T09:34:03.508359** - Julia:
> :smiling_face_with_tear:

**2025-10-10T09:36:26.487199** - Julia:
> Is it me oder is it the content?

**2025-10-10T09:42:49.391969** - Julia:
> ja genau, find ich auch. also carporn wird gut funktionieren und auch moods für die story etc. aber die konzepte funktionieren halt so nicht ohne den content :face_exhaling:

**2025-10-13T09:42:33.236969** - Julia:
> Guten Morgen :wave:

**2025-10-13T10:42:43.893019** - Julia H. mentioned Julia:
> Hello ihr beiden.
Hab Feedback von Charly zu Porsche Points. "Points sehen cool aus. Bildsprache findet sie super."
Kommentare sind in der Präsi <@U09D64LA420> kannst du sie öffnen? Sonst exportiere ich sie dir.

*Hier noch ein paar Notes, denke aber das hat sie auch kommentiert:*
• Gardasee mit Palmen am Hotel und See + BEV Fahrzeuge (Macan am Hotel) --&gt; Mehr Varianz Fahrzeuge
• Caption: Start in Bozen - bis Gardasee
• Gibt es auf der Route sonst noch Points die erwähnenswert wären


**2025-10-13T10:51:20.750629** - Julia:
> ich seh leider nichts, hatte ihr nur ein PDF geschickt – schicks mir gerne :slightly_smiling_face:

**2025-10-13T10:52:45.814989** - Julia:
> oder <@U093J779DAQ> siehst du es?

**2025-10-13T11:25:14.966799** - Julia:
> <https://www.picdrop.com/nicolasbaerphotographie/VYQ8h76w7R>

**2025-10-13T12:00:44.131879** - Julia:
> oh okay

**2025-10-13T12:41:06.795319** - Julia:
> also mir hat flo jetzt geschrieben Di oder Mi mal sprechen

**2025-10-13T12:53:42.696299** - Julia:
> beim 2. sieht man mehr Landschaft, was ich bei PP wichtig finde. Aber tatsächlich fehlt dann der Fahrzeug bezug etwas. Können wir sonst beide nehmen? Mag die Kombi

**2025-10-13T13:20:57.422289** - Julia:
> Hab Hanna jetzt die Event Updates geschickt. Mache dann jetzt kurz Coco Break. Bis gleich!

**2025-10-13T14:52:48.174129** - Mert Koc mentioned Julia:
> <@U09D64LA420> Ich habe das Feedback von den PP soweit fertig. Kannst du bitte überprüfen, ob ich das richtig umgesetzt habe?
Es ist alles in Figma :slightly_smiling_face:
Ich mach eine kurze Pause

**2025-10-13T15:01:59.058089** - Julia:
> mach ich :slightly_smiling_face:

**2025-10-13T15:23:29.313129** - Julia:
> hab in Figma kommentiert und die Gardasee Caption angepasst

**2025-10-13T16:23:06.279669** - Julia:
> <@U08V6A47PKN> soll ich?

**2025-10-13T16:29:48.285289** - Julia:
> habs geposted

**2025-10-13T16:35:31.047489** - Julia:
> glaube das könnte man anhand dem Redaktionsplan rausfinden, welche die Reihenfolge ist. Aktuell ist der 8. online, heißt jetzt übermorgen am 15.10. ist Nummer 9 mit Gardasee, oder?

**2025-10-13T18:00:49.954139** - Julia:
> Gardasee:
• Das war das mit der Kombi was wir vorhin meinten. Aber ja dann lieber austauschen
• Glaube da hat Mert einfach entschieden, das Storytelling zu kürzen, wie bei den anderen, oder? 
Dolomiten:
• Das mit dem Restaurant parken: ja das hab ich auch gesehen aber das passt zeitlich nicht mit dem Restaurant – das war wann anders. 
Das andere von dir hatten wir auch zur Auswahl :smile:

**2025-10-14T09:15:01.797489** - Julia:
> Morgen :slightly_smiling_face:

**2025-10-14T09:15:34.115969** - Julia:
> Julia ich hab keine Ahnung wieso, aber ich bin bei allen Huddles raus bzw. hab die scheinbar abgelehnt? Ich dachte ich hätte nur mal den Freitag abgelehnt. Könntest du mich nochmal hinzufügen? :face_with_peeking_eye:

**2025-10-14T09:51:33.871269** - Julia:
> das find ich auch super. ist ja quasi dieser matchcut nur bissl cooler

**2025-10-14T09:51:52.418589** - Julia:
> ohjaaa! Süßer wäre es wenn noch ein Hund daneben ist, statt einem Menschen haha

**2025-10-14T09:54:30.337459** - Julia:
> jaa oder ich fand das bei dämmerung noch cooler - glaub das hast du rausgeschmissen

**2025-10-14T09:55:04.826729** - Julia:
> 

**2025-10-14T10:31:18.686269** - Julia:
> <@U093J779DAQ> wir kommen paar Minuten später, sind noch im Call mit Charly

**2025-10-14T10:52:20.468769** - Julia:
> eben noch gefunden, Gardasee Content: kA wo das abliegt. Vllt einfach als Screenshot nehmen?
<https://www.instagram.com/p/DPOr0QAjFOM/?img_index=10>

**2025-10-14T11:20:59.706029** - Julia:
> juhuuuu

**2025-10-14T11:43:04.053329** - Julia:
> How it feels to work with Porsche :face_with_peeking_eye:

**2025-10-14T12:09:48.591589** - Julia:
> ich kann das racing thema gerne übernehmen aus Charly's Mail

**2025-10-14T13:15:25.862169** - Julia:
> hab die Karnevals Präsi noch mit dem 911 Carousel angepasst – wenn ihr sonst keine anderen Ideen mehr habt, könntest du das gerne rausschicken <@U08V6A47PKN>

**2025-10-14T14:38:30.296229** - Julia:
> sehr cool!
Story Einstieg mit: MUT ZUR FARBE – EURE WAHL

Ich würde in die Caption noch etwas hinzufügen a la – "ihr habt bei der Konfiguration diese Farbe gewählt, deshalb haben wir sie unter die Lupe genommen.."

**2025-10-14T15:01:29.805779** - Julia:
> Hanna meldet sich nicht zurück und ist in der Präsi auch immer wieder offline – ich nutze mal die Zeit und geh jetzt nochmal eine Runde Gassi. Bis gleeeich

**2025-10-15T09:11:42.797549** - Julia:
> mega cool

**2025-10-15T09:11:48.077739** - Julia:
> Würde ich alle direkt reposten :smile:

**2025-10-15T09:26:41.684369** - Julia:
> bin dran am carousel. Farbe des Monats liegt ab Story + Feedpost + IG Highlights

**2025-10-15T09:30:57.891829** - Julia:
> yes mach ich. legs bei ready for approval ab

**2025-10-15T10:01:32.889819** - Julia:
> Carporn bin ich grad dran und lege ich die updates parallel ab

**2025-10-15T10:04:11.836439** - Julia:
> 1. :slightly_smiling_face: 

**2025-10-15T10:04:23.213539** - Julia:
> aso nee

**2025-10-15T10:04:24.537019** - Julia:
> sorry 2

**2025-10-15T10:11:32.891079** - Julia:
> Luganoblau.
 Mehr als nur eine Farbe – ein bewusste Entscheidung. :blue_heart: (vllt mal mit Herz versuchen?)
Bei der Konfiguration eurer Wahl gehört dieser Ton zu den Favoriten. Grund genug, ihn genauer unter die Lupe zu nehmen.
Wäre Luganoblau auch deine Wahl?

**2025-10-15T10:13:05.475109** - Julia:
> :heart:

**2025-10-15T11:11:03.743199** - Julia:
> ich hab den Fächer letztens gefunden in der Datenbank als Freisteller!

**2025-10-15T11:16:10.745279** - Julia:
> hatte "bunt, farbe" und sowas eingegeben

**2025-10-15T11:55:40.460719** - Julia:
> Ja das ist leider echt das Problem, das Feedback ändert sich mit jeder Review :smile:

**2025-10-15T12:05:30.530709** - Julia:
> guuuten

**2025-10-15T12:56:01.661909** - Julia:
> hab keinen Zugriiiiff manno

**2025-10-15T12:57:04.268229** - Julia:
> ich kann leider die Präsi nicht sehen, sonst hätte ich es schnell gemacht. Welche 2 Bilder sind es denn <@U08V6A47PKN>?

**2025-10-15T14:35:31.312909** - Julia:
> Also die normale. Hab im Suchfeld „Farbe“ eingegeben. Kann aber gleich schauen, ob ich es schneller finde 

**2025-10-15T14:56:49.270959** - Julia:
> jaaa!

**2025-10-15T15:16:09.110879** - Julia:
> ich auch

**2025-10-15T16:12:49.722799** - Julia:
> falls jemand von euch Zugriff auf die Carrera Cup Präsi von Charly hat, könntet ihr es mir dann weiterleiten/exportieren? :heart_hands:

**2025-10-15T16:15:15.595639** - Julia:
> Iteration 35...?

**2025-10-15T17:24:10.972739** - Julia:
> yes, grad die finalen Captions in Asana reingelegt

**2025-10-15T17:24:48.283889** - Julia:
> gleiches Spiel wie vorher zum Copenhagen – gerne teilen :face_with_peeking_eye: (es ist bald vorbeeeeeei) :smile:

**2025-10-15T17:27:35.128729** - Julia:
> Ich sags euch wie es ist: mir reichts auch wieder für heute :smile: Ich wurde am Feld grad noch von 2 Kindern dumm angeredet, dass der Hund da und da hingeschissen hätte – stimmt nicht – und es wäre ja im gaaaaanzen Park – grenzt zu einem Feld an – komplette Leinenpflicht. Ob ich kurz davor war, ihm eine Leine anzulegen? :joy:

**2025-10-15T17:30:43.599379** - Julia:
> echt so. Ziellinie ist vorraus

**2025-10-15T17:31:01.360089** - Julia:
> :checkered_flag:

**2025-10-15T17:31:32.754659** - Julia:
> Ordner wäre hier <https://drive.google.com/drive/folders/1bWcXzCdRy9sz9nV-bnSOYV08HCLAXgdf>

**2025-10-15T17:40:31.810679** - Julia:
> dann bis morgen :slightly_smiling_face: Happy Feierabend euch

**2025-10-16T12:23:54.174159** - Julia:
> moment ich checke

**2025-10-16T12:34:34.960559** - Julia:
> ich hab die Downloard Präsi offen, die geht

**2025-10-16T12:38:20.289559** - Julia:
> wie sollen wir es denn am besten machen? Soll ich jetzt durchgehen und alle Slides die wir übernehmen sollten rausspeichern in eine extra Präsi und hier reinschicken? Dann können wir an der arbeiten und Julia du dann in die Original Präsi legen?

**2025-10-16T12:41:48.577909** - Julia:
> ja genau, aber wir sollten vorher abstimmen welche assets wir überhaupt übernehmen, das meine ich. deshalb schicke ich hier gleich "meine" präsi rein. okay?

**2025-10-16T12:46:32.399899** - Julia H. mentioned Julia:
> <@U09D64LA420> kannst du uns da wieder nen sharepoint amchen? :stuck_out_tongue:

**2025-10-16T12:46:38.559769** - Julia:
> ja moment das meine ich

**2025-10-16T12:47:05.534929** - Julia:
> 

**2025-10-16T12:56:03.144649** - Julia:
> Sooo: <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/EanELsEUjYtFh4At-DCqLkQBSYJVyEyGZnOcRO2ZT_nP5Q?e=FNHN2H>

**2025-10-16T13:12:12.887789** - Julia:
> Also die ersten Story Übersetzungen liegen ab. Die Wrap Up Story + Captions mache ich nach der MiPa ready :slightly_smiling_face: <@U093J779DAQ>
Videos sind alle fertig so, muss nichts übersetzt werden

**2025-10-16T13:15:04.223139** - Julia:
> Bei Slide 10 gerne mal eure Meinung: da wäre geplant die 2 Reels von Tagen vorher zu reposten mitten in der Story. Fand ich jetzt random aber mal was Neues. Was meint ihr?

**2025-10-16T14:32:28.912669** - Julia:
> Wie wo wann was? :flushed::scream:

**2025-10-16T14:34:39.337169** - Julia:
> Slide 12 sorry. hatte sich jetzt verschoben

**2025-10-16T14:35:18.354139** - Julia:
> Wie wollen sie das einplanen?

**2025-10-16T14:39:42.739869** - Julia:
> 

**2025-10-16T14:53:46.513489** - Julia:
> ist das denn der..:
Macan Turbo (WLTP, vorläufige Werte): Stromverbrauch kombiniert: 20,6 – 18,4 kWh/100 km; CO₂-Emissionen kombiniert: 0 g/km; CO₂-Klasse: A; Stand 10/2025


Aber dachte das ist der GTS oder ist das das Gleiche? ich hab doch keine Ahnung :smile:

**2025-10-16T14:53:49.711219** - Julia:
> HELP

**2025-10-16T15:23:55.874849** - Julia:
> Also alle Übersetzungen und mMn benötigten Assets liegen in der Präsi

**2025-10-16T15:28:03.194359** - Julia:
> Ja

**2025-10-16T15:28:15.195869** - Julia:
> Noch kurze Entscheidung was findet ihr besser als Headline:

**2025-10-16T15:28:48.144689** - Julia:
> Die GTS Familie wächst (sehr nah am Original der PAG)
oder
Noch mehr Power für die GTS Familie

oder
Die GTS Story geht weiter: der neue Macan GTS

**2025-10-16T15:29:28.414479** - Julia:
> je nachdem wäre es super, wenn du <@U093J779DAQ> diese Slide dann noch kurz anpasst. Dann kann ich die Präsi downloaden und dir schicken <@U08V6A47PKN>

**2025-10-16T15:30:04.718789** - Julia:
> okay dann passts, nix anpassen :slightly_smiling_face:

**2025-10-16T16:22:28.262159** - Julia:
> uhhh ich finds total cool! :heart_eyes:

**2025-10-16T16:33:08.788079** - Julia:
> was verkackt? passt doch alles oder bin ich doof :smile:

ich finds wirklich cool. denke für 4x5 müssten man das mittelstück wahrscheinlich noch bissl schneiden

**2025-10-16T16:36:13.897849** - Julia:
> ahhh verstehe haha
finde hier das Logo ganz geil so blurry – vllt kann man ja einen Mix zusammen basteln?

**2025-10-16T17:17:19.071269** - Julia:
> ja

**2025-10-16T17:26:27.236909** - Julia:
> <@U093J779DAQ> hast du Zugriff auf die SOS Präsi die Julia abgelegt hat? Charly hat gefeedbackt und die müssen wir ja morgen bearbeiten. Julia falls du doch nochmal reinschaust

**2025-10-17T08:47:14.664579** - Julia:
> GuMo :slightly_smiling_face: okay danke. Weil so können wir natürlich nichts einplanen bzw. vorbereiten.
<@U093J779DAQ> du kannst das Video ja einfach in Premiere hochladen und der generiert die Übersetzungen direkt, oder? ich hatte das in unserer Unterlage eigentlich dann erst für Montag eingeplant aber dann halt Sonntag. Weil dann könnten wir Hanna später ein paar Dinge rüberschicken:
• Das Reel + die neue Caption von Charly (?) und einplanen
• Halloween BS
• Farbe des Monats Update Feedpost + Story (hatte sie noch nicht gesehen, oder?)
• IG Highlights Update
• Gobi Wallpaper
• Konzept für den Rundgang Teil 3


**2025-10-17T09:18:09.724069** - Julia:
> der sharepoint wird immer wilder

**2025-10-17T09:20:47.998129** - Julia:
> alles klar. dann machen wir es doch so, sobald Halloween auch abliegt schreib ich ihr wegen diesen Updates :slightly_smiling_face:

**2025-10-17T12:10:06.992529** - Julia:
> :zipper_mouth_face:

**2025-10-17T12:10:26.069419** - Julia:
> Ja sonst passt alles :) liegt gleich alles bei Hanna zur Review

**2025-10-20T09:32:00.613239** - Julia:
> Hellooo :slightly_smiling_face: jaa, leider viel zu kurz haha. Bei euch?

**2025-10-20T10:05:27.285459** - Julia:
> die Wärme von Kaptstadt und die Herbstfarben von München :heart_eyes:

**2025-10-20T10:34:25.704889** - Julia:
> Neee das wollt ich eben noch sagen. Haben Hanna ja alles geschickt Freitag Vormittag aber sie hat es sich scheinbar nicht angeguckt 

**2025-10-20T10:34:39.786489** - Julia:
> so nervig 

**2025-10-20T11:00:25.746669** - Julia:
> neee same..

**2025-10-20T12:57:49.259269** - Julia:
> <https://www.instagram.com/reel/DPonqGHCfy1/?utm_source=ig_web_copy_link>

**2025-10-20T12:57:59.648679** - Julia:
> wollten sie ja nichtmehr

**2025-10-20T13:54:19.907409** - Julia:
> ah Mist, ging Asana doch nicht? Hatte da eigentlich dich da grad eig markiert weil Mert schon alles abgelegt hat m 

**2025-10-20T14:32:47.725329** - Julia:
> ja genau

**2025-10-20T14:33:04.158909** - Julia:
> die waren noch nicht ready

**2025-10-20T14:46:17.978989** - Julia:
> <@U093J779DAQ> kanns auch übernehmen – wo liegt das denn?

**2025-10-20T14:49:00.945229** - Julia:
> Ja meinte die Assets. Hä wie komisch, ich hatte die Texte schon drin

**2025-10-20T15:02:04.945039** - Julia:
> Sorry, ich weiß nicht warum das weg war – hatte da eigentlich richtig gute Texte. Vorallem lag jetzt auch als Subline TINS ab; ich war das nicht

**2025-10-20T15:04:26.399619** - Julia:
> das versteh ich nämlich gerade auch nicht

**2025-10-20T15:05:17.832259** - Julia:
> ich checks gerade mit den versionen ab – bzw. versuche es, moment

**2025-10-20T15:25:11.183559** - Julia:
> <@U093J779DAQ> das sind die finalen texte

**2025-10-20T15:26:57.105289** - Mert Koc mentioned Julia:
> <@U09D64LA420> du meinst die hier oder ?

**2025-10-20T15:27:52.453289** - Julia:
> neee eben nicht, die englischen von Julias Screenshot

**2025-10-20T15:40:18.712509** - Julia:
> deine Version wäre natürlich schöner

**2025-10-20T16:02:24.920699** - Julia:
> Ja oder? also ich hab da eh nichts verändert

**2025-10-20T16:02:35.110559** - Julia:
> Wer ist eigentlich dieser Andrés?

**2025-10-20T16:31:50.373229** - Julia:
> bin grad am Macan Wallpaper dran

**2025-10-20T16:53:25.084359** - Julia:
> 

**2025-10-20T16:56:51.182889** - Julia:
> <@U08V6A47PKN> for you

**2025-10-20T17:50:51.203119** - Julia:
> schönen Abend euch! :slightly_smiling_face:

**2025-10-21T08:52:08.736549** - Julia:
> Super. Muss ich irgendwas aus Charley’s Mail beachten bezüglich vorläufig? 

**2025-10-21T09:47:28.069949** - Julia:
> Ahja voll cool 

**2025-10-21T11:23:19.966179** - Julia:
> hier oder <@U093J779DAQ>?

**2025-10-21T11:23:49.250129** - Julia:
> <@U093J779DAQ> Hanna hatte noch einen Kommentar bei der Story für die Farbe des Monats

**2025-10-21T11:27:22.360899** - Julia:
> Ahh!

**2025-10-21T11:36:05.602559** - Julia:
> ich glaube mein internet hier reicht nicht für unser meeting :sob: bin übers Handy drin

**2025-10-21T11:49:59.548699** - Julia:
> Ja oder?

**2025-10-21T12:00:37.644379** - Julia:
> Guuten! Von den anderen Topics (Leica, Halloween usw.) hast du noch nichts gehört oder?

**2025-10-21T12:08:11.969559** - Julia:
> <@U093J779DAQ> --&gt; nochmal ein comment bei story farbe / war nicht richtig verstanden sorry.

**2025-10-21T12:08:15.391779** - Julia:
> Von hanna

**2025-10-21T12:12:53.944519** - Julia:
> Dankeee

**2025-10-21T12:13:01.289149** - Julia:
> Wird jetzt am Donnerstag geposted

**2025-10-21T12:18:57.465049** - Julia:
> Bezüglich BS Halloween usw. meldet sie sich heute Abend

**2025-10-21T14:59:54.978989** - Julia:
> Asana geht bei euch auch wieder normal oder?

**2025-10-22T09:07:40.857649** - Julia:
> Halloo :slightly_smiling_face: bin jetzt auch dran und schau es mir an

**2025-10-22T09:18:09.675779** - Julia:
> 0:27 --&gt; Er oder es?
1:06 --&gt; als leidenschaftlicher Gamer?
2:00 --&gt; Statt Garage vllt bei dir Zuhause
2:30 Würde auch Sound nehmen
3:05 --&gt; unterhaltsam und macht Spaß (umdrehen)
3:51 --&gt; um den Sound zu hören (statt genießen)
3:58 Bucket List würde ich auch lassen

**2025-10-22T09:18:39.358369** - Julia:
> Puh muss sagen, das Video zieht sich schon ganz schön und würde nicht behaupten, dass das Quickfire Q&amp;As sind :smile:

**2025-10-22T09:19:16.899049** - Julia:
> hellloo :slightly_smiling_face: cool!

**2025-10-22T10:46:29.542869** - Julia:
> ich hab heute Mittag einen Sport Kurs gebucht :face_with_peeking_eye: aber wäre bis 11.30 noch da! Oder danach..?

**2025-10-22T10:57:56.555209** - Julia:
> oke. Ich packe schnell meine Tasche dann kann ich direkt los :)

**2025-10-22T11:23:08.730189** - Julia:
> Ah vergessen: Rundgang 1 ist ja eigentlich Montag geplant – bleibt das dabei?

**2025-10-22T11:54:10.574399** - Julia:
> Ich würde eher von „es“ sprechen wegen Fahrzeug

**2025-10-22T13:18:08.868629** - Julia:
> FYI; hab Charly in WhatsApp geantwortet. Das wusste ich nicht, Mist..
Aber sie hat’s freigegeben :melting_face:

**2025-10-22T14:17:27.017639** - Julia:
> ich leider nicht..

**2025-10-22T15:27:37.432529** - Julia:
> hab ichs schon mal gesagt: ich hasse diese online präsis :smile: :smile: :smile:

**2025-10-23T09:59:42.485629** - Julia:
> halloo :slightly_smiling_face: wir haben um 10.30 Huddle oder?

**2025-10-23T10:28:36.136669** - Julia:
> Ja voll, ich habs ja nur nicht mehr im Kalender

**2025-10-23T11:31:09.528999** - Julia:
> Was wurde eigentlich aus Mark Webber TINS?

**2025-10-23T11:41:01.892559** - Julia:
> okay, schade

**2025-10-23T13:14:17.587159** - Julia:
> Hab in die übergabe alles soweit reingeladen, was ich erstellt hab und weiß wo es abliegt

**2025-10-23T15:59:10.530859** - Julia:
> stimmt, macht sinn

**2025-10-23T17:38:46.189729** - Julia:
> Ich mache mal Feierabend :slightly_smiling_face:
<@U093J779DAQ> sollen wir morgen früh einen kurzen Huddle machen?
Happy evening und weekend <@U08V6A47PKN>! :heart:
Die letzten Taaaaage whoop

**2025-10-23T17:45:02.562529** - Julia:
> Neee hör auf! wie denn das? Das tut sooo weh.. wie gehts dir?

**2025-10-24T09:47:31.280739** - Julia:
> jaa! Ich hab das jedes Jahr 1x und mir hilft am allermeisten die Zwiebeln klein schneiden, in den Ofen und dann in so kleine Säckchen oder Socken und auf die Ohren legen – das bewirkt wirklich wunder!

**2025-10-27T09:32:24.538079** - Julia:
> echt? Also eigentlich war garnichts, hatte kurz mit Charly wegen den Posts am WE und Repost geschrieben. Hanna hatte die BS Assets angeguckt und wollte sie mit Denise sharen – mehr wissen wir nicht :face_with_peeking_eye:

**2025-10-27T09:32:43.131109** - Julia:
> Hallooo :slightly_smiling_face:

**2025-10-27T09:34:07.688809** - Julia:
> Also ich hab den gestrigen Tag in der bereitschaftspraxis verbracht - so einen Sonntag lieben wir :smile:
Hab mir so den Ischias eingeklemmt und bin jetzt erstmal nur im Liegen erreichbar.

Bei diiir?

**2025-10-27T09:41:13.307519** - Julia:
> Dankeee. können direkt das Krankenlager hier aufmachen haha

**2025-10-27T11:20:17.119979** - Julia:
> ja die offenen Dateien dafür würden Sinn machen

**2025-10-27T11:20:26.496579** - Julia:
> Nööö

**2025-10-27T13:51:58.996249** - Julia:
> Sagt Bescheid, wenn ich was helfen kann. Bin wieder da

**2025-10-27T13:52:41.116879** - Julia:
> ja der Krisen Workshop wahrscheinlich: <https://www.focus.de/finanzen/news/nach-startegieschwenk-porsche-meldet-gewinneinbruch-von-95-9-prozent_605c49b0-52c2-4848-bdd7-828a896f446b.html>

**2025-10-27T13:59:34.464689** - Mert Koc mentioned Julia:
> <@U09D64LA420> Ich würde Emmy jetzt die Weeklies nochmal per Mail schicken und die Freigabe holen, wenn Hanna noch nicht auf die Präsi geantwortet hat :slightly_smiling_face:

**2025-10-27T14:03:03.723209** - Julia:
> jaa sollen die dann direkt klären

**2025-10-27T15:10:09.571889** - Julia:
> Ich kann halt leider die Rundgang Assets alle noch nicht ablegen :melting_face:

**2025-10-27T15:35:13.602819** - Julia:
> hab kurz kein Internet, bei uns kommt ein Techniker weil das wlan so spinnt 

**2025-10-27T16:10:10.249889** - Julia:
> kanns mit meinem lahmen hotspot grad nicht hochladen :sleepy:

**2025-10-27T16:19:42.632999** - Julia:
> danke :heart_hands:

**2025-10-27T16:27:53.996559** - Julia:
> alles=

**2025-10-27T16:29:11.373849** - Julia:
> obs am Ende trotzdem unser Fehler ist? JA

**2025-10-27T16:31:04.523689** - Julia:
> wie geschrieben Mert "keine Zeit für den Text" --&gt; die 2 Minuten klar

**2025-10-27T17:19:37.826489** - Julia:
> Das stimmt, happy feierabend! T-4 Wuhuuuu :heart:

**2025-10-28T11:41:10.996789** - Julia:
> die Leute haben so krasse Vorstellungen :smile:

**2025-10-28T13:19:04.005419** - Julia:
> bin jetzt auch mal unterwegs, bis gleich!

**2025-10-28T14:43:45.037199** - Julia:
> Weils so viel Feedback gibt oder wie haha 

**2025-10-28T14:58:20.935509** - Julia:
> Österreichs Wildnis? :joy: ne aber sowas vllt? 

**2025-10-28T15:30:54.580829** - Julia:
> Hat sie was wegen den rundgängen gesagt?

**2025-10-28T15:52:51.979629** - Julia:
> ja voll

**2025-10-28T15:53:31.498169** - Julia:
> oder kann man aus dem artikel irgendwas emotionales rausziehen?
"abwechselungsreiche/ abenteuerliche route von ..."

**2025-10-28T16:06:34.294429** - Julia:
> Ich würde Route Triest (war das Ziel oder?) schreiben  

**2025-10-28T16:43:08.640159** - Mert Koc mentioned Julia:
> <@U09D64LA420> :grin:

**2025-10-28T17:05:25.155679** - Julia:
> ah sorry hatte den thread nicht gesehen. Ja das passt doch. Du hast es ja sehr analog dem Magazin erstellt oder? 

**2025-10-29T09:16:53.270079** - Julia:
> was mir noch eingefallen ist: bei der caption müssten wir halt schauen wegen "letzte kurven", wann sie es posten wollen

**2025-10-29T09:19:20.176349** - Julia:
> im schlaf verfolgt.. :pensive:

**2025-10-29T12:52:27.013229** - Julia:
> Ja ist doch gut. vllt der Macan GTS? als neues Modell

**2025-10-29T13:24:24.150009** - Julia:
> bin jetzt auch bissl mit coco draußen 

**2025-10-29T15:08:52.976549** - Julia:
> gore? :smile:

**2025-10-29T15:34:26.506249** - Julia:
> hahahah JA

**2025-10-29T15:57:17.850679** - Julia:
> Hanna kommentiert auch gerade in die BS Präsi

**2025-10-29T16:57:32.886439** - Julia:
> jetzt kommentiert sie NOCHMAL alle Storyslides mit neuen Texten.. ich glaube es nicht, leute :smile:

**2025-10-30T09:22:50.111609** - Julia:
> Guten Morgen! :slightly_smiling_face:
Ahh ich hab sooo verschlafen, das passiert mir echt nie. Bin gleich da aber ohne Kamera :joy:

**2025-10-30T09:28:18.570589** - Julia:
> Wie ihr mögt aber wäre sonst jetzt da :slightly_smiling_face:

**2025-10-30T09:31:04.148119** - Julia:
> bin im huddle, hoffe der link ist richtig

**2025-10-30T10:22:22.817189** - Julia:
> ob sie von Design/ Texten keine Ahnung haben :smile:

**2025-10-30T10:22:38.676609** - Julia:
> voll der gute Einstieg :new_moon_with_face:

**2025-10-30T10:46:01.311889** - Julia:
> hast du die Asana Task schon mit uns geteilt <@U08V6A47PKN>? Finde es gerade nicht

**2025-10-30T14:11:40.939009** - Julia:
> Konfi post passen für Hanna :slightly_smiling_face:

**2025-10-30T14:11:53.064919** - Julia:
> mach daaas. Bei uns regnet es sooo :sleepy:

**2025-10-30T14:44:09.086789** - Julia:
> das ist der Figma Link: <https://www.figma.com/design/902cDjeQLIyg77xt49VdZg/Porsche-DE-%F0%9F%8F%8E%EF%B8%8F?node-id=1-205>

**2025-10-30T14:45:49.924529** - Julia:
> • Weekly Stories: <https://www.figma.com/design/JrbypsbvDwTvRRgwvqhdvd/Porsche-BS-%F0%9F%9B%8D%EF%B8%8F?node-id=58-81> 
+ Die alten Vorlagen von <@U093J779DAQ>
• Rundgang hast du jetzt ja
• Konfi: <@U093J779DAQ> 
• Highlights: <@U093J779DAQ> 
• Malmedie: <@U093J779DAQ> 


**2025-10-30T14:54:26.389219** - Julia:
> ich würde dann auch gleich mal Pause machen – muss noch ein paar Party Vorbereitungen für morgen treffen :slightly_smiling_face:

**2025-10-30T15:23:03.730089** - Julia:
> bestes Gefühl ever :joy:

**2025-10-30T16:58:45.658909** - Julia:
> Ne Rundgang Stories liegt auch in den Ordner mit ab 

**2025-10-30T17:44:27.135579** - Julia:
> was meinst du mit was noch auf sprinklr muss? Stories sind ja eh händisch oder? :)
Eintragen yes.
Danke dir und happy Weekend und urli :heart_eyes:

**2025-10-31T09:05:20.915299** - Julia:
> Okidoki

**2025-10-31T09:31:00.063789** - Julia:
> das sind die hier alle, oder?

**2025-10-31T09:56:51.708479** - Julia:
> true that – datum checken wäre eine idee gewesen hahaha

**2025-10-31T09:57:30.490119** - Julia:
> komisch, jetzt ist es 2mal da. Aber passt, danke :slightly_smiling_face:

**2025-11-10T09:14:33.841809** - Julia:
> Hallooo :slightly_smiling_face:

**2025-11-10T09:14:48.788049** - Julia:
> Wollen wir in 15-20 Minuten sprechen? Mert ist heute off

**2025-11-10T09:15:21.904129** - Julia:
> du hast auch irgendwie alles und nichts verpasst hahaha

**2025-11-10T09:25:12.281159** - Julia:
> gernee

**2025-11-10T09:32:34.658399** - Julia:
> ahh jetzt waren wir gleichzeitig

**2025-11-10T09:32:38.469159** - Julia:
> dann komm ich in deinen

**2025-11-10T11:41:23.308329** - Julia:
> :joy: liebs

**2025-11-10T11:44:08.511599** - Julia H. mentioned Julia:
> Huhuuu ihr beiden,
ich bin jetzt mal alle Dokumente durchgegangen und ich hab hier mal ungefiltert meine Fragen aufgelistet.

• Gorenje Instagram ist noch nicht aufgesetzt worden oder?
• Teams bin ich eingeloggt aber ich seh noch Porsche, hattet ihr da ne Mail oder so bekommen von Flo?
• Meeting Notes im Nachgang --&gt; <@U09D64LA420> Kannst du Jana bitte mal fragen wo die Notes der vorherigen Meetings liegen oder sie bitten die Notes der letzten 3-5 Meetings weiterzuleiten.
• Haben wir sonst irgendwo eine Art Bilddatenbank etc für die Produkte?
• Wie sieht es mit Brand-Kooperationen aus? Wissen wir dazu was? Im Grunde kann man ja da super viel machen (Stichwort everdrop :stuck_out_tongue:)
• *Produktionen:*
    ◦ Pascal Hens Shooting wird als Hauptkampagne genutzt --&gt; Wisst ihr, was das genau bedeutet? In der Präsentation sind ja nur Content Ideen drin, aber nirgends, wie sich die Kampagne aufbaut, ob es feste Bestandteile gibt, Claims, Postingplan? 
    ◦ Zu den Produktionen generell ist noch gar nichts geplant oder?
    ◦ Budget Produktionen /Abstimmung Freigaben
    ◦ Content Creator Entscheidung Y/N - Vorstellung Kunde? Wer entscheidet?
    ◦ Hisense Produktion 25.&amp;28. → Direkt an hintereinander folgenden Tagen wäre doch viel einfacher → Setup etc?
    ◦ Technik &amp; "Crew"?

**2025-11-10T11:52:01.758619** - Julia:
> Ich antworte mal Schritt für Schritt:
• Teams ist hier einfach so eine Gruppe, da bist du eigentlich auch mit drin. Hier nochmal der Link: <https://teams.live.com/l/invite/FEAE-pbGHgdVo-ySA>

**2025-11-10T12:03:18.604979** - Julia:
> • nein, sollen wir das am Mittwoch ins Meeting mitnehmen. Weißt nicht, ob wir das einfach dürfen?
• hab sie gefragt
• Schätze das hängt mit der CI zusammen --&gt; soll ja von Marvin kommen
• keine Info (jaaa mussten wir auch sofort dran denken, Flashbacks :smile:)
• Pascal: ne, hatte ich Jana auch nochmal gefragt. Versteh ich auch nicht
• nein
• Info von Jana tbd.
• wir sollen welche vorstellen
• ja total. Die Daten kamen von uns – woher weiß ich nicht
• keine Infos bisher


**2025-11-10T12:29:00.632539** - Julia:
> jetzt seh ich, dass du in Teams neu drin bist

**2025-11-10T13:16:57.484859** - Julia:
> Ah vllt noch als Tipp <@U08V6A47PKN>: ich hab mir mit meiner Bold-Mail einfach einen TikTok Account erstellt. Dann bekomme ich auch nur den Content angezeigt, der dafür relevant ist

**2025-11-11T09:20:33.708869** - Julia:
> Hello :slightly_smiling_face: sie kommunizieren damit hauptsächlich mit der TikTok Ansprechpartnerin

**2025-11-11T11:26:27.273589** - Julia:
> Jana hat mir gerade geantwortet, dass sie dran sind und mir asap ein update schickt

**2025-11-11T11:26:55.680019** - Julia:
> ja voll. eigentlich ja heute schon Singles Day..

**2025-11-11T11:32:09.870959** - Julia:
> :smile: ihre anderen Persönlichkeiten vllt?

**2025-11-11T11:34:28.319769** - Julia:
> Leute, ich bin echt noch nicht soo fit (und eigentlich ja auch bis Freitag krankgeschrieben). Ich mach ein Päuschen und leg mich nochmal hin. Ich bin ab 16 Uhr im Zug nach München und würde mich die Zugfahrt über mit den Creatorn beschäftigen

**2025-11-11T11:59:41.053149** - Julia:
> Flo hat jetzt einen Chat erstellt und mich angerufen

**2025-11-11T12:00:00.504569** - Julia:
> uhh bekomme jetzt die Mails, ihr auch?

**2025-11-11T12:03:02.323529** - Mert Koc mentioned Julia:
> <@U09D64LA420> leitest du an Julia weiter oder soll ich? :slightly_smiling_face:

**2025-11-11T12:06:23.624699** - Julia:
> mach ich schnell

**2025-11-11T12:07:47.476479** - Julia:
> ja glaub das wollte er jetzt kurz klein halten

**2025-11-11T12:07:58.668769** - Julia:
> er ist auch maximal abgefucked hab ich gemerkt

**2025-11-11T14:35:28.524689** - Julia:
> nochmal <@U08V6A47PKN>

**2025-11-11T17:01:05.165199** - Julia:
> juhuu

**2025-11-11T18:19:15.654939** - Julia:
> Spoiler: it never happend

**2025-11-12T09:31:11.780939** - Julia:
> Hello :slightly_smiling_face: Ja same..

**2025-11-12T09:43:28.676049** - Julia:
> ja, also wir haben jetzt gleich den Paid termin zumindest

**2025-11-12T11:04:04.094269** - Julia:
> So der Termin ist durch. Im Übergabe Dokument jetzt <https://docs.google.com/document/d/1PbEVpTroRccqnCrtHg53hsJWhv4qibQldX2fX5jIRyY/edit?tab=t.t5im4sgc3pz8#heading=h.gwxo6wy7zmzd|eine neue Seite >+ ganz unten Infos zu Paid --&gt; sollen wir uns durchlesen (ist ChatGPT Copy paste)

Weitere Infos:
• Redaktionsplan ist aktuell bei KW37 —&gt; einfach "durcheinander", sie weiß nicht warum. Sollen wir uns überlegen, wie wir das aufbauen/ fixen wollen
• Offen KW37: 2 Videos mit Feedback von Laureen --&gt; frage ich gleich bei Jana an, sonst später im Meeting
• Posting Uhrzeit: nicht speziell
• Nach dem Posten: direkt Thumbnail + Überschrift TikTok anpassen


**2025-11-12T11:06:50.487089** - Julia:
> Paid Kampagne Schritt für Schritt:
1. Organisch Posten 
2. danach direkt in den Paid Account einloggen _(Zugangscode von Flo)_
3. *BCC_Hisense!!* kein anderer
4. Kampagne —&gt; Welches Ziel? Nicht auf Reichweite gehen
5. Für uns: bisher *Video Views* (für wenig Budget am besten) + *Community Interaktion* (kostet natürlich am meisten)
6. Deswegen gerade nur auf *Video Views* gehen
7. Sind bei TikTok unter der Grenze —&gt; Muss auf 50€ Budget am Tag gehen 
8. Add group —&gt; bleibt so stehen
9. _Wie lange laufen die Kampagnen?_ Bis morgen einstellen, damit sie automatisch beendet wird
10. die alte Ad oben noch deaktivieren und oben auf Add klicken
11. —&gt; Add Video, umbenennen etc.
12. *Publish all --&gt; Done!*
13. Oder manuell abschalten: bei über 10k Views

Am besten erklären wir dir das dann am Tool direkt

**2025-11-12T11:07:38.249239** - Julia:
> Neue Strategie:
Empfehlungen von Jana
• View Kampagne hinterlegen + CI Kampagne den ganzen Monat laufen lassen —&gt; so sind alle Videos in der CI Kampagne drin &amp; so haben wir ein Kampagnen Budget und kein Tagesbudget! (500€)
• in der CI Kampagne werden dann alle Videos hochgeladen die gepostet werden
+ die Tages Kampagne laufen
--&gt; Mert: lieber dann unseren Content pushen + brauchen dringend mehr Budget!

**2025-11-12T11:10:06.458679** - Julia:
> To Do's next:
• Juli: Jana 2 Videos von KW37 fragen
• Julia: erstmal nur im TikTok Business Manager anmelden (siehe Übergabe Dokument --&gt; Code von Flo anfordern)
• all: im Meeting später TIkTok Zugang mit Laureen --&gt; Codes
• all: morgen oder asap Termin mit Flo: wieviel Paid Budget können wir vom Agentur Budget abgeben? Brauchen dringend eine neue Budget Vorgabe!
• Mert &amp; Juli: Termin morgen/ Freitag mit Jana, um neue Kampagne anzulegen
• Julia: Video Freigaben mit Laureen ab KW41 im Redaktionsplan besprechen
Soweit alles klar für euch? <@U08V6A47PKN> <@U093J779DAQ>

**2025-11-12T11:15:37.941579** - Julia:
> Ich denke nicht, oder? Schickst du ihnen eine Agenda? Da müssten wir halt dann auf das mit den TikTok Codes aufnehmen

**2025-11-12T12:18:38.280999** - Julia:
> Flo hat mir einen Code geschickt:

**2025-11-12T12:18:43.180709** - Julia:
> DVSWAA

**2025-11-12T12:58:50.023679** - Julia:
> klar. können wir! aber denke auch es wird eher ein "hallo, wer seid ihr..." blabla

**2025-11-12T13:01:34.544109** - Julia:
> also wie ihr wollt, bin da :slightly_smiling_face:

**2025-11-12T13:15:04.964829** - Julia:
> okee

**2025-11-12T13:15:55.120289** - Julia:
> Mert und ich haben vorhin auch noch gesprochen nach dem Meeting und mal ganz ehrlich: wenn die Kunden mit einem Redaktionsplan zufrieden sind, der seit 10 Wochen nicht gepflegt wurde oder whatever, können wir garnicht so viel falsch machen :new_moon_with_face:

**2025-11-12T13:19:27.472859** - Julia:
> hab grad gesehen, dass Jana auf Flo's Nachricht geantwortet hat. Macht natürlich Sinn, mich da dann nicht zu markieren

**2025-11-12T13:23:29.700979** - Julia:
> Und FYI, weil jana antwortet einsilbig. Hab ich jetzt an Flo, Marvin und Jana geschickt

**2025-11-12T13:23:39.607539** - Julia:
> Ja genau, das macht sie dauernd

**2025-11-12T13:28:29.951089** - Julia:
> Marvin meinte nach unserem Meeting mit H, sollen wir kurz mit ihm sprechen bezüglich Redaktionsplan. Könnt ihr da?

**2025-11-12T13:28:39.767139** - Julia:
> Ich muss nur um 15Uhr dann kurz weg

**2025-11-12T13:31:47.744979** - Julia:
> okay, sags euch gleich. Weil er hat laut Kalender um 15Uhr eigentlich noch ein Meeting

**2025-11-12T13:31:48.942709** - Julia:
> jaa

**2025-11-12T13:39:36.477769** - Julia:
> kann jemand von euch teilen? ich kann was sagen aber nicht bildschirm teilen

**2025-11-12T13:47:25.940649** - Julia:
> ich versteh nicht, was wir hier machen

**2025-11-12T13:49:54.717529** - Julia:
> willst du, soll ich?

**2025-11-12T13:51:23.901009** - Julia:
> ja gerne

**2025-11-12T13:56:14.801069** - Julia:
> Termin mit Marvin um 14.30

**2025-11-12T13:59:55.574049** - Julia:
> wie machen wir weiter?

**2025-11-12T14:02:53.134639** - Julia:
> neee :smile:

**2025-11-12T14:03:36.531319** - Julia:
> müssen die ideen nochmal genauer vorstellen

**2025-11-12T14:06:00.844249** - Julia:
> ja genau

**2025-11-12T14:21:24.456029** - Julia:
> was ist heimkinoraum?

**2025-11-12T14:21:48.218619** - Julia:
> liebs so, wie wir da alle sitzen und keine ahnung haben von irgendwas

**2025-11-12T14:22:34.137159** - Julia:
> jaa ist es, ist ja wild

**2025-11-12T14:31:13.044299** - Julia:
> ja

**2025-11-12T14:31:36.361969** - Julia:
> müssen die ideen eben noch runterbrechen und finalisieren

**2025-11-12T14:32:24.534849** - Julia:
> termin mit marvin morgen früh

**2025-11-12T14:36:48.634779** - Julia:
> wärd ihr ready wegen den tiktok codes? dann frag ich gleich Laureen

**2025-11-12T14:37:46.084569** - Julia:
> JA

**2025-11-12T14:39:32.035499** - Julia:
> also ich frag mich, ob das tiny house überhaupt dann sinn macht oder ob wir nicht lieber creator suchen sollen/ studios die dann gleich die perfekte umgebung sind?

**2025-11-12T14:40:57.108699** - Julia:
> ja oder das

**2025-11-12T14:41:04.437939** - Julia:
> ohne creator kriegen wir das schon hin

**2025-11-12T14:53:31.834579** - Julia:
> mit uns 3 :fast_parrot::fast_parrot::fast_parrot:

**2025-11-12T14:53:40.331949** - Julia:
> Habt ihr eigentlih einen Lieblingsemoji? :smile:

**2025-11-12T15:02:41.567099** - Julia:
> voooooll

**2025-11-12T15:03:02.418179** - Julia:
> also ich muss jetzt los. sollen wir morgen volle power geben?

**2025-11-12T15:03:34.246989** - Julia:
> lieb ich beide. meiner der hier: :melting_face: hahaha

**2025-11-12T15:07:08.463059** - Julia:
> cool, danke :slightly_smiling_face:

**2025-11-12T17:15:20.679689** - Mert Koc mentioned Julia:
> <@U09D64LA420>  sollen wir einfach dein Konzept mit Ray teilen oder willst du es eher vorstellen? 

**2025-11-13T09:03:59.906619** - Julia:
> Ahh sorry! Dankee

**2025-11-13T09:06:05.801039** - Julia:
> Halloo, ja sehr gerne :slightly_smiling_face:

**2025-11-13T09:07:26.558229** - Julia:
> Jana hat uns angeschissen, warum wir die Kampagne nicht offline gestellt haben <@U093J779DAQ>
Das müssen wir uns jetzt auch unbedingt merken bzw. wenns klappt heute mit Flo alles besprechen

**2025-11-13T09:16:28.019349** - Julia:
> Ja genau

**2025-11-13T09:36:22.167509** - Julia:
> FYI: mein WLAN ist seit gestern einfach weg. Techniker kommt am Montag YAY. Bin also mit unstabilem Hotspot dauernd drin :smiling_face_with_tear:

**2025-11-13T09:47:30.418019** - Julia:
> habt ihr noch fragen/ themen?

**2025-11-13T11:12:07.094239** - Julia:
> jaa hab ich auch gelesen! es gibt ja gottseidank auch so wohnungen die man mieten kann. ich schau mal und erstelle dann eine neue präsi :slightly_smiling_face:

**2025-11-13T11:17:33.492189** - Julia:
> Also Leute ich schaue ja gerade alle Videos an: WAS ZUR HÖLLE? :joy: die sind SO schlecht

**2025-11-13T11:17:46.293349** - Julia:
> Teilweise wird der Ton auch einfach am Ende abgeschnitten

**2025-11-13T11:31:53.243159** - Julia:
> Super, alles klar verständlich

**2025-11-13T12:23:44.856759** - Julia:
> FYI: Flo zieht mich gerade noch bisschen auf andere Projekte/ Kunden und will zB noch was von mir für BitPanda heute. Also nur, dass ihr Bescheid wisst

**2025-11-13T12:30:09.235389** - Julia:
> glaube da pitchen sie

**2025-11-13T12:30:46.290319** - Julia:
> aber so genau weiß ich es auch nicht. Finds auch bissl schade, dass man sowas nicht in einer großen Runde teilt. sind ja voll coole agentur news, wenns dann neue kunden gibt

**2025-11-13T14:12:43.592339** - Julia:
> ohh aber wie gut, dass du warst :slightly_smiling_face:

**2025-11-13T14:13:58.698169** - Julia:
> also ich muss jetzt tatsächlich heute erstmal für Bitpanda arbeiten. <@U093J779DAQ> hättest du schon mal Kapa bezüglich Ideen ausarbeiten oder "Airbnb's" suchen?
Versuche da später auch noch was zu machen
Morgen bin ich sicher raus, weil ich da ab 9Uhr im Büro bin und bei dem MINI Pitch dabei bin :face_with_peeking_eye:

**2025-11-13T14:52:50.897799** - Julia H. mentioned Julia:
> An sich brauchen wir uns ja nicht Stressen, der Ball liegt ja eh gerade beim Kunden und wir können das auch nächste Woche machen. <@U093J779DAQ> <@U09D64LA420> ?

**2025-11-13T14:59:59.213509** - Julia:
> klar :slightly_smiling_face: bin gespannt, wann sie sich melden

**2025-11-13T16:07:29.400619** - Julia:
> Bei mir sind glaub ich die Änderungen noch nicht drin. du hast ja die captions wahrscheinlich auch alle angepasst oder?

**2025-11-13T16:07:58.603739** - Julia:
> oder bin ich im falschen Dokument :joy: der ist bei Asana verlinkt: <https://docs.google.com/spreadsheets/d/1VYT-H11Hjf0aetErKOVdDvb5MmLnQegQIOa1oICnApQ/edit?gid=2103663789#gid=2103663789>

**2025-11-13T16:13:57.826059** - Julia:
> Achso okay. Aber die Videos mit "raus" sind nichtmehr drin, oder?
Reihenfolge passt ja soweit und würde die restlichen Videos dann einfach "nachrücken" bzw. so planen, dass natürlich die fertigen Videos erstmal kommen, im Dezember dann die mit den Anpassungen. Die 2 Videos bei denen ich es dazu geschrieben hab, gerne umplanen. 1x für nächste Woche (als Ersatz für das was raus soll zB) und einmal das Stirb Langsam um die Weihnachtszeit.
Magst du in dem Zuge dann noch eine WIP Markierung bei den Videos einbauen, an denen wir zB nochmal etwas anpassen müssen? Dankeee

**2025-11-13T16:14:34.510369** - Julia:
> Könnten ja das "M" als WIP umändern

**2025-11-14T11:37:46.920149** - Mert Koc mentioned Julia:
> Good News, ich bin im TikTok Account drinnen, Laptop + Handy :slightly_smiling_face:
Habe ich gerade mit Laureen in Teams geklärt <@U09D64LA420>  Vielleicht klappt es jetzt bei dir auch

**2025-11-14T12:11:34.594409** - Julia:
> ah mega! Perfekt, mach ich gleich nach der MiPa :slightly_smiling_face: danke dir

**2025-11-14T14:23:24.672069** - Julia:
> perfekt, vielen Dank! Schicke ich an Laureen mit den Infos

**2025-11-14T14:30:19.263029** - Julia:
> würdest du dann am Sonntag auch posten?

**2025-11-14T16:26:36.304059** - Julia:
> Kurze Info bezüglich des Tiny Houses: hatte ein Meeting mit Rückenwind (die haben das gebaut?) und sie meinten das Tiny House muss am 18.11. wieder in Berlin abgebaut werden, das wäre ihre Info. Ich gebe diese Info mal an Laureen weiter

**2025-11-17T08:48:33.909209** - Julia:
> Hello! :slightly_smiling_face: Jaa sehr und du?

**2025-11-17T08:48:57.029009** - Julia:
> Oh wow, das ist immer ewig. Klar gerne

**2025-11-17T09:31:15.604549** - Julia:
> Diese Ämter sind überall auf der welt einfach nur nervig :joy:

**2025-11-17T09:31:44.777049** - Julia:
> also unser Techniker fürs internet kommt heute doch nicht – ich fahr jetzt gleich zu meiner Mama und arbeite von da FYI. wie du sagst Julia: was ein Montag

**2025-11-17T11:00:57.391259** - Julia:
> okee

**2025-11-17T11:01:10.451779** - Julia:
> ich bin übrigens voll in BitPanda drin, kann ich euch gleich mal zeigen :slightly_smiling_face:

**2025-11-17T11:26:45.661109** - Julia:
> ja gerne

**2025-11-17T12:17:33.764619** - Julia:
> 

**2025-11-17T12:40:33.951739** - Julia:
> hööö

**2025-11-17T13:27:06.389919** - Julia:
> Klassiker:
• *Schöne Bescherung*
• *Charlie und die Schokoladenfabrik*
• *Tatsächlich … Liebe*
• *Drei Haselnüsse für Aschenbrödel (lame)*

**2025-11-17T15:07:05.389129** - Julia:
> POV: hätte nicht gedacht, dass ich mich jemals in meinem beruflichen Leben damit auseinander setze :smile:

**2025-11-17T15:08:11.815699** - Julia:
> hilfe Chatgpt

**2025-11-17T15:10:18.961839** - Julia:
> Ich hab noch kurz eine andere Frage bzw. benötige eure kreative Hilfe :fast_parrot:

Es geht um dieses Konzept für Bitpanda "Reason Why" – anbei nochmal hier als Screenshots
Die Umsetzung hab ich euch ja vorhin gezeigt aber hier nochmal mit Ton – wollen wir ja anpassen.
Ich hab das jetzt mal umgeschrieben, wie findet ihr das bzw. habt ihr sonst noch eine Idee wenn man das sonst cool machen könnte?

**2025-11-17T15:10:47.414669** - Julia:
> 

**2025-11-17T15:10:56.831569** - Julia:
> Neuer Ansatz. What do we say?

**2025-11-17T15:21:44.268909** - Julia:
> Ja versteh ich, danke dir! Hab grad parallel mit Flo gesprochen, der hatte da nochmal eine etwas andere Vorstellung. Muss es nochmal umbauen haha

**2025-11-17T15:22:48.649609** - Julia:
> witzig, genau das will Flo auch. Er will mehr Story.
ich dachte so kurz wie möglich aber er meinte auch so die italienische Oma usw. hahaha

**2025-11-17T16:02:10.221019** - Julia:
> oh das wäre ja auch perfekt

**2025-11-17T16:57:05.195979** - Julia:
> Uhh viel Glück! :heart_hands:

**2025-11-18T09:00:49.666999** - Julia:
> Guten Morgen! Ich glaube ich schaffe es nicht in den SoMe Call, wir müssen bei 13Uhr die ganzen Videos fertig machen :melting_face:

**2025-11-18T09:33:29.789849** - Julia:
> Okay :heart_hands:

**2025-11-18T09:33:36.727359** - Julia:
> bin gespannt auf den Termin heute nachmittag..?

**2025-11-18T09:40:37.077519** - Julia:
> vllt werden wir doch abgehört

**2025-11-18T09:40:39.080269** - Julia:
> :new_moon_with_face:

**2025-11-18T10:19:54.335659** - Mert Koc mentioned Julia:
> Soll ich einfach das TikTok von heute hochladen <@U09D64LA420>?

**2025-11-18T10:38:21.474799** - Julia:
> ja gerne!

**2025-11-18T11:53:28.978589** - Julia:
> ah sorry, war im tunnel. Ne um 11

**2025-11-18T11:53:33.052939** - Julia:
> Hats geklappt?

**2025-11-18T11:54:44.786889** - Julia:
> ahh okay!

**2025-11-18T11:55:12.576909** - Julia:
> sollen wir morgen früh kurz sprechen wegen offenen to-do's fürs meeting mit Hisense nachmittags? Kann morgen wieder voll einsteigen!

**2025-11-18T11:56:51.950769** - Julia:
> Und FYI :slightly_smiling_face:  (leider nicht seine Originalstimme, das klappte rechtlich einfach nicht)

**2025-11-18T12:14:21.625979** - Julia:
> und wann steigst DU ein Julia? :smile:

**2025-11-18T12:55:38.865369** - Julia:
> ich hab wieder WLAN :fast_parrot:

**2025-11-18T16:03:31.383449** - Julia:
> :joy:

**2025-11-18T16:17:04.735739** - Julia:
> ich hab das gefühl es wird jetzt nicht mehr so in kleinen teams gearbeitet, oder? Was meint ihr?

**2025-11-18T16:17:35.920759** - Julia:
> also mit den neuen kunden. dann müssten sie ja nochmal neue teams einstellen

**2025-11-18T16:23:07.154359** - Julia:
> ja bei Bitpanda haben wir eine WhatsApp Gruppe zu 3. (obs unangenehm ist?) :smile: und da gibt er schon auch Feedback, aber am Ende wird das umgesetzt was Flo sagt

**2025-11-18T16:23:21.316349** - Julia:
> aber er war ganz süß, hat sich dann auch gleich bedankt

**2025-11-18T16:24:44.526499** - Julia:
> ih, das hat Ersin auch

**2025-11-18T16:26:09.821199** - Julia:
> "Hi, ich bin der Alex" :smile:

**2025-11-18T16:35:34.069439** - Julia:
> finde er ist auch eine Maus

**2025-11-18T17:15:39.720959** - Julia:
> ich bin dann mal off. schönen Abend euch &amp; bis morgen! :heart_hands:

**2025-11-19T09:01:20.597219** - Julia:
> Hello! yes, viel Spaß :slightly_smiling_face:

**2025-11-19T12:23:40.335639** - Julia:
> Wollen wir die Creator/ Brands heute schon vorstellen? Glaube so schnell sind wir dann doch nicht

**2025-11-19T12:39:28.276969** - Julia:
> FYI <@U08V6A47PKN>

**2025-11-19T12:45:23.660519** - Julia:
> oh wow sorry:
<https://docs.google.com/presentation/d/1rbYB7aLiZwdcgXMezmgL1kWXM0APEyGw64nXlBrXhpY/edit?slide=id.g3a64d1ec782_0_33#slide=id.g3a64d1ec782_0_33>

**2025-11-19T12:46:57.346459** - Julia:
> Cool! mega gut zusammengefasst.
Sollen wir noch ergänzen: Unsere Empfehlung: Langfristig Option B, Kurzfristig: Option C.?

**2025-11-19T12:48:23.772719** - Julia:
> jaaa. so witzig, hab vorhin versucht die erste Slide zu bearbeiten und diesen komischen verlauf rauszunehmen – ging nicht

**2025-11-19T14:05:02.090689** - Julia:
> dein ton ist irgendwie sehr leise

**2025-11-19T15:00:32.228609** - Julia:
> voooll

**2025-11-19T15:08:45.616339** - Julia:
> • seh ich auch so
• ja total. ich glaube wir müssen da noch weiter denken und auch vielmehr mit "trends" spielen und dann sehr produktbezogen sein, auch wenn die trends dann nichtmehr super aktuell sind. 
• Sollen wir dazu ein Brainstorming machen morgen früh? Kann gerne eins aufsetzen und vorbereiten
• 4. Punkt: da weiß ich nicht was du meinst
• hab übrigens meine Meeting Notes in Asana gepackt <@U08V6A47PKN> 

**2025-11-19T15:16:23.632419** - Julia:
> perfekt, ich setz eins in figma auf :slightly_smiling_face: um 10?

**2025-11-19T15:16:40.829709** - Julia H. mentioned Julia:
> Thank you!! Lasst uns gern morgen ein Meeting dazu machen! <@U09D64LA420> Sehe Punkt 1&amp;2 genauso. Wobei man überlegen kann ob man 1 Tag den großen TV macht on Location und 1 Tag die Projektoren im Heimkino.

Gorenje ist Sponsor der EHF und das wird bei denen überall auf den Kanälen gespielt. Denke das wäre getan mit ein paar Konzepten die darauf einzahlne z.B. Pizza Party um gemeinsam Handball zu schauen... etc?

**2025-11-19T15:21:04.329829** - Julia:
> Perfekt. meeting ist raus. Board setze ich auf und schicke ich euch davor, dann könnten wir vorm meeting schon erste Ideen ablegen und dann direkt besprechen.

Ahh das meint ihr, ja genau!

**2025-11-19T15:38:30.781079** - Julia:
> Genau. Dann können wir uns auch erstmal die Aussrbeitung der anderen Produkte etwas sparen, solange es dafür noch keine logistische Lösung gibt 

**2025-11-19T17:34:52.429169** - Julia H. mentioned Julia:
> <@U09D64LA420> die Leute von Rückenwind sind wohl unsere Vermieter, denen könne wir schreiben und das mit dem Kühlschrank in der unteren Küche klären 

**2025-11-20T08:47:46.130799** - Julia:
> ach cool! Soll ich sie anschreiben? kann ich gerne machen

**2025-11-20T08:56:39.619189** - Julia:
> GuMoooo! Checkt gerne mal, ob ihr hierauf Zugriff habt:
<https://www.figma.com/board/R4ar6AX2IMiYboLpcYFzDt/Brainstorming-Content-Q4?node-id=0-1&amp;p=f&amp;t=I0Am1AyO6r3ujdEW-0>

Die Idee dabei ist: dass jeder vorab schon mal erste Ideen einträgt, die zum Thema passen könnten (Moods, Screenshots, Konzept Ideen...). Im Meeting selbst stoppen wir auch nochmal die Zeit und jeder hat nochmal 10 minuten Zeit. Danach besprechen wir die einzelnen Ideen und picken uns raus, was uns am besten gefällt + was wir gut kombinieren könnten.
Im letzten Schritt gehts dann um die finale Ausarbeitung &amp; den Umsetzungsplan.
Hoffe das ist verständlich :slightly_smiling_face:

**2025-11-20T09:12:12.119629** - Julia:
> Achso ja, der Login ist hier:
<https://app.asana.com/1/1199360402832734/project/1210671893802702/task/1211822863301659?focus=true>

**2025-11-20T09:40:40.288869** - Julia:
> klappts?

**2025-11-20T09:48:44.596819** - Julia:
> Also ne :smile:

**2025-11-20T09:59:53.139359** - Julia:
> Ich mach mir noch schnell einen Kaffee 

**2025-11-20T10:04:09.597139** - Julia:
> wie süüüüß

**2025-11-20T10:13:40.146929** - Julia:
> 

**2025-11-20T10:14:08.432999** - Julia:
> 

**2025-11-20T11:09:33.848359** - Julia:
> boah ey :smile:

**2025-11-20T11:09:37.300899** - Julia:
> neues Sideboard?

**2025-11-20T11:10:17.753469** - Julia:
> direkt Koop mit Tylko anfragen

**2025-11-20T11:46:35.992769** - Julia:
> omg 

**2025-11-20T12:53:00.914099** - Julia:
> Bin gleich wieder daheim, passt euch 13.15? 

**2025-11-20T13:05:53.754759** - Julia:
> ne alles gut, bin da :slightly_smiling_face:

**2025-11-20T13:07:00.253509** - Julia:
> uh mega!

**2025-11-20T13:07:34.635749** - Julia:
> hahahha ja

**2025-11-20T13:08:04.420829** - Julia:
> okay das ist auch mega

**2025-11-20T13:09:38.949219** - Julia:
> stimmt! vllt kann man das auch umdrehen auf "ich bin so tech-afin"

**2025-11-20T13:13:54.957699** - Julia:
> wegen mir gerne. ich weiß nur nicht, inwiefern wir da Flo rein reden dürfen :smile:
Die Farbkombi ist eh schwierig

**2025-11-20T13:14:34.614839** - Julia:
> ich versteh goarnix, aber geil :smile:
<@U093J779DAQ> wollen wir das aufnehmen? :slightly_smiling_face:

**2025-11-20T13:16:26.653949** - Julia:
> bin drin!

**2025-11-20T13:16:45.715539** - Julia:
> bitte was Julia? :smile:

**2025-11-20T13:19:42.798799** - Julia:
> okay passt

**2025-11-20T15:09:42.639099** - Julia:
> ihr meint dann visuell das gleiche SetUp? ja total

**2025-11-20T15:10:13.001329** - Julia:
> denke da kommen beim Dreh oder dann später in der Bearbeitung dann auch nochmal paar Ideen oder?

**2025-11-20T15:12:30.124739** - Julia:
> Mert soll ich SetUp1 machen und du Setup2 + 3? (Shooting Tag1)

**2025-11-20T15:54:56.670619** - Julia:
> Das ist super! 

**2025-11-20T15:55:17.221079** - Julia:
> jaa finde ich auch sehr gut! 

**2025-11-20T15:55:37.829139** - Julia:
> Ja gerne. Bitte keine WhatsApp Gruppe :sweat_smile:

**2025-11-20T15:58:04.341919** - Julia:
> Da ist 2x du wolltest nur eine Folge schauen drin. Und ich denke es würde Sinn machen, “Freundin schläft ein” eher abends gegen 16Uhr zu machen, wenns schon leicht dämmert 

**2025-11-20T15:59:36.785479** - Julia:
> hmm macht das da Sinn? Mit dekorieren usw. 

**2025-11-20T16:48:43.284889** - Julia:
> hab hier jetzt nach Beispielvideos gesucht und meistens sieht man da schon die Freundin wie sie es einrichtet – evtl. fügen wir hier :red_haired_woman: ein?

**2025-11-20T17:08:02.686099** - Julia:
> okay ich bin bei der Ausarbeitung jetzt nochmal auf das gleiche Thema gestoßen, dass es zB doch das Couple sein muss, statt nur der Freundin. Evtl. müssten wir morgen nochmal alles abgleichen <@U08V6A47PKN>?

**2025-11-20T17:22:56.549039** - Julia:
> Ein Shooting bei unserem Logistiker wäre im Zeitraum *15.12.–19.12.2025* möglich. Ihr könnt uns hierzu gerne euren Wunschtermin nennen

oh, das ist echt spät. aber müss ma ja machen oder?

**2025-11-20T17:48:47.132129** - Julia:
> puh, ja. lasst uns da gerne morgen sprechen was wir machen :face_with_peeking_eye:

**2025-11-20T17:50:59.679169** - Julia:
> Also für unsere Präsi hab ich jetzt folgendes erstellt <@U093J779DAQ>
• SetUp 1 ausgearbeitet (ein paar Beispiel Videos muss ich noch einfügen/ austauschen) + die Content Säulen dazu geschrieben (Premium, bold, innovative) :white_check_mark:
• alle 3 SetUps kurz auf Folien aufgezeigt --> würde ich dann als Trennfolien nutzen für die einzelnen Content Pieces :white_check_mark:
• Shooting Tag 1 aufgezeigt --> Tag 2 + Tag 3 mach ich morgen :white_check_mark:
• Heimkinoraum + Mediamarkt --> fange ich morgen früh einfach an und können wir sonst nochmal aufteilen :x:
• <@U08V6A47PKN> falls du morgen dann wirklich Zeit hast, müssten wir nochmal den Produktionsplan mit den ausgearbeiteten Ideen vergleichen --> kann ich aber sonst auch gerne anpassen :white_check_mark:

**2025-11-20T17:52:56.100819** - Julia:
> eh Reinung 400€? Da schleck ich ihnen den Boden sauber :smile:

**2025-11-20T17:53:13.115949** - Julia:
> Asoo bist du mit deinen Ausarbeitungen schon ganz durch?

**2025-11-20T17:56:44.513939** - Julia:
> Ah jetzt seh ichs. Ne ist doch super! :star-struck: ich hab mich da an deinem orientiert. Würde nur die Zeilen oben mit den Kategorien anpassen und dann passt es!
Dann wäre es super, wenn du Heimkinoraum oder MediaMarkt übernimmst?

**2025-11-20T17:58:41.112569** - Julia:
> wollte da auch nicht in Berlin sein but well :smile:

**2025-11-20T17:58:57.689639** - Julia:
> jaa gerne

**2025-11-20T17:59:56.551189** - Julia:
> dann bis morgen :heart_hands:

**2025-11-20T18:16:59.081379** - Julia:
> du, vllt gehts auch alleine. kriegen wir alles hin

**2025-11-21T08:13:41.496149** - Julia:
> Guten Morgen! Deine oder unsere Zeit? :zany_face:
Flo wollte, dass ich heute ins Office komme. Hoffe das überschneidet sich dann nicht 

**2025-11-21T09:07:08.266659** - Julia:
> Ja schauen wir mal. Dachte eigentlich die haben heute den bitpanda pitch?

**2025-11-21T10:00:03.211729** - Julia:
> Hab die Slides für Shooting Tag 2 &amp; Shooting Tag 3 noch hinzugefügt. Seite 26 + 27

**2025-11-21T10:04:01.857449** - Julia:
> hab ihm mal geantwortet, können ja heute zumindest dann das schicken, was wir haben und mit julia's kostenaufstellung

**2025-11-21T10:30:16.408309** - Julia:
> Juhuu, komme ins Meeting

**2025-11-21T11:32:16.486329** - Julia H. mentioned Julia:
> <@U09D64LA420> KÖnntest du bitte vor der Mail nochmal beim Heimkinoraum anrufen? Das wäre super

**2025-11-21T11:32:49.741259** - Julia:
> yes, bin grad dabei – wieviele Stunden hatten wir grob gesagt? 3?

**2025-11-21T11:36:52.094909** - Julia:
> hab einen Kontakt bekommen – schicke jetzt eine Mail hin, setze euch CC

**2025-11-21T11:48:46.341369** - Julia:
> ja hätte auch gedacht, man kann die da vllt kaufen...?!

**2025-11-21T11:49:06.167839** - Julia:
> online geht schon mal

**2025-11-21T11:50:45.740709** - Julia:
> ja genau

**2025-11-21T11:51:29.752019** - Julia:
> sehr cool!

**2025-11-21T11:52:46.618279** - Julia:
> <@U093J779DAQ> ich spreche jetzt gleich mit flo – evtl. könntst du doch noch die ausarbeitung der restlichen ideen übernehmen? wenn wir es asap rausschicken wollen, schaffe ich nicht so schnell

**2025-11-21T11:54:37.273069** - Julia:
> ja sehr cool. bin da noch nicht weiter, aber da finden wir schon noch paar

**2025-11-21T11:55:34.000549** - Julia:
> *„Tech Village Berlin“ im MediaMarkt am Alex realisiert <@U08V6A47PKN>* 

**2025-11-21T12:04:54.762819** - Julia:
> Also Angebot von Rückenwind soll ich direkt mit ihnen besprechen – das ist zuviel und brauchen wir nicht. Flo meinte im besten Fall zahlt das Gorenje, sollen wir auch asap mit Laureen besprechen + eine Gegenüberstellung erstellung für Tiny House und den Content der dann wirklich entsteht. Weil wenn wir Stand jetzt nur 2 Produkte dort shooten --> macht keinen Sinn

**2025-11-21T12:06:29.655469** - Julia:
> ja genau. sind jetzt kurz beim lunch, danach kümmere ich mich darum

**2025-11-21T12:07:38.654379** - Julia:
> ich berichte dann

**2025-11-21T12:07:52.044459** - Julia:
> :simple_smile:

**2025-11-21T13:05:23.813129** - Julia:
> Bin wieder da. Erzähl euch am Montag gerne alles :slightly_smiling_face:

**2025-11-21T13:08:36.516039** - Julia:
> welchen Score soll ich denn in die Gruppe schreiben? 9/10?

**2025-11-21T13:23:09.217509** - Julia:
> sorryyy, falsch Datei hochgeladen

**2025-11-21T13:24:49.461489** - Julia:
> again <@U08V6A47PKN>

**2025-11-21T13:31:10.763369** - Julia:
> oh ja, das wäre ein traum! danke fürs checken :heart_hands:

**2025-11-21T13:31:44.370929** - Julia:
> Ne ich denke nicht. Ich versuche Jasmin heute noch abzufangen im Büro und eine Info vom Heimkinoraum zu bekommen. Flo meinte ich soll Marvin nochmal fragen

**2025-11-21T13:32:33.106919** - Julia:
> yeees. Happy weekend! :heart_hands:

**2025-11-21T13:34:17.889319** - Julia:
> Happy weekend und danke :heart_hands:

**2025-11-21T13:43:21.718719** - Julia:
> ja genau. <@U093J779DAQ> würdest du einmal bei unseren "alten" bereits erstellen Content Ideen shauen, was wir noch im Tiny House drehen könnten? (Mikrowelle, Staubsauger usw.)
Weil damit können wir grob übershlagen wieviele Videos wir ca. daraus ziehen können. Also wie wir es für Hisense auch gemacht haben und dann schauen, ob die Rechnung irgendwie Sinn macht

**2025-11-21T14:09:49.131369** - Julia:
> danke dir :slightly_smiling_face:

**2025-11-21T14:10:13.757959** - Julia:
> Ja würde ich auch sagen. Ich poste dann auch mal

**2025-11-21T14:12:08.958939** - Julia:
> und natürlich danke fürs übernehmen!

**2025-11-21T14:18:06.957489** - Julia:
> du kannt mich auch gerne markieren, dann kann ich es einfach resharen

**2025-11-21T15:06:45.957929** - Julia:
> *Wichtiges Update von Jasmin (Rückenwind):*
• sie passt das Angebot an --> nur einen Shooting Tag & Dekokosten weg. Beim Angebot ist schon alles mit drin bezüglich Wasseranschluss und und und. Diese "Umsetzungskosten" sind dafür, dass jemand von ihnen dabei ist. Das ist mehr oder weniger unmöglich weg zu streichen. Reinigung bestehen sie auch darauf von sich machen zu lassen.
• Termin: der 15.12. wäre ihnen am liebsten, wenn das bei uns auch geht 
• _"alternativ könnten wir darüber nachdenken, dafür unser ERT-Küchenmodul zu nutzen, das sich flexibel für Shootings ins Studio im Content Club schieben lässt." -->_  das ist folgendes: 
1. sie haben ein *Küchenmodul gebaut mit gorenje* zusammen (war auch sehr überrascht, dass sie uns das nicht gesagt haben?! Conny weiß das) und das könnten wir auf jeden Fall haben. Das beinhaltet 2x Pizzaöfen, Schränke und diese Arbeitsplatte vorne
2. wir haben ein Studio im Büro, hier könnte man dieses Modul reinbauen für 1-2 Tage und quasi die Küche faken
3. ALLERDINGS haben wir jetzt auch ausgemessen, der *supergroße Kühlschrank von Hisense und die 2 kleineren* passen nicht durch die Türen bei uns im Büro/ Studio (weder oben, noch Keller über den Garten)
• Info: Tiny House: wird halt bitterkalt jetzt im Dezember, selbst wenn wir mit diesem Zelt/ Container arbeiten
• Für uns jetzt zu klären: ob TH sich wirklich mit den geplanten Content lohnt, oder ob wir dieses gebaute Modul von ihnen nehmen könnten 
--> kein Wasseranschluss und nur Pizzaofen als großes Produkt quasi

**2025-11-21T15:11:50.685439** - Julia:
> finde man müsste auch so filmen oder abhängen, dass man das gebrandete nicht richtig sieht. Sonst echt unglaubwürdig für SoMe

**2025-11-21T15:37:52.661399** - Julia:
> Ja denke ich auch 

**2025-11-21T15:40:06.027709** - Julia:
> Ja? Wo hast du nochmal die Wohnung geschickt? 
Passt das alles rein. Bin jetzt gebrandmarkt :joy:

**2025-11-21T16:01:12.852529** - Julia:
> :weary:

**2025-11-21T16:53:29.553829** - Julia:
> ach mist. aber dann müssen wir die kampagnen jetzt stoppen oder wie läuft das ab?

**2025-11-21T16:55:13.178329** - Julia:
> okay, macht sinn. da sind die views ja eh schon voll gut!

**2025-11-21T17:12:38.352049** - Julia:
> Niiiice! Meinst du der Platz zwischen Couch und TV Abstand reicht? Das ist das einzige "Problem" was ich sehe.
Marina hatte mir gestern ihre Wohnung auch schon angeboten und da hab ich gedacht es ist zu wenig Platz

**2025-11-21T17:22:36.624079** - Julia:
> könntest du sie noch 3 Sachen fragen bitte:
1. Breite des Sideboards? (weil wir ja sonst ein neues kaufen müssen fürs Shooting)
2. Einmal den Abstand messen zwischen Couch und TV --&gt; vom Screenshot aus. Würde es einmal in Chatgpt jagen, ob das passt :smile:  
3. Couchtisch haben sie keinen? Vllt ein großes Brett oder sowas?

**2025-11-21T17:31:32.493049** - Julia:
> dankee! FYI: ich arbeite gerade für Flo an Estée Lauder – da gibts am Montag ein 1. Gespräch

**2025-11-21T18:34:15.625679** - Mert Koc mentioned Julia:
> <@U09D64LA420> 
Die Distanz zwischen Sideboard und Couch (Ecke Screenshot) sind 1,95m :)

**2025-11-21T19:10:15.523659** - Julia:
> Wie cool! Na klaro, wer weiß was bis dahin ist :joy:

**2025-11-21T19:10:18.260699** - Julia:
> Happy weekend!

**2025-11-24T08:52:25.318449** - Julia:
> Hallooo! :slightly_smiling_face: Nein :joy:

**2025-11-24T09:20:44.151969** - Julia:
> Hisense – der Porsche unter den TVs

**2025-11-24T09:37:43.874679** - Julia:
> • FYI: Bei 2,5 m Diagonale → *3,0 m bis ca. 4,0 m* wirken für die meisten angenehm.
*2 m* Abstand ist bei der Größe definitiv *zu nah* – das fühlt sich eher nach „erste Reihe IMAX“ an und bringt genau das von dir angesprochene Genick-Workout.
*Kurz &amp; knackig:*
 Für ein natürliches, entspanntes Seherlebnis: *Mindestens ~3 m*, gern ein bisschen mehr, wenn der Raum es hergibt.

können wir ja gleich besprechen!

**2025-11-24T09:54:57.684839** - Julia:
> ja macht wahrscheinlich am meisten sinn

**2025-11-24T11:49:58.753719** - Julia:
> Also Marina und David wären beide dabei – ich krieg noch Content und kann dann jeweils eine Slide in der Präsentation erstellen

**2025-11-24T11:57:11.665359** - Julia:
> ui perfekt

**2025-11-24T12:08:51.338009** - Julia:
> ne stop das ist das model

**2025-11-24T12:12:14.529469** - Julia:
> habs wieder gelöscht. Flo hatte eine Rechnung geschickt vom Heimkinoraum – war aber das Model Honorar, nicht der Raum

**2025-11-24T12:20:20.905279** - Julia:
> Heimkinoraum: wir müssen auf die antwortet von dem Ansprechpartner warten – sie dürfen keine Nummer rausgeben

**2025-11-24T12:41:09.539829** - Julia:
> Marie kann uns nicht helfen am 5.12.

**2025-11-24T12:41:29.450699** - Julia:
> denke aber Anna. ich frag mal

**2025-11-24T12:44:01.216699** - Julia:
> Und noch anderes Thema <@U093J779DAQ> wenn wir es schaffen, dass mietraum, Heimkinoraum und unser Wohnungs-Shooting in der gleichen Woche wäre, wäre ja auch mega oder?

**2025-11-24T13:00:57.412419** - Julia:
> Okay letztes update, danach geh ich ins die Break :smile:
Marie hilft uns heute bei der Creator Suche für <https://docs.google.com/presentation/d/1rbYB7aLiZwdcgXMezmgL1kWXM0APEyGw64nXlBrXhpY/edit?slide=id.g3a64d1ec782_0_33#slide=id.g3a64d1ec782_0_33|diese Präsentation>, dann haben wir hier auch schon was

**2025-11-24T14:10:30.972529** - Julia:
> ich auch

**2025-11-24T14:20:42.008969** - Julia:
> 2./3. vllt? Da wäre Marie auch da

**2025-11-24T14:22:46.763689** - Mert Koc mentioned Julia:
> Brauchen sie auch zwei Wochen für die Modulare Küche als Vorlauf <@U09D64LA420> ?
Sollen wir dann Rückenwind erst einmal anfragen bzgl. eines passenden auslieferungs Datums? 

**2025-11-24T14:27:33.140459** - Julia:
> Nene, kann ich gerne machen, sobald Jasmin sich nochmal melden

**2025-11-24T14:32:36.141449** - Julia:
> okay, also ich bin jetzt im Hisense Doc. Kosten machen alle Sinn! glaub vieles wird günstiger, aber das ist dann ja gut

**2025-11-24T14:36:38.961219** - Julia:
> • bei Gorenje sind die 400€ in dem 6k Angebot mit drin
• Protagonisten: <@U093J779DAQ> reicht uns hier eine Person?

**2025-11-24T14:57:18.154569** - Julia:
> ihr seid bei allen Mails von heimkinoraum und Rückenwind in CC.. hoffe da kommt endlich mal was

**2025-11-24T15:21:01.776109** - Julia:
> coool danke! :slightly_smiling_face:
Ne weiß ich leider auch nichtmehr

**2025-11-24T15:21:59.540249** - Julia:
> ich glaube Tiny House macht vllt doch Sinn :smiling_face_with_tear:

**2025-11-24T15:30:01.061409** - Julia:
> Ich wäre dafür. Mein Gefühl war nur, dass Ray etwas „panisch“ war und uuuunbedingt neuen content will im Januar 

**2025-11-24T15:30:14.727589** - Julia:
> Möglichst viel 

**2025-11-24T15:38:18.674399** - Julia:
> hab jetzt Caro's Maße von der wohnung noch bekommen, falls wir einen Plan B brauchen. Aber kein Aufzug in den 4. Stock haha

**2025-11-24T15:39:04.845089** - Julia:
> glaube eigentlich nichts, oder?
Frage wäre noch, wenn wir das Ikea Regal bestellen &amp; liefern lassen --&gt; haben wir eine KK von BCC für die Zahlung?

**2025-11-24T15:39:37.098959** - Julia:
> Drückt mir die Daumen für das Estée Lauder Meeting gleich, dass ich nicht wieder so ins kalte Wasser geschmissen werde wie wir letztens :smile:

**2025-11-24T15:51:09.702079** - Julia:
> :fast_parrot:

**2025-11-24T15:51:20.236449** - Julia:
> ob ich mich fürs Meeting extra geschminkt hab? VLLT

**2025-11-24T16:45:45.714829** - Julia:
> ja gerne

**2025-11-24T16:45:52.382659** - Julia:
> also ungern gern aber wir sprechen :smile:

**2025-11-24T17:26:44.531579** - Julia:
> also MAC könnte echt was werden :star-struck:

**2025-11-25T08:04:24.826009** - Julia:
> Oh nein, hör auf :weary: ich hoffe es wird besser! 

**2025-11-25T10:03:48.679309** - Julia:
> Jaa gute Besserung :bouquet::sleepy:

**2025-11-25T10:11:13.433369** - Julia:
> Kurz zur Abstimmung, was wir gleich im Meeting alles besprechen müssen:

GORENJE
• Kosten Tiny House --> Angebot weiterleiten von Rückenwind
• Modulare Küche: zeigen + Idee mit Mietstudio West (<@U093J779DAQ> könntest du hier die Präsi/ Folie  kurz updaten mit allen Infos zu Preis, Zeitraum, Julia's Skizze mit dem modularen Teil – falls noch nicht geschehen?)
• hierfür Produktfokus (Pizzaofen evtl. noch Staubsauger? für jetzt)
• Timing KW49/ 50 --> Machbarkeit der Produktlieferungen? 
• Tiny House --> Kühlschrank?
HISENSE
• Feedback zur Präsentation (Content) --> passt alles? 3 Shooting Optionen (Wohnung, HKR, Store)
• zusätzlich neu: Wohnungen zeigen, Models zeigen
• Timing: KW 49/50 --> Machbarkeit der Produktlieferungen? (RBG TV, Laser TV's)
• Sideboard für TV --> Empfehlung?
• HKR: fehlende Rückmeldung, haben sie noch einen Kontakt? Kosten?

**2025-11-25T10:11:17.955399** - Julia:
> Hab ich was vergessen?

**2025-11-25T10:29:49.573579** - Julia:
> Oh nein, das hört sich sooo eklig an. Ach quatsch, alles gut. Wegen uns brauchst du dir nichts denken! Werd du fit, alles andere ist jetzt egal

**2025-11-25T11:53:10.338509** - Julia:
> Notizen vom Call sind in Bold &amp; Kursiv!

GORENJE
• Kosten Tiny House --&gt; Angebot weiterleiten von Rückenwind _--&gt; *Eher Kosten bei Gorenje, aber findet es auch sehr hoch!*_
• Timing KW49/ 50 --&gt; Machbarkeit der Produktlieferungen? -_-&gt; *klärt sie, aber wahrscheinlich schon*_
• _*SDA’s bestellt Laureen zu uns ins Büro -&gt; schickt uns eine Liste*_
• Tiny House --&gt; alter Kühlschrank _--&gt; *wird nicht ausgetauscht; alles so nehmen wie es ist*_
• _*To Do: Juli --&gt; Frage an Logistiker: SDA’s mit drin geblieben oder nicht?*_
• _*Zusammenfassend: findet Mietstudio + Modulare Küche super als Lösung + Tiny House auf nächstes Jahre verschieben klärt sie im Team, aber wäre sie auch dafür*_ 

HISENSE
• Feedback zur Präsentation (Content) _--&gt; *kommt noch von Laureen, hatte noch keine Zeit*_
• Wohnungen zeigen, Models zeigen _*--&gt; alles super, noch To Do: Juli Stimme von David schicken*_
• Timing: KW 49/50 --&gt; Machbarkeit der Produktlieferungen? (RBG TV, Laser TV's) --&gt; _*RGB TV —&gt; anderes Thema; C2 Ultra + PT1 easy, schickt sie auch ins Büro*_
• Sideboard für TV --&gt; Empfehlung? _*--&gt; frägt nach Store Möbeln, evtl. machbar &amp; schön*_
• HKR: fehlende Rückmeldung, haben sie noch einen Kontakt? _*--&gt; keine andere Info*_


**2025-11-25T12:56:00.159449** - Julia:
> Boah leute ich hab sooo viel für Estée Lauder, ich check garnichts was Flo da will. Ich kotze..

**2025-11-25T12:58:24.453019** - Julia:
> Bezüglich der Verifizierung <@U093J779DAQ> für dich wichtig, wie kommt man dahin:
• Burger Menü
• Settings &amp; Privacy
• Account
• Verification
• Request....
• hier dann Upload

**2025-11-25T13:01:35.081109** - Julia:
> <@U093J779DAQ> könntest du Jasmin eine Mail (du bist immer in CC) schreiben und kurz anfragen, welche SDA Produkte im Tiny House geblieben sind?

**2025-11-25T13:32:05.464629** - Julia:
> dankeee

**2025-11-25T14:46:16.277209** - Julia:
> Weil sie uns einfach nur in die Pfanne hauen will 

**2025-11-25T18:03:52.907769** - Julia:
> mega! Das sind ja gute Nachrichten :slightly_smiling_face: (sie ist wohl doch nicht so unfähig wie behauptet wird....????)
Dankeee Mert

**2025-11-25T18:16:00.455269** - Julia:
> happy feierabend und bis morgen! :heart_hands: (hoffentlich wieder vereint)

**2025-11-26T08:46:48.264339** - Julia:
> Welcome back! Okay :crossed_fingers: ja gerne. Bin gerade auf dem Weg ins Büro 

**2025-11-26T09:43:13.557879** - Julia:
> auch cool! meinst du, das wird dann wirklich „gemütlich“? 

**2025-11-26T10:00:33.978969** - Julia:
> jaa ich glaube Küchenfronten und evtl. eine Mittelinsel wären fast das Wichtigste, damit es wohnlich aussieht.
Jaa die sind gut! :slightly_smiling_face:

**2025-11-26T10:00:45.891559** - Julia:
> <@U08V6A47PKN> schaffst du es dann überhaupt zum Termin um 10.30?

**2025-11-26T11:06:41.120649** - Julia H. mentioned Julia:
> geht das bei dir auch <@U09D64LA420>?

**2025-11-26T11:07:26.313339** - Julia:
> yes!

**2025-11-26T12:04:03.956849** - Julia:
> Hier in Page 2 ist das neue leere Brainstorming:
<https://www.figma.com/board/R4ar6AX2IMiYboLpcYFzDt/Brainstorming-Content-Q4?node-id=3351-232&amp;t=gfoXdcJOJV7swW4w-1>

hab noch keine hard facts eingetragen, bin grad mit Flo im Meeting

**2025-11-26T13:57:25.210359** - Julia:
> wie wild wärs? :smile:

**2025-11-26T14:01:37.540529** - Julia:
> ist erst um 14.30

**2025-11-26T14:28:11.192809** - Julia:
> so wild, ich kenn die. wusste nicht, dass die für Gorenje wirbt

**2025-11-26T14:30:54.416889** - Julia:
> komme gleich!

**2025-11-26T14:43:48.921409** - Julia:
> <https://www.figma.com/board/R4ar6AX2IMiYboLpcYFzDt/Brainstorming-Content-Q4?node-id=3351-232&amp;t=gfoXdcJOJV7swW4w-1>

**2025-11-26T15:49:34.660489** - Julia:
> Wäre es möglich, dass ihr sowohl den Hisense- als auch den Gorenje-Dreh in einer (AirBnb) Wohnung dreht? Sicherlich lässt sich eine Wohnung finden, in der sowohl das Wohnzimmer zu Hisense passt und die Küche als Drehort für den Gorenje-Content dient, oder?

**2025-11-26T15:49:36.791229** - Julia:
> hahaha

**2025-11-26T15:50:15.684079** - Julia:
> Ehm... that's what we are planning?! Aber es geht ja um die großen Geräte. Dachte das hätten sie verstanden

**2025-11-26T16:08:31.187379** - Julia:
> ja sie wollen einen dreh (2 tage) in einer wohnung der alles abdeckt. und dann nochmal einen dreh im tiny house. oder?

**2025-11-26T16:16:37.733239** - Julia:
> wie meinst du <@U08V6A47PKN>? Also für den PT1 meinte Laureen benötigt es eigentlich so eine bestimmte Leinwand (deshalb HKR, weil es diese dort gibt)

**2025-11-26T16:16:52.942639** - Julia:
> aber ich versteh nicht ganz, warum Tiny House jetzt doch wieder gedreht werden soll aber gut :smile:

**2025-11-26T16:21:17.725549** - Julia:
> Dann müssten wir jetzt prüfen, ob Amelie's Wohnung auch für die Küche geeignet wäre, oder?
Bzw. oder doch dein Bruder <@U08V6A47PKN>? Glaube das wäre DIE perfekte Location :smiling_face_with_tear:

**2025-11-26T16:24:50.733279** - Julia:
> Naja :moneybag:

**2025-11-26T16:25:20.139939** - Julia:
> Also wenn ich mit 2-3 Drehtagen schon die komplette Miete drin hab, sofort :smile:

**2025-11-26T16:28:37.045109** - Julia:
> hör auf, ich glaube das nicht :joy:

**2025-11-26T16:28:59.439699** - Julia:
> ja, da ist der Fixpreis über 1k und goooo

**2025-11-26T16:31:23.163629** - Julia:
> Manno :disappointed:

Also Marina's Wohnung ist halt bezüglich Küche super: groß, hell, schön --&gt; nur der Ofen ist eine Katastrophe, aber filmen wir ja eh nicht.
Problem hier: kein Aufzug, 4. Stock wegen RGB TV und evtl. müsste man wegen TV + Couch Abstand dann faken

**2025-11-26T16:50:46.601369** - Julia:
> ja gerne. ich weiß noch nicht 100%, ob ich es morgen schaffe wegen den anderen themen :face_exhaling:  sonst sprecht ihr gerne schon mal

**2025-11-26T17:49:51.394529** - Julia:
> uhh nice. Ganz ehrlich, dann fragen wir doch die an, ob wir dort drehen dürfen. Man kann ja dann nochmal den Preis evtl. verhandeln

**2025-11-26T18:07:43.059209** - Julia:
> Flo meinte wir sollen einen neuen Airbnb Account aufsetzen und dann über Business buchen/ Anfragen

**2025-11-26T18:08:03.262429** - Julia:
> Wenn’s nicht klappt (wegen 0 Bewertungen) können wir seinen Account haben 

**2025-11-26T18:09:31.253509** - Julia:
> Also Leute ich bin morgen eher raus bei der Hisense Planung - ich hab noch Lidl mit 2 KI pitch Videos und Format Entwicklung für MAC. 
Wenn ihr da coole Ideen habt, voll gerne her damit :face_holding_back_tears: bin echt um jede Idee dankbar 

**2025-11-26T18:48:54.523279** - Julia:
> Vorschlag: Flo morgen mal kurz 10 min anrufen nach dem Call mit Laureen zum Verifizierungsthema. Mein Gefühl ist, dass er einfach die Gründe verstehen muss  

**2025-11-27T08:20:07.467609** - Julia:
> Hello! :slightly_smiling_face: Ja wäre auch eine gute Idee.
Also ich glaube ein zentraler Ort (dein Bruder) wäre am sinnvollsten aber können auch gerne die 2 Wohnungen nehmen. Dann muss ich Marina nochmal final fragen

**2025-11-27T09:21:54.062879** - Julia:
> ahhh ja, die kenne ich. find ich süß :slightly_smiling_face: Da reicht auch eine Person denke ich

**2025-11-27T09:22:07.871469** - Julia:
> ich frag mich nur, ob man das jemanden (außer uns) wirklich zumuten kann

**2025-11-27T09:48:52.170549** - Julia H. mentioned Julia:
> <@U09D64LA420> hast du schon die Stimme von David für Laureen?

**2025-11-27T09:51:01.486799** - Julia:
> Hab ich ihr geschickt, yes

**2025-11-27T11:01:46.943699** - Julia:
> Bin auch im Meetind dabei. Dankee euch fürs übernehmen :heart:

**2025-11-27T11:04:56.594579** - Julia:
> ich versteh das nicht, kommuniziert wirklich NIEMAND miteinander?

**2025-11-27T11:06:10.799409** - Julia:
> Ja jetzt

**2025-11-27T11:06:15.215409** - Julia:
> in dem neuen von Laureen

**2025-11-27T11:24:55.817529** - Julia:
> wollen wir nach dem meeting kurz sprechen?

**2025-11-27T11:37:45.299479** - Julia:
> alles gut, können auch gerne hier nur kurz schreiben. wollte einmal klären was die to do's sind
Aber dann würde ich Jasmin einmal antworten und:
• Modulare Küche absagen
• Halle für TH nachfragen + Angebot Update
• Marina und David schon mal wegen evtl. späteren Zeitpunkt Bescheid geben
• Marina Küche anfragen? 

**2025-11-27T11:46:24.521649** - Julia:
> ist so okay, oder?

**2025-11-27T11:46:59.845669** - Julia:
> ich finds wirklich krass, dass es dauernd unerwartete updates gibt :smile:

**2025-11-27T11:47:57.248549** - Julia:
> ich bin mal drin, falls jemand joinen will haha

**2025-11-27T11:55:33.009219** - Julia:
> hö wieso bist du im warteraum? :smile: also wir sind drin

**2025-11-27T11:56:28.406749** - Julia:
> <@U08V6A47PKN> du brauchst nicht reinkommen, alles gut

**2025-11-27T14:17:02.304829** - Julia:
> komme wahrscheinlich paar Minuten später sorryyy. Beeile mich 

**2025-11-27T14:32:10.692669** - Julia:
> bin da!

**2025-11-27T14:34:40.136469** - Julia:
> Mert bist du im warteraum? wir sind im call

**2025-11-27T14:47:59.862619** - Julia:
> Aso. Würde für die Zukunft auf jeden Fall Sinn machen, dass wir alle drin sind

**2025-11-27T14:49:06.809659** - Julia:
> alles gut!

**2025-11-27T15:17:35.635959** - Julia:
> <@U093J779DAQ> Ist unser Redaktionsplan zufälligerweise schon mit den neuen Videos (Emoji Austausch am Ende) geupdated? :slightly_smiling_face: Für die Instagram Agentur

**2025-11-27T15:18:52.169999** - Julia:
> hö

**2025-11-27T15:20:08.974889** - Julia:
> okay! fyi <@U08V6A47PKN>

**2025-11-27T15:22:08.131679** - Julia:
> yes! Wenn wir das mit tiny house verbinden, müssten wir fast zu 2. sein

**2025-11-27T15:23:21.164269** - Julia:
> spreche gerade mit jasmin

**2025-11-27T15:28:07.502399** - Julia:
> 

**2025-11-27T15:31:01.484449** - Julia:
> <https://pos-mail.de/hisense-mit-neuem-brand-store-konzept-im-tech-village-berlin/>

**2025-11-27T15:31:33.896249** - Julia:
> muss jetzt mal wieder ins Lidl Loch zurück :face_exhaling::wave:

**2025-11-27T15:34:28.171919** - Julia:
> 

**2025-11-27T15:35:45.448319** - Julia:
> Flo ist da mit drin im Chat :joy:

**2025-11-27T15:36:06.887229** - Julia:
> ich glaube, dass die einfach nie geschaut haben, ob status sich geändert hat in der app. kann das sein?

**2025-11-27T15:51:29.446469** - Julia:
> meine leute aus berlin sind alle zu alt

**2025-11-27T15:52:32.629219** - Julia:
> sie arbeitet leider nur montag, dienstag, mittwoch 1/2 tag aber dann auf jeden fall

**2025-11-27T16:50:53.062179** - Julia:
> Vllt Kaddi? die kann sowas ja mega gut

**2025-11-27T16:55:46.435099** - Julia:
> dankeee. ich werd morgen am 2. lidl video sitzen

**2025-11-27T16:56:00.462229** - Julia:
> Damit ihr wisst, was ich eigentlich so den ganzen Tag mache:

**2025-11-27T16:59:13.882419** - Julia:
> FYI

**2025-11-27T17:14:20.401419** - Julia:
> Ja wild trifft es wirklich gut :smile:
Higgsfield --&gt; <https://app.asana.com/1/1199360402832734/project/1210671893802702/task/1212210237961264?focus=true|Zugang liegt jetzt auch ab>. Kann ich dir sehr gerne erklären, falls du es noch nicht kennst

**2025-11-27T17:14:44.027239** - Julia:
> ich hab noch garnichts gemacht aber ja, würde es auch so machen

**2025-11-27T17:18:53.150599** - Julia:
> mega danke! :slightly_smiling_face:

**2025-11-27T17:32:34.117729** - Julia:
> nur für diese woche oder auch für den ganzen november? Das weiß ich gerade nichtmehr

**2025-11-27T18:25:03.170569** - Julia:
> Könnten in Marinas Küche drehen, garkein Problem 

**2025-11-27T18:25:06.857479** - Julia:
> Fotos kommen noch 

**2025-11-27T18:25:12.879259** - Julia:
> Bis morgen! :heart_hands:

**2025-11-27T18:25:49.847999** - Julia:
> Ah okay! 

**2025-11-28T09:15:35.426139** - Julia:
> Guten Morgen :sunny: okay, aber good to know.. 
ich bin heut 100% auf Lidl und noch irgendwas für bitpanda :melting_face:

**2025-11-28T09:31:10.035649** - Julia:
> <@U093J779DAQ> gib gerne Bescheid, sobald du da bist. Flo stresst irgendwie etwas rum und will, dass Anna ausgelastet wird (Werki) und ich denke bei Hisense kann sie bestimmt unterstützen mit Creatorn?

**2025-11-28T09:35:49.319509** - Julia:
> Ne sie ist Werki (eigentlich von Flo)

**2025-11-28T09:36:44.973869** - Julia:
> jetzt will Flo, dass sie mir bei Lidl hilft – obwohl sie das nicht kann, und nicht bei Hisense. Der treibt mich manchmal echt in den wahnsinn

**2025-11-28T10:05:36.265279** - Julia:
> Alles gut danke :kissing_heart:

**2025-11-28T10:36:21.210919** - Julia:
> Idee: Das Update an Laureen schicken/ oder sagen hey hier die neuen Versionen und sie fragen, ob das passt

**2025-11-28T12:13:08.308129** - Julia:
> war grad im bitpanda call – wenn das fix ist, werden wir als Team bitpanda übernehmen hat Flo gesagt (alle Angaben ohne Gwähr) aber wäre ja mega nice :slightly_smiling_face:

**2025-11-28T12:43:05.863909** - Julia:
> ich meine ja

**2025-11-28T13:21:39.106549** - Julia:
> ahhh das wäre perfekt

**2025-11-28T13:22:12.739899** - Julia:
> wie findet ihr die? versteht man es? habs an die typischen lidl plakate angepasst

**2025-11-28T16:59:03.184009** - Julia:
> wünsche euch ein schönes Wochenende! :heart:

**2025-11-28T17:00:32.157879** - Julia:
> haben wir zufälligerweise schon eine Produktinfo wegen dem RGB TV bekommen? Ich muss Marina und David das Datum bestätigen oder absagen..

**2025-11-28T17:09:04.029089** - Julia:
> Ja das wissen sie der 5.12. Aber hier war ja offen, dass sie die Lieferung noch klären wollen, deshalb frag ich :slightly_smiling_face:

**2025-11-28T17:19:57.717039** - Julia:
> hab geschrieben. lieferadresse wissen wir ja noch nicht --&gt; vllt Julia's Bruder oder Amelie. Oder hab ich was verpasst?

**2025-12-01T09:17:33.419059** - Julia:
> Guten Morgen! :slightly_smiling_face:

**2025-12-01T09:17:53.502349** - Julia:
> komisch, bekomme auch keine Anfrage

**2025-12-01T11:02:18.363539** - Julia H. mentioned Julia:
> Nochmal kurz die Notes/To Dos von vorher:
<@U093J779DAQ>:
• Call Benny Tiny House Halle
• Konzepte in Präsi übertragen
<@U08V6A47PKN>
• Final Check/Bestätigung Wohnung 08./09.12.
• Email Heimkinoraum
• Briefing Marie Creator
• UGC Anfrage Text
<@U09D64LA420>
• Check Verfügbarkeit Marina &amp; David neues Datum
*Wir alle:* Konzepte zusammen finalisieren

**2025-12-01T12:59:35.582049** - Julia:
> ah mir fällt gerade jemand als creator ein mit essen/ kochen. moment

**2025-12-01T12:59:52.100679** - Julia:
> die Maria (glaube ich?) von everdrop damals, die hat einen Instagram Foodie Account

**2025-12-01T13:01:06.711979** - Julia:
> genau! ahh okay, ich schau auch mal

**2025-12-01T14:00:06.075529** - Julia:
> ja :heart_hands:

**2025-12-01T14:00:19.583529** - Julia:
> ach nein! Ja ist so.: 

**2025-12-01T14:12:29.373299** - Julia:
> ja find ich gut. Würde den Part mit “Vergütung rausnehmen”, schicken sie uns ja eh
Man kann noch mit aufnehmen: Gesicht des gorenje Accounts, da dieser komplett neu aufgesetzt wird 

**2025-12-01T14:13:48.375019** - Julia:
> 

**2025-12-01T14:46:11.260479** - Julia:
> lieben wir

**2025-12-01T14:50:41.445679** - Julia:
> ne hör auf

**2025-12-01T14:51:01.743229** - Julia:
> also am ende muss das echt Gorenje entscheiden, wenn die dafür 20k hinlegen wollen OKAY

**2025-12-01T14:51:15.018969** - Julia:
> voll

**2025-12-01T14:51:33.225319** - Julia:
> normal wäre TikTok Stil: stell die modulare Küche mit Pizza Ofen in den Büro Gang und wir faken eine Küche

**2025-12-01T15:15:05.277879** - Julia:
> Marinas Küche FYI

**2025-12-01T15:38:21.685459** - Julia:
> jaa oder?

**2025-12-01T16:28:33.903279** - Julia:
> Jaa gerne! Können wegen mir direkt um 9 Uhr meeten?

**2025-12-01T16:28:36.915299** - Julia:
> Happy Feierabend

**2025-12-01T16:28:53.151069** - Julia:
> ich bin grad noch hier :+1:

**2025-12-01T16:39:03.609189** - Julia:
> Mac :new_moon_with_face:

**2025-12-01T16:40:59.098559** - Julia:
> ja dachte ich auch

**2025-12-01T16:41:14.155319** - Julia:
> ich hab das gefühl die haben KEINE AHNUNG

**2025-12-01T17:19:07.938559** - Julia:
> ja verstehe, lasst uns sonst Laureen fragen, ob wir Montag fix machen könnten oder?

**2025-12-01T17:49:15.355269** - Julia:
> ich hab Marina und David wegen dem 8. bescheid gegeben, sollte auch passen!

**2025-12-01T17:50:34.414769** - Julia:
> wahrscheinlich schon, ja

**2025-12-01T17:50:44.836249** - Julia:
> ich bin noch am Laptop und kanns ihm gerne kurz schreiben

**2025-12-01T17:52:15.096309** - Julia:
> ja krank. lohnt sich ja auch nicht ohne einen "Promi" wie Pascal Hens

**2025-12-01T18:09:16.575569** - Julia:
> ich glaube das war schon von Anfang an so, aber da die untereinander nicht sprechen oder falschinformationen teilen, kam das jetzt auf :smile:

**2025-12-01T18:09:19.872889** - Julia:
> dooone

**2025-12-01T18:10:16.015029** - Julia:
> okay passt, abgesagt hahaha

**2025-12-01T20:47:23.013359** - Julia:
> Schlimme Story.. aber diese Headline :face_with_open_eyes_and_hand_over_mouth:

**2025-12-02T10:07:16.641009** - Julia:
> Oh mannoooo aber wenigstens Dienstag..?

**2025-12-02T10:54:34.394569** - Julia:
> ich bin gerade leider voll in MAC, aber der Rest steht ja oder? :slightly_smiling_face: Können ja sagen specials fügen wir noch ein und schicken wir ihnen heute eh zu

**2025-12-02T10:58:47.139589** - Julia:
> mega!

**2025-12-02T10:59:55.702609** - Julia:
> FYI hab gerade eine Mial bekommen wegen RGB TV

**2025-12-02T11:00:02.416539** - Julia:
> leite ich euch einfach kurz weiter

**2025-12-02T11:28:11.310329** - Julia:
> yes, macht sie

**2025-12-02T11:35:28.557909** - Julia:
> NOTES:

*HISENSE*
RGB TV:
• Laureen klärt die Speditions-Lieferung nochmal mit Conny bezüglich Lieferung um 8Uhr morgens zB
• Restliche Geräte sollten am 4.12. im Büro ankommen (eins davon ist bei der Agentur)
Brand Store Berlin:
• Klärt sie ab, ob nächstes Jahr wenn auch TH Dreh

*GORENJE*
• 40k müssen ausgegeben werden —&gt; aber Rechnung einfach im Dezember?
• Tiny House: wir raten ab —&gt; eher nächstes Jahr
• Laureen gibt es an Ray und Conny —&gt; findet es auch nicht sinnvoll
• Schaut sich Julia &amp; Nena an
• Statt Waffeln eher die skandinavischen Kügelchen
• Schickt uns den Content mit Pascal Hens zu
• finalisieren der Konzepte und an Laureen schicken


**2025-12-02T11:40:42.943399** - Julia H. mentioned Julia:
> <@U09D64LA420> denkst du das kosten thema müssen wir nochmal mit flo besprechen? ich bin mir nicht so ganz sicher, ob ich das kapiert hab wie das ablaufen soll

**2025-12-02T11:48:14.207139** - Julia:
> ja wahrscheinlich schon. also sie meinte halt, ob wir die Rechnung für das Tiny House einfach schon im Dezember stellen können und den Dreh aber dann zB erst nächstes Jahr machen. Weil sie Angst hat, dass wir nicht auf die 40k pro Brand kommen.

Kommen wir ja auch nicht oder?
Wir könnten zu unseren Produktionen noch die Creator die zB abgesagt haben zum Dreh anfragen, ob sie selbst Content erstellen (also so wie UGC Creator normalerweise arbeiten). --&gt; Kosten liegen hier auch bei den 800€ + noch die Geräte die Gorenje bereitstellen muss

**2025-12-02T11:54:18.086449** - Julia:
> ja

**2025-12-02T12:37:28.733839** - Julia:
> Ach scheisse aber okay. Dann frag ich Marina wegen Küche am Dienstag oder?  

**2025-12-02T13:05:19.545919** - Julia:
> wow, auch cool. also ich glaube eine freistehende kücheninsel wäre eh super zum filmen

**2025-12-02T13:05:50.482329** - Julia:
> ich wäre für 1 oder 4 :fast_parrot:

**2025-12-02T13:09:17.720159** - Julia:
> ja das stimmt auf jeden Fall

**2025-12-02T13:09:20.787479** - Julia:
> okay :heart_hands:

**2025-12-02T13:10:19.169589** - Julia:
> :joy:

**2025-12-02T13:10:39.131599** - Julia:
> ne

**2025-12-02T13:41:37.288509** - Julia:
> Ich kann mich ab morgen direkt an die Hisense Skripte setzen, wollte eh noch ein kurzes briefing bezüglich Styling usw. aufsetzen für David &amp; Marina

**2025-12-02T13:42:03.129489** - Julia:
> wir haben jetzt gleich das Meeting mit Lidl, denke der wird sich erst danach melden. So gegen 15.30

**2025-12-02T13:46:26.475059** - Julia:
> Bezüglich Ikea regal: könnten wir das am Wochenende oder sonst jetzt unter der Woche schon zu deinem Bruder liefern lassen/ aufbauen?

**2025-12-02T13:47:34.478909** - Julia:
> ja Lieferung ist wahrscheinlich eher samstags 

**2025-12-02T15:04:13.668129** - Julia:
> oh gott, ich versteh es so. Sorry &amp; Danke, dass ihr das gerade alleine stemmt :heart_hands:

**2025-12-02T15:04:26.707289** - Julia:
> Lidl war MEGA – die waren so happy

**2025-12-02T16:09:20.075709** - Julia:
> Sorry nochmal kurz wegen IKEA:
• dass wir das neue Sideboard brauchen ist fix, richtig?
• normale Lieferung von IKEA ist zu spät, Express kostet: *69,00€ und wäre am Donnerstag möglich* (kann leider hier nichts anderes auswählen),
• ansonsten kann es natürlich jeden Tag im IKEA abgeholt werden (auch samstags)
• Aufbau müsste dann am Samstag oder Sonntag stattfinden
• Betonsteine brauchen wir, oder? Wir haben solche daheim, dont ask :smile: sollten auch gehen denke ich

**2025-12-02T16:12:07.952259** - Julia:
> <@U08V6A47PKN> du musst mir nur einmal final sagen, wann es deinem Bruder recht ist, wann ich das Regal kaufen/ liefern lassen soll

<@U093J779DAQ> ja pleaseee

**2025-12-02T16:30:24.988639** - Julia:
> ja die Info hab ich auch gesucht :sweat_smile: aber passt ja das Ikea Regal ist 2,4m lang. 
Okay super, danke! Ich kann da auch sonst am Samstag kurz mit Ersin zu Ikea (immer schön hahaha) und fahren es dann zur Location und wir treffen uns da Mert?
Frage die ich mir noch stelle: was machen wir nach dem Dreh mit dem Regal? ASAP wieder zu Ikea? Kleinanzeigen? Wie lange dürfte es im Notfall bei deinem Bruder stehen? 

**2025-12-02T16:49:08.240979** - Julia:
> haben wir schon eine Info bekommen von Laureen zum rgb tv? Die Spedition ruft mich gerade zum 5 mal hintereinander an und ich weiß nicht was ich denen sagen soll/ kann 

**2025-12-02T16:52:48.745249** - Julia:
> Ne wollte sie klären. Mert könntest du sie einmal in Teams fragen? Ich bin gerade mit coco draußen und muss die Spedition asap zurück rufen. Hab kein Teams am Handy 

**2025-12-02T16:54:03.997649** - Julia:
> Lieferung am Montag um 8uhr möglich?
Abholung Dienstag morgen 

Plus: wer richtet uns das Teil ein? Jemand muss ja das anschließen und einrichten. Das muss doch jemand von denen machen 

**2025-12-02T17:07:19.745199** - Julia:
> Also ich kenne das eigentlich anders mit kompletten Sendersuchlauf usw. aber idk 

**2025-12-02T17:07:28.975789** - Julia:
> Danke! Bin jetzt auch wieder da 

**2025-12-02T17:15:05.530469** - Julia:
> eh moment, dann bearbeite ich sie oder?

**2025-12-02T17:18:49.895789** - Julia:
> done!

**2025-12-02T17:36:09.232459** - Julia:
> yes

**2025-12-02T17:41:46.938789** - Julia:
> euch auch! :slightly_smiling_face:

**2025-12-02T18:32:55.916079** - Julia:
> ahja!

**2025-12-02T18:33:12.112849** - Julia:
> ich bin morgen um 10 Uhr im MAC Call, melde mich danach :slightly_smiling_face:

**2025-12-03T09:22:40.047949** - Julia:
> Guten Morgen! :slightly_smiling_face:

**2025-12-03T09:22:58.396629** - Julia:
> Dnake dir, hab ihr gerade auch nochmal geschrieben. Diese Spedition ruft mich 20 mal an

**2025-12-03T09:23:00.362859** - Julia:
> krank :smile:

**2025-12-03T09:53:02.388989** - Julia:
> Ja oder? 

**2025-12-03T10:16:43.238089** - Julia:
> ja wirklich

**2025-12-03T10:17:25.389039** - Julia:
> Um 11 ist der MAC Call vorbei, denke dann meldet sich Flo wegen Conny

**2025-12-03T10:37:56.253959** - Julia:
> also MAC würden wir fix übernehmen :smile:

**2025-12-03T10:40:00.817769** - Julia:
> sieht nur so aus, sind ziemlich nett

**2025-12-03T11:37:36.448079** - Julia:
> Ohje okay

**2025-12-03T11:37:39.943499** - Julia:
> yes gerne, bin da

**2025-12-03T12:14:25.339589** - Julia:
> HÄ

**2025-12-03T12:15:34.037599** - Julia:
> :exclamation:

**2025-12-03T12:17:06.200519** - Julia:
> Hat marc gesagt? Er weiß nichts, von dem Container den uns Jasmin (seine Angestellte) verkaufen will?

**2025-12-03T12:19:06.839119** - Julia:
> ich check garnichts mehr :smile:

**2025-12-03T12:19:20.402629** - Julia:
> Und sorry aber wegen der Spedition nochmal:

**2025-12-03T12:21:00.746459** - Julia:
> 

**2025-12-03T13:18:13.883949** - Julia:
> Ja, ich geh gerade nichtmehr ans Telefon weil mich ungelogen alle 5 Minuten jemand anruft

**2025-12-03T13:18:37.094709** - Julia:
> Ich kann sie gerne zurückrufen – oder sollen wir die Info mit Mark noch abwarten?

**2025-12-03T13:21:39.716889** - Julia:
> passt, sag ich ihr

**2025-12-03T14:22:59.997579** - Julia:
> leute die spedition ruft mich immer noch an. was soll ich denn machen?

**2025-12-03T14:23:57.529739** - Julia:
> ich hab keine Ahnung

**2025-12-03T14:24:09.884739** - Julia:
> wegen dem/ den TV's wahrscheinlich

**2025-12-03T14:25:55.624609** - Julia:
> genau. Deswegen haben wir ja Laureen jetzt schon 2 mal gefragt, was ich denn sagen soll. Und sie meint sie klären das oder geben uns eine Antwort. Ich weiß, wenn ich jetzt rangehe, funktioniert diese ganze Kette an Planung wieder nicht, weil irgendwer irgendwas falsch versteht :smile:

**2025-12-03T14:29:06.010359** - Julia:
> habs jetzt nochmal geschrieben, lets see. Sonst geh ich ran und sag sie sollen mich in Ruhe lassen haha

**2025-12-03T14:30:50.420949** - Julia:
> Im Tiny House meinst du?

**2025-12-03T14:31:50.684529** - Julia:
> Okay ja super

**2025-12-03T14:36:01.704969** - Julia:
> Oh ne.. Marie hatte schon alle angeschrieben oder?

**2025-12-03T14:37:48.233299** - Julia:
> Aber muss das sein? Also klar wäre schon von Vorteil wenn jemand ein bisschen Backerfahrung hat aber sonst nehmen wir einfach ein UGC Model?

**2025-12-03T14:38:33.872059** - Julia:
> <@U08V6A47PKN> antwortest du? Hab die Adresse nimma

**2025-12-03T14:41:41.816649** - Julia:
> ich schau nochmal

**2025-12-03T14:44:53.788289** - Julia:
> ich geh jetzt mal kurz eine Runde Gassi

**2025-12-03T14:45:45.826479** - Julia:
> dann kann ich Jasmin jetzt aber absagen, richtig?

**2025-12-03T15:27:35.607719** - Julia:
> jetzt! Ob wir um 16 uhr sprechen können. Hast du da noch Zeit?

**2025-12-03T15:45:00.483129** - Julia:
> Oh no.. wieso?

**2025-12-03T15:52:02.984289** - Julia:
> ne hör auf.. wieso sagt hier eigentlich keiner was? Ahhh
Aber das Gute ist! Jetzt könnten wir das nochmal angehen, oder?

**2025-12-03T16:09:44.392219** - Julia:
> bin so gespannt was Flo sagt

**2025-12-03T16:26:43.568849** - Julia:
> also: ich hab bisher noch keinen anderen Koch Creator für München gefunden FYI :smile:

**2025-12-03T16:42:31.038429** - Julia:
> <https://www.instagram.com/melli.ugc?igsh=MTAzOWtzYWJmaHZjcA==|https://www.instagram.com/melli.ugc?igsh=MTAzOWtzYWJmaHZjcA==>

<https://www.instagram.com/vivian.ob?igsh=MTBwbGF0cmZ3MXZ2eQ==|https://www.instagram.com/vivian.ob?igsh=MTBwbGF0cmZ3MXZ2eQ==>

<https://www.instagram.com/sequinfabrics?igsh=MWtkZ3J2aGh1b2U5YQ==|https://www.instagram.com/sequinfabrics?igsh=MWtkZ3J2aGh1b2U5YQ==>

<https://www.instagram.com/genussverliebt_?igsh=MTFwem5qcTJoZTRuYg==|https://www.instagram.com/genussverliebt_?igsh=MTFwem5qcTJoZTRuYg==>

<https://www.instagram.com/rules.of.mary?igsh=OWJqcmRyb2JieXRk|https://www.instagram.com/rules.of.mary?igsh=OWJqcmRyb2JieXRk>

<https://www.instagram.com/tasty.kli?igsh=b29jeWV2cGF2YWx6|https://www.instagram.com/tasty.kli?igsh=b29jeWV2cGF2YWx6>

<https://www.instagram.com/grigoria.auer?igsh=MWFmdGJxZGJybzlyMA==|https://www.instagram.com/grigoria.auer?igsh=MWFmdGJxZGJybzlyMA==>

**2025-12-03T16:43:53.718119** - Julia:
> hier nochmal ein paar, schaut sie euch gerne an. Haben halt nur teilweise was mit Kochen zutun... sind auch nicht alle MUC based, aber Melli &amp; Vivian kenne ich noch von PV, waren sehr flexibel mit Anreise usw.

**2025-12-03T16:46:26.297979** - Julia:
> wenn wir generell planen mehr mit UGC Creatorn zu arbeiten, gibt es verschiedene Plattformen bei denen man sich registiert und bekommt dann eine Auswahl von Creatorn. Ist eigentlich ziemlich cool, die Kommunikation läuft komplett über das Tool und die Videos werden teilweise nach 1 Woche schon fertig gestellt

**2025-12-03T16:46:36.455849** - Julia:
> Preise waren hier immer so 200-300€ pro Video

**2025-12-03T16:47:16.829109** - Julia:
> ich denk auch

**2025-12-03T16:47:53.361909** - Julia:
> Jaa das wäre ja perfekt morgen im Meeting direkt zu klären

**2025-12-03T16:54:21.907259** - Julia:
> btw: <@U093J779DAQ> wegen den Geräten im Büro. Wann sollen wir die am besten holen und zur Location bringen? Denke am WE ist das Büro zu. Oder am Montag nach dem Shooting..?

<@U08V6A47PKN> ich klärs nochmal mit Ersin ab, aber man könnte es auch für Freitag 14-21 Uhr liefern lassen. Was ist deinem Bruder denn lieber?

**2025-12-03T16:55:50.700069** - Julia:
> Oder Mert machen wir einfach fix: Abholung Samstag + Aufbau?

**2025-12-03T17:02:25.574649** - Julia:
> gerne :sweat_smile:
Ich sag dir morgen gleich Bescheid.
Ansonsten: ich kann keinen Sprinter fahren FYI :joy:
Plus: Unser Werkzeug ist gerade in Berlin

**2025-12-03T17:20:37.167599** - Julia:
> Okay verstehe. Dann Lieferung doch für Freitag zu deinem Bruder? und Aufbau am Sonntag?

**2025-12-03T17:20:52.123139** - Julia:
> <@U093J779DAQ> Freitag Büro oder wie mach mas?

**2025-12-03T17:33:29.715249** - Julia:
> Und wie wars?

**2025-12-03T17:34:14.824809** - Julia:
> Aaaaach Überraschung

**2025-12-03T17:35:19.216509** - Julia:
> okay. komisch, dass es von allen seiten kommt. War Flo auch dabei?

**2025-12-03T17:38:08.601459** - Julia:
> BTW in einer Präsentation eben gefunden:

**2025-12-04T09:13:40.666749** - Julia:
> mega, vielen dank!

**2025-12-04T09:15:37.403189** - Julia:
> Ahh ich bin noch garnicht ready, aber dann ohne Kamera haha

**2025-12-04T09:17:29.384099** - Julia:
> witzig, bei mir genau das gegenteil, ich denk mir so: DIE WOCHE IST SCHON RUM?

**2025-12-04T09:29:04.511629** - Julia:
> Nee da hab ich leider ein Meeting mit Anna haha

**2025-12-04T09:29:18.464109** - Julia:
> Also können gerne jetzt sprechen, ist ja kein Problem :slightly_smiling_face:

**2025-12-04T09:29:58.536679** - Julia:
> sorrry :smile: bin im meet

**2025-12-04T10:55:09.619479** - Julia:
> jaa sicher

**2025-12-04T10:55:34.136649** - Julia:
> hab kurz mit meiner Mum gesprochen :joy::sob: wir haben den Retro TV nichtmehr

**2025-12-04T10:59:59.665569** - Julia:
> ich schau mal kleinanzeigen

**2025-12-04T11:01:43.850859** - Julia:
> ja ich auch

**2025-12-04T11:19:07.760909** - Julia:
> PUH

**2025-12-04T11:35:39.942059** - Julia:
> wie findet ihr den?
<https://www.kleinanzeigen.de/s-anzeige/retro-grundig-s-w-portable-tv-voll-funktionsfaehig-top-raritaet/2889435693-175-5591>

**2025-12-04T11:40:10.514439** - Julia:
> ja war eben auch meine frage

**2025-12-04T11:43:39.558979** - Julia:
> ja solche gehen auch. dachte so richtig retro

**2025-12-04T11:43:43.001749** - Julia:
> ich schreib die mal an

**2025-12-04T11:43:45.436439** - Julia:
> dankee!

**2025-12-04T11:44:26.305499** - Julia:
> <@U093J779DAQ> sollen wir die Ikea Sachen einfach online schon per Click &amp; Collect auswählen? Dann könnten wir direkt mit Flo's Kreditkarte zahlen

**2025-12-04T11:46:26.430829** - Julia:
> ja gerne! genau, man bekommt dann ein zeitfenster – das müsstest du einmal checken. aber sollte morgen vormittag trotzdem klappen

**2025-12-04T11:49:38.880629** - Julia:
> ich weiß es auch nicht. Also ich bin bisschen mehr für Julia wegen der Küchen Geschichte. Aber man könnte dann ja Nena als UGC Creator nutzen für die nächsten Videos – Geräte könntest du ja direkt mitnehmen Mert :slightly_smiling_face: dann haben beide was davon

**2025-12-04T11:53:08.962479** - Julia:
> Also wenn der das VO am Ende so schlimm findet, nehmen wir nochmal eins auf und legen es drüber

**2025-12-04T11:58:08.540919** - Julia:
> ja cool! ich hab in der Hisense Präsi eine Folie mit Styling gemacht. Kannst du gerne kopieren. ist ja mehr oder weniger das Gleiche

**2025-12-04T11:59:01.234319** - Julia:
> ich hab noch eine Spalte mit Voiceover hinzugefügt und beschreibe die skripte so - soweit okay?

**2025-12-04T12:00:21.288879** - Julia:
> Brunnthal würde ich sagen

**2025-12-04T12:00:35.992339** - Julia:
> ja? also können wir auch, wenn du da welche weißt. sonst schreib ich die mal an

**2025-12-04T12:17:26.457679** - Julia:
> wir haben hier 6 Videos eingetragen, im Produktionsplan nur eins. Ich denke 1 ist richtig, oder?

**2025-12-04T12:25:26.294059** - Julia:
> voll gerne :heart_hands:

**2025-12-04T12:25:32.425699** - Julia:
> ich sag Jasmin ab oder?

**2025-12-04T12:28:25.928339** - Julia:
> okay, passt

**2025-12-04T12:28:36.443009** - Julia:
> von rückenwind!

**2025-12-04T12:31:15.375719** - Julia:
> okay, dankee :slightly_smiling_face:

**2025-12-04T12:44:00.470159** - Julia:
> ja bitte, mach das! Sag bescheid, wenn ich was übernehmen soll :bouquet:

**2025-12-04T13:07:35.453589** - Julia:
> Ach nein... Ja wenn du reden willst, sag bitte bescheid. :heart_hands:
Genau, vollkommen easy. Arbeit ist bei sowas eh nebensächlich

**2025-12-04T13:15:34.954649** - Julia:
> ah mega! alles nochmal durch gehen ist vllt bissl zu viel, oder? haha

**2025-12-04T13:16:38.735199** - Julia:
> Hab die Skripte für Hisense fertig – bei "Movie Must Watch" hab ich die ganzen Texte für die einzelnen Filme jetzt nicht geschrieben, ich denke das können wir gut vor Ort mit Marina besprechen, oder?

**2025-12-04T13:19:52.120229** - Julia:
> doofe frage: wie kann ich das Excel Blatt "Hisense Wohnung Timing" exportieren, dass ich es Marina und David schicken kann, ohne dass es alles zerschießt, damit sie sich die Texte schon mal durchlesen können?

**2025-12-04T13:21:55.627289** - Julia:
> oder schicken wir die gesamte Excel raus?

**2025-12-04T13:37:13.942699** - Julia:
> <@U08V6A47PKN> je nachdem wie lange alles dauert, sollen wir das regal morgen gleich aufbauen oder das trotzdem am sonntag machen?

**2025-12-04T13:45:49.381129** - Julia:
> ja klar. ich kanns garnicht einschätzen gerade. vllt so gegen 12 bei ihm?

**2025-12-04T13:46:09.430829** - Julia:
> ahh wie hast du das gemacht?

**2025-12-04T13:46:14.061369** - Julia:
> dankeee!

**2025-12-04T14:00:39.921759** - Julia:
> Auf jeden Fall, mach Feierabend. 
Mert, ich mach das, alles gut! :) 

Lass uns morgen um 9.30 im Büro treffen? 

**2025-12-04T14:00:59.058849** - Julia:
> :face_holding_back_tears:

**2025-12-04T14:01:49.285189** - Julia:
> Soll ich auch a David und Marina weiterleiten oder? 

**2025-12-04T14:02:59.877889** - Julia:
> Na klar. Noch eine Frage: die Technik ist alles im Büro oder? Müssen wir nur einpacken?
Ja genau, einmal kurz Bescheid geben. 
Mach dir einen ruhigen Tag :heart_hands:

**2025-12-04T16:29:44.808439** - Julia:
> FYI Habe Marie schon mal geschrieben wegen Dienstag, falls sie vorher mal online kommt

**2025-12-04T17:01:48.366059** - Julia:
> leute wie schlimm!!! mit der Halleeeee und das für 30k? OMG

**2025-12-04T17:37:14.826669** - Julia:
> Leute SOS:
Laureens Nachricht bezüglich RGB TV --&gt; Julia könntest du das sonst mit deinem Bruder klären?
Ich werd dann D&amp;M fragen --&gt; aber denke eh, dass Flo sie nicht will.
Ich kotze wirklich

**2025-12-05T09:07:36.317949** - Julia:
> Hello! Yes machen wir :blush: Treffrn uns gleich im Büro. Hisense Paket kam an laut Anna, müsste der C2 sein. 
Jaa, wahrscheinlich dann eher direkt oder? 

**2025-12-05T09:15:14.960489** - Julia:
> ja ich versteh es auch nicht. Aber einfach typisch am Ende dann einmischen und Chaos reinbringen 

**2025-12-05T09:17:10.669619** - Julia:
> Idk, hat sich ja scheinbar nix aus den Präsentationen angeguckt. Wahrscheinlich will er jetzt doch creator die Reichweite haben – dann findet das shooting aber erst nächstes Jahr statt :sweat_smile:

**2025-12-05T09:57:49.138239** - Julia:
> <@U08V6A47PKN> wir wären jetzt da und ready. Hast du Zeit? :slightly_smiling_face:

**2025-12-05T10:03:26.230819** - Julia:
> ja perfekt. überlegen wir gerade, weil die hisense pakete super groß sind. evtl würden wir die erste Fuhre jetzt gleich mit den Produkten machen, danach zu ikea und dann wieder zu ihm. meinst du das passt?

**2025-12-05T10:07:20.457399** - Julia:
> sind im meet

**2025-12-05T10:12:37.083989** - Julia:
> Also wir müssen jetzt eigentlich los, sonst sind wir überall zu spät. Können auch später ausm Auto telefonieren?

**2025-12-05T10:13:52.708909** - Julia:
> alles gut

**2025-12-05T10:15:13.846279** - Julia:
> ja perfekt. wir melden uns :slightly_smiling_face:

**2025-12-05T10:16:01.826809** - Julia:
> wir laden jetzt gleich die technik + die Produkte ein (sind riiiesig) und schauen, je nach Platz ob wir erst einmal ausladen bei deinem Bruder oder direkt Ikea

**2025-12-05T10:57:42.073819** - Julia:
> also fahren jetzt mit der ersten Fuhre zu deinem Bruder, hab ihn erreicht :) 

**2025-12-05T10:58:48.345439** - Julia:
> Alles gut, mach ich später! Komme gerade nicht ran

Meinst das können wir machen bei deinem Bruder? :)

**2025-12-05T11:26:44.596989** - Julia:
> Top down Stativ ist bestellt :ballot_box_with_check:

**2025-12-05T15:30:14.873649** - Julia:
> Hat jemand von euch Julias Nummer gerade parat? Ich hab von Handy keinen Zugriff auf die mails und wollte ihr Bescheid geben, dass es etwas nach 16 Uhr wird

**2025-12-05T16:11:20.791489** - Julia:
> same, hab ihr eben geschrieben. aber danke :slightly_smiling_face:

**2025-12-07T12:10:25.590109** - Julia:
> Dankeeee dir, perfekt! :slightly_smiling_face: Ja gern

**2025-12-08T08:20:55.962689** - Julia:
> Guten Morgen! :slightly_smiling_face: Bin gerade an den Skripten für morgen dran, werde da nicht ganz fertig bis zum Meeting mit Julia. Müssten das danach noch kurz fertig stellen um es ihr zu schicken

**2025-12-08T08:22:39.231849** - Julia:
> Ich schreibs jetzt so, damit wir dann wissen welche Shots wir benötigen. Aber mal kurz zum Verstädnis: es macht ja eigentlich Sinn alle Videos von Julia einmal im ganzen aufzunehmen, dass sie in die Kamera spricht, oder? Weil wir danach die Möglichkeit haben die Shots von den Zutaten, vonm Juicer usw usw reinzuschneiden, aber wir brauchen ja ihr gesamtes VO.

**2025-12-08T08:24:09.994499** - Julia:
> Und <@U08V6A47PKN> können wir einmal durchgehen, was wir heute am besten schon vorbereiten können an Food Themen? Bin hier etwas überfordert haha

**2025-12-08T08:55:11.325009** - Julia:
> okay :slightly_smiling_face: Mert und ich müssen dann bald los, aber zusammen gehts vllt schneller!

**2025-12-08T10:15:32.977349** - Julia:
> Wäre fertig

**2025-12-08T10:17:43.256609** - Julia:
> <https://www.kleinanzeigen.de/s-anzeige/grundig-roehren-fernseher-funktioniert-/3254562749-175-6440>
<@U093J779DAQ> ich schreib den kurz an. Evtl. könnten wir den sonst abholen

**2025-12-08T10:43:16.686509** - Julia:
> okay moment

**2025-12-08T10:46:07.039859** - Julia:
> find ich cool! Ich weiß nur nicht, ob wir das Modell so nennen sollen?

**2025-12-08T10:46:35.757159** - Julia:
> <@U08V6A47PKN> du hast die Skripte jetzt ohne Rot/ Kamera Einstellungen geschrieben, oder?

**2025-12-08T10:49:49.189639** - Julia:
> okay, alles gut! ich fügs mal hinzu

**2025-12-08T10:52:36.981579** - Julia:
> Lass uns das Laureen am besten fragen

**2025-12-08T10:57:25.154719** - Julia:
> Skript 23 &amp; 24: sind die gleichen. Das ist ausversehen oder?

**2025-12-08T11:04:53.466539** - Julia:
> ja genau, das hatten wir auch gerade hahaha

**2025-12-08T11:04:58.276199** - Julia:
> Sollen wir Laureen fragen lieber oder?

**2025-12-08T11:05:02.410999** - Julia:
> dankee!

**2025-12-08T11:08:03.951099** - Julia:
> <@U08V6A47PKN> hat Chris eine Mikrowelle? weißt du das? sonst müssten wir Konzept 23 auch nochmal umdenken

**2025-12-08T11:11:34.466249** - Julia:
> jaa perfekt

**2025-12-08T11:11:39.188899** - Julia:
> dachte nur was wir dann visuell zeigen

**2025-12-08T11:12:18.883679** - Julia:
> ich bin gleich durch mit den Kameraeinstellungen und dann müssen Mert und ich schon los. Schickst du es dann Julia oder? Das wäre mega :heart_hands:

**2025-12-08T11:20:56.249819** - Julia:
> ich komme genau um 12.30 an :smile:

**2025-12-08T11:21:10.840929** - Julia:
> <@U08V6A47PKN> Skripte sind alle readyyyyy

**2025-12-08T11:21:30.181299** - Julia:
> dankeee

**2025-12-08T11:54:55.285029** - Julia:
> Angst :face_with_spiral_eyes::face_with_spiral_eyes::face_with_spiral_eyes:

**2025-12-08T12:35:01.477389** - Julia:
> Sieb jetzt da 

**2025-12-08T13:26:50.690559** - Julia:
> Food und Fernseher sind da!

**2025-12-08T13:56:46.038459** - Julia:
> ne, sind nichtmehr da

**2025-12-08T13:57:01.959919** - Julia:
> Mert schickt gleich ein Bild in die Gruppe

**2025-12-08T13:58:36.812229** - Julia:
> Danke dir!

**2025-12-08T13:59:09.407119** - Julia:
> Wir haben in der Prop Liste mal makiert was fehlt und was "zusätzlich" geliefert wurde. Hättest du kurz zeit einmal zu checken, ob die fehlenden Sachen tragisch sind? wir sind noch am auspacken

**2025-12-08T14:05:37.328859** - Julia:
> Also wenn das geht natürlich, sonst wären wir später hin. Aber holen auch noch den Retro TV und so

**2025-12-08T14:05:42.528749** - Julia:
> Also wird schon wieder alles stressig :smile:

**2025-12-08T14:49:10.733469** - Julia:
> glaube gerade garnichts

**2025-12-08T14:49:20.062119** - Julia:
> wir schauen uns die produkte an und checken garnichts hahaha

**2025-12-08T14:49:21.600659** - Julia:
> aber wird

**2025-12-08T15:30:03.710389** - Julia:
> okay machen wir

**2025-12-08T15:41:58.009619** - Julia:
> ich checks kurz ab

**2025-12-08T15:53:28.359049** - Julia:
> <@U08V6A47PKN> sorry aber kannst du uns die Skripte alle einmal als PDF exportieren :smile: ich kriegs nicht hin, bei mir hat es Schriftgröße 2

**2025-12-08T15:53:35.692829** - Julia:
> dann drucke ich es gleich aus

**2025-12-08T15:54:52.387909** - Julia:
> Hisense auch voll gerne direkt

**2025-12-08T16:08:30.342799** - Julia:
> mega!

**2025-12-08T16:24:37.618379** - Julia:
> Holen jetzt das Kabel 

**2025-12-08T16:24:42.045889** - Julia:
> Nee danke :heart_eyes:

**2025-12-08T16:39:11.765339** - Julia:
> juhu :heart_hands:

**2025-12-08T16:39:38.194089** - Julia:
> Dann können wir ja doch die hausparty machen höhö

**2025-12-08T16:56:49.579959** - Julia:
> Haben das Kabel 

**2025-12-08T16:57:26.070839** - Julia:
> Holen jetzt heute Abend oder morgen nach dem Dreh noch den tv und dann haben wir finally alle 

**2025-12-08T16:57:52.037239** - Julia:
> Kamera/ Handy Tests haben wir gemacht, sieht gut aus 

**2025-12-08T17:09:19.875689** - Julia:
> Was mir gerade noch einfällt: Julia vllt kannst du morgen Flo einmal Bescheid geben, dass wir am Donnerstag die Produkte und halt die benutzen Ikea Artikel ins Büro bringen müssten und dort abstellen? 

**2025-12-08T17:09:38.379599** - Julia:
> Evtl.  Muss man ihn etwas sensibilisieren dafü :joy:

**2025-12-09T07:42:34.108239** - Julia:
> Dankeee :heart_hands:

**2025-12-09T15:41:39.441329** - Julia:
> • Pancakes haben wir nicht --&gt; neues Rezept abfilmen?
• Dips --&gt; Fußball Watch Party --&gt; morgen früh? 
• Banana Bread --&gt; morgen?

**2025-12-09T15:56:11.090879** - Julia:
> Moment ich denk mal kurz :smile:

**2025-12-09T15:56:36.437229** - Julia:
> du meinst POV Gaming Night heute noch?

**2025-12-09T15:57:04.223749** - Julia:
> Glaube das wird nichts, weil wir den TV ja noch anschließen müssen + Playsi (hab ich heute nicht dabei) und wir ja erst gestern Abend das Kabel bekommen haben

**2025-12-09T16:07:17.060929** - Julia:
> aso ja verstehe

**2025-12-09T16:11:59.280009** - Julia:
> Also wir hätten jetzt überlegt, dass wir am Freitag im Büro in der Küche unten die 2 Food Processor Shakes machen

**2025-12-09T16:12:07.951359** - Julia:
> Morgen früh Dips mit Marina

**2025-12-09T16:13:02.030799** - Julia:
> okay

**2025-12-09T16:13:40.127139** - Julia:
> yes, aber das machen wir dann morgen früh

**2025-12-09T16:13:56.184659** - Julia:
> Mert und ich meinen Basti brauchen wir nicht

**2025-12-09T16:14:00.262369** - Julia:
> wir filmen parallel

**2025-12-09T16:14:03.712429** - Julia:
> morgen geht safe schnell

**2025-12-09T16:14:19.462259** - Julia:
> und was wir nicht schaffen, machen wir Freitag/ Donnerstag im Büro unten :slightly_smiling_face: Sorry Flo

**2025-12-09T16:14:49.490469** - Julia:
> Wir hoffen es. Dann schauen wir auch nochmal wegen den Pancakes

**2025-12-09T16:14:57.298919** - Julia:
> Wo hast du das Rezept nochmal geschickt?

**2025-12-09T16:15:03.065379** - Julia:
> ohja gerne!

**2025-12-09T16:15:15.412969** - Julia:
> Also ich denke Freitag ist realistisch, weil wir Donnerstag alles abbauen etc.

**2025-12-09T16:15:32.293009** - Julia:
> ich markiere in den Skripten was wir haben, was fehlt und was wir morgen drehen

**2025-12-09T16:16:57.847529** - Julia:
> jaa, damit es hell ist :joy:

**2025-12-09T16:17:22.974269** - Julia:
> danke!

**2025-12-09T16:18:27.077869** - Julia:
> danke! ich geh wieder zum Drehen

**2025-12-09T16:18:28.351739** - Julia:
> :slightly_smiling_face:

**2025-12-10T07:34:11.957509** - Julia:
> Ich hab das nochmal neu gemacht basierend auf dem Datenblatt und von gpt prüfen lassen. Sollte passen, aber könne es gerne nochmal rüber schicken :)

**2025-12-11T08:37:58.737159** - Julia:
> Guten morgen! :) wir fahren gleich zur Location und dann wird der TV direkt abgeholt. Danach packen wir zusammen usw. Wir müssten den JF mit Hisense verschieben, da sind wir sicherlich noch unterwegs

**2025-12-11T09:05:23.573899** - Julia:
> Flo hat nixmehr gesagt wegen Büro und Lagerung oder? 

**2025-12-11T09:08:05.478859** - Julia:
> Gerne. Ich hab von 14.30-15 Uhr einen Termin aber sonst bin ich flexibel :) 

**2025-12-11T09:44:01.198029** - Julia:
> Jooooa. Können wir später drüber reden 

**2025-12-11T13:10:02.634209** - Julia:
> Muss mit coco raus aber kann mich übers Handy dazu schalten! 

**2025-12-11T13:10:34.321459** - Julia:
> Ich geh mal ins Meeting :) 

**2025-12-11T13:11:48.444279** - Julia:
> Bin im link von oben 

**2025-12-11T13:21:54.570929** - Julia:
> Mir voll egal 

**2025-12-11T13:22:04.442689** - Julia:
> Können wirauch 

**2025-12-11T13:26:10.736519** - Julia:
> Also wir können auch jetzt 

**2025-12-11T13:26:18.584729** - Julia:
> Dann hab ich keinen Stress wegen coco haha 

**2025-12-11T13:26:26.730019** - Julia:
> Und bleib einfach draußen 

**2025-12-11T13:26:36.955099** - Julia:
> Aso okay 

**2025-12-11T13:26:41.518029** - Julia:
> Hat sich überschnitten 

**2025-12-11T13:46:59.433879** - Julia:
> bin daaaa

**2025-12-11T13:47:32.414159** - Julia:
> und im meet :slightly_smiling_face:

**2025-12-12T09:26:08.697719** - Julia:
> Ahh ich hab die Mail nicht

**2025-12-12T09:26:24.828269** - Julia:
> Was ist passiert? :fearful:

**2025-12-12T09:26:36.209829** - Julia:
> Wir müssen für die Angebote zahlen oder sowas, wetten

**2025-12-12T09:39:19.566559** - Julia:
> OMG. was ist denn los? Also maybe es ist PMS Talking aber die Leute spinnen doch alle? Wir haben doch einfach mal gefragt? Also woher sollten wir denn wissen, dass es kostet, wenn wir in unserem eigenen Büro zu drehen!? Immer gleich als Verbrecher hingestellt zu werden? check ich nicht

**2025-12-12T09:45:52.132099** - Julia:
> Und mit "drehen" meine ich: man macht sich einen Shake, den man in der Küche evtl. eh zubereiten würde und filmt das ganze mit einem iPhone – da brauch ich nicht die ganze Küche sperren :smile:

**2025-12-12T09:47:10.458249** - Julia:
> wortwörtlich

**2025-12-12T10:07:20.857859** - Julia:
> krank echt

**2025-12-12T10:52:29.655599** - Julia:
> Das bekommen wir übrigens nur für das Regal zurück bei IKEA

**2025-12-12T11:11:33.964979** - Julia:
> ahh leitet es mir bitte weiter, das Kino will ich miterleben

**2025-12-12T11:11:43.087449** - Julia:
> schauen wir mal haha

**2025-12-12T12:31:23.186839** - Julia:
> Ach mist

**2025-12-12T13:00:52.383579** - Julia:
> Also leute wenn es euch nichts ausmacht, würde ich mich eher für heute ausloggen. Ich bin echt noch sooo fertig :face_with_spiral_eyes:

**2025-12-12T13:18:06.623739** - Julia:
> okay :heart_hands: wir können gerne am Montag dann direkt mit der Sichtung starten und alles aufteilen!

**2025-12-12T13:30:02.736069** - Julia:
> wuhuuuuu :women-with-bunny-ears-partying:

**2025-12-12T13:30:21.475689** - Julia:
> So eine geile Sprache 

**2025-12-12T14:46:04.257339** - Julia:
> Happy Weekend und bis Montag :heart_hands:

**2025-12-15T09:27:39.661589** - Julia:
> Guten Morgen! Meins war auch schön :slightly_smiling_face: Power Days kicken leider aber sonst wars entspannt!
Danke Julia, wow!

**2025-12-15T10:17:04.314109** - Julia:
> 

**2025-12-15T11:02:50.219029** - Julia:
> warteraum oder?

**2025-12-15T11:18:21.573809** - Julia:
> wann wäre Dänemark nochmal grob?

**2025-12-15T12:25:17.529459** - Julia:
> perfekt :slightly_smiling_face:

**2025-12-15T12:25:33.820589** - Julia:
> find ich cool!

**2025-12-15T12:38:01.182989** - Julia:
> ich würde jetzt mal dann Pause machen solange ich noch nicht starten kann. Bis gleich!

**2025-12-15T13:19:28.069769** - Julia:
> Was mir einfällt: habt ihr schon eine Info, ob es Betriebsurlaub über Weihnachten gibt? 

**2025-12-15T13:26:13.210299** - Julia:
> Ich frag ihn gleich mal 

**2025-12-15T13:54:38.898689** - Julia:
> <@U093J779DAQ> ich fang jetzt einfach mal von oben an. _cut wenn ich ein Video snippet erstellt hab. Und Rest in trash. Passt das? 

**2025-12-15T14:08:07.756459** - Julia:
> *Florian Listl*  [2:06 PM]
Ja, verkünden wir im All Hands, wir machen von 24.-6. Jan zu. Dieses Jahr braucht man durch die ganzen Feiertage nur 4 oder 5 Urlaubstage für 14 freie Tage, da kann jeder mal runterkommen

**2025-12-15T15:06:29.227589** - Julia:
> kurze Info: Quicktime ersetzt die Videos nicht, also wären beide immer doppelt drin. Hab jetzt die raw Videos in den "trash" Ordner, sonst ist es super unübersichtlich hatte ich das Gefühl. Gerne einen anderen Vorschlag

**2025-12-15T15:22:40.915339** - Julia:
> uh nice! Schaffen wir das? das sind sooo viele videos haha
sonst montag/ dienstag noch?

**2025-12-15T15:31:55.186499** - Julia:
> okay :smile:

**2025-12-15T15:39:42.138289** - Julia:
> sehr cool, ja gerne

**2025-12-15T15:53:30.603539** - Julia:
> perfekt, ich bin mit 3 ordnern jetzt auch durch :slightly_smiling_face:

**2025-12-15T16:29:48.538199** - Julia:
> Okay. Versteh nicht ganz was er damit meint aber ja, dann müssen wir uns noch andere formate überlegen :saluting_face:

**2025-12-15T16:30:23.005659** - Julia:
> ja gerne

**2025-12-15T16:54:07.172989** - Julia:
> okeeee. ja wir teilen das auf Mert! :slightly_smiling_face: kriegen wir hin

**2025-12-15T16:55:32.527809** - Julia:
> ich habs jetzt eh schon so geordnet, damit man die einzelnen Videos "einfach" aneinander cutten kann. denke diese vorarbeit hilft uns dann extrem!

**2025-12-15T16:56:08.661069** - Julia:
> Mert meinst du, du könntest den Upload heute den ganzen Abend laufen lassen? dann könnten wir morgen auch mit den XMas Videos sichten starten

**2025-12-15T17:07:59.608199** - Julia:
> ja perfekt

**2025-12-15T17:57:00.199339** - Julia:
> okay ich hab schon viereckige Augen :smile:
Also ready sind:
• Couple Betrayal
• Freund betrügt dich
• Gaming SetUp for Boyfi
• Interactive WarmUp
• Movie night: Expec. vs. Reality
• Nur eine Folge schauen
• Streit ums Programm
• Wohin der Wind mich trägt x2
• RBG TV Zocken x3
• Gaming Date Night: Mario, Barbie, Fortnite
Tbd:
• Gaming Date Night x3 (oder 4?)
• Must Watch
• Nerd Talk
Mehr hat noch nicht geladen

**2025-12-15T18:28:40.509439** - Julia:
> Happy Feierabend und bis morgen! :women-with-bunny-ears-partying:

**2025-12-16T08:35:57.524129** - Julia:
> Hello! Gerne :) ich hab gestern Abend noch ein paar Videos weiter gemacht. Ich bin heute Mittag nämlich bei der physio und hab eine doppelstunde bekommen – das wird etwas länger dauern!

**2025-12-16T08:37:55.581019** - Julia:
> Mert und ich haben gestern noch besprochen, dass es am meisten Sinn macht, wenn wir die paar XMas Videos selbst schneiden und die Editor die anderen Videos bekommen. KA wann und ob so zwischen den Jahren arbeiten aber dann wäre evtl. im Januar schon viel fertig :slightly_smiling_face: 

**2025-12-16T09:06:33.363259** - Julia:
> Vllt nochmal zusammenfassend, diese Videos könnten wir fertig machen – was meint ihr?

*Videos Gorenje:*
• vor XMas: *Plätzchen Rezept*
• während XMas: *Ginger Shot* für gut ins neue Jahr rutschen
• nach XMas: Beauty Shots *Produkte "Santa delivered" x3??*
*Hisense Videos:*
• vor XMas: *Vorher/ Nachher XMas Lights* :white_check_mark: Schnitt
• vor/während/ nach XMas: *Movies Must Watch* x2 oder x3 :hourglass_flowing_sand: Schnitt
• nach XMas: *Interactive Warumup* (wegen Trend?) "Ready machen für das neue Jahr" :white_check_mark: Schnitt

**2025-12-16T10:22:54.572439** - Julia:
> <@U093J779DAQ> Stimmt das bei Movie Must Watch:
Xmas Edition: Grinch, Kevin, Santa Clause
Xmas Kids: Barbie, Weihnachtsmann &amp; Co KG, Polarexpress?

**2025-12-16T10:32:12.098779** - Julia:
> 

**2025-12-16T10:35:51.239299** - Julia:
> Dankeeee

**2025-12-16T10:43:23.157969** - Julia:
> hier quasi :)

**2025-12-16T11:05:21.263589** - Julia:
> Ich hab keine Ahnung 

**2025-12-16T11:18:29.112389** - Julia:
> gerne, ich kann bis 12.25 

**2025-12-16T12:46:29.053719** - Julia:
> Jaaa wir hatten das nicht in Redaktionsplan. Ist uns dann aufgefallen beim Abbau und den Rosen :sweat_smile::smiling_face_with_tear:

**2025-12-16T14:38:02.973009** - Julia:
> bin auch gleich wieder da! Leider U-Bahn Chaos 

**2025-12-16T14:38:48.533799** - Julia:
> Genau, wir haben extra nur Trailer oder Demo Versionen gezeigt 

**2025-12-16T14:38:55.607079** - Julia:
> Von YouTube 

**2025-12-16T14:46:44.569939** - Julia:
> Ja find ich auch 

**2025-12-16T14:48:28.352009** - Julia:
> Ja passt! Wahrscheinlich können wir das erst entscheiden, wenn Video 1 fertig ist 

**2025-12-16T14:49:04.196489** - Julia:
> Die VO legst du separat ab oder auch in die Ordner direkt? Hab Angst vor denen :joy:

**2025-12-16T14:57:31.178879** - Julia:
> QuickTime hat keinen bock mehr, stürzt alle 3 Videos ab  :rage:

**2025-12-16T15:04:01.507259** - Julia:
> das ist super! 

**2025-12-16T15:42:26.295039** - Julia:
> hör auf.. aber wie gut, dass du das alles rausgefunden hast! juhuuu

**2025-12-16T15:42:29.999779** - Julia:
> Update an Flo vllt?

**2025-12-16T15:57:44.490019** - Julia:
> voll cool, vielen dank! :slightly_smiling_face: bin gerade im Premiere Tunnel aber schau ich mir später an

**2025-12-16T16:00:08.183199** - Mert Koc mentioned Julia:
> Alle Videos sind jetzt hochgeladen :slightly_smiling_face:
Editierst du schon Videos <@U09D64LA420>?

**2025-12-16T16:00:19.902359** - Julia:
> muss die Belichtung noch besser hinbekommen und text fehlt noch aber so als Rohschnitt. Was meint ihr?

**2025-12-16T16:00:30.153039** - Julia:
> yes, erster draft lädt auch gerade hier rein

**2025-12-16T16:14:08.655619** - Julia:
> ja klar!
• Okay, findest du es braucht keinen Switch Sound? Ohne ist es lame.
• Das mit der Musik ist super nervig, weil alle Sounds nur 5 bzw. 10 Sekunden lang sind, deshalb ist es gestückelt aber ich schau mal was noch geht

**2025-12-16T16:31:23.104929** - Julia:
> Ah nicht, dass wir da durcheinander kommen, da bin ich parallel auch schon dran

**2025-12-16T16:33:28.453989** - Julia:
> artlist

**2025-12-16T19:48:55.252229** - Julia:
> Shit! Habt ihr diese Prozess E-Mail für Flo gemacht? Voll vergessen 

**2025-12-17T09:00:57.357059** - Julia:
> FYI, ich habs jetzt so gemacht ganz grob

**2025-12-17T09:04:22.258889** - Julia:
> good morning :slightly_smiling_face: sorry

**2025-12-17T09:06:44.720909** - Julia:
> figma! kanns auch schicken, moment

**2025-12-17T09:07:35.739189** - Julia:
> <https://www.figma.com/board/R4ar6AX2IMiYboLpcYFzDt/Brainstorming-Content-Q4?node-id=3721-175&amp;t=mucWvSzF7BZN0FZe-1>

habs hier unten rein beim brainstorming :slightly_smiling_face:
passt gerne die farben usw. etwas an haha
hab bestimmt irgendwas vergessen oder falsch

**2025-12-17T09:46:01.271699** - Julia:
> ah cool!

**2025-12-17T09:46:13.517259** - Julia:
> Ja man vergisst da auch voll schnell einiges, musste 5 mal ausbessern

**2025-12-17T09:50:06.243419** - Julia:
> 

**2025-12-17T12:25:42.414249** - Julia:
> Marie hat mich gerade nach to-do's gefragt. Mert soll ich ihr die restliche Gorenje Sortierung geben oder bist du da schon komplett fertig?

**2025-12-17T12:42:30.157499** - Julia:
> done :slightly_smiling_face:

**2025-12-17T13:21:53.472729** - Julia:
> okay. sagt bescheid, ich bin da

**2025-12-17T13:22:03.110659** - Julia:
> wenn mein laptop nicht explodiert, kann ich evtl. joinen :smile:

**2025-12-17T14:02:05.091459** - Julia:
> passt!

**2025-12-17T14:05:50.085789** - Julia:
> ich auch

**2025-12-17T14:05:51.987519** - Julia:
> beides

**2025-12-17T15:08:24.479549** - Julia:
> Interactive: hier haben wir 2 Perspektiven gefilmt und da wäre es super, wenn sie etwas hin und her cutten könnten
Santa: find ich super! unser Material sieht nur nicht so schön aus haha

**2025-12-17T15:31:30.147639** - Julia:
> jaaa! cool

**2025-12-17T16:00:11.606849** - Julia:
> Voll gut! :slightly_smiling_face:

**2025-12-17T16:00:35.449609** - Julia:
> Okay ich bin voll erleichtert gerade, ich dachte irgendwie das Material kann garnichts :smile:

**2025-12-17T16:03:58.955389** - Julia:
> Ja stimmt! also ich mag nur die Aufzählung nicht so gerne weil es logischerweise abgehakt wirkt. Aber ich denke mit musik wirds dann eh smooth :slightly_smiling_face: voll cool Mert!

**2025-12-17T16:05:54.735389** - Julia:
> Frage in die Runde: sollen wir die Cuts auch Flo zeigen oder machen wir das alles mit dem Kunden und ciao?

**2025-12-17T16:07:47.560319** - Julia:
> :sadblob:

**2025-12-17T16:33:40.792309** - Julia:
> perfekt! Hab eben noch gesehen: "Du wolltest nur eine Folge schauen".. könnten sie auch machen, oder?

**2025-12-17T16:34:46.417589** - Julia:
> ich verlinke euch in Asana jetzt meine fertigen Videos (alle noch ohne Texte, falls wir welche wollen)

**2025-12-17T16:41:51.793329** - Julia:
> ja, wenn wir laut asana posten dann wäre das schon am 5.1. deshalb

**2025-12-17T17:10:25.827679** - Julia:
> Nee :slightly_smiling_face: danke dir!

**2025-12-17T18:52:17.618099** - Julia:
> so alle 4 Must Watch Videos sind in Drive, sagt gern Bescheid. Bis morgen! :slightly_smiling_face:

**2025-12-18T09:50:52.513079** - Julia:
> Hello! :slightly_smiling_face: Ne ich denke auch, einfach weiter schneiden oder eben nicht.
Wie cool!

**2025-12-18T09:51:01.306629** - Julia:
> Was mir noch eingefallen ist, es gibt doch gerade diesen Trend:

**2025-12-18T09:53:44.731919** - Julia:
> okay habs euch in instagram geschickt :smile:

**2025-12-18T09:54:48.100739** - Julia:
> den trend könnten wir eigentlich eeeeasy und schnell mitnehmen oder? ginger shot: "wenn du endlich keine teuren ingwer shots mehr kaufen musst" oder sowas

**2025-12-18T09:58:20.642769** - Julia:
> <@U08V6A47PKN> <@U093J779DAQ> hab mit "Juli" ergänzt

**2025-12-18T09:59:15.125469** - Julia:
> ich seh nur eins. welches noch? :slightly_smiling_face:

**2025-12-18T10:07:04.066929** - Julia:
> Das ist immer die Frage.. also den Song nicht, aber bei dem Visuellen?! Ich hab das mal in diese Whatsapp Gruppe geschickt mit den "ideen" – kann Flo ja sagen, ob hop oder top

**2025-12-18T10:07:29.530049** - Julia:
> oh mannooo, drück dir die daumen!

**2025-12-18T10:07:53.880879** - Julia:
> Also falls ihr noch Zeit habt zwischendurch schaut euch gerne mal die Must Watches an, die ich in Asana reingelegt hab. Würde sonst anfangen die Filmtitel einzubauen

**2025-12-18T10:21:00.374799** - Julia:
> alright, aber ne, seh ich genauso

**2025-12-18T10:23:48.162769** - Julia:
> habs

**2025-12-18T10:43:23.716689** - Julia:
> schöön! :slightly_smiling_face:
Ja same. Vllt echt dort das VO weglassen und nur mit Text arbeiten?

**2025-12-18T10:50:52.763559** - Julia:
> ja stimmt

**2025-12-18T10:55:14.903729** - Julia:
> 

**2025-12-18T11:00:19.430849** - Julia:
> ja verstehe was du meinst, i try. teilweise einfach schwierig, weils nichts zusammen passt und die trailer auch visuell voll überbelichtet sind

**2025-12-18T11:00:42.824309** - Julia:
> yes

**2025-12-18T11:11:43.337259** - Julia:
> sollen wir jetzt danach kurz sprechen?

**2025-12-18T11:20:24.280099** - Julia:
> Wenn die Bildspur eines Videos Informationen enthält, welche nicht aus der Audiospur hervorgehen, muss eine Audiodeskription als Alternative bereitgestellt werden. In dieser werden die visuellen Inhalte für Menschen mit oder ohne eingeschränktem Sehvermögen beschrieben.


PUH

**2025-12-18T12:22:56.845079** - Julia:
> oh okay! 

**2025-12-18T14:23:50.699759** - Julia:
> Ich glaub mein Premiere rush ist schon in weihnachtsurlaub, es mag nichtmehr :sweat_smile: 

**2025-12-18T14:47:45.455829** - Julia:
> okay. Aber wir sind ja eh nicht zum feedbacken da. Oder wolltet ihr rein schauen? Ich würde gerne komplett frei machen :face_with_spiral_eyes:

**2025-12-18T14:54:56.295919** - Julia:
> Ja okay. Perfekt, genau. Da können wir uns gerne auch aufteilen 

**2025-12-18T16:02:02.582829** - Julia:
> uh nice! wie wäre es mit kürzer "Wall upgrade :100:"

**2025-12-18T16:06:18.724069** - Julia:
> jetzt dreht er komplett durch, hat sich aufgehangen und dann kam das hahaha

**2025-12-18T16:07:16.352049** - Julia:
> Ja cool! vllt noch: "Looking for a sign?"

**2025-12-18T16:07:50.683199** - Julia:
> kreativ und faul, irgendwas dazwischen

**2025-12-18T16:08:00.790429** - Julia:
> Welche Schriftgröße hast du bei den Texten benutzt?

**2025-12-18T17:09:19.432179** - Julia:
> bei mir dauert der upload noch ewig, Julia wenn du auch nichtmehr da bist. ich kann die videos gerne dann direkt in <http://frame.io|frame.io> legen (?) und Laureen schreiben

**2025-12-18T17:31:51.868389** - Julia:
> okay :face_with_peeking_eye:

**2025-12-18T17:46:13.432269** - Julia:
> bin noch bissl hier. Bis morgen! :slightly_smiling_face:

**2025-12-19T09:13:55.957439** - Julia:
> GuMo! Die Videos liegen geupdated in den Ordnern und können in <http://frame.io|frame.io> hochgeladen werden :slightly_smiling_face:
Mein speicher ist jetzt durchgängig voll, ich kann einfach nichtmehr weiter schneiden mit diesem gerät.. Aber ich würde anfangen detaillierte briefings zu schreiben für Hummus &amp; Ginger Wellness. Da dachte ich mir, könnten wir ja auch am Montag/ Dienstag dann noch das VO selbst drüber legen? Also dass sie uns die groben Schnitte schon mal erstellen mit Musik etc.? Das meint ihr? Auch für die anderen Videos? Glaube das wäre auch eine Variante für die Sprachbarriere?

**2025-12-19T09:23:21.831989** - Julia:
> jaa! Und könntest du mir einmal schicken, wie die Premiere einstellungen sind für die farbkorrektur? würde das dann auch einfach immer hinzufügen

**2025-12-19T09:26:26.846209** - Julia:
> All i want for christmas: ein neuer laptop :smile:

**2025-12-19T10:13:28.649069** - Julia:
> ich kann's nicht Downloaden :pleading_face:

**2025-12-19T10:27:27.376819** - Julia:
> ne wegen meinem Laptop 

**2025-12-19T12:02:19.281659** - Julia:
> kein stress :slightly_smiling_face: alles guuut

**2025-12-19T12:02:23.917299** - Julia:
> ups! haha

**2025-12-19T12:03:45.679999** - Julia:
> spreche gerade mit Marie, sie hilft uns auch bissl beim briefen/ vorbereiten :slightly_smiling_face:

**2025-12-19T12:34:25.798499** - Julia:
> same :smile:

**2025-12-19T15:01:33.503709** - Julia:
> sorryyyy, wir waren noch im "off meeting"

**2025-12-19T15:47:24.959069** - Julia:
> ja gerne! 16.15 sowas?

**2025-12-19T16:16:30.860379** - Julia:
> koooommen

**2025-12-22T08:36:03.109459** - Julia:
> Guten morgen! Ja.. genau Flo &amp; Alex meinten dann auch so "Nö Text haben wir ja nicht"..

Also <@U093J779DAQ> dann erstellen wir trotzdem mal die Briefings und schauen dann, oder? Marie kann uns hier heute auch noch helfen.
FYI für euch beide: ich hab gestern mit Flo geschrieben, weil er meinte ich soll am Dienstag einen AI Workshop mit Peru halten. Ich hab ihn aber dann gefragt, ob ich Dienstag spontan freinehmen kann – haben endlich Flüge gefunden und das wäre am Dienstag :slightly_smiling_face: . Bisher noch keine Antwort

**2025-12-22T09:02:34.561869** - Julia:
> FYI

**2025-12-22T09:04:08.342369** - Julia:
> Oke :slightly_smiling_face:

**2025-12-22T09:04:50.089359** - Julia:
> Ne, also das wird keine krasse Vorbereitung. Ich werd einfach zeigen, was ich da mache. Sorry aber, ich hab ihm auch gesagt "ich kann nur die Basics"

**2025-12-22T11:48:53.527349** - Julia:
> <@U08V6A47PKN> wir kommen mit den Feedbacks nicht weiter – das ist soo viel feedback und teilweise 3 mal das gleiche. Sollen wir Flo jetzt schon anhauen und sagen, dass es so nicht klappt?

**2025-12-22T13:41:02.480709** - Julia:
> designern

**2025-12-22T16:57:08.491319** - Julia:
> Bisher noch garnicht, Mert ist im Austausch. Oder? :smile:

**2025-12-22T17:30:53.135879** - Julia:
> klingt nach einem guten Plan (B)

**2025-12-23T07:32:01.733389** - Julia:
> Guten Morgen :sun_with_face: 
Wollte euch Bescheid geben, dass ich heute ab mittags/ nachmittags da bin. Davor sitze ich im Flieger! Flo weiß Bescheid. 
Schon mal vorab: wunderbare Weihnachten und erholsame Ferien für euch :heart_hands::heart_eyes: Liebs sehr, dass wir wieder ein Team sind!

**2025-12-23T15:16:03.594839** - Julia:
> Danke :heart_hands: hatten fast 2 std Verspätung aber naja 

**2026-01-07T09:10:27.258949** - Julia:
> Guten Morgen! Happy new year :heart_eyes::sparkles:

**2026-01-07T09:10:33.399469** - Julia:
> Ja gerne! Wann ihr wollt?

**2026-01-07T09:15:13.653029** - Julia:
> perfekt

**2026-01-07T09:15:24.191079** - Julia:
> oder 9.45? :slightly_smiling_face:

**2026-01-07T09:16:07.799729** - Julia:
> juhuuu

**2026-01-07T09:34:08.083959** - Julia:
> neeeein

**2026-01-07T09:34:12.799899** - Julia:
> Asana wrapped

**2026-01-07T09:45:07.581279** - Julia:
> uh nice! sehr cool ja

**2026-01-07T09:46:28.989099** - Julia:
> bin im meeting

**2026-01-07T11:42:08.601069** - Julia:
> Info von Flo: die Designer bekommen Deutschkurse gestellt

**2026-01-07T12:00:18.884519** - Julia:
> Ja total

**2026-01-07T12:03:56.012039** - Julia:
> konnte gerade noch nicht mit dem feedback starten, bisher mit Flo im Call und jetzt SIXT übergabe FYI

**2026-01-07T13:37:01.826289** - Julia:
> <@U093J779DAQ>
• <https://app.asana.com/1/1199360402832734/project/1211896720550264/task/1212474812894547?focus=true|WarmUp>: stellen wir so online meinten wir vorhin, right? Würde dann hier nur die Copy anpassen zu: "Vorsätze durchziehen" oÄ
• <https://app.asana.com/1/1199360402832734/project/1211896720550264/task/1212357252090003?focus=true|du wolltest nur eine Folge schauen>: ist das Feedback in Frame schon aktuell oder noch bevor Malorie das Video abgelegt hat? Beides 19 Tage her, deshalb für mich schwierig zu erkennen
• <https://app.asana.com/1/1199360402832734/project/1211896720550264/task/1212357252535002?focus=true|Marina Rewatch>: können wir posten
• Rest kommentiere ich direkt in die Tasks für die Designer :slightly_smiling_face: 

**2026-01-07T13:48:01.158099** - Julia:
> alles klar!
Achso, ich dachte du meintest vorhin lassen wir jetzt einfach so

**2026-01-07T13:56:36.386309** - Julia:
> okay!

**2026-01-07T15:03:52.389849** - Julia:
> moment, ich lese kurz

**2026-01-07T15:06:27.050079** - Julia:
> Ja Bilder davon wären super wichtig!

**2026-01-07T15:09:42.990879** - Julia:
> • wie Mert schon sagt: ich würde es zusammen legen und sagen Verwendung/ Nutzung auf beiden Kanälen --> 4 Videos dann insgesamt?
• Taggen ist Pflicht
• Schnitt und Post liegt bei ihr? 
• wie viele Feedbackschleifen inklusive?
• RAW Material: brauchen wir es ja oder nein?
• ich hab gerade bei einem Freelance Projekt noch einen Insider für UGC bekommen, da wird pro Skript (max. 2 Video Schnitte draus) 350€ gezahlt, also denke in dem Rahmen wird es sich hier auch bewegen

**2026-01-07T15:27:49.304279** - Julia:
> wenn du magst, können wir das auch morgen zusammen machen? Ich hab von 16.-17 Uhr mit ihr Übergabe. Aber laut Flo brauch ich das ganze Paid Wissen dann auch für SIXT

**2026-01-07T15:44:33.368639** - Julia:
> ich weiß es klingt gemein, aber manchmal weiß ich garnicht, wo ich beim feedback anfangen soll :smile:

**2026-01-07T15:55:23.983059** - Mert Koc mentioned Julia:
> <@U09D64LA420> sollen wir/ können wir die Designer auch direkt fragen ob sie Thumbnails erstellen können oder sollen wir das selber machen? An sich brauchen sie nur einen Screenshot + Text erstellen. Ich bräuchte das in Zukunft, damit ich das uploaden evtl. automatisieren kann. :confused: (wobei das auch nicht so gut performen soll)

**2026-01-07T16:03:23.677659** - Julia:
> würde das lieber bei uns lassen. bezüglich typo größe usw.

**2026-01-07T16:07:42.871759** - Julia:
> könntet ihr mir nochmal den Gorenje Redaktionsplan schicken? ist bei mir irgendwie nichtmehr im Verlauf gespeichert

**2026-01-07T16:08:23.506999** - Julia:
> dankee!

**2026-01-07T16:35:49.425669** - Julia:
> gute Frage. Also ich hatte schon noch viel Feedback. Ich hab mal eben in diesem AI channel gefragt, wie ihre Kapazitäten sind

**2026-01-07T16:37:48.357579** - Julia:
> gebe Bescheid, wenn sie sich melden (oder Flo ein Machtwort spricht)

**2026-01-07T16:40:14.429269** - Julia:
> Weil sie diese Decathlon Projekt haben und Flo natürlich die Prios festlegt

**2026-01-07T16:40:37.075399** - Julia:
> bist drin

**2026-01-07T16:47:35.298119** - Julia:
> kann ich gerne eintragen :slightly_smiling_face:
<@U093J779DAQ> und du postest?

**2026-01-07T16:53:35.561179** - Julia:
> ja glaube das dauert noch bisschen. Machen wir! Bis morgen :slightly_smiling_face:

**2026-01-07T17:42:57.079539** - Mert Koc mentioned Julia:
> <@U09D64LA420> Kann ich sie posten? ^^

**2026-01-07T18:23:02.239849** - Julia:
> Jaa gerne

**2026-01-07T18:23:21.922519** - Julia:
> Oder was meinst du? :slightly_smiling_face:

**2026-01-08T08:59:12.699119** - Julia:
> Guten Morgen! Meine Erkältung ist leider schlimmer geworden und so sollte ich nicht mit zum Studio :pleading_face:

**2026-01-08T09:12:34.301759** - Julia H. mentioned Julia:
> <@U09D64LA420> dann schreib dich bitte krank, damit du gesund werden kannst ja? wir schaffen alles

**2026-01-08T09:21:27.718319** - Julia H. mentioned Julia:
> Bei mir ist es eh ums Eck! Also yes! Dann lass uns um 13 Uhr da treffen und wir filmen alles mit für dich <@U09D64LA420>

**2026-01-08T09:32:06.223689** - Julia:
> Dankeeee! Hätte euch so gerne gesehen :sleepy: bin so sauer AHH

**2026-01-08T09:32:41.416049** - Julia:
> Aber vllt schaffen wir es dann nächste Woche mal im Büro oder auch einfach zum Lunch? :crossed_fingers:

**2026-01-08T09:34:43.289419** - Julia:
> ja und vorallem steck ich euch so 10000% an

**2026-01-08T09:56:03.595719** - Julia:
> ich schreib nur 2,3 nachrichten und abends die Übergabe, sonst gibts glaub ich Ärger

**2026-01-08T09:56:20.735449** - Julia:
> wegen mir gerne. bis dahin sollte ich auch wieder fit sein :crossed_fingers:

**2026-01-08T11:02:45.461529** - Julia:
> sagt mir gerne Bescheid, was im Call rauskam. ich sehe leider aus wie der Tod

**2026-01-08T15:15:16.293019** - Julia:
> wie waaars?

**2026-01-08T15:35:48.149119** - Julia:
> Ich hab jetzt einen Call mit Flo wegen lidl und danach die SIXT Übergabe. Aber Mert morgen gleich? :slightly_smiling_face:

**2026-01-08T15:35:55.478959** - Julia:
> hab ich gesehen :heart_eyes:

**2026-01-08T15:55:00.355119** - Julia:
> hahaha wie cool! Können wir sonst auch gerne morgen zusammen machen? :slightly_smiling_face:

**2026-01-08T15:55:14.392169** - Julia:
> willst du unsere Wohnung designen? pleasseeee haha

**2026-01-08T15:56:47.143889** - Julia:
> Also das heißt nur kurz für mich: wir könnten da wirklich eine komplette Küche reinbauen und so wie es uns gefällt?

**2026-01-08T16:01:55.226419** - Julia:
> bin jetzt mit Jana im Call für die Übergabe LETS SEE

**2026-01-08T17:02:03.089629** - Julia:
> sehr cool! Ich glaube zumindest updaten, oder?

**2026-01-08T17:02:14.350669** - Julia:
> happy feierabend und schönes WE! Du bist morgen off, oder? :slightly_smiling_face:

**2026-01-08T17:03:18.165999** - Julia:
> okay

**2026-01-08T17:29:01.977839** - Julia H. mentioned Julia:
> Euch auch und Gute Besserung <@U09D64LA420> :heart:

**2026-01-08T17:30:51.065749** - Julia:
> ahh okay danke!

**2026-01-09T09:33:17.680499** - Julia:
> Guten Morgen :slightly_smiling_face: Ich hab um 10 Uhr jetzt LIDL Call. Wollen wir danach kurz sprechen?

**2026-01-09T10:33:05.583639** - Julia:
> wäre ready :slightly_smiling_face:

**2026-01-09T12:19:44.312429** - Julia:
> voll gut!

**2026-01-09T12:20:05.595009** - Julia:
> vllt noch paar Stichpunkte mit Vorteilen, was man wie und wo shooten kann?

**2026-01-09T13:06:22.838799** - Julia:
> ahh aber wie cool!

**2026-01-09T13:11:21.691179** - Julia:
> meinst du man kann noch eine Person an das L-Eck stellen? Da erkennt man die Dimensionen etwas besser

**2026-01-09T13:43:06.883129** - Julia:
> cool :slightly_smiling_face: danke!

**2026-01-09T13:43:28.354909** - Julia:
> Wenn ich da wieder fit bin, sehr gerne. Kann euch ja am Sonntag Abend mal kurz ein Update hier geben

**2026-01-09T13:47:07.443639** - Julia:
> voll gut!

**2026-01-09T13:47:12.544989** - Julia:
> macht schon Spaß mit AI oder?

**2026-01-11T20:22:09.087019** - Julia:
> Hallooo no way :pleading_face: 

**2026-01-11T20:22:20.826089** - Julia:
> Ja wollt auch eben sagen, bin noch zu verschleimt :sneezing_face:

**2026-01-11T20:22:27.954299** - Julia:
> Gute Besserung! 

**2026-01-12T08:50:36.298539** - Julia H. mentioned Julia:
> Good morning ihr beiden
Ich hoffe ihr hattet ein schönes WE? <@U09D64LA420> bist du wieder gesund?
Ich nehme mal an dass wir heute nicht ins Office gehen haha. Donnerstag dann aber fix? Mittwoch ginge auch

**2026-01-12T09:28:41.619879** - Julia:
> Guten Morgen! Ich bin da, aber ne nicht gesund. Ja gerne dann Donnerstag! :slightly_smiling_face:

**2026-01-12T09:36:23.932159** - Julia:
> bleib du stark, fürs team hahaha

**2026-01-12T09:45:04.440809** - Julia:
> <@U093J779DAQ> bist du dann heute raus, oder?

**2026-01-12T10:01:28.292849** - Julia:
> Laureen sagen: Imke direkt als Collab. einladen vor Posten

**2026-01-12T10:01:44.846429** - Julia:
> Okay, jaa erhol dich!

**2026-01-12T10:56:07.510849** - Julia:
> Klar! erhol dich in ruhe

**2026-01-12T12:04:58.431969** - Julia:
> glaube das wird lustig :slightly_smiling_face:

**2026-01-12T14:23:05.246919** - Julia:
> sorry, ich war jetzt 2 std in meetings mit Flo

**2026-01-12T14:23:34.552919** - Julia:
> super, hab noch nicht reingucken können.
Heißt dann aber auch 2x Ginger, 2x Brot, richtig?

**2026-01-12T14:25:05.575829** - Julia:
> ich find den 2. sound bisschen weird tatsächlich

**2026-01-12T15:02:48.113949** - Julia:
> Leute blöde Frage: findet ihr David könnte also SSIO gehen? 
Bin echt lost, es gibt keine passenden Komparsen und ich weiß, der ist bei jedem schmarn dabei 

**2026-01-12T15:53:30.233959** - Julia:
> <https://www.p-f.tv/system/index.php?cccpage=kleindarsteller&amp;show=212231>

**2026-01-12T15:53:48.602249** - Julia:
> leute ich kann nichtmehr, diese seiten sind so cringe teilweise :smile:

**2026-01-12T15:58:25.824969** - Julia:
> ISSO

**2026-01-12T15:58:40.089819** - Julia:
> hab grad auch mit David gesprochen der wäre auf jeden fall am start

**2026-01-12T15:58:50.176939** - Julia:
> also finde beide voll okay, halt nicht SSIO aber optionen :slightly_smiling_face:

**2026-01-12T15:59:10.863879** - Julia:
> voll gerne!

**2026-01-12T15:59:19.241789** - Julia:
> moment

**2026-01-12T16:02:15.931009** - Julia:
> • internes Pitch Video mit einer Länge von 30-40 Sekunden (keine Veröffentlichung!)
• Timing: Ende dieser oder Anfang nächste Woche 
• Dauer des Drehs schätze ich mal auf maximal 3 Std.
• Outdoor Shooting: Isar
• Content: humorvoll, Social Media, wir faken eine "FKK" Szene, mit weiblichem Model zusammen
• kümmern uns natürlich um warme Mäntel, Heißgetränke usw.

**2026-01-12T16:02:32.125079** - Julia:
> <@U093J779DAQ> meinst du deine Mitbewohnerin hätte da Lust auf die weibliche Rolle?

**2026-01-12T16:26:10.626069** - Julia:
> genau, hatten kurz gehuddelt :slightly_smiling_face:

**2026-01-12T16:26:15.306119** - Julia:
> ah okay!

**2026-01-12T16:26:27.396059** - Julia:
> die sind alle sooooo!! :smile:

**2026-01-12T16:54:34.779749** - Julia:
> Kennt ihr die 102 Boyz? falls ja, die kennt man? sollte man kennen? :smile:

**2026-01-12T16:56:26.369739** - Julia:
> DANKE hahaha

**2026-01-12T17:06:54.357289** - Julia:
> ach krass!

**2026-01-12T17:30:08.478529** - Julia:
> super, dankeschön! :slightly_smiling_face: Happy Feierabend und bis morgen :heart:
(bin morgen wieder mehr bei LIDL und hab noch mit Marvin eine Übergabe auch FYI)

**2026-01-12T17:40:57.276129** - Julia:
> bin gespannt was wir am mittwoch im Call besprechen :face_with_spiral_eyes:

**2026-01-13T08:54:24.928579** - Julia:
> GuMo :slightly_smiling_face:

**2026-01-13T09:02:23.219049** - Julia:
> Ein kleines bisschen besser glaube ich, aber trotzdem noch garnicht fit einfach. Bei euch?

**2026-01-13T09:22:28.763799** - Julia:
> ach kooomm :sleepy:

**2026-01-13T09:46:56.164799** - Julia:
> ah cool!

**2026-01-13T10:21:32.461939** - Julia:
> Was meint ihr wegen Dänemark? Wie entscheiden sie sich?

**2026-01-13T10:30:58.989589** - Julia:
> haha sehr gut

**2026-01-13T10:31:09.236819** - Julia:
> versteh ich :sleepy:

**2026-01-13T11:27:46.723079** - Julia H. mentioned Julia:
> Hello ihr beiden, Laureen hat bei Gorenje alles freigegeben und bei Hisense auch. Zumindest laut Redaktionsplan. Wie machen wir das mit dem Posten <@U093J779DAQ>? <@U09D64LA420> kannst du das machen?

**2026-01-13T11:52:33.229409** - Julia:
> puh gute Frage. Eigentlich nicht oder?

**2026-01-13T11:53:05.052129** - Julia:
> <@U093J779DAQ> wir können uns in Zukunft auch gerne aufteilen. Du postet Hisense, ich Gorenje?
Den Paid Push würde ich allerdings dir überlassen, da kann ich nur verlieren :smile:

**2026-01-13T11:57:08.672009** - Julia:
> ja klar. Hisense muss ich den Zugang nochmal mit Laureen probieren :face_with_spiral_eyes: würde ich sie morgen direkt fragen

**2026-01-13T12:02:13.834369** - Julia:
> nee, fand ich jetzt nicht

**2026-01-13T12:02:24.114609** - Julia:
> bzw. schreit sie manchmal so :smile:

**2026-01-13T15:02:42.229009** - Julia:
> Also David wird unser SSIO :smile: Flo hats grad freigegeben

**2026-01-13T15:26:46.995179** - Julia:
> Unsere "Mandy" hat abgesagt für den LIDL Videodreh – habt ihr noch eine Idee, wer passen könnte?
Ich würds machen, ist mir total egal, aber ich sitze da mit im Pitch. Das wäre etwas unangenehm :smile:

**2026-01-13T15:29:04.812679** - Julia:
> • natürlich und "klassisch schöne"/attraktive Frau
• Mitte 20
• schlank/ sportlich, groß
• Haarfarbe oder Hauttyp spielt hier keine Rolle
Das wären die Anfoderungen

**2026-01-13T15:29:11.660649** - Julia:
> jaa ich denks mir auch...

**2026-01-13T16:34:54.946939** - Julia:
> ja.. blöd, wenn man sich die Leute verkrault :sweat_smile:

**2026-01-13T16:35:09.901769** - Julia:
> Ja klar mach das. Oh manno :pleading_face:

**2026-01-14T08:54:58.527769** - Julia:
> Gumo! FYI Ich bin heute erst um 10 da, hab noch einen Termin vorher 

**2026-01-14T10:22:06.951569** - Julia:
> Ahh das ist ja vogelwild

**2026-01-14T10:22:14.634059** - Julia:
> :rolling_on_the_floor_laughing:

**2026-01-14T10:22:21.246739** - Julia:
> yes, moment

**2026-01-14T10:23:44.545079** - Julia:
> er bekommt dann einen Code

**2026-01-14T10:54:24.716399** - Julia:
> hatte heute morgen kurz mit Flo gesprochen und da meinte er, er will nochmal über die Zuständigkeiten sprechen. Also wahrscheinlich auch bei mir wegen SIXT usw.

**2026-01-14T11:15:56.213259** - Julia:
> wollen wir danach kurz drin bleiben oder in huddle springen?

**2026-01-14T12:12:05.054319** - Julia:
> 24.04.1994
Julia Hopper (kein Zweitname)

**2026-01-14T12:21:31.791909** - Julia:
> aber eigentlich war das ja auch klar. müssen sie ja davon ausgehen, dass es jeden tag teurer wird

**2026-01-14T12:27:56.707209** - Julia:
> puh okay

**2026-01-14T12:31:10.910189** - Julia:
> bin auch grad dabei :smile:

**2026-01-14T12:32:05.752619** - Julia:
> Also die Frage ist halt bei sowas wie Fan Interview, zB
"3 schnelle Fragen“
• Wer gewinnt heute?
• Welcher Spieler macht den Unterschied?
• Wo schaust du sonst Handball? (Halle / TV / Kneipe)
--&gt; Das müsste man ja direkt vor Ort schneiden und vor 20.30 als Reel hochladen. Ich glaube das ist nicht machbar

**2026-01-14T12:36:46.676589** - Julia:
> Was haltet ihr von sowas?
Umfrage Zuschauer:
*This or That: Wer gewinnt das "Match" --&gt; Deutschland oder Spanien?*
*Fragen:*
• *Bier oder Sangria?*
• *Bratwurst oder Tapas?*
• *Deutsche Abwehr oder spanischer Angriff?*
• *Apfelkuchen oder Mandelkuchen?*
Etc.

Das könnte man dann auch am Dienstag posten und sagen "auch wenn das Spiel so ausgegangen ist, unsere Umfrage zeigt folgendes Ergebnis"

**2026-01-14T12:37:09.908109** - Julia:
> ja fänd ich auch mega

**2026-01-14T12:37:21.833489** - Julia:
> dann aber bitte keinen Flug um 8 Uhr morgens, das packe ich nicht hahaha

**2026-01-14T12:38:45.245279** - Julia:
> Okay. Mert wir könnten ja sonst morgen die erste Szene im Büro drehen? Wir sitzen beide am Laptop und dann sprechen wir drüber, dass das Match ansteht und dann Cut auf dem Weg zum Flughafen :smile:

**2026-01-14T12:40:02.475299** - Julia:
> Dann wäre doch die Reihenfolge:

• Reel "Should we watch the match...?" am Montag bis 19 Uhr? 
• Story Begleitung ca. 8 Slides/ Videosnippets Montag vor, während und nach dem Spiel
• Reel "Match Spanien/ Deutschland" Interview am Dienstag EOD

**2026-01-14T12:40:28.592479** - Julia:
> reicht das?

**2026-01-14T12:45:59.822759** - Julia:
> Vllt können wir einen Trend von Marie noch nehmen

**2026-01-14T12:46:09.785209** - Julia:
> 

**2026-01-14T12:46:58.551179** - Julia:
> haha super danke

**2026-01-14T12:47:36.608709** - Julia:
> das?

**2026-01-14T12:47:53.065399** - Julia:
> :joy: perfekt das nehmen wir

**2026-01-14T12:48:40.179359** - Julia:
> ich frage an

**2026-01-14T12:50:07.215729** - Julia:
> there you go

**2026-01-14T12:50:15.671419** - Julia:
> 

**2026-01-14T12:55:05.218429** - Julia:
> niiice

**2026-01-14T12:55:37.447879** - Julia:
> genau und auch wie's dort halt aussieht mit Branding usw.

**2026-01-14T12:55:44.331299** - Julia:
> perfekt :heart_eyes:

**2026-01-14T12:55:51.448559** - Julia:
> ich glaub so effizient waren wir noch nie oder haha

**2026-01-14T12:57:06.069059** - Julia:
> Das mit den Wolken passt super, wenn wir eh im Flieger sitzen :smile: könnten wir verbinden

**2026-01-14T12:59:07.293049** - Julia:
> vielen Dank! Ja same

**2026-01-14T12:59:14.894899** - Julia:
> oh stop Julia

**2026-01-14T12:59:18.661379** - Julia:
> Ich glaube man kann es nicht sehen

**2026-01-14T12:59:36.094299** - Julia:
> 

**2026-01-14T13:00:03.003799** - Julia:
> okay

**2026-01-14T14:28:07.014399** - Julia:
> Weil ich es gerade sehe: bei gorenje haben wir einen kommentar "viel Spaß beim Reinigen"
hier könnten wir ja antworten "Das geht easy in der Spülmaschine" oder? Dürfen wir das?

Sollten wir Marie/ Anna dazu mal briefen für die Zukunft?

**2026-01-14T14:28:56.236699** - Julia:
> ja da war ich mir nicht sicher

**2026-01-14T14:36:53.408849** - Julia:
> okay, dankeee Julia! :slightly_smiling_face:
Also das überlasse ich gerne dem potenziellem Fahrer

**2026-01-14T14:40:17.934759** - Julia:
> ja super, das machen wir

**2026-01-14T14:40:40.355749** - Julia:
> ich finds so wild :smile:

**2026-01-14T14:56:30.172649** - Julia:
> juhuu danke!

**2026-01-14T15:03:02.828909** - Julia:
> mega gut, vielen dank!

**2026-01-14T15:28:49.080199** - Julia:
> FYI ich mach kurz einen Walk und laufe ho zur Isar. Ich schau wo wo am besten drehen könnten 

**2026-01-14T16:50:35.497849** - Julia:
> Ne ich auch nicht

**2026-01-14T16:56:58.824869** - Julia:
> neeein was ist das für ein name :smile:

**2026-01-14T16:57:28.288199** - Julia:
> okay! dann sehen wir uns morgen im büro :slightly_smiling_face:
Hab jetzt auch noch einen Termin mit Flo und danach Feierabend. Muss morgen leider auch was für sixt machen

**2026-01-14T17:55:47.377309** - Julia:
> FYI hahaha

**2026-01-15T08:42:37.757779** - Julia:
> Hello! Jeeein, brauche deshalb auch gerade noch länger beim fertig machen haha 
Ich komme so gegen 10.30 :) 
Freu mich! 

**2026-01-15T09:30:11.314029** - Julia:
> Bin auch unterwegs. Brauch ja aber eine std :stuck_out_tongue_winking_eye:

**2026-01-15T10:34:24.870239** - Julia:
> Maisonette finde ich super
Marcel joooa :smile:

**2026-01-15T11:05:32.481689** - Julia:
> wer ist Jan nochmal? der organisiert Events usw. oder?

**2026-01-15T11:06:36.296869** - Julia:
> ja genau

**2026-01-15T11:36:45.847599** - Julia:
> 

**2026-01-15T15:21:48.749579** - Julia:
> dankeee

**2026-01-15T18:36:40.949129** - Julia:
> Wenn euch noch was anderes einfällt für DE vs. ESP, gebt gerne Bescheid :smile:
Lebensmittel sind halt am einfachsten

**2026-01-16T08:05:38.494189** - Julia:
> haha nice! ich erstelle noch 2-3 und schicke es dann nochmal hier rein <@U093J779DAQ> :slightly_smiling_face:

**2026-01-16T09:31:20.146079** - Julia:
> there you gooo

**2026-01-16T15:22:16.356009** - Julia:
> <@U093J779DAQ> ich würde die Videosnippets hochladen und die grobe Reihenfolge in asana packen. Magst du dann das Briefing schreiben bzw. an Peru übergeben? 

**2026-01-19T09:09:59.845719** - Julia:
> Hello! Wir haben eben gesehen, dass es einen Kommentar von Laureen zum heutigen Hisense Video gibt. Deshalb tauschen wir das von mittwoch auf heute :slightly_smiling_face:

**2026-01-19T09:13:36.054379** - Julia:
> genau

**2026-01-19T09:13:55.513539** - Julia:
> und generell gehen wir den plan gerade durch: Was hältst du davon, wenn wir posts am Wochenende immer auf Sonntag 11 Uhr legen. Dann kann Mert sich das blocken und wir vergessen es nicht.
Hatten nämlich samstags jetzt übersehen

**2026-01-19T15:25:39.645139** - Julia:
> Ja voll gut, danke! 

**2026-01-20T09:26:57.126809** - Julia:
> Hallo :) wir machen quasi auch ein Software Update - Frühstück geskippt und die std länger geschlafen :smile: glaube wir beide sind richtig richtig erledigt. 
Bei dir?

Machen uns jetzt langsam ready und setzen uns dann in die Lobby und bearbeiten die Videos. 

**2026-01-20T10:35:03.110799** - Julia:
> wären hier, wenn du auch Zeit hast :slightly_smiling_face:

**2026-01-20T11:47:58.436099** - Julia:
> das ist die instagram version, bezüglich sound

**2026-01-20T11:48:25.372659** - Julia:
> es gibt nicht so viel auswahl leider

**2026-01-20T12:04:43.272049** - Julia:
> ja genau wir brauchen 2 Versionen bezüglich Sound pro Plattform.
Echt? krass ist schon auf 50% aber kanns noch leiser machen. Schicke es dir hier gleich rein, dann kannst du das schon mal in den Redaktionsplan legen

**2026-01-20T12:10:53.507839** - Julia:
> IG Version (Bildschirmaufnahme bezüglich Sound)

**2026-01-20T12:12:42.276649** - Julia:
> jaa löschen oder?

**2026-01-20T12:17:34.296999** - Julia:
> ah oder so. dankee

**2026-01-20T12:32:32.758259** - Julia:
> hier die TikTok Version von "Sollen wir"

**2026-01-20T12:57:17.802489** - Julia:
> hier die "The sign" videos als Bildschirmaufnahmen

**2026-01-20T13:03:46.478169** - Julia:
> würden dann jetzt mal kurz in die Stadt und was zum Essen suchen. sind danach wieder am laptop :slightly_smiling_face:

**2026-01-20T13:34:28.941579** - Julia:
> Danke! 

**2026-01-20T14:00:54.234499** - Julia:
> sind wieder da

**2026-01-20T14:02:04.702799** - Julia:
> Okee. Wir machen jetzt mal mit LIDL weiter

**2026-01-20T14:27:24.116119** - Julia:
> <@U08V6A47PKN> sollen wir die Belege nach Datum sortieren oder ist das egal?

**2026-01-20T14:34:26.423269** - Julia:
> Habs kurz in Asana, was von meiner Seite schon fertig ist :slightly_smiling_face:
von Flo's KK haben wir nichts bezahlt

**2026-01-20T14:34:49.234539** - Julia:
> <https://app.asana.com/1/1199360402832734/project/1212808160983275/task/1212877115931020?focus=true>

**2026-01-20T14:38:55.957039** - Julia:
> Oh nein, was ist passiert? :sleepy:

**2026-01-20T14:45:27.773809** - Julia:
> der Arme, ohjee

**2026-01-20T15:18:57.087529** - Julia:
> yaaay, ich poste jetzt mal

**2026-01-20T15:29:04.097139** - Julia:
> beide online!

**2026-01-20T16:16:18.512669** - Julia:
> fahren jetzt zum Flugiiii

**2026-01-21T16:17:14.991219** - Julia:
> FYI <@U08V6A47PKN> falls du morgen wieder da wärst:
Habe den *Hisense Redaktionsplan* für diese Woche angepasst. Habs allerdings noch nicht mit der Monatsübersicht verlinkt/ angepasst
• _Mittwoch/ heute: Couple Video_
• _Donnerstag: Facemorphing_
• _Freitag evtl je nach Bearbeitung von Peru: Wohin der Wind.._
cc <@U093J779DAQ>

**2026-01-21T17:04:01.007269** - Julia:
> Also das nächste Handball DE Spiel ist morgen Nachmittag :sweat_smile: yay

**2026-01-21T19:09:51.297249** - Julia:
> ja lass gerne mal schauen was Ray sagt.. evtl. ist es dann ja eh zu spät. aber so wie ich sie einschätze, ist es ihnen auch egal

**2026-01-21T19:10:01.129969** - Julia:
> Ich bin morgen ab 10.30 am Laptop btw :slightly_smiling_face:

**2026-01-22T11:17:58.959829** - Julia:
> die 2 sind so sweet

**2026-01-22T11:28:25.169119** - Julia:
> Meeting Notizen:
• IG Highlights EHF Euro 2026 erstellen (Asana Task tbd.)
• generell: IG Highlights erstellen mit Icons —> 1-2 Varianten schien (Asana Task tbd.)
• FYI: Collab-Reels mit Imke: nur ein paar, deshalb nicht wundern
Dringende To-Do heute:
• Interview Video fertigstellen --> heute schon schicken, wenn möglich (Mert)
• 3 Dips VoiceOver aufnehmen (Juli) :white_check_mark:
• 2x Feedback Peru (Juli) :white_check_mark:
• 2x Lidl Videos fertig stellen (Mert) 

**2026-01-22T13:20:34.430219** - Julia:
> <@U093J779DAQ> Reminder: noch das Hisense Video posten heute :slightly_smiling_face:
<https://docs.google.com/spreadsheets/d/1VYT-H11Hjf0aetErKOVdDvb5MmLnQegQIOa1oICnApQ/edit?gid=1767979417#gid=1767979417>

**2026-01-23T08:35:52.971079** - Julia:
> Hello! FYI: ich bin heute morgen bei der Physio 

**2026-01-23T10:57:21.726089** - Julia:
> Gorenje "The Sign" ist auf TT &amp; IG geposted :slightly_smiling_face:

**2026-01-26T09:11:52.400789** - Julia:
> Hello! Happy Monday :face_with_hand_over_mouth: Gut und dir? 

**2026-01-26T09:29:06.954399** - Julia:
> Oh wahnsinn.. Aber nur Magen oder dann auch das komplette Erkältungsprogramm?

**2026-01-26T09:29:33.308809** - Julia:
> Nee denke die kann man einfach löschen

**2026-01-26T09:29:56.685889** - Julia:
> :100: Woll ma nach Herning?

**2026-01-26T09:36:42.908609** - Julia:
> :100: JAAA

**2026-01-26T09:36:46.916969** - Julia:
> Flo hat den Chat verlassen

**2026-01-26T09:37:14.788359** - Julia:
> Ja das ist gut. Ein paar Standard nachrichten aufsetzen

**2026-01-26T09:51:25.444749** - Julia:
> Oh neeein :face_with_spiral_eyes:

**2026-01-26T09:51:37.921949** - Julia:
> same

**2026-01-26T09:51:59.666199** - Julia:
> also ich wäre ready falls ihr jetzt schon sprechen wollt

**2026-01-26T11:15:38.777579** - Julia:
> Dienstag bin ich nicht in München

**2026-01-26T11:32:10.830149** - Julia:
> War auch sehr happy :smile:

**2026-01-26T11:32:17.256969** - Julia:
> Bin gespannt ob und wie sie die Videos zeigen

**2026-01-26T12:02:33.716039** - Julia:
> ich auch :smile:

**2026-01-26T13:38:38.406109** - Julia:
> 

**2026-01-26T13:39:06.752329** - Julia:
> :smile:

**2026-01-26T13:46:23.884139** - Julia:
> gerne :smile: sitze noch drin

**2026-01-26T14:21:05.516419** - Julia:
> Muss jetzt ganz dringend was essen &amp; mit Coco raus. Aber nur kurz:

**2026-01-26T14:22:39.775939** - Julia:
> 

**2026-01-26T14:30:16.390739** - Julia:
> ja schon eher verloren

**2026-01-26T14:31:02.819029** - Julia:
> ja das sowieso! aber auch generell: ich hab von anfang an gesagt "kühltasche" ist nicht so passend zur community/ Gen z. Keine Reaktion :smile:

**2026-01-26T14:31:04.248439** - Julia:
> NAJA

**2026-01-26T14:47:29.350349** - Julia:
> Aber da sieht man ja genau das generelle Thema wieder: wollen eine coole junge Agentur sein mit all hands Mentalität und setzen es dann aber nicht um. Man könnte doch bei den 10 Leuten wie wir sind von jedem mal eine Idee pitchen lassen und eben die Zielgruppe sprechen lassen 

**2026-01-26T15:46:47.154369** - Julia:
> zu Niku's Mail: es gibt kein Intro oder :smile:

**2026-01-26T16:14:01.349719** - Julia:
> "dafür waren wir leider noch nicht zuständig"

**2026-01-26T16:14:29.284729** - Julia:
> ja, weil wir das bei "unseren" Videos auch nicht mit dem TT TN machen

**2026-01-26T16:37:03.258769** - Julia:
> Scheiße, schnell Wärme draufpacken!

**2026-01-26T16:47:00.511399** - Julia H. mentioned Julia:
> Ich bin jetzt auch mit meinen Sachen durch. <@U09D64LA420> brauchst du noch irgendwo hilfe?

**2026-01-26T16:47:40.962609** - Julia:
> Gute Besserung! :bouquet:

**2026-01-26T16:47:51.351889** - Julia:
> Ne danke, sitze an SIXT und Decathlon, das wird noch bissl dauern

**2026-01-26T16:48:00.127629** - Julia:
> aber dann bis morgen :slightly_smiling_face:

**2026-01-26T18:37:58.977549** - Julia:
> <https://www.tiktok.com/@adicindrea/video/7571488271394540822?_r=1&amp;_t=ZG-93OoH6N6IwC>

das hier als Trend Video für HiGo? Vllt fällt uns ja eine schnelle Aufnahme/ Story ein?

**2026-01-26T18:38:24.252909** - Julia:
> "Fehlermeldung am TV, Akku leer bei Gerät XY..." sowas?

**2026-01-27T08:56:13.524119** - Julia:
> GuMo! Alles klar :slightly_smiling_face: Ich muss heute bis Nachmittags erstmal komplett Sixt machen

**2026-01-27T09:02:22.750359** - Julia:
> Gehts dir besser?

**2026-01-27T09:02:27.249429** - Julia:
> Nö :smile:

**2026-01-27T09:03:55.031449** - Julia:
> sehr guuut

**2026-01-27T09:05:09.579129** - Julia:
> Ne die hatten eine Idee für eine "Kampagne" und das soll Ende März fertig sein – Drehort: USA. Aber weder Produktionsfirma noch irgendwas geschweigedenn die Idee an sich sind final :smile:
"Juli mach mal"

Und das beste: der Ton bei SIXT ist "JETZT hab ich gesagt"
lieben wir

**2026-01-27T09:07:54.124019** - Julia:
> ich wusste schon, warum ich da nicht reinwill :smile:

**2026-01-27T09:14:21.164489** - Julia:
> hahahaha ja

**2026-01-27T09:51:10.945379** - Julia:
> Übrigens: wollte ich gestern noch erzählen aber vergessen. Coco wird am Donnerstag morgen operiert und das wird ein krasser Eingriff :pensive: Je nachdem wann wir sie abholen können etc. bin ich Donnerstag evtl nicht zu 100% da

**2026-01-27T10:45:42.515579** - Julia:
> dankeee :face_holding_back_tears:

**2026-01-27T11:23:35.620059** - Julia:
> leider neeein

**2026-01-27T12:41:07.280219** - Julia:
> also ich hab super viele Tasks für Freitag bekommen (viel AI, was einfach immer lange dauert). Ich bin mir nicht sicher, ob ich diese Tasks hier gerade schaffe:
<https://app.asana.com/1/1199360402832734/project/1212808160983275/task/1212807852658838?focus=true>
<https://app.asana.com/1/1199360402832734/project/1211206795229799/task/1212974690939830?focus=true>
<@U093J779DAQ> wenn du Kapa hast...?

Fifa würde ich mir für später noch mitnehmen

**2026-01-27T12:50:36.391189** - Julia:
> glaube das bringt nicht viel. sehen wir ja jetzt schon. der ist dann eher der meinung ich soll schneller machen

**2026-01-27T12:50:53.517869** - Julia:
> aber wie gesagt, sobald Marvin weg ist, kann ich euch schon sagen, dass ich nur noch sixt machen werde weil wie soll das sonst gehen

**2026-01-27T12:52:23.833819** - Julia:
> ja same

**2026-01-27T12:52:44.345359** - Julia:
> und dann muss Mert nur editing machen für LIDL und Gorenje, weil er DAS Peru nicht zutraut :smile:

**2026-01-27T12:52:52.099989** - Julia:
> hööör auf. um was geht es dieses mal?

**2026-01-27T13:04:36.111709** - Julia:
> soviel dazu :smile:

**2026-01-27T13:20:16.563039** - Julia:
> :heart:

**2026-01-27T14:40:53.332579** - Julia:
> das ist so doof...

**2026-01-27T14:41:06.368659** - Julia:
> hab die kurz eine DM geschickt wegen einer Task in the future

**2026-01-28T09:05:01.642579** - Julia:
> Hello! :slightly_smiling_face: Alles oke und bei dir?

**2026-01-28T09:53:36.089659** - Julia:
> Nee..

**2026-01-28T09:53:45.311639** - Julia:
> die Kommunikation lieben wir

**2026-01-28T12:36:38.847049** - Julia:
> wie läufts bei euch?

**2026-01-28T12:36:45.675189** - Julia:
> ich werfe gleich das Handtuch, das sag ich euch :smile:

**2026-01-28T13:01:34.901029** - Julia:
> Ne alles gut aber ich spielen sich Dramen ab, das könnt ihr euch nicht vorstellen

**2026-01-28T13:28:16.241289** - Julia:
> Huddle? :joy:

**2026-01-28T13:42:21.607959** - Julia:
> nooow

**2026-01-29T09:10:12.514209** - Julia:
> Hello! Liebe das Orakel :heart_eyes:

**2026-01-29T11:02:49.234039** - Julia:
> komme nicht rein?

**2026-01-29T11:03:34.350419** - Julia:
> okee. bei mir hängt es generell merke ich :smile:

**2026-01-29T11:04:22.801329** - Julia H. mentioned Julia:
> Hello ihr beiden, hier nochmal kurz aufgelistet die größeren Tasks für HiGo und damit wir sehen wir wir uns aufteilen. <@U09D64LA420> hast du Zeit für grobe Review?
• Hisense FiFa Präsi finalisieren (sollte morgen rausgehen im best case) 
• Gorenje SoMe Strategy Paper für Insta aufsetzen (Versand/Vorstellung Anfang next week)
• Creator Briefing für Miriel finalisieren --&gt; Ich kann den aktuellen Stand mal mit Laureen besprechen, damit die Hard Facts auch alle stimmen
• CM Guidelines bin ich dran

**2026-01-29T11:05:36.554009** - Julia:
> yes mache ich. Morgen kann ich auch wieder etwas Zeit für Hisense blocken (wenn Flo heute mit der SIXT Präsi happy ist) besprechen diese um 16Uhr

**2026-01-29T12:17:51.064039** - Julia:
> happy lunch

**2026-01-29T12:18:13.829229** - Julia:
> Wir müssen heute zwischen 14-16 Uhr Coco abholen. Kann aber auch sein, dass alles schneller geht :face_with_peeking_eye:

**2026-01-29T12:19:11.268329** - Julia:
> jaaa, hoffe ich auch :face_holding_back_tears:

**2026-01-29T12:43:32.478769** - Julia:
> ja

**2026-01-29T12:43:39.875859** - Julia:
> wäre ja auch voll cool, wenn das klappt und zündet :slightly_smiling_face:

**2026-01-29T12:58:11.036389** - Julia:
> was ich grad so mache: :smile:

**2026-01-29T12:59:29.978049** - Julia:
> :joy:

**2026-01-29T13:10:01.727979** - Julia:
> FYI - Moni hat mir die Auslagen nochmal zurückgeschickt weil die Google Umrechnung anders ist :smile:

**2026-01-29T13:20:53.992489** - Julia:
> find die süß :smile:

**2026-01-29T14:00:39.209289** - Julia:
> find ich sehr cool! :slightly_smiling_face:
• Sollen wir auch noch aufnehmen, dass wir auch direkt individuell und witzig auf Kommentare antworten und hier Beispiele reinpacken wie zB?
<https://www.tiktok.com/@sixt/video/7593041782905031969>

• Ich glaube wir sollten noch eine Slide hinzufügen mit Antwortmöglichkeiten mit GIF's. Das was LIDL, SIXT usw. so gut machen. Da hat Flo immer was in den Pitch Unterlagen, will er sicherlich mit drin haben


**2026-01-29T14:00:58.429219** - Julia:
> ah hier sagst du es :)

**2026-01-29T14:01:50.020059** - Julia:
> Ja seh ich auch so! Vllt könnte sie da sowas machen wie "Wenn Gorenje in deine DM's slidet" oder cooler :smile:

**2026-01-29T14:02:11.500649** - Julia:
> Moods braucht es eigentlich nichtmehr, weil wir ja wissen wie ihre Küche aussehen soll etc.?

**2026-01-29T14:06:58.823469** - Julia:
> danke DIR!

**2026-01-29T14:09:37.975379** - Julia:
> hab nur diese Slide gefunden. Flo müsste da noch viel aktuellere haben

**2026-01-29T14:10:26.802879** - Julia:
> Sollen die Fragenkataloge dann eigentlich auch von Laureen und Team befüllt werden?

**2026-01-29T14:16:50.092599** - Julia:
> genau. okay verstanden

**2026-01-29T14:17:46.861969** - Julia:
> Kriegen wir hin.
Also laut Jana muss ich noch EINIGES für morgen machen. Aber hab auch Meeting um 16Uhr mit Flo, dann weiß ich mehr, wieviel ich morgen noch für SIXT machen muss.
Sonst kann ich morgen Mini machen und Gorenje starten :slightly_smiling_face:

**2026-01-29T14:20:58.637259** - Mert Koc mentioned Julia:
> Ich fange schon mal an, die Folien einzufügen und du kannst dann rauskicken &amp; sortieren <@U09D64LA420>
Das sollte dann wenigstens Arbeit abnehmen hoffe ich mal

**2026-01-29T14:21:40.570589** - Julia:
> true that

**2026-01-29T14:21:49.544749** - Julia:
> liebs wie jeder Kunde so seine Eigenheiten hat

**2026-01-29T14:27:16.155259** - Julia:
> niiice :slightly_smiling_face:

**2026-01-29T14:27:22.960379** - Julia:
> Muss jetzt die Maus abholen, bis später!

**2026-01-29T16:11:38.843979** - Julia:
> lieb ich auch – sitzen im meeting und Flo sagt "ja jetzt präsentiert die Präsi so wie es in reallife wäre", wollten sie jetzt eigentlich erstmal durchsprechen.
Weder Marvin und ich kennen die Präsentation :smile:

**2026-01-29T16:12:23.484779** - Julia:
> also unsere Ideen schon aber den Rest nicht :smile:

**2026-01-29T16:41:22.093719** - Julia:
> Happy feierabend! Du bist morgen off oder? :slightly_smiling_face:

**2026-01-29T17:16:47.520319** - Julia:
> also ich muss morgen noch eiiiniges für die Präsi machen :zany_face:

**2026-01-29T17:52:01.559339** - Julia:
> Ne.. aber ich werd morgen Gorenje eher nicht schaffen, ich versuchs Montag direkt

**2026-01-30T10:02:11.102339** - Julia:
> Guten Morgen! Anna hat mich 4x grad gefragt, wie und wo sie unterstützen kann. Leider macht das bei mir gerade keinen Sinn. <@U093J779DAQ> ich hab jetzt gesagt, sie soll sich sonst mal bei dir melden bezüglich der Content Ideen für IG Gorenje – glaube das wäre was für sie!

**2026-01-30T10:16:17.076919** - Julia:
> ah cool!

**2026-01-30T19:04:57.805769** - Julia:
> Also ihr Lieben, kurzes Update von mir: heute war ein geisteskranker Tag und ich hab Flo das auch so kommuniziert. Er zeigt dann schon Einsicht und sagt auch "Gesundheit (von mir oder Tier) ist das wichtigste" aber er erwartet ja trotzdem alles.
Damit ihr wisst was nächste Woche alles ansteht und wann ihr mich einplanen könnt (Mittwoch..)

Montag:
• Decathlon Präsentation Rehearsal
• MINI finalisieren
• SIXT Workshop am Nachmittag vor Ort
Dienstag:
• fahren um 11 Uhr los nach Stuttgart
• auf der Hin-&amp; Rückfahrt will Flo, dass wir MINI finalisieren
• Decathlon Präsentation vor Ort
Mittwoch:
• bin ich tot und ciao

Happy feierabend und ein schönes Wochenende! :heart:

**2026-02-02T09:12:17.961769** - Julia:
> hello! :slightly_smiling_face: ich komm kurz rein, damit ich wenigstens up to date bin!

**2026-02-02T09:12:22.561889** - Julia:
> 9.30 oder 9.15?

**2026-02-02T09:15:29.572499** - Julia:
> Okee :slightly_smiling_face:

**2026-02-02T10:29:00.395979** - Julia:
> AHJA

**2026-02-02T11:50:27.422549** - Julia:
> Okay Update:

**2026-02-02T11:51:40.986369** - Julia:
> 

**2026-02-02T11:58:10.691849** - Julia:
> o-Ton: Mit so einer Präsentation können wir nicht zu SIXT

**2026-02-02T11:58:12.255539** - Julia:
> ups

**2026-02-02T12:07:09.602509** - Julia:
> :smile:

**2026-02-02T12:08:43.979529** - Julia:
> wahnsinn oder

**2026-02-02T13:23:46.811249** - Julia:
> an sich find ichs gut. Flo findet die aber gut so wie sie ist :smile:

**2026-02-02T14:34:20.478499** - Julia:
> Die Aufgabe war die slides einheitlich zu machen. Das ist das Ergebnis. Also sorry, wenn sie dafür wirklich bezahlt wird, streike ich :smile:

**2026-02-02T17:48:34.623039** - Julia:
> Bin am Heimweg :melting_face: ne war voll okay. Der workload dann wird krass aber das ist nochmal ein anderes Thema 

**2026-02-02T17:49:17.723859** - Julia:
> Hab jetzt erfahren, dass ich Mittwoch beim Mini pitch auch dabei bin und präsentieren soll. Also bin ich Mittwoch wahrscheinlich auch eher raus 

**2026-02-02T17:50:28.005349** - Julia:
> Und noch als Info: ich Sitz ja morgen mit Flo und Alex im Auto und nebeneinander. Da sollten wir aufpassen was wir schreiben haha

**2026-02-02T17:59:56.486179** - Julia:
> 

**2026-02-03T09:09:32.673459** - Julia:
> Hello! Yes, hatte Katharina gestern auch kurz gesagt. Ist das schon mit Konzept? Ich dachte erstmal kurz kennenlernen und Timings besprechen :face_with_spiral_eyes:

**2026-02-03T09:10:15.706499** - Julia:
> ja alles schaff ich nicht, muss für SIXT auch noch 2 visuelle Sachen diese Woche machen, irgendwie

**2026-02-03T09:14:05.879949** - Julia:
> dankeee, bin sehr gespannt!!

**2026-02-03T09:17:52.420069** - Julia:
> Bzw. ich schau mir das morgen dann morgens an, evtl. ist es ja doch machbar. Für Flo ist es eh machbar :smile:

**2026-02-03T09:33:24.124519** - Julia:
> dann müssen wir es wohl schaffen

**2026-02-03T09:33:56.506969** - Julia:
> ne es bringt bei Flo nichts, ich sag täglich was – er sagt ja dann auch immer "das Visual erstellen dauert 5 Minuten"

**2026-02-03T09:35:39.877429** - Julia:
> Also Marvin ist morgen auch erst wieder mittags/ nachmittags daheim, der bleibt ja über nacht. Dann arbeiten wir morgen ab 15/16 Uhr dran, wird schon klappen

**2026-02-03T09:39:27.368369** - Julia:
> :crossed_fingers: bin gespannt!

**2026-02-03T16:54:14.252089** - Julia:
> Sooo pitch war sehr gut! Und der Kunde ist auch Zucker, also wirklich! :)

**2026-02-03T16:54:21.427019** - Julia:
> Fahren jetzt zurück 

**2026-02-03T16:54:27.530709** - Julia:
> Happy Feierabend :heart_hands:

**2026-02-09T08:41:50.053459** - Julia H. mentioned Julia:
> Good morning ihr beiden
<@U09D64LA420> ich hoffe du bist wieder gesund? 
<@U093J779DAQ> Logo kein Problem für mich 

**2026-02-09T09:37:11.443999** - Julia:
> Guten Morgen! :heart_hands: An sich geht's mir etwas besser, aber was für Tage :woozy_face: mich hat's wieder richtig zerlegt. Hab jetzt wieder den krassen Husten.. Ich Versuch gerade meinen Arzt zu erreichen wegen der Ergebnisse aber bisher keine Antwort. 
Also ich bin gerade auf jeden Fall noch raus, sonst zieht sich das alles noch länger :sneezing_face:

**2026-02-09T11:21:04.321289** - Julia:
> Danke euch. tut mir leid, dass ich gerade so ausfalle

**2026-02-13T09:04:46.395709** - Julia:
> Hello! :slightly_smiling_face: Hoffe euch gehts soweit guut

**2026-02-13T09:05:14.549779** - Julia:
> Wollte auch nur Bescheid geben, ich bin ab Montag wieder voll da. Heute werden Marvin und ich eine Übergabe oÄ machen

**2026-02-13T09:05:24.294099** - Julia:
> Und ich hab am Dienstag tatsächlich Urlaub schon mal FYI

**2026-02-16T09:00:45.340499** - Julia H. mentioned Julia:
> <@U09D64LA420> bist du wieder fit?

**2026-02-16T09:01:46.050609** - Julia:
> Guten Morgen! :slightly_smiling_face: Ja besser, danke! Ich bin heute wieder da

**2026-02-16T09:02:30.770019** - Julia:
> ich hab allerdings um 10 Uhr montags jetzt immer SIXT (wegen unserem Termin) und ich komme wahrscheinlich ein paar Minuten später zum Cloud Studio. Würde ich Laureen auch kurz schreiben. Denke um 11.15 bin ich sicher da

**2026-02-16T09:02:49.894949** - Julia:
> Wie war deins?? :slightly_smiling_face: So sunny oder?

**2026-02-16T09:06:12.795419** - Julia:
> wegen mir gerne! so in 15 Min? :slightly_smiling_face:

**2026-02-16T09:22:36.218819** - Julia:
> bin drin :slightly_smiling_face:

**2026-02-16T09:53:11.332569** - Julia:
> <https://docs.google.com/spreadsheets/d/16asKjHfqeoKWliec5qV0cUYJ82Q59G8aj9Bd5QAsThM/edit?gid=1810259804#gid=1810259804>

**2026-02-16T15:50:37.416149** - Julia:
> jaaa voll!
<@U08V6A47PKN> Mert und ich haben kurz geredet und das wäre vom Aufwand echt am einfachsten für uns

**2026-02-16T16:03:03.722079** - Julia:
> ja genau. Hatte Mert grad auch schon gesagt, dass David und sein Kumpel zB grad voll abgehen auf TikTok – da hätten wir halt gleich welche, die auch sowas mitmachen

**2026-02-16T16:46:11.590759** - Julia:
> wäre für 1.2!

**2026-02-16T17:39:50.334839** - Julia:
> Welche Teaser meinst du? :smile: sorry bin bissl raus

**2026-02-16T17:40:00.761579** - Julia:
> ja ich auch nicht!

**2026-02-16T17:42:29.525929** - Julia:
> Asooo. Ja finds nicht optimal aber wir könnten den "Soon" Post ja fixieren? Dann ist es etwas gesondert


---

### #moving-forward (3 messages)

**2025-11-27T17:28:35.391059** - Julia:
> <@U09D64LA420> has joined the channel

**2025-11-27T17:31:20.235399** - Julia:
> Hi everyone :slightly_smiling_face:

As mentioned, improving the collaboration and efficiency between Germany and Peru is a top priority for me.
After speaking with several of you, I believe we should use our call on *3 December* as a real reset and a fresh start.

In this alignment call, I want us to:
&gt; • Listen to each other openly
&gt; • Address what hasn’t worked
&gt; • Agree on clear solutions and next steps

*For the call, I need from you (by Tuesday (2nd) evening):*
1. A *list* of what *_hasn’t_ worked well* in the past
2. For each point in that list: a concrete proposal on *how to fix/ improve* it
3. *Your wish/vision* for how the collaboration should work in 2026

I’ll use your input to create a focused agenda for the call.
This alignment will be the basis for a larger workshop in the next 2–3 weeks, where we’ll define how we work together in 2026.

The timing is perfect: right now we have a bit more capacity before a busy December, especially with Hisense &amp; Gorenje. Let’s use this window to set ourselves up properly.

In the call will be:
<@U08UAJ393T9> / Project manager :flag-pe:
<@U045Z7ZCZRN> / Creative lead :flag-pe:
<@U0929T1BG0G> / Creative lead :de:
<@U093J779DAQ> / Creative for Hisense &amp; Gorenje :de:

Thanks in advance for your input :raised_hands:

**2025-11-27T17:34:09.060029** - Julia:
> <@U09D64LA420> has left the channel


---

### #mpdm-florian--anna--julia.hopper-1 (4 messages)

**2025-11-14T16:32:30.331309** - Julia:
> Hi Anna, schön dich kennenzulernen! :slightly_smiling_face: Danke dir

**2025-11-14T17:09:36.696489** - Julia:
> yes, ich schau es mir an und melde mich!

**2025-11-14T17:09:37.864409** - Julia:
> dankee dir

**2025-11-17T11:27:56.029549** - Julia:
> Hello Anna! :slightly_smiling_face: Nein garnicht, sind schon sehr coole Gedanken und Dialoge dabei. Vielen dank dir! Ich habe die Texte noch etwas ausformuliert FYI:


---

### #mpdm-florian--jana--julia.hopper--marvin-1 (59 messages)

**2025-10-30T10:06:26.566959** - Florian Listl mentioned Julia:
> Liebe Juli, liebe Jana,
ihr solltet euch kennenlernen!
<@U0994RLAGHW> ist aktuell noch für Hisense zuständig und wird das Projekt an dich <@U09D64LA420> übergeben.
Bitte macht einen Termin aus, zB. morgen 16:30 oder Montag Vormittag, ich joine auch um etwas kontext zu geben.

<@U0994RLAGHW> bitte bereite dafür ein Übergabe Dokument vor und next steps, die mit anderen Stakeholdern wie Basti besprochen werden sollen.

Am Mittwoch stellen wir das neue Team dem Kunden im JFX vor

**2025-10-30T11:23:37.332519** - Julia:
> Hi! Super, danke fürs Connecten! Ich erstelle gerade einen Fragenkatalog und schicke ihn asap hier rein. <@U0994RLAGHW> wäre super, wenn wir diese Fragen dann beantworten können :slightly_smiling_face:
Terminlich richte ich mich nach euch

**2025-10-30T11:25:27.204149** - Jana Kordt mentioned Julia:
> Hi <@U09D64LA420> - freut mich sehr! 
Yes, das packe ich dann alles in die Übergabe. 
Wir haben auch schon einige Deadlines Ende nächster Woche und einige Shootings im November. 
Wie passt es morgen zwischen 12-14?

**2025-10-30T13:19:07.874599** - Julia:
> Hier schon mal ein paar Fragen/ offene Punkte – wenn du noch mehr hast <@U0994RLAGHW> sehr gerne her damit :slightly_smiling_face:

*Abstimmung mit Kunden:*
1. AP's Rollen und Responsibilities
2. Meetingstruktur?
3. Produktschulung/Infos? Wer gibt Produkte vor?
4. Bestimmte Themen vorgegeben oder werden die gepitcht?
5. Abläufe Produktionen/Absimmung/Freigaben/Feedbackprozesse
6. Feste Anzahl Iterationen?
*Generell:*
1. Verteilung Budget: Paid/Organic/Produktion
2. Redaktions- und Kampagnenplan
3. Übergabe-Sheet mit AP, Zugängen, Ablage/Drive
*Tools + Content:*
1. Gesamtstrategie für Kanäle/ Ziele?
2. Redaktions- und Kampagnenplan
3. CI - Vorlagen, Logos, Typos?
4. Werden Tools verwendet? (Reporting)
5. Community Management Guidelines/Vorgehen/ Vorlagen
6. Zugangsdaten für alle Unterlagen
7. Technisches Setup? Asana? Meta?
8. Reportings?
*Produktionen:*
1. Wie sehen die Produktionen aus?
2. Wo finden diese statt?
3. Wer sind die momentanen Testimonials?
4. Gibt es ein Standard-Team für die Umsetzung /Videografen?
5. UGC/ Influs/ Creator?

Der Zeitraum passt mir gut. Aber <@UNUQV5R08> du kannst da nicht, oder? Sonst direkt Montag? Würde Mert auch direkt mitnehmen in unser Meeting, damit er auch bestmöglich abgeholt ist :slightly_smiling_face:

**2025-10-30T14:14:32.784219** - Florian Listl mentioned Julia:
> dann macht ihr morgen direkt ein meeting und ich ergänze am montag 10 uhr <@U0994RLAGHW> <@U09D64LA420>

**2025-10-30T14:20:03.222809** - Julia:
> Alles klar. <@U0994RLAGHW> dann um 13Uhr? :slightly_smiling_face:

**2025-10-31T10:32:55.670029** - Jana Kordt mentioned Julia:
> <@U09D64LA420>  wir haben soooooo viele Sachen gerade bei SIXT reingekommen. Wäre es später auch noch denkbar? Ansonsten Montag. 

**2025-11-12T13:18:59.842819** - Julia:
> Hi Jana!
• Also Reporting Info ist im Übergabe Dokument, yes. Aber September und Oktober fehlen ja noch. Könnt ihr das noch hinzufügen bitte?
• CI haben wir jetzt die Hausschrift bekommen, sonst nichts. Gibt es da noch irgendwas?

**2025-11-12T13:23:09.389459** - Julia:
> Hi zusammen! :slightly_smiling_face:
Leider kommen wir mit dem Redaktionsplan nicht wirklich zurecht. Jana du hast uns ja vorher schon gesagt, dass es etwas durcheinander ist und daher wäre es super, wenn ihr uns noch etwas helfen könntet:
Bei manchen Videos ist ein M markiert – was bedeutet das?
Ab und an gibt es Kommentare in frame, aber nicht immer und die M's passen dann nicht dazu.

Es wäre super hilfreich, wenn wir uns im Redaktionsplan einmal bis zu KW41 (Stop der finalen Approvals) in grün markiert, welche Videos so raus gehen können. Dann wissen wir, der Rest muss ersetzt werden. Danke!

**2025-11-12T13:28:05.374159** - Julia:
> super, danke!

**2025-11-12T13:30:42.482329** - Julia:
> Direkt um 14.30 oder später? Ich kann leider nur bis 15Uhr. Julia H. könnte allerdings – oder morgen direkt?

**2025-11-12T14:30:46.009769** - Julia:
> okay

**2025-11-12T14:30:50.107189** - Julia:
> sonst morgen früh?

**2025-11-12T14:33:30.499019** - Julia:
> alles gut, ich verschiebs!

**2025-11-12T14:53:58.072769** - Jana Kordt mentioned Julia:
> <@U09D64LA420> Verifizierung sind wir ja schon durchgegangen. Hast du konkrete andere Fragen?

**2025-11-13T08:30:00.434829** - Jana Kordt mentioned Julia:
> Guten Morgen <@U09D64LA420> <@U093J779DAQ>
Gibt es einen Grund, warum ihr die Kampagne,  die wir angelegt haben, nicht ausgestellt habt?
Ich mein, ihr habt ja mehr Budget, das weiß ich nicht, aber wir sind jetzt bei 58K Views und 78€ Spend. Ich hab sie erstmal pausiert, aber sagt mir gern Bescheid.

**2025-11-13T09:04:48.947579** - Julia:
> Guten Morgen Jana, weil wir das schlichtweg vergessen haben. Danke für den Reminder.
Zugänge haben wir leider noch nicht, weil das bei Laureen nicht klappt. Wir haben es auf dem Schirm

**2025-11-13T09:16:50.751649** - Julia:
> <@UNUQV5R08> wir kommen da heute auch noch auf dich zu, sobald wir endlich den Zugang haben

**2025-11-18T10:51:22.841339** - Jana Kordt mentioned Julia:
> Guten Morgen. 
Ich sehe, dass ihr vor 3 Tagen das letzte Mal gepostet habt, dieser Beitrag ist aber immer noch nicht geboostet. 
Wir können nicht, ein Video 3 Tage auf 700 Views lassen. 
Könnt ihr euch das bitte ASAP anschauen? 

<@U09D64LA420> <@U093J779DAQ> 

**2025-11-18T11:00:03.134649** - Julia:
> Hi Jana, yes wir posten jetzt gleich und boosten direkt. Wir haben die neue Paid Strategie gestern mit Flo besprochen und setzen das direkt um

**2025-11-18T17:10:30.047169** - Julia:
> Du meinst das Bösewicht Video oder? Das ist jetzt in der neuen Kampagne mit drin und views bei 8K

**2026-01-07T13:53:00.486979** - Julia:
> Hi zusammen! :slightly_smiling_face: Ich hab morgen um 11 Uhr schon einen Paralleltermin mit Hisense/ Gorenje, der auch zum Start ins neue Jahr wichtig ist, dass ich dabei bin. Können wir unseren Termin verlegen? Heute nachmittag/ abends? oder morgen früh?

**2026-01-07T13:59:07.164879** - Julia:
> passt, ich bin flexibel und morgen nachmittags geht auch

**2026-01-07T14:00:29.319699** - Julia:
> danke!

**2026-01-29T14:39:01.035519** - Jana Kordt mentioned Julia:
> <@U05LQB4GTC1> <@U09D64LA420> ich glaube es reicht, wenn ihr einmal as Anfang die Ideen mit uns durch geht - Präsi mach ich dann mit Flo 

**2026-01-29T14:41:18.515249** - Jana Kordt mentioned Julia:
> Okay. Ich dachte, dann müssen die beiden keine Stunde aufbringen, sondern können ggfls lieber Anpassungen noch machen. Aber <@U09D64LA420> <@U05LQB4GTC1> passt es euch um 3?

**2026-01-29T15:50:56.631659** - Julia:
> Ich bin wieder da

**2026-01-29T17:22:31.775809** - Jana Kordt mentioned Julia:
> <@UNUQV5R08> ich schicke dir die fertige Präse dann morgen. 

<@U09D64LA420> bis wann kannst du die Anpassungen schicken? 

<@U05LQB4GTC1> bis wann Kannst du auf dem RSA Fragen-Asset rumdenken? 

**2026-01-29T17:38:28.474009** - Julia:
> same, ich versuchs möglich zu machen. aber müsste es sonst wie heute immer stück für stück nachliefern

**2026-01-30T09:55:56.102639** - Julia:
> Hello!
<@U0994RLAGHW> hier noch die textlichen Anpassungen für die jeweiligen Folien. Visuals leg ich in den Ordner mit heutigem Datum ab
• Slide Personality Change: Text oben hinzufügen: „Wir zeigen wie krass das Fahrerlebnis mit SIXT ist.“
• BEAT SIXT: FUN Säule | - „Trend“ unten raus
• Carpool: „deutsche“ raus
• Roast raus als Folie aber als Bsp. bei Carpool mit aufnehmen
• SIXT Pranked: passiv-aggressiv als letztes Beispiel rein | Text: „Brand Ambassador“ raus
• Dating Show: Text unten „Trendfaktor…“ anpassen zu: Reality TV als perfektes Serien Format —&gt; Spannungsaufbau!

**2026-01-30T09:56:48.480059** - Julia:
> <@UNUQV5R08> wie genau hast du dir bei  "Things you can say..." den Visual Aufbau vorgestellt?
Du meintest rechts immer das gleiche Bild..?

**2026-01-30T09:59:42.865929** - Florian Listl mentioned Julia:
> Genau, wir machen rechts das Bild groß und aus einer slide machen wir 5 oder 6 je nachdem wie viele Bilder es gibt.

Bei den 5-6 slides ist nur das Bild rechts unterschiedlich, Text links, Headline etc bleibt gleich.

Heisst für dich: Bitte einmal die Bilder in SIXT Schrift machen (frag gern Anna dafür), Text einfacher machen (bei der anfangs slide) und sonst musst du nur die Folien duplizieren und die neu erstellten Bilder groß machen.


Wenn du's delegierst ist das für dich in 5 min erledigt <@U09D64LA420> 
Nutz gern Anna, sie kann Photoshop; dafür haben wir sie

**2026-01-30T11:04:39.542029** - Julia:
> das sind die neuen Visuals

**2026-01-30T11:52:58.045449** - Julia:
> Hier noch die Ideen für die Reality shows, gerne als Subtexte unter die Visuals auf einer neuen Folie: <@U0994RLAGHW>

*Too hot to handle:*
Absolute Auto Fans in einer Villa … aber sie dürfen ihr Traumauto einfach nicht fahren.
• „Dir wurde ein kostenloses Upgrade angeboten … aber du darfst es nicht fahren.“
• Schlüssel hinter einer Glasbox wie ein Forbidden Object
-----
*Dschungelcamp:*
Celebs müssen Prüfungen bestehen, um am Ende lebenslang kostenlose SIXT-Fahrzeuge fahren zu dürfen.
• Prüfungen, um sich ein späteres Upgrade zu erspielen
• der berühmte Ruf wird geändert zu „I’m a celeb… get me a SIXT ride!"
• SIXT als Preis und als Rettung
----
*Are you the one?*
SIXT wird zum Matchmaker. Die Kandidat:innen müssen herausfinden: Welches Auto passt perfekt zu mir?
• jeder hat eine andere Vorliebe bei Autos “I’m a SUV girl” – stimmen diese?
• Challenges: “Earn your keys” Gewinner bekommen Hinweise (“Your match is electric.” / “Your match has a soft top.”)

<@U05LQB4GTC1> als Reality TV Profi – gerne drüberlesen :wink:

**2026-01-30T11:58:50.282119** - Julia:
> passt

**2026-01-30T12:00:49.948459** - Julia:
> • Ekelprüfungen indem sich die Autos Videos von Falscher Handhabung von Autos anschauen müssen etc.
--&gt; :smile: okay got it

**2026-01-30T12:01:16.040489** - Julia:
> will ich sehen

**2026-01-30T12:03:26.577469** - Julia:
> Visuals dazu sind fast fertig, Anna ersetzt kurz die SIXT Logo's mit den richtigen

**2026-01-30T13:18:59.168889** - Julia:
> sobald die abliegen gebe ich Bescheid 

**2026-01-30T13:38:48.258459** - Julia:
> <@U0994RLAGHW> die ersten Visuals liegen ab mit heutigem Datum
• LIB kommt noch
• Thumbnail/ Grid kommt noch


**2026-01-30T14:52:21.017439** - Julia:
> liegen ab <@U0994RLAGHW>

**2026-01-30T14:59:25.312989** - Julia:
> <@UNUQV5R08> hast du bei den Visuals mit heutigem Datum noch Änderungswünsche?
<https://drive.google.com/drive/folders/1aLCz7CZkdJOu_PQiBQh9GxUdMamSHJdt>

**2026-01-30T15:34:15.334189** - Florian Listl mentioned Julia:
> Kriegen wir vielleicht BMW statt VW bei den pods/ Blinker noch hin? <@U09D64LA420> 

**2026-01-30T15:37:36.721419** - Julia:
> <https://drive.google.com/drive/folders/1aLCz7CZkdJOu_PQiBQh9GxUdMamSHJdt>
Das ist das mit BWM. Oder welches meinst du?

**2026-02-02T12:45:25.852089** - Julia:
> ja same here!

**2026-02-02T12:45:47.665509** - Julia:
> "muss repariert werden" stand bei mir

**2026-02-02T12:49:56.215449** - Florian Listl mentioned Julia:
> <@U09D64LA420> dann steuerst du einfach die slides - weil ich hab gar keinen teil

**2026-02-02T12:51:39.335959** - Julia:
> Hmm ich weiß ja nicht genau wann Jana weiter klicken würde. Willst du mir dann ein Zeichen geben oder sagst du dann sowas wie "die nächste Slide"?

**2026-02-02T13:23:10.967899** - Julia:
> 3 kleine Sachen die mir aufgefallen sind <@U0994RLAGHW>
• Slide 19: Headline "wir zeigen wie krass..." sollte in den Text darunter und nicht in der Headline stehen
• Slide 22: Variante 2 bitte rausnehmen (Ride &amp; Roast lassen wir raus)
• Slide 23: da ich es im PDF nicht sehe: hier nur der Screenshot statt dem Video drin oder? Screenshot hatte ich dir abgelegt
Danke!

**2026-02-02T13:23:24.013189** - Julia:
> ich kenne mich da nicht aus..? Kriegen wir schon hin

**2026-02-02T13:39:44.398199** - Julia:
> hier ist nochmal das Still: <https://drive.google.com/drive/folders/1aLCz7CZkdJOu_PQiBQh9GxUdMamSHJdt>

**2026-02-02T13:42:05.025579** - Julia:
> Ne statt dem Video. Weil wir ja das passiv aggressive nicht in den Vordergrund packen wollen

**2026-02-02T13:44:02.227729** - Julia:
> Slide 23: "brand Ambassdor..." sollte auch raus

**2026-02-02T16:14:18.473459** - Jana Kordt mentioned Julia:
> Hier die To Dos, die sich von Katharina ergeben hat:

Love is Blind - weiter auskonziptionieren - <@U09D64LA420> <@U05LQB4GTC1> - bitte über SIXT ONE nachdenken, das Loyalty Programm

Carousel "Things you cant say/do" - bitte schon mal 5 Carousels fertig machen - <@U09D64LA420>

Schattenmenschen - startet heute, erste Serie - <@U0994RLAGHW> Abstimmung mit Romina zu Thumbnails

**2026-02-02T17:34:45.352239** - Florian Listl mentioned Julia:
> Danke, <@U09D64LA420> schickt email und ppt 

**2026-02-02T17:47:45.244649** - Julia:
> Yes, bin leider noch nicht daheim, dauert noch

**2026-02-03T16:56:46.600769** - Julia:
> Hello! Für AoN benötigen wir bitte noch die Moderatoren Liste, die schon mit SIXT besprochen wurde. Jana du hast diese oder? 

**2026-02-04T10:38:58.122029** - Jana Kordt mentioned Julia:
> <@U09D64LA420> hast du da jetzt alles ?

**2026-02-09T19:45:57.857249** - Florian Listl mentioned Julia:
> Hi Leute, lasst uns bitte einmal intern über die Daten sprechen. Das heißt vor allem paid IG.
Welche Zeit passt euch da Mittwoch? 15-30 min reichen <@U05LQB4GTC1> <@U09D64LA420> <@U0994RLAGHW> 

Am liebsten irgendwann von 9-13 Uhr Mittwochs 


---

### #mpdm-florian--jana--julia.hopper-1 (7 messages)

**2025-11-27T16:00:35.390119** - Jana Kordt mentioned Julia:
> Die Unterlagen hab ich bei Marvin angefragt. Bitte auch einmal auf dem Drive schauen <@U09D64LA420> 

**2025-11-27T17:42:18.374059** - Julia:
> da liegt leider nichts ab, außer 2 dokumente.  danke dir!

**2025-11-28T09:42:27.780979** - Jana Kordt mentioned Julia:
> <@U09D64LA420> welche weiteren Dokumente brauchst du denn? Zeitungsartikel sind ja Links?

**2025-11-28T09:43:25.193229** - Julia:
> wir brauchen eine AUflistung welche Artikel (egal ob PDF oder Links) ihr schon hochgeladen habt. wir haben ja hier garkeinen überblick

**2025-11-28T09:43:50.358889** - Julia:
> ja das sind litteraly 2 Dokumente?

**2025-11-28T09:44:31.327789** - Julia:
> Ich mach einen neuen Chat mit Mert auf, er übernimmt das Thema

**2025-11-28T09:44:56.628589** - Jana Kordt mentioned Julia:
> <@U09D64LA420> die Zeitungsartikel lädt man ja nicht runter, das sind Links. Eine Auflistung gibt es da nicht. 


---

### #mpdm-julia.hallhuber--florian--julia.hopper-1 (44 messages)

**2025-09-17T10:42:42.147769** - Julia:
> Hello! Bin an den Stories für Gobi – soll ich euch die Drafts immer erstmal hier rein schicken oder wie ist hier der Prozess? :slightly_smiling_face:

• 2 Alternativen für den Start
• würde die Verlinkung direkt machen
• Umfragesticker wie gewünscht 
• habe die Texte leicht angepasst

**2025-09-17T11:24:02.411559** - Julia:
> Ausgetauscht mit Kofferbild

**2025-09-17T11:42:32.907169** - Julia:
> Ah okay, schade. Mach ich. Soll ichs dann in die Whatsapp Gruppe schicken oder legst du das direkt in Sprinkler rein?

**2025-09-17T11:45:55.045709** - Julia:
> okay!

**2025-09-17T13:50:56.176589** - Julia:
> <@UNUQV5R08> kannst du kurz helfen? Das ist nur der normale Cayenne, oder?

**2025-09-18T11:22:32.310069** - Florian Listl mentioned Julia:
> <@U09D64LA420> ich hab dich hier auch mal eingeladen :slightly_smiling_face:

**2025-09-18T11:25:53.953219** - Julia:
> Ja perfekt, danke

**2025-09-18T16:53:50.693929** - Julia:
> Hilfe: ich weiß nicht, wo der Fehler ist aber bei jedem Ordner kommt diese Fehlermeldung...

**2025-09-18T17:00:48.258939** - Julia:
> nee.. seit heute morgen. Flo vllt ist das auch ein Bug mit der Mailadresse? :smile:

**2025-09-18T17:01:53.610639** - Julia:
> na toll, jedenfalls kann ich einfach nichts ablegen

**2025-09-18T17:03:45.807979** - Julia:
> yes und yes

**2025-09-19T09:57:30.360579** - Julia:
> Guten Morgen! <@UNUQV5R08> ich hab heute Hunde Dienst und bin deshalb im HO geblieben :smiling_face_with_tear:

Mir ist mein To Do hier noch nicht ganz klar – wollen wir das gleich im Meeting kurz besprechen?

**2025-09-19T17:26:28.204409** - Julia:
> Hi ihr beiden! Finally jetzt die Ideen &amp; Konzepte für den Brand Store :slightly_smiling_face:

Die Präsi ist noch so aufgebaut wie die alte Präsentation von Roxanne. Punkt 2 ist allerdings von mir überarbeitet und angepasst. Der übersichtshalber hab ich mit "New ones" abgegrenzt, aber können wir dann gerne rausnehmen.
Ich bin noch nicht ganz durch, aber denke hier könnt ihr auf jeden Fall schon euren Input geben.
Was fehlt noch komplett? Was überzeugt nicht?

Offene To Do's die ich dann am Montag fertigstelle:
• teilweise fehlt mir noch Content für Beispiele oder die Visualisierungen (<@U08V6A47PKN> vielleicht kannst du mir hier etwas helfen?)
• Redaktionsplan + Rythmus
• Cayenne Content
• reicht das erstmal so als Basis oder muss es wirklich schon komplett ausformuliert sein mit Captions etc.?
<https://docs.google.com/presentation/d/1DADc4z0yjy8dCYPF1MWD77C4HpFJAGPC/edit?usp=drive_link&amp;ouid=113547910377163828129&amp;rtpof=true&amp;sd=true>

Danke und schönes Wochenende!

**2025-09-19T17:30:58.086479** - Florian Listl mentioned Julia:
> <@U09D64LA420> danke! Ich kommentiere direkt

**2025-09-22T09:45:50.475299** - Florian Listl mentioned Julia:
> Kommt ihr ins Büro? :slightly_smiling_face: <@U08V6A47PKN> <@U09D64LA420>

**2025-09-22T10:32:11.070449** - Florian Listl mentioned Julia:
> <@U08V6A47PKN> <@U09D64LA420> ich würde uns für 17 Uhr einen schulterblick termin bei Hanna einbuchen, damit sie mal über die Ideen schauen kann, die Juli präsentiert. Und wir ggf. nach ihrem Feedback die Konzepte noch verfeinern.

Passt euch das?

**2025-09-22T10:39:00.757629** - Julia:
> ich auch etwas später!

**2025-09-22T14:11:28.827279** - Julia:
> hab die Präsi für gleich überarbeitet

**2025-09-22T19:09:45.129619** - Florian Listl mentioned Julia:
> <@U09D64LA420>

**2025-09-24T17:30:22.331809** - Julia:
> Halloo, ich bin wieder „alive“.. ich hab glaub ich eben 18 Std. geschlafen. Fieber ist endlich runter und ich werde morgen wieder voll reinstarten! 
Tut mir Leid, dass ich plötzlich ausgefallen bin bei dem was gerade alles ansteht

**2025-09-30T09:20:58.437399** - Julia:
> Guten Morgen! Wollte nur Bescheid geben, dass ich morgen um 12.00 Uhr einen Arzt Termin hab und so gegen 11.30 los muss

**2025-09-30T09:25:59.180109** - Julia:
> Ne keine Ahnung. Ich hatte ihr letzte Woche wie besprochen das Reel geschickt – ich kannte auch nur das. Julia hat mir gestern dann gesagt, dass es eine Präsentation gibt mit einem Carousel, Captions usw. Das hatte mMn nicht mehr so 100% gepasst und wir haben es noch kurz angepasst, bevor es an Charly rausging, inklusive ein Thumbnail. In der Präsentation lagen noch halbfertige Stories, die aber nichtmehr zum Reel gepasst haben

**2025-09-30T09:27:06.394259** - Julia:
> Ich kannte das Projekt außer das Video nicht, also kann ich gerne heute übernehmen – aber weiß natürlich nicht, was scheinbar vor Wochen besprochen wurde

**2025-09-30T09:40:52.118389** - Julia:
> Ja ich brauch natürlich die Infos zu Bildauswahl usw. Aber eigentlich hattest du das doch gestern noch extra angepasst <@U08V6A47PKN> ! Deswegen weiß ich nicht was ihr nicht passt 

**2025-09-30T09:41:14.390849** - Julia:
> Vorallem weiß ich auch nicht wo der content dazu abliegt, habe nur die video snippets 

**2025-09-30T10:01:07.329759** - Julia:
> ich komme wieder nicht in das meeting rein wegen teams

**2025-09-30T10:02:11.022469** - Julia:
> glaube es geht. warte, dass mich jemand reinlässt

**2025-09-30T10:02:58.967729** - Julia:
> bin jetzt über die app. manchmal gehts so, manchmal so

**2025-09-30T13:22:06.112349** - Julia:
> Hallo! bitte einmal euer Feedback zu Leonie:

**2025-09-30T13:23:24.181419** - Julia:
> • Caption Carousel neu
• Stories hinzugefügt
• Caption Reel neu

**2025-09-30T13:25:06.331379** - Julia:
> <@UNUQV5R08> <@U08V6A47PKN> würde euch gerne vorher drüber schauen lassen, bevor ich es rausschicke. Danke!

**2025-09-30T13:40:26.523429** - Julia:
> Feedback von Julia hab ich angepasst. Wording der Storyslides etwas knapper gehalten. <@UNUQV5R08> kannst du es auf Sharepoint laden? Ansonsten würde ich Charly jetzt das PDF davon schicken

**2025-09-30T13:50:25.533229** - Julia:
> oh okay. Dann sag ich Basti das kurz. Aber könnten wir ja auch evtl. nachträglich anpassen, oder meint ihr das fällt ihr direkt auf?

**2025-09-30T13:51:09.736469** - Julia:
> okay. also soll ich ihr antworten? ich kanns halt nur nicht in sharepoint ablegen

**2025-09-30T13:59:33.295249** - Julia:
> habs ihr geschickt – komischerweise habe ich auf die Präsi jetzt wieder zugriff :smile:

**2025-09-30T14:08:14.039659** - Julia:
> Danke euch! 

**2025-10-30T17:18:09.962319** - Florian Listl mentioned Julia:
> <@U08V6A47PKN> <@U09D64LA420>

**2025-10-31T10:07:33.059709** - Julia:
> Hello! Also wir haben bisher nur 2 Folien erstellt mit BP Posts und Low Performer, thats it – würde ich nicht unbedingt als Reporting bezeichnen

**2025-11-12T17:20:12.976199** - Florian Listl mentioned Julia:
> <@U09D64LA420> haben wir da was? Bzgl Hisense 

**2025-11-13T09:04:09.610949** - Julia:
> Jaa genau :slightly_smiling_face: danke! :slightly_smiling_face:

**2025-11-20T13:13:07.170629** - Julia:
> Hi Flo! :slightly_smiling_face:
1. Da gibt es leider noch kein Update – also diese Prüfung läuft noch. Aber direkt eine Frage dazu: wir haben gestern mit Laureen den gorenje Account aufgesetzt. Sollen wir es hierfür auch direkt starten? Dann schreibe ich Marvin wie das genau geht.
2. An sich super gerne für CM – hier müssen wir noch einen Prozess aufsetzen bzw. hatten wir das hier ausarbeitet aber Hisense noch nicht vorgestellt. Das fällt ja in den Bereich und dafür müssen wir Do's &amp; Dont's gemeinsam mit dem Kunden festlegen. Können wir auf jeden Fall nächste Woche machen. Julia hat uns jetzt eine neue Meeting Struktur mit Hisense aufgestellt, damit wir eh mehr im Austausch sind 

**2025-11-20T17:53:47.159459** - Julia:
> alles klar!

**2026-02-16T16:31:43.343609** - Florian Listl mentioned Julia:
> <@U09D64LA420> <@U08V6A47PKN>

bzgl b) - sprecht da gern auch mit Basti, der filmt ja und ggf mit Marvin

**2026-02-16T17:44:29.923709** - Julia:
> Yes, sollten wir hinkriegen :slightly_smiling_face: Genau, dazu brauch ich Basti auf jeden fall


---

### #mpdm-julia.hopper--florian--jana--mert-1 (3 messages)

**2025-11-28T09:44:41.961539** - Julia:
> Hier der neue Chat

**2025-11-28T09:45:03.977699** - Julia:
> <@U093J779DAQ> your topic :slightly_smiling_face:

**2025-11-28T09:45:30.243309** - Julia:
> *Jana Kordt*  [9:44 AM]
<@U09D64LA420> die Zeitungsartikel lädt man ja nicht runter, das sind Links. Eine Auflistung gibt es da nicht.

Aber ihr müsst doch irgendwo dokumentiert haben, welche Links ihr da versendet habt??


---

### #mpdm-julia.hopper--florian--marie-1 (17 messages)

**2025-12-01T11:48:06.433789** - Julia:
> Hi Flo! Marie und ich sitzen an den TikTok Shop Zahlen für MAC und hängen hier gerade etwas. Wir bräuchten einmal deine Hilfe damit wir weitermachen können. Danke!

**2025-12-01T12:04:47.925209** - Julia:
> Also wir wissen schon mal, dass durschnittliche Likes bei MAC De 92k sind bei den LIVE Events

Haben uns für das Live Event morgen angemeldet, dann können wir zumindest schon sehen wieviele Leute ca. daran teilnehmen

**2025-12-01T12:22:20.256709** - Julia:
> okay, schauen wir uns an!

**2025-12-01T12:22:22.433949** - Julia:
> dankee

**2025-12-01T12:23:45.614349** - Julia:
> Hast du eine Nachricht bekommen? Code 43

**2025-12-01T12:24:20.785929** - Julia:
> Jetzt 74

**2025-12-01T12:24:26.159199** - Julia:
> Ist gesprungen 

**2025-12-01T12:42:36.555479** - Julia:
> okay, danke! die platform von oben ist auch schon super

**2025-12-01T14:14:17.905609** - Julia:
> 15.30 sollten wir schaffen 

**2025-12-01T15:40:45.513109** - Julia:
> kommt gleich!

**2025-12-01T16:19:49.529829** - Julia:
> Okay, wir haben einen neuen Case gebaut anhand des TikTok Shops bzw. den alten angepasst: Update 1.12.
<https://docs.google.com/document/d/1SByofKhnwxNEQS8nKwrzm-wT7L5-qAubuA9JX6N6XGo/edit?tab=t.vxamqr41n8zq>

**2025-12-01T16:20:59.084179** - Julia:
> basierend darauf sind neue Content Formate entstanden die hauptsächlich mit der Live Metrik zutun haben

**2025-12-01T16:22:34.192099** - Julia:
> Interessant ist hier: der *Live Shopping ist MACs stärkste Waffe* – zwei Lives allein bringen *~1.500 € GMV +* Lives produzieren hohe Viewerzahlen (*18k+*)

**2025-12-02T08:29:40.478679** - Florian Listl mentioned Julia:
> Ich brauche von euch 3 Themen:
1. Zahlen/ Screenshots der View to Sale Ratio von anderen Brands
2. Anzahl Live Zuschauer von anderen Brands - ich glaube 18k ist nicht so viel, weil da wahrscheinlich alle reinzählen die eine Sekunde zuschauen und dann weiterswipen
3. Haben wir zahlen dazu wie lange leute den MAC live stream schauen? Entweder Median oder Average. Haben wir Vergleichswerte?
Generell ist der Vergleich zu anderen immer essentiell, um die Zahlen richtig einschätzen zu können
<@U09D64LA420> <@U09TJSTN85B>

**2025-12-02T08:55:08.883669** - Julia:
> Guten Morgen,
1. wir haben die Zahlen von Maybelline DE zum Vergleich. Sollen wir auch die US Marken vergleichen? Schicken wir dir.
2. 18k ist für die DE Beauty Marken viel – hier gibt's nur Maybelline DE als wirklichen Vergleich, alle anderen haben ja sowieso weniger
3. checken wir
4. Beauty oder generell?

**2025-12-02T10:05:32.567079** - Julia:
> <@UNUQV5R08> der Fastmoss Zugang für die US Shops hat 10€ gekostet. Hab die Rechnung bereits weitergeleitet

**2025-12-02T15:39:43.909809** - Julia:
> Hi Flo, jetzt die fehlenden Infos.
Vorab als Info bezüglich der Vergleiche
• wie anfangs schon rausgefunden, es gibt wirklich *kaum eine DE Marke mit TT Shop* und/ oder *Lives auf dem eigenen TT Shop*.
• Lives werden nochmal differenziert zwischen *Live Shop &amp; Live Creator*
• Die meisten *US Marken hosten Lives nur über Creator Profile,* nicht ihre eigenen.
• Deshalb wenige Vergleichswerte für uns.
1. *View-to-sale Rate Vergleiche:* <https://boldcreators-my.sharepoint.com/:x:/g/personal/marie_gottschall_boldcreatorsclub_com/ET4BSKx62fhMpiswGgNC9sEBDR16D0Kim2f3GmQsqcmgrQ?e=gs5SU2|Hier in der Excel> haben wir mit Brands erweitert, die einen eigenen TT Shop mit Lives hosten.
--&gt; elfyeah (US) hat im Vergleich eine View-to-sale Rate von *1,57%,* Theordinarystore (US) liegt bei *0,82%*

2. *Median 18K Views:* im Vergleich zu elfyeah &amp; Theordinarystore mit TT Shop LIVE im Mittelfeld. Siehe Screenshot/ <https://boldcreators-my.sharepoint.com/:x:/g/personal/marie_gottschall_boldcreatorsclub_com/ET4BSKx62fhMpiswGgNC9sEBDR16D0Kim2f3GmQsqcmgrQ?e=gs5SU2|Excel>

*3. Watchtime:* hier konnten wir keine zuverlässigen Daten finden.

4. *DE Shop mit 10 Mio. Jahresumsatz:* Nicht ganz. Siehe Screenshot: "Hanadis Marken Welt" liegt bei 726k im Monat --&gt; *8,7 Mio. im Jahr*


---

### #mpdm-julia.hopper--florian--mert-1 (16 messages)

**2025-09-26T12:07:49.830969** - Julia:
> Flo, wolltest du die Bilder in der Präsi direkt eingesetzt oder sollen wir sie dir hier schicken?

**2025-09-26T12:09:53.805949** - Julia:
> würde sonst schon mal ein paar einsetzen

**2025-09-26T12:16:19.455289** - Julia:
> okay

**2025-09-26T12:16:36.854959** - Julia:
> Könntest du die excel tabelle noch in asana ablegen? Dann kann ich mir die "Friends" und Co. nochmal anschauen

**2025-09-26T12:27:24.087849** - Julia:
> Hab ein paar eingesetzt, die ich noch im Kopf hatte

**2025-09-26T12:27:39.928209** - Julia:
> <@U093J779DAQ> würdest du die letzte Slide mit den Kommentaren befüllen? :slightly_smiling_face:

**2025-09-26T12:31:42.398319** - Julia:
> yes

**2025-09-26T12:47:01.890189** - Florian Listl mentioned Julia:
> <@U09D64LA420>

**2025-09-26T12:48:48.333489** - Julia:
> danke!

**2025-09-26T12:57:51.293809** - Julia:
> Bilder usw. sind alle angepasst – die restlichen Slides baust du gerade, oder <@UNUQV5R08>?

**2025-09-26T12:58:27.771869** - Julia:
> yeees <@U093J779DAQ>

**2025-11-03T16:55:37.565909** - Julia:
> Hi! Flo noch eine Frage – gibt es schon irgendwo eine Auswertung zur Hisense/ Gorenje Zielgruppe? Klar auf Tiktok etwas jünger aber gibt es genaue Metriken?

**2025-11-03T16:57:48.132679** - Julia:
> Und haben wir eigentlich einen BCC interen TikTok Account den wir für Recherche nutzen können? Sonst aktivier ich meinen uralten wieder :smile:

**2025-11-03T16:58:32.257349** - Julia:
> okay super. Aber es gibt jetzt nicht das typische Diagramm wie bei Instagram? Altergruppe für den Account, Standort etc.?

**2025-11-03T16:59:20.209019** - Julia:
> ja genau. okay, dann so

**2025-11-03T17:32:45.754679** - Julia:
> super danke :slightly_smiling_face:


---

### #mpdm-julia.hopper--jana--marvin-1 (50 messages)

**2026-01-12T10:55:31.052199** - Julia:
> Hi zusammen! eine Frage zu den "Zugängen":  hier ist einfach gemeint, was man benötigt oder?

**2026-01-12T10:55:56.278219** - Julia:
> Und <@U0994RLAGHW> könntest du mich noch freigeben? Hab ein paar Anfragen geschickt

**2026-01-12T10:58:29.720709** - Julia:
> Okay, danke! Das kommt dann mit dem sixt-account oder?

**2026-01-26T09:46:24.137699** - Julia:
> Hi! Also hier kam auch noch nichts von SIXT selbst oder?

**2026-01-26T09:47:52.103269** - Julia:
> Yes, klang nur so als würde SIXT schon jemanden vor Ort angefragt haben

**2026-01-26T15:51:33.994709** - Julia:
> Danke Marvin! :slightly_smiling_face:

**2026-01-26T15:52:07.367559** - Julia:
> <@U0994RLAGHW> du hattest in den Projektplan für Anything reingeschrieben, dass es eine Shortliste für die Moderatoren gibt. Könntest du mir die einmal schicken? Dankee

**2026-01-27T09:05:33.002589** - Jana Kordt mentioned Julia:
> <@U09D64LA420> Die Moderatoren-PPP liegt ab und ist in der Übergabe, aber ich suche es noch mal raus.

**2026-01-27T09:55:03.443939** - Jana Kordt mentioned Julia:
> Hier das Feedback von Flo zu den Ideen bei SIXT (IG WORKSHOP).

<@U05LQB4GTC1> Der Dialog bei Love is Blind muss angepasst werden. Hier müssen wir mehr den USP eines Autos rausstellen, mit Stereotyp spielen. Das ist zu generisch noch.

<@U09D64LA420> Flo hätte gerne ein Video Snippet/MockuP (kann AI sein) von einer Love is Blind Szene. Man sollte zuerst die Frau sehen, dann das Reveal mit dem SIXT Auto.

<@U05LQB4GTC1> - wie kriegen wir das Carpool karaoke auf 120 Sekunden? Wie kriegen wir in die 120 Sekunden was rein, was ganz typisch für SIXT ist?

<@U05LQB4GTC1> &amp; <@U09D64LA420> - Habt ihr eine Idee für potenzielle Moderatoren für Carpool Karaoke?

<@U05LQB4GTC1> - Personality Change muss krasser sein. Öko Mutti steigt in einen Benzer, dann rappt sie Haftbefehl mit.
Macho Typ sterigt in SUV und hat einen Matcha Latte in der Hand und sing DShirin David.
Welche anderen Ideen hast du? Wir brauchen 7 Ideen...

<@U05LQB4GTC1> - SIXT Pranked (AI Voice) - Hier brauchen wir konkrete Beispiele (bim Popeln erwischt, am Handy, etc)
<@U09D64LA420> - die die Szene brauchen wir auch ein Video mit einer eingesprochenen Stimme - der Kunde muss sich das vorstellen können.

<@U09D64LA420> - Bitte ein Carousel Ad erstellen mit Dingen, die man nicht sagen sollte - die Ideen sind super, sollten wir nur anskribbeln.

<@U05LQB4GTC1> - das Quiz findet er so etwas zu billig - er will RSAs mit einbeziehen, ählich wie hier: <https://www.youtube.com/watch?v=l9fs06Fw8FY>
Hier brauchen wir konkrete Fragen.

<@U09D64LA420> Wir brauchen je ein THumbnail zu jeder Idee - damit wri das in ein Instagram Feed mockuppen können.

**2026-01-27T10:31:57.371859** - Julia:
> Donnerstag ist super knapp evtl. wird nicht alles fertig

**2026-01-27T10:32:57.866079** - Julia:
> kann ich so nicht sagen, kommt immer auf die AI an. Aber ich geb eh Bescheid, sobald ich was weiß

**2026-01-27T10:34:59.381119** - Julia:
> yes. Flo weiß aber auch, dass die Designs/ Videos mit AI oft nicht klappen, daher kann es sein, dass eine Idee so nicht visualisiert werden kann wie er sich das vorstellt. ich stelle alles bereit was geht – nur evtl. anders :slightly_smiling_face:

**2026-01-27T12:15:59.863139** - Julia:
> Das wollte Sixt aber unbedingt oder?

**2026-01-27T12:16:24.738629** - Jana Kordt mentioned Julia:
> <@U09D64LA420> woher weiß SIXT was wir vorstellen werden? 

**2026-01-27T12:17:14.708779** - Julia:
> ganz genau

**2026-01-28T09:56:27.483379** - Julia:
> bin dabei nach und nach die Visualisierungen zu erstellen

**2026-01-28T11:16:27.226129** - Julia:
> hello! hab leider immer noch keinen Zugang zu Asana, wer kann mich freigeben?

**2026-01-28T11:53:50.457459** - Jana Kordt mentioned Julia:
> Flo will morgen zusamemn über den Workshop gehen mit allen fertigen Videos und so <@U09D64LA420>
Wann kannst du?

**2026-01-28T12:33:16.830969** - Julia:
> 

**2026-01-28T12:33:25.279729** - Julia:
> Ab 14.30 Uhr wäre super

**2026-01-28T12:33:27.467759** - Julia:
> danke dir!

**2026-01-28T12:37:33.764879** - Julia:
> danke!

**2026-01-28T12:49:13.075989** - Julia:
> Kannst du schon einschätzen wann ca? Dann können wir es etwas planen

**2026-01-29T09:53:27.266729** - Julia:
> Ne, leider nicht. Flo hat sie dann geschickt. Marvin und ich haben die Slides mit den Formaten angepasst. Sollten gegen mittags fertig werden. Dann schicke ich dir die Sildes hier rein und wir können sie später zusammen fügen. Die Videos schicke ich dir gesondert per Link, dann kannst du sie so nochmal einbauen

**2026-01-29T09:53:38.220059** - Julia:
> alles gut, haben sie ja jetzt

**2026-01-29T11:18:27.105999** - Julia:
> Fiat hab ich eh nicht erstellt

**2026-01-29T11:18:39.826089** - Julia:
> Marie

**2026-01-29T11:19:11.628369** - Julia:
> Wie gesagt ich schick es dir asap alles zu. Glaube so macht es keinen Sinn die Sachen durchzugehen, da sich ja eh nochmal viel geändert hat :slightly_smiling_face:

**2026-01-29T11:19:54.190379** - Julia:
> Ne aber wir können ja nicht alles umsetzen, daher ist jetzt immer nur eine Idee zB visualisiert

**2026-01-29T11:19:58.685449** - Julia:
> siehst du dann gleich bei den Slides

**2026-01-29T12:50:05.586759** - Julia:
> Ich brauch noch ca. 15 min. Hab leider noch nicht alle Videos von Basti bekommen, aber hab markiert wo diese reinmüssen

**2026-01-29T13:18:43.594919** - Julia:
> So there you go.
• Der Aufbau mit den Content Säulen ist analog Porsche damals – natürlich auf SIXT angepasst
• Formate sind alle visualisiert, weitere Beispiele sind dann dazu geschrieben, wir werden vieles mündlich erzählen
• Formate sind nach den Content Säulen sortiert
• Finale Videos laden hier rein: <https://drive.google.com/drive/folders/1aLCz7CZkdJOu_PQiBQh9GxUdMamSHJdt>
Besprechen wir dann alles im Termin mit Flo, oder?

**2026-01-29T13:28:20.886389** - Julia:
> wie oben geschrieben, ist nach Säule sortiert. Die Headlines hab ich noch nicht angepasst, falls wir das nochmal umändern wollen. also Reihenfolge (1,2,3..) ist in dieser Version noch nicht final

**2026-01-29T13:28:52.930899** - Julia:
> Woher kam das?
Können wir es verbinden, zusammenfügen?

**2026-01-29T13:35:27.660619** - Jana Kordt mentioned Julia:
> <@U09D64LA420> "Dinge die man nicht sagen sollte" - hier sollten wir eine Carousel Ad erstellen - kannst du das machen?

**2026-01-29T13:37:09.297579** - Julia:
> Dinge die man nicht sagen sollte ist als GIF angescribbelt

**2026-01-29T13:38:05.277459** - Julia:
> Was genau meinst du denn damit? Die Visuals sind im IG MockUp angelegt
Thumbnails für was?

**2026-01-29T13:38:19.740089** - Julia:
> Dann lass es uns verbinden, oder? Passt doch super

**2026-01-29T13:42:07.183649** - Julia:
> Videos von Basti sind fertig und liegen alle ab

**2026-01-29T13:42:37.191829** - Jana Kordt mentioned Julia:
> <@U09D64LA420>
Dinge die man nicht sagen sollte ist aber ein Carousel, kannst du bitte ein Carousel raus machen?

**2026-01-29T13:45:36.210469** - Julia:
> ich versteh nicht ganz was du meinst. Ich habs als GIF animiert, damit man den Eindruck bekommt es ist ein Carousel Post. Den "Swipe" Effekt kann ich so schnell nicht umsetzen. Wenn der Aufwand nötig ist, kann ich es Basti geben.
Hier das GIF:
<https://drive.google.com/drive/folders/1aLCz7CZkdJOu_PQiBQh9GxUdMamSHJdt>

**2026-01-29T13:46:59.755129** - Julia:
> Okay, Thumbnails bzw. Profilübersicht kann ich noch für morgen erstellen

**2026-01-29T13:47:38.377879** - Jana Kordt mentioned Julia:
> <@U09D64LA420> WIr sollen einfach die verschiedenen Slides zeigen - das ist kein Video, sondern 4 Bilder nebeneinander -

**2026-01-29T13:48:29.300269** - Julia:
> • bei LIB ist vor dem geschriebenen Dialog davor (...), wir hören den Anfangsteil im Video

**2026-01-29T13:49:31.677319** - Julia:
> Ja weil das nur der Opener ist

**2026-01-29T13:49:43.188849** - Julia:
> Der Rest wird ja nicht gesprochen, sondern nur gezeigt

**2026-01-29T13:50:13.754249** - Julia:
> Also ich glaube es macht gerade wenig Sinn die Präsi so durchzugehen. Ich kann dir gerne alles in Ruhe erklären. Bzw. präsentieren Marvin und ich ja eh diesen Teil, daher ist uns klar was wir da sagen und zeigen

**2026-01-29T13:50:54.452969** - Julia:
> Wenn du es umschreiben möchtest, dann mach das gerne. Aber jede einzelne Slide hier schriftlich erklären ist gerade nicht effizient bei dem Workload

**2026-01-29T13:52:43.783379** - Julia:
> Ja, die Sachen sind ja teilweise nicht komplett umsetzbar in dieser kurzen Zeit und wir müssen vieles mündlich ergänzen. Oder eben als "weitere Varianten" vorstellen etc.

**2026-01-29T13:55:36.942449** - Julia:
> ich weiß, dass es kein Video ist. Der Effekt mit "swipen", sollte durch das GIF erstellt werden.

Hier die einzelnen Slides als PNGs:
<https://drive.google.com/drive/folders/1aLCz7CZkdJOu_PQiBQh9GxUdMamSHJdt>


---

### #mpdm-julia.hopper--marie--anna-1 (11 messages)

**2025-11-21T14:09:20.586109** - Julia:
> Hier unsere Gruppe! :slightly_smiling_face:

**2025-11-21T15:20:51.197099** - Julia:
> Wie gesagt, Screenshots + alles was ihr über die Super-Fans noch spannendes rausfinden könnt (arbeitet bei MAC oÄ), wäre super. Danke euch! :slightly_smiling_face:

**2025-11-21T16:39:50.705219** - Julia:
> all good, danke schon mal!

**2025-11-21T16:50:00.145539** - Julia:
> Sind das die Instagram oder TikTok Kanäle?

**2025-11-21T17:29:15.365199** - Julia:
> Ach super, das sieht doch schon mal gut aus

**2025-11-21T17:29:40.573929** - Julia:
> alles gut, hab Flo schon Bescheid gegeben, dass es heute etwas knapp wird

**2025-11-21T18:18:03.057989** - Julia:
> danke euch! :slightly_smiling_face: habt ein tolles Wochenende

**2025-11-24T16:38:53.813569** - Julia:
> Hi! :slightly_smiling_face: Eine Frage: habt ihr zu ihr noch mehr Infos rausgefunden oder könntet da nochmal recherchieren? Amy kommentiert ja wirklich jede Marke, da wäre interessant was ihr Background ist

**2025-11-24T16:54:07.070409** - Julia:
> haha okay. Sind da noch andere Marken außer "unsere" dabei?

**2025-11-24T16:56:49.459649** - Julia:
> ah okay, also einfach krasser Beauty Fan

**2025-12-05T18:16:49.905399** - Anna Arndt mentioned Julia:
> Hallo Juli und Marie! Für die Lidl-Wohnwagen-Kampagne habe ich ganz viel rumtelefoniert und angefragt, allerdings gibt es einige Anbieter, die ich nicht erreicht habe und einige, die wir spezifisch am Montag nochmal fragen sollen. Ich schicke euch Listen durch, wäre super, wenn ihr da nochmal anrufen könntet!

1. Wohnwagen-Vermieter:
<https://roadsurfer.com/>
<https://camper.check24.de/wohnmobil-mieten/ci/deutschland/hamburg>
<https://www.reinschgmbh.de/autovermietung/wohnmobilvermietung/>

2. Parken
<https://elbecamp.de/>
<https://wohnmobilstellplatz-wedel.de/> *Montag nochmal probieren,* Fragen nach Herrn Niss (Badleitung) -&gt; eigentlich machen die das nicht aber ganz evtl. gibt es eine Chance wegen Sonderanfrage

3. Außenfolierung: Da kommen Angebote per Email rein, <@U09D64LA420> du bist im CC

4. Inneneinrichtung:
Habe die komischerweise alle nicht erreicht, bis auf einen, der meinte es würde gehen und er ruft zurück, hat sich aber noch nicht gemeldet: <https://hp-camper.de/>
Bitte nochmal fragen, ansonsten z.B. die hier:
(Noch) nicht erreicht
<https://vanme.de>
<https://solutionsfornomads.de/>
<https://www.freaksoffashion.com/>
<https://www.hamburger-holzschmiede.de/>

5. Genehmigung
Wir brauchen eine Genehmigung, um mit Wohnwagenkollonne durch die Stadt zu fahren
-&gt; anscheinend vom LVB, die kümmern sich wohl um Polizei etc.
-&gt; habe trotzdem alle möglichen Stellen angefragt (Stadt, Ämter, Polizei), wurde nur herum geschickt, niemand ist verantwortlich anscheinend hahah,
folgende Nummer wurde mir jetzt für Montag gegeben:
040 428582492 (Sonderggenehmigungsstelle des LVB, 9-13 Uhr erreichbar)


---

### #mpdm-julia.hopper--marvin--florian-1 (17 messages)

**2026-01-15T13:10:42.138929** - Julia:
> Hi, hab erste Format Ideen für SIXT hier gesammelt:
<https://docs.google.com/document/d/1fI3JcT0WHICFJ_oo6li7B8t22ezx9aWenC8AeXIjVSo/edit?tab=t.0>

Lasst mich gern wissen, ob's in die richtige Richtung geht!

**2026-01-15T15:42:04.590719** - Julia:
> Danke für deine Einschätzung und das Feedback!
Das international Thema war mir noch nicht ganz klar, aber macht jetzt natürlich Sinn.
Ich denke Idee 3 wäre dann wirklich nur in den USA dann umsetzbar oder mit jemanden der in DE &amp; USA bekannt ist (so viele gibts da nicht..)
Idee 6 könnte man trotzdem machen aber dann DE + USA oder DE + ESP – Fokus einfach auf die internationalen Unterschiede, was ja auch super witzig sein kann

**2026-01-27T12:27:12.789909** - Julia:
> Just FYI: Higgsfield ist mit Nana Banana Pro heute fast nicht benutzbar. Habs jetzt paar mal versucht aber wird immer abgebrochen. Die anderen Tools sind einfach im Vergleich nicht gut genug. Heißt also: wird alles etwas länger dauern

**2026-01-27T12:28:46.993429** - Julia:
> ja sehr ärgerlich, ich probiers weiter

**2026-01-27T13:08:42.869859** - Florian Listl mentioned Julia:
> Hi ihr beiden :slightly_smiling_face:

<@U09D64LA420> lass uns beide vor Ort hinkommen, dementsprechend sollte Juli auch zumindest ihre Ideen vorstellen, ggf sogar etwas mehr

So zeigen wir Präsenz und Juli kann alle kennenlernen :slightly_smiling_face:

**2026-01-27T17:09:16.813689** - Julia:
> also das klappt heute wirklich garnicht – vllt Love is Blind mit 2 Autos und sie muss sich entscheiden? :smile:

**2026-01-27T17:09:48.598069** - Julia:
> können wir gerne vor Ort machen. ich denke wir teilen es dann je nach Idee auf oder? <@U05LQB4GTC1> :slightly_smiling_face:
Bzw. hat Marvin ja auch nochmal mehr Gespür was sie dann anfechten, anzweifeln etc.

**2026-01-27T17:13:30.248429** - Julia:
> Neee ich meinte das als Witz :smile: ich probier es weiter, aber die Ausgabe ist heute einfach nicht gut. Hatte auch schon ein Video bei dem die Frau spricht, aber es klappt nicht so wie es sein soll

**2026-01-27T17:13:48.697079** - Julia:
> Und Jana stellt es aber generell vor, oder?

**2026-01-28T12:34:26.536489** - Julia:
> Hello! Unterstützung ist schon mal super! Evtl. könnten wir zu 3. einmal sprechen? Ehrlicherweise ist mein Gefühl es braucht jemand anderen als eine Werkstudentin

**2026-01-28T12:45:56.707699** - Julia:
> Wann habt ihr zeit?

**2026-01-28T14:01:32.872809** - Julia:
> bin in 1 min da

**2026-01-29T15:54:41.331649** - Julia:
> FIY: Marvin und ich haben Jana den Content Teil geschickt, den Rest den Präsi kennen wir auch noch nicht. Je nachdem können wir es gut präsentieren oder eben nicht

**2026-01-29T16:00:18.101599** - Julia:
> unseren Teil jetzt, ja

**2026-01-30T10:31:32.274239** - Julia:
> Hello! Ne, null leider

**2026-01-30T10:32:25.602399** - Julia:
> Geht eher darum, dass wir bisher noch nicht üben konnten. Oder <@U05LQB4GTC1> das meinst du?
Also ich hab mich noch keine Sekunde mehr damit befasst

**2026-01-30T10:40:56.912449** - Julia:
> es macht 100% Sinn, das nochmal zusammen durchzugehen, keine Frage! Das Timing ist einfach super schwierig für heute auch noch.
Marvin und ich sind einfach grad gedanklich SO tief in allen anderen Themen und am abarbeiten – correct me if I'm wrong. Ich persönlich springe von SIXT zu Hisense/ Gorenje, zu Mini und dann noch Decathlon. Ich persönlich kann nicht am Tag für 4 Kunden arbeiten um dann bei allen abliefern


---

### #mpdm-julia.hopper--marvin--julia.hallhuber-1 (20 messages)

**2026-01-28T14:23:19.215929** - Julia:
> Hallooo Julia! Hast du gegen 15.45Uhr Zeit für uns? :slightly_smiling_face:

**2026-01-28T15:32:21.677149** - Julia:
> juhu, hab schnell was eingestellt :stuck_out_tongue:

**2026-01-28T15:55:07.191949** - Julia:
> <https://docs.google.com/spreadsheets/d/1rLNbYB-utwI4QMIVidwnUajC9M8qAjCFD043DCj0tco/edit?usp=sharing>

**2026-01-29T15:50:22.158079** - Julia:
> Super, das ist doch schon mal ein Anfang! :slightly_smiling_face:

**2026-02-02T13:03:07.958799** - Julia:
> bin auch da!

**2026-02-03T10:42:14.656049** - Julia:
> Sehr cool! 

**2026-02-03T10:42:51.860339** - Julia:
> Konzept kriegen wir auch hin. Haben den Termin am Donnerstag ja erst nachmittags 

**2026-02-03T16:55:57.741399** - Julia:
> I daut it. Aber ich frage 

**2026-02-03T17:35:50.467409** - Julia:
> <@U08V6A47PKN> wir sinds :sweat_smile:
Wir haben ein sehr sehr krasses Timing von SIXT bekommen und müssen einen weiteren Projektplan (ganz grob) skizzieren – hättest du morgen Nachmittags Zeit das einmal mit uns zu erstellen/ durchzugehen etc.?
Je nachdem wie weit wir jetzt mit MINI kommen, können wir 2 auch gerne direkt morgens dazu sprechen?

**2026-02-03T17:52:07.436189** - Julia:
> okay ich ruder zurück: ich bin morgens im Büro und wir machen MINI. Also könnte wenn spontan oder dann ab nachmittag :saluting_face:

**2026-02-05T08:26:13.653449** - Julia:
> Guten Morgen ihr 2, sorry für meinen totalausfall gestern – konnte kaum auf den Bildschirm schauen :face_with_spiral_eyes:
Leider hat mich jetzt die Erkältung/ Grippe komplett erwischt und ich liege flach, wirklich zum kotzen.

<@U05LQB4GTC1> soll ich SIXT schreiben und damit auch die Verspätung der Timings an SIXT weitergeben?

**2026-02-05T09:20:43.060559** - Julia:
> danke euch!
Okay soll ich ihnen in der WhatsApp Gruppe Bescheid geben oder was ist dir hier am liebsten Marvin?

**2026-02-05T09:25:52.261579** - Julia:
> 

**2026-02-05T09:27:41.716339** - Julia:
> Mert kann da bestimmt sonst auch kurz reinspringen?

**2026-02-05T09:28:22.297869** - Julia:
> hier liegen die SIXT Dateien: Login über clients@bold
<https://www.figma.com/design/fNswah1KYpfq88QqRS9ZoG/IG-Worksop?node-id=0-1&amp;t=X2zMsmHRvK60a7zL-1>

**2026-02-06T09:24:04.247719** - Julia:
> Guten Morgen! Bin heute leider noch raus und fahre gerade zum Arzt. Ich melde mich asap :woozy_face: 

**2026-02-06T12:03:44.482279** - Julia:
> ihr seid ja cute :pleading_face: Ja bin heute noch krankgeschrieben. Ich melde mich gleich Montag bei euch! danke danke danke und schönes Wochenende

**2026-02-09T09:41:09.926969** - Julia:
> Hello! Oh krass, bin gespannt! 
Bin leider noch nicht fit genug :woozy_face: Ich meld mich sobald ich wieder kann! 

**2026-02-10T10:05:49.580219** - Julia:
> 

**2026-02-11T14:16:43.353289** - Julia:
> Hallo :slightly_smiling_face: Neee du hast am WE doch sicher besseres vor, als das :smile:
Würde es dir denn morgen oder Freitag passen? richte mich da komplett nach dir


---

### #mpdm-julia.hopper--mert--anna-1 (1 messages)

**2025-11-28T09:33:03.069849** - Julia:
> Hi zusammen :slightly_smiling_face: Hier ein kurzer Connect – Anna kann uns heute bei Hisense/ Gorenje unterstützen! Am besten besprecht ihr euch einmal kurz was die offenen To-Do's sind (Stichwort Creator Suche). Dankee!


---

### #mpdm-julia.hopper--mert--florian--marvin--jose-1 (1 messages)

**2025-12-23T16:55:53.446569** - Julia:
> Hi guys! Sorry my internet just crashed and I’m looking for a new spot :pray:


---

### #mpdm-julia.hopper--mert--jana-1 (31 messages)

**2025-11-03T13:11:35.659439** - Julia:
> Hi Jana, danke schon mal für die Übergabe!
Noch ein paar Fragen:
• Gibt es Präsentationsvorlagen oder Ähnliches welches wir für die Ideen Präentation nutzen können?
• Welches Social Media Tool nutzt ihr fürs Posten?
• Flo hatte uns die damalige Strategie Präsi noch gezeigt und war sich unsicher bezüglich der Roadmap, gibt es hierzu schon etwas?

**2025-11-03T13:18:30.472759** - Julia:
> Alles klar. Und hast du noch irgendwie diese Karte der Standorte der Geräte oder was du vorhin meinstest?

**2025-11-03T15:07:53.139649** - Julia:
> Uns fehlt noch die generelle CI für beide Marken. Also Styleguide, Schriften, Farben etc. Wo finden wir das?

**2025-11-04T16:26:17.844649** - Julia:
> Hi Jana, schaffen wir es morgen den Ads Manager durchzugehen oder wann passt es dir?

**2025-11-05T09:52:59.182359** - Jana Kordt mentioned Julia:
> <@U09D64LA420> <@U093J779DAQ> Wollt ihr anhand einer Timeline schon mal Shootings für dieses Jahr einplanen?
Es kann in München geshootet werden, dafür braucht Ray allerdings die Daten.

Die Highlight-Produkte habe ich aufgeführt.
Da die Zeit rennt: Ist es realistisch, dass ihr bis zum nächsten Mittwoch ein Konzept inkl. Shootinglist vorstellt, was wir mit den Produkten machen können?

**2025-11-05T11:21:41.811429** - Julia:
> Hallo ihr beiden! Danke fürs Stellung hatten. Ne die Info hatte ich von Flo von heute morgen

**2025-11-05T11:22:41.466739** - Julia:
> Er hatte mir gesagt, dass wir die Ideen einfach nachträglich vorstellen, sobald ich wieder fit bin

**2025-11-05T11:22:54.951219** - Julia:
> Vllt sprecht ihr euch da mal ab. Daraufhin sollte ich die nachricht in die gruppe schreiben

**2025-11-06T17:12:35.617989** - Jana Kordt mentioned Julia:
> <@U09D64LA420> du bist noch krank, oder ? :(

**2025-11-07T09:15:48.259449** - Julia:
> Guten Morgen! Yes, bin leider noch ausgeknockt :melting_face: Jana könnten wir unseren Paid Termin auch am Montag machen?

**2025-11-07T09:16:50.607419** - Julia:
> Ah du hast ihn eh schon rausgenommen

**2025-11-10T10:07:26.512719** - Julia:
> Hello!

**2025-11-10T10:07:53.116279** - Julia:
> Mert ist heute noch OOO – wollen wir unseren TikTok Termin dann morgen mit ihm zusammen machen?

**2025-11-10T10:46:58.233069** - Julia:
> Super. Ich bin bis 14.30 Uhr gut erreichbar, danach sitze ich leider im Zug. Passt es euch davor?

Ich hab tatsächlich noch ein paar Fragen, die mir von letzter Woche noch fehlen:
• wie ist der Kommunikationsstand mit dem Kunden gerade --&gt; die letzte Mail von Ray am 5.11. noch aktuell? Wie sieht es mit Produktverfügbarkeiten aus? Falls nicht, könntest du uns bitte alle Mails weiterleiten :slightly_smiling_face: 
• die Termine der Produktionen sind noch uns festgelegt oder woher kommen diese? Final und mit Kunden abgestimmt?
• Wie gehts weiter mit dem Content Upload? Wo liegen diese Dateien und wer postet? Die Ordner im Drive sind teilweise leer
• CI Unterlagen fehlen uns noch
• Reportings sind teilweise noch offen, finalisiert ihr diese noch bis Oktober?
• Ist Marvin wieder da? Bezüglich CM 
• Wird der Pascal Hens Content auch auf TikTok geposted oder ist das komplett getrennt?
• noch eine detaillierte Frage zum Produktionsbudget: wie ist hier die Abstimmung, also sind wir komplett frei in der Aufteilung oder spricht der Kunde da mit? Gibt der Kunde alles frei oder haben wir freie Hand?
Danke dir!

**2025-11-10T11:44:14.458889** - Julia:
> Okay danke dir!
• du meinst über <http://Frame.io|Frame.io> downloaden? Bis wohin lädst du denn hoch oder ab wann sollen wir? Das müssten wir ja festlegen
• Pascal Hens: was heißt genau "wird mit uns gedreht"? Wir sollen ja nur noch eine Content Idee liefern – läuft die Kampagne nicht über die Instagram Agentur?
• Budget: yes, aber hast du in der Vergangenheit die anfallenden Kosten mit dem Kunden besprochen also zB Kosten für Statisten oder gabs einfach das Budget und macht was ihr wollt damit?

**2025-11-10T12:04:01.004279** - Julia:
> Und noch eine Frage in der Übergabe hattest du ja geschrieben "Meeting Notes nach den Meetings" könntest du uns diese auch zur Verfügung stellen der letzten 2-3?

**2025-11-10T12:06:50.482719** - Julia:
> + Reportings :slightly_smiling_face: danke dir

**2025-11-11T09:21:27.065059** - Julia:
> Hi Jana, hast du die finalen Infos für uns bitte? Dann können wir die Übergabe final abschließen. Das wäre super, danke dir

**2025-11-11T11:37:18.990339** - Julia:
> Danke

**2025-11-11T11:37:24.366159** - Julia:
> Ja die Info haben wir parallel jetzt auch

**2025-11-11T11:38:03.658509** - Julia:
> Klar stimmen wir uns mit Julia ab, aber uns fehlen ja die Infos schon seit paar Tagen, deshalb fragen wir ja immer wieder bei dir nach

**2025-11-11T11:52:09.547269** - Julia:
> yes, aber es gibt ja viele Themen die noch offen sind und ich einfach nur eine kurze Info von dir brauche

**2025-11-11T11:52:34.004859** - Julia:
> Julia Hallhuber hat keinen Zugang. Das habe ich in Lark auch schon geschrieben, Mert und ich haben Zugang. Etwas anderes haben wir auch nicht gesagt?

**2025-11-11T11:53:09.513929** - Julia:
> Nichtmehr, ist abgelaufen

**2025-11-11T11:53:44.387679** - Julia:
> hab ich auch schon

**2025-11-11T11:53:54.124659** - Julia:
> klappt leider nicht

**2025-11-11T14:34:57.913689** - Julia:
> habt ihr beide morgen um 10 Uhr Zeit für den Paid Termin?

**2025-11-12T11:11:55.987219** - Julia:
> kurze Frage noch zu den nächsten Videos, wenn du es weißt sonst frag ich später Laureen:
• Was bedeutet das M? 
• auf welches Video bezieht sich der Kommentar? Der ist in <http://frame.io|frame.io> auf Video 1 aber hier ist es bei Video 2 markiert

**2025-11-12T13:11:17.418309** - Julia:
> okay und was bedeutet das? also irgendwas relevantes für uns?

**2025-11-13T14:20:17.968469** - Julia:
> Hey Jana! Also es wäre super, wenn du das TikTok morgen noch organisch posten kannst, bisher klappt der Login einfach nicht – wir werden es morgen boosten und dann abschalten, das würde <@U093J779DAQ> dann übernehmen. Am Montag haben wir erst den Budget Termin mit Flo und können dann die weitere Woche planen und hoffentlich direkt übernehmen

**2025-11-14T23:46:54.017959** - Mert Koc mentioned Julia:
> Hi <@U0994RLAGHW>,
Ich habe die Kampagne jetzt eben abgestellt. Ich habe eigentlich alles so gemacht, wie du uns gezeigt hast aber es wurde nichts geboostet und auch kein Geld ausgegeben. Ich weiß nicht warum. Ich habe eben nochmal alles durchgeschaut und weiß nicht, was ich übersehen habe.
Wäre super, wenn wir das am Montag zusammen nochmal anschauen könnten, dann verschieben wir das nächste Video posten von Sonntag auf Montag :confused:
fyi <@U09D64LA420>


---

### #mpdm-julia.hopper--mert--julia.hallhuber--marie-1 (17 messages)

**2025-11-24T15:55:06.826529** - Julia:
> Helloo! Ich dachte mir ich erstell ganz offiziell einen Chat für uns. Sollen wir morgen einen kurzen Vorstellungscall machen? :slightly_smiling_face:

**2025-11-24T15:56:00.243789** - Julia:
> Marie hat uns schon fleißig bei der Creator Suche unterstützt – <@U093J779DAQ> magst du gerne mal in die Präsentation schauen und Marie Feedback geben? Evtl. findet ihr ja noch wen. Ich bin jetzt gleich im Meeting und schaffe das heute nichtmehr. Dankeee :slightly_smiling_face:

**2025-11-24T15:56:52.652099** - Julia:
> <https://docs.google.com/presentation/d/1rbYB7aLiZwdcgXMezmgL1kWXM0APEyGw64nXlBrXhpY/edit?slide=id.g3a64d1ec782_0_33#slide=id.g3a64d1ec782_0_33>

**2025-11-25T09:18:54.621159** - Julia:
> Hello! Ne das war nur überschlagen. Könntest du die korrekten Zahlen eintragen?

**2025-11-25T09:21:35.680609** - Julia:
> Ah Mist und die Median Werte wie bei Estée Lauder? Geht nur um einen groben Vergleichswert für den Kunden

**2025-11-25T09:30:16.565969** - Julia:
> Ja du hast Recht, hatte etwas anderes im Kopf.
Aber wenn du sagst die Views stimmen nicht – dann trag doch trotzdem gerne mit deinem besten Gewissen die korrekteren View Anzahlen ein. Das wäre super :pray:
cc <@U093J779DAQ>

**2025-11-25T09:36:40.783159** - Julia:
> cool danke!

**2025-11-25T09:43:50.372949** - Julia:
> ich verschiebs. <@U09TJSTN85B> wie bist du morgen erreichbar?

**2025-11-25T09:44:41.832019** - Julia:
> super danke!

**2025-11-25T10:40:07.388899** - Julia:
> ich melde mich nach unserem Meeting mit dem Kunden, welche To Do's dann offen sind :slightly_smiling_face: danke dir!

**2025-12-03T09:59:08.459709** - Julia:
> ah super, danke dir! 3 Stück?

**2026-01-07T12:58:40.512539** - Julia:
> Happy new year! :slightly_smiling_face: hoffe du hattest schöne freie Tage

**2026-01-27T12:12:22.866739** - Julia:
> Hi Marie! :slightly_smiling_face: Hoffe dir geht es gut. Ich nehme gerne einmal deine Kreativität in Anspruch. Es geht um folgende Format Idee. Hier siehst du ja schon ein paar Beispiele. Allerdings sind diese Flo noch etwas zu "brav". Er hätte gerne eher "Mutti steigt in Benz ein und rappt dann Haftbefehl"

Hättest du Kapa hier ein paar Beispiele runter zu schreiben? Gerne ein Mittelweg von "Matcha Latte" zu "Haftbefehl" :smile:

**2026-01-27T12:27:33.993889** - Julia:
> there you go: <https://docs.google.com/document/d/1fI3JcT0WHICFJ_oo6li7B8t22ezx9aWenC8AeXIjVSo/edit?tab=t.0>

**2026-01-27T12:27:51.392969** - Julia:
> kannst gerne direkt in den Tab "Update" reinarbeiten. Vielen Dank dir! :slightly_smiling_face:

**2026-01-27T15:15:23.954689** - Julia:
> schon sehr cool! :smile: ich versuch was ich umsetzen kann mit AI - danke dir!
Noch eine Frage: die Autos gibt es alle bei SIXT oder?

**2026-01-27T16:03:21.947409** - Julia:
> Habs Marvin geschickt, hab da selbst leider auch keine Ahnung. Wollte er sich anschauen :slightly_smiling_face:


---

### #mpdm-julia.hopper--mert--sebastian--julia.hallhuber-1 (11 messages)

**2025-09-04T17:40:51.691639** - Julia:
> Hello! Hab hier den Styleguide mal in PPT aufgesetzt für Porsche. Schaut gerne mal rein. Youtube würde ich nachziehen, aber vllt können wir ihnen diesen Status Quo ja schon mal schicken: <https://docs.google.com/presentation/d/1NYJecXqmY5G5_olYJcMTLr-bH7ToODD0/edit?slide=id.p1#slide=id.p1>

<@U0929T1BG0G> ich habs jetzt extrem runter gekürzt seitens den Premiere Einstellungen, weil das für die Porsche Freigabe nicht relevant sein sollt3e.

<@U08V6A47PKN> kannst du die Fußzeile bearbeiten? Oder mir gerne kurz sagen, wie das geht :smile:

**2025-09-04T17:49:57.645879** - Julia:
> btw: ändert sich die Font bei euch auch, wenn ihr die Präsi online öffnet statt runterladet? Hatte eigentlich alles in der Hausschrift angelegt

**2025-09-04T17:54:34.249979** - Julia:
> ja genau in der Onlineversion

**2025-09-05T15:35:26.961749** - Julia:
> Das ist an die PAG angelehnt und auch nur bei direkten Übersetzungen

**2025-09-05T15:43:48.924949** - Julia:
> ah perfekt. das wusste ich noch nicht :slightly_smiling_face:

**2025-09-05T15:44:03.980469** - Julia:
> <@U08V6A47PKN> hast dus schon abgeschickt oder soll ich das noch anpassen?

**2025-09-05T15:48:12.926459** - Julia:
> Blink Version PDF liegt ab!
<https://drive.google.com/drive/folders/1Uqfsv2dzOxUL2lpnQUGXIqSmga7tscPP>

**2025-09-08T09:31:33.515529** - Julia:
> Ja hatte ich Julia auch schon gesagt. Ich glaube sie hat hier etwas verwechselt. Es ist ja auch die Slide zu den Stories

**2025-09-08T09:32:40.822609** - Julia:
> Hatte extra nicht das iPhone Mockup genommen. Jetzt wollen sie es doch haha

**2025-09-08T11:26:53.509309** - Julia:
> Das hattest du eigentlich an PAG angepasst <@U093J779DAQ> oder?

**2025-09-08T11:29:10.136259** - Julia:
> das ist nämlich gleich, der Text ist nur länger


---

### #mpdm-julia.hopper--mert--sebastian-1 (6 messages)

**2025-09-04T14:45:42.761459** - Julia:
> Hello! :slightly_smiling_face: Sitze gerade am Styleguide da Julia den heute schon an Charly schicken möchte. Eine Frage: ich hab die PS-Vorlage von dir vorhin ja benutzt <@U093J779DAQ> Hier haben wir Sublines in 11pt. In der Styleguide Präsi haben wir 13pt.

Hatte vorhin das Gefühl online sind 11pt schon klein. Was meint ihr?

**2025-09-04T14:52:37.272129** - Julia:
> Alright, du hast da einen besseren Einblick als ich! Dann lasst uns nur sicherstellen, dass einzeilige Texte dann nicht verloren aussehen &amp; gut ins Layout eingebunden sind. War heute in den wireless stories leider nicht gut, wollte Porsche so :melting_face:

**2025-09-05T13:29:01.783579** - Julia:
> Darf ich jemanden von euch aus Adobe schmeißen? :face_with_peeking_eye:

**2025-09-05T13:42:08.771059** - Julia:
> okay.. ist es sehr schlimm?

**2025-09-26T10:57:01.954269** - Julia:
> sind gleich durch – meld mich sofort :smile:

**2025-09-26T11:09:44.596239** - Julia:
> könnt reinkommen


---

### #mpdm-julia.hopper--sebastian--julia.hallhuber-1 (1 messages)

**2025-09-30T17:32:08.902239** - Julia:
> Also das Leonie Video von VO find ich schon schwierig. Sollen wir den Text dann zumindest so einblenden?


---

### #mpdm-julia.hopper--sebastian--marvin-1 (35 messages)

**2026-01-28T11:29:59.350529** - Julia:
> Hello! :slightly_smiling_face: Basti ich hab dir eine Asana Task erstellt für's Editing von verschiedenen Assets für den IG Workshop am Montag mit SIXT.
Nach und nach füge ich die weiteren Ideen und Tasks für dich hinzu.

Ist das soweit verständlich? Sonst können wir gerne gleich mal dazu sprechen! Danke dir

**2026-01-28T16:22:38.975839** - Julia:
> super, danke! :slightly_smiling_face: Evtl. kommt noch was Kleines, sonst versuchen wir jetzt viel über Stills abzubilden

**2026-01-28T16:22:47.329449** - Julia:
> Wäre mir egal – das was wir sonst bei SIXT auch verwenden?

**2026-01-28T16:25:55.158989** - Julia:
> Ah okay

**2026-01-28T16:25:56.177079** - Julia:
> ja gerne

**2026-01-28T17:38:56.599609** - Basti mentioned Julia:
> <@U09D64LA420> hast dus dir so in etwa vorgestellt?: <https://f.io/xeAq9ugX>
<https://app.asana.com/1/1199360402832734/task/1212991424663406?focus=true>

**2026-01-28T17:42:16.980259** - Julia:
> Nice! Beste aus dem Material rausgeholt, danke dir :slightly_smiling_face:

**2026-01-28T17:42:44.873539** - Julia:
> yes, da bin ich grad noch nicht so weit.
Bei Personality change lege ich dir gerade die Snippets ab

**2026-01-29T09:21:04.626899** - Julia:
> Hello! <@U0929T1BG0G> bist du heute auf einem Dreh? Ich meine da etwas gehört zu haben :slightly_smiling_face:

**2026-01-29T09:21:33.489499** - Julia:
> Oh no

**2026-01-29T09:21:41.811499** - Julia:
> Aber gut für mich :stuck_out_tongue:

**2026-01-29T10:05:44.109769** - Julia:
> danke dir :slightly_smiling_face: hab in Asana kommentiert – wir haben uns überschnitten!

• Personality change
• Things you shouldn't do
sind noch ready for you!

2-3 weitere kommen noch, da gebe ich asap Bescheid

**2026-01-29T10:06:10.912459** - Julia:
> ein Traum hier

**2026-01-29T10:48:22.332049** - Basti mentioned Julia:
> <@U09D64LA420> Untertitel sind eingefügt: <https://app.asana.com/1/1199360402832734/task/1212991179974329?focus=true>

**2026-01-29T10:50:18.364459** - Julia:
> danke dir! Hast du das IG Mockup zufälligerweise als PNG? Dann würde ich das für die Stills auch direkt nutzen

**2026-01-29T11:00:55.764889** - Julia:
> Okay, welcher Unterschied ist bei den Logos? Wenn ich es google kommt nur das eine

**2026-01-29T11:01:46.363299** - Basti mentioned Julia:
> <@U09D64LA420> hier findest du die richtigen Logos: <https://drive.google.com/drive/folders/18vV0u11GaZaXKAVsBTyHJvABswIA-HC2?usp=drive_link>

**2026-01-29T11:02:10.031819** - Julia:
> ahh jetzt

**2026-01-29T11:02:11.841539** - Julia:
> okay wow

**2026-01-29T11:02:35.683889** - Julia:
> dann achte ich bei der Erstellung den nächsten Assets jetzt drauf :slightly_smiling_face: danke!

**2026-01-29T11:04:30.425809** - Julia:
> ich versuchs mal, sonst sagen wir es dazu. danke Basti für den Hinweis :slightly_smiling_face: wäre mir so nicht aufgefallen

**2026-01-29T11:12:41.220129** - Julia:
> danke dir! :slightly_smiling_face:

**2026-01-29T13:01:20.833119** - Julia:
> :joy: liebs

**2026-01-29T13:13:52.597389** - Julia:
> dankeee!

**2026-01-29T13:14:26.882459** - Julia:
> Hab noch eine weitere Task angelegt, da lädt das Video Snippet gerade los. Bis dahin wars es erstmal. Kann sein, dass Flo heute Abend doch noch ein paar Visualisierungen will, aber da melde ich mich

**2026-01-29T13:15:27.143239** - Julia:
> ja klar, wir davor

**2026-01-29T13:33:06.036459** - Basti mentioned Julia:
> <@U09D64LA420> vielleicht so ne Mischung?

<https://app.asana.com/1/1199360402832734/task/1213024814714292?focus=true>

**2026-01-29T13:41:13.829859** - Julia:
> Ja, why not! Danke dir :slightly_smiling_face:

**2026-01-30T10:25:47.732949** - Basti mentioned Julia:
> <@U09D64LA420> Huhu kurze Frage, wegen dem "Love is blind" soll ich trotzdem beim letzten Shot nach dem "l´m turning left or right" raus schneiden oder soll ich den Rest jetzt drin lassen?

**2026-01-30T10:27:33.952199** - Julia:
> Hello! Die neuen Videos sind noch nicht fertig :slightly_smiling_face: melde mich asap. Evtl. krieg ich es evtl länger hin und du musst am Ende nichts cutten

**2026-01-30T11:45:56.851459** - Julia:
> Wenn ich dir die Video Snippets ohne Voiceover schicke, meinst du, du kannst diese dann von den "falschen" Videos nehmen? Ich hoffe es klappt, aber IDK

**2026-01-30T11:56:26.304639** - Julia:
> liegen ab, hat sogar geklappt!

**2026-01-30T13:06:08.866489** - Julia:
> Danke dir 

**2026-01-30T14:13:19.358339** - Basti mentioned Julia:
> <@U09D64LA420> Check this ;): <https://app.asana.com/1/1199360402832734/task/1212991424663406?focus=true>

**2026-01-30T14:28:04.923299** - Julia:
> super, vielen Dank! :slightly_smiling_face:


---

### #mpdm-mert--julia.hallhuber--julia.hopper--laetitia-1 (12 messages)

**2025-09-18T12:55:37.505539** - Julia:
> Könntet ihr mir darauf Zugriff geben? :slightly_smiling_face:

**2025-09-18T16:04:19.635699** - Julia:
> Hello <@U093J763E5A>! :slightly_smiling_face: Hab nun auch Zugriff. Ging die Präsentation schon an Prosche raus?
Mir ist aufgefallen, dass wir teilweise unterschiedliche Typo auf den Slides haben und die Textblöcke springen (Slide 7,8,9).  Außerdem wäre es super, wenn wir Bilder/ Beispiele immer ungefähr auf der gleichen Höhe ablegen.
Könntest du das ganzheitlich noch anlegen?  Dankee dir

**2025-09-18T16:22:45.006899** - Julia:
> retro sunday liegt ab!

**2025-09-18T17:38:46.148729** - Julia:
> Danke diiir :heart: happy feierabend

**2025-09-19T10:12:52.688019** - Julia:
> das ist ja wirklich so dämlich gemacht :smile:

Aber dann lasst uns gerne in Zukunft nur noch PDFs an Porsche schicken bzw. präsentieren? Der Kunde sollte dieses Typo-Chaos nicht zu sehen bekommen

**2025-09-19T13:11:18.467899** - laetitia mentioned Julia:
> <@U08V6A47PKN> <@U09D64LA420> habe die vorläufigen Captions in die Präsentation gepackt und Fact check ist auch durch. Habe die links immer unter die jeweiligen Posts gepackt und ansonsten einen Kommentar hinterlassen. 
<@U093J779DAQ> Video &amp; Foto upload für den Targa hat gestartet, also gerne im Blick behalten und dann direkt starten

**2025-09-19T13:28:28.389209** - Julia:
> cool danke! :slightly_smiling_face: komme heute noch nicht dazu mir die anzugucken aber am montag dann direkt!

**2025-09-19T14:44:00.021379** - Julia H. mentioned Julia:
> Okay. Finde die Bildauswahl nicht ganz so stark <@U09D64LA420> magst du auch einmal drauf schauen bitte? <@U093J779DAQ> Bis wann denkst du, hast du was zum zeigen?

**2025-09-19T15:14:06.586319** - Julia:
> habe noch ein paar orange markiert die man gut einsetzen könnte. ich denke 2 Slides mit jeweilig dem anderen Auto im Fokus könnte auch cool sein, oder? :slightly_smiling_face:

**2025-09-22T12:27:56.761569** - laetitia mentioned Julia:
> <@U08V6A47PKN> <@U09D64LA420> wollt ihr auf S. 7 noch meine Bildauswahl checken bevor ich es an Hanna weitergebe? habe auch einen Kommentar noch hinterlassen. Leider gibt es auch nicht sooo viel Bildauswahl finde ich <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7B4D6C66A4-616A-40AD-AF31-A368ECCF5E4B%7D&amp;file=250908_Porsche_BS_Sommerfest.pptx&amp;action=edit&amp;mobileredirect=true|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7B4D6C66[…]orsche_BS_Sommerfest.pptx&amp;action=edit&amp;mobileredirect=true>

**2025-09-22T13:30:29.287069** - Julia:
> hab keinen Zugriff leider 

**2025-09-22T14:16:44.840669** - Julia:
> <@U093J763E5A>
Ich würde die Reihenfolge noch etwas anpassen:
1. So lassen – oder gibt es noch ein Alternativ Bild von der gleichen Situation?
2. Junge mit Handy
3. Slide 2
4. lassen
5. Slide 7
6. Food
7. Targa (Slide 5)
8. lassen
9. lassen
Caption: Targa ohne Porsche?
Dankee dir :slightly_smiling_face:


---

### #mpdm-mert--julia.hallhuber--julia.hopper-1 (1 messages)

**2025-09-23T14:18:36.180319** - Julia:
> Hilfe was ist passiert


---

### #porsche-design (31 messages)

**2025-09-02T10:43:05.303689** - Julia:
> <@U09D64LA420> has joined the channel

**2025-09-03T09:41:14.315749** - Julia H. mentioned Julia:
> Hello Creative Boldies,
<@U0929T1BG0G> <@U093J779DAQ> <@U09D64LA420> denkt ihr wir bekommen bis Freitag hin einen aktuellen Stand des Styleguides mit Porsche zu teilen?

**2025-09-03T12:13:24.660859** - Julia:
> Lieber wäre mir Montag, wenn das auch okay ist? Würde mir gerne noch einen genaueren Überblick verschaffen mit welchen Mitteln wir arbeiten/ können. Was meint ihr?

**2025-09-03T12:16:21.384299** - Basti mentioned Julia:
> <@U08V6A47PKN> <@U09D64LA420> Yes bin ich auch der Meinung. Ich würd das ganze dann vom Look her auch erstmal gerne mit <@UNUQV5R08> besprechen, ob das für ihn auch so cool is und ja visuell noch überarbeiten wäre auch sinnvoll :smile:

**2025-09-03T14:38:05.814389** - Julia:
> Gerne! Könntet ihr mir den bisherigen styleguide einmal verlinken? Würde schon mal starten und euch dann natürlich asap dazu reinholen

**2025-09-04T08:45:27.499919** - Julia:
> Da gehts ums Übersetzen &amp; Text drauf setzen oder?
Kann ich gerne übernehmen

**2025-09-04T09:18:19.432289** - Julia:
> ich hab mich angemeldet :innocent::melting_face:

**2025-09-04T09:18:33.151789** - Julia:
> aber eigentlich haben wir ja 3 logins laut asana?

**2025-09-04T09:22:25.311049** - Julia:
> oh mist. gib mir noch paar minuten und dann kannst du mich rausschmeißen :slightly_smiling_face:

**2025-09-05T15:38:06.269069** - Julia:
> Help! :slightly_smiling_face: Wo finde ich denn das TINS Key Visual im Drive? Finde nur das zum TINS Day

**2025-09-05T15:41:13.935689** - Julia:
> nee das ist leider genau das falsche

**2025-09-05T15:41:30.234799** - Julia:
> brauche das hier.

Oder?

**2025-09-11T16:27:08.887949** - Julia:
> Hello <@U093J779DAQ> <@U0929T1BG0G> noch jemand am Start und könnte kurz Text auf ein Video legen? :slightly_smiling_face:

**2025-09-11T16:28:45.552989** - Basti mentioned Julia:
> <@U09D64LA420> ich bin grad los zur IAA und leider nicht mehr am Laptop :man-facepalming:

**2025-09-11T16:32:19.995009** - Julia:
> Okay, würde noch dauern :slightly_smiling_face: melde mich gleich. dankeee

**2025-09-11T16:48:52.781449** - Julia:
> dauert noch bissl

**2025-09-11T17:18:58.706739** - Julia:
> hat sich für heute erledigt. Würde sonst eine Asana Task erstellen für morgen :slightly_smiling_face: dankeee

**2025-09-11T17:19:14.695349** - Julia:
> all good! Sehen wir uns später?

**2025-09-11T17:27:53.731919** - Julia:
> Kann diesen Stil jemand von euch umsetzen? :) würden gerne proaktiv etwas vorstellen. Aber brauchen den Proof, dass wir das können 

**2025-09-11T18:04:42.023399** - Basti mentioned Julia:
> <@U09D64LA420> also ich bin jetzt bei Porsche 

**2025-09-11T18:31:11.858079** - Julia:
> Sind noch im Kabuff...

**2025-09-17T08:12:20.343069** - Julia:
> Guten Morgen :slightly_smiling_face: Bin mir garnicht sicher, wer alles da ist. Aber sollen wir heute morgen evtl. kurz sprechen was alles ansteht, passiert ist etc.?

**2025-09-17T10:20:08.642139** - Florian Listl mentioned Julia:
> <@U09D64LA420> du bist jetzt auch im porsche.deutschland Verteiler :slightly_smiling_face:

**2025-09-17T16:35:30.478019** - Mert Koc mentioned Julia:
> <@UNUQV5R08>
Das Video liegt hier: <https://drive.google.com/drive/folders/1YHczPYnPNueRE4sYJsfcD_UC32VnjqRD?usp=drive_link>

Falls es noch Anpassungen geben soll, kann ich das heute Abend machen, ich muss jetzt leider los.

<@U09D64LA420> <@U08V6A47PKN> FYI :slightly_smiling_face:

**2025-09-18T13:09:45.622509** - Julia:
> Eine Frage: wir *dürfen* keine Bilder spiegeln oder machen es einfach nicht? Klar, wenn die Schrift spiegelverkehrt ist. Aber zB Mood Bilder wie das hier?

**2025-09-18T13:12:44.336759** - Julia:
> 

**2025-09-22T17:37:42.956999** - Julia:
> Wen darf ich aus Adobe kurz rauskicken? :slightly_smiling_face:

**2025-09-29T12:12:53.869739** - Julia:
> Hello! :slightly_smiling_face: Gibt es irgendwo Content von Ferry Porsche den wir nutzen können? Hanna hatte das für den BS angefragt

**2025-09-29T12:25:05.058059** - Julia:
> ahh cool!

**2025-09-29T12:25:08.181969** - Julia:
> aber danke :slightly_smiling_face:

**2025-09-29T12:27:20.982879** - Julia:
> juhuuuu


---

### #porsche-general (41 messages)

**2025-09-02T10:43:12.631889** - Julia:
> <@U09D64LA420> has joined the channel

**2025-09-02T10:45:23.409899** - Julia H. mentioned Julia:
> WEEEELCOME <@U09D64LA420>

**2025-09-02T13:04:24.830199** - Julia:
> Hellooo, danke! Ich freu mich total dabei zu sein :heart_eyes:

**2025-09-04T10:23:12.601869** - Julia:
> Viel Erfolg!

**2025-09-05T12:38:47.421459** - laetitia mentioned Julia:
> <@U09D64LA420> <@U09D64LA420> Sommerfest/ 60 Jahre Targa Präsi liegt auf Asana ab

**2025-09-05T13:42:39.483959** - Julia:
> Sollen wir nochmal abstimmen?

**2025-09-08T12:18:38.342269** - Florian Listl mentioned Julia:
> Auf initiative von <@U09D64LA420> haben wir jetzt Figma :slightly_smiling_face:

<https://www.figma.com/team_invite/redeem/DKFChzNJhSyooJubf7bpEr>

Master login via Google:
<mailto:porsche.deutschland@boldcreators.club|porsche.deutschland@boldcreators.club>
PORSCHE@bcc_2025

**2025-09-08T12:19:48.276429** - Julia:
> Juhu! Danke :slightly_smiling_face: Ich lege sobald ich wieder am Laptop bin IAA File an. Hier können wir dann gemeinsam drin arbeiten und asap Änderungen anpassen

**2025-09-08T12:24:30.770599** - Basti mentioned Julia:
> ja leck noch n Tool mehr :smile:
<@U09D64LA420> macht es vielleicht Sinn, wenn du uns einen Termin einstellst für ne kleine Introduction zu den Tool?

**2025-09-08T12:26:08.064359** - Julia:
> jaa auf jeden Fall. Also da es eh nur relevant für Stills &amp; generelle Templates ist, würde ich das nächste Woche in Ruhe machen. Ist das okay für dich <@U0929T1BG0G>? Mert kennt sich damit schon aus und kann im Zweifelsfall ab morgen mit reinspringen :slightly_smiling_face:

**2025-09-08T12:27:33.743559** - Julia:
> True that :smile: So machen wir es

**2025-09-25T09:32:46.988639** - Julia:
> Jaaaa! Wollte Caption checken :fast_parrot:

**2025-09-25T17:16:22.080739** - Julia H. mentioned Julia:
> *Hello Boldies, da ich ja morgen off bin, hier eine kurze Auflistung der wichtigsten To Dos:*

<@UNUQV5R08> <https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1211464223666361?focus=true|Reporting Gipfeltreffen>
<https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BD3204CB4-6946-46A9-896D-D1E414A316B4%7D&amp;file=250925_UGC_Vorschla%CC%88ge_Master.pptx&amp;action=edit&amp;mobileredirect=true|UGC>: Habe endlich geschafft mal ein Update für UGC zu machen. Kannst gerne mal drüber schauen. Rest finalisieren Juli &amp; Mert

<@U09D64LA420> <@U093J779DAQ>
• <https://app.asana.com/1/1199360402832734/project/1211017007394565/task/1211026466791699|Retro Sunday>: Alles ist in Sprinklr gescheduled, nur die Stories noch nicht ---&gt; Werden wir erst Montag posten 
• <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BD3204CB4-6946-46A9-896D-D1E414A316B4%7D&amp;file=250925_UGC_Vorschla%CC%88ge_Master.pptx&amp;action=edit&amp;mobileredirect=true|UGC>: Bitte einmal Präsi prüfen und finalisieren
    ◦ <https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1210751511044934|Offene Daten zum Aufruf >haben wir jetzt (Bildmaterial not sure.. Vielleicht aus den alten <https://porsche.sharepoint.com/sites/PDMK/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FPDMK%2FShared%20Documents%2FGeneral%2FUMZUG%2FDigitales%20Marketing%2FSocial%2FInsta%2F08%5FRedaktionsplanung%2FContents%2F2025%2FUGC%2FMaterial&amp;viewid=6340b967%2Dd3d5%2D401d%2D9687%2D73af93fd1ecf&amp;csf=1&amp;web=1&amp;e=YdzFfu&amp;CID=7e2a435d%2D2939%2D41fb%2D9048%2D5ab214ca428f&amp;FolderCTID=0x012000B0A40330D7B2464BB054061397BEF042|Ordnern>?)
• <https://app.asana.com/1/1199360402832734/project/1211017007394565/task/1210983935124110|Brand Store Konzept> --&gt; Posts für kommende Woche ausarbeiten/finalisieren
• <https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1211450829020501|Wiesn-Post> finalisieren &amp; an Charly
• <https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1210703906249623|Porsche DE: Postings >November planen  (Porsche Points, etc...)
<@U093J779DAQ>
• <https://app.asana.com/1/1199360402832734/project/1211017007394565/task/1211196394933806|USA Community Post >Videos auf 4:5 croppen und an Hanna 
• <https://app.asana.com/1/1199360402832734/project/1210522556460237/task/1210997489529401?focus=true|Sonderwunsch> Videos - Anpassungen an Jana
<@U09D64LA420>
• <https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1210556034500746|Leonie Beck Video> final review --&gt; an Charly &amp; Marie
• Saturday Tunes Slide: Draft in Sprinklr anpassen
• Arthur Kar 3 Stories händisch posten 12 Uhr

**2025-09-25T17:46:15.241649** - Julia:
> Danke dir und bis Montag! :slightly_smiling_face:

**2025-09-26T08:48:43.506329** - Julia:
> <@U093J779DAQ> könntest du mir die UGC Präsi runterladen und schicken? Hab leider keinen Zugriff

**2025-09-26T12:00:08.440519** - Julia:
> Update Übersicht:
• USA Community Post --&gt; rausgeschickt/ noch kein Feedback
• Leonie Beck Video --&gt; rausgeschickt/ noch kein Feedback
• Wiesn Post --&gt; rausgeschickt/ noch kein Feedback
• Arthur Kar --&gt; gleich online
• Arthur Kar Reminder --&gt; freigegeben &amp; auf Sprinklr
• Saturday Tunes --&gt; angepasst
• Sonderwunsch Videos --&gt; laden gerade hoch
• Reporting Gipfeltreffen --&gt; sind dran, kann mittags raus
• BS: Posts ausarbeiten --&gt; noch kein Grundriss von Agentur, aber bereiten schon mal Rest vor. Mert erstellt Draft für Konfi/ Colour Post
• UGC Präsi --&gt; fügen heute noch Kommentare ein
• November Posting --&gt; je nachdem wieviel ich heute noch schaffe

**2025-09-26T17:34:09.177889** - Julia:
> *Update der noch offenen Themen:* <@U08V6A47PKN> <@UNUQV5R08>

• <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BD3204CB4-6946-46A9-896D-D1E414A316B4%7D&amp;file=250925_UGC_Vorschla%25u0308ge_Master.pptx&amp;action=edit&amp;mobileredirect=true|UGC Prozess Präsi:> habe noch einiges an UGC hinzugefügt + würde gerne testen, ob sie sich auf Reels die etwas nahbarer sind und man super mit der Community in Austausch treten kann, einlassen + neue Storyslides für den Aufruf von <@U093J779DAQ> liegen ebenso ab
• <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BE33428F9-BF0F-4720-B9FE-D8EDF165E52E%7D&amp;file=250924_Porsche_BS_SoMe_Konzepte_JH.pptx&amp;action=edit&amp;mobileredirect=true|Brand Store Präsi:> Haben eine neue Kategorie "Weekly Trends" eingeführt bei denen wir Hanna (&amp; Charly dann natürlich auch in einer gesonderten Präsi) unsere Empfehlungen für Trends zeigen + Story des Rundgangs liegt ab (ohne Grundriss --&gt; haben die Datei immernoch nicht, aber habe mit "Driven for Dreams" einen Ersatz gefunden) + erster Draft Konfi. Post und Story von <@U093J779DAQ> :sparkles: 
--&gt; habe Hanna Bescheid gegeben, dass hier etwas abliegt for approval

• November Postings: schau ich mir direkt am Montag an, heute nichtmehr geschafft
Happy weekend! :slightly_smiling_face:

**2025-09-29T10:49:47.424029** - Julia:
> *Kurze Zusammenfassung von Meeting eben*

An Charly geschickt und warten auf Feedback:
• Leonie Beck Video
• Wallpaper // Drafts wegen VBWs
• Sonderwunsch
• Wiesn Post
To Do/ Wünsche seitens Charly:
• Modell der Woche --&gt; asap an Charly schicken /Faktencheck: belegt?
• Halloween asap verschicken (Bitte Feedback Flo/ Julia)
• TINS Assets checken PAG —&gt; bis Mittwoch
• SOS Post Turbo S einplanen
• Red Dots Design Award anschauen
• Insider Posts —&gt; Florian Trettenbach Sylt Fotos --&gt;  Single Image Posts + Gipfeltreffen --&gt; bis Donnerstag
• Alltags Drive Post checken 

**2025-09-29T13:50:47.813129** - Florian Listl mentioned Julia:
> <@U09D64LA420> wichtig, wenn wir einen Report hochladen, müssen wir online in sharepoint immer nochmal die Schrift anpassen - weil sharepoint das vergeigt. Geht ganz schnell, aber nur, dass du dich nicht wunderst, wieso das so durcheinander aussieht

**2025-09-29T14:10:08.897149** - Florian Listl mentioned Julia:
> <@U09D64LA420> <@U08V6A47PKN> Habt ihr Charlys WhatsApp Nachricht bzgl Verbrauchswerten gesehen? :)

**2025-09-29T14:31:15.272869** - Julia H. mentioned Julia:
> <@UNUQV5R08> <@U09D64LA420> ihr müsstet bitte morgen nochmal das Daily mit Charly ohne mich machen. Ich lande um 9:30 erst :disappointed:

**2025-09-29T14:37:32.094059** - Julia:
> jetzt ja! Soll ich mal Captions vorschlagen?

**2025-09-29T14:37:57.841629** - Julia:
> Ach ist das echt ein Daily? Okay!

**2025-09-29T14:38:37.024819** - Julia:
> Okay :slightly_smiling_face: Jaa ist mir auch schon aufgefallen, dass das immer alles zerhaut..

**2025-09-29T14:52:13.001189** - Julia:
> Mal 2 Vorschläge angelehnt an Püntis lockeren Aufsager:

Kaum zu glauben aber wahr: Das Porsche Gipfeltreffen 2025.
Danke an die #PorscheFamily für unvergessliche Tage.
---
IYKYK: Das Porsche Gipfeltreffen – wie immer ein Highlight. Danke an die gesamte #PorscheFamily.

**2025-09-29T15:28:51.268289** - Florian Listl mentioned Julia:
> <@U09D64LA420> ich hab dich in alle Dailies mit Porsche eingeladen :slightly_smiling_face:

**2025-09-29T15:45:26.168939** - Julia:
> Schadé

**2025-09-29T17:23:32.272419** - Julia:
> woran liegt es jetzt, dass es hier wieder keine Porsche Font gibt? :smile: ich dreh durch

**2025-09-29T17:29:45.147159** - Julia:
> Ahhhh. Kannst dus mal probieren? Weil ich meine ich hab folgendes rausgefunden: wenn ich auf ein Dokument Zugriff hatte, dann hab ichs danach auch öffnen können :smile:

**2025-09-30T11:38:21.626079** - Florian Listl mentioned Julia:
> <@U08V6A47PKN> Bilder von Lattke liegen hier ab: <https://drive.google.com/drive/folders/1VFAueLLUHEN8hJJlhyIsOHUpCF8JF5Vs>

Unter dem Link liegen leider keine Bilder, die braucht <@U09D64LA420> für die PPT, kann es sein, dass die Bilder woanders hin verschoben wurden?

**2025-09-30T11:52:21.766699** - Julia H. mentioned Julia:
> <@U09D64LA420> kann man sich da die Dateien rausziehen mit Photoshop oder so?

**2025-09-30T11:53:51.653029** - Julia:
> Roxanne ist leider nicht erreichbar.. ich versuche es, aber I daut it..

**2025-09-30T12:03:40.979549** - Florian Listl mentioned Julia:
> <@U08V6A47PKN> Kannst du Ariane fragen, ob sie uns den Link zum Drive mit allen Bildern schicken kann?

Gern als email nur an Ariane, mit Juli in CC - aber Porsche nicht 


<@U09D64LA420> wähle gern trotzdem schon mal die besten Bilder via PDF aus. Dann tun wir uns danach leichter

**2025-09-30T12:05:51.852369** - Florian Listl mentioned Julia:
> Top, für die story Präsentation kannst du gern die Bilder aus dem pdf nutzen <@U09D64LA420> 

Roxanne hat auch nicht mehr Bilder als in den PDFs :)

**2025-09-30T12:16:51.176199** - Julia:
> <@UNUQV5R08> mach ich. Allerdings sind die "Story Slides" glaube ich nur Screenshots aus dem Video. Das liegt nicht in den PDFs drin.

<@U08V6A47PKN> das wären die Bilder:

06_CMP416_LeonieBeck_byTobiasKempe_midres_DSC00351.jpg

01_CMP416_LeonieBeck_byTobiasKempe_midres_DSC00765.jpg

02_CMP416_LeonieBeck_byTobiasKempe_midres_DJI_20250520071725_0026_D_TK_fein_116_3Pro...

05_CMP416_LeonieBeck_byTobiasKempe_midres_DSC00889.jpg

04_CMP416_LeonieBeck_byTobiasKempe_lowres_DSC09510.jpg

06_CMP416_LeonieBeck_byTobiasKempe_lowres_L1020298.jpg

CMP416_LeonieBeck_byTobiasKempe_lowres_DSC00484.jpg

CMP416_LeonieBeck_byTobiasKempe_midres_DSC00321.jpg

CMP416_LeonieBeck_byTobiasKempe_midres_DSC01273.jpg

CMP416_LeonieBeck_byTobiasKempe_midres_DSC00895.jpg

07_CMP416_LeonieBeck_byTobiasKempe_lowres_DSC00604.jpg

CMP416_LeonieBeck_byTobiasKempe_lowres_DJI_20250520072101_0034_D.jpg

CMP416_LeonieBeck_byTobiasKempe_lowres_DSC00696.jpg

CMP416_LeonieBeck_byTobiasKempe_lowres_DSC008402.jpg

CMP416_LeonieBeck_byTobiasKempe_lowres_L1020262

CMP416_LeonieBeck_byTobiasKempe_lowres_DSC01124.jpg

CMP416_LeonieBeck_byTobiasKempe_midres_DSC01273.jpg

**2025-09-30T12:25:28.522859** - Julia:
> + CMP416_LeonieBeck_byTobiasKempe_lowres_DJI_20250520072101_0034_D.jpg

**2025-10-01T10:55:50.565609** - Florian Listl mentioned Julia:
> Hi Leute :slightly_smiling_face: Ich glaube wir hatten Charly gesagt, dass wir die bis heute oder Donnerstag schicken oder? <@U09D64LA420>

**2025-10-01T11:01:47.322989** - Julia:
> wir haben die "Insider" ja vorgezogen, das war eigentlich für morgen geplant

**2025-10-06T19:30:26.076539** - Florian Listl mentioned Julia:
> <@U08V6A47PKN> <@U09D64LA420> <@U093J779DAQ> Hi Leute, ich hab uns einen Termin für morgen 9 Uhr eingestellt, bitte alle kommen

**2025-10-09T09:57:50.649809** - Julia:
> Hello! <@UNUQV5R08> kommst du heute in den Daily Huddle? :slightly_smiling_face:

**2025-10-16T16:40:01.785669** - Julia:
> Hello! Sollen wir  Figma eigentlich für ab November wieder kündigen oder behalten wir das Tool?


---

### #sixt-design (1 messages)

**2026-01-08T14:21:37.571149** - Julia:
> <@U09D64LA420> has joined the channel


---

### #sixties (1 messages)

**2026-02-16T17:46:53.341799** - Julia:
> <@U09D64LA420> has joined the channel


---

### #what-the-fuck (5 messages)

**2025-11-18T15:47:54.328019** - Julia:
> <@U09D64LA420> has joined the channel

**2025-11-26T10:05:03.985189** - Julia:
> Hi zusammen! Ich hab folgende Herausforderung: wir sind gerade dabei TikTok Shops verschiedener Marken zu vergleichen. Allerdings geht das nur für deutsche Shops. Wir würden allerdings gerne für einen generellen Überblick auch die Shops aus UK, US usw. vergleichen.  Mit VPN + neuem TikTok Account soll das angeblich klappen. Ich selbst hab aber keinen VPN, hat jemand eine Lösung? Danke schon mal! :slightly_smiling_face:

**2025-11-26T10:08:59.450799** - Julia:
> ich check's mal mit dem iPhone, danke euch!

**2026-01-12T14:48:50.327249** - Julia:
> Hi zusammen! :slightly_smiling_face: Für einen Pitch-Dreh benötigen wir ein männliches Model, das als SSIO-Double durchgehen könnte. Leider haben wir bei Komparsen-/ Modelagenturen noch kein Glück und nur Absagen. Hat jemand hier im Bekanntenkreis evtl. jemand der in Frage kommen würde?
Timing: Ende dieser Woche/ Anfang nächster Woche, max. halber Tag (eher 2 Std.)
Location: am besten direkt in München
:crossed_fingers:

**2026-01-12T15:05:14.355579** - Julia:
> jaa hatten wir auch so Plan B, Pitbull Style :joy:


---

