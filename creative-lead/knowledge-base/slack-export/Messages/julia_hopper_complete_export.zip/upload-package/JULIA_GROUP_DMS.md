# Julia Hopper - Complete DM Export

**User ID:** U09D64LA420
**Email:** julia.hopper@boldcreators.club
**Export Date:** 2026-02-16 19:33:11

---

## Summary

- **1:1 Direct Messages:** 6
- **Group Messages (MPDM):** 12
- **Total DM Conversations:** 18

---

## 1:1 Direct Messages

### Basti (77 messages: 47 from Julia, 30 from Basti)

**Folder:** `D09E76RSBNF`

2025-09-09T16:53:11.031439 - **Julia:**
> Hello! :slightly_smiling_face: Es gab beim Styleguide ja einen Kommentar bezüglich der VBWs. Könntest du diese für dieses Visual Template rausnehmen und mir kurz schicken? Würde es dann im Styleguide ersetzen

  📎 Bildschirmfoto 2025-09-09 um 16.52.17.png

2025-09-09T16:53:25.697019 - **Julia:**
> Julia möchte den Styleguide jetzt rausschicken

2025-09-09T16:53:46.413829 - **Basti:**
> Yes mach ich

2025-09-09T16:53:50.181249 - **Julia:**
> dankeee

2025-09-09T17:22:04.714469 - **Basti:**
> Passts so :slightly_smiling_face:?

  📎 Zeichenfläche 1.png

2025-09-09T17:26:31.013289 - **Julia:**
> nice! Ich brauch es allerdings in der IG Vorschau :slightly_smiling_face:

2025-09-09T17:54:58.094799 - **Julia:**
> Bist du noch da? :slightly_smiling_face:

2025-09-09T18:19:21.507159 - **Basti:**
> Hey ja sorry war im Gespräch mit dem Flo

2025-09-09T18:20:15.530139 - **Basti:**
> Das war aber YouTube in dem Fall :joy: 

2025-09-09T18:27:01.427369 - **Basti:**
> 

  📎 Bildschirmfoto 2025-09-09 um 18.26.31.jpeg

2025-09-09T18:34:54.228409 - **Julia:**
> auch okay :smile: Dankeee

2025-09-23T17:08:37.492999 - **Basti:**
> Hey sorry nochmal aber bis wann brauchst du das Christo dings Video ding da :smile:?

2025-09-23T17:09:12.366039 - **Julia:**
> Hello :slightly_smiling_face:

2025-09-23T17:10:16.482149 - **Julia:**
> also am 25.9. kommt die Zeitschrift mit ihr aus. Wenn wir es am gleichen Tag posten könnten, wäre mega --&gt; aber da eh Gipfeltreffen ist, denk ich wirds dann erst später zum Wochenende passend

2025-09-23T17:11:20.767029 - **Basti:**
> okay aber bedeutet ich kann mich da morgen dran setzen das sollte reichen...

2025-09-23T17:12:00.349879 - **Julia:**
> Ja, morgen sollten wir Porsche mal unseren Vorschlag schicken aber die haben eh grad andere Themen :smile:

2025-09-23T17:12:01.064439 - **Basti:**
> Mir kam Marvin mit SIXT heute unerwartet mit nem dringenden Schnitt dazwischen das hat mir meine Planung für den Porsche Schnitt leider voll verhauen

2025-09-23T17:12:15.857639 - **Julia:**
> alles gut :slightly_smiling_face:

2025-09-25T15:42:21.285029 - **Basti:**
> Hey hey, hab dir das Video neu rausgerechnet und die Schwimmszenen eingebaut. Find auch die passen super rein und machen nochmal ne sehr schöne Verbindung von ihr zum Porsche: <https://drive.google.com/file/d/1_JFCYMOQpscL2Qntpl36LU3jXELUc1vi/view?usp=sharing>

  📎 250925_Porsche_DE_ChristoShooting_9x16_v1.mp4

2025-09-25T17:25:38.112589 - **Julia:**
> Hello! Sorry für meine späte Antwort, war etwas im Stress. Danke Basti! :slightly_smiling_face: Sieht super aus

2025-09-25T17:26:12.514109 - **Julia:**
> Wo legt ihr die Videos normalerweise für Porsche ab? Würde ihnen gerne den Sharepoint Link schicken. Magst du mir diesen einmal schicken? (Ich hab teilweise noch keinen Zugriff) Dann leite ich es direkt weiter

2025-09-26T09:19:49.268959 - **Basti:**
> Die liegen von unserer Seite aus immer auf Drive ab. Wie die dann zu Porsche kommen weis ich leider auch nicht ab dem Moment wo wir euch das finale Asset schicken sind wir bisher eigentlich immer raus gewesen :smile:

2025-09-26T09:41:35.352959 - **Julia:**
> Okay :slightly_smiling_face: Ich frag mal Mert

2025-09-30T15:23:44.975869 - **Julia:**
> Hello! :slightly_smiling_face: Bezüglich dem Leonie Video:

2025-09-30T15:24:04.188279 - **Basti:**
> huhu hab ich grad schon auf Asana gesehen :slightly_smiling_face:

2025-09-30T15:24:58.294739 - **Julia:**
> Julia hatte dich ja schon gefragt wegen der Stimme. Charly gefällt diese nicht bzw. folgendes Feedback "Diese klingt aktuell noch etwas starr. Falls es nicht Leonie ist, können wir die Stimme ersetzen oder weglassen?"

Komplett weglassen würde ich nicht. Haben wir die Möglichkeit das zu ersetzen?
Würde es dann auch nochmal in Asana aufnehmen

2025-09-30T15:28:51.614089 - **Basti:**
> Ja genau is ne KI Stimme, klar da gibts viele die können wir ersetzen, aber ich sag gleich vorab ich hab dir nicht ohne Grund genommen :smile: Die hat von der Betonung und Stimmfarbe schon recht gut zu ihr gepasst also obs wirklich besser wird werden wir sehen. Aber ja gibt auf jeden Fall Möglichkeiten :slightly_smiling_face: Mach ich dann morgen alles in einem Abwasch. Wenn du magst und/oder Zeit hast kannst du natürlich aber auch auf Artlist selbst schauen welche Stimme dir gefallen würde. Ansonsten bekommst es morgen von mir :slightly_smiling_face:

2025-09-30T15:30:43.900149 - **Julia:**
> ja denk ich mir. Aber soweit kommt Porsche natürlich nicht – als würden wir uns jemals Gedanken machen :smile:
Such du gerne aus, ich geb ihr Rückmeldung, dass wir es anpassen können

2025-09-30T15:32:37.694919 - **Julia:**
> Heute hast du keine Kapa mehr oder? Haben morgens einen kleinen Einlauf von Charly bekommen, weil das Thema schon etwas liegt..

2025-09-30T15:34:13.804559 - **Basti:**
> Doch kann mich auch heute schon drum kümmern aber was macht das für einen Sinn wenns eh noch von Leonie approved werden muss?

2025-09-30T15:34:23.800809 - **Julia:**
> ja I know

2025-09-30T15:34:53.479519 - **Julia:**
> genau das hab ich ihr jetzt auch geschrieben. Ob sie es Leonie so zeigen will oder schon mit neuer Stimme. Gebe dir asap ein Update

2025-09-30T15:35:02.952269 - **Julia:**
> Danke :face_exhaling:

2025-09-30T15:35:39.783059 - **Basti:**
> okay ja dann geb mir einfach bescheid :slightly_smiling_face:

2025-09-30T15:36:38.227509 - **Basti:**
> "Einlauf von Charly"... gibts von der überhaupt was anderes?

2025-09-30T15:36:45.209329 - **Julia:**
> :joy:

2025-09-30T15:36:48.535509 - **Julia:**
> Scheinbar nicht

2025-09-30T17:23:47.805709 - **Julia:**
> Hab dir Charly's Mail weitergeleitet

2025-09-30T17:28:16.956599 - **Basti:**
> Okay also kicken wir das VO... Also für Charlys Info, rein rechtlich dürfen wir das verwenden. Wir haben extra einen Account dafür mit Lizenzen für commercial. Wenn sie seitens Porsche das nicht dürfen ist das ne andere Geschichte, dann kann man nur sagen...bitte kommt ins Jahr 2025 :joy:

2025-09-30T17:31:23.258729 - **Julia:**
> ja wir hatten das heute auch schon mit Bildern die ich erstellt hatte – AI ist der Feind!!!

2025-09-30T17:31:24.280309 - **Julia:**
> :smile:

2025-10-01T09:21:34.688159 - **Basti:**
> Okay VBW´s sind angepasst warte nur auf euer "Go" dann rechne ich euch das Video raus.

2025-10-01T09:21:55.450669 - **Julia:**
> cool danke!

2025-10-01T09:22:22.507479 - **Julia:**
> Charly schickt heute alles an Leonie und holt ihre Freigabe. geb dir dann bescheid

2025-10-08T15:35:41.451819 - **Julia:**
> Hello! :slightly_smiling_face: bist du heute da?

2025-10-08T15:52:40.737379 - **Basti:**
> Hi ne sorry bin heute für Sixt auf Dreh 

2025-10-08T16:41:47.236449 - **Julia:**
> ah okay! Bist du morgen wieder da?

2025-10-08T17:05:46.564579 - **Basti:**
> Muss ich mal schauen bin leider am kränkeln und weis nicht wie mich der Tag heute vollends zerlegt oder nicht :grimacing: aber prinzipiell bin ich da ja 

2025-10-08T17:28:13.104339 - **Julia:**
> ach mist, dann halte gut durch! :heart_hands:

2025-10-09T09:39:51.785959 - **Basti:**
> Moin Juli, also mir gehts tatsächlich nicht schlechter als gestern also bin ich heute am Start. Wie kann ich dir helfen :slightly_smiling_face:?

2025-10-09T09:57:07.999999 - **Julia:**
> Hello! :slightly_smiling_face: okay gut

2025-10-09T09:57:10.752709 - **Julia:**
> Wie war der Dreh?

2025-10-09T09:57:21.072019 - **Julia:**
> Wir müssten heute das Leonie Video fertig bekommen

2025-10-09T10:01:39.789969 - **Basti:**
> War ganz gut, aber viel :smile: Selten gibts ne Mittagspause auf Dreh und ehe man sich versieht hat man n 10 Stunden Tag durch geballert :grimacing:

2025-10-09T10:01:55.757669 - **Basti:**
> Ja alles klar, da müssen ja nur die VBW´s angepasst werden wenn ich das richtig verstanden hatte?

2025-10-09T10:08:01.551469 - **Julia:**
> ja glaub ich dir sofort, total!

2025-10-09T10:08:05.015729 - **Julia:**
> genau :slightly_smiling_face:

2025-10-09T10:08:24.988589 - **Julia:**
> am besten verlinkst du dann in asana direkt Julia – sie übernimmt den Upload :slightly_smiling_face: danke dir

2025-10-09T10:08:55.892229 - **Basti:**
> Alles klar mach ich danke dir :slightly_smiling_face:

2025-10-09T11:19:23.898229 - **Basti:**
> Hier das Video mit den aktuellen VBW´s. Ich leite den Link und Asana an Julia H. weiter: <https://drive.google.com/file/d/1zJTmqauZITlgn17uVs9AJ44oW_I5LGBr/view?usp=drive_link>

  📎 251009_Porsche_DE_ChristoShooting_9x16_v1.mp4

2025-10-09T13:19:59.679179 - **Julia:**
> danke!

2025-11-21T09:46:15.661669 - **Julia:**
> Hello! :slightly_smiling_face: Bist du heute im Büro? Würde mich sonst an deinen Platz setzen – ziemlich voll heute haha

2025-12-05T15:37:37.426969 - **Basti:**
> Hey hey, denkst du bitte daran mir noch bescheid zu geben bezüglich dem Mittwoch? Merci :)

2025-12-05T15:46:02.189479 - **Julia:**
> Hello! 

2025-12-05T15:46:14.403989 - **Julia:**
> Yes, hab’s eben gelesen: Mittwoch ist der Dreh. Ist jetzt final 

2025-12-05T15:46:24.174909 - **Julia:**
> Haben dieses Licht unterm Schreibtisch bei dir gelassen 

2025-12-05T15:51:48.379659 - **Basti:**
> Alles klar danke dir

2025-12-05T15:58:24.863449 - **Julia:**
> Danke dir! 

2025-12-11T10:43:58.856189 - **Julia:**
> Hello! Sind in paar Minuten im Büro mit der Technik 

2025-12-11T11:23:10.732549 - **Basti:**
> danke euch :slightly_smiling_face:

2026-02-10T14:27:34.726279 - **Basti:**
> GUTE BESSERUNG :grin::raised_hands:

2026-02-10T15:28:39.176559 - **Julia:**
> Danke dir :heart_hands:

2026-02-16T09:45:41.246449 - **Julia:**
> Hello! Findet der CheckIn statt? :slightly_smiling_face:

2026-02-16T10:24:59.014289 - **Julia:**
> Marvin meinte du bist da mit drin, deshalb :slightly_smiling_face:
Aber alles gut. Ich hab 2 Themen die sie meinten, die offen sind und ich ihnen ein Update geben sollte:
• Car Edit Monstertruck
• Desicion Video BeamNG

2026-02-16T12:02:49.851539 - **Basti:**
> Hi Juli, ich bin leider krank 

2026-02-16T12:22:05.009309 - **Julia:**
> ach Mist! Dann gute Besserung :crossed_fingers:

2026-02-16T12:22:26.538239 - **Basti:**
> Ja danke dir :)


---

### Florian Listl (554 messages: 253 from Julia, 301 from Florian Listl)

**Folder:** `D09CX8LTPGB`

2025-09-02T06:46:44.451979 - **Julia:**
> Julia Hopper accepted your invitation to join Slack — take a second to say hello.

2025-09-04T10:18:40.384469 - **Julia:**
> Hi Flo! Ich hoffe du hast einen schönen Urlaub – trotz der Nachrichten gestern!

Ich wollte einmal schon ein Thema für nächste Woche vormerken:
Es würde meiner Meinung nach sehr viel Sinn machen in Zukunft mit Figma zu arbeiten. Hier können wir den benötigten Still Content super schnell erstellen und müssen keine einzelnen Dateien anlegen, erstellen usw usw. Oder wie jetzt gerade mit Mert uns mit den Abobe Lizensen teilen. Hier kann man einen Benutzen anlegen und teilen &amp; vor allem gleichzeitig darin arbeiten – das einiges erschnellt :slightly_smiling_face:

2025-09-04T11:06:20.115579 - **Florian Listl:**
> Hi Juli :) ich finde super, dass du proaktiv die Initiative ergreifst

2025-09-04T11:06:49.284169 - **Florian Listl:**
> Ich kenn mich mit Figma nicht aus, ihr seid die Profis - lasst uns das gerne testen!

2025-09-04T11:07:21.251039 - **Florian Listl:**
> Ich hoffe deinen ersten 1-2 Tage waren schön und du hast dich beim Team gut eingelebt- einige kennst du ja auch schon :)

2025-09-04T11:37:25.412809 - **Julia:**
> Okay super :slightly_smiling_face: Dann können wir das ja am Montag besprechen

2025-09-04T11:37:53.709829 - **Julia:**
> auf jeden Fall! Ist super spannend &amp; so ganz blicke ich noch nicht durch, aber das kommt ja eh mit der Zeit

2025-09-04T20:36:02.151349 - **Florian Listl:**
> genau, das machen wir!

2025-09-04T20:36:31.652689 - **Julia:**
> Ich wollte dir eben noch den Personalfragebogen schicken. Hatte hier noch gesehen, dass das Gehalt tatsächlich falsch eingetragen ist. Also ich sag nicht  natürlich Nein haha! Aber sollte evtl. angepasst werden :)

  📎 Bildschirmfoto 2025-09-04 um 20.36.11.png

2025-09-05T14:09:13.027599 - **Florian Listl:**
> Haha danke! stimmt!

2025-09-05T14:09:26.037069 - **Florian Listl:**
> Passe ich direkt nach dem Urlaub an!

2025-09-08T08:07:25.835829 - **Julia:**
> Guten Morgen Flo! :slightly_smiling_face: Die Anmeldung bei Teams klappt mit der Adresse irgendwie nicht wirklich. Da kommt immer eine Fehlermeldung

2025-09-08T08:32:26.586859 - **Florian Listl:**
> Guten Morgen :) lass es uns zusammen anschauen, ich bin in 20-30 min im
Office

2025-09-08T08:50:03.947969 - **Julia:**
> Gerne. Ich fahre jetzt auch los

2025-09-08T09:30:50.720609 - **Julia:**
> Würde hier "Professional" empfehlen: <https://www.figma.com/de-de/pricing/#features>

2025-09-08T22:51:19.735649 - **Julia:**
> Hallo! Magst du mir das nochmal neu schicken oder soll ichs anpassen?

2025-09-10T09:00:34.954429 - **Julia:**
> Guten Morgen, sorry es ging gestern dann doch wieder länger. Ich meld mich wenn ich gleich auf dem Weg bin

2025-09-14T13:31:03.955479 - **Julia:**
> Hello! Wir sind heute doch nochmal am arbeiten &amp; am Content finalisieren für morgen. Warten gerade auf Feedback.
Porsche will nochmal ein paar Recap Slides für morgen etc. etc. Die meisten Assets werden dann heute schon gescheduled, ansonsten denke ich wird Julia morgen den Rest posten.
Ich würde mir dann morgen schon mal als Ausgleich für Samstag nehmen und je nachdem was dir lieber ist, direkt Dienstag oder Freitag dann den halben Tag von heute – hoffe es bleibt dabei

2025-09-14T13:32:00.841609 - **Florian Listl:**
> Puh das tut mir leid, hart dass ihr heute auch noch ran müsst

2025-09-14T13:32:09.923609 - **Florian Listl:**
> Lass uns mo und di machen 

2025-09-14T13:32:21.915189 - **Florian Listl:**
> Danke!!

2025-09-14T17:52:11.519559 - **Julia:**
> Ja wirklich etwas nervig... sind noch dran. Versuchen sie von unserer Empfehlung zu überzeugen

2025-09-14T17:52:36.852279 - **Julia:**
> Passt! Bin dann Mittwoch wahrscheinlich auch im Büro

2025-09-15T09:23:15.146959 - **Florian Listl:**
> Top! :) Ich freu mich!

2025-09-18T16:33:18.309969 - **Florian Listl:**
> oh das müssen wir noch anpassen :sweat_smile:

  📎 image.png

2025-09-18T16:33:47.931759 - **Julia:**
> Jaaa. Hab auch immer Probleme mit der Anmeldung :smile:

2025-09-18T16:33:59.721209 - **Julia:**
> Kannst du als Admin das anpassen?

2025-09-18T16:34:48.930369 - **Florian Listl:**
> Ich checke mal, bei uns heißt du schon Hopper, aber auf dem Porsche Tool noch nicht. Ich checke das mal

2025-09-18T16:35:08.409039 - **Julia:**
> okay, danke :smile:

2025-09-23T09:13:59.186839 - **Julia:**
> Hi Flo, ich bin leider garnicht fit. Hab nachts Migräne bekommen, die immer noch etwas da ist. Ich versuch das Reporting auf jeden Fall fertig zu bekommen, sobald es mir besser geht.

2025-09-23T10:08:02.668399 - **Florian Listl:**
> Hi Juli, gute Besserung! Danke für's bescheid geben!

2025-09-23T12:38:43.913209 - **Julia:**
> daanke dir

2025-09-23T12:39:27.557499 - **Julia:**
> Ich versuch gerade wenigstens das Reporting fertig zu stellen. Aber noch eine Frage: Haben wir denn für den BS schon irgendwelche KPIs/ Ziele definiert? Das hatte ich gestern vergessen zu fragen

2025-09-23T12:40:05.643289 - **Florian Listl:**
> Gute Frage. Hilft es dir, wenn ich ein reporting fertigstelle und du die anderen adaptierst? Sozusagen als Blueprint

2025-09-23T12:43:09.980039 - **Julia:**
> ich würde es jetzt so erstellen wie gestern besprochen und dann schicke ich es dir eh zum checken. daraus entsteht dann wahrscheinlich der Blueprint, oder?

2025-09-23T12:47:46.955269 - **Florian Listl:**
> gerne - ich wollte dir nur anbieten, dass ich die Vorlage erstelle

2025-09-23T12:47:52.189709 - **Florian Listl:**
> weil dir geht's ja heute nicht gut

2025-09-23T12:48:55.773609 - **Florian Listl:**
> lass mich das mal machen, dann kannst du dich noch bisschen ausruhen

2025-09-23T12:49:10.720279 - **Florian Listl:**
> kannst du mir die Notes noch schnell schicken von gestern?

2025-09-23T12:49:15.034109 - **Florian Listl:**
> einfach als Foto reicht

2025-09-23T12:57:34.784049 - **Julia:**
> ach danke dir, das ist wirklich sehr lieb

2025-09-23T12:57:42.637909 - **Julia:**
> Warte ich schick dir auch schon mal was ich anfangen hab

2025-09-23T12:57:47.783059 - **Florian Listl:**
> top

2025-09-23T13:01:41.073839 - **Julia:**
> 

  📎 Bildschirmfoto 2025-09-23 um 13.01.27.png
  📎 Bildschirmfoto 2025-09-23 um 13.01.20.png

2025-09-23T13:02:42.180819 - **Julia:**
> 

  📎 202508_BrandStore_Reporting_August_JH.pptx

2025-09-23T13:09:28.141169 - **Florian Listl:**
> danke!

2025-09-23T13:09:39.202499 - **Florian Listl:**
> kannst du mir auch noch kurz diese Content Haus Slide weiterleiten?

2025-09-23T14:17:54.154419 - **Julia:**
> 

  📎 Bildschirmfoto 2025-09-22 um 15.26.53.png

2025-09-23T23:34:54.094389 - **Florian Listl:**
> FYI :slightly_smiling_face: Ich hoffe es geht dir besser!

  📎 20250923_BrandStore_Reporting_August.pptx

2025-09-24T07:47:45.513939 - **Julia:**
> cool, das hilft mir auf jeden Fall für die nächsten Male! :pray: 

2025-09-24T07:50:19.435919 - **Julia:**
> Leider nein, wollte mich deshalb auch gerade melden, mich hats dann komplett zerlegt. Hab abends hohes Fieber bekommen. Bin leider  immer noch fiebrig.. :sob: ich würde mich heute dann komplett krankmelden, damit ich morgen wieder voll am Start sein kann 

2025-09-24T08:46:10.783109 - **Florian Listl:**
> Okay, wie sieht die ppt mit den Ideen von Brand Store aus?

2025-09-24T08:46:20.724769 - **Florian Listl:**
> Sind die Andeutungen schon eingearbeitet?

2025-09-26T08:24:07.116179 - **Florian Listl:**
> Guten Morgen :)

2025-09-26T08:24:22.788919 - **Florian Listl:**
> Lass uns gern mal bzgl dem reporting sprechen, sobald du available bist

2025-09-26T08:38:13.269349 - **Julia:**
> Hello!

2025-09-26T08:38:46.249009 - **Julia:**
> Vielleicht vor unserem Huddle? Oder bist du da garnicht dabei?

2025-09-26T08:45:47.200149 - **Florian Listl:**
> Gern

2025-09-26T08:46:00.990099 - **Florian Listl:**
> Normalerweise bin ich da nicht dabei, aber heute ist es vlt sinnvoll :)

2025-09-26T08:53:59.928089 - **Julia:**
> perfekt

2025-09-26T09:10:47.429579 - **Florian Listl:**
> 9:30?

2025-09-26T09:17:09.372779 - **Florian Listl:**
> Kannst du auf den Link zugreifen und die PPT bearbeiten? <https://porsche.sharepoint.com/:p:/r/sites/PDMK/Shared%20Documents/General/UMZUG/Digitales%20Marketing/Social/Insta/09_Reporting/02_Sonderreportings/2025/Gipfeltreffen/250926_PD_Social-Reporting_Gipfeltreffen.pptx?d=w3cafe52939c24a3f84b7d6395760c8e3&amp;csf=1&amp;web=1&amp;e=M3sFHU|250926_PD_Social-Reporting_Gipfeltreffen.pptx> <@U09D64LA420>

2025-09-26T09:30:31.502369 - **Florian Listl:**
> bist du ready für den Call? <@U09D64LA420>

2025-09-26T09:39:33.176019 - **Julia:**
> Nee hab leider keinen Zugriff

2025-09-26T09:39:39.943459 - **Julia:**
> Bin jetzt ready!

2025-09-26T09:39:59.082019 - **Florian Listl:**
> versuche dich mal einzuloggen mit der email - das ist wichtig, dass du zugriff hast

2025-09-26T09:40:22.916459 - **Julia:**
> welche mail?

2025-09-26T09:40:39.705089 - **Julia:**
> hab den Zugriff angefordert

2025-09-26T09:40:42.572129 - **Florian Listl:**
> <mailto:julia.hopper@boldcreatorsclub.com|julia.hopper@boldcreatorsclub.com>

2025-09-26T09:40:58.931059 - **Julia:**
> Aber kann sein, dass das wieder nicht klappt – Julia meinte Marie muss mich hier freigeben

2025-09-26T09:41:10.900719 - **Julia:**
> Hab auf viele Sharepoint Dateien keinen zugriff

2025-09-26T09:41:30.350989 - **Julia:**
> 

  📎 Bildschirmfoto 2025-09-26 um 09.41.24.png

2025-09-26T09:41:55.080729 - **Florian Listl:**
> okay, dann logg dich mal mit meinen credentials ein

2025-09-26T09:42:24.360789 - **Florian Listl:**
> <mailto:florian.listl@boldcreatorsclub.com|florian.listl@boldcreatorsclub.com>
vG.nZGi#E83a6jm

2025-09-26T09:42:29.082419 - **Julia:**
> okay, moment

2025-09-26T09:42:40.615989 - **Florian Listl:**
> dann muss ich die zahl nur eingeben bei 2fa

2025-09-26T09:43:09.996499 - **Julia:**
> ah moment, jetzt hat mich irgendwer freigegeben und ich kanns öffnen

2025-09-26T09:43:16.242199 - **Florian Listl:**
> top

2025-09-26T09:43:56.262339 - **Florian Listl:**
> dann lass uns hier gleich rein :slightly_smiling_face:

2025-09-26T09:43:57.798619 - **Florian Listl:**
> <https://meet.google.com/gwf-zuzb-jvi?authuser=1>

2025-09-26T10:41:02.835969 - **Julia:**
> <https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1211465610715674?focus=true>

2025-09-26T14:49:34.962669 - **Julia:**
> Eine Frage: soll ich Hanna später Bescheid geben, wenn Post/ Story Vorschläge in der BS Präsi ablegen oder machen wir das erst ab Montag?

2025-09-26T14:49:41.919889 - **Julia:**
> Mert und ich sind dran :slightly_smiling_face:

2025-09-26T17:34:44.238769 - **Julia:**
> habs ihr jetzt mal geschickt, hoffe das war okay

2025-09-29T09:55:36.487259 - **Florian Listl:**
> oh sorry, hab ich übersehen

2025-09-29T09:55:38.101119 - **Florian Listl:**
> aber klar!

2025-09-29T10:21:49.830679 - **Julia:**
> Also insider posts + alltagsdrive sagt mir leider garnichts

2025-09-29T10:35:23.654969 - **Florian Listl:**
> Sylt Golf: <https://www.picdrop.com/eyecatchme/porsche-golf-circle-sylt>

2025-09-29T10:38:06.271369 - **Florian Listl:**
> 4NYr5m9k

2025-09-29T17:21:34.363229 - **Julia:**
> irgendwie bin ich noch als Schmid drin :smile:

  📎 Bildschirmfoto 2025-09-29 um 17.21.20.png

2025-09-30T09:21:35.885919 - **Florian Listl:**
> okay, ich checke das mal im Porsche Portal

2025-09-30T09:55:16.944889 - **Julia:**
> Danke 

2025-09-30T10:07:29.033279 - **Julia:**
> ich kanns nicht teilen wegen sharepoint

2025-09-30T10:54:53.446839 - **Florian Listl:**
> Ich komm gleich ins Meeting

2025-09-30T10:55:01.535299 - **Julia:**
> okay

2025-09-30T11:34:44.945489 - **Florian Listl:**
> 

  📎 250930_Porsche_DE_Social-Media_Sep-Okt_JH.pptx

2025-09-30T11:36:08.394479 - **Florian Listl:**
> 

  📎 2509_CHRISTO X LEONIE BECK_SM ASSETS.pptx

2025-09-30T18:23:32.900759 - **Julia:**
> Hello! Bist du noch da?

2025-09-30T18:23:41.284839 - **Florian Listl:**
> hey

2025-09-30T18:23:42.005659 - **Florian Listl:**
> klar

2025-09-30T18:26:08.146039 - **Julia:**
> 

  📎 audio_message.m4a

2025-09-30T18:26:52.195259 - **Florian Listl:**
> Okay, ich ruf ihn schnell an :)

2025-09-30T18:26:55.265639 - **Florian Listl:**
> Danke!

2025-09-30T18:26:58.225909 - **Florian Listl:**
> Kriegt sie

2025-09-30T18:27:36.319509 - **Julia:**
> okay!

2025-10-07T14:05:16.487919 - **Florian Listl:**
> Hi Juli :slightly_smiling_face:
Kannst du mir kurz noch sagen wie viele Stunden du insgesamt für IAA und Gipfeltreffen gearbeitet hast? Inklusive allen Meetings, am besten nach Woche geordnet:
also 1.-7.9., 8.-14., 15.-21., 22.-28., 29.-30.

2025-10-07T14:12:07.541389 - **Julia:**
> Hello! Klar, schreib ich dir runter

2025-10-07T14:12:14.705869 - **Florian Listl:**
> danke!!

2025-10-07T15:03:47.543349 - **Julia:**
> ganz grob mit Tasks, Mails usw.:

*IAA*
1.9. - 7.9.: 7 Std. (Grid, IG Highlight, Captions für alle Assets)
8.9. - 14.9.: so wie Julia 70-75 Std. (Vor Ort + Sonntag Nachbereitung GIF Vorschläge)

*Gipfeltreffen*
15.9. - 21.9.: 4 Std. (Grid, IG Highlight Vorschläge)
22.9. - 28.9.: 3 Std. (Textbausteine für Captions, Grid Anpassungen, Postings aushelfen)
29. - 30.9.: 0
1.10. - 5.10.: 4 Std. (Carousels…)
6.10. - 7.10.: 3 Std. (2x neue Carousels, tbd.)

2025-10-07T15:04:07.374249 - **Florian Listl:**
> danke!!

2025-10-10T11:09:54.090849 - **Florian Listl:**
> Hey :slightly_smiling_face: <@U09D64LA420> lass uns gern kurz sprechen, wenn du vom Hundespaziergang wieder da bist :slightly_smiling_face: über das was heute ansteht

2025-10-10T11:22:44.549699 - **Julia:**
> Hello! bin wieder da

2025-10-10T11:32:40.674479 - **Julia:**
> Aufgaben sind klar:
• Porsche Points vom Gipfeltreffen für DE – macht Mert fertig und ich schicke sie gleich Charly, inklusive Captions
• Story Antworten Leonie Beck: Abstimmung gleich per Mail, kann dann geposted werden
• der größte Brocken ist heute die Bearbeitung des Contents von Event im Brand Store gestern: Content ist nicht gut, Hanna ist garnicht happy. versuchen das beste rauszuholen aber der Fotograf ghosted mich jetzt gerade auch

2025-10-10T11:51:07.704809 - **Florian Listl:**
> super!

2025-10-10T11:51:37.590689 - **Florian Listl:**
> weißt du was hier noch fehlt? <https://docs.google.com/presentation/d/1uJx_LoaNymBB1qkIUF3tGpVu0i_J5cT2/edit?usp=drive_web&amp;ouid=110452318806524765124&amp;rtpof=true>

  📎 20251009_BrandStore_Reporting_September [Automatisch gespeichert].pptx

2025-10-10T11:52:19.372309 - **Florian Listl:**
> danke, dass du dich um das brand store event kümmerst!

2025-10-10T11:56:24.773139 - **Julia:**
> ich glaube alles was "gelb" ist meine Julia – habe es aber noch nicht geschafft, wirklich durchzugehen

2025-10-10T11:56:46.670709 - **Julia:**
> ja gerne. Aber wie gesagt, es ist echt schwierig. Der Fotograf reagiert auf keine einzige Nachricht

2025-10-10T11:56:55.559409 - **Florian Listl:**
> kannst du ihn anrufen?

2025-10-10T12:00:34.009119 - **Julia:**
> hab ich schon probiert

2025-10-10T14:44:10.829079 - **Julia:**
> 

  📎 audio_message.m4a

2025-10-13T10:25:49.688699 - **Florian Listl:**
> Guten Morgen :slightly_smiling_face: Lass uns gern auch am Dienstag oder Mittwoch besprechen auf welchen anderen Projekten nach Porsche wir dich einsetzen können, damit du eine bessere Perspektive hast für die nächsten Monate

2025-10-13T12:40:53.132929 - **Julia:**
> Hi Flo, das können wir sehr gerne machen. Morgen direkt? :slightly_smiling_face:

2025-10-15T11:15:41.511109 - **Julia:**
> Hey, ich wollte jetzt nochmal nachfragen, ob es denn generell schon ein Update von Porsche gibt? Du meintest ja letzte Woche bis spätestens Mitte dieser Woche sollte es eine Info geben oder du meldest dich bei uns.
Mert, Julia und ich hängen schon echt sehr in der Luft und selbst, wenn es kein Update gibt weil ihr noch in den Verhandlungen seid, wäre es schon fair zu erfahren, "dass es kein Update gibt".  Porsche hat schon paar mal Andeutungen gemacht, dass es wohl nur noch bis Ende Oktober geht bezüglich Prios etc., das ist natürlich dann schon ein komisches Gefühl, wenn wir das von dir aber noch nicht erfahren haben. Und generell müssten wir uns ja dann auch in 2 Wochen nach einem neuen Job umsehen oder auch nicht..? Hast du hier eine Info für uns? Danke dir

2025-10-15T11:16:08.706749 - **Florian Listl:**
> Hi, nein, du bleibst auf jeden Fall bei BCC :slightly_smiling_face:

2025-10-15T11:16:34.055279 - **Florian Listl:**
> Lass uns heute um 15 Uhr sprechen

2025-10-15T11:17:03.179199 - **Florian Listl:**
> wann Porsche aufhört hat nichts mit dir zu tun

2025-10-15T11:17:34.351149 - **Florian Listl:**
> ich hab dir einen Termin eingestellt

2025-10-15T11:55:02.912229 - **Julia:**
> okay, das sind doch schöne nachrichten

2025-10-15T11:55:08.712569 - **Julia:**
> danke!

2025-10-17T15:38:44.476139 - **Florian Listl:**
> Hi :slightly_smiling_face: Kannst du das schnell checken?

  📎 image.png

2025-10-17T15:42:20.586749 - **Julia:**
> schau ich mir an

2025-10-17T15:42:26.819619 - **Florian Listl:**
> danke! :slightly_smiling_face:

2025-10-17T15:47:12.791069 - **Julia:**
> Keine Ahnung, was da war

2025-10-17T15:47:30.276869 - **Julia:**
> klar gerne, hatte mein Handy nur gerade nicht bei mir

2025-10-17T15:51:45.608159 - **Florian Listl:**
> du musst das am Sonntag nicht checken :slightly_smiling_face:

2025-10-17T15:53:47.587089 - **Julia:**
> Ja, ich bin auch fähig ein Reel hochzuladen ohne komischen Rand haha

2025-10-17T16:11:47.456969 - **Florian Listl:**
> ja...

2025-10-21T11:13:32.457789 - **Julia:**
> Hello! Die Rechnungsadresse für den Fotografen vom 60Y Targa Event ist die Mandlstraße oder?

2025-10-24T11:21:33.550389 - **Florian Listl:**
> ja :slightly_smiling_face:

2025-10-30T13:32:35.063079 - **Florian Listl:**
> so sehe ich die Aufgabenverteilung für Hisense.
Community Mgmt. kann auch bei Mert statt bei dir liegen, aber dem Kunden können wir das nicht kommunizieren, dass der Designer non-designer jobs macht :slightly_smiling_face:

  📎 image.png

2025-10-30T13:33:23.528739 - **Florian Listl:**
> Hier ist die Lohnabrechnung :slightly_smiling_face:

  📎 lobn_202509_0030125_10731_00012.pdf

2025-10-30T13:47:25.905909 - **Julia:**
> danke dir! Okay, alles klar. Kann man sonst ja auch aufteilen je nach Kapa

2025-10-30T13:47:50.702469 - **Florian Listl:**
> genau

2025-10-30T13:47:53.178979 - **Julia:**
> super danke! Hast du auch noch die für September?
Eigentlich kommen diese per Post oder? Also so kenne ich das

2025-10-30T13:48:21.117729 - **Florian Listl:**
> das ist die von September, wir machen das immer digital, morgen kann ich dir die von Oktober schicken

2025-10-30T13:48:36.501979 - **Julia:**
> ahh sorry :smile: falsch gelesen

2025-10-30T13:48:41.807019 - **Julia:**
> perfekt, danke :slightly_smiling_face:

2025-10-30T14:07:39.823189 - **Julia:**
> FYI beim Brand Store hatten wir für die Rundgang Stories 4 Iterationen – falls du das für die Abrechnung brauchst

2025-10-30T14:08:07.312169 - **Julia:**
> Waren immer wieder Textanpassungen, die inhaltlich gleich geblieben sind aber sie einfach die Texte umgestellt haben :no_mouth:

2025-10-30T14:08:46.431789 - **Florian Listl:**
> :man-facepalming::man-facepalming::man-facepalming::man-facepalming:

2025-10-30T14:08:54.065309 - **Florian Listl:**
> Danke!

2025-10-30T14:27:41.955309 - **Julia:**
> Bin übrigens schon 31 – aber Danke fürs jünger machen :innocent:

2025-10-31T10:02:53.696039 - **Florian Listl:**
> haha deine Ideen waren so fresh, dass ich dich jünger geschätzt hab :stuck_out_tongue_winking_eye:

2025-10-31T10:03:19.718669 - **Florian Listl:**
> Happy Friday :slightly_smiling_face: hier die Lohnkostenabrechnung für Okt

  📎 lobn_202510_0030125_10731_00012.pdf

2025-10-31T10:06:23.799449 - **Julia:**
> danke!

2025-11-03T10:35:50.988659 - **Julia:**
> Hi Flo, können wir hier sprechen? Mein Handy funktioniert leider nicht gerade

2025-11-03T10:35:58.507619 - **Florian Listl:**
> haha klar :slightly_smiling_face:

2025-11-03T10:36:00.485949 - **USLACKBOT:**
> 

2025-11-03T10:42:05.567619 - **Florian Listl:**
> hier <https://drive.google.com/drive/folders/1Tygyp-KCUMWiL9bP9_yC9P_h7dBXq1Jh?usp=sharing>

2025-11-03T14:31:02.369249 - **Julia:**
> Das meinte ich vorhin, bei Figma ist der Admin Account noch der Porsche Account. Sollen wir diesen weiterhin nutzen?

  📎 Bildschirmfoto 2025-11-03 um 14.30.27.png

2025-11-03T14:32:10.964559 - **Florian Listl:**
> sehr guter punkt, auch das will ich streamlinen, in zukunft sollen alle payments über <mailto:clients@boldcreators.club|clients@boldcreators.club> laufen - ist für die Buchhaltung viel einfacher.

Kannst man da eine andere email adresse angeben?

2025-11-03T14:33:51.985889 - **Julia:**
> ah perfekt. checke ich gerade

2025-11-03T14:39:44.812549 - **Julia:**
> yes, klappt

2025-11-03T14:39:56.077939 - **Julia:**
> soll ich die neue Mail direkt übernehmen oder ist das noch nicht final?

2025-11-03T14:41:23.265819 - **Florian Listl:**
> ist final

2025-11-03T14:41:28.529909 - **Florian Listl:**
> ich geb dir die zugangsdaten

2025-11-03T14:41:34.189739 - **Florian Listl:**
> login bitte wieder mit google

2025-11-03T14:41:34.642499 - **Julia:**
> okay super, danke

2025-11-03T14:41:42.874059 - **Florian Listl:**
> also login via google

2025-11-03T14:41:48.355429 - **Florian Listl:**
> die option gibts da beistens

2025-11-03T14:41:49.692529 - **Florian Listl:**
> meistens

2025-11-03T14:42:01.883609 - **Julia:**
> ja stimmt

2025-11-03T14:42:07.198009 - **Florian Listl:**
> login via Google:
<mailto:clients@boldcreators.club|clients@boldcreators.club>
_clients@bcc2023!

2025-11-03T14:42:17.239969 - **Florian Listl:**
> also wichtig: _clients@bcc2023! ist das google passwort :slightly_smiling_face:

2025-11-03T14:42:31.739159 - **Julia:**
> okay. ich versuchs mal

2025-11-03T14:43:11.879979 - **Florian Listl:**
> 90 24 84

2025-11-03T14:43:40.427319 - **Florian Listl:**
> bitte log dich am besten an deinem handy in der gmail app auch mit <mailto:clients@boldcreators.club|clients@boldcreators.club> ein, dann kannst du's selbst verifizieren und brauchst nicht mich

2025-11-03T14:43:54.365419 - **Florian Listl:**
> auf welche Zahl soll ich klicken? :grin:

2025-11-03T14:44:01.200839 - **Julia:**
> 84

2025-11-03T14:44:33.648439 - **Julia:**
> yes, mach ich. Stelle nur gerade auf ein neues Handy um und des backup lädt seit heute morgen, deshalb kann ich hier noch nichts umstellen

2025-11-03T14:44:44.539789 - **Julia:**
> jetzt ist es Nummer 28

2025-11-03T14:45:51.068419 - **Florian Listl:**
> kein problem, danke!

2025-11-03T14:53:58.306759 - **Julia:**
> Hat geklappt, Figma ist umgestellt :slightly_smiling_face: danke dir

2025-11-03T14:54:03.017829 - **Florian Listl:**
> top!

2025-11-04T14:45:17.956129 - **Julia:**
> Hi Flo! Hier ab Slide 17 haben wir neue Content Ideen und Reihen gesammelt, die eben auf die Content Säulen des Strategie Papers einzahlen, sowie eine grobe "Roadmap" erstellt. Das ist gerade noch etwas schwierig ohne wirklich zu wissen, wie die Produktionen sonst laufen.
Freu mich über Feedback:
<https://docs.google.com/presentation/d/1hCn3KbyAlmOzdpS0aAdcerl52U-l4EYm/edit?slide=id.g39fbe07ff9b_0_162#slide=id.g39fbe07ff9b_0_162>

2025-11-04T17:14:47.212519 - **Florian Listl:**
> Mega, danke! Ich schau es mir an :+1::+1:

2025-11-10T10:11:22.367509 - **Julia:**
> Hi Flo! Ich bin heute wieder mehr oder weniger da und mache zumindest schon mal die Übergabe mit Julia &amp; fange die Ausarbeitungen der Content Ideen an

2025-11-10T10:11:55.381369 - **Florian Listl:**
> Hi Juli, super!

2025-11-12T14:40:46.671099 - **Julia:**
> Evlt. macht das Tiny House dann garkeinen Sinn und wir suchen lieber Creator/ Studios die schon perfekt gestyled sind

2025-11-12T14:41:08.462199 - **Florian Listl:**
> verstehe, die haben im tiny house halt die ganze einrichtung

2025-11-12T14:41:08.720719 - **Julia:**
> oder direkt in Berlin

2025-11-12T14:41:12.450199 - **Florian Listl:**
> das ist ganz cool

2025-11-12T14:41:18.200739 - **Julia:**
> ja das auf jeden fall

2025-11-13T09:51:49.005859 - **Julia:**
> Hello! :slightly_smiling_face: Wann sollen wir wegen den KI Videos sprechen? Und wenn du mir noch die Infos zum Termin morgen gibst, wäre super :slightly_smiling_face:

2025-11-13T11:31:06.242159 - **Florian Listl:**
> 13 Uhr?

2025-11-13T11:48:11.449809 - **Julia:**
> yes, passt

2025-11-13T11:52:05.786799 - **Florian Listl:**
> top, hab dir eine einladung geschickt

2025-11-13T11:52:25.338089 - **Florian Listl:**
> darum wird's gehen :slightly_smiling_face:

  📎 Bitpanda_TSeitz.pdf

2025-11-13T11:53:05.758709 - **Florian Listl:**
> Tobias hat die Storyline geschrieben, die müssen wir noch mit leben füllen. Ich brauche deine Social Skills und deine Video Skills dafür. Mehr erzähle ich dir um 13 uhr

2025-11-13T11:53:43.199879 - **Florian Listl:**
> das war das briefing an Tobias

  📎 Bitpanda Briefing v3.pdf

2025-11-13T11:54:32.000659 - **Julia:**
> okay, schau ich mir an

2025-11-13T11:54:43.461089 - **Julia:**
> Tobias ist von BCC?

2025-11-13T11:56:12.113989 - **Florian Listl:**
> Tobias Seitz ist unser Senior Advisor, wir kennen ihn von seiner Zeit als Global CMO bei SIXT, davor hat er als CMO Westwing aufgebaut. Seit Juni ist er Global CMO von OBI <https://campaigngermany.de/news/beitrag/783-ex-sixt-cmo-tobias-seitz-heuert-bei-obi-an.html>

2025-11-13T11:56:29.520469 - **Julia:**
> Ahja genau, okay

2025-11-13T11:56:39.814179 - **Florian Listl:**
> Wir nutzen ihn oft um Marken zu verstehen und strategisch zu denken

2025-11-13T11:56:42.981389 - **Florian Listl:**
> darin ist er super

2025-11-13T11:56:54.832339 - **Florian Listl:**
> Jetzt haben wir das Gerüst, das müssen wir jetzt mit Fleisch füllen

2025-11-13T12:11:38.608299 - **Julia:**
> okay :slightly_smiling_face:

2025-11-13T13:00:15.739759 - **Florian Listl:**
> Hier noch für gleich: <https://youtu.be/0eEG5LVXdKo?t=1691> -&gt; bitte mit Stromberg-Ernie als Sparkasse/ Windows und einem von denen als Apple/ Bitpanda <https://www.tiktok.com/@hannesundjeremy/video/7345495818364816673?q=telefon%20prank&amp;t=1763035190400>

2025-11-13T13:00:54.456489 - **Florian Listl:**
> und bitte noch community stories einbauen

2025-11-13T13:00:57.927979 - **Florian Listl:**
> bis gleich :slightly_smiling_face:

2025-11-13T13:02:01.537889 - **Julia:**
> haha okay

2025-11-13T13:02:04.067999 - **Julia:**
> bin im meeting

2025-11-13T13:42:18.536349 - **Florian Listl:**
> <https://drive.google.com/file/d/1GzpyNFdmpV5BaRDDdQwXzFX91uFC_Y60/view?usp=sharing> MINI Video

  📎 MINI Pitch Video - Cut v3 alt.mov

2025-11-13T13:42:41.614519 - **Florian Listl:**
> Link zum Bitpanda Skript: <https://docs.google.com/document/d/1npeOaKceAB7Cxys3oTxUj2v4nRpQqFVs/edit>

  📎 BITPANDA SCRIPT.docx

2025-11-13T13:54:53.152299 - **Florian Listl:**
> mit DAZN macht Bitpanda scheinbar auch einiges :slightly_smiling_face:

  📎 image.png

2025-11-13T14:06:19.725039 - **Florian Listl:**
> ich hab dich auch in die Gruppe mit Alex und mir eingeladen, so können wir Ideen und Visuals schneller besprechen :slightly_smiling_face:

2025-11-13T14:12:23.838689 - **Julia:**
> ah cool, perfekt :slightly_smiling_face:

2025-11-13T16:19:55.998069 - **Julia:**
> noch eine Frage zu Bitpanda: alles auf deutsch oder englisch?

2025-11-13T16:24:29.961789 - **Florian Listl:**
> Deutsch passt

2025-11-13T16:24:40.969769 - **Florian Listl:**
> Aber Englisch geht auch

2025-11-13T16:24:44.134319 - **Florian Listl:**
> Eigentlich egal

2025-11-13T16:24:49.891579 - **Florian Listl:**
> Was dir lieber ist

2025-11-13T16:24:58.179809 - **Florian Listl:**
> Geht um Video creation oder?

2025-11-13T16:25:22.418819 - **Julia:**
> ja genau

2025-11-13T16:25:43.469229 - **Julia:**
> weil sie auf ihrem TikTok Account auch beides mixen, deshalb frag ich

2025-11-14T15:20:32.365289 - **Florian Listl:**
> Kannst du da rein? :slightly_smiling_face: <https://meet.google.com/sqt-cfga-irb?authuser=0> <@U09D64LA420>

2025-11-17T12:45:11.168969 - **Julia:**
> Hello! Hast du zufälligerweise den Kontakt von Rückenwind würde mal nachfragen, ob sie Infos haben

2025-11-17T12:46:25.038649 - **Florian Listl:**
> Klar, einfach die Jasmin Jasmin Kharbeiti | RÜCKENWIND <mailto:jasmin@rueckenwind.rocks|jasmin@rueckenwind.rocks>

2025-11-17T12:47:22.423429 - **Julia:**
> super danke

2025-11-18T11:54:25.345559 - **Julia:**
> 

  📎 Gnarby_V1.mp4

2025-11-18T13:35:19.788349 - **Julia:**
> Hier auch nochmal, falls WhatsApp spinnt :slightly_smiling_face:

  📎 Reason_Why_V1.mp4

2025-11-21T14:03:20.053629 - **Florian Listl:**
> 

  📎 TikTok_MAC_BoldCreatorsClub_20241021_compressed.pdf

2025-11-21T14:07:57.530399 - **Florian Listl:**
> 

  📎 BITPANDA_BOLDCREATORS_20251115 v01.02 offline.pdf
  📎 BITPANDA_BOLDCREATORS_20251115 v01.02 offline.pptx

2025-11-21T16:45:50.394029 - **Julia:**
> FYI: Anna und Marie sind noch an der Liste dran

2025-11-21T16:58:00.842589 - **Florian Listl:**
> Okay, Push sie :)

2025-11-21T17:13:49.922499 - **Julia:**
> yes, es lädt alles so lange scheinbar

2025-11-21T17:14:24.789859 - **Julia:**
> ansonsten schicke ich dir den onepager morgen früh direkt, wenn das jetzt noch etwas dauert

2025-11-21T17:14:28.080259 - **Florian Listl:**
> Ok

2025-11-21T17:14:30.825059 - **Florian Listl:**
> Danke!!

2025-11-22T11:10:23.520669 - **Julia:**
> Hello Flo!
Hier die Zusammenfassung und Storyline:
<https://docs.google.com/document/d/1SByofKhnwxNEQS8nKwrzm-wT7L5-qAubuA9JX6N6XGo/edit?tab=t.0>

Hier noch die Super Fans Ausarbeitungen + Content der Konkurrenz von Marie &amp; Anna als Ergänzung:
<https://docs.google.com/document/d/1t04tJSyVL0e2TAE2H277MDg7mhF4fi3uN5bBYDQCAgs/edit?tab=t.0>

Hier die Median Likes sortiert:
<https://boldcreators-my.sharepoint.com/:x:/g/personal/marie_gottschall_boldcreatorsclub_com/ET4BSKx62fhMpiswGgNC9sEBDR16D0Kim2f3GmQsqcmgrQ?rtime=TaLwKhQp3kg|https://boldcreators-my.sharepoint.com/:x:/g/personal/marie_gottschall_boldcreatorsclub_com/[…]MpiswGgNC9sEBDR16D0Kim2f3GmQsqcmgrQ?rtime=TaLwKhQp3kg>
Hier haben mir tatsächlich die Views gefehlt, um die Engagement Rates ausrechnen zu können --&gt; bitte ich sie am Montag nochmal drum.
Happy weekend :slightly_smiling_face:

2025-11-22T11:10:43.006859 - **Florian Listl:**
> Danke! :)

2025-11-22T11:11:02.443649 - **Florian Listl:**
> Sind das die Anzahl der Videos die kommentiert wurden von den Usern?

  📎 IMG_9341.png

2025-11-22T11:11:12.581339 - **Florian Listl:**
> Oder die Anzahl der Kommentare?

2025-11-22T11:11:43.101219 - **Florian Listl:**
> Hast du die excel files ggf. noch? :)

2025-11-22T11:11:58.350579 - **Florian Listl:**
> Danke!! Auch für die xtra mile

2025-11-22T11:14:31.923389 - **Julia:**
> so wie ich es gesehen die Anzahl der Videos. Amy zB kommentiert jedes Video - aber kann ich gerne nochmal nachfragen. Habe auf die Schnelle nicht gesehen, dass es doppelte Kommentare gibt

2025-11-22T11:14:57.304339 - **Julia:**
> klar, hier sind die Folder:
<https://drive.google.com/drive/folders/1jxccnuQ8RY-et_z6thNXnixY-TvkHDio>

2025-11-22T11:15:03.945719 - **Julia:**
> <https://drive.google.com/drive/folders/16XoGvShB_HogZBtipVE7hw4oYY0vmrub?usp=drive_link>

2025-11-22T11:15:41.292459 - **Florian Listl:**
> Okay, weil das würde bedeuten, dass Mac 355 Videos 2025 gepostet hat, und Amy jedes der Videos kommmtiert hat

2025-11-22T11:15:44.064889 - **Florian Listl:**
> Oder?

2025-11-22T11:16:01.648729 - **Julia:**
> gerne. Das Thema ist echt spannend, weil da eigentlich soo viel Potenzial drin ist.
bin gespannt, was du zur Storyline sagst

2025-11-22T11:18:38.839699 - **Julia:**
> insgesamt haben sie ca. 520 videos gepostet

2025-11-22T11:18:49.726769 - **Julia:**
> 522

2025-11-22T11:18:59.247749 - **Florian Listl:**
> 2025?

2025-11-22T11:19:09.353789 - **Florian Listl:**
> Das sind ja fast 2 Videos pro Tag im Schnitt 

2025-11-22T11:19:11.461039 - **Florian Listl:**
> Crazy

2025-11-22T11:19:31.481469 - **Julia:**
> ja

  📎 Bildschirmfoto 2025-11-22 um 11.19.26.png

2025-11-22T11:20:04.620409 - **Florian Listl:**
> Okay krass 

2025-11-22T11:20:56.510849 - **Florian Listl:**
> Danke!!

2025-11-22T11:21:34.351159 - **Julia:**
> gerne! Happy weekend und viel Spaß beim Skifahren

2025-11-22T11:37:28.479009 - **Florian Listl:**
> Haha danke :) dir viel Spaß mit den Schwiegereltern :smile:

2025-11-24T11:55:17.633149 - **Julia:**
> Hi Flo! Leider kann uns Marvin die Info zur damaligen Heimkinoraum Buchung nicht geben, deshalb wollte ich dich nochmal fragen, ob du  wegen einer alten Rechnung oÄ schauen könntest?

2025-11-24T12:02:28.434069 - **Julia:**
> für die Kostenaufstellung

2025-11-24T12:06:01.279669 - **Florian Listl:**
> Here you go, die heimkino Rechnung

  📎 Hinsense Rechnung Darin Pinter.pdf

2025-11-24T12:06:23.236119 - **Florian Listl:**
> Konntest du schon mit Marie sprechen?

2025-11-24T12:09:03.393839 - **Julia:**
> ah das ist das Model – bräuchten vom Raum selbst

2025-11-24T12:09:28.673089 - **Florian Listl:**
> War auch 500€ glaube ich

2025-11-24T12:09:32.716389 - **Florian Listl:**
> Was braucht ihr?

2025-11-24T12:09:36.336369 - **Florian Listl:**
> Nur den Preis?

2025-11-24T12:09:39.914679 - **Julia:**
> genau

2025-11-24T12:09:51.489549 - **Florian Listl:**
> Den weiß Marvin sicher 

2025-11-24T12:09:59.072909 - **Julia:**
> ne weiß er leider nicht

2025-11-24T12:10:06.193759 - **Julia:**
> haben schon 2 mal gefragt haha

2025-11-24T12:10:21.664379 - **Florian Listl:**
> Okay

2025-11-24T12:10:45.019389 - **Florian Listl:**
> Dann ruf gern bei heimkinoraum an, sag ob wir wieder 500€ machen können, du bist die Hisense Agentur 

2025-11-24T12:10:52.277019 - **Julia:**
> hab ich schon

2025-11-24T12:11:23.763859 - **Julia:**
> das ist leider super nervig, der EINE Ansprechpartner antwortet mir nicht und alle anderen können keine auskunft geben – ich ruf da schon täglich an

2025-11-24T12:11:41.599089 - **Julia:**
> Marvin meinte halt es kann auch sein, dass es umsonst war. deshalb

2025-11-24T15:50:28.841479 - **Florian Listl:**
> ich fand die storyline zu mac gut - gebe dir noch im detail feedback

2025-11-24T15:50:40.602359 - **Julia:**
> alright

2025-11-24T15:50:47.539049 - **Julia:**
> Muss ich noch irgendwas vorm Meeting jetzt wissen?

2025-11-24T15:52:35.672899 - **Florian Listl:**
> Nein, wir möchten herausfinden wie hoch das Budget und wo wir im Prozess stehen

2025-11-24T16:47:59.191979 - **Julia:**
> sehr spannend!

2025-11-25T10:20:21.256529 - **Florian Listl:**
> Lass uns kurz zu Estée Lauder bzw MAC sprechen, wann hast du Zeit?

2025-11-25T10:33:05.169919 - **Julia:**
> ja gerne. hab um 11 das meeting mit Hisense. also gerne jetzt oder danach?

2025-11-25T10:33:10.851559 - **Florian Listl:**
> danach

2025-11-25T10:33:15.661269 - **Florian Listl:**
> lass uns 12 machen

2025-11-25T10:33:19.879499 - **Florian Listl:**
> schick mir gern eine einladung

2025-11-25T10:33:55.821309 - **Julia:**
> passt, done!

2025-11-25T10:36:40.390829 - **Florian Listl:**
> wieso fehlt bei vielen das Engagement?

  📎 image.png

2025-11-25T10:37:31.173289 - **Florian Listl:**
> und der deutsche elf Account fehlt oder? <https://www.tiktok.com/@elf_vonzehn?lang=en>

2025-11-25T10:39:10.389049 - **Julia:**
> da hatte ich Marie gestern erstmal nur um die wichtigsten Accounts gebeten

2025-11-25T10:39:15.547829 - **Julia:**
> Ah krass, den kannte ich auch nicht!

2025-11-25T10:39:46.516779 - **Julia:**
> Ja und dieses Dr. Jart vom Meeting gestern haben wir auch noch nicht drin

2025-11-25T10:40:03.519319 - **Florian Listl:**
> okay, dann sag Marie gern, dass sie das noch machen woll

2025-11-25T10:40:04.739109 - **Florian Listl:**
> soll

2025-11-25T10:40:06.361349 - **Florian Listl:**
> danke!!

2025-11-25T10:44:44.961609 - **Florian Listl:**
> hast du einen diligence check gemacht, dass L'Oréal wirklich im Median 2025 16k Likes haben kann? Erscheint mir auf den ersten Blick unwahrscheinlich, die haben barely 16k Views auf vielen der letzten Videos

  📎 image.png

2025-11-25T13:45:50.466489 - **Florian Listl:**
> Hey :slightly_smiling_face: danke für das hands-on sein.

Ich hab was für dich vorbereitet. Lass uns dazu gleich nochmal telefonieren.
Ich glaube voll an dein Potenzial und will dich in Zukunft stärker in Client Meetings einbeziehen mit CMOs &amp; Co.
Dafür möchte ich dich in deinen Stärken fördern und in deinen Schwächen challengen.

Deine Stärken sind mmn:
• gutes Social Verständnis
• hard working
Schwächen:
• du denkst nicht wirtschaftlich genug, das muss mehr in Richtung McKinsey, BCG &amp; Co. gehen - sonst bleibst du auf der Marketing Manager Ebene und CMOs hören dir nicht zu
• du solltest noch etwas durchsetzungsstärker werden, so ein Excel Sheet muss eine Zero-Mistake-Policy haben. Ich möchte, dass dir so etwas in Zukunft auffällt und du hart durchgreifst bei dem, der dir das geschickt hat
• ich wünsche mir, dass du noch mehr "high-level" denkst
Das sind aber alles Themen, die man gut lernen kann. Sobald du das gelernt hast, bist du nicht 10%, sondern 10x besser und kannst Pitches leiten.

Die Project instructions werden dir dabei helfen.

Zusammen machen wir einen game plan.

Lass mich gern wissen, wann du Zeit für einen Call hast :rocket:

  📎 Juli Project Instructions.docx
  📎 Juli Beispiel.mov
  📎 BITPANDA_BOLDCREATORS_Voffline.pdf

2025-11-25T13:58:30.587989 - **Julia:**
> Hey Flo, danke dir! Also im Moment überfordert mich dieser Input noch sehr, also ja lass uns da gerne zu sprechen :smile: Ich muss jetzt allerdings mal kurz mit dem Hund raus.
Aber auch generell komme ich da wie gesagt gerade etwas an meine bisherigen "Grenzen", wie du ja merkst. Ich bin super kreativ und kann dir 100 Content Ideen/ Konzepte entwickeln die super fürs Brand Building sind; dieses analytische und pure "zahlenbasierte" ist einfach 100% neu für mich. Deshalb bin ich gerade sehr unsicher, ob ich das überhaupt kann? Also für mich ist es super schwer, die für dich logischen Rückschlüsse aus den Zahlen zu ziehen. Wie zB mit dem vermeintlichen Fehler in der Excel-Tabelle: wäre mir nicht aufgefallen, weil ich damit einfach nicht vertraut bin. Ich muss hier erstmal noch das Basic Grundverständnis aufbauen gefühlt, damit ich dich da so unterstützen kann wie du es gerne hättest

2025-11-25T14:00:46.080709 - **Florian Listl:**
> klar kannst du das :slightly_smiling_face:

2025-11-25T14:01:19.035769 - **Florian Listl:**
> dann lass es uns so machen, ich zeig dir diligence checks und danach machen wir eine road map, wie du's nach und nach lernst

2025-11-25T14:48:26.330629 - **Julia:**
> okay, sehr gerne. Das klingt gut 

2025-11-25T14:52:06.885409 - **Julia:**
> also ich schau mir jetzt deine instructions in ruhe an und dann können wir gerne sprechen. Oder macht es Sinn, dass wir uns morgen einmal im Büro zusammensetzen und das alles durchgehen? Auch in Bezug auf die Estée Lauder Task?

2025-11-25T15:01:47.377909 - **Florian Listl:**
> Ja, lass uns das machen :)

2025-11-25T16:03:48.443299 - **Julia:**
> Kurze Frage: ich bin gerade dabei die TikTok Shops der Beauty Brands zu vergleichen. Geht allerdings nur für DE, für UK, US usw. hab ich keinen Zugriff bzw. wird einem der TikTok Shop nicht angezeigt. GPT sagt, mit VPN + neuem TikTok Account klappt das.
Ich hab aber keinen VPN, haben wir hierfür eine Lösung?

2025-11-25T16:04:09.464429 - **Julia:**
> + das wäre ein Thema für What to fix oder? :slightly_smiling_face:

2025-11-25T18:13:47.778949 - **Julia:**
> So, hier einmal ein Update des One Pager's (Tab: One Pager Update)
<https://docs.google.com/document/d/1SByofKhnwxNEQS8nKwrzm-wT7L5-qAubuA9JX6N6XGo/edit?tab=t.phidpfv5zl1i>

Ist noch nicht das, wo wir am Ende hin müssen aber mit meinem jetzigen Verständnis/ Skills der Status Quo, ich taste mich ran :slightly_smiling_face:
Hab natürlich deinen Input aus dem Loom Video auch einbezogen. Marie hat mich super unterstützt und gute Punkte mit reingebracht! Wir sind beide morgen im Büro, dann wäre es super, wenn wir uns das einmal zusammen anschauen. Infos zu den Super Fans kommen morgen noch

2025-11-25T22:08:44.109359 - **Florian Listl:**
> Sehr cool - und don’t worry, das wird nicht von heute auf morgen perfekt sein, aber das muss es auch nicht. Da wirst du reinwachsen :muscle:

2025-11-26T11:30:27.645269 - **Julia:**
> hier schon mal das KI Tool:
<https://higgsfield.ai/>

--&gt; Hier kauft man Credits die bei jedem Draft aufgebraucht werden

2025-11-26T11:30:39.159009 - **Florian Listl:**
> ist das auch in artlist?

2025-11-26T11:31:14.128869 - **Julia:**
> das weiß ich tbh nicht

2025-11-26T11:34:42.741069 - **Florian Listl:**
> falls nicht, kannst du Higgsfield als Firmenaccount buchen

  📎 Rechnungsinformationen Bold Creators Club GmbH.pdf

2025-11-26T11:34:57.994189 - **Florian Listl:**
> 

  📎 image.png

2025-11-26T11:35:05.251529 - **Florian Listl:**
> wichtig ist, immer die korrekte Rechnungsadresse anzugeben

2025-11-26T11:35:22.963469 - **Florian Listl:**
> eine Sache noch: kannst du sprout kündigen? Das brauchen wir nicht mehr - dnake!

2025-11-26T15:43:57.540659 - **Julia:**
> setze ich auf die to do liste

2025-11-26T15:46:38.828979 - **Julia:**
> wie lange sollen die Lidl Videos ca. sein?
Wenn es aus mehreren Snippets bestehen soll (Close Up auf Lidl Logo auf Wohnmobil, zoom out, Karawane zu sehen, fahren los, in Hamburg rum/ Drohnenaufnahme", Leute drehen sich um "WOW", Ankunft OMR) usw. usw.

2025-11-26T16:51:04.877079 - **Florian Listl:**
> Kurz, 10-20 sek oder so, man soll vor allem checken worum es geht 

2025-11-26T17:48:32.688049 - **Julia:**
> ich hab die besprochenen Cases jetzt strukturiert und mit Proofs versehen: <https://docs.google.com/document/d/1SByofKhnwxNEQS8nKwrzm-wT7L5-qAubuA9JX6N6XGo/edit?tab=t.vxamqr41n8zq>

Für die finalen Content/ Format Ideen muss ich mich mit frischem Kopf morgen früh dran setzen – aber das geht ja bei mir schneller, als dieser One Pager :smile:

2025-11-26T17:50:04.985539 - **Julia:**
> bei One Pager 26.11.

2025-11-26T18:00:36.267839 - **Florian Listl:**
> da geht mir ja ganz das herz auf bei der Situation/ Problem/ Solution Logik :heart_eyes:

  📎 image.png

2025-11-26T18:00:55.712899 - **Florian Listl:**
> Diese Art wird long-term deinen Impact stark vergrößern

2025-11-26T18:49:13.015369 - **Julia:**
> juhu :partying_face:

2025-11-27T11:22:05.074399 - **Julia:**
> Hi! Die Content Ideen liegen jetzt auch jeweils mit ab :slightly_smiling_face:
Im nächsten Schritt erstellt ihr eh das Pitch Deck oder? Hier kann ich gerne die Content Ideen ausformulieren/ visuelle Beispiele suchen usw.

2025-11-27T11:22:27.196609 - **Florian Listl:**
> Hi, ist alles hier? <https://docs.google.com/document/d/1SByofKhnwxNEQS8nKwrzm-wT7L5-qAubuA9JX6N6XGo/edit?tab=t.vxamqr41n8zq>

  📎 251121_EstéeLauder_Social-Storyline

2025-11-27T11:22:55.190419 - **Julia:**
> genau, bei Content Formate

2025-11-27T11:22:58.907899 - **Florian Listl:**
> danke!

2025-11-28T09:34:31.609069 - **Julia:**
> Hi Flo. FYI Ich hab Anna an Mert übergeben, weil sie bei Hisense/Gorenje viel besser unterstützen kann. Die MockUps (Zeitungsartikel wahrscheinlich, oder?) erstelle ich wenn machbar direkt mit AI, da kann sie mir nicht helfen

2025-11-28T09:36:12.614899 - **Julia:**
> Oder kannst du mir kurz sagen was du genau willst, dass sie erstellt? Ich hab keine Ahnung was ich ihr briefen soll wenn ihr scheinbar schon was besprochen habt

2025-12-01T11:51:31.403109 - **Florian Listl:**
> Hi, bitte schicke dir Higgsfield Rechnung mit korrekten Zahlungsdaten an mich via email

2025-12-01T12:19:43.680969 - **Julia:**
> Du meinst bezüglich der neuen Credits? mach ich, bisher reicht es noch

2025-12-01T12:19:55.110399 - **Florian Listl:**
> nein, ich brauche die rechnung

2025-12-01T12:19:59.453629 - **Florian Listl:**
> du hast ja schon was gekauft

2025-12-01T12:20:07.340509 - **Florian Listl:**
> bzw abo abgeschlossen :slightly_smiling_face:

2025-12-01T12:20:27.734829 - **Julia:**
> achso, ja klar. leite ich dir weiter

2025-12-01T12:20:40.163559 - **Florian Listl:**
> top, bitte mit stichwort "rechnug"

2025-12-01T12:20:42.982199 - **Florian Listl:**
> rechnung

2025-12-01T12:20:48.116999 - **Florian Listl:**
> dann geht's direkt an accounting

2025-12-01T12:21:20.959039 - **Julia:**
> alright. Hatte sie vorhin schon an Moni weitergeleitet

2025-12-01T12:21:25.959529 - **Florian Listl:**
> super

2025-12-01T12:21:28.785939 - **Florian Listl:**
> danke!

2025-12-03T10:00:49.181309 - **Julia:**
> bin im warteraum

2025-12-04T10:14:09.780099 - **Julia:**
> Hi Flo! FYI wegen morgen Büro: Mert und ich müssen morgen die ganzen Erledigungen für die Shootings am Mo/Di machen. Heißt ich kann nicht genau sagen, wann wir im Büro sind und wenn dann wahrscheinlich nur kurz um die Geräte abzuholen. Sollen wir sonst in Ruhe am Mittwoch sprechen?

2025-12-04T10:14:53.233249 - **Florian Listl:**
> Klar! Stell mir gern was ein für Mittwoch :)

2025-12-04T10:14:56.333899 - **Florian Listl:**
> Danke!!

2025-12-05T08:25:06.217809 - **Julia:**
> Hi Flo! Könntest du mir hier die Vollmacht unterschreiben? Rest fülle ich dann gleich aus. Die Ikea Bestellung läuft auf deinen Namen, sonst kann ich sie nicht abholen

  📎 20250401_vollmacht.pdf

2025-12-05T08:29:06.832969 - **Florian Listl:**
> Guten Morgen :) hab ich in WhatsApp geschickt, da kann Mans direkt unterschreiben 

2025-12-05T09:07:46.549119 - **Julia:**
> Vielen Dank :pray: 

2025-12-05T16:28:42.305939 - **Julia:**
> Hello! Ich müsste Batterien und Verlängerungskabel bei Amazon bestellen und würde dafür die Karte nochmals nutzen

2025-12-05T16:28:52.525499 - **Florian Listl:**
> ja passt

2025-12-05T16:33:30.236809 - **Julia:**
> hat geklappt, danke

2025-12-15T09:53:31.491739 - **Julia:**
> Guten Morgen! Für das IKEA Regal bekommen wir noch 87 € zurück, wenn wir es zurück zu IKEA bringen. Jetzt hatte ich überlegt, ob ich es BCC einfach für 100€ abkaufe, da ich tatsächlich ein Neues brauche! Ist das eine Option für dich? :slightly_smiling_face:

  📎 Bildschirmfoto 2025-12-11 um 22.49.27.png

2025-12-15T09:54:54.129969 - **Florian Listl:**
> Dann behalt es einfach und wir hüllen den Mantel des Schweigens darüber ;)

2025-12-15T09:55:51.913139 - **Florian Listl:**
> Brauchst nicht extra 100€ zahlen

2025-12-15T11:24:09.951969 - **Julia:**
> Oh wow, dankeeeee! Das ist ja super lieb :star-struck:

2025-12-15T14:05:46.278089 - **Julia:**
> noch eine andere Frage die vorhin aufkam: gibt es denn Betriebsurlaub über Weihnachten? Oder sollen wir individuell Urlaub nehmen?

2025-12-15T14:06:57.933879 - **Florian Listl:**
> Ja, verkünden wir im All Hands, wir machen von 24.-6. Jan zu. Dieses Jahr braucht man durch die ganzen Feiertage nur 4 oder 5 Urlaubstage für 14 freie Tage, da kann jeder mal runterkommen

2025-12-15T14:07:28.406989 - **Julia:**
> Ah okay!

2025-12-15T14:07:31.496469 - **Julia:**
> danke schon mal :slightly_smiling_face:

2025-12-15T14:07:57.030269 - **Julia:**
> dann könnten wir das Laureen auch schon am Donnerstag sagen, da sie danach nämlich weg ist

2025-12-15T14:08:19.997599 - **Florian Listl:**
> passt, also gepostet werden muss natürlich trotzdem

2025-12-15T14:08:26.422449 - **Florian Listl:**
> aber grundsätzlich ist frei

2025-12-15T14:08:38.771279 - **Julia:**
> ja klar, nur wegen der Post-Produktion

2025-12-15T14:08:50.158629 - **Florian Listl:**
> passt

2025-12-15T14:09:43.206919 - **Julia:**
> hatten ihr heute gesagt, dass wir bis Ende der Woche noch ein paar Videos mit weihnachtlichem Content und für EOY cutten, das passt ja dann perfekt

2025-12-15T14:09:50.196989 - **Florian Listl:**
> top!

2026-01-07T20:05:17.944349 - **Julia:**
> Hey Flo! Ich hab gerade noch den Weihnachts-Urlaub eingetragen in clockify. War das richtig so? Wollte eben noch weiteren Urlaub für dieses Jahr eintragen, aber es sind nur 8 Tage freigeschaltet bisher

2026-01-07T20:45:13.223269 - **Florian Listl:**
> Hey :)

2026-01-07T20:45:19.732869 - **Florian Listl:**
> Sorry, das ist ein Fehler

2026-01-07T20:45:23.204919 - **Florian Listl:**
> Bin gerade im gym

2026-01-07T20:45:30.318889 - **Florian Listl:**
> Reichts dir wenn ich's mir morgen anschaue?

2026-01-08T08:57:57.913669 - **Julia:**
> Guten Morgen, ja klar kein Stress

2026-01-08T15:37:09.768499 - **Julia:**
> bin da

2026-01-08T15:58:35.827069 - **Florian Listl:**
> wir können für die Hosen und BH und so auch hautfarbene kleidung kaufen

2026-01-08T15:59:06.296559 - **Julia:**
> ja voll

2026-01-08T15:59:43.902039 - **Julia:**
> es könnte auch witzig sein, wenn man sonst einen Typ nimmt der ganz anders aussieht und quasi "Pitbull" Style ihn als SSIO verkleidet. So wie im Sommer alle (frauen und männer) als Pitbull zu den konzerten sind

2026-01-08T15:59:58.339759 - **Florian Listl:**
> haha ja

2026-01-08T15:59:59.518779 - **Florian Listl:**
> stimmt

2026-01-08T16:00:09.409639 - **Florian Listl:**
> gute idee

2026-01-08T16:07:48.504249 - **Florian Listl:**
> ich warte noch auf die SIM, dann laden wir dich mit der neuen nummer in die WA Gruppen ein :slightly_smiling_face:

2026-01-08T16:19:23.681579 - **Florian Listl:**
> ich hab Anna schon mal vorgewarnt und ihr die Idee grob erklärt

2026-01-08T16:19:30.466499 - **Florian Listl:**
> dann hast du's später leichter

2026-01-08T17:02:40.247849 - **Julia:**
> okay super danke

2026-01-08T17:03:07.677129 - **Julia:**
> Also lieber SSIO Double oder absichtlich "Normalo" den wir dann so hinstylen? das müsstest du entscheiden

2026-01-08T17:03:51.993659 - **Florian Listl:**
> SSIO double ist Prio 1, wenn das nicht geht, nehmen wir einen mit SSIOs Status und stylen ihn so

2026-01-08T17:08:23.169019 - **Julia:**
> okay

2026-01-09T10:33:01.530519 - **Julia:**
> hab kurz Meeting mit Julia &amp; Mert, wollen wir danach die next steps besprechen?

2026-01-13T11:28:00.453149 - **Julia:**
> Hi, ich bräuchte bitte noch einmal den Brandguide für Sixt

2026-01-13T11:47:02.648059 - **Florian Listl:**
> hier: <https://drive.google.com/drive/folders/18vV0u11GaZaXKAVsBTyHJvABswIA-HC2?usp=sharing>

vor allem die "brand presentation" und "SIXT guide" sind für dich relevant

  📎 image.png

2026-01-13T11:47:17.557089 - **Florian Listl:**
> in dem ordner sind auch alle schriften, logos etc.

2026-01-13T12:16:49.439959 - **Julia:**
> danke!

2026-01-14T10:39:26.285819 - **Julia:**
> noch eine Info, die Marie mir gegeben hat – das "ignorieren" wir für das Video?

  📎 Bildschirmfoto 2026-01-14 um 10.38.51.png

2026-01-14T11:28:34.440449 - **Julia:**
> <@UNUQV5R08> ich müsste Figma wieder aktivieren. Passt das?

2026-01-14T11:28:50.866449 - **Florian Listl:**
> Ja :)

2026-01-14T11:58:25.828069 - **Julia:**
> Ich bestelle jetzt mal die Props für den Lidl Dreh – falls du hier ein paar Codes bekommst

2026-01-14T11:59:01.591579 - **Florian Listl:**
> du musst es mir nur sagen, ich bekomme keine codes, das ist eine auth app

2026-01-14T11:59:09.424729 - **Julia:**
> ah okay!

2026-01-14T12:07:53.367699 - **Julia:**
> jetzt

2026-01-14T13:07:25.796979 - **Julia:**
> hab jetzt den 2. Teil bei Amazon bestellt

2026-01-14T15:19:19.745649 - **Julia:**
> ich reaktiviere gerade figma

2026-01-14T15:19:38.756579 - **Julia:**
> da solltest du etwas aufs handy bekommen

2026-01-14T15:19:38.846299 - **Florian Listl:**
> wichtig: bitte immer auf richtige rechnungsstellung etc achten

2026-01-14T15:19:46.662249 - **Florian Listl:**
> wieso?

2026-01-14T15:19:53.424189 - **Florian Listl:**
> über welche email machst du's?

2026-01-14T15:20:05.888549 - **Julia:**
> 

  📎 Bildschirmfoto 2026-01-14 um 15.19.51.png

2026-01-14T15:20:10.406119 - **Julia:**
> hab ich. auch VAT etc.

2026-01-14T15:20:11.182519 - **Florian Listl:**
> ah

2026-01-14T15:20:18.563769 - **Julia:**
> clients als mail

2026-01-14T15:20:28.844339 - **Florian Listl:**
> super, danke!

2026-01-14T15:20:32.485959 - **Florian Listl:**
> ist freigegeben

2026-01-14T15:20:47.770969 - **Julia:**
> oh wurde abgelehnt

2026-01-14T15:20:56.661599 - **Florian Listl:**
> dann mach paypal

2026-01-14T15:21:22.840599 - **Julia:**
> gibts leider nicht, nur SEPA-lastschrift

2026-01-14T15:21:59.865229 - **Florian Listl:**
> okay:
*Bold Creators Club GmbH*
*IBAN:* DE04 1001 0010 0951 4921 04
*SWIFT (BIC):* PBNKDEFF
*Bank:* FYRST – ein Angebot der Deutschen Bank

2026-01-14T15:22:44.264049 - **Julia:**
> danke, ich probiers!

2026-01-14T15:22:49.277649 - **Florian Listl:**
> gerne

2026-01-14T15:26:34.793919 - **Julia:**
> okay, sollte geklappt haben. Da war dauernd ein Bug

2026-01-14T19:02:54.035779 - **Florian Listl:**
> oh cool sind diese ganzen naruto videos von uns? weißt du wer aus dem team die gemacht hat? sieht richtig cool aus!

  📎 image.png

2026-01-15T08:15:38.961219 - **Julia:**
> Guten Morgen, nee weiß ich leider nicht! 

2026-01-15T14:41:24.104519 - **Florian Listl:**
> <mailto:florian@boldcreators.club|florian@boldcreators.club>
eSbB15@55&lt;,q

2026-01-15T15:58:23.253289 - **Julia:**
> Also tatsächlich klappt es nicht. Mir fehlt die normale SIM-Pin aus 4 Ziffern. Steht leider auch nirgends im Konto. normalerweise so wie ich das noch kenne, kommt das auch mit der Post

2026-01-15T16:08:26.998459 - **Julia:**
> ich muss jetzt los und die restlichen sachen einkaufen und alles vorbereiten. Wenn du morgen früh kurz Zeit hast, könnten wir das ja zusammen machen? Du bekommst dann nämlich auf deine Mail adresse einen code, glaube ich hab einen Trick gefunden

2026-01-15T16:11:45.992659 - **Florian Listl:**
> Hey :)

2026-01-15T16:12:05.427309 - **Florian Listl:**
> Das ist ja nervig 

2026-01-15T16:12:11.901419 - **Florian Listl:**
> Bin heute oder morgen available!

2026-01-16T09:35:41.927109 - **Florian Listl:**
> Hey :slightly_smiling_face: Wann machen wir's? Du brauchst ja das Handy

2026-01-16T09:35:50.679429 - **Florian Listl:**
> wichtig ist, dass du heute in alle Gruppen hinzugefügt wirst

2026-01-16T09:41:56.801319 - **Julia:**
> Hi! hast du jetzt Zeit?

2026-01-16T09:42:02.060799 - **Florian Listl:**
> ja :slightly_smiling_face:

2026-01-16T09:42:10.842749 - **USLACKBOT:**
> 

2026-01-16T10:17:20.885259 - **Julia:**
> kannst du mich hiermit nochmal einladen? der Link klappt nicht

  📎 IMG_0021.PNG

2026-01-16T10:17:30.614139 - **Florian Listl:**
> klar

2026-01-16T10:17:54.094459 - **Florian Listl:**
> done

2026-01-16T10:19:05.270359 - **Julia:**
> perfekt danke

2026-01-20T12:22:00.754159 - **Julia:**
> wegen sprout: da werden sie sich bei dir melden, weil du der billing address Kontakt bist

  📎 Bildschirmfoto 2026-01-20 um 12.21.16.png

2026-01-27T13:01:39.805439 - **Florian Listl:**
> Danke! :slightly_smiling_face:

2026-01-27T13:02:09.676139 - **Florian Listl:**
> Kurze Frage: ich hab 2 spannende Themen für dich, MINI (für diese Woche), und Pepsi (nächste Woche), können wir dazu heute kurz sprechen?

2026-01-27T13:03:57.423109 - **Florian Listl:**
> bei MINI steht schon sehr viel, aber ich bin mit den Ideen noch nicht happy, da sollten wir nochmal sprechen

  📎 BCC x MINI v20251113.pptx

2026-01-27T13:06:12.845659 - **Florian Listl:**
> ich kann immer außer 16-17:30 und 18-21 uhr

2026-01-27T13:16:20.608389 - **Julia:**
> Hello! Ja, passt es dir um 15 Uhr?

2026-01-27T13:16:25.171359 - **Florian Listl:**
> super!

2026-01-27T14:55:39.724019 - **Julia:**
> Können wir 15.15 machen?

2026-01-27T14:55:43.341709 - **Florian Listl:**
> klar

2026-01-27T14:55:47.790909 - **Julia:**
> okay, danke!

2026-01-27T14:55:53.663179 - **Florian Listl:**
> Marie nehm ich auch mit

2026-01-27T14:55:57.567209 - **Florian Listl:**
> die war ja bei MINI

2026-01-27T14:56:01.231929 - **Florian Listl:**
> soll dir helfen :slightly_smiling_face:

2026-01-27T14:56:05.003309 - **Julia:**
> perfekt

2026-01-28T11:54:06.623299 - **Julia:**
> Hello!

2026-01-28T11:54:12.194549 - **Julia:**
> ich antworte die gleich in whatsapp

2026-01-28T11:54:12.503079 - **Florian Listl:**
> hey :slightly_smiling_face:

2026-01-28T11:54:19.543499 - **Florian Listl:**
> easy

2026-01-28T11:54:33.807219 - **Julia:**
> Aber kurz hier weil Jana parallel super stresst und wir im SIXT meeting sitzen :smile:

2026-01-28T11:54:41.773859 - **Florian Listl:**
> oh nein

2026-01-28T11:54:44.230419 - **Florian Listl:**
> tut mir leid

2026-01-28T11:55:13.808729 - **Julia:**
> Die Videos/ MockUps für den Workshop werden nicht bis morgen alle fertig. ich bin dran aber das dauert einfach. Zudem die Ideen auch teilweise noch nicht final sind

2026-01-28T11:55:29.506639 - **Julia:**
> Also damit du schon mal weißt, ich bin dran aber ich kann das nicht bis morgen alles fertig machen

2026-01-28T11:55:39.106119 - **Florian Listl:**
> okay verstehe ich, dann lass es uns ganz pragmatisch machen

2026-01-28T11:55:48.215769 - **Florian Listl:**
> lass uns schauen, dass man die ideen so gut wie möglich erkennen kann

2026-01-28T11:55:55.254509 - **Florian Listl:**
> was fertig wird, wird fertig

2026-01-28T11:56:06.924299 - **Florian Listl:**
> was nicht, formulieren wir für morgen textlich aus

2026-01-28T11:56:13.520839 - **Florian Listl:**
> damit man sich was darunter vorstellen kann

2026-01-28T11:56:20.588979 - **Julia:**
> okay

2026-01-28T11:56:21.932099 - **Julia:**
> ja gerne

2026-01-28T11:56:29.967899 - **Julia:**
> ich kläre es mit Marvin und Jana

2026-01-28T11:56:33.906029 - **Florian Listl:**
> super, danke! :slightly_smiling_face:

2026-01-28T11:56:43.575439 - **Florian Listl:**
> Lass dich von Jana nicht stressen :slightly_smiling_face:

2026-01-28T11:57:02.653419 - **Julia:**
> Ne, wollte es nur mit dir absprechen bevor es wieder hin und her geht

2026-01-28T11:57:11.830189 - **Florian Listl:**
> wir brauchen deine :sparkles:Creative Energy:sparkles:

2026-01-28T11:57:15.934879 - **Florian Listl:**
> da hilft stress nicht :smile:

2026-01-28T11:57:18.351179 - **Florian Listl:**
> top, danke!

2026-01-28T12:01:03.008149 - **Julia:**
> danke!

2026-01-28T12:02:04.515269 - **Julia:**
> ich hatte jetzt love is blind soweit fertig und es basti zum schnitt gegeben:
<https://app.asana.com/1/1199360402832734/project/1211046662010247/task/1212991424663406?focus=true>

Das für alle anderen Ideen ist zu aufwendig bis morgen. Aber ich spreche gleich mit dem Team

2026-01-28T12:02:14.683019 - **Florian Listl:**
> geil!

2026-01-28T12:03:59.373339 - **Florian Listl:**
> ist super geworden - für das Meeting würde ich noch einen Screenshot mit den sprechenden Gegenständen einbauen.

Weil der Golf mit Mund und augen wäre super

2026-01-28T12:04:06.730599 - **Florian Listl:**
> ist aber für's Mockup nicht nötig

2026-01-28T12:04:16.102519 - **Florian Listl:**
> SIXT wird sehr happy sein, dass wir schon so weit sind

2026-01-28T12:04:25.850189 - **Florian Listl:**
> und es passt super zu tagesaktuell

2026-01-28T12:06:00.878749 - **Florian Listl:**
> Ich würde es sogar größer machen und sagen, dass wir in Zukunft öfter aktuelle Shows parodieren könnten

2026-01-28T12:06:15.623769 - **Julia:**
> welche Gegenstände meinst du?

2026-01-28T12:06:18.949909 - **Florian Listl:**
> weil LiB ist glaube ich schon vorbei

2026-01-28T12:06:57.916709 - **Florian Listl:**
> <https://www.tiktok.com/@wenndingereden/video/7593424277815201046>

2026-01-28T12:07:00.510769 - **Florian Listl:**
> das hier

2026-01-28T12:07:15.325399 - **Julia:**
> aso ja, das ist ja eine andere Idee nochmal!

2026-01-28T12:07:44.893729 - **Florian Listl:**
> genau, aber es wäre cool, wenn das auto mimik hat, so checkt man leichter dass es spricht

2026-01-28T12:08:32.005759 - **Julia:**
> achso meinst du

2026-01-29T09:57:29.633719 - **Julia:**
> Hello! Wir hatten da schon mal drüber gesprochen aber ich weiß es gerade nichtmehr, ob ich die selbst irgendwo her bekomme oder du mir das zu schickst. Ich hab eben meine Lohnabrechnung von Januar bekommen, mir fehlen noch die von Nov, Dez und diese Anmeldung zum Jobstart. Soll ich Julia Hillmaier danach fragen?

2026-01-29T10:00:28.659499 - **Florian Listl:**
> Hi Juli, frag gerne Fr Hillmaier für die Monate, wenn du die files jetzt brauchst. Wir haben in der Zwischenzeit Datev Arbeitnehmer Online aufgesetzt. Du solltest in den nächsten Tagen Post bekommen mit dem verification code.

Mit AO ist alles was Arbeitnehmer Dokumente angeht fully self service 
 

2026-01-29T10:00:44.735449 - **Florian Listl:**
> Heißt du bist nicht mehr darauf angewiesen, dass irgendjemand dir etwas schickt 

2026-01-29T10:01:12.880289 - **Florian Listl:**
> Aber wie gesagt, es braucht ein paar Tage bis der Code bei dir ist. Wenn du's jetz brauchst, schreib am besten der Hillmaier

2026-01-29T10:01:13.454329 - **Julia:**
> Okay passt

2026-01-29T10:01:24.810249 - **Julia:**
> Ja super, das kenne ich. Danke!

2026-01-29T15:46:48.471159 - **Florian Listl:**
> Top

2026-01-29T17:51:23.850899 - **Julia:**
> wegen MINI: Marie und ich haben ein paar Ideen ausformuliert. Ich schaff es allerdings nichtmehr das noch viel weiter zu spinnen bzw. hübsch zu visualisieren. Ich gliedere das Dokument für morgen noch, aber ich würds dir morgen eher mal "erzählen" als 1. Schritt. Passt das?

2026-01-29T17:51:36.568639 - **Florian Listl:**
> passt!

2026-01-30T16:30:46.116829 - **Julia:**
> <https://docs.google.com/document/d/1NEnlqXtQv5wCwQTJwg87O0flVR4dX0z-fwHf1-nqxH8/edit?tab=t.y41r0wyaqkw6>

2026-01-30T16:45:52.255829 - **Florian Listl:**
> 

  📎 BCC x MINI v20260127.pptx

2026-02-02T09:48:59.001359 - **Julia:**
> Hello! Ich kann die MINI Präsi leider nicht öffen, scheint "kaputt" zu sein

2026-02-02T09:49:19.537249 - **Florian Listl:**
> okay, ich schick dir einen google drive link, moment

2026-02-02T09:50:48.368859 - **Florian Listl:**
> lädt gerade hoch: <https://drive.google.com/drive/folders/16Jx-rZqfS_9qMDRbIcRmxOAPJQmN8TNd?usp=sharing>

2026-02-02T09:51:44.153939 - **Julia:**
> danke!

2026-02-02T09:51:56.094789 - **Florian Listl:**
> ist hochgeladen :slightly_smiling_face:

2026-02-02T09:53:52.590519 - **Julia:**
> Ne klappt irgendwie nicht

  📎 Bildschirmfoto 2026-02-02 um 09.52.35.png

2026-02-02T09:54:16.601289 - **Florian Listl:**
> kannst du's einfach downloaden?

  📎 image.png

2026-02-02T09:54:32.826619 - **Florian Listl:**
> in slides würde ich eh nichts bearbeiten, die software ist nicht gut genug+

2026-02-02T09:55:23.330889 - **Julia:**
> bisher noch nicht. ich probier es gleich nach meinem Call

2026-02-02T09:55:30.618809 - **Florian Listl:**
> okay top

2026-02-02T09:58:06.772039 - **Florian Listl:**
> sonst ist hier der Link via wetransfer <https://we.tl/t-BuPZm1OE5G>

2026-02-02T10:12:41.503739 - **Julia:**
> ja so klappt es

2026-02-02T10:13:32.662229 - **Julia:**
> danke!

2026-02-02T10:13:53.498599 - **Julia:**
> der Workshop bei SIXT findet schon statt oder?

2026-02-02T10:14:03.254189 - **Julia:**
> Weil wir die Präsi ja immernoch nicht haben (fertig haben)

2026-02-02T10:14:03.867249 - **Florian Listl:**
> ja, wir beide sind vor ort

2026-02-02T10:14:09.291259 - **Florian Listl:**
> zugspitzstraße 1, pullach

2026-02-02T10:14:21.093509 - **Florian Listl:**
> ja - ich hab Jana schon geschrieben, um 11 schickt sie's

2026-02-02T10:14:41.345599 - **Julia:**
> ah okay, super

2026-02-02T10:15:14.094219 - **Julia:**
> passt, ich muss noch schauen wie ich am besten hinkomme mit dem Streik

2026-02-02T10:16:45.406179 - **Florian Listl:**
> okay, passt! ich bin in mittersendling, von da könnte ich dich mitnehmen

2026-02-02T10:25:01.798789 - **Julia:**
> da komme ich auch irgendwie nicht hin :smile: aber danke. Alles gut, ich find einen weg. Wann sollen wir uns dort treffen 14.45?

2026-02-02T10:25:34.283059 - **Florian Listl:**
> super! 14:45 klingt gut

2026-02-02T11:42:14.609779 - **Julia:**
> Ist Marie heute nicht da? Oder hab ich das falsch im Kopf?

2026-02-02T11:42:41.637609 - **Florian Listl:**
> nein, die hat gebeten, dass sie heute für ihre arbeit lernen kann

2026-02-02T11:42:51.542229 - **Florian Listl:**
> sie ist morgen früh wieder da

2026-02-02T11:43:01.839469 - **Julia:**
> ahh okay, schade! :smile:

2026-02-02T11:43:03.419799 - **Julia:**
> danke

2026-02-02T11:43:23.970759 - **Florian Listl:**
> sorry :disappointed: sie hat gestern gefragt und ich wollte dich am we nicht stören

2026-02-02T11:44:17.754909 - **Julia:**
> alles gut, ich hab mich nur gewundert, dass sie mir nicht antwortet :slightly_smiling_face: hatte ihr am Freitag 2 Tasks gegeben und wollte dazu heute sprechen

2026-02-02T13:00:54.779689 - **Florian Listl:**
> hey, ich hätte gern dass ein werki noch 5 decathlon t shirts holt für morgen, welche größe passt bei dir?

2026-02-02T13:01:08.484939 - **Florian Listl:**
> musst dich um nichts kümmern, ich brauche nur die größe

2026-02-02T13:01:53.246139 - **Julia:**
> Haha okay

2026-02-02T13:02:01.182809 - **Julia:**
> XS/S

2026-02-02T13:02:45.816579 - **Florian Listl:**
> top, danke!

2026-02-02T20:38:47.886809 - **Julia:**
> Ich hab hier unsauber mitgeschrieben – hier wolltest du einfach 3 Bilder wie diese Challanges erarbeitet werden oder?

  📎 Bildschirmfoto 2026-02-02 um 20.37.48.png
  📎 Bildschirmfoto 2026-02-02 um 20.38.21.png

2026-02-02T20:39:19.861219 - **Florian Listl:**
> Genau

2026-02-02T20:39:41.983019 - **Julia:**
> okay passt, danke für die schnelle Antwort!

2026-02-02T20:39:45.867679 - **Florian Listl:**
> Middle finger ist cool

2026-02-02T20:39:50.441119 - **Florian Listl:**
> Regel 6

2026-02-02T20:40:09.713399 - **Florian Listl:**
> 37 ist cool, also Rallye 

2026-02-02T20:40:32.386569 - **Florian Listl:**
> Und 2 kann man glaube ich noch gut darstellen

2026-02-02T20:40:38.635949 - **Florian Listl:**
> 1 ist bisschen ausgelutscht

2026-02-02T20:40:51.125679 - **Julia:**
> ja passt, brief ich eben ein

2026-02-03T12:43:08.256199 - **Julia:**
> FYI – eben gesehen, wurde gebucht

  📎 Invoice-7KILTIJF-0011.pdf

2026-02-04T10:55:50.810159 - **Florian Listl:**
> super! Danke

2026-02-09T09:40:01.298599 - **Julia:**
> Hi Flo, hoffe dir geht’s gut! Ich bin etwas fitter aber noch immer nicht gesund und hab wieder diesen schlimmen Husten bekommen jetzt. Ich hab leider noch keine Antwort vom Arzt, warte da nur drauf. Ich brauch heute auf jeden Fall noch den Tag und meld sobald ich mehr weiß :crossed_fingers:

2026-02-09T09:41:01.459109 - **Florian Listl:**
> Okay, gute Besserung! Ich drück die Daumen, dass es bald wieder aufwärts geht!

2026-02-09T11:21:11.161959 - **Julia:**
> danke!!

2026-02-16T13:50:39.465539 - **Julia:**
> Hi! :slightly_smiling_face: würde es dir um 4 passen? Dann stell ich uns kurz was ein

2026-02-16T13:58:13.712619 - **Florian Listl:**
> Nachmittag ist recht voll 

2026-02-16T13:58:19.099919 - **Florian Listl:**
> Lass uns jetzt gleich sprechen

2026-02-16T13:58:22.485339 - **Florian Listl:**
> Ich ruf dich an

2026-02-16T14:02:02.990089 - **Julia:**
> okay


---

### Jana Kordt (22 messages: 12 from Julia, 10 from Jana Kordt)

**Folder:** `D09NZF18J2K`

2025-10-31T10:46:19.269009 - **Julia:**
> Hi Jana! Wie wäre es, wenn wir Montag dann einfach um 9.30 Uhr starten und Flo kommt dann einfach dazu ab 10Uhr?

2025-10-31T13:54:40.071699 - **Jana Kordt:**
> Hallo.
Das können wir gerne so machen.

2025-10-31T14:06:10.830249 - **Julia:**
> Super :slightly_smiling_face: stellst du das Meeting ein?

2025-11-03T09:31:18.295209 - **Julia:**
> Hi Jana, wie sieht es mit unserem Meeting aus?

2025-11-03T09:32:59.688889 - **Jana Kordt:**
> Shame, ich glaube, ich habe die falsche Julia eingeladen - was ist dein Nachname? Bzw Email Adresse?

2025-11-03T09:33:46.779079 - **Julia:**
> <mailto:julia.hopper@boldcreators.club|julia.hopper@boldcreators.club>

2025-11-03T09:33:55.452569 - **Julia:**
> <mailto:mert@boldcreators.club|mert@boldcreators.club>

2025-11-03T09:35:04.943599 - **Jana Kordt:**
> ah perfekt.
Ich hab SIXT schon die ganze Zeit am Telefon, laut eurer Kalender würde auch 10:30-11:30 passen, Flo hatte den Inital-Termin auch abgesagt, hier haben wir alle einen Puffer. Passt das?

2025-11-03T09:37:05.597929 - **Julia:**
> okay

2025-11-03T10:06:21.255079 - **Jana Kordt:**
> Wir haben ein SIXT Kundenmeeting reinbekommen, es ist gerade etwas stressig, da Marvin nicht da ist. Ich muss noch mal etwas nach hinten schieben :disappointed: SORRY für das hin und her.

2025-11-03T10:24:56.207699 - **Julia:**
> alles gut, danke fürs Bescheid geben

2026-01-06T11:07:09.054149 - **Jana Kordt:**
> Hey hey. Happy new year. Passt es dir morgen nach dem Lunch oder Donnerstag besser für die SIXT Übergabe ?

2026-01-07T09:21:04.272989 - **Julia:**
> Hi Jana! Happy new year :slightly_smiling_face: Gerne morgen um 10Uhr? Passt dir das?

2026-01-07T10:33:03.947709 - **Jana Kordt:**
> Perfekt :) 

2026-01-07T10:35:05.594689 - **Jana Kordt:**
> Flo will, dass wir es heute machen. 

2026-01-07T10:42:48.128579 - **Julia:**
> Dann machen wir es heute. 14.30?

2026-01-07T10:53:05.611489 - **Jana Kordt:**
> Geht es auch später? 

2026-01-07T10:53:32.078809 - **Julia:**
> yes, du kannst mir gerne einfach was einstellen

2026-01-07T12:49:17.577639 - **Julia:**
> sehe grade bei Flo im Kalender, du hast die falsche Mail genommen. das ist meine richtige: <mailto:julia.hopper@boldcreators.club|julia.hopper@boldcreators.club>

2026-01-09T10:57:50.039239 - **Julia:**
> Hi Jana! Kurze Frage: kannst du mir kurz sagen, wieviele Std. du schätzungsweise für SIXT in der Woche aufgewendet hast? Damit ich das Pensum grob einschätzen kann

2026-01-09T12:45:23.914839 - **Jana Kordt:**
> Hey hey 

2026-01-09T12:45:39.061909 - **Jana Kordt:**
> Puh. Total unterschiedlich. Schicke dir später mein srubdebzettel 


---

### Jose Pequeno (25 messages: 14 from Julia, 11 from Jose Pequeno)

**Folder:** `D0A57U5R90E`

2025-12-23T18:17:11.864469 - **Jose Pequeno:**
> Hi Juli :slightly_smiling_face:

2025-12-23T18:18:45.092579 - **Jose Pequeno:**
> could you send me the credentials on highfield

2025-12-23T18:27:40.921419 - **Julia:**
> Hi!

2025-12-23T18:27:47.129029 - **Julia:**
> What do you mean exactly? :slightly_smiling_face:

2025-12-23T18:35:54.514899 - **Jose Pequeno:**
> Sorry, I got confused with the chat hehe :disappointed:

2026-01-30T17:56:44.844189 - **Julia:**
> Hi Jose! :slightly_smiling_face: Hope you are doing fine

2026-01-30T17:57:43.891199 - **Julia:**
> I just add some tasks into the new Asana Board &amp; will fill them now with detailed briefings! It would be awesome, if you and the team could work and that already today? :slightly_smiling_face:
We need the final assets on wednesday, so it's very tight!

2026-01-30T17:59:16.486079 - **Jose Pequeno:**
> Hi Juli, we are fine, i hope you too :slightly_smiling_face:

2026-01-30T17:59:24.774719 - **Julia:**
> I won't be able to feedback today, but I've you like I can give you a quick overview/ introduction about the project :slightly_smiling_face:

2026-01-30T17:59:32.242599 - **Jose Pequeno:**
> yes of course, tha task is already on asana?

2026-01-30T17:59:52.570829 - **Julia:**
> just the titles. I'll insert the briefings now asap

2026-01-30T18:01:37.657469 - **Jose Pequeno:**
> Perfect, will these be AI-generated videos or edited with material you provide?

2026-01-30T18:02:35.485779 - **Julia:**
> AI generated pictures

2026-01-30T18:18:03.359789 - **Jose Pequeno:**
> Perfect, we'll keep an eye out :slightly_smiling_face:

2026-01-30T18:29:25.454109 - **Julia:**
> perfect! The first briefing for 3 pictures is in Asana

2026-01-30T18:52:09.661479 - **Julia:**
> 3 briefings (out of 5) are ready. The rest will follow on monday

2026-01-30T18:52:31.261809 - **Julia:**
> Everything okay for you or should we have a quick call now?

2026-01-30T19:04:26.064779 - **Jose Pequeno:**
> can we have a call?

2026-01-30T19:05:00.281869 - **Julia:**
> sure!

2026-01-30T19:05:22.745449 - **USLACKBOT:**
> 

2026-02-02T13:32:45.836109 - **Julia:**
> Hi! Thank you for the AI Content already :slightly_smiling_face: I commented one task and need one more iteration.
Another new task is in the Asana board. Today in the evening I will add briefing for the last task "Road Challange" in Asana

2026-02-02T14:16:42.016049 - **Jose Pequeno:**
> Hi Juli,

Perfect, now I check it with the girls for corrections and new tasks

2026-02-02T20:50:15.902309 - **Julia:**
> the last briefing is online now :slightly_smiling_face: thank you so much

2026-02-03T15:41:41.999969 - **Jose Pequeno:**
> Hi <@U09D64LA420>

we have finished our asana tasks :slightly_smiling_face:

2026-02-03T16:54:44.150829 - **Julia:**
> Thank you! I’ll have a look asap 


---

### Marvin Hammerschmidt (640 messages: 328 from Julia, 312 from Marvin Hammerschmidt)

**Folder:** `D09U7C9S230`

2025-11-20T17:54:47.125279 - **Julia:**
> Hi Marvin! :slightly_smiling_face:
Wir haben den Gorenje TikTok Account jetzt auch aufgesetzt und würden hier natürlich auch gerne den blauen Haken beantragen. Könntest du mir evtl. nochmal erklären, wie und wo ihr das gemacht habt? :smile:

2025-11-20T17:54:49.500799 - **Julia:**
> danke dir!

2025-11-20T17:56:07.765919 - **Marvin Hammerschmidt:**
> Hey Juli. Kann ich dir morgen gern erklären. Bin aber bis mittags voll in Terminen 

2025-11-20T17:56:56.634009 - **Julia:**
> ja easy, kein Stress!

2025-11-21T13:27:32.462299 - **Julia:**
> Hello, hab noch eine weitere Frage: Julia meinte du hättest die Info nicht, Flo meinte doch :smile:
Es geht um die Kosten für den Dreh im Heimkinoraum. Könntest du mir hier grob sagen, wieviele Videos in welchem Zeitaufwand entstanden sind und was es ca. gekostet hat?
Danke

2025-11-21T13:30:58.203849 - **Marvin Hammerschmidt:**
> Hello :slightly_smiling_face:
Uf
Das hab ich nicht organisiert und die die das gemacht haben sind beide nicht mehr da
Es waren um die 90 Videos
Ich meine die Creator haben jeweils 500 gekostet
Der Videograph glaube ich 600

Was wir für die Nutzung des Raumes gezahlt haben weiß ich leider nicht aber kann auch umsonst gewesen sein

2025-11-21T13:32:20.106309 - **Julia:**
> Okay, aber das hilft schon mal etwas weiter. ich danke dir!

2025-11-21T13:32:42.626109 - **Marvin Hammerschmidt:**
> Kann gleich nochmal alles durchschauen

Haben gerad released und bin übel im Stress:D melde mich :slightly_smiling_face:

2025-11-21T13:33:27.975599 - **Julia:**
> alles gut, danke dir!

2025-11-21T13:33:42.317479 - **Julia:**
> wegen blauen Haken können wir auch montags sprechen – hab auch noch genügend anderes

2025-11-21T13:35:55.044349 - **Marvin Hammerschmidt:**
> Dann lieber Montag
Heute ist craaaazy :smile:

2025-11-21T13:37:27.868179 - **Julia:**
> alles klar, meld du dich dann gerne einfach oder stell mir was ein. bin wahrscheinlich flexibler

2025-11-25T10:49:22.253849 - **Julia:**
> Hey, hast du gegen 12.30 kurz Zeit?

2025-11-25T10:50:01.923469 - **Marvin Hammerschmidt:**
> Hey
Bis jetzt schon. Kann aber noch ein Termin dazwischen kommen

2025-11-25T11:00:48.685759 - **Marvin Hammerschmidt:**
> ok passt
13 Uhr hab ich den folge Termin :slightly_smiling_face:

2025-11-25T11:01:22.103439 - **Julia:**
> okay super, dann huddle ich dich an

2025-11-25T12:32:26.413699 - **USLACKBOT:**
> 

2025-11-25T12:34:39.806179 - **Julia:**
> melde mich gleich

2025-11-25T12:40:03.743439 - **Julia:**
> sorryy, Flo ist am Telefon

2025-11-25T12:40:19.702959 - **Marvin Hammerschmidt:**
> ohje

2025-11-25T12:51:50.832879 - **USLACKBOT:**
> 

2025-12-22T13:26:53.352349 - **Julia:**
> Hi Marvin! Hoffe dir geht es gut :slightly_smiling_face:

2025-12-22T13:27:34.145849 - **Julia:**
> Flo möchte gerne, dass ich eine kleine Intro zum Thema Higgsfield/ AI gebe. Terminlich wäre heute 18Uhr sein Wunsch – da ich mir aber vorstellen kann, dass einige da schon nichtmehr available sind, frag ich lieber einmal nach

2025-12-22T13:27:52.609779 - **Julia:**
> Sag gern Bescheid, ob dir das passt. Ansonsten würde ich morgen gegen 17 Uhr anpeilen

2025-12-22T13:28:32.704309 - **Marvin Hammerschmidt:**
> Hey Juli
oh man

2025-12-22T13:28:40.770929 - **Marvin Hammerschmidt:**
> ja dann morgen gegen 17 Uhr wenn es geht bitte

2025-12-22T13:28:48.665369 - **Marvin Hammerschmidt:**
> Nur du und ich oder er auch?

2025-12-22T13:29:04.887179 - **Julia:**
> Okay, ja hab ich mir schon gedacht :smile: Mert passt es auch nicht und mir eigentlich auch nicht (weder heute noch morgen aber well)

2025-12-22T13:29:12.388799 - **Julia:**
> er auch. Peru auch

2025-12-22T13:29:19.064399 - **Marvin Hammerschmidt:**
> Ja same haha

2025-12-22T13:29:32.830649 - **Marvin Hammerschmidt:**
> uf

2025-12-22T13:30:00.652029 - **Marvin Hammerschmidt:**
> Für wielang ist das angesetzt?

2025-12-22T13:30:33.701689 - **Julia:**
> ich hab noch keine Ahnung

2025-12-22T13:30:52.816339 - **Marvin Hammerschmidt:**
> alright
Danke fürs Bescheid geben ^^
Ich bin gespannt

2025-12-22T13:31:19.075549 - **Julia:**
> 

  📎 audio_message.m4a

2025-12-22T13:31:33.562659 - **Marvin Hammerschmidt:**
> Klassiker

2026-01-07T03:14:54.260229 - **Marvin Hammerschmidt:**
> Hey Juli. Ich hoffe du hattest nen entspannten Urlaub :) lass uns heute doch mal kurz über die neue Struktur sprechen und wie wir das alles am besten organisieren. Ich hab am Morgen 2 Termine aber dann bis 14 Uhr frei. Wann würde es dir am besten passen? :)

2026-01-07T09:12:13.095989 - **Julia:**
> Hi Marvin! Happy new year :slightly_smiling_face:
Yes, wahrscheinlich hast du auch mehr Infos als ich. Also gerne. Passt es dir um 12 Uhr?

2026-01-07T09:15:13.566919 - **Marvin Hammerschmidt:**
> Das bezweifle ich stark ehrlicherweise :smile:

2026-01-07T09:15:19.254749 - **Marvin Hammerschmidt:**
> Ja können wir machen :slightly_smiling_face:

2026-01-07T09:15:37.791029 - **Julia:**
> lieb ich

2026-01-07T09:15:41.007149 - **Julia:**
> ich stell schnell was ein

2026-01-07T09:15:46.202089 - **Marvin Hammerschmidt:**
> Super
Danke dir!

2026-01-07T12:47:20.057579 - **Marvin Hammerschmidt:**
> emails nicht aber dafür um die 50 whatsapp nachrichten

2026-01-07T12:58:21.520059 - **Julia:**
> hab ich mir schon gedacht

2026-01-07T13:50:44.369739 - **Marvin Hammerschmidt:**
> Kannst du mir den Termin mit Julia noch weiterleiten?
Ich hab bisher keinen^^

2026-01-07T13:51:12.015479 - **Julia:**
> Jana meinst du oder? :slightly_smiling_face:

2026-01-07T13:51:17.856099 - **Julia:**
> Sie hat ihn jetzt auf morgen verlegt..?

2026-01-07T13:51:35.844799 - **Julia:**
> ich kann da nicht, deshalb schwierig :smile:

2026-01-07T13:51:54.426139 - **Marvin Hammerschmidt:**
> huch
Ja haha

ohman

2026-01-07T13:53:10.852629 - **Julia:**
> sieht man ja eigentlich auch im Kalender aber okay

2026-01-07T13:53:21.865249 - **Julia:**
> Wir können aber trotzdem gerne später kurz quatschen

2026-01-08T14:21:29.839109 - **Marvin Hammerschmidt:**
> Hey Juli bist du da und könntest für mich was an die Designer briefen?

2026-01-08T14:58:13.014549 - **Julia:**
> Hi, kann dir in ca. 30 min weiterhelfen 

2026-01-08T14:59:00.746929 - **Julia:**
> Bzw. Ist das dann meine Aufgabe? Oder wie lief das vorher bei euch ab?  

2026-01-08T14:59:24.534059 - **Marvin Hammerschmidt:**
> Eigentlich basti aber der muss zum arzt und bei mir brennt alles :smile:

2026-01-08T15:00:02.108769 - **Marvin Hammerschmidt:**
> ich machs gleich selber all good
Ist nicht viel

2026-01-08T15:36:04.214079 - **Julia:**
> ah mist, sorry!

2026-01-08T15:36:18.906189 - **Julia:**
> Flo wollte jetzt nochmal vorm Meeting mit mir sprechen

2026-01-08T15:36:49.947649 - **Marvin Hammerschmidt:**
> Alles gut
War wie gesagt nicht viel:)
Wenn die Designer direkt delivern, passt alles ^^

2026-01-08T15:37:18.628109 - **Julia:**
> fingers crossed!

2026-01-08T15:58:53.712819 - **Marvin Hammerschmidt:**
> Flo hat mich gebeten, dir die Kontakte von den Darsteller Agenturen durchzugeben

<mailto:cr@lachfalten-people.de|cr@lachfalten-people.de>  und <mailto:info@agentur-isarperlen.de|info@agentur-isarperlen.de> waren bisher die vielversprechensten.
Ansonsten gibt es noch <https://www.fameonme.de/kontakt/> und  <https://agenturfrehse.com/> mit einem recht großen Angebot.

2026-01-08T16:00:31.640579 - **Julia:**
> ah super, danke! :slightly_smiling_face: ja genau da haben wir eben drüber gesprochen

2026-01-09T09:52:58.222449 - **Julia:**
> Hi! Hast du so gegen 11.30 nochmal kurz Zeit für mich bezüglich SIXT?

2026-01-09T09:54:28.063689 - **Marvin Hammerschmidt:**
> Hey
Ich bin ab 11 im Call mit SIXT, wenn der dann vorbei ist meld ich mich bei dir

2026-01-09T09:54:40.703259 - **Julia:**
> okay perfekt

2026-01-09T11:48:13.953679 - **Marvin Hammerschmidt:**
> bin gleich soweit
im sorry

2026-01-09T11:49:40.627509 - **USLACKBOT:**
> 

2026-01-09T14:20:27.484959 - **Marvin Hammerschmidt:**
> Ist mit Flo geklärt
Zum jahres Auftakt kommst nur du mit, er nicht

Wir sollen nächste WOche mal 2 längere Termine haben in denen wir more deep dive gehen :slightly_smiling_face:

2026-01-09T14:39:45.184699 - **Julia:**
> okay

2026-01-09T14:40:15.464599 - **Marvin Hammerschmidt:**
> Also nach deiner Entscheidung natürlich. Ich bleib aber beim Rat: Versuchs mal :) 

2026-01-09T14:56:24.305659 - **Julia:**
> danke :slightly_smiling_face: ja ich muss das mal kurz sacken lassen über's Wochenende und meld mich dann am Montag direkt!

2026-01-12T12:32:45.125039 - **Julia:**
> entschieden hab ich mich eigentlich nicht dafür, aber sieht Flo leider nicht so. also here I am

2026-01-12T12:32:56.506389 - **Marvin Hammerschmidt:**
> What 

2026-01-12T12:33:28.350229 - **Marvin Hammerschmidt:**
> er ruft mich gerade an

2026-01-12T12:33:35.513589 - **Julia:**
> na super :smile:

2026-01-12T12:33:37.373959 - **Marvin Hammerschmidt:**
> und sagt es liegt daran das es an meinem vortrag liegt

2026-01-12T12:33:44.432649 - **Marvin Hammerschmidt:**
> das ich zu viele probleme genannt habe

2026-01-12T12:34:09.414749 - **Julia:**
> ja hat er zu mir auch gesagt. aber ich hab 5 mal gesagt "ich will diese verantwortung nicht tragen, ich bin kein Projektmanager"

2026-01-12T12:34:25.368839 - **Julia:**
> hat er nicht akzeptiert, weil er sagt das ist basic, das kann ich und hab ich ja auch schon gemacht

2026-01-12T12:34:45.282939 - **Julia:**
> ich hab gesagt ich will nicht der Haupt-AP sein/ werden, soll ich aber nach und nach trotzdem

2026-01-12T12:40:22.720319 - **Julia:**
> jetzt ruft er mich wieder an

2026-01-12T12:40:39.837369 - **Marvin Hammerschmidt:**
> Ich habe ihm gesagt, dass wir schon besprochen haben, dass ich es eher unsinnig finde, in unserem Falle PM und Creative klar abzugrenzen
Dem hat er zugestimmt.
Auch das mit dem Hauptansprechpartner, das werde immer ich sein, gerade weil es auch super viel TikTok Expert fragen sind (eigentlich zu 95%)

2026-01-12T12:40:51.820179 - **Marvin Hammerschmidt:**
> Wir werden uns das sinngemäß´aufteilen und so machen wie du Kapazitäten hast

2026-01-12T12:43:02.569149 - **Marvin Hammerschmidt:**
> Das, wobei ich dich brauche, ist vor allem, um mit meiner unstrukturierten Art "aufzuräumen" und in Strukturen zu geben.
Das ist das große Überding, würde ich sagen.
Alles andere ist punktuell und können wir so machen, wie wir beide das am besten aufteilen wollen. Ich habe das lang genug alleine gemacht. Es ist also nicht so, dass du da mit irgendetwas alleine bist oder da Angst haben musst.
Ich habe sowieso auf alles ein Auge und würde dich da mit nichts alleine lassen. Lass uns gleich wenn Flo aufgelegt hat auch kurz sprechen, oder halt nach unserem call um 13 uhr

2026-01-12T12:46:59.393099 - **Julia:**
> 

  📎 audio_message.m4a

2026-01-12T12:49:11.707919 - **Marvin Hammerschmidt:**
> Ja alles gut^^
Wir sprechen nach dem Call auch über Verantwortungen etc.
Das bekommen wir schon alles hin

2026-01-13T12:01:28.425349 - **Julia:**
> bin in 2 min da!

2026-01-13T12:01:40.591559 - **Marvin Hammerschmidt:**
> kein stress

2026-01-13T12:07:42.885109 - **Marvin Hammerschmidt:**
> <https://f.io/E6p5Lww5>

2026-01-13T12:15:17.892339 - **Marvin Hammerschmidt:**
> <https://drive.google.com/file/d/1gxZnZ63Dh4MNgFBt1QRVoL3rwrLU1hgr/view?usp=drive_link>

2026-01-13T14:26:03.202709 - **Marvin Hammerschmidt:**
> Könntest du mir die ssio Idee mal schicken? 

2026-01-13T14:48:05.311259 - **Julia:**
> klar, habs hier unter Videodreh – Skripte etc. sind noch nicht freigegeben von Flo, hab ich ihm eben geschickt. Die Grundidee mit dem FKK Video kam aber von Flo/ Alex

  📎 260113_BCCxLIDL_Kollektion_JH.pdf

2026-01-13T14:59:24.493639 - **Marvin Hammerschmidt:**
> Ah danke :slightly_smiling_face:

2026-01-14T09:05:39.800999 - **Marvin Hammerschmidt:**
> GuMo Juli :slightly_smiling_face:

Hast du den Invite bekommen?

2026-01-14T09:21:47.268639 - **Julia:**
> Hi! Yes, kam an :slightly_smiling_face: danke

2026-01-14T09:22:08.172489 - **Julia:**
> Wissen sie denn schon von mir? Bzw. wurde ich schon in einer Form angekündigt? Bzgl. Vorstellung

2026-01-14T09:22:36.719599 - **Marvin Hammerschmidt:**
> Ich habe gesagt dass da jemand neues kommt
Mehr nicht

2026-01-14T09:22:42.966299 - **Marvin Hammerschmidt:**
> lass uns vorher nochmal kurz sprechen

2026-01-14T09:23:10.149109 - **Julia:**
> Okay, ja gern. Würde es dann recht knapp halten und sagen ich unterstütze jetzt auch im Team – muss ja keinen Fokus nennen

2026-01-14T09:23:20.688929 - **Marvin Hammerschmidt:**
> yes

2026-01-14T09:23:37.432659 - **Marvin Hammerschmidt:**
> Flo hat mir ein paar sachen geschickt
Darüber reden wir gleich und schauen wie wir das smart sagen

2026-01-14T09:23:49.755719 - **Julia:**
> Klar hat er das :smile:

2026-01-14T09:23:51.804009 - **Julia:**
> So machen wir es

2026-01-14T09:41:00.465409 - **Marvin Hammerschmidt:**
> Hab dir noch nen Termin geschickt
Sorry hab nicht gesehen das es 2 sind heut

2026-01-14T09:51:30.409809 - **Julia:**
> okay alles klar

2026-01-14T09:51:44.206689 - **Julia:**
> sag mal wie heißt das Sixt Projekt in Clockify? Ich finde das nicht

2026-01-14T10:24:45.847699 - **Marvin Hammerschmidt:**
> Sixt retainer.   Schaue gleich genau. Muss noch was fertig machen :)

2026-01-14T10:43:58.730839 - **Marvin Hammerschmidt:**
> 2023-SIXT-Retainer-TikTok

2026-01-14T10:44:10.370629 - **Marvin Hammerschmidt:**
> Wann sollen wir vorher noch kurz sprechen :slightly_smiling_face:?
Meeting ist um 2

2026-01-14T10:46:56.380149 - **Julia:**
> kannst du um 11.45?

2026-01-14T10:47:31.279729 - **Marvin Hammerschmidt:**
> yes

2026-01-14T11:04:08.797179 - **Julia:**
> super, ich huddle dich dann gleich an

2026-01-14T11:45:23.737329 - **USLACKBOT:**
> 

2026-01-14T14:01:49.549079 - **Julia:**
> hänge im warteraum

2026-01-14T15:03:01.181349 - **Marvin Hammerschmidt:**
> rufe dich gleich kurz an :;

2026-01-14T15:03:07.902209 - **Julia:**
> perfekt

2026-01-14T15:04:26.298399 - **USLACKBOT:**
> 

2026-01-14T15:05:36.593619 - **Julia:**
> 

  📎 Bildschirmfoto 2026-01-14 um 14.35.39.png

2026-01-14T17:39:28.221439 - **Marvin Hammerschmidt:**
> ehrlicher gedanke?

Ich habe sorge dass das zu boring ist und highlights fehlen

2026-01-14T17:40:12.771169 - **Julia:**
> finde es sehr werblich

2026-01-14T17:40:23.470209 - **Marvin Hammerschmidt:**
> ich sag gleich was

2026-01-14T17:40:44.063849 - **Julia:**
> sie haben den pitch schon abgeschickt, also ändern wird eh schwierig

2026-01-14T17:40:51.115949 - **Marvin Hammerschmidt:**
> oh

2026-01-14T17:41:07.390799 - **Marvin Hammerschmidt:**
> das ist schlecht

2026-01-14T18:04:41.885899 - **Marvin Hammerschmidt:**
> Interessant

2026-01-14T18:04:46.434709 - **Julia:**
> :smile:

2026-01-14T18:04:54.963519 - **Julia:**
> Meinungen werden ja auch nicht unbedingt aufgenommen

2026-01-14T18:05:11.861199 - **Julia:**
> Naja, ich muss jetzt pünktlich los! Ich meld mich morgen gleich bei dir :slightly_smiling_face: happy evening!

2026-01-14T18:05:37.788369 - **Marvin Hammerschmidt:**
> Das ging sogar noch haha 

Yes. Machen wir.  Danke gleichfalls :)

2026-01-15T10:09:41.456229 - **Julia:**
> Hello! also ich hab jetzt die Präsi nochmal durchgelesen. Mein fav. Part wäre: 19-23 (also der Consistency Part)
Bezüglich Endslides hab ich tatsächlich das Gefühl, dass das eher bei Flo liegen sollte mit Versprechen usw. 

Hast du schon eine Meinung dazu? :slightly_smiling_face:

2026-01-15T10:10:21.526069 - **Marvin Hammerschmidt:**
> hello
Verstehe generell noch nicht zu n100% warum wir da mit einsteigen

Ich bin noch bis 12 busy und schau es mir dann an und melde mich bei dir :slightly_smiling_face:

2026-01-15T10:12:36.804469 - **Julia:**
> ja same :joy:

2026-01-15T10:13:12.957019 - **Julia:**
> klaro 

2026-01-15T12:48:59.379089 - **Marvin Hammerschmidt:**
> sorry
rede noch mit Flo

2026-01-15T12:49:47.531969 - **Julia:**
> hab ich mir schon gedacht. bin im büro und er hatte einmal deinen Namen gesagt. ist dann aber ins Nebenzimmer :smile:

2026-01-15T12:50:15.961539 - **Marvin Hammerschmidt:**
> Ja ein klein wenig beef :smile:

2026-01-15T12:50:20.512579 - **Marvin Hammerschmidt:**
> as usual
So ich schaus mir jetzt an

2026-01-15T12:53:34.845099 - **Marvin Hammerschmidt:**
> alright dann mach ich etwas den bad cop mit 13-19 :smile:

Fühlt sich an wie ein Schulreferat

2026-01-15T12:54:02.752289 - **Marvin Hammerschmidt:**
> Flo wäre es schon wcihtig wenn du mit in das jarhes kickoff kommst mit sixt und er hat da schon recht 
Meinst du das wäre irgendwie möglich oder bist du um 2 im Flugzeug?

2026-01-15T13:10:52.818909 - **Julia:**
> oh wieso bad cop?

2026-01-15T13:11:06.214039 - **Julia:**
> den schluss macht dann flo? oder sagen wir es ihm nochmal?

2026-01-15T13:11:17.305539 - **Marvin Hammerschmidt:**
> Müssen wir noch besprechen

2026-01-15T13:12:27.447339 - **Julia:**
> ich lande laut plan um 13.30. Wenn ich dazu kommen kann, klar. ich kann leider garnicht einschätzen wie es dort am Flughafen ist. Ist ein kleiner :smile:

2026-01-15T13:12:41.333109 - **Julia:**
> also im Hotel oder so sind wir da noch nicht. Brauchen dort mit dem auto nochmal eine Std.

2026-01-15T13:29:55.579609 - **Marvin Hammerschmidt:**
> Das ist natürlich tight
Meisnte mobil ohne Kamera geht dazwischen?
Ich weiß  das ist stressig :disappointed:

2026-01-15T15:39:05.881729 - **Julia:**
> ja, ich probiers aber kanns wie gesagt nicht versprechen

2026-01-15T15:39:21.433299 - **Marvin Hammerschmidt:**
> ja klar das ist voll ok

2026-01-15T15:42:48.462609 - **Julia:**
> wir könnten die option mit: wir wollen das nicht präsentieren auch mal noch versuchen :smile:

2026-01-15T15:42:58.115419 - **Marvin Hammerschmidt:**
> hahahahahah

2026-01-15T15:43:19.698999 - **Marvin Hammerschmidt:**
> ich glaub nicht das es dafür eine chance gibt:D

2026-01-15T15:43:33.298879 - **Julia:**
> :sadblob:

2026-01-16T09:29:01.259369 - **Marvin Hammerschmidt:**
> Hey Juli
Hast du zeit um 11 mit ins SIXT meeting zu kommen? Katharina ist nicht da aber wir können über Romina ein paar Zugriffe anfragen

2026-01-16T09:32:23.295409 - **Julia:**
> Hello! Leider nein, wir drehen heute ab 11.30. Ich bin gleich nichtmehr am Laptop

2026-01-16T09:32:37.948989 - **Julia:**
> ich weiß, dass Flo das super wichtig ist (und ist es ja auch) aber ich kann mich nicht 2teilen

2026-01-16T09:32:41.322889 - **Marvin Hammerschmidt:**
> Alles klar
ich schau ob die ohne dich organisieren kann :slightly_smiling_face:

2026-01-16T09:32:50.161019 - **Marvin Hammerschmidt:**
> ne verstehe ich vollkommen haha
Keine Sorge

2026-01-16T09:33:26.629879 - **Marvin Hammerschmidt:**
> Viel Spaß beim Dreh!

2026-01-16T09:33:34.314659 - **Julia:**
> okay, danke und sorry!

2026-01-16T09:34:12.928659 - **Marvin Hammerschmidt:**
> Brauchst dich da echt nicht für entschuldigen
Ich weiß wie das ist
Habs auch gestern bei Flo nochmal angesprochen
So ganz sehen tut ers nicht aber naja wir schauen mal
Das wird schon

2026-01-16T09:34:17.159859 - **Julia:**
> ja ich weiß. es ärgert mich einfach, dass da kein verständnis da ist bzw. die kapa planung einfach nicht bedacht wird oder whatever :smile: auch mit Montag

2026-01-16T09:34:43.398459 - **Julia:**
> ja ich werd da nächste Woche auch nochmal was sagen

2026-01-16T09:34:52.735659 - **Julia:**
> danke dir :heart_hands:

2026-01-16T09:40:13.060939 - **Marvin Hammerschmidt:**
> Er meinte zu mir, dass 60 % schon sehr viel von deiner Kapa ist
Ich habe ihm dann gesagt, dass das zwar stimmt, ich aber nicht glaube, dass du wirklich 60% frei hast.
Und dazu sagte er nur, dass du bei Hisense weniger mit der Produktion zu tun hast und ihr da angeblich Dinge macht, um dir Zeit freizuschaufeln. Und wenn das noch nicht reicht, solle ich mich bei ihm melden, damit ihr da noch mehr macht

2026-01-16T09:41:47.252399 - **Julia:**
> ja machen wir auch. aber trotzdem muss ich nach Dänemark hinfliegen und heute LIDL drehen, das meinte ich :slightly_smiling_face: manche Sachen muss man ja trotzdem machen

2026-01-16T09:42:23.783329 - **Marvin Hammerschmidt:**
> Wie gesagt, ich verstehs komplett :smile:
Kapazitäten werden von außen oft falsch eingeschätzt

2026-01-16T09:53:05.211959 - **Julia:**
> das ist meine neue Nummer: 015902014144
Für die whatsapp gruppen etc :slightly_smiling_face:

2026-01-16T09:53:19.497209 - **Marvin Hammerschmidt:**
> Perfekt
Danke!

2026-01-16T09:53:29.339889 - **Julia:**
> richte es gerade ein

2026-01-16T09:54:44.982989 - **Marvin Hammerschmidt:**
> Für den Workshop: Ich hab dein Sheet um 2 Ideen ergänzt
Wir müssen im Hintergrund dann die ein oder andere Idee noch etwas ausformulieren aber das muss ja erstmal nicht auf die FOlie
Ich geb sie dann so an Jana

2026-01-16T09:55:27.449599 - **Julia:**
> 

  📎 IMG_0021.PNG

2026-01-16T09:55:42.465189 - **Julia:**
> okay cool! schau ich mir asap an :slightly_smiling_face:

2026-01-16T09:56:33.113599 - **Marvin Hammerschmidt:**
> Absolut nichts bahnbrechendes tbh:D

2026-01-16T16:46:39.764779 - **Julia:**
> Bin wieder da :slightly_smiling_face: Du hast mich noch zu keiner Gruppe eingeladen, oder? Nur falls es nicht geklappt haben sollte

2026-01-16T16:47:04.156619 - **Marvin Hammerschmidt:**
> Servus
Ne wir kamen leider zu absolut NICHTS:D

2026-01-16T16:47:40.995479 - **Julia:**
> alles gut haha

2026-01-16T16:47:52.661259 - **Marvin Hammerschmidt:**
> Wie war der Dreh?

2026-01-16T16:47:53.331509 - **Julia:**
> aber passt alles oder was passiert?

2026-01-16T16:48:10.066159 - **Marvin Hammerschmidt:**
> Nene nichts besonderes. All good.  Gab nur viel zu tun :sweat_smile:

2026-01-16T16:48:54.466359 - **Julia:**
> sehr witzig :joy:  hat alles gut geklappt und war nicht so kalt

  📎 Bildschirmfoto 2026-01-16 um 16.48.31.png

2026-01-16T16:49:15.667099 - **Marvin Hammerschmidt:**
> Haha geil die lidletten :sweat_smile:

2026-01-16T16:49:40.576889 - **Julia:**
> richtig schön designt :smile:

2026-01-20T11:15:24.618959 - **Marvin Hammerschmidt:**
> Hey Juli
Bist du schon wieder im Land :slightly_smiling_face:?

2026-01-20T11:26:12.478249 - **Julia:**
> Hello! Ne sind heute noch in Dänemark

2026-01-20T11:43:35.061899 - **Marvin Hammerschmidt:**
> Ah mist.
Bin etwas besorgt ob wir nicht vor dem Kickoff mit Flo nochmal ein paar Dinge irgendwie "durchgehen" nicht das er das gefühl hat es ist noch nichts passiert aber bisher warst du ja auch eigentlich wirklich durchgehend in anderen Dingen eingebunden

2026-01-20T11:49:09.516469 - **Julia:**
> wir können morgen davor sprechen. Du ich mach mir da garkeinen Stress, der soll ruhig merken, dass die Planung so nicht funktioniert

2026-01-20T11:50:02.204639 - **Julia:**
> der wollte, dass Mert gestern im Flugzeug LIDL schneidet. obs ging oder ob er wie ein T-Rex dort saß? Also sorry, ich zieh ihm schon noch den Zahn von unrealistischen Erwartungen/ Timings

2026-01-20T11:50:11.644719 - **Julia:**
> Ich weiß garnicht, für was der Termin morgen sein soll?

2026-01-20T11:54:35.356389 - **Marvin Hammerschmidt:**
> Das ist ein Mammut Projekt :smile:

Ja ich hab auch extra nachgefragt: "Rollen, Prozesse, Learnings und was wir wie standardisieren können"

2026-01-20T11:55:56.356519 - **Julia:**
> okay

2026-01-20T11:56:15.791289 - **Julia:**
> ja dann lass uns gerne morgen vormittags sprechen?

2026-01-20T11:58:13.058709 - **Marvin Hammerschmidt:**
> Können wir machen 11:30 -12:00 haben wir ja eh sixt meeting

2026-01-20T11:58:41.110549 - **Julia:**
> Ah das hab ich noch nicht im Kalender :slightly_smiling_face:

2026-01-20T12:00:17.107219 - **Marvin Hammerschmidt:**
> Ich lad dich ein
Das müssen wir mit Katharina nochmal klären :slightly_smiling_face:

2026-01-20T12:07:59.186329 - **Marvin Hammerschmidt:**
> Einladung bekommen?

2026-01-20T12:12:55.246419 - **Julia:**
> yes! danke

2026-01-20T13:00:10.567359 - **Julia:**
> btw: würdest du meine neue Nummer in die BCC Creative Whatsapp Gruppe reinnehmen?

2026-01-20T13:07:24.092469 - **Marvin Hammerschmidt:**
> done :slightly_smiling_face:

2026-01-20T13:11:34.946519 - **Julia:**
> Danke!

2026-01-20T21:42:20.884699 - **Julia:**
> Für dich als Info: wir haben den Anschlussflug verpasst weil wir Verspätung hatten und sind jetzt in Amsterdam. der nächste Rückflug ist morgen Vormittag, kann also wieder nicht am Meeting um 11.30 Uhr teilnehmen. Lieben wir :face_exhaling:

2026-01-20T21:42:57.566039 - **Marvin Hammerschmidt:**
> Ach du scheiße. Ihr armen :flushed:

2026-01-20T21:43:50.155519 - **Marvin Hammerschmidt:**
> Ja alles gut. Ich mach das. Das wird Flo ja verstehen denke ich 
Habt ihr n Hotel gefunden? 

2026-01-21T07:16:09.898559 - **Julia:**
> Danke dir! 
Ja hat alles gut geklappt :) wenigstens das haha

2026-01-21T13:20:21.056189 - **Julia:**
> Hi Marvin! Ich wäre jetzt am Laptop

2026-01-21T13:20:25.878169 - **Julia:**
> Falls du etwas besprechen willst

2026-01-21T13:20:43.867249 - **Marvin Hammerschmidt:**
> Hey
Juli
Lass mich kurz was fertig mache, dann ruf ich dich an

2026-01-21T13:20:54.847129 - **Julia:**
> Okay

2026-01-21T13:34:50.326229 - **USLACKBOT:**
> 

2026-01-22T15:32:33.532059 - **Julia:**
> Hello! Sollen wir morgen nach dem Check-In zum projektplan sprechen?

2026-01-22T15:32:56.774089 - **Marvin Hammerschmidt:**
> Jana sollte uns eigentloch vor dem Meeting was einstellen

2026-01-22T15:33:06.826809 - **Marvin Hammerschmidt:**
> hat sie leider nicht
Hab aber gleich ein gespräch mit ihr

2026-01-22T15:34:15.806129 - **Marvin Hammerschmidt:**
> Falls sie mir das einrichtet....
Also ja machen wir, hab mir aber einen überblick verschafft und gesehen das wir Jana brauchen :slightly_smiling_face:

2026-01-22T15:34:53.114669 - **Julia:**
> okay

2026-01-22T15:34:59.401589 - **Julia:**
> alles klar

2026-01-22T15:35:06.531289 - **Marvin Hammerschmidt:**
> Alles sehr ärgerlich :smile:

2026-01-22T15:35:30.491029 - **Julia:**
> ich bin morgen ab 10 Uhr ca. am laptop, davor hab ich physio

2026-01-22T15:35:36.795359 - **Marvin Hammerschmidt:**
> All good Dann danach :slightly_smiling_face:

2026-01-22T15:45:49.066469 - **Julia:**
> ja wie gesagt von 10 irgendwas -11 garkein Stress

2026-01-22T15:45:59.551899 - **Julia:**
> Oder danach, je nachdem was Jana einstellt haha

2026-01-22T15:46:09.664019 - **Marvin Hammerschmidt:**
> Wir können das auch Montag machen
Nimm dir deinen ausgleich

2026-01-22T15:47:37.307199 - **Julia:**
> Mir ist beides Recht. Ich muss da nur etwas dagegen reden, weil er meine Anfrage ja komplett ignoriert und ich seh das nicht ein :smile: irgendwann reichts auch. Sowieso gestern wieder bis 20 Uhr

2026-01-22T15:48:02.503789 - **Marvin Hammerschmidt:**
> Ich kenn das
ALl good
Ich möchte dich da nicht zusätzlich beladen!!!

2026-01-22T15:48:25.284559 - **Marvin Hammerschmidt:**
> Würde generell nochmal mit Flo sprechen weil ich den Sinn hinter über 10 STD auto fahren (wenns gut läuft) um 5 Folien vorzutragen nicht sehe

2026-01-23T08:46:50.071949 - **Julia:**
> Hello! Es gibt noch keinen Termin von Jana oder? :sweat_smile:

2026-01-23T08:47:12.337359 - **Julia:**
> Ja. Der Sinn würde mich da auch interessieren 

2026-01-23T08:47:16.423639 - **Marvin Hammerschmidt:**
> Good morning

Nop
Habs ihr gerad auch nochmal gesagt

2026-01-23T08:48:15.484659 - **Marvin Hammerschmidt:**
> Gibt da generell gerad einige Probleme
SIXT ist sehr unzufrieden damit wie unregelmäßig Jana antwortet etc.

2026-01-23T08:48:53.873049 - **Julia:**
> Ja hab ich mir schon gedacht. Hab eben alle Nachrichten durchgelesen 

2026-01-23T08:49:20.214929 - **Marvin Hammerschmidt:**
> Sie haben mich mehrfach angerufen um sich zu beschweren aber ich bekomme Jana einfach nicht in Termine
Das ist echt richtig kacke

2026-01-23T08:49:42.979109 - **Julia:**
> Aber was sagt sie dazu? Oder ignoriert sie es? 

2026-01-23T08:50:10.475649 - **Julia:**
> Das kann man einfach nicht machen 

2026-01-23T08:50:13.790429 - **Marvin Hammerschmidt:**
> Gibt immer nen Grund weswegen sie jetzt gerade nicht sprechen kann

2026-01-23T08:50:28.313799 - **Julia:**
> Ahja oke 

2026-01-23T08:50:32.165979 - **Julia:**
> :no_mouth:

2026-01-23T09:49:50.262389 - **Marvin Hammerschmidt:**
> Jetzt haben wir was drin

2026-01-23T09:49:52.044929 - **Marvin Hammerschmidt:**
> 10:15

2026-01-23T09:52:24.244239 - **Julia:**
> okay ich beeile mich 

2026-01-23T09:52:56.496169 - **Marvin Hammerschmidt:**
> Sorry dass das für Stress sorgt. Mir sind die Hände gebunden ich muss nehmen was ich kriegen kann :sob:

2026-01-23T09:54:21.684059 - **Julia:**
> Alles gut. Macht Sinn :) 

2026-01-23T09:54:47.950049 - **Julia:**
> Evtl bin ich 5 min später dran aber ich geb dir nochmal Bescheid 

2026-01-23T09:55:07.416309 - **Marvin Hammerschmidt:**
> Das ist kein Problem 

2026-01-23T09:55:12.997099 - **Marvin Hammerschmidt:**
> Müssen uns ja eh erst sortieren 

2026-01-23T10:12:26.973609 - **Julia:**
> oke, brauch noch paar Minuten! 

2026-01-23T10:59:50.884359 - **Julia:**
> liebs auch einfach

2026-01-23T11:00:17.547579 - **Julia:**
> Bin im Pitch mit drin, aber bekomme seit 2 Wochen keine Infos mehr, was die Kampagne ist oÄ. Aber den Content dazu musste ich erstellen :smile:

2026-01-23T11:00:20.344209 - **Julia:**
> wegen montag

2026-01-23T11:01:02.796869 - **Marvin Hammerschmidt:**
> Uf

2026-01-26T10:55:58.091799 - **Marvin Hammerschmidt:**
> Guten Morgen :slightly_smiling_face:
Wie sehr bist du heute eingebunden?

2026-01-26T11:04:39.250939 - **Julia:**
> Hello! Mit 2 Std. Pitch schon etwas :smile: Aber können gerne um 11.30 sprechen?

2026-01-26T11:04:51.488119 - **Marvin Hammerschmidt:**
> Machen wir :slightly_smiling_face:

2026-01-26T11:24:05.002069 - **Julia:**
> Ich ruf dich gleich an, sobald der Call rum ist

2026-01-26T11:24:16.994329 - **Marvin Hammerschmidt:**
> all good
Kein stress

2026-01-26T11:37:29.607939 - **USLACKBOT:**
> 

2026-01-26T12:03:40.966209 - **Julia:**
> Ah ganz vergessen!

2026-01-26T12:03:56.348999 - **Julia:**
> hattest du noch mit Flo wegen Decathlon gesprochen?

2026-01-26T12:04:02.158159 - **Julia:**
> Das kommt ja heute auch noch :face_with_peeking_eye:

2026-01-26T12:04:40.771099 - **Marvin Hammerschmidt:**
> Ja
Also ich buch mir n Hotel und werd da schlafen
Aber mit muss ich

Feedback zu meinem Video hab ich noch nicht bekommen

2026-01-26T12:05:11.184939 - **Julia:**
> Ah okay, aber das ist ja schon mal gut! Bzw. besser als die Hin-und Herfahrerei

2026-01-26T12:06:33.043579 - **Marvin Hammerschmidt:**
> definitiv

2026-01-26T12:44:12.823629 - **Julia:**
> Im Plan "Fahrer" sind die gemeint, die die Sixt Autos dann in den Videos fahren..?

2026-01-26T12:44:25.538019 - **Julia:**
> oder wer soll das sein?

  📎 Bildschirmfoto 2026-01-26 um 12.44.01.png

2026-01-26T12:45:53.702339 - **Marvin Hammerschmidt:**
> Würd ich raus nehmen. Das ist das Problem der Produktionsfirma 

2026-01-26T12:46:01.148969 - **Julia:**
> okay

2026-01-26T12:46:09.323399 - **Julia:**
> aber sind das nicht die Creator dann?

2026-01-26T12:46:15.270679 - **Julia:**
> verstehe den Punkt nicht ganz

2026-01-26T12:46:22.249639 - **Marvin Hammerschmidt:**
> Creator Sind ja an sich die Teilnehmer oder?

2026-01-26T12:46:26.509669 - **Julia:**
> ja

2026-01-26T12:46:32.784089 - **Marvin Hammerschmidt:**
> Und da würde ich auch eher actor sagen als creator 

2026-01-26T12:46:41.088389 - **Marvin Hammerschmidt:**
> Die sollten ja nicht bekannt sein 

2026-01-26T12:46:48.859889 - **Marvin Hammerschmidt:**
> Ja nimm einfach raus. Ist seltsam 

2026-01-26T12:47:15.304039 - **Julia:**
> passt

2026-01-26T15:52:46.092389 - **Julia:**
> Mir kam grad noch ein Gedanke für die sixt content reihen

2026-01-26T15:53:06.931299 - **Marvin Hammerschmidt:**
> Ah cool
Erzähl

2026-01-26T15:53:26.075729 - **Julia:**
> ihr habt ja dieses Video gemacht mit der DB

2026-01-26T15:53:39.951689 - **Marvin Hammerschmidt:**
> Das war JVM aber ja

2026-01-26T15:55:20.177579 - **Julia:**
> Ah schade

2026-01-26T15:55:44.019039 - **Marvin Hammerschmidt:**
> Egal
Erzähl trotzdem :smile: muss ja nicht wichtig dafür sein

2026-01-26T15:57:53.407269 - **Julia:**
> Idee 1: DB Abklatsch: SIXT Serie mit Mitarbeitenden
Idee 2: Herzblatt/ Speed Dating in Auto

  📎 audio_message.m4a

2026-01-26T15:59:48.910699 - **Marvin Hammerschmidt:**
> Hab tatsächlich beides schonmal vorgeschlagen :smile:
Denke wenn wir das nochmal bringen wollen müssen wir das nochmal expiziter amchen

Dating show hab ich sogars ausgearbeitet aber hat flo nicht gefallen

2026-01-26T16:00:38.573849 - **Julia:**
> :no_mouth:

2026-01-26T16:00:55.414459 - **Julia:**
> Okay okay

2026-01-26T16:01:11.864649 - **Julia:**
> also Dating und Valentines Day wäre natürlich sehr passend

2026-01-26T16:01:29.971979 - **Marvin Hammerschmidt:**
> Können das gern nochmal versuchen

2026-01-26T16:01:33.389429 - **Marvin Hammerschmidt:**
> Ich fands ja auch gut

2026-01-26T16:01:39.304379 - **Marvin Hammerschmidt:**
> Und ich glaube sixt würds auchg efallen

2026-01-26T16:02:01.022209 - **Julia:**
> okay :smile: ich mach jetzt erstmal den Projektplan fertig

2026-01-26T16:02:08.679019 - **Julia:**
> LIDL war leider nicht gut

2026-01-26T16:02:17.994929 - **Marvin Hammerschmidt:**
> war nicht gut?

2026-01-26T16:02:20.743679 - **USLACKBOT:**
> 

2026-01-26T17:39:57.284599 - **Julia:**
> So schau gerne mal in den Projektplan, obs für dich so Sinn ergibt

2026-01-26T17:40:03.590479 - **Julia:**
> Timing ist SO KNAPP

2026-01-26T17:40:31.983509 - **Marvin Hammerschmidt:**
> Dann lass uns ne 2. Version machen mit ner zeitplanung die machbarer ist 

2026-01-26T17:40:51.250859 - **Marvin Hammerschmidt:**
> Es ist halt wieder viel auf einmal
Dieser Workshop schman auch. Das werden wir ja auch umsetzen müssen 

2026-01-26T17:41:36.900039 - **Marvin Hammerschmidt:**
> Die stellen wir dann vor
Wenn sie dann sagen „ne muss schneller“ dann zeigen sie den tighten 

2026-01-26T17:41:45.537289 - **Julia:**
> ja können wir auvh

2026-01-26T17:42:16.542829 - **Marvin Hammerschmidt:**
> Lass uns da morgen drüber sprechen ich hab heut keinen Nerv mehr haha sorry 


2026-01-26T17:42:27.489219 - **Marvin Hammerschmidt:**
> Schaue es mir aber gleich sxhonmal an :)

2026-01-26T17:42:35.378599 - **Julia:**
> alles gut :smile: mache jetzt auch mal Decathlon

2026-01-26T17:43:08.433639 - **Marvin Hammerschmidt:**
> Inhalt scheinbar nicht so wichtig. Fokus eher auf klare Betonungen 

2026-01-26T17:43:35.673049 - **Julia:**
> gut, dann mach ich meine eigene Präsentation :smile:

2026-01-26T17:43:49.385109 - **Julia:**
> bau noch kurz eigene Slides ups :rolling_on_the_floor_laughing:

2026-01-26T17:43:59.791119 - **Marvin Hammerschmidt:**
> :joy:

2026-01-26T17:51:13.772629 - **Julia:**
> nicht wundern, das kann man alles aufklappen. würde es aber so gruppiert lassen, sonst erschlägt es einen

  📎 Bildschirmfoto 2026-01-26 um 17.50.37.png

2026-01-26T17:51:38.196519 - **Marvin Hammerschmidt:**
> Ja sieht gut aus so 

2026-01-27T09:31:23.034689 - **Julia:**
> Guten Morgen!

2026-01-27T09:31:30.399549 - **Julia:**
> Können wir unser Meeting um 11.30 starten?

2026-01-27T09:31:37.479079 - **Marvin Hammerschmidt:**
> Good morning :slightly_smiling_face:
Machen wir

2026-01-27T09:31:42.876559 - **Julia:**
> Danke dir :slightly_smiling_face:

2026-01-27T12:13:09.430509 - **Julia:**
> ich hab Marie Idee 2 mal geschickt für weitere Ideen7/ Skripte "Mittelweg von matcha und Haftbefehl"

2026-01-27T12:13:55.655839 - **Marvin Hammerschmidt:**
> &gt; gute idee

2026-01-27T12:17:19.813509 - **Julia:**
> hui

2026-01-27T12:17:28.783609 - **Julia:**
> ist da immer so eine passiv aggressive stimmung?

2026-01-27T12:17:55.985529 - **Marvin Hammerschmidt:**
> Mir gegenüber selten aber gegen flo eig immer ja:D

2026-01-27T12:18:39.622589 - **Marvin Hammerschmidt:**
> drüber stehen

2026-01-27T12:20:09.270069 - **Julia:**
> 

  📎 audio_message.m4a

2026-01-27T12:25:34.713639 - **Marvin Hammerschmidt:**
> Ne ist auch eig unsinn
Liegt aber daran das das workshop ding ihre aufgabe ist

2026-01-27T12:25:38.024219 - **Marvin Hammerschmidt:**
> und wir nur zuarbeiten

2026-01-27T12:25:39.148199 - **Marvin Hammerschmidt:**
> eigentlich

2026-01-27T12:27:19.639289 - **Julia:**
> okay

2026-01-27T15:36:03.738979 - **Julia:**
> Marie hat die Ideen ausformuliert --&gt; Gibt es die Autos alle bei SIXT? Da hab ich keine Ahnung und sie hatte es nicht überprüft. Weißt du das?

2026-01-27T15:37:12.465369 - **Marvin Hammerschmidt:**
> Schaue mir das gleich an
Hab hier gerad etwas baby struggle

Bin immernoch kein Fan der Art und Weise tbh

2026-01-27T15:37:21.655849 - **Marvin Hammerschmidt:**
> Hab sonst zu allem schonmal ein bisschen was geschrieben

2026-01-27T15:38:29.647539 - **Marvin Hammerschmidt:**
> außer das Prank ding
Da fällt mir bisher nichts zu sein

2026-01-27T15:38:46.696789 - **Julia:**
> oh nein, aber alles okay?

2026-01-27T15:38:55.970779 - **Julia:**
> was meinst du welche Art und Weise?

2026-01-27T15:39:19.594949 - **Julia:**
> Okay sehr gut, schau ich mir dann auch gleich an. Muss noch was anderes für Flo machen :no_mouth:

2026-01-27T15:39:34.260389 - **Marvin Hammerschmidt:**
> Joa das weiß man gerad nicht so genau:D
Das hemmt auch gerad etwas meine Gedanken

Das mit dem Singen etc
ABer ich schau da noch drüber und denk nach:)

2026-01-27T15:39:36.220829 - **Marvin Hammerschmidt:**
> natürlich :smile:

2026-01-27T15:40:22.587539 - **Julia:**
> Oh nein, ja dann nimm dich bitte raus!

2026-01-27T15:40:31.667029 - **Marvin Hammerschmidt:**
> all good

2026-01-27T17:19:30.151209 - **Marvin Hammerschmidt:**
> mach dir keine sorge wegen dem "möglichst viel" das ist ecjht smarter und vor sixt vortragen ist recht angenehm tbh

2026-01-28T10:50:57.417159 - **Julia:**
> Hello! Hast du eine Idee wer der Moderator bei Carpool Karaoke sein könnte?

2026-01-28T10:51:26.093559 - **Marvin Hammerschmidt:**
> Hab einen rausgesucht den ich extrem lustig finde <https://www.instagram.com/zachjustice/?hl=en>

2026-01-28T10:51:28.242649 - **Marvin Hammerschmidt:**
> zach justice

2026-01-28T10:51:56.910539 - **Julia:**
> Ah okay, der auch als Moderator. dachte nur für den roast aber passt

2026-01-28T10:51:59.191239 - **Marvin Hammerschmidt:**
> Lass uns gern nach dem SIXT call nochmal kurz quatschen
Evtl finden wir für das ai video und die personalities zusammen ne bessere lösung

2026-01-28T10:52:08.316659 - **Marvin Hammerschmidt:**
> nene find den generell gut da der sehr lustig und spontan ist

2026-01-28T10:52:12.219129 - **Marvin Hammerschmidt:**
> das bringt "sixtyness" rein

2026-01-28T10:52:47.812169 - **Julia:**
> du ich bin noch nicht mal so weit. ich bin bei der videoerstellung für Love is blind seit 2 std. also wie gesagt das dauert :smile:

2026-01-28T10:53:23.757609 - **Marvin Hammerschmidt:**
> für den Kunden wirds ok sein wenn wir da keine videos haben
Das ist wieder so ne extrameile

2026-01-28T10:53:39.380209 - **Marvin Hammerschmidt:**
> woran harkts denn da?
Soll ich mich da auch dran versuchen?

2026-01-28T10:54:49.243209 - **Julia:**
> 

  📎 audio_message.m4a

2026-01-28T10:55:18.760709 - **Marvin Hammerschmidt:**
> Zusammenschneiden einfach an basti geben
Dafür ist er da :slightly_smiling_face:

2026-01-28T10:55:24.888489 - **Julia:**
> oder so!

2026-01-28T10:56:10.296999 - **Marvin Hammerschmidt:**
> Der mpsste auch kapazitäten haben
Also wenn du da was hast wo er helfen kann bezieh ihn gern mit ein

2026-01-28T11:14:51.641769 - **Julia:**
> kurze Frage: bisher habt ihr auch noch kein proforma Asana Board?

2026-01-28T11:15:22.274979 - **Marvin Hammerschmidt:**
> <https://app.asana.com/1/1199360402832734/project/1211046662010247/list/1211047329988574>

2026-01-28T11:15:39.769399 - **Marvin Hammerschmidt:**
> doch aber ich persönlich nutze es kaum um ehrlich zu sein
Ich organisier mich mit der sixt check in liste

2026-01-28T11:15:49.983539 - **Marvin Hammerschmidt:**
> <https://docs.google.com/spreadsheets/d/1nvQxh5qkGXqmgdXObbcezfEAk8IOAGEf2L0PU_DXLW8/edit?usp=sharing>

2026-01-28T11:16:41.569429 - **Julia:**
> okay ja da hab ich keinen Zugriff

2026-01-28T11:16:51.306589 - **Julia:**
> okay verstehe

2026-01-28T11:16:58.446939 - **Marvin Hammerschmidt:**
> auf asana?

2026-01-28T11:16:59.840599 - **Marvin Hammerschmidt:**
> moment

2026-01-28T11:17:03.628409 - **Julia:**
> ja ich erstell die Tasks für Basti dann mal so

2026-01-28T11:17:35.177349 - **Marvin Hammerschmidt:**
> Hab dir eine Einladung geschickt
Dachte Jana hat das bereits gemacht

2026-01-28T11:17:47.261209 - **Julia:**
> ne, hab sie auch schon 2 mal gefragt

2026-01-28T11:18:00.768669 - **Julia:**
> dankee habs!

2026-01-28T11:19:24.859259 - **Marvin Hammerschmidt:**
> Große Klasse :smile:

2026-01-28T11:23:14.390279 - **Julia:**
> und der verlinkte Ordner in Drive ist leer :no_mouth:

  📎 Bildschirmfoto 2026-01-28 um 11.22.42.png

2026-01-28T11:23:23.898529 - **Julia:**
> oder ich kanns auch immer noch nicht sehen

2026-01-28T11:23:34.511469 - **Marvin Hammerschmidt:**
> Da hat Basti was geändert
Sekunde ich such den neuen

2026-01-28T11:23:40.601639 - **Marvin Hammerschmidt:**
> da gehts um generell alles was sixt angeht oder?

2026-01-28T11:23:41.151469 - **Julia:**
> okay dankee

2026-01-28T11:23:57.778409 - **Julia:**
> ja genau, ich muss ihm ja die ganzen snippets ablegen

2026-01-28T11:24:11.257189 - **Marvin Hammerschmidt:**
> <https://drive.google.com/drive/folders/19lvNlFPlsvOD0Yi0ZzJfIWp22JjbkeEY?usp=sharing>

2026-01-28T11:24:26.616609 - **Marvin Hammerschmidt:**
> Sonst auf <http://Frame.io|Frame.io>

2026-01-28T11:56:09.175649 - **Julia:**
> lass uns gleich noch sprechen, schreibe grad mit Flo

2026-01-28T11:59:49.579909 - **Marvin Hammerschmidt:**
> Yes

2026-01-28T12:00:27.230119 - **Marvin Hammerschmidt:**
> rufe dich direkt nach dem call an

2026-01-28T12:15:47.464589 - **USLACKBOT:**
> 

2026-01-28T12:39:46.519539 - **Julia:**
> gibt es irgendeinen Promi den SIXT mega feiert? oder influencer?

2026-01-28T12:40:21.330759 - **Marvin Hammerschmidt:**
> Puh
Also  so Leute wie Opa werner undso aber das ist halt zu cringe

2026-01-28T12:43:17.286369 - **Marvin Hammerschmidt:**
> Von Romina...

  📎 image.png

2026-01-28T12:43:27.322719 - **Marvin Hammerschmidt:**
> Also wir sollten bei Flo echt pushen das Julia da helfen sollte

2026-01-28T12:45:01.237329 - **Marvin Hammerschmidt:**
> Ich fürchte das wir da mal wieder zu viel auf einmal versprechen

2026-01-28T12:45:34.481149 - **Julia:**
> Ah cool

2026-01-28T12:46:14.642299 - **Julia:**
> also ich sags dir ehrlich: ich mach das so nicht weiter :smile:

2026-01-28T12:46:52.758379 - **Marvin Hammerschmidt:**
> Wir sprechen da gleich zu 3. vernünftig drüber

2026-01-28T12:47:01.401809 - **Julia:**
> Ja

2026-01-28T12:47:45.858889 - **Marvin Hammerschmidt:**
> Ich kann dann halt keinen Vaterschaftsurlaub nehmen
ist wie es ist
Ich brauche nur in dem ersten Monat wenigstens ein paar "downtimes" damit ich dinge auch mal abends erledigen kann und nicht direkt auf abruf
Dann bekommen wir das irgendwie hin

2026-01-28T12:48:12.618399 - **Julia:**
> Ne als Marvin sorry

2026-01-28T12:48:16.766059 - **Julia:**
> Auf garkeinen Fall

2026-01-28T12:48:32.319319 - **Julia:**
> Flo soll Leute einstellen die ihre Expertise ausleben können/ dürfen fertig

2026-01-28T12:48:44.956249 - **Marvin Hammerschmidt:**
> All good
Ist nicht schlimm
Hab das schon einkalkuliert

2026-01-28T12:48:53.935679 - **Julia:**
> Ja aber das macht doch keinen Sinn?

2026-01-28T12:49:36.597419 - **Marvin Hammerschmidt:**
> Er wird dir niemanden zur Seite stellen
Und selbst zu Zweit wird das schon extrem schwierig

2026-01-28T12:49:53.511239 - **Marvin Hammerschmidt:**
> Es ist dem Kunden aber extrem wichtig daher müssen wir das irgendwie hinbekommen

2026-01-28T12:50:41.725899 - **Julia:**
> Ja

2026-01-28T12:50:49.700139 - **Marvin Hammerschmidt:**
> Was sollen wir jetzt bei Flo anbringen?
Wir haben nur 30 min
Lass uns da einen genauen schlachtplan aufsetzen und die "talking points" besprechen

2026-01-28T12:52:32.316799 - **Julia:**
> • Anything or nothing --&gt; entweder mache ich das komplett, aber dann bin ich bei allen anderen Themen raus das SIXT betrifft oder Übergabe an Julia H.
• Werkstudentin --&gt; für was? Wir brauchen erfahrene Leute, niemanden den wir ein lernen müssen

2026-01-28T12:53:31.619269 - **Marvin Hammerschmidt:**
> • Content Workshop von Instagram zieht einiges an mehrarbeit mit sich. Wir müssen den Content ja auch umsetzen und es handelt sich hierbei ja nicht um 0815 Conent den man mal schnell abdreht

2026-01-28T12:53:40.582419 - **Julia:**
> ich kann und werde dich nicht covern mit Themen die ich sowieso nicht kann/ weiß + daily business + Kampagne

2026-01-28T12:53:49.804199 - **Julia:**
> ganz genau

2026-01-28T12:54:09.714789 - **Marvin Hammerschmidt:**
> Da wird er sagen " ja warum hat marvin dir das nicht gezeigt"
Darauf müssen wir halt vorbereitet sein

2026-01-28T12:54:58.330789 - **Marvin Hammerschmidt:**
> Aber siehst du
Es läuft darauf hinaus dass das nicht klappt mit dem Vaterschaftsurlaub:D
Das ist auch oK
Wie gesagt wir brauchen da nur ne "hybride" Lösung das ich einfach mir das freier einteilen kann

2026-01-28T12:57:36.604319 - **Julia:**
> Punkt 1:

2026-01-28T12:59:25.817819 - **Julia:**
> 

  📎 audio_message.m4a

2026-01-28T13:03:12.967669 - **Marvin Hammerschmidt:**
> Willkommen im Klub haha
Also ich bin froh dass du da bist!!:D

Er wird das an uns weiter geben
Für ihn ist das alles immer "nicht so schwer" das ist die problematik dahinter
Der Kunde hat aber schon nen hohen Anspruch und durchaus auch ne krasse Frequenz was den Input angeht (hast du ja gehört)
Wir bräuchten wirklich eine Julia die das organisatorische übernimmt dann du den Kreativen Part und ich den Social expert/Kreativen teil.
Das wird der Retainer halt nicht hergeben ABER das ist dann einfach nicht gut verhandelt
Ohne diesen Instagram Workshop wäre das ja auch jetzt machbar
Aber das wir für Insta noch mit Content generieren müssen ist halt einfach NOCH mehr arbeit sowohl in konzeption als auch Ausführung

2026-01-28T13:03:43.492449 - **Julia:**
> total

2026-01-28T13:04:14.134519 - **Julia:**
> also in Summe ist es ja so:
Ein Kanal on top und du für einen bestimmten Teil down --> das geht nicht :D

2026-01-28T13:04:40.530569 - **Julia:**
> muss kurz mit dem hund raus, bis gleich!

2026-01-28T13:08:36.050679 - **Marvin Hammerschmidt:**
> 

  📎 image.png

2026-01-28T13:42:12.991289 - **Julia:**
> süß

2026-01-28T14:23:02.223379 - **Marvin Hammerschmidt:**
> Das lief dann doch mal ganz gut


Also Julia mit dabei wäre massiv

2026-01-28T14:23:25.873649 - **Julia:**
> ja wirklich!

2026-01-28T14:23:48.240399 - **Julia:**
> total, wie gesagt die hat schon sooo viele Produktionen geleitet, da sind meine ein Witz dagegen und dann ist der Block einfach weg

2026-01-28T14:24:46.631719 - **Marvin Hammerschmidt:**
> Ja safe
Auf sie kann man sich zu 100% verlassen dass wenn sie das angeht das auch laufen wird
Das bringen wir auch gleich beim SIXT meeting an das wir da neue Kapazitäten für haben und eine absolute top organisatorin mit an board haben

2026-01-28T14:26:27.140889 - **Julia:**
> genau

2026-01-28T14:26:40.436549 - **Julia:**
> Oh je, Jana hat die Präsentation ja ganz anders aufgebaut :smile:

2026-01-28T18:02:42.969269 - **Julia:**
> :joy:

  📎 hf_20260128_165915_6f09c634-2bce-463a-b842-7eb6dd822e4c.mp4

2026-01-28T18:02:52.217899 - **Julia:**
> Was zur Hölle, soll das für eine Sprache sein

2026-01-28T18:03:07.949319 - **Marvin Hammerschmidt:**
> aaahahahahaha

2026-01-28T18:03:17.527919 - **Marvin Hammerschmidt:**
> fast niederländisch:D

2026-01-28T18:03:40.376389 - **Julia:**
> jaa

2026-01-28T18:03:47.248339 - **Julia:**
> deutsch kann die AI einfach noch nicht :smile:

2026-01-28T18:35:21.586969 - **Julia:**
> So hier der Status Quo. Genauso hatten wir es damals bei Porsche. Siehst ja was noch frei ist bei den Content INhalten. Textlich gerne auch noch anpassen was dir fehlt etc.
Würde dann bei der finalen Version die Videos einbauen (Basti ist dran), macht jetzt mit dem Hin und Her schicken von Präsis keinen Sinn :slightly_smiling_face:

  📎 260128_WORKSHOP_Formate_JH.pptx

2026-01-28T18:35:26.226429 - **Julia:**
> happy feierabend!

2026-01-28T18:35:42.567699 - **Julia:**
> hier noch die Videos die basti noch bearbeitet: <https://drive.google.com/drive/folders/1ipOCItOdJLWuxEmdd24BM21TNdt5McKR>

2026-01-28T18:36:30.232649 - **Julia:**
> würde Jana gegen mittags gerne die Präsi schicken, damit sie diese Slides in ihre Version baut bzw. anpasst. Sonst macht die Präsi keinen Sinn

2026-01-28T18:37:47.850339 - **Marvin Hammerschmidt:**
> Danke dir! Schau ich mir gleich an. Muss nur eben kochen :) 

2026-01-29T09:36:41.994299 - **Julia:**
> Guten Morgen

2026-01-29T09:37:03.336569 - **Marvin Hammerschmidt:**
> Guten Morgen

2026-01-29T09:47:40.255299 - **Julia:**
> Konntest du dir schon die Präsi anschauen?

2026-01-29T09:48:16.410109 - **Marvin Hammerschmidt:**
> Hab noch was neues  reinbekommen
Gib mir 10 min dann schau ichs mir an
Sorry

2026-01-29T09:48:31.649499 - **Julia:**
> Ja alles gut, kein Stress!

2026-01-29T09:57:05.784129 - **Marvin Hammerschmidt:**
> Folie 12 muss glaub ich raus

Sonst passt das oder?

2026-01-29T09:57:32.432509 - **Marvin Hammerschmidt:**
> Er wollte halt mehr ausformuliert haben, tragen wir dass dann eher vor ? Also z.b. beim ai prank oder auch beim Love is blind

2026-01-29T09:57:45.224349 - **Julia:**
> moment ich schau kurz

2026-01-29T09:57:49.968869 - **Marvin Hammerschmidt:**
> By the way: Ai prank fällt mir absolut nichts ein
Ich hab keine Ahnung irgendwie krieg ich das nicht hin gerade...

2026-01-29T09:58:56.035769 - **Julia:**
> Das interaktive Quiz? Also sollen wir nur die Variante mit RSA nehmen?

Ja genau, würde da viel zu erzählen. Also die Beispiele dann einfach sagen. Können wir ja easy in die Besprechungsnotizen packen

2026-01-29T09:59:16.633619 - **Marvin Hammerschmidt:**
> Ne da ist doch eine slide doppelt oder nicht? 

2026-01-29T09:59:20.619859 - **Julia:**
> Du kannst auch gerne einfach Kommentare hinzufügen und ich packe die restlichen Sachen noch rein

2026-01-29T09:59:54.905529 - **Julia:**
> Ne, habs nur noch nicht visuell angepasst

  📎 Bildschirmfoto 2026-01-29 um 09.59.22.png

2026-01-29T10:00:13.022939 - **Julia:**
> mir auch noch nicht. aber setze ich mich jetzt dran :smile:

2026-01-29T10:00:20.863119 - **Marvin Hammerschmidt:**
> Genau. Bei dem oberen steht ja der Text von dem Persönlichkeiten Video 

2026-01-29T10:00:41.349539 - **Julia:**
> ahhhh

2026-01-29T10:00:50.363989 - **Julia:**
> ist mir durchgerutscht

2026-01-29T10:00:52.003269 - **Julia:**
> danke!

2026-01-29T10:01:00.057069 - **Marvin Hammerschmidt:**
> Gibt von meiner Seite aus sonst ehrlicherweise nichts zu kommentieren 

Denke das ist fine so:) 

2026-01-29T10:02:04.341889 - **Marvin Hammerschmidt:**
> Muss leider noch einiges fürs Fat ice Race machen.  
Dann hat Romina gestern gesagt sie hat das Gefühl Katharina ist mit dem content generell unzufrieden. Da hab ich heute auch emergency Meetings und muss mal wieder alles umstoßen :sob:

2026-01-29T10:02:17.609009 - **Julia:**
> alright

2026-01-29T10:02:20.878639 - **Julia:**
> Oh nein, Mist!

2026-01-29T10:02:36.158049 - **Julia:**
> Ja klar, mach. Ich kümmere mich um die Slides

2026-01-29T10:02:41.641699 - **Marvin Hammerschmidt:**
> UND ich brauche noch schnell was für search ads da wir ja nächste Woche kaum Zeit haben :sob:

2026-01-29T10:03:01.711299 - **Marvin Hammerschmidt:**
> Wenn du partiell was brauchst Tell me ! 


2026-01-29T10:03:10.850439 - **Marvin Hammerschmidt:**
> Hab eig tu allem was geschrieben außer ai prank 

2026-01-29T10:04:31.259509 - **Julia:**
> obs stressig ist :smile:

2026-01-29T10:04:38.844139 - **Julia:**
> alles gut, ich schau mal und schicks dir dann wieder

2026-01-29T10:04:40.454049 - **Julia:**
> danke!

2026-01-29T10:04:43.934379 - **Marvin Hammerschmidt:**
> Quaaaatsch :sweat_smile:

2026-01-29T10:42:22.312749 - **Julia:**
> Fällt dir eine Persönlichkeit ein, die krass wäre für den Carpool Roast mit Zach?

2026-01-29T10:43:17.153979 - **Marvin Hammerschmidt:**
> Hm
Am besten eine polarisierende Person aus den USA
let me think

2026-01-29T10:44:43.580449 - **Julia:**
> für den normalen Carpool Talk hätte ich Bill Kaulitz gewählt. Ist ja auch in USA bekannt.
Aber für den Roast wollte ich gerne noch jemand krasseren, genau

  📎 hf_20260129_092743_98028674-210e-4a35-8ce0-96c8f046f450.png

2026-01-29T10:45:02.640469 - **Marvin Hammerschmidt:**
> Ach der geht auch dafür tbh
Der polarisiert und ist lustig

2026-01-29T10:45:05.438939 - **Marvin Hammerschmidt:**
> Ich schaue

2026-01-29T10:45:26.775369 - **Julia:**
> okay

2026-01-29T10:45:33.484719 - **Marvin Hammerschmidt:**
> Eigentlich unsinnig die ganze idee
Das ist viel zu teuer für so ein normales Format:D

2026-01-29T10:45:48.400949 - **Marvin Hammerschmidt:**
> Also für highlights ja aber niemals würden wir so viel Geld für sowas ausgeben

2026-01-29T10:46:04.074889 - **Julia:**
> Marvin!

2026-01-29T10:46:07.248129 - **Julia:**
> Sell the dream!!

2026-01-29T10:46:10.207169 - **Julia:**
> :smile:

2026-01-29T10:46:19.914069 - **Marvin Hammerschmidt:**
> Alles klar Flo :smile:

2026-01-29T10:46:29.840589 - **Julia:**
> Ja, hab's als Monthly rein

2026-01-29T10:50:15.046709 - **Marvin Hammerschmidt:**
> Vielleicht einen altern kinderstar? Könnte generell spannend sein
z.B. Josh Peck von Drake and Josh
Der macht jetzt auch noch recht viel Social media, ist ganz lustig aber bietet auch angriffsfläche

2026-01-29T10:51:03.874079 - **Julia:**
> Jaa nehm ich mit auf

2026-01-29T10:51:09.180469 - **Julia:**
> danke!

2026-01-29T11:07:02.250379 - **Julia:**
> (Flo kennt das Video von LIB schon)

2026-01-29T11:07:22.989469 - **Julia:**
> und ist ja leider auch nur paar Sekunden, dann wird es verhauen

2026-01-29T12:44:28.836209 - **Julia:**
> hatte für Pranked jetzt noch eine andere Idee

  📎 Bildschirmfoto 2026-01-29 um 12.43.42.png

2026-01-29T12:45:19.568789 - **Marvin Hammerschmidt:**
> Das mit dem passiv aggressiv stell ich mir lustig vor :smile:

2026-01-29T12:45:35.210159 - **Julia:**
> Ja ich auch :smile:

2026-01-29T13:27:47.154199 - **Marvin Hammerschmidt:**
> :face_palm:

2026-01-29T13:28:34.378829 - **Julia:**
> puh

2026-01-29T13:39:11.505959 - **Julia:**
> 

  📎 audio_message.m4a

2026-01-29T14:24:53.453149 - **Marvin Hammerschmidt:**
> Ohje ich hoffe es geht ihm gut

Ja all fine!

2026-01-29T15:51:10.801619 - **Marvin Hammerschmidt:**
> Flo will das jeder seinen Teil vorstellt

Wie teilen wirs auf?

2026-01-29T15:51:57.860739 - **Marvin Hammerschmidt:**
> Wusste nicht das er direkt in die Vortragssituation will....

2026-01-29T15:52:03.272569 - **Julia:**
> das wusste ich auch nicht

2026-01-29T15:52:12.222899 - **Julia:**
> denke das geht auch nicht, weil Jana sicher die Präsi noch nicht fertig hat

2026-01-29T15:52:25.603209 - **Marvin Hammerschmidt:**
> Na das wird spannend

2026-01-29T15:53:26.663689 - **Julia:**
> Entweder abwechselnd oder ich stell alles vor oder du stellst "deine" ideen vor:
• beat the rsa
• AI tipps
• ride n roast
• Kesslers Knigge

2026-01-29T15:53:28.461879 - **Julia:**
> you decide

2026-01-29T15:54:43.295519 - **Marvin Hammerschmidt:**
> Mir ist auch völlig egal
Ist ja eh mainly deins und so wirds ja auch vor ort sein  dann passt die Aufteilung so

2026-01-29T15:54:57.385339 - **Julia:**
> okay. dann du deine?

2026-01-29T15:55:02.917349 - **Marvin Hammerschmidt:**
> • beat the rsa
• AI tipps
• ride n roast
• Kesslers Knigge


2026-01-29T15:55:07.638419 - **Julia:**
> passt!

2026-01-29T15:55:23.278299 - **Marvin Hammerschmidt:**
> Halt natürlich hart ohne die Präsi zu kennen :smile:

2026-01-29T15:55:24.382629 - **Julia:**
> liebs ja, dass man keine Sekunde Zeit hat irgendwas zu üben :smile:

2026-01-29T15:55:28.800079 - **Marvin Hammerschmidt:**
> Ja ist top

2026-01-29T15:55:47.867089 - **Marvin Hammerschmidt:**
> Es ist halt auch leider einfach nicht das einzige Thema was es aktuell gibt:D

2026-01-29T15:56:01.465549 - **Marvin Hammerschmidt:**
> Hoffen wir mal es passt ihm so

2026-01-29T15:58:12.913119 - **Julia:**
> ne

2026-01-29T15:58:39.545979 - **Julia:**
> er wollte eigentlich auch, dass ich morgen Decathlon vor ihm nochmal präsentiere mit meiner Verbesserung – i doubt it :smile:

2026-01-29T15:59:04.104399 - **Marvin Hammerschmidt:**
> Ach krass
Hat er dir das so nochmal gesagt?
Hab seine Memos nicht ganz gehört
Nicht das ich das auch machen sollte :smile:

2026-01-29T15:59:12.922539 - **Marvin Hammerschmidt:**
> Ja eng auf jeden Fall:D

2026-01-29T15:59:35.797339 - **Julia:**
> ja, weil er meinte, ob ich ins Büro kommen kann

2026-01-29T15:59:37.265579 - **Julia:**
> ich auch nicht

2026-01-29T16:13:26.738169 - **Julia:**
> aber wie unnötig ist es auch eine Präsentation zu präsentieren, die wir uns noch nicht zusammen angeschaut haben

2026-01-29T16:14:21.669789 - **Marvin Hammerschmidt:**
> ja 10/10

2026-01-29T16:40:00.793149 - **Julia:**
> haben wir eine strategie, wenn sie alle Formate scheiße finden? :smile:

2026-01-29T16:40:15.932129 - **Marvin Hammerschmidt:**
> Nö:D

2026-01-29T17:16:59.844779 - **Julia:**
> Willst du jetzt nochmal sprechen oder lieber morgen früh direkt?

2026-01-29T17:17:25.873859 - **USLACKBOT:**
> 

2026-01-29T17:24:22.240909 - **Marvin Hammerschmidt:**
> <https://www.youtube.com/watch?v=JLllxhfhBXg>

2026-01-30T10:32:17.846549 - **Marvin Hammerschmidt:**
> uf

2026-01-30T10:32:35.011869 - **Julia:**
> er versteht es einfach niiiicht :smile:

2026-01-30T10:32:47.509759 - **Marvin Hammerschmidt:**
> es ist so crazy

2026-01-30T10:33:20.732419 - **Marvin Hammerschmidt:**
> Es geht mir so auf den sack

2026-01-30T10:33:25.027279 - **Marvin Hammerschmidt:**
> wie man uns so vollladen kann

2026-01-30T10:41:04.011359 - **Julia:**
> ja und das geht einfach nicht

2026-01-30T10:41:14.135369 - **Julia:**
> auch die visuals in 5 minuten erstellen – nein das geht nicht

2026-01-30T10:41:37.430399 - **Marvin Hammerschmidt:**
> bringt nix zu diskutieren sag ich dir...

2026-01-30T10:41:42.180709 - **Julia:**
> ja ich weiß

2026-01-30T10:46:51.258609 - **Marvin Hammerschmidt:**
> Depriorisieren 

2026-01-30T10:47:14.582809 - **Marvin Hammerschmidt:**
> Also 
Workshop ist top prio
Decathlon ist top prio
Anything or nothing ist top prio 


2026-01-30T10:47:16.557739 - **Julia:**
> den IG Workshop vllt?

2026-01-30T10:47:20.351939 - **Julia:**
> :smile:

2026-01-30T10:47:47.847249 - **Marvin Hammerschmidt:**
> Er wird nächste Woche sagen „ wo stehen wir bei anything or nothing“. Dann wird ihm das nicht passen.  Dann wird er sagen „das war top prio“ 

2026-01-30T10:48:12.982519 - **Marvin Hammerschmidt:**
> Ja gut. Also ich les gleich einfach ab mit besseren Betonungen. That's orb

2026-01-30T10:48:15.273589 - **Marvin Hammerschmidt:**
> *it 

2026-01-30T10:48:29.738399 - **Julia:**
> ja whatever

2026-01-30T10:48:42.746149 - **Julia:**
> "euer erster Pitch" Ja ich hab nie gesagt, dass ich das machen will? :smile:

2026-01-30T10:48:54.778059 - **Julia:**
> Und ist auch nicht mein erster Pitch. Aber so wie er ihn gerne hätte

2026-01-30T10:49:18.097619 - **Marvin Hammerschmidt:**
> Same :sweat_smile:

2026-01-30T10:49:50.821409 - **Marvin Hammerschmidt:**
> Also ich würd liebend gern nicht. Ich lass meine Frau 2 Wochen vor Entbindung 2 Tage allein. Finde das generell absolut Ungeil :sweat_smile:

2026-01-30T11:01:32.025619 - **Julia:**
> Ja versteh ich zu 10000%

2026-01-30T11:01:33.795329 - **Julia:**
> Das ist so krank

2026-01-30T11:01:43.192069 - **Julia:**
> Marvin kurze andere Frage:

2026-01-30T11:02:01.409899 - **Julia:**
> sieht man hier schon, dass es kein BMW ist? ich kenne mich nicht aus :smile:

  📎 Bildschirmfoto 2026-01-30 um 11.01.28.png

2026-01-30T11:04:12.794679 - **Marvin Hammerschmidt:**
> Ja also man kann es schon erkennen aber ich sagmal das wäre keine katastrophe :smile:

2026-01-30T11:05:03.028039 - **Julia:**
> okay, ja wenn ich es anpasse dann richtig :smile:

2026-01-30T11:09:21.050429 - **Marvin Hammerschmidt:**
> Dann musst du leider nochmal ran:D

2026-01-30T12:07:21.316639 - **Julia:**
> Muss jetzt leider nochmal zum Tierarzt, meinem Hund gehts richtig schlecht. Also mache kurz "Lunch Break" Bis gleich!

2026-01-30T12:12:42.670699 - **Marvin Hammerschmidt:**
> Scheiße :open_mouth:
Gute Besserung an den guten :disappointed:

2026-01-30T13:19:11.590719 - **Julia:**
> Danke :heart_hands:

2026-01-30T13:19:27.123979 - **Julia:**
> also Jana ist nicht ganz auf der Höhe oder? 

2026-01-30T13:24:09.887159 - **Marvin Hammerschmidt:**
> sie macht unseren kram recht halbherzig würde ich sagen

2026-01-30T13:29:36.255499 - **Marvin Hammerschmidt:**
> Gehts deinem Doggo besser?

2026-01-30T13:34:24.927229 - **Julia:**
> würd ich auch sagen :smile:

2026-01-30T13:34:53.181529 - **Julia:**
> bisher nicht, aber hat jetzt alles mögliche gespritzt bekommen, sollte also bald besser werden. War aber auch einfach eine krasse OP, also verständlich

2026-01-30T13:34:56.773259 - **Julia:**
> danke der Nachfrage!

2026-01-30T14:00:31.763629 - **Marvin Hammerschmidt:**
> Ich drück die Daumen!

2026-01-30T14:41:22.985939 - **Julia:**
> hab mir Decathlon noch nicht durchgelesen :smile: du?

2026-01-30T14:41:31.144909 - **Julia:**
> SIXT AoN – kann ich dir da schon was bauen?

2026-01-30T14:42:29.954099 - **Marvin Hammerschmidt:**
> Nö. Mach ich gleich   Werde das auch krass runterkürzen :sweat_smile:

Kann dir bisher nur den one pager zeigen der das Konzept erklärt 

2026-01-30T14:46:04.447019 - **Marvin Hammerschmidt:**
> Opening Scene
We see a participant sitting in their own car on a quiet street.
A lively, cheeky moderator (think Jimmy Fallon meets car chaos) steps in, full of energy and sarcasm.
*Host*: “Are you really happy with your car? Or do you want something bigger?”
(He points at the shiny G-Class with a massive orange bow next to him.)
“All you have to do is let us do whatever we want with your car — and in return, you’ll get the G-Wagon for half a year. Deal?”
*Participant*: “If it gets me that G-Wagon, do whatever you want!”
*Host* (smirking): “Alright then… let’s go."

The Twist – Engraving the Car
Suddenly the *host* yells: “Jay, we’ve got permission!”
A second person appears, holding a power grinder with a mischievous grin.
Without hesitation, he starts engraving a huge “I :heart: SIXT” across the side of the participant’s car.
The participant’s jaw drops in disbelief, while the host bursts into laughter.

The Reward
When the engraving is done, the *host* claps his hands dramatically: “Congratulations! That’s your new car… but not for the next six months.”
He proudly hands over the keys to the Mercedes G-Class, gleaming under the sun.
*Host*: “Your ride for the next six months!”
The participant, now half-shocked and half-thrilled, jumps into the G-Class and drives off — leaving their newly ‘decorated’ car behind.


Opening und Reward bleiben eigentlich immer gleich
Was sich ändert ist der Twist

2 weitere Möglichkeiten:
1.
A famous golfer is invited to “aim for the deal.”
He has one chance to hit a golf ball through the car’s open window — if he succeeds, the participant gets the G-Class.
The risk: even a perfect shot might leave serious dents in the car.

2.
The participant’s car becomes a fashion icon.
Fake eyelashes on the headlights, bright red lips on the grill, and full-on “bitchy” glam styling.
A beauty makeover that screams SIXT with attitude — and leaves the owner blushing when they see it on the street.

2026-01-30T15:00:56.549109 - **Marvin Hammerschmidt:**
> Die trash tv bilder find ich mega cool :joy:

2026-01-30T15:04:20.891599 - **Marvin Hammerschmidt:**
> Ideen was mit den Autos sonst noch so passiert mach ich mir am we oder montag

2026-01-30T15:04:29.086359 - **Marvin Hammerschmidt:**
> Hab Julia aber schonmal ein paar fragen beantwortet

2026-01-30T15:11:41.469089 - **Julia:**
> Sorry bin grad kurz bei MINI

2026-01-30T15:12:03.005159 - **Marvin Hammerschmidt:**
> Alles gut
AoN muss halt warten

2026-01-30T15:12:04.950019 - **Julia:**
> alles klar. Dann übernimmst du die Folie oder ich? Ich kann ja LIB erzählen und dann übernimmst du mit der Übersicht?

2026-01-30T15:12:17.873479 - **Marvin Hammerschmidt:**
> Ja Trash mach ich

2026-01-30T15:12:23.867639 - **Julia:**
> ja..

2026-01-30T15:12:25.370309 - **Marvin Hammerschmidt:**
> LIB nimmst du

2026-01-30T15:12:28.865539 - **Julia:**
> okay

2026-01-30T16:17:01.472029 - **Marvin Hammerschmidt:**
> von wegen Inhalt passt

2026-01-30T16:30:41.729909 - **Julia:**
> ja hab ich mir auch gedacht

2026-01-30T19:02:02.214719 - **Julia:**
> happy weekend trotz allem und hoffentlich ein bisschen Ruhe!

2026-01-30T19:09:40.912629 - **Marvin Hammerschmidt:**
> Das wünsche ich dir auch!!!! 

2026-02-02T09:18:30.980839 - **Julia:**
> Guten Morgen :slightly_smiling_face:

2026-02-02T09:20:47.348999 - **Marvin Hammerschmidt:**
> Good morning:)

2026-02-02T09:28:04.387269 - **Julia:**
> Hattest du ein schönes Wochenende?

2026-02-02T09:28:38.303979 - **Marvin Hammerschmidt:**
> Leider weniger erholsam als gehofft aber da muss man durch^^
Und du? Wie gehts deinem Hund?

2026-02-02T09:30:20.127479 - **Julia:**
> Ja same. Gefühlt war gestern erst Freitag :smile:

2026-02-02T09:30:43.321579 - **Julia:**
> Wird langsam, waren jeden Tag beim Tierarzt/ Klinik aber heute sieht es ganz gut aus :slightly_smiling_face:

2026-02-02T09:31:01.013729 - **Marvin Hammerschmidt:**
> was ein scheiß
Der Arme
Weiterhin gute Besserung!

2026-02-02T09:46:33.248759 - **Julia:**
> Dankeee

2026-02-02T10:09:00.802979 - **Julia:**
> also ich weiß ja nicht, ob die Präsi heute was wird :smile:

2026-02-02T10:14:59.106429 - **Marvin Hammerschmidt:**
> Die für SIXT?
Ach ja warum nicht:D

2026-02-02T10:15:01.422369 - **Marvin Hammerschmidt:**
> das wird schon

2026-02-02T10:15:13.925679 - **Marvin Hammerschmidt:**
> Ist halt kacke das wir die noch nicht vorliegen haben

2026-02-02T11:29:51.194199 - **Julia:**
> ja genau

2026-02-02T11:48:57.247789 - **Julia:**
> boah

2026-02-02T11:49:05.359899 - **Julia:**
> sie hat ja quasi garnichts gemacht

2026-02-02T11:49:14.898899 - **Marvin Hammerschmidt:**
> Klasse

2026-02-02T11:49:25.626689 - **Julia:**
> slides alle noch alt vom look her

2026-02-02T11:49:30.222689 - **Julia:**
> Texte einfach reinkopiert

2026-02-02T11:50:19.323829 - **Marvin Hammerschmidt:**
> das ist schon crazy...

2026-02-02T12:01:26.203709 - **Marvin Hammerschmidt:**
> Sie haben mich auch um eine Agenda gebeten
Habe das um 10 an sie kommuniziert. Sie meinte 30 min

2026-02-02T12:01:29.436039 - **Marvin Hammerschmidt:**
> immer noch nicht

2026-02-02T12:01:32.680319 - **Marvin Hammerschmidt:**
> 0 Verlass

2026-02-02T12:49:08.634519 - **Julia:**
> wahnsinn

2026-02-02T12:49:21.470259 - **Julia:**
> Marvin welches Auto hab ich bei Opa Werner nochmal? :smile: Bzw. was könnte das sein?

2026-02-02T12:51:15.998599 - **Marvin Hammerschmidt:**
> Let me check:D

2026-02-02T12:51:41.333599 - **Marvin Hammerschmidt:**
> Kannst du mir das video schicken?
von dem Frame würd ich sagen das ist ein vw

2026-02-02T12:51:49.027549 - **Julia:**
> yes moment

2026-02-02T12:51:50.030069 - **Marvin Hammerschmidt:**
> kanns in der pdf aber nicht abspielen^^

2026-02-02T12:52:12.887499 - **Julia:**
> <https://drive.google.com/drive/folders/1aLCz7CZkdJOu_PQiBQh9GxUdMamSHJdt>

2026-02-02T12:52:34.742969 - **Julia:**
> also ich muss nur wissen, wenn ich jetzt sag: er wird dann im Benz zum oberrapper – nicht, dass es klar erkennbar der bwm x irgendwas ist

2026-02-02T12:52:52.261209 - **Marvin Hammerschmidt:**
> Welches davon ist das?

2026-02-02T12:53:01.455999 - **Marvin Hammerschmidt:**
> ah

2026-02-02T12:53:01.708939 - **Julia:**
> ach scheiße

2026-02-02T12:53:02.335299 - **Marvin Hammerschmidt:**
> sekunde

2026-02-02T12:53:03.417819 - **Marvin Hammerschmidt:**
> habs

2026-02-02T12:53:04.458479 - **Marvin Hammerschmidt:**
> all good

2026-02-02T12:53:07.454479 - **Julia:**
> sorry dachte da kommt direkt der link

2026-02-02T12:53:10.851469 - **Julia:**
> okay

2026-02-02T12:53:39.074389 - **Marvin Hammerschmidt:**
> Also als er einsteigt ist es ein verkappter VW
Wenn er drin sitzt ist das eine alte S-Klasse

2026-02-02T12:54:04.445909 - **Julia:**
> wunderbar

2026-02-02T12:54:45.464979 - **Marvin Hammerschmidt:**
> Ist fine Benz zu sagen
Das wird ihnen nicht auffallen im ersten part

2026-02-02T12:54:55.319289 - **Julia:**
> OKAY

2026-02-02T12:54:58.236619 - **Julia:**
> sorry :smile:

2026-02-02T12:54:58.642279 - **Marvin Hammerschmidt:**
> Gleich nochmal kurzen call zum abstimmen?

2026-02-02T12:55:02.785039 - **Julia:**
> okay, ja gerne

2026-02-02T12:55:08.895389 - **Marvin Hammerschmidt:**
> Wann passt sdir?

2026-02-02T12:55:23.656009 - **Julia:**
> in 5min?

2026-02-02T12:55:27.820579 - **Marvin Hammerschmidt:**
> aight

2026-02-02T13:02:16.176839 - **USLACKBOT:**
> 

2026-02-02T16:27:01.435329 - **Julia:**
> wie ist dein Gefühl?

2026-02-02T16:27:41.681139 - **Marvin Hammerschmidt:**
> Okay würd ich sagen
Am besten ruft ihr mich zusammen an wenn ihr raus seid:)

2026-02-02T16:35:18.912669 - **Marvin Hammerschmidt:**
> Dafür das es gut wird geben wir wieder zu viel ab 
Ich hab Sorge dass es zu cringe wird oder sie zu viel da rein geben um zu viel Werbung zu  machen 

2026-02-02T16:35:45.007319 - **Julia:**
> yes machen wir

2026-02-02T17:36:38.593659 - **Marvin Hammerschmidt:**
> Der Look &amp; Feel (Das Fundament)
• *Opening Shot:* Immer ein 1.5-Sekunden-Zoom auf das Gesicht des Protagonisten mit einem spezifischen "Hook-Satz".
• *Sound &amp; Jingle:* Ein kurzes, prägnantes Audio-Logo (z.B. ein "Pop"-Sound oder ein spezieller Bass-Riff), das bei jedem Video-Start unterlegt ist.
• *Schnitt-Stil:* Schnelle, rhythmische Schnitte (Jump-Cuts), die den "Fun &amp; Bold"-Vibe unterstreichen.
• *AI-Anteil (30-40%):* Wir filmen reale Menschen in echten Umgebungen (Brooklyn Coffee Shop Vibe) und nutzen KI nur für *Hintergrund-Enhancements, Voice-Over-Clarity oder surreale Effekte* in den "Prank"-Szenen.


2026-02-02T17:39:51.050369 - **Marvin Hammerschmidt:**
> • Wiedererkennbarkeit durch Cuts, Personen, Sounds

2026-02-02T17:39:59.477429 - **Julia:**
> Danke dir 

2026-02-02T17:40:14.231939 - **Julia:**
> Bin leider noch immer unterwegs 

2026-02-02T17:41:02.249599 - **Marvin Hammerschmidt:**
> To dos:
Love is blind weiter ausarbeiten
Erste Carousel Posts erstellen von "Not to say"
Ideen für den Text oben auf dem Insta Kanal
Wer sind die Charaktere wie sind die verfügbar, wo finden die Sachen statt, Sound &amp; Jingle, Look anf Feel
Grundaufbau soll immer gleich sein und das sollen wir detailiert in unseren Konzepten zeigen
An produktionsworkaround denken

2026-02-11T14:17:41.354639 - **Marvin Hammerschmidt:**
> Also 1-2 Videos pro woche ist tatsächlich bei entsprechendem Aufwand gar nicht wenig

2026-02-12T10:53:50.652849 - **Julia:**
> Hello! :slightly_smiling_face: Also ich richte mich nach dir wegen der Übergabe. Morgen nachmittag passt für mich auch? Also sag du gerne wann es dir passt!

2026-02-12T11:52:26.267249 - **Marvin Hammerschmidt:**
> Morgen ab 3 würde evtl gehen
Jenachdem was da noch an to dos reinkommt:)

2026-02-13T09:06:04.402929 - **Julia:**
> Guten morgen, magst du mir einfach in WhatsApp schreiben, sobald du was weißt? :slightly_smiling_face: Dann übersehe ich es nicht. Bin ja nicht dauernd am Laptop

2026-02-13T09:09:46.249739 - **Marvin Hammerschmidt:**
> Guten Morgen

Yes mach ich

Sind gerad zum
Vorgespräch im Krankenhaus dann hab ich bis 3 Meetings. Ich hoffe es geht direkt danach aber ich meld mich noch :) 

2026-02-13T09:10:15.981689 - **Julia:**
> Uhh hoffe es ist alles gut! :crossed_fingers:

2026-02-13T09:10:46.023159 - **Julia:**
> Ja sag einfach bescheid, wenns heute zu stressig ist, können wir das natürlich auch am Sonntag oder so machen. Morgen bin ich nur (endlich wieder) nicht daheim und unterwegs :slightly_smiling_face:

2026-02-13T09:11:48.165529 - **Marvin Hammerschmidt:**
> Ansonsten halt Dienstag
Ist halt wie es ist :sweat_smile:

2026-02-13T09:12:12.398869 - **Julia:**
> Nenene ab nächster Woche bist du im Baby Fokus

2026-02-13T09:12:43.000099 - **Marvin Hammerschmidt:**
> Bin die ganze Woche noch da außer Montag
Wir werden das heute nicht ansatzweise schaffen


2026-02-13T09:12:55.500459 - **Marvin Hammerschmidt:**
> Einmal reicht auch nicht um das alles allein zu machen 

2026-02-13T09:43:48.218889 - **Julia:**
> okay

2026-02-13T14:35:21.211509 - **Julia:**
> wie siehts bei dir aus? :slightly_smiling_face:

2026-02-13T14:41:19.135719 - **Marvin Hammerschmidt:**
> bin noch in meetings
Werde auf jeden Fall länger brauchen

2026-02-13T14:42:25.158709 - **Julia:**
> okay. was ist dir denn am liebsten? Sollen wir DI/ MI morgens gleich direkt halbe Tage dafür blocken?

2026-02-13T14:43:05.324199 - **Marvin Hammerschmidt:**
> Ich muss gleich eh einmal das reporting machen
Das können wir einmal kurz zusamen machen und dann machen wir am DI und MI Deep dive :slightly_smiling_face:

2026-02-13T14:51:10.298239 - **Julia:**
> okay

2026-02-13T15:26:00.177079 - **USLACKBOT:**
> 

2026-02-13T15:26:40.685679 - **Julia:**
> hat irgendwie nicht geklappt

2026-02-13T15:26:41.313379 - **Julia:**
> moment

2026-02-13T15:26:44.754899 - **USLACKBOT:**
> 

2026-02-13T15:34:39.229379 - **Marvin Hammerschmidt:**
> Mit einem einmaligen Link erhalten Sie sicheren Zugriff auf einen Keeper-Datensatz. Der Zugriff auf Datensätze funktioniert nur auf einem Gerät und läuft in 1 Woche ab. <https://keepersecurity.eu/vault/share/#F4b8oaZqzqQL4knOqJgzNdomVsteEOSRFQz2X6SLno4>


---

### Unknown (218 messages: 106 from Julia, 112 from Unknown)

**Folder:** `D0A05HAPK1R`

2025-11-28T09:28:22.779999 - **Anna Arndt:**
> Hi hi! Flo meint, du hast eine Aufgabe, bei der ich dir helfen könnte? Irgendwas zu Lidl und Photoshop-Mockups? Schreib mir gerne oder ruf mich kurz an:)

2025-11-28T09:28:32.281539 - **Julia:**
> Hi Anna! wollte mich gerade melden

2025-11-28T09:29:07.399679 - **Anna Arndt:**
> Kein Stress:grin:

2025-11-28T09:30:10.157369 - **Julia:**
> Tatsächlich nein, ich weiß nicht genau was er damit meint, da kannst du mich leider nicht unterstützen. Allerdings benötigen meine Kolleginnen Julia Hallhuber und Mert Unterstützung beim Kunden Hisense/Gorenje, da ich hier heute nicht aushelfen kann

2025-11-28T09:30:56.967769 - **Anna Arndt:**
> Hmm okay, dann frag ich da mal nach:)

2025-11-28T09:31:19.374459 - **Julia:**
> Ich connecte euch

2025-11-28T09:33:21.301329 - **Anna Arndt:**
> Flo sagt Lidl first, ich brauche die Kampagne und irgendwelche Bilder von dir:joy:

2025-11-28T09:33:38.567249 - **Anna Arndt:**
> Ich soll irgendwie Artikel Snippets schreiben

2025-11-28T09:35:14.461379 - **Julia:**
> ich ruf ihn an

2025-11-28T09:37:09.091119 - **USLACKBOT:**
> 

2025-11-28T09:48:08.949389 - **USLACKBOT:**
> 

2025-11-28T09:50:07.271629 - **Julia:**
> 

  📎 251127_Lidl_OMR_Wohnmobile_Video_komplett_neuer-Text.mp4

2025-11-28T09:56:42.565519 - **Julia:**
> Bevorzug gerne die Bilder bei denen man das OMR Logo auch sieht oder wir photoshoppen es dann nochmal rein

  📎 00ce9a6f-a9b7-497e-9206-50719338d8d1.png
  📎 83f59e0f-46e7-431a-8498-933d5b3fb35a.png
  📎 89f658af-2629-425d-8ae6-7adced7c2dd4 (2).png
  📎 54923c48-4a0a-4be4-ac08-8d82afba04fc.png
  📎 6471d297-b98f-485c-af7a-9b4845655325.png
  📎 578fba0c-4d16-4507-ab9f-3345e2431914.png

2025-11-28T09:57:43.211869 - **Anna Arndt:**
> Danke dir!

2025-11-28T10:05:12.069979 - **Anna Arndt:**
> Könnte ich dann win/zwei davon (mit OMR Logo) noch 16:9 haben bitte? :slightly_smiling_face:

2025-11-28T10:19:45.022299 - **Julia:**
> yes, erstelle ich dir gleich 

2025-11-28T11:01:07.915669 - **Anna Arndt:**
> danke:)

2025-11-28T11:11:01.768209 - **Julia:**
> links müsste man wahrscheinlich etwas zuschneiden wegen den blau/gelben wohnmobilen

  📎 a65265ec-2cbe-4f7c-87c6-3587dad38e37.png

2025-11-28T11:12:44.398349 - **Julia:**
> 

  📎 efee0908-7762-422d-9047-b97340216340.png

2025-11-28T11:13:12.165969 - **Anna Arndt:**
> Vielen Dank dir Juli!

2025-11-28T11:14:04.951349 - **Julia:**
> sehr gerne! bin bis 12 Uhr in einem Meeting, melde ich danach wieder :slightly_smiling_face:

2025-11-28T11:14:08.427639 - **Julia:**
> danke dir!

2025-11-28T11:27:19.545209 - **Julia:**
> hiermit könnten wir noch social Posts faken beispielsweise

  📎 f04b33de-3fde-46cb-9a61-2b1d639791a5.png

2025-11-28T12:46:10.355409 - **Julia:**
> Kommst du voran? Alles gut?

2025-11-28T13:25:08.111789 - **Anna Arndt:**
> Yes! Ich zeig dir schonmal paar Sachen, Flo hat gerade auch grob drüber geschaut, sag mir gerne, wenn etwas anders sein soll:)

2025-11-28T13:25:40.218799 - **Anna Arndt:**
> Die Zeitschriften hat übrigens auch Flo vorgegeben und um das Konzept mit dem Interview hat er auch gebeten

2025-11-28T13:26:47.348049 - **Anna Arndt:**
> 

  📎 LIDL BILD.png
  📎 file
  📎 LIDL Campaign.png
  📎 LIDL Horizont.png
  📎 file
  📎 LIDL W&V.png
  📎 LIDL W&V Artikel.png

2025-11-28T13:28:47.394019 - **Anna Arndt:**
> 

  📎 LIDL BILD.png

2025-11-28T13:41:22.992499 - **Julia:**
> sehr cool! Eine Kleinigkeit "Lidl" schreibt sich selbst nicht in Caps also nicht "LIDL". Würde deshalb eher bei der Schreibvariante Lidl bleiben. Bei dem Visual kann ich es leider nicht gut austauschen, aber sollten es bei den Headlines der Zeitschriften richtig haben

2025-11-28T13:41:30.557499 - **Anna Arndt:**
> 

  📎 LIDL Horizon Interview.png

2025-11-28T13:41:51.634529 - **Julia:**
> von Anna Arndt vllt? :slightly_smiling_face:

2025-11-28T13:41:58.620709 - **Julia:**
> 

  📎 Bildschirmfoto 2025-11-28 um 13.41.30.png

2025-11-28T13:42:05.671919 - **Anna Arndt:**
> Oh, good to know! Danke! mach ich

2025-11-28T13:42:15.070069 - **Anna Arndt:**
> achso hahah ja kann ich auch machen

2025-11-28T13:42:17.908979 - **Anna Arndt:**
> Anna Arndt

2025-11-28T13:42:24.025719 - **Anna Arndt:**
> dachte der Autor ist erstmal egal

2025-11-28T13:42:27.824449 - **Anna Arndt:**
> aber gerne

2025-11-28T13:43:03.858519 - **Julia:**
> als kleiner Schmunzler – solche Tricks kann man immer einbauen :slightly_smiling_face:

2025-11-28T13:54:01.987569 - **Anna Arndt:**
> Ein paar LinkedIn Posts mache ich auch gleich noch

2025-11-28T13:54:03.641619 - **Anna Arndt:**
> Hier nochmal korrigiert!

  📎 Lidl BILD Artikel.png
  📎 Lidl BILD.png
  📎 Lidl Horizont Interview.png
  📎 Lidl Campaign.png
  📎 Lidl W&V Artikel.png
  📎 Lidl W&V.png

2025-11-28T13:54:15.787169 - **Anna Arndt:**
> hast du denn zufällig schon was erstellen können zu den Innenräumen?

2025-11-28T13:57:50.495889 - **Julia:**
> super cool!

2025-11-28T13:58:11.295959 - **Julia:**
> leider noch nicht, aber ich schicke dir schon mal die anderen Bilder:

2025-11-28T14:00:05.942029 - **Julia:**
> 

  📎 2e80083f-d408-4078-ae94-0488ea711a9e.png
  📎 8c76ebb8-ed80-44ef-a339-e11d97b342fc.png
  📎 42a74603-49c2-4a2e-a922-5d4e0249f954.png
  📎 e6f503c8-81d7-48f6-ba56-7156e4f1c162.png

2025-11-28T14:00:36.719229 - **Julia:**
> 

  📎 c48cc524-c5a6-439e-905c-cc94e1c7bc5f.png

2025-11-28T14:02:53.334439 - **Julia:**
> 

  📎 018fc37f-f047-4cac-9324-d5ac12fc8ec0.png

2025-11-28T14:50:33.072989 - **Anna Arndt:**
> Wie cool, danke!

2025-11-28T15:42:12.593519 - **Anna Arndt:**
> Hier schonmal zwei Linkedin Mockups

  📎 Lidl Linkedin Johannes Klietsch.png
  📎 Lidl Linkedin Oliver Voss.png

2025-11-28T15:44:06.738939 - **Julia:**
> sehr cool! :slightly_smiling_face:

2025-11-28T15:47:56.867829 - **Julia:**
> du könntest noch das "Gefällt" mir als aktiviert anzeigen. Glaube das ist dann blau

2025-11-28T15:49:16.283209 - **Julia:**
> beim 2. würde ich schreiben "..Hamburg ist während der OMR komplett überlastet: nicht genügend Betten für den Ansturm

2025-11-28T16:02:58.077559 - **Anna Arndt:**
> Mach ich!

2025-11-28T16:08:59.052249 - **Julia:**
> 

  📎 Innenausstattung_Bett.png
  📎 Innenausstattung_vorne.png

2025-11-28T16:09:08.024869 - **Anna Arndt:**
> Nr 1

  📎 Lidl Linkedin Johannes Kliesch.png

2025-11-28T16:09:22.637519 - **Anna Arndt:**
> woow wie cool! mercii

2025-11-28T16:18:05.070949 - **Anna Arndt:**
> Nr 2

  📎 Lidl Linkedin Oliver Voss.png

2025-11-28T16:34:11.217189 - **Anna Arndt:**
> Hier noch einer:

  📎 Lidl Linkedin Andreas von der Heydt.png

2025-11-28T16:38:12.177609 - **Anna Arndt:**
> Flo möchte noch UGC-Mockups, unter anderem für diese drei Kandidaten &amp; Formate:
Opa Werner trinkt Matcha Latte im LIDL
Matthias Malmedie testet ob man mit LIDL Wohnwagen driften kann "Ich teste den LIDL OMR Wohnwagen - geht er quer?!"
 Ben Bernschneider macht "hotel vlog" aus LIDL Wohnwagen

Er meinte, ich soll dich fragen ob du dazu auch noch etwas generieren könntest bitte? Vielen Dank dir!

2025-11-28T16:48:22.482749 - **Julia:**
> Was genau sind UGC Mockups?

2025-11-28T16:48:33.402309 - **Julia:**
> Für IG, TikTok?

2025-11-28T16:48:41.180019 - **Julia:**
> Stills oder Video?

2025-11-28T17:01:12.749269 - **Anna Arndt:**
> User generated content, das heißt Mockups davon, was "normale" user und in dem Fall Influencer dazu generiert haben könnten. Für sowohl Instagram als auch Tiktok, aber eins pro Person. da kümmer ich mich drum. ich bräuchte nur bitte zu jeder Person 1 Still zum Thema:)

2025-11-28T17:02:32.183969 - **Julia:**
> Nene ich weiß was UGC ist aber ich meinte was UGC Mockups sein sollen :slightly_smiling_face: Instagram Handles also

2025-11-28T17:04:28.011629 - **Anna Arndt:**
> Naja, nicht deren handles sondern diese drei Influencer gibt es so, und einfach Bilder zu den Szenarios. Also Opa Werner, wie er Matcha trinkt in dem Wohnwagen, Matthias Malmedie am driften in einem und Ben Bernschneider, wie er einen Vlog macht. Macht das Sinn?

2025-11-28T17:04:40.389219 - **Julia:**
> wir können es probieren. Schwierigkeit liegt dabei, dass die Person von der 100% übernommen wird. Bei Matthias ist das das beste Ergebnis

  📎 MatthiasMalmedie.png

2025-11-28T17:05:37.283849 - **Julia:**
> das evtl noch, richtig zugeschnitten:

  📎 5c4868d9-ffd4-43e8-a5c0-c711391e8869.png

2025-11-28T17:25:28.247899 - **Julia:**
> Hier Ben und Opa Werner

  📎 Ben_1.png
  📎 Ben_3.png
  📎 Opa-Werner.png

2025-11-28T17:29:22.611149 - **Julia:**
> hier noch innen drin, das hatte erst nicht geklappt

  📎 Ben_Inside.png

2025-11-28T17:34:19.052289 - **Anna Arndt:**
> Danke dir!! Sieht super aus!

2025-11-28T17:36:10.299319 - **Julia:**
> danke dir! ein tolles wochenende :slightly_smiling_face:

2025-11-28T17:38:36.568289 - **Anna Arndt:**
> dir auch!

2025-12-04T08:43:03.210899 - **Julia:**
> Guten Morgen Anna! 
Hast du um 10 Uhr Zeit für ein kurzes Meeting? 

2025-12-04T09:19:14.114979 - **Anna Arndt:**
> Hallo Juli! Yes, sehr gerne!

2025-12-04T09:19:45.425279 - **Anna Arndt:**
> Flo meinte, du hast eine Aufgabe für mich - geht es darum oder kann ich vorher schon was für dich tun?

2025-12-04T09:59:31.694749 - **Julia:**
> Ruf dich gleich an :slightly_smiling_face: Ne geht darum

2025-12-04T10:03:37.861169 - **USLACKBOT:**
> 

2025-12-04T10:07:41.612019 - **Julia:**
> 

  📎 LIDL ROOMS BOLD CREATORS 20251202.pdf

2025-12-04T10:12:46.409369 - **Julia:**
> *WOHNWÄGEN:*
• 40 (50) Stück während der OMR 2026 in Hamburg
• Anbieter: einer oder über mehrere? --&gt; Machbar? Kosten?
• Wie sehen diese Wohnwägen im Roh Zustand aus?
• Design: Folierung (Außen) --&gt; Machbar? Kosten?
• Design: Interieur/ Umbau --&gt; Machbar? Kosten?
• Campingplatz: wo können die Wohnwägen am Ende stehen?
• Alle Infos die du findest helfen uns schon weiter :slightly_smiling_face: 
• Benötigt man eine Genehmigung für die Stadtfahrten? Wenn eine 300m lange Wohnwagen Karavane den Straßenverkehr blockiert
Danke dir!

2025-12-04T10:59:11.070909 - **Julia:**
> Könntest du bei Gelegenheit mal checken, ob ein Paket von Hisense angekommen ist? Gorenje müssten 3 Stück sein. Aber wir warten noch auf ein Produkt seitens Gorenje :slightly_smiling_face:

2025-12-04T11:56:53.329099 - **Anna Arndt:**
> Ich sehe drei Gorenje Pakete. Hisense noch keins.

2025-12-04T11:57:44.465679 - **Anna Arndt:**
> Viele der Wohnwagen-Anbieter haben Infos zu Stückzahl und Preis nur auf Anfrage (Email). Soll ich da schonmal nachfragen oder ist das zu konkret für jetzt?

2025-12-04T12:00:47.010839 - **Julia:**
> okay danke dir

2025-12-04T12:01:21.753649 - **Julia:**
> ja frag  gerne an. Hier bitte beachten: keine konkrete Nennung von LIDL, sondern eher von einem großen Kunden sprechen

2025-12-04T12:25:46.629029 - **Anna Arndt:**
> Ja klar:) Mach ich

2025-12-04T13:47:12.715719 - **Julia:**
> danke dir!

2025-12-04T14:03:48.962979 - **Anna Arndt:**
> Hier schonmal meine Übersicht: <https://docs.google.com/document/d/1f7r5ByOzHE94Fp-i_MxLFVouK_wdo4QEXB1FM4YRHig/edit?tab=t.0>
Ich mache Mittagspause und kann danach gerne nochmal anpassen, mir Sachen genauer anschauen, ergänzen etc:) Wenn du schon Anmerkungen hast lass es mich gern wissen

2025-12-04T14:05:29.914609 - **Anna Arndt:**
> Es ist teilweise etwas schwer schon genaue Angaben zu machen, ich schau mal was ich so als Antworten bekomme (und wan hahah) und kann das dann dementsprechend etwas fester machen. Bei den Stellplätzen kann ich auch mal konkreter Anfragen wenn du möchtest. Aber die genauen Summen wissen wir glaub ich echt erst wenn wir konkret was ausmachen und buchen.

2025-12-04T14:55:42.268289 - **Julia:**
> cool, danke dir!

2025-12-04T14:56:15.470249 - **Julia:**
> Die Kosten für die Außenfolierung hattest du jetzt nicht nochmal extra recherchiert, sondern über die Wohnmobil Vermietungen angefragt?

2025-12-04T14:56:31.903679 - **Julia:**
> klar verständlich

2025-12-04T15:21:11.601179 - **Anna Arndt:**
> Genau. Mach ich aber gern nochmal extra

2025-12-04T16:18:57.329839 - **Julia:**
> die erste Absage kam ja sogar schon rein

2025-12-04T16:19:33.193709 - **Julia:**
> falls du es eh noch nicht gemacht hast: markiere gerne in dem Dokument die Absagen und den Status der Anfragen

2025-12-04T16:22:02.906329 - **Julia:**
> Und könntest du nochmal zusammenrechnen (mit den Informationen die wir haben) wieviel grob ein Wohnmobil kostet mit allem (Folierung, Fahrer, Parkgebühren, generelle Gebühren...) danke! :slightly_smiling_face:

2025-12-04T16:51:02.288539 - **Anna Arndt:**
> Mach ich. Flo hatte mich eh gebeten, die alle anzurufen und da bin ich grad dabei uns sortiere dann nochmal aus.

2025-12-04T16:52:05.023709 - **Anna Arndt:**
> Meinst du bei deiner letzten Nachricht mit Wohnwagen Vermietung oder Kauf? Weil ein Gesamtpreis für das alles im Falle der Vermietung steht eigentlich schon mit drinnen...

2025-12-04T17:14:40.249959 - **Julia:**
> Ah magst du mir das einmal markieren/ mich kommentieren? Dann hab ich es übersehen. Danke dir!

2025-12-04T17:37:25.927019 - **Anna Arndt:**
> Mach ich!

2025-12-05T09:04:23.104949 - **Anna Arndt:**
> fyi- das Hisense Paket ist angekommen:)

2025-12-05T09:05:57.292319 - **Julia:**
> Guten Morgen! Danke dir :) bin auch gleich da 

2025-12-05T17:18:33.585059 - **Anna Arndt:**
> Hey, ich hab heute noch ganz viel rum telefoniert, alle Infos und Updates sind in dem Doc von gestern! Damit du Bescheid weißt und falls du auf ein neues wartest hahah:)

2025-12-05T17:19:21.517399 - **Anna Arndt:**
> Ich hab dich immer in CC gesetzt bei den Emails (auch gestern ja schon) - ich hoffe das ist okay aber so kriegst du hoffentlich die Antworten auch in der Zeit wo ich nicht da bin!

2025-12-05T18:23:48.167699 - **Anna Arndt:**
> Hier eine Zusammenfassung, die sich Flo noch gewünscht hatte, einmal auch an dich:

2025-12-05T18:23:50.360289 - **Anna Arndt:**
> *Executive Summary Anna - Wohnwagen Kampagne Lidl*

-&gt; Anrufe und Emails (da wo angefordert oder nicht erreicht)



1. *Wohnwagen*
• Wohnmobil-Vermieter in und um Hamburg
• Realistischste Option:
<https://www.schwarz-mobile-freizeit.de/vermietung/wohnmobile#/iframe/> / McRent
hätten die Anzahl da, verschiedene Fahrzeuge, Branding möglich
4 Nächte 540 Euro - 860 Euro , Sonderpreis möglich: -25%
-&gt; Broschüre an Juli und Marie geschickt



• Ansonsten:
    ◦ Vermieter mit weniger Kapazitäten:
<https://www.drm.de/de/stationen/hamburg-henstedt> höchstens ca. 6 auf einmal, Infos kommen noch
<https://naturecaravan.de/> auch weniger, melden sich zurück mit Anzahl und Preis
<https://caravanhamburg.de/de/wohnmobile-mieten> Infos kommen noch
<https://www.roehnelt-caravan.de/> 10 Stück, ca. 500 Euro für 4 Tage, Folierung möglich

• Eventfahrzeug-Anbieter <https://www.showtruck-marketing.com/>
	Kleinere Stückzahl, teurer, melden sich zurück mit Anzahl und Preis
-&gt; Machen aber auch Folierung und Interior

Next Steps:

• Warten auf weitere Antworten
• Liste mit denen, die ich nicht erreicht habe an Juli und Marie geschickt






*2. Parken*

• Realistischste Optionen:
<http://knauscamp.de|knauscamp.de> -&gt; Melden sich zurück
<https://www.elbepark-bunthaus.de/startseite-elbepark-bunthaus.html>
	-&gt; Könnte gehen, aber man muss alles manuell buchen
Online für den Zeitraum noch viel Verfügbarkeit, 26-30€ pro Fahrzeug und Nacht
<https://www.safe-depot.de/wohnmobil-stellplaetze/> evtl. möglich, ruft zurück

	Roadblocker
• Zusatzkosten für Strom, Sanitär und anwesende Personen
	Next Steps
• Auf Rückmeldungen warten
• Weitere anfragen,  Liste mit denen, die ich nicht erreicht habe an Juli und Marie geschickt




*3. Außenbranding/Folierung*

• Bei vielen Anbietern prinzipiell möglich
• Mockups per Email, melden sich mit Angeboten
	Zum Beispiel:
<https://b-branded.com/fahrzeugbeschriftung-und-flottenbeschriftung/>
<https://www.phoenixdesigns.de/fahrzeugbeschriftung-hamburg/>

Next Steps:
• Warten auf Angebote, Entscheiden für sinnvollste Option




*4. Inneneinrichtung*

• <https://hp-camper.de/> schonmal erreicht und wahrscheinlich möglich
• Liste an weiteren Optionen -&gt; Juli und Marie geschickt
Next Step:
• Weiter anfragen, Optionen vergleichen




*5. Genehmigung*

• Brauchen wir
• LBV, die klären mit Polizei etc.
• Trotzdem alle möglichen Adressen angefragt, noch keine klare Antwort
	Next Step:
• Anruf am Montag unter angeblich hilfreicher Nummer -&gt; Juli und Marie geschickt




*-&gt;* *Schätzung Gesamtprei*s (laut AI, also ungenau, aber vllt. zur groben Einschätzung): *60.000-300.000 €* (edited)

*<http://drm.de|drm.de>*
*<https://www.drm.de/de/stationen/hamburg-henstedt|Wohnmobil mieten ab Hamburg/Henstedt-Ulzburg>*
Wohnmobil &amp; Camper mieten ab Hamburg / Henstedt-Ulzburg ✓Kundenservice-Testsieger ✓Seit 1994 ✓2. Fahrer gratis ✓Inkl. KM &amp; Vollkasko Schutz ✓Hund kostenlos

*Nature Caravan | Patrick Heinze*
*<https://naturecaravan.de/|Wohnmobilvermietung Hamburg | Nature Caravan>*
Buchen Sie mit Nature Caravan Ihren Urlaub! Familiengeführtes Unternehmen seit 2021, spezialisiert auf die Vermietung von Wohnmobilen und Wohnwagen in Hamburg. Jetzt starten!

*Lisa Automobile GmbH*
*<https://caravanhamburg.de/de/wohnmobile-mieten|Caravan Hamburg – Camper mieten mit Rundum-Sorglos-Service>*
Starte deinen Roadtrip mit Caravan Hamburg – moderne Camper, individuelle Beratung &amp; flexible Mietoptionen in Börnsen &amp; Marschacht.

*<http://roehnelt-caravan.de|roehnelt-caravan.de>*
*<https://www.roehnelt-caravan.de/|Home Röhnelt Caravan GmbH in Hamburg>*
Bei uns finden Sie Beratung und Angebot zu Reisemobilen und Mobilheimen mit umfassenden Serviceleistungen, Ihr Freizeittraum individuell auf Sie abgestimmt.

2025-12-05T18:25:18.350309 - **Anna Arndt:**
> Hier noch ein PDF, was mir der eine, realistischste Anbieter geschickt hat. Von allen Fahrzeugen hat er in dem Zwitraum 2-4 Stück verfügbar, es warden also wahrscheinlich unterschiedliche, aber hier die Auswahl:

  📎 scan4799.pdf

2025-12-05T18:25:29.686719 - **Anna Arndt:**
> LG und bis nächste Woche!

2025-12-05T18:49:23.973059 - **Julia:**
> Hallo Anna, vielen Dank dir für die tolle Arbeit! Sehr sehr cool. Ich kann mir das alles nach unserem Shooting in Ruhe angucken

2025-12-05T18:49:32.154579 - **Julia:**
> Hab ein schönes Wochenende :slightly_smiling_face:

2025-12-10T15:34:12.411139 - **Anna Arndt:**
> Updates Summary Wohnwagen Lidl:

-Kontakt mit noch einem Außenfolierungs- und einem Inneneinrichtungs-Unternehmen
-Außenfolierung ca. 5.500 bis 8.000 € netto pro Fahrzeug
Aber: man müsste schon im Januar anfangen
-Inneneinrichtung <https://hp-camper.de/> -> brauchen genaue Angaben zu Fahrzeugen und Maßen, müssten auch schon im Januar beginnen
-Parken bei <http://knauscamp.de|knauscamp.de> -> Ist möglich!
ca. 42€
gültig für 1 Person, inkl. Stellplatz, Strom, Sanitäranlagen
-Genehmigung: Ansprechpartner gefunden: Andre Thamm <mailto:vd51@polizei.hamburg.de|vd51@polizei.hamburg.de>

-> Wenn wir bei manchen Anbietern schon im Januar mit der Gestaltung beginnen müssen, bräuchten wir die Wohnwägen da schon und müssten sie für 5 Monate mieten

2026-01-08T16:55:37.639359 - **Anna Arndt:**
> Hello Juli! Ersteinmal frohes neues Jahr! Flo hat mir gesagt, du bräuchtest vielleicht meine Hilfe? (bzgl. Lidl Video, Kontakt mit den Schauspiel Agenturen etc.?)

2026-01-08T17:08:47.027889 - **Julia:**
> Hi Anna! :slightly_smiling_face: Dankee, das wünsche ich dir auch

2026-01-08T17:09:23.977559 - **Julia:**
> ja genau, sehr gut! War eben noch im Meeting deshalb kam ich nicht dazu

2026-01-08T17:09:50.424409 - **Julia:**
> Sollen noch kurz sprechen oder lieber morgen?

2026-01-08T17:10:41.575359 - **Anna Arndt:**
> wir können gerne jetzt noch wenn du zeit hast:) sonst passt morgen auch

2026-01-08T17:12:25.117919 - **Julia:**
> dann gerne jetzt noch!
 <https://meet.google.com/rgm-vdeq-ord>

2026-01-08T17:12:54.767859 - **Anna Arndt:**
> Sekundeee

2026-01-08T17:12:59.377559 - **Julia:**
> klaro

2026-01-08T17:16:52.725469 - **Julia:**
> 

2026-01-08T17:19:44.593519 - **Anna Arndt:**
> dankeschööön:)

2026-01-09T09:20:05.395479 - **Anna Arndt:**
> Hi Juli, wenn ich die Agenturen/Schauspieler anfrage, darf und soll ich schon sagen, für was genau? Und was soll ich als gewünschtes Datum angeben?

2026-01-09T09:36:37.965179 - **Julia:**
> Guten Morgen!

2026-01-09T09:38:57.901569 - **Julia:**
> Ne, sag gerne ein internes Pitch Video mit einer Länge von 30-40 Sekunden
Datum Mitte/Ende nächster Woche oder direkt Montag/Dienstag KW4
Dauer des Drehs schätze ich mal auf maximal 2 Std. (mit allem drum herum)

2026-01-09T09:39:27.855419 - **Anna Arndt:**
> Perfekt, danke dir!

2026-01-09T09:39:55.989369 - **Anna Arndt:**
> haben wir was die weibliche Schauspielerin angeht irgendwelche besonderen Vorstellungen und Voraussetzungen?

2026-01-09T09:42:43.462969 - **Julia:**
> "Mandy" soll ja quasi stellvertretend für einen Crush sein, deshalb würde ich sagen eine natürlich und "klassisch schöne"/attraktive Frau, Ende 20, Blond oder Brünett spielt hier jetzt keine Rolle, schlank/ sportlich, groß

2026-01-09T09:43:23.166659 - **Julia:**
> Wenn es bei den Seiten auch eine Auswahl gibt, kannst du mir sehr gerne auch ein paar Profile zur Auswahl schicken, dann suchen wir uns hier welche raus und können genau sagen, wen wir bräuchten

2026-01-09T09:51:47.740949 - **Anna Arndt:**
> Ah super, das wollte ich grade vorschlagen!

2026-01-09T09:52:30.948709 - **Anna Arndt:**
> Auf den Seiten ist tatsächlich bisher niemand dabei, der mich hundert pro überzeugt...Aber ich schick dir mal eine Auswahl

2026-01-09T09:54:49.854709 - **Anna Arndt:**
> <https://lachfalten-people.de/models/semi-h/>
<https://lachfalten-people.de/models/brian-s/>
<https://lachfalten-people.de/models/daniel-t/>
<https://lachfalten-people.de/models/joe-t/>

2026-01-09T09:56:42.054229 - **Anna Arndt:**
> <https://www.fameonme.de/kartei/komparsen/aran-s/>
<https://www.fameonme.de/kartei/extra-faces/ahmed-m/>

2026-01-09T09:56:43.675919 - **Julia:**
> Ja hast du Recht aber ich seh was du meinst, würde sagen die sind alle "okay"

2026-01-09T09:57:08.243379 - **Julia:**
> Bisheriger Favorit: Brian von Lachfalten

2026-01-09T09:57:28.968379 - **Anna Arndt:**
> <https://agenturfrehse.com/schauspieler/daniel-aminati/>

2026-01-09T09:58:07.781429 - **Anna Arndt:**
> <https://agenturfrehse.com/schauspieler/peter-post/>

2026-01-09T09:58:58.043249 - **Anna Arndt:**
> Frauen schau ich grad noch durch aber da finden wir ja safe was

2026-01-09T09:59:01.242249 - **Julia:**
> ich melde mich gleich nach meinem Meeting. Ich frage mich ob der Aufwand für zB Brian der aus Köln ist, für die 2 Std Dreh dann auch relevant ist
Also wenn wir Münchner finden, wäre super

2026-01-09T09:59:50.216499 - **Anna Arndt:**
> Kein Stress! Ah shit, hatte nicht gesehen dass der aus Köln ist:sweat_smile: ich schau ob die restlichen Münchner sind

2026-01-09T10:00:04.713179 - **Anna Arndt:**
> Sonst hab ich auf den Seiten aber alle durchgeschaut

2026-01-09T10:07:35.294849 - **Anna Arndt:**
> hmm jagut die sind alle bisschen weit weg...ich guck mal ob ich münchner agenturen finde

2026-01-09T10:22:04.014459 - **Anna Arndt:**
> <https://www.zimt-casting.com/online-kartei?tx_bsdsedcards_bsdsedcards%5Baction%5D=show&amp;tx_bsdsedcards_bsdsedcards%5Bcontroller%5D=People&amp;tx_bsdsedcards_bsdsedcards%5BcurrentPage%5D=15&amp;tx_bsdsedcards_bsdsedcards%5Bfilter%5D%5BageMax%5D=99&amp;tx_bsdsedcards_bsdsedcards%5Bfilter%5D%5BageMin%5D=0&amp;tx_bsdsedcards_bsdsedcards%5BitemsPerPage%5D=96&amp;tx_bsdsedcards_bsdsedcards%5Bpeople%5D=1504&amp;cHash=83be40d0f62c13cb0afc5143212601af|https://www.zimt-casting.com/online-kartei?tx_bsdsedcards_bsdsedcards%5Baction%5D=show&amp;[…]ds%5Bpeople%5D=1504&amp;cHash=83be40d0f62c13cb0afc5143212601af> vielleicht mit hair &amp; makeup? hahaha

2026-01-09T10:22:26.034219 - **Anna Arndt:**
> <https://www.zimt-casting.com/online-kartei?tx_bsdsedcards_bsdsedcards%5Baction%5D=show&amp;tx_bsdsedcards_bsdsedcards%5Bcontroller%5D=People&amp;tx_bsdsedcards_bsdsedcards%5BcurrentPage%5D=15&amp;tx_bsdsedcards_bsdsedcards%5Bfilter%5D%5BageMax%5D=99&amp;tx_bsdsedcards_bsdsedcards%5Bfilter%5D%5BageMin%5D=0&amp;tx_bsdsedcards_bsdsedcards%5BitemsPerPage%5D=96&amp;tx_bsdsedcards_bsdsedcards%5Bpeople%5D=1552&amp;cHash=d5330b7b2bc70140f9a4118c3ce0b8fc|https://www.zimt-casting.com/online-kartei?tx_bsdsedcards_bsdsedcards%5Baction%5D=show&amp;[…]ds%5Bpeople%5D=1552&amp;cHash=d5330b7b2bc70140f9a4118c3ce0b8fc>

2026-01-09T10:46:29.906549 - **Anna Arndt:**
> <https://lachfalten-people.de/models/monika-g/>
<https://lachfalten-people.de/models/amelia-h/>
<https://lachfalten-people.de/models/mirjam-h/>
<https://lachfalten-people.de/models/daria-w/>

2026-01-09T10:46:51.701159 - **Anna Arndt:**
> die sind zumindest alle in München:sweat_smile:

2026-01-09T11:07:38.142239 - **Anna Arndt:**
> <https://www.fameonme.de/kartei/komparsen/nathalie-b/>

2026-01-09T11:08:35.491429 - **Anna Arndt:**
> <https://www.fameonme.de/kartei/komparsen/caroline-n/>

2026-01-09T11:09:02.148479 - **Anna Arndt:**
> <https://www.fameonme.de/kartei/komparsen/laura-d/>

2026-01-09T11:09:47.015159 - **Anna Arndt:**
> bei denen steht nichts dabei aber ich wollte trotzdem mal paar von der Seite raussuchen, falls wir den Mann auch von hier nehmen macht es ja Sinn, die direkt zusammen bei einer Agentur zu buchen

2026-01-09T11:16:08.983899 - **Anna Arndt:**
> <https://agenturfrehse.com/schauspieler/electra-maier/>

2026-01-09T11:16:48.338579 - **Anna Arndt:**
> <https://agenturfrehse.com/schauspieler/darya-birnstiel/>

2026-01-09T11:16:55.396919 - **Anna Arndt:**
> hier wieder beide aus München

2026-01-09T11:17:33.382469 - **Anna Arndt:**
> Der hier vielleicht noch mit Fantasie und Makeup <https://agenturfrehse.com/schauspieler/john-vincent-ragner/>

2026-01-09T11:31:03.579469 - **Anna Arndt:**
> <https://www.p-f.tv/system/index.php?cccpage=komparsen&amp;show=165336> theoretisch aber die website sieht so bisschen...unseriös aus

2026-01-09T12:23:16.669649 - **Julia:**
> super, schau mir jetzt alle an :slightly_smiling_face:

2026-01-09T12:37:38.248639 - **Julia:**
> Lachfalten: Daria, Amelia
fameonme: Brian --&gt; der könnte genau den richtigen Humor mitbringen für diese Art von Video, Laura D., Caroline N.

--&gt; die gerne mal anfragen!

2026-01-09T12:39:55.555119 - **Julia:**
> Eckdaten:
• Halber Drehtag in München
• KW3 oder KW4
• höchstwahrscheinlich Outdoor, evtl. Indoor (sowas wie Therme Erding könnte man überlegen)
• Dreh ist für einen internen Pitch
• Social Media Format// also gerne Humor mitbringen
• gerne schon vorab sagen: Badekleidung/ Unterwäsche (wird natürlich von uns gestellt)

2026-01-09T12:41:57.662629 - **Anna Arndt:**
> Mach ich!

2026-01-09T12:42:18.841479 - **Julia:**
> danke dir!

2026-01-09T13:08:00.128129 - **Julia:**
> Kam Aran über Flo? Brian ist raus?

2026-01-09T13:10:11.304869 - **Julia:**
> ah sorry mein Fehler, habs verwechselt. Brian ist ja von Lachfalten

2026-01-09T13:55:30.739569 - **Anna Arndt:**
> Oh, Aran ist ausversehen drinn geblieben sorry! Aber macht ja nichts, wir müssen eh ein paar Leuten ggf absagen.

2026-01-09T13:55:56.894269 - **Anna Arndt:**
> Yesss, Brian hab ich gesehen und dann richtig zugeordnet

2026-01-09T14:45:36.671719 - **Julia:**
> super danke

2026-01-09T14:48:49.804289 - **Julia:**
> Magst du auf die Absage einmal antworten:
• dass der Dreh natürlich so kurz wie möglich statt findet und wir realistisch max. 2 Std benötigen
• wir natürlich für warme Mäntel, Heißgetränke usw. sorgen ("da wir ja auch nicht frieren möchten") und die Darsteller:innen immer nur kurz in Unterwäsche wären
• zudem wir gerade noch die Option mit Indoor klären
Bei fame on me:
• einmal erklären, dass das video nur für interne Zwecke genutzt wird und wir also keine SoMe Nutzung brauchen
• dann gerne einmal unverbindlich die Angebote einholen

2026-01-09T14:50:20.368369 - **Julia:**
> Bezüglich Indoor:
Würdest du bitte hier einmal anfragen, ob ein Dreh möglich wäre und was es kosten würde für einen halben Tag?
<https://robertobeach.de/home/beach-area/>

Hätte das gerne als Back-Option für Indoor :slightly_smiling_face: Könnte man ja sonst auch draußen am Beach cool drehen

2026-01-09T15:18:12.312599 - **Anna Arndt:**
> Klaro bin dran!

2026-01-09T15:20:28.470359 - **Julia:**
> danke dir!

2026-01-09T15:23:31.747599 - **Julia:**
> Falls du noch Ideen hast zu Artists die cool passen könnten, außer:
• Cro
• SSIO
• Nina Chuba
• Ski Aggu
• Bill &amp; Tom
• Marteria
• Zartmann 
sag gern Bescheid :slightly_smiling_face: Solange sie nicht mit ALDI oÄ zusammenarbeiten

Oder auch momentane "Trends" bzw. Themen die man überall mitbekommt wie Späti Talk mit Mo Douzi, auch super gerne. Weil wir daraufgehend die Kampagne bauen müssen

2026-01-09T15:24:29.512289 - **Julia:**
> <https://www.youtube.com/watch?si=WUN0h3LPnSfYqM0b&amp;v=rR4oIJiRp-g&amp;feature=youtu.be>

2026-01-09T15:25:23.958949 - **Julia:**
> Da wärs natürlich auch super einen Bezug zu Sommer/ Festival zu finden

2026-01-09T15:33:30.386769 - **Anna Arndt:**
> yesss das kenn ich

2026-01-09T15:34:42.652859 - **Anna Arndt:**
> Blöde Frage aber wieso hatten wir in erster Linie SSIO? Ich mein cool hahah aber gibt es einen bestimmten Grund passend zu Lidl oder "nur" weil er gerade so bekannt ist?

2026-01-09T15:41:56.892529 - **Julia:**
> Das kommt von Lidl selbst. Sie finden seine Memes und die Art der Launches so genial 

2026-01-09T15:42:14.759419 - **Anna Arndt:**
> Ich überleg auf jeden Fall mal aber spontaner Einfall - Wäre Ikkimel zu polarisierend?:joy:

2026-01-09T15:42:23.524809 - **Anna Arndt:**
> Ah okay spannend!

2026-01-09T15:46:15.402899 - **Julia:**
> Ja hatte ich auch kurz überlegt. Können wir auf jeden Fall mal auf die Liste setzen :joy: krasser sollten wir jedenfalls nicht mehr werden 

2026-01-30T09:26:16.752829 - **Anna Arndt:**
> Hallo Juli! Wie kann ich dich bei MINI/Pepsi unterstützen?

2026-01-30T09:43:38.379009 - **USLACKBOT:**
> 

2026-01-30T09:57:41.969949 - **Julia:**
> Hello Anna!

2026-01-30T10:01:04.569919 - **Julia:**
> Für Mini haben Marie und ich erste Ideen formuliert – allerdings habe ich diese noch nicht final gecheckt bzw. verfeinert. Du kannst es dir sehr gerne einmal durchlesen und deine Kommentare hinzufügen oder falls du andere Ideen hast einfügen!
<https://docs.google.com/document/d/1NEnlqXtQv5wCwQTJwg87O0flVR4dX0z-fwHf1-nqxH8/edit?tab=t.0>

Pepsi hab ich noch zu wenige Infos, um hier etwas kreatives zu erstellen. Falls Flo da schon was hat, kannst du auch gerne damit starten :slightly_smiling_face:
Ansonsten weiß ich, dass Mert viel auf dem Tisch hat, da ich ihn gerade nicht unterstützen kann durch SIXT. Sonst frag ihn doch gerne mal? Da geht es um Content Ideen für Instagram für die Marke Gorenje

2026-01-30T10:06:12.800159 - **Anna Arndt:**
> okie, mach ich alles! danke dir!

2026-01-30T10:07:16.488919 - **Julia:**
> danke dir :slightly_smiling_face:

2026-01-30T10:07:35.180439 - **Julia:**
> ich meld mich auch nochmal, evtl. benötige ich für SIXT deine Photoshop Skills

2026-01-30T10:07:52.598599 - **Anna Arndt:**
> ohh okay, gerne!

2026-01-30T10:10:11.641699 - **Anna Arndt:**
> kannst du mir bitte noch den zugriff freischalten für das MINI dokument?

2026-01-30T10:10:44.687429 - **Julia:**
> Glaube den müsstest du anfragen

2026-01-30T10:10:51.927169 - **Julia:**
> Dann kann ich dich freigeben

2026-01-30T10:14:58.767509 - **Anna Arndt:**
> hab ich eigentlich...

2026-01-30T10:15:01.535849 - **Anna Arndt:**
> ich schau nochmal

2026-01-30T10:15:48.531859 - **Anna Arndt:**
> ah okay, irgendwie hat mein browser gesponnen, in einem anderen gehts!

2026-01-30T10:16:04.533719 - **Julia:**
> okay

2026-01-30T10:16:08.159059 - **Julia:**
> also du hast Zugriff?

2026-01-30T10:17:26.242119 - **Anna Arndt:**
> yes, danke!!

2026-01-30T10:18:14.829439 - **Julia:**
> perfekt!

2026-01-30T11:17:47.137989 - **Anna Arndt:**
> Zu Mini habe ich Kommentare und Ideen eingefügt! Ich fand das Spreading Smiles am coolsten da seh ich sehr viel Potenzial!:star-struck:

2026-01-30T11:18:21.221589 - **Anna Arndt:**
> Zu Pepsi hab ich grade mit Flo gesprochen und ich kümmer mich drum! Er meinte das kannst du als erledigt betrachten:)

2026-01-30T11:26:51.146659 - **Julia:**
> super, schau ich mir an :slightly_smiling_face: Ja mag die Idee auch sehr gerne

2026-01-30T11:26:56.627859 - **Julia:**
> danke dir

2026-01-30T11:32:34.365679 - **Julia:**
> Jetzt zur PS Task: Könntest du bei den Bildern die ich dir nach und nach schicke bitte das SIXT Logo austauschen? Ist nur ein minimaler Unterschied aber wichtig :slightly_smiling_face:

Bild 1: Too Hot too handle
Bild 2: Dschungelcamp
Bild 3: Are you the one?

Finale PNGs bitte in diesen Ordner mit folgendem Namen ablegen:
300126_SIXT_RealityTV_TooHot
300126_SIXT_RealityTV_IBES
300126_SIXT_RealityTV_TheOne

Sixt Logo:

  📎 SIXT_Logo_BW_RGB.png
  📎 SIXT_Logo_Neg_RGB.png

2026-01-30T11:32:51.855529 - **Julia:**
> 

  📎 hf_20260130_102234_5c1e4028-9e27-4be3-83c8-bf6038de4c92.png

2026-01-30T12:02:42.799059 - **Julia:**
> und last one:

2026-01-30T12:02:49.783889 - **Julia:**
> 

  📎 hf_20260130_110016_c0776530-ef43-44f8-93fc-ab7d59ba83da.png

2026-01-30T12:03:01.677849 - **Julia:**
> sag gerne Bescheid, wenn du Hilfe benötigst :slightly_smiling_face:

2026-01-30T12:04:11.772269 - **Julia:**
> ah sorry beim Dschungelcamp gabs noch eine Anpassung:

2026-01-30T12:06:51.635709 - **Julia:**
> 

  📎 hf_20260130_110355_7c5d3358-1466-4ce4-933b-933cbf6c6cb1.png

2026-01-30T12:13:06.182479 - **Anna Arndt:**
> Dankeschön! Ich mach mich gleich dran

2026-01-30T12:34:53.072259 - **Anna Arndt:**
> Sollen die kleinen Logos auf den Autos auch ausgetauscht werden?

2026-01-30T12:52:09.737679 - **Anna Arndt:**
> Kannst du mir einen Pfad schicken zu dem Ordner wo die rein sollen?

2026-01-30T13:07:06.136809 - **Julia:**
> Die großen reichen 

2026-01-30T13:07:14.414909 - **Julia:**
> Ah mist, schicke ich dir gleich!

2026-01-30T13:08:14.281859 - **Anna Arndt:**
> Top, kein Stress!

2026-01-30T13:34:15.269459 - **Julia:**
> <https://drive.google.com/drive/folders/1aLCz7CZkdJOu_PQiBQh9GxUdMamSHJdt>

2026-01-30T13:34:18.233219 - **Julia:**
> danke dir!!

2026-01-30T13:47:49.748079 - **Anna Arndt:**
> Da komme ich zu einem Instagram Workshop Ordner - ist das richtig?

2026-01-30T13:53:08.113679 - **Julia:**
> genau "ready for presentation"

2026-01-30T14:28:44.754089 - **Julia:**
> alles gut soweit? :slightly_smiling_face:

2026-01-30T14:31:25.438099 - **Anna Arndt:**
> yess! ich mach grad pepsi

2026-01-30T14:32:16.564759 - **Anna Arndt:**
> kannst du die hochgeladenen Bilder sehen?

2026-01-30T14:33:56.263639 - **Julia:**
> jaa super, vielen dank :slightly_smiling_face:


---


## Group DMs (Multi-Person)

### florian (29 messages, 15 from Julia)

**Participants:** florian
**Folder:** `mpdm-julia.hopper--florian--mert-1`

2025-09-26T12:07:49.830969 - **Julia:**
> Flo, wolltest du die Bilder in der Präsi direkt eingesetzt oder sollen wir sie dir hier schicken?

2025-09-26T12:09:53.805949 - **Julia:**
> würde sonst schon mal ein paar einsetzen

2025-09-26T12:10:22.504159 - **Florian Listl:**
> am besten in der PPT direkt

2025-09-26T12:10:23.631449 - **Florian Listl:**
> danke :slightly_smiling_face:

2025-09-26T12:16:19.455289 - **Julia:**
> okay

2025-09-26T12:16:36.854959 - **Julia:**
> Könntest du die excel tabelle noch in asana ablegen? Dann kann ich mir die "Friends" und Co. nochmal anschauen

2025-09-26T12:27:24.087849 - **Julia:**
> Hab ein paar eingesetzt, die ich noch im Kopf hatte

2025-09-26T12:27:39.928209 - **Julia:**
> <@U093J779DAQ> würdest du die letzte Slide mit den Kommentaren befüllen? :slightly_smiling_face:

2025-09-26T12:27:56.093219 - **Florian Listl:**
> Hi Juli, sehr gerne

2025-09-26T12:31:33.901119 - **Mert Koc:**
> Soll ich dafür einfach Screenshots nutzen?

2025-09-26T12:31:42.398319 - **Julia:**
> yes

2025-09-26T12:46:57.113349 - **Florian Listl:**
> ist online <https://app.asana.com/1/1199360402832734/task/1211465610715674/comment/1211475459341977?focus=true>

2025-09-26T12:47:01.890189 - **Florian Listl:**
> <@U09D64LA420>

2025-09-26T12:48:48.333489 - **Julia:**
> danke!

2025-09-26T12:49:20.131769 - **Mert Koc:**
> Done :white_check_mark:

2025-09-26T12:57:51.293809 - **Julia:**
> Bilder usw. sind alle angepasst – die restlichen Slides baust du gerade, oder <@UNUQV5R08>?

2025-09-26T12:58:10.404119 - **Florian Listl:**
> sind die CM Screenshots auch schon drin?

2025-09-26T12:58:27.771869 - **Julia:**
> yeees <@U093J779DAQ>

2025-09-26T13:09:41.879829 - **Florian Listl:**
> top

2025-11-03T16:55:37.565909 - **Julia:**
> Hi! Flo noch eine Frage – gibt es schon irgendwo eine Auswertung zur Hisense/ Gorenje Zielgruppe? Klar auf Tiktok etwas jünger aber gibt es genaue Metriken?

2025-11-03T16:57:36.081459 - **Florian Listl:**
> sehr gute Frage:
Gorenje: student bis young professional/ young family
Hisense: Tech begeistert, aber grundsätzlich jeder, der einen guten TV zu einem fairen Preis möchte.
Hisense hat bisher noch viel auf TV gesetzt

2025-11-03T16:57:48.132679 - **Julia:**
> Und haben wir eigentlich einen BCC interen TikTok Account den wir für Recherche nutzen können? Sonst aktivier ich meinen uralten wieder :smile:

2025-11-03T16:58:32.257349 - **Julia:**
> okay super. Aber es gibt jetzt nicht das typische Diagramm wie bei Instagram? Altergruppe für den Account, Standort etc.?

2025-11-03T16:58:53.777669 - **Florian Listl:**
> wir haben einige, mach ruhig einen neuen auf mit deiner Juli Adresse, weil dann ist er nicht "versaut", wenn du davor zb viel Formel 1 geschaut hast, dann wird dir der algo keine koch oder tv videos anzeigen

2025-11-03T16:59:00.293179 - **Florian Listl:**
> ah verstehe. kriegst du

2025-11-03T16:59:01.252209 - **Florian Listl:**
> sekunde

2025-11-03T16:59:20.209019 - **Julia:**
> ja genau. okay, dann so

2025-11-03T17:01:48.855639 - **Florian Listl:**
> 

  📎 IMG_9212.png
  📎 IMG_9211.png
  📎 IMG_9210.png

2025-11-03T17:32:45.754679 - **Julia:**
> super danke :slightly_smiling_face:


---

### florian, anna (11 messages, 4 from Julia)

**Participants:** florian, anna
**Folder:** `mpdm-florian--anna--julia.hopper-1`

2025-11-14T15:54:18.678729 - **Florian Listl:**
> Hey :slightly_smiling_face:
<@U09RFTW8ZFS> schick gern die Ergebnisse hier in den chat :slightly_smiling_face: Juli hat ja die Grundideen formuliert, ich hab sie gerade gebrieft was wir besprochen haben und an was du arbeitest :)

2025-11-14T16:22:28.142239 - **Anna Arndt:**
> Hii! Mach ich sofort, ich helf grad noch Basti kurz was!

2025-11-14T16:32:30.331309 - **Julia:**
> Hi Anna, schön dich kennenzulernen! :slightly_smiling_face: Danke dir

2025-11-14T17:00:01.375089 - **Anna Arndt:**
> <https://docs.google.com/document/d/13JSNKBfOF-ZBb3NoNgT_XgblKLRs51tTS3yX14_lRp4/edit?tab=t.0>

2025-11-14T17:00:18.133229 - **Anna Arndt:**
> Hier bitte:) Könnt ihr das öffnen?

2025-11-14T17:00:38.302629 - **Anna Arndt:**
> Ebenso:relaxed:

2025-11-14T17:01:11.134779 - **Anna Arndt:**
> Gebt mir gerne Bescheid, wenn ich spezifisch etwas ändern, hinzufügen etc. kann! Ansonsten tüftel ich nochmal bisschen weiter dran rum:)

2025-11-14T17:09:36.696489 - **Julia:**
> yes, ich schau es mir an und melde mich!

2025-11-14T17:09:37.864409 - **Julia:**
> dankee dir

2025-11-14T17:21:09.976319 - **Anna Arndt:**
> Gerne vor allem bei den Texten kritisch sein! Das sind erstmal Entwürfe in welche Richtung es gehen könnte, aber ich bin mir garnicht so sicher - wenn die unlustig sind oder zu langweilig dann bin ich garnicht böse:joy:

2025-11-17T11:27:56.029549 - **Julia:**
> Hello Anna! :slightly_smiling_face: Nein garnicht, sind schon sehr coole Gedanken und Dialoge dabei. Vielen dank dir! Ich habe die Texte noch etwas ausformuliert FYI:

  📎 251117_Bitpanda_ApplevsPC_Skripte_Version_JH.pdf


---

### florian, jana (18 messages, 4 from Julia)

**Participants:** florian, jana
**Folder:** `mpdm-florian--jana--julia.hopper-1`

2025-11-11T11:55:12.322599 - **USLACKBOT:**
> Florian Listl moved all the messages from this conversation to one with <#C09RQJA8L31|>.

2025-11-27T11:07:20.837259 - **Florian Listl:**
> <@U0994RLAGHW> wann wurde der Antrag auf TikTok Verifizierung von Hisense abgegeben? Falls du's nicht weißt bitte mit Marvin rücksprache halten. Juli braucht die info

2025-11-27T15:07:15.850289 - **Florian Listl:**
> <@U0994RLAGHW> das team hat schon 5 mal nachgefragt, bitte schnelle antwort hierzu

2025-11-27T15:07:41.757639 - **Florian Listl:**
> wir brauchen auch die dokumente die das letzte Mal eingereicht wurden. Die müssen ja von dir oder Marvin geschickt worden sein

2025-11-27T15:33:51.406269 - **Jana Kordt:**
> <@UNUQV5R08> ja, ich hab nur ein Datum. 21.08.  Aber ich warte noch auf Bestätigung. 

2025-11-27T15:43:02.479379 - **Florian Listl:**
> Ja, bitte schicke auch die Dateien. Entweder Marvin oder du müssen die ja mal runtergeladen haben. Wir brauchen die <@U0994RLAGHW> 

Bitte bis morgen 15 Uhr schicken, danke

2025-11-27T16:00:04.161589 - **Jana Kordt:**
> Wir haben kein weiteres Datum. Man bekommt ja keine Mail oder so. 

2025-11-27T16:00:14.355529 - **Jana Kordt:**
> Ich konnte es mir von meinem
Stundenzettel ableiten. 

2025-11-27T16:00:35.390119 - **Jana Kordt:**
> Die Unterlagen hab ich bei Marvin angefragt. Bitte auch einmal auf dem Drive schauen <@U09D64LA420> 

2025-11-27T17:42:18.374059 - **Julia:**
> da liegt leider nichts ab, außer 2 dokumente.  danke dir!

2025-11-27T18:01:34.754619 - **Florian Listl:**
> <@U0994RLAGHW> wer hat den Antrag verschickt? Der muss ja alles haben. Das ist sinnvoller als wenn Juli den Drive durchsucht ohne zu wissen ob das alle files sind.

Bitte finde das raus, bis wann kannst du hier alle files schicken?

2025-11-28T09:41:48.989529 - **Jana Kordt:**
> Ich spreche schon mit Marvin…

2025-11-28T09:42:27.780979 - **Jana Kordt:**
> <@U09D64LA420> welche weiteren Dokumente brauchst du denn? Zeitungsartikel sind ja Links?

2025-11-28T09:43:20.673479 - **Jana Kordt:**
> <https://drive.google.com/drive/folders/1Fu16-ci6bNoXjWZj68RppTohia1w7yC9|https://drive.google.com/drive/folders/1Fu16-ci6bNoXjWZj68RppTohia1w7yC9>

Das haben wir ja bereits letzte Woche an Mert geschickt ?

2025-11-28T09:43:25.193229 - **Julia:**
> wir brauchen eine AUflistung welche Artikel (egal ob PDF oder Links) ihr schon hochgeladen habt. wir haben ja hier garkeinen überblick

2025-11-28T09:43:50.358889 - **Julia:**
> ja das sind litteraly 2 Dokumente?

2025-11-28T09:44:31.327789 - **Julia:**
> Ich mach einen neuen Chat mit Mert auf, er übernimmt das Thema

2025-11-28T09:44:56.628589 - **Jana Kordt:**
> <@U09D64LA420> die Zeitungsartikel lädt man ja nicht runter, das sind Links. Eine Auflistung gibt es da nicht. 


---

### jana (148 messages, 43 from Julia)

**Participants:** jana
**Folder:** `mpdm-julia.hopper--jana--marvin-1`

2026-01-12T10:55:31.052199 - **Julia:**
> Hi zusammen! eine Frage zu den "Zugängen":  hier ist einfach gemeint, was man benötigt oder?

  📎 Bildschirmfoto 2026-01-12 um 10.55.09.png

2026-01-12T10:55:56.278219 - **Julia:**
> Und <@U0994RLAGHW> könntest du mich noch freigeben? Hab ein paar Anfragen geschickt

2026-01-12T10:56:48.308939 - **Marvin Hammerschmidt:**
> Genau, das sind einfach nur die Dinge, die du benötigst
Zugang zu:
1. TikTok
2. Reportingliste
3. Projektliste

2026-01-12T10:58:29.720709 - **Julia:**
> Okay, danke! Das kommt dann mit dem sixt-account oder?

2026-01-12T10:59:01.701679 - **Marvin Hammerschmidt:**
> Das holen wir alles ein, sobald sie dich kennen

2026-01-12T10:59:18.781849 - **Marvin Hammerschmidt:**
> Ich nehme also an du hast dich dafür entschieden es zu probieren :slightly_smiling_face:?

2026-01-26T09:46:24.137699 - **Julia:**
> Hi! Also hier kam auch noch nichts von SIXT selbst oder?

  📎 Bildschirmfoto 2026-01-26 um 09.45.48.png

2026-01-26T09:46:47.579809 - **Marvin Hammerschmidt:**
> Soweit ich weiß nicht

2026-01-26T09:47:16.324359 - **Jana Kordt:**
> Nein, die Produktionsfirmen müssen ja erstmal rausgesucht und dem Kunden vorgestellt werden

2026-01-26T09:47:52.103269 - **Julia:**
> Yes, klang nur so als würde SIXT schon jemanden vor Ort angefragt haben

2026-01-26T10:26:55.505149 - **Marvin Hammerschmidt:**
> Sollen wir dann gleich in einen Call Juli, um da gemeinsam rüber zu gehen?
Muss noch was fertig machen und wäre dann ready

2026-01-26T11:32:45.652959 - **Jana Kordt:**
> Könnt ihr mir bitte zu den Ideen bei SIXT Videos raussuchen? :slightly_smiling_face:
Also Love is Blind ein TikTok/IG Video von einer Szene, Persoinality Change das Video etc.

Bitte runterladen und mir als Video schicken

2026-01-26T11:53:29.342239 - **Jana Kordt:**
> hello? :slightly_smiling_face:

2026-01-26T11:54:02.573659 - **Marvin Hammerschmidt:**
> Wir sind gerade noch busy
Ich schaus mir gleich an

2026-01-26T11:55:25.381589 - **Jana Kordt:**
> kein problem, wollte nur wissen, ob nachricht angekommen ist.

2026-01-26T12:16:39.768479 - **Marvin Hammerschmidt:**
> L:ove is blind

  📎 When Shayne called Natalie {Shaina} and then crashed out over it  🚩 #loveisblind #realitytv #unforgettable  #loveisblindnetflix #netflix #fyp #topmoments.mp4

2026-01-26T12:21:10.395829 - **Marvin Hammerschmidt:**
> Personalities

  📎 Video.mp4

2026-01-26T12:22:33.325989 - **Marvin Hammerschmidt:**
> Carpool

  📎 #carpoolkaraoke with #jlo #jenniferlopez #jamescorden #thelatelateshow #spanishlanguage.mp4

2026-01-26T12:24:36.909729 - **Marvin Hammerschmidt:**
> Versteckte Kamera

  📎 Kleingeld-Regen im Parkhaus Automat wechselt Münzen nur in Cent! 🤣😜 #parkhaus #kassenautomat #geldautomat #parkschein #parkscheinautomat #pranks #verstehensiespass #lustig #city.mp4

2026-01-26T12:25:35.065129 - **Marvin Hammerschmidt:**
> 5 Dinge die man nicht tun sollte

  📎 10 Dinge die sie nicht tun sollten wenn sie beim Zahnartzt sind #kesslersknigge #fyoupage #fypシ #memestiktok.mp4

2026-01-26T12:26:09.357259 - **Marvin Hammerschmidt:**
> Für Branch standorte find ich auf die schnelle nichts

2026-01-26T12:26:27.739109 - **Marvin Hammerschmidt:**
> Auto quiz

  📎 Guess these cars by their Bumpers #carquiz #guessthecar #quiz #autos #quizcar #automobile #cars #automobilequiz #autocar #bumper #cartrivia #carenthusiasts.mp4

2026-01-26T12:26:46.434189 - **Marvin Hammerschmidt:**
> KI Tipps

  📎 Wenn Autoteile ehrlich wären #auto #fyp #wenndingereden #witzig #autotok.mp4

2026-01-26T15:51:33.994709 - **Julia:**
> Danke Marvin! :slightly_smiling_face:

2026-01-26T15:52:07.367559 - **Julia:**
> <@U0994RLAGHW> du hattest in den Projektplan für Anything reingeschrieben, dass es eine Shortliste für die Moderatoren gibt. Könntest du mir die einmal schicken? Dankee

2026-01-26T16:02:12.841929 - **Marvin Hammerschmidt:**
> <@U0994RLAGHW> hast du noch die Präsi für die Dating Idee im Auto?

2026-01-27T09:05:13.441699 - **Jana Kordt:**
> Hello :slightly_smiling_face:
SOrry, ich war gestern busy mit Flo mit dem WOrkshop - melde mich gleich mit den neuen To Dos dazu

2026-01-27T09:05:33.002589 - **Jana Kordt:**
> <@U09D64LA420> Die Moderatoren-PPP liegt ab und ist in der Übergabe, aber ich suche es noch mal raus.

2026-01-27T09:05:56.656639 - **Jana Kordt:**
> <@U05LQB4GTC1> puhhh, wo haben wir die noch mal vorgestellt?
Ich erinner mich dran, aber weiß gerade nicht, in welcher ppp die war

2026-01-27T09:06:29.000639 - **Marvin Hammerschmidt:**
> Haben das nicht dem Kunden vorgestellt. Flo wollte die nicht 
Passt schon ich such später 

2026-01-27T09:06:52.347769 - **Jana Kordt:**
> ja, aber wir haben die präsei ja für flo gemacht erst - welcher monat war das?

2026-01-27T09:07:09.712339 - **Marvin Hammerschmidt:**
>  Puuuh 
Weiß ich echt nichtmehr :sob:

2026-01-27T09:55:03.443939 - **Jana Kordt:**
> Hier das Feedback von Flo zu den Ideen bei SIXT (IG WORKSHOP).

<@U05LQB4GTC1> Der Dialog bei Love is Blind muss angepasst werden. Hier müssen wir mehr den USP eines Autos rausstellen, mit Stereotyp spielen. Das ist zu generisch noch.

<@U09D64LA420> Flo hätte gerne ein Video Snippet/MockuP (kann AI sein) von einer Love is Blind Szene. Man sollte zuerst die Frau sehen, dann das Reveal mit dem SIXT Auto.

<@U05LQB4GTC1> - wie kriegen wir das Carpool karaoke auf 120 Sekunden? Wie kriegen wir in die 120 Sekunden was rein, was ganz typisch für SIXT ist?

<@U05LQB4GTC1> &amp; <@U09D64LA420> - Habt ihr eine Idee für potenzielle Moderatoren für Carpool Karaoke?

<@U05LQB4GTC1> - Personality Change muss krasser sein. Öko Mutti steigt in einen Benzer, dann rappt sie Haftbefehl mit.
Macho Typ sterigt in SUV und hat einen Matcha Latte in der Hand und sing DShirin David.
Welche anderen Ideen hast du? Wir brauchen 7 Ideen...

<@U05LQB4GTC1> - SIXT Pranked (AI Voice) - Hier brauchen wir konkrete Beispiele (bim Popeln erwischt, am Handy, etc)
<@U09D64LA420> - die die Szene brauchen wir auch ein Video mit einer eingesprochenen Stimme - der Kunde muss sich das vorstellen können.

<@U09D64LA420> - Bitte ein Carousel Ad erstellen mit Dingen, die man nicht sagen sollte - die Ideen sind super, sollten wir nur anskribbeln.

<@U05LQB4GTC1> - das Quiz findet er so etwas zu billig - er will RSAs mit einbeziehen, ählich wie hier: <https://www.youtube.com/watch?v=l9fs06Fw8FY>
Hier brauchen wir konkrete Fragen.

<@U09D64LA420> Wir brauchen je ein THumbnail zu jeder Idee - damit wri das in ein Instagram Feed mockuppen können.

2026-01-27T10:02:05.474359 - **Marvin Hammerschmidt:**
> Juli und ich sprechen um 11:30 darüber
Bis wann muss das denn fertig sein?
Wir haben leider auch so generell einiges auf dem Tisch liegen
Ursprünglich waren ja 2 std von mir für den Workshop eingeplant falls ich mich recht erinnere

2026-01-27T10:24:31.527249 - **Marvin Hammerschmidt:**
> bzw: Wann ist der nächste Blick darauf

2026-01-27T10:25:35.101049 - **Jana Kordt:**
> Hey hey. Die 2 Stunden waren der letzte workshop. Dieser ist mehr. Ich finde die Übersicht von Flo gerade nicht. 

Ich spreche mit Flo morgen Nachmittag, aber Julia Sachen reichen Donnerstag 

2026-01-27T10:26:11.086039 - **Marvin Hammerschmidt:**
> Ah okay

2026-01-27T10:31:57.371859 - **Julia:**
> Donnerstag ist super knapp evtl. wird nicht alles fertig

2026-01-27T10:32:25.475789 - **Jana Kordt:**
> Bis wann würde es denn gehen?

2026-01-27T10:32:57.866079 - **Julia:**
> kann ich so nicht sagen, kommt immer auf die AI an. Aber ich geb eh Bescheid, sobald ich was weiß

2026-01-27T10:33:14.969479 - **Jana Kordt:**
> Also bis Freitag brauchen wir es definitiv 

2026-01-27T10:34:59.381119 - **Julia:**
> yes. Flo weiß aber auch, dass die Designs/ Videos mit AI oft nicht klappen, daher kann es sein, dass eine Idee so nicht visualisiert werden kann wie er sich das vorstellt. ich stelle alles bereit was geht – nur evtl. anders :slightly_smiling_face:

2026-01-27T12:14:36.730209 - **Marvin Hammerschmidt:**
> <@U0994RLAGHW> was ist mit den ideen zu denen es keinen Kommentar gibt?

2026-01-27T12:15:11.333859 - **Jana Kordt:**
> Die Städte Ideen sind raus :( 

2026-01-27T12:15:22.712849 - **Marvin Hammerschmidt:**
> Ai erklär video?

2026-01-27T12:15:59.863139 - **Julia:**
> Das wollte Sixt aber unbedingt oder?

2026-01-27T12:16:14.096969 - **Marvin Hammerschmidt:**
> Sie sind zumindest starke fans von ai

2026-01-27T12:16:24.738629 - **Jana Kordt:**
> <@U09D64LA420> woher weiß SIXT was wir vorstellen werden? 

2026-01-27T12:16:55.219419 - **Jana Kordt:**
> Eigentlich haben wir gesagt weg von AI videos :grin: gerade bei Instagram 

2026-01-27T12:17:07.572469 - **Marvin Hammerschmidt:**
> Sixt und ich reden
Und ich weiß ja was sie mögen und was nicht
In manchen bereichen musste ich auch vorgreifen, da sie sonst dinge selsbt umgesetzt hätten

2026-01-27T12:17:14.327299 - **Marvin Hammerschmidt:**
> also weg von ai wollen sie auf keinen Fall

2026-01-27T12:17:14.708779 - **Julia:**
> ganz genau

2026-01-27T12:17:31.988489 - **Jana Kordt:**
> Komisch. Das war ein learning mit Paul auf Instagram 

2026-01-27T12:18:04.852289 - **Jana Kordt:**
> Ich stelle die Idee Flo noch mal vor und Mede mich dann 

2026-01-27T12:18:24.554669 - **Marvin Hammerschmidt:**
> Also mir wurde es wirklich oft erzählt dass sie ai machen wollen und sie haben ja auch die eltzten wochen mehrere ai pieces geposted

2026-01-27T12:18:54.333099 - **Jana Kordt:**
> Wir sind aber mit der ersten Runde an Ideen so super aufgestellt. Dann haben wir 2 videos pro series format (hero, entertainment, utility). 

2026-01-27T12:19:02.815979 - **Jana Kordt:**
> Aber wie gesagt, stelle die Idee Flo noch mal vor 

2026-01-27T12:19:36.106269 - **Marvin Hammerschmidt:**
> Er kennt die videos an sich auch

2026-01-27T12:20:08.697309 - **Jana Kordt:**
> Habt ihr eine Idee für 3 Fakten? 

2026-01-27T12:20:21.813789 - **Jana Kordt:**
> Er will das aus konzipiert haben 

2026-01-27T12:20:35.818259 - **Marvin Hammerschmidt:**
> Für das ai video

2026-01-27T12:20:38.498309 - **Marvin Hammerschmidt:**
> ja ich schau später

2026-01-27T12:20:43.433379 - **Jana Kordt:**
> Jap 

2026-01-28T09:54:07.590439 - **Jana Kordt:**
> Hello ihr beiden. Wird sieht es aus mit den Sachen für den Workshop? 

2026-01-28T09:56:05.122929 - **Marvin Hammerschmidt:**
> Ich hab eingetragen was mir eingefallen ist 
Love ist blind Text ist fertig 

Carpool hab ich was zu geschrieben 

Personality change müssen wir heute nochmal drüber gucken  genau so wie pranked 

Quiz hab ich auch was zu geschrieben 

2026-01-28T09:56:25.877109 - **Jana Kordt:**
> In welchem Dokument ? 

2026-01-28T09:56:27.483379 - **Julia:**
> bin dabei nach und nach die Visualisierungen zu erstellen

2026-01-28T09:57:57.727599 - **Marvin Hammerschmidt:**
> <https://docs.google.com/document/d/1fI3JcT0WHICFJ_oo6li7B8t22ezx9aWenC8AeXIjVSo/edit?tab=t.0>

2026-01-28T11:16:27.226129 - **Julia:**
> hello! hab leider immer noch keinen Zugang zu Asana, wer kann mich freigeben?

  📎 Bildschirmfoto 2026-01-28 um 11.15.52.png

2026-01-28T11:20:04.619769 - **Marvin Hammerschmidt:**
> <@U0994RLAGHW> kannst du uns die Moderatoren Liste zukommen lassen?

  📎 image.png

2026-01-28T11:20:52.848559 - **Marvin Hammerschmidt:**
> Ebenso bitte die Konzepte zu  dem Girly Fräsen und Sticker die SIXT vorgestellt wurden

  📎 image.png

2026-01-28T11:28:32.098559 - **Jana Kordt:**
> <@U05LQB4GTC1> Fräasen, Girly Hello Kitty Car &amp; Sticker kamen von dir. das war ein dokument, was du mir geshcikt hattest

2026-01-28T11:29:03.840479 - **Marvin Hammerschmidt:**
> Aber ich habs nicht vorgestellt
Das waren doch du und Flo oder nicht?
Kannst du mir die Unterlagen dazu schicken

2026-01-28T11:29:05.804519 - **Jana Kordt:**
> Moderator schau ich nach dem Termin, das hatte ich doch verlinkt, weird

2026-01-28T11:29:24.857309 - **Jana Kordt:**
> Wir haben keine Präsentation zu den Ideen gemacht, wir sind das im Call durchgegenangen mit dem Dokument von dir

2026-01-28T11:29:44.567819 - **Marvin Hammerschmidt:**
> Hast du die Dokumente noch?

2026-01-28T11:30:50.455399 - **Marvin Hammerschmidt:**
> <https://docs.google.com/document/d/18ji3u2cROPi5dXF4SCS85hLjhxyTXLRuUWqweOS9K2M/edit?usp=sharing>
Das war von mir

Das hier nicht
<https://docs.google.com/document/d/10-Z_dcXXJAAxXG_grSNrBiBVtjluL9BhqKYBgIWdNPQ/edit?usp=sharing>

2026-01-28T11:32:17.821199 - **Jana Kordt:**
> muss ich schauen. Wir haben das damals zusammen ini einem video call gemacht

2026-01-28T11:53:50.457459 - **Jana Kordt:**
> Flo will morgen zusamemn über den Workshop gehen mit allen fertigen Videos und so <@U09D64LA420>
Wann kannst du?

2026-01-28T12:33:16.830969 - **Julia:**
> 

  📎 audio_message.m4a

2026-01-28T12:33:25.279729 - **Julia:**
> Ab 14.30 Uhr wäre super

2026-01-28T12:33:27.467759 - **Julia:**
> danke dir!

2026-01-28T12:35:23.546689 - **Jana Kordt:**
> Cool, schicke euch die Präsi 

2026-01-28T12:37:33.764879 - **Julia:**
> danke!

2026-01-28T12:49:13.075989 - **Julia:**
> Kannst du schon einschätzen wann ca? Dann können wir es etwas planen

2026-01-29T09:51:39.504029 - **Jana Kordt:**
> hä? habt ihr die präsentation bekommen?

2026-01-29T09:51:44.557219 - **Jana Kordt:**
> mein slack ist immer noch auf 99%

2026-01-29T09:51:46.287039 - **Jana Kordt:**
> wtf

2026-01-29T09:52:32.986119 - **Jana Kordt:**
> 

  📎 WORKSHOP 2.0 - v1 JK.pdf

2026-01-29T09:53:02.917089 - **Jana Kordt:**
> ich schicke es mal per mail

2026-01-29T09:53:06.976659 - **Jana Kordt:**
> wie weird

2026-01-29T09:53:27.266729 - **Julia:**
> Ne, leider nicht. Flo hat sie dann geschickt. Marvin und ich haben die Slides mit den Formaten angepasst. Sollten gegen mittags fertig werden. Dann schicke ich dir die Sildes hier rein und wir können sie später zusammen fügen. Die Videos schicke ich dir gesondert per Link, dann kannst du sie so nochmal einbauen

2026-01-29T09:53:38.220059 - **Julia:**
> alles gut, haben sie ja jetzt

2026-01-29T11:06:20.983429 - **Jana Kordt:**
> <@U05LQB4GTC1> Frage zu dem Dialog bei Love is blind - das ist immer noch nicht Automodell spezifisch, nur mehr Rental Car spezifisch - was ist die Begründung?

2026-01-29T11:06:28.657499 - **Jana Kordt:**
> Ich find es gut, aber die Frage wird von Flo kommen

2026-01-29T11:07:00.327589 - **Marvin Hammerschmidt:**
> Es ist autospezifisch aber subtil 
Klischee: bmw Fahrer blinken nicht 

2026-01-29T11:12:54.707919 - **Jana Kordt:**
> ahhhh

2026-01-29T11:17:23.553089 - **Jana Kordt:**
> und <@U05LQB4GTC1> die autos sind auch in der SIXT Flotte, oder? Bei dem personality change

2026-01-29T11:18:02.088529 - **Marvin Hammerschmidt:**
> Ich hab Barbie, Rocker, naturverbundene und Student geschrieben

Die Autos sind auch in der Flotte
Die dinge Darunter würd ich nicht mit aufnehmen

2026-01-29T11:18:18.384409 - **Jana Kordt:**
> ok, also nicht den fiat5ßß?

2026-01-29T11:18:27.105999 - **Julia:**
> Fiat hab ich eh nicht erstellt

2026-01-29T11:18:35.798419 - **Jana Kordt:**
> von wem kam denn dann fiat?

2026-01-29T11:18:39.826089 - **Julia:**
> Marie

2026-01-29T11:18:43.418999 - **Jana Kordt:**
> ah okay

2026-01-29T11:19:11.628369 - **Julia:**
> Wie gesagt ich schick es dir asap alles zu. Glaube so macht es keinen Sinn die Sachen durchzugehen, da sich ja eh nochmal viel geändert hat :slightly_smiling_face:

2026-01-29T11:19:12.243549 - **Marvin Hammerschmidt:**
> Das Problem daran ist dass das alles mit deutscher Musik geschrieben ist
Das bringt halt nichts bei US Content
Meine vorschläge sind generischer

2026-01-29T11:19:36.350209 - **Jana Kordt:**
> ach, die ganzen ideen ändern sich noch?

2026-01-29T11:19:54.190379 - **Julia:**
> Ne aber wir können ja nicht alles umsetzen, daher ist jetzt immer nur eine Idee zB visualisiert

2026-01-29T11:19:58.685449 - **Julia:**
> siehst du dann gleich bei den Slides

2026-01-29T11:20:04.651989 - **Jana Kordt:**
> ok

2026-01-29T11:20:23.176059 - **Jana Kordt:**
> aber wir müssen bei der idee dem kunden schon 3 ideen vorstellen :slightly_smiling_face: - reicht ja als chatgpt bild

2026-01-29T12:44:55.802519 - **Jana Kordt:**
> Und? :) 

2026-01-29T12:50:05.586759 - **Julia:**
> Ich brauch noch ca. 15 min. Hab leider noch nicht alle Videos von Basti bekommen, aber hab markiert wo diese reinmüssen

2026-01-29T13:18:43.594919 - **Julia:**
> So there you go.
• Der Aufbau mit den Content Säulen ist analog Porsche damals – natürlich auf SIXT angepasst
• Formate sind alle visualisiert, weitere Beispiele sind dann dazu geschrieben, wir werden vieles mündlich erzählen
• Formate sind nach den Content Säulen sortiert
• Finale Videos laden hier rein: <https://drive.google.com/drive/folders/1aLCz7CZkdJOu_PQiBQh9GxUdMamSHJdt>
Besprechen wir dann alles im Termin mit Flo, oder?

  📎 260128_WORKSHOP_Formate_JH.pptx

2026-01-29T13:22:05.941129 - **Jana Kordt:**
> danke dir, ich geh es durch, füg es mit meinem zusammen und dann schicke ich es noch mal

2026-01-29T13:25:24.651919 - **Jana Kordt:**
> wir denken also nicht mehr in hero, entertainment, utility?

2026-01-29T13:27:11.873899 - **Jana Kordt:**
> und warum fangen wir mit concept 2 an=?

2026-01-29T13:27:21.921589 - **Jana Kordt:**
> warum ist die reihenfolge so?

2026-01-29T13:28:20.886389 - **Julia:**
> wie oben geschrieben, ist nach Säule sortiert. Die Headlines hab ich noch nicht angepasst, falls wir das nochmal umändern wollen. also Reihenfolge (1,2,3..) ist in dieser Version noch nicht final

2026-01-29T13:28:52.930899 - **Julia:**
> Woher kam das?
Können wir es verbinden, zusammenfügen?

2026-01-29T13:32:25.255349 - **Jana Kordt:**
> kann ich das einfach anpassen?

  📎 Screenshot 2026-01-29 at 14.28.49.png

2026-01-29T13:32:48.345689 - **Jana Kordt:**
> das kam von mir, aber schon in dem ersten workshop - das ist eine ganz normale IG-Content-Logikm

2026-01-29T13:35:27.660619 - **Jana Kordt:**
> <@U09D64LA420> "Dinge die man nicht sagen sollte" - hier sollten wir eine Carousel Ad erstellen - kannst du das machen?

2026-01-29T13:36:27.449179 - **Jana Kordt:**
> und was war mit den thumbnails?
Flo wollte das visualisiert haben

2026-01-29T13:37:09.297579 - **Julia:**
> Dinge die man nicht sagen sollte ist als GIF angescribbelt

2026-01-29T13:38:05.277459 - **Julia:**
> Was genau meinst du denn damit? Die Visuals sind im IG MockUp angelegt
Thumbnails für was?

2026-01-29T13:38:19.740089 - **Julia:**
> Dann lass es uns verbinden, oder? Passt doch super

2026-01-29T13:42:07.183649 - **Julia:**
> Videos von Basti sind fertig und liegen alle ab

2026-01-29T13:42:37.191829 - **Jana Kordt:**
> <@U09D64LA420>
Dinge die man nicht sagen sollte ist aber ein Carousel, kannst du bitte ein Carousel raus machen?

2026-01-29T13:43:13.306839 - **Jana Kordt:**
> Thumbnail für beispielsweise 2-3 serien, damit wir den wiedererkennungswert auf dem profil sehen können.

2026-01-29T13:45:36.210469 - **Julia:**
> ich versteh nicht ganz was du meinst. Ich habs als GIF animiert, damit man den Eindruck bekommt es ist ein Carousel Post. Den "Swipe" Effekt kann ich so schnell nicht umsetzen. Wenn der Aufwand nötig ist, kann ich es Basti geben.
Hier das GIF:
<https://drive.google.com/drive/folders/1aLCz7CZkdJOu_PQiBQh9GxUdMamSHJdt>

2026-01-29T13:46:59.755129 - **Julia:**
> Okay, Thumbnails bzw. Profilübersicht kann ich noch für morgen erstellen

2026-01-29T13:47:12.041039 - **Jana Kordt:**
> und bei love is blind sagt die stimme was anderes als auf dem chart steht

2026-01-29T13:47:38.377879 - **Jana Kordt:**
> <@U09D64LA420> WIr sollen einfach die verschiedenen Slides zeigen - das ist kein Video, sondern 4 Bilder nebeneinander -

2026-01-29T13:48:29.300269 - **Julia:**
> • bei LIB ist vor dem geschriebenen Dialog davor (...), wir hören den Anfangsteil im Video

2026-01-29T13:48:50.205019 - **Jana Kordt:**
> ok und bei things you shouldnt say?

2026-01-29T13:48:57.698819 - **Jana Kordt:**
> da sagt die stimme "things you shouldnt do"

2026-01-29T13:49:31.677319 - **Julia:**
> Ja weil das nur der Opener ist

2026-01-29T13:49:43.188849 - **Julia:**
> Der Rest wird ja nicht gesprochen, sondern nur gezeigt

2026-01-29T13:50:13.754249 - **Julia:**
> Also ich glaube es macht gerade wenig Sinn die Präsi so durchzugehen. Ich kann dir gerne alles in Ruhe erklären. Bzw. präsentieren Marvin und ich ja eh diesen Teil, daher ist uns klar was wir da sagen und zeigen

2026-01-29T13:50:54.452969 - **Julia:**
> Wenn du es umschreiben möchtest, dann mach das gerne. Aber jede einzelne Slide hier schriftlich erklären ist gerade nicht effizient bei dem Workload

2026-01-29T13:51:41.577539 - **Jana Kordt:**
> Ich frage nur, warum eine Diskrepanz herrrscht zwischen den Videos (und was in den Videos gesagt wird) und was auf den Sheets steht, aber ok, dann bis später.

2026-01-29T13:52:43.783379 - **Julia:**
> Ja, die Sachen sind ja teilweise nicht komplett umsetzbar in dieser kurzen Zeit und wir müssen vieles mündlich ergänzen. Oder eben als "weitere Varianten" vorstellen etc.

2026-01-29T13:55:36.942449 - **Julia:**
> ich weiß, dass es kein Video ist. Der Effekt mit "swipen", sollte durch das GIF erstellt werden.

Hier die einzelnen Slides als PNGs:
<https://drive.google.com/drive/folders/1aLCz7CZkdJOu_PQiBQh9GxUdMamSHJdt>

2026-01-29T14:06:18.187729 - **Jana Kordt:**
> easy, ich finde es einfacher zu sehen, wenn es einzelne slides/bilder sind, als ein gif

2026-01-29T14:30:41.042779 - **Jana Kordt:**
> soll ich die inspirationsvideos noch einfügen? oder nicht?

2026-02-06T11:15:40.760519 - **Jana Kordt:**
> Hey, wie sieht es mit den Carousels aus?

2026-02-06T11:16:26.435919 - **Marvin Hammerschmidt:**
> Sag ich gleich was zu


---

### julia.hallhuber, florian (114 messages, 36 from Julia)

**Participants:** julia.hallhuber, florian
**Folder:** `mpdm-julia.hallhuber--florian--julia.hopper-1`

2025-09-12T09:29:29.743009 - **Julia H.:**
> Unser carousel performer fast so gut wie das reel das mit Werbung gepusht wurde. Haben wir in Eigeninitiative gebastelt :heart_eyes:

  📎 File.jpg

2025-09-12T12:13:53.497179 - **Florian Listl:**
> MEGA geil JJs!!

2025-09-12T12:17:35.227899 - **Julia H.:**
> 

  📎 giphy-46.gif

2025-09-14T18:31:35.244389 - **Julia H.:**
> Hello Flo,

IAA Recap Reel ist freigegeben und in Sprinklr als Entwurf drin für morgen 15 Uhr.
• Uhrzeit wird Porsche noch festlegen
• Caption müssen sie noch freigeben 
• Thumbnail muss noch hinterlegt werden.
• VBW double check.
Die Story davor und danach hat Juli in Figma angelegt.

  📎 image.png

2025-09-15T09:23:45.084759 - **Florian Listl:**
> Checke ich gleich mal!

2025-09-17T10:42:42.147769 - **Julia:**
> Hello! Bin an den Stories für Gobi – soll ich euch die Drafts immer erstmal hier rein schicken oder wie ist hier der Prozess? :slightly_smiling_face:

• 2 Alternativen für den Start
• würde die Verlinkung direkt machen
• Umfragesticker wie gewünscht 
• habe die Texte leicht angepasst

  📎 Bildschirmfoto 2025-09-17 um 10.40.34.png
  📎 Bildschirmfoto 2025-09-17 um 10.40.48.png
  📎 Bildschirmfoto 2025-09-17 um 10.41.01.png

2025-09-17T11:24:02.411559 - **Julia:**
> Ausgetauscht mit Kofferbild

  📎 Bildschirmfoto 2025-09-17 um 11.23.46.png

2025-09-17T11:40:42.077419 - **Julia H.:**
> DAnke Juli!! Nur noch die Namen bei den Influs ergänzen. Denke sie wollen hier nicht offen taggen

2025-09-17T11:42:32.907169 - **Julia:**
> Ah okay, schade. Mach ich. Soll ichs dann in die Whatsapp Gruppe schicken oder legst du das direkt in Sprinkler rein?

2025-09-17T11:44:12.295199 - **Julia H.:**
> Whatsapp Group bitte, denke wir posten direkt dann händisch

2025-09-17T11:45:55.045709 - **Julia:**
> okay!

2025-09-17T13:50:56.176589 - **Julia:**
> <@UNUQV5R08> kannst du kurz helfen? Das ist nur der normale Cayenne, oder?

  📎 Bildschirmfoto 2025-09-17 um 13.50.40.png

2025-09-18T11:22:32.310069 - **Florian Listl:**
> <@U09D64LA420> ich hab dich hier auch mal eingeladen :slightly_smiling_face:

2025-09-18T11:22:36.298499 - **Florian Listl:**
> 

  📎 image.png

2025-09-18T11:25:53.953219 - **Julia:**
> Ja perfekt, danke

2025-09-18T16:53:50.693929 - **Julia:**
> Hilfe: ich weiß nicht, wo der Fehler ist aber bei jedem Ordner kommt diese Fehlermeldung...

  📎 Bildschirmfoto 2025-09-18 um 16.53.20.png

2025-09-18T17:00:03.791379 - **Julia H.:**
> Ja das hab ich auch manchmal

2025-09-18T17:00:07.387159 - **Julia H.:**
> Reload dann gehts wieder

2025-09-18T17:00:48.258939 - **Julia:**
> nee.. seit heute morgen. Flo vllt ist das auch ein Bug mit der Mailadresse? :smile:

2025-09-18T17:01:08.922049 - **Florian Listl:**
> nee ich hab das auch immer wieder

2025-09-18T17:01:20.317729 - **Florian Listl:**
> das ist weil sharepoint mega crappy ist

2025-09-18T17:01:21.606189 - **Florian Listl:**
> leider

2025-09-18T17:01:25.733089 - **Julia H.:**
> jap

2025-09-18T17:01:53.610639 - **Julia:**
> na toll, jedenfalls kann ich einfach nichts ablegen

2025-09-18T17:02:35.991179 - **Julia H.:**
> Madig... Auch wenn du realoadest? noch mal ein und ausloggen

2025-09-18T17:03:45.807979 - **Julia:**
> yes und yes

2025-09-18T17:08:23.417529 - **Julia H.:**
> Sonst sag bescheid, dann leg ich ab

2025-09-18T19:57:28.774169 - **Florian Listl:**
> Hi :slightly_smiling_face: Wir machen morgen full Brand Store Fokus. Dafür erstelle ich noch Slides.
Neben der Slide-Struktur brauchen wir die Daten.

Die kamen vom Brand Store Reporting immer direkt von *Sprinklr* (nicht Sprout), das geht ganz easy:
1. man geht auf das reporting icon auf der linken seite
2. dann auf den ordner "best practice reportings"
3. dann auf Instagram deep dive
4. dort wählt man oben bei "account" "porsche_brandstore" aus und oben die richtige Date range, z.B. Juni
5. Jetzt könnt ihr sehr detailliert die high-level metriken sehen, aber auch in die Details von Feedposts und Stories gehen durch die Buttons neben "overview" 

  📎 Reporting_Mai25 (2).pdf
  📎 image.png
  📎 image.png
  📎 image.png

2025-09-18T20:01:42.385299 - **Florian Listl:**
> Natürlich brauchen wir dazu noch etwas Text und Empfehlungen, aber das ist keine Rocket Science auf dem niveau auf dem der BS das will

  📎 image.png

2025-09-19T09:57:30.360579 - **Julia:**
> Guten Morgen! <@UNUQV5R08> ich hab heute Hunde Dienst und bin deshalb im HO geblieben :smiling_face_with_tear:

Mir ist mein To Do hier noch nicht ganz klar – wollen wir das gleich im Meeting kurz besprechen?

2025-09-19T09:57:51.765729 - **Florian Listl:**
> klar, ich muss kurz eine email fertig machen, dann lasst uns gern sprechen

2025-09-19T09:58:11.964089 - **Julia H.:**
> Haben wir das Reporting als PPT? sonst bau cih

2025-09-19T17:26:28.204409 - **Julia:**
> Hi ihr beiden! Finally jetzt die Ideen &amp; Konzepte für den Brand Store :slightly_smiling_face:

Die Präsi ist noch so aufgebaut wie die alte Präsentation von Roxanne. Punkt 2 ist allerdings von mir überarbeitet und angepasst. Der übersichtshalber hab ich mit "New ones" abgegrenzt, aber können wir dann gerne rausnehmen.
Ich bin noch nicht ganz durch, aber denke hier könnt ihr auf jeden Fall schon euren Input geben.
Was fehlt noch komplett? Was überzeugt nicht?

Offene To Do's die ich dann am Montag fertigstelle:
• teilweise fehlt mir noch Content für Beispiele oder die Visualisierungen (<@U08V6A47PKN> vielleicht kannst du mir hier etwas helfen?)
• Redaktionsplan + Rythmus
• Cayenne Content
• reicht das erstmal so als Basis oder muss es wirklich schon komplett ausformuliert sein mit Captions etc.?
<https://docs.google.com/presentation/d/1DADc4z0yjy8dCYPF1MWD77C4HpFJAGPC/edit?usp=drive_link&amp;ouid=113547910377163828129&amp;rtpof=true&amp;sd=true>

Danke und schönes Wochenende!

2025-09-19T17:30:58.086479 - **Florian Listl:**
> <@U09D64LA420> danke! Ich kommentiere direkt

2025-09-19T17:48:36.422229 - **Florian Listl:**
> 90% der Ideen sind richtig vielversprechend. Tolle Arbeit Juli!
Am Montag sortieren wir aus. Wir brauchen 2-3 Rockstar Ideen, rest kommt in die back slides. Sonst schalten die kunden ab

2025-09-22T09:45:50.475299 - **Florian Listl:**
> Kommt ihr ins Büro? :slightly_smiling_face: <@U08V6A47PKN> <@U09D64LA420>

2025-09-22T09:47:56.900419 - **Julia H.:**
> Yes, aber erst später :slightly_smiling_face:

2025-09-22T10:32:11.070449 - **Florian Listl:**
> <@U08V6A47PKN> <@U09D64LA420> ich würde uns für 17 Uhr einen schulterblick termin bei Hanna einbuchen, damit sie mal über die Ideen schauen kann, die Juli präsentiert. Und wir ggf. nach ihrem Feedback die Konzepte noch verfeinern.

Passt euch das?

2025-09-22T10:36:54.229729 - **Julia H.:**
> Wir haben von 16:30 bis 17:30 Gipfeltreffen PPM

2025-09-22T10:38:28.395129 - **Florian Listl:**
> verstehe, dann lieber 14:30?

2025-09-22T10:38:34.611949 - **Florian Listl:**
> Hanna kann bis 15 uhr

2025-09-22T10:38:37.917889 - **Florian Listl:**
> 15:30*

2025-09-22T10:38:56.684969 - **Julia H.:**
> Ja das passt

2025-09-22T10:39:00.757629 - **Julia:**
> ich auch etwas später!

2025-09-22T10:39:01.804329 - **Florian Listl:**
> okay, top!

2025-09-22T14:11:28.827279 - **Julia:**
> hab die Präsi für gleich überarbeitet

  📎 290922_Porsche_BS_SoMe_Konzepte_JH.pptx

2025-09-22T19:09:11.339719 - **Florian Listl:**
> 

  📎 202508_BrandStore_Reporting_August.pptx

2025-09-22T19:09:45.129619 - **Florian Listl:**
> <@U09D64LA420>

  📎 20250917_SIXT_BCC_Q3_2025.pdf

2025-09-24T17:30:22.331809 - **Julia:**
> Halloo, ich bin wieder „alive“.. ich hab glaub ich eben 18 Std. geschlafen. Fieber ist endlich runter und ich werde morgen wieder voll reinstarten! 
Tut mir Leid, dass ich plötzlich ausgefallen bin bei dem was gerade alles ansteht

2025-09-24T17:32:35.502799 - **Julia H.:**
> Arme juuuli, Gesundheit immer first! schön, dass es dir besser geht

2025-09-26T08:23:59.169669 - **Florian Listl:**
> Dem kann ich nur zustimmen - Gesundheit steht immer an erster Stelle :)

2025-09-30T09:20:58.437399 - **Julia:**
> Guten Morgen! Wollte nur Bescheid geben, dass ich morgen um 12.00 Uhr einen Arzt Termin hab und so gegen 11.30 los muss

2025-09-30T09:21:45.278729 - **Florian Listl:**
> Kein Problem!

2025-09-30T09:22:28.002599 - **Florian Listl:**
> lass uns gleich im Meeting auch das Thema Leonie Beck besprechen, weißt du was Charly für ein Problem mit der Storyline hat?

2025-09-30T09:25:59.180109 - **Julia:**
> Ne keine Ahnung. Ich hatte ihr letzte Woche wie besprochen das Reel geschickt – ich kannte auch nur das. Julia hat mir gestern dann gesagt, dass es eine Präsentation gibt mit einem Carousel, Captions usw. Das hatte mMn nicht mehr so 100% gepasst und wir haben es noch kurz angepasst, bevor es an Charly rausging, inklusive ein Thumbnail. In der Präsentation lagen noch halbfertige Stories, die aber nichtmehr zum Reel gepasst haben

2025-09-30T09:27:06.394259 - **Julia:**
> Ich kannte das Projekt außer das Video nicht, also kann ich gerne heute übernehmen – aber weiß natürlich nicht, was scheinbar vor Wochen besprochen wurde

2025-09-30T09:37:17.555289 - **Florian Listl:**
> okay, hast du fragen zu Charlys Feedback?

2025-09-30T09:40:52.118389 - **Julia:**
> Ja ich brauch natürlich die Infos zu Bildauswahl usw. Aber eigentlich hattest du das doch gestern noch extra angepasst <@U08V6A47PKN> ! Deswegen weiß ich nicht was ihr nicht passt 

2025-09-30T09:41:14.390849 - **Julia:**
> Vorallem weiß ich auch nicht wo der content dazu abliegt, habe nur die video snippets 

2025-09-30T09:55:55.168769 - **Florian Listl:**
> Sie wollen immer min. 50% Fahrzeugbilder, eher 2 drittel

2025-09-30T09:58:31.190799 - **Florian Listl:**
> und sie wollen eine stärkere Connection zu dem Christo Artikel - also ich kann das Feedback schon verstehen

  📎 CPM_Market_416_v07_20250724_gesamt.pdf

2025-09-30T09:58:38.343699 - **Florian Listl:**
> der Ton ist nicht gut

2025-09-30T09:59:08.912309 - **Julia H.:**
> Good morning
Yes genau! Die Bilder sind auch aus dem Artikel wobei wir sie glaub ich auch schon irgendwo haben. 

2025-09-30T09:59:14.347479 - **Florian Listl:**
> <@U08V6A47PKN> falls du's doch in den Call schaffst wäre es super, nicht dass Juli/ ich einen Blind Spot haben

2025-09-30T09:59:17.706549 - **Florian Listl:**
> geht auch nur via audio

2025-09-30T09:59:58.816749 - **Julia H.:**
> Bin grad mitten in der immigration

2025-09-30T10:00:02.542589 - **Julia H.:**
> Also leider nein

2025-09-30T10:00:06.921849 - **Julia H.:**
> Aber kann tippen 

2025-09-30T10:00:17.612379 - **Florian Listl:**
> okay

2025-09-30T10:01:07.329759 - **Julia:**
> ich komme wieder nicht in das meeting rein wegen teams

2025-09-30T10:02:06.693439 - **Florian Listl:**
> kannst du im browser teilnehmen?

2025-09-30T10:02:11.022469 - **Julia:**
> glaube es geht. warte, dass mich jemand reinlässt

2025-09-30T10:02:17.820099 - **Florian Listl:**
> ich auch :slightly_smiling_face:

2025-09-30T10:02:58.967729 - **Julia:**
> bin jetzt über die app. manchmal gehts so, manchmal so

2025-09-30T10:27:34.857209 - **Julia H.:**
> Sorry bin rausgeflogen 

2025-09-30T10:27:41.569159 - **Julia H.:**
> Komm gleich wieder rein wenn ihr mich braucht?

2025-09-30T10:27:52.916159 - **Florian Listl:**
> brauchen dich nicht :slightly_smiling_face:

2025-09-30T10:32:54.432389 - **Julia H.:**
> Ok top bin in 30 min daheim

2025-09-30T10:46:39.745339 - **Florian Listl:**
> FYI die Videos kann man nicht abspielen (auch nicht in der PPT), lasst uns schauen, dass wir das in Zukunft fixen

2025-09-30T10:46:50.363849 - **Florian Listl:**
> Charly war overall aber ziemlich happy mit Julias Posts :slightly_smiling_face:

2025-09-30T11:00:52.898329 - **Florian Listl:**
> <@U08V6A47PKN> kannst du aktuell community management machen? Charly ist da gerade recht picky (siehe Whatsapp) und du kennst Porsche am längsten

2025-09-30T11:05:45.610959 - **Julia H.:**
> Ich mach das cm aktuell….. Mert hat ja noch keinen Zugriff 

2025-09-30T13:22:06.112349 - **Julia:**
> Hallo! bitte einmal euer Feedback zu Leonie:

2025-09-30T13:23:24.181419 - **Julia:**
> • Caption Carousel neu
• Stories hinzugefügt
• Caption Reel neu

  📎 250930_CHRISTO X LEONIE BECK_SM ASSETS_JH.pptx

2025-09-30T13:25:06.331379 - **Julia:**
> <@UNUQV5R08> <@U08V6A47PKN> würde euch gerne vorher drüber schauen lassen, bevor ich es rausschicke. Danke!

2025-09-30T13:40:26.523429 - **Julia:**
> Feedback von Julia hab ich angepasst. Wording der Storyslides etwas knapper gehalten. <@UNUQV5R08> kannst du es auf Sharepoint laden? Ansonsten würde ich Charly jetzt das PDF davon schicken

  📎 250930_CHRISTO X LEONIE BECK_SM ASSETS_JH.pptx

2025-09-30T13:40:49.591669 - **Florian Listl:**
> sekunde :slightly_smiling_face:

2025-09-30T13:49:33.903759 - **Florian Listl:**
> finde ich gut - im Reel ist der Cayenne GTS nur mit den Werten mit Stand 09/2025 angegeben, sonst überall mit 10/2025

2025-09-30T13:50:25.533229 - **Julia:**
> oh okay. Dann sag ich Basti das kurz. Aber könnten wir ja auch evtl. nachträglich anpassen, oder meint ihr das fällt ihr direkt auf?

2025-09-30T13:50:31.581649 - **Florian Listl:**
> genau

2025-09-30T13:50:45.083569 - **Florian Listl:**
> du kannst es auch in die email schreiben, dass das gerade noch angepasst ist, aber das Konzept steht

2025-09-30T13:51:09.736469 - **Julia:**
> okay. also soll ich ihr antworten? ich kanns halt nur nicht in sharepoint ablegen

2025-09-30T13:51:24.736749 - **Florian Listl:**
> Hier ist der Sharepoint link <https://porsche.sharepoint.com/:p:/r/sites/PDMK/Shared%20Documents/General/UMZUG/Digitales%20Marketing/Social/Insta/08_Redaktionsplanung/Contents/2025/09_September/Christo_Leonie%20Beck/250930_CHRISTO%20X%20LEONIE%20BECK_SM%20ASSETS_JH.pptx?d=w7bdded1f44e94b6cb2287b372dcee960&amp;csf=1&amp;web=1&amp;e=fEA8cj|250930_CHRISTO X LEONIE BECK_SM ASSETS_JH.pptx>, die schrift ist angepasst

2025-09-30T13:59:33.295249 - **Julia:**
> habs ihr geschickt – komischerweise habe ich auf die Präsi jetzt wieder zugriff :smile:

2025-09-30T14:00:11.280909 - **Florian Listl:**
> Top, danke :)

2025-09-30T14:04:14.289329 - **Julia H.:**
> Nice danke Juli!

2025-09-30T14:08:14.039659 - **Julia:**
> Danke euch! 

2025-10-30T17:18:05.753879 - **Florian Listl:**
> hi :slightly_smiling_face: haben wir den Brand Store Report für Oktober schon? Hanna will den doch nicht, aber wenn wir ihn schon haben, stellen wir ihn natürlich in rechnung

2025-10-30T17:18:09.962319 - **Florian Listl:**
> <@U08V6A47PKN> <@U09D64LA420>

2025-10-31T10:07:33.059709 - **Julia:**
> Hello! Also wir haben bisher nur 2 Folien erstellt mit BP Posts und Low Performer, thats it – würde ich nicht unbedingt als Reporting bezeichnen

2025-10-31T10:07:43.113899 - **Florian Listl:**
> gut, dann skippen wir das

2025-11-12T17:20:12.976199 - **Florian Listl:**
> <@U09D64LA420> haben wir da was? Bzgl Hisense 

  📎 IMG_9262.png

2025-11-12T17:22:45.371399 - **Julia H.:**
> Ja haben wir. Wollten wir eigentlich heute vorstellen aber dann schicken wir es so rüber 

2025-11-12T17:23:15.836409 - **Florian Listl:**
> Ihr seid die besten!!

2025-11-12T17:23:20.056929 - **Florian Listl:**
> Top

2025-11-12T17:23:51.282239 - **Julia H.:**
> Super!! Mert schickt es, gerade mit ihm gesprochen, bin schon weg vom Laptop 

2025-11-13T09:04:09.610949 - **Julia:**
> Jaa genau :slightly_smiling_face: danke! :slightly_smiling_face:

2025-11-20T12:41:50.148249 - **Florian Listl:**
> Hey :slightly_smiling_face:
2 themen:
a) Wie weit sind wir mit der Verifizierung für den Blauen Haken? Was sind next steps?
b) Braucht ihr support? zb Community Mgmt? Wir haben mehr als genug Werkis für sowas

2025-11-20T13:13:07.170629 - **Julia:**
> Hi Flo! :slightly_smiling_face:
1. Da gibt es leider noch kein Update – also diese Prüfung läuft noch. Aber direkt eine Frage dazu: wir haben gestern mit Laureen den gorenje Account aufgesetzt. Sollen wir es hierfür auch direkt starten? Dann schreibe ich Marvin wie das genau geht.
2. An sich super gerne für CM – hier müssen wir noch einen Prozess aufsetzen bzw. hatten wir das hier ausarbeitet aber Hisense noch nicht vorgestellt. Das fällt ja in den Bereich und dafür müssen wir Do's &amp; Dont's gemeinsam mit dem Kunden festlegen. Können wir auf jeden Fall nächste Woche machen. Julia hat uns jetzt eine neue Meeting Struktur mit Hisense aufgestellt, damit wir eh mehr im Austausch sind 

  📎 Bildschirmfoto 2025-11-20 um 13.11.09.png
  📎 Bildschirmfoto 2025-11-20 um 13.11.06.png

2025-11-20T13:58:30.198049 - **Florian Listl:**
>  Ja Gorenje auch bitte, danke :)

2025-11-20T17:53:47.159459 - **Julia:**
> alles klar!

2026-02-16T16:31:21.070149 - **Florian Listl:**
> Hi ihr beiden :slightly_smiling_face: könnt ihr mir bis Mittwoch mittag sagen wie viele Stunden wir diesen Monat (von Anfang bis Ende)
a) in AoN
b) in Instagram Produktion bei SIXT stecken werden?

Darauf basierend müssen wir einen KVA für beides schicken

2026-02-16T16:31:43.343609 - **Florian Listl:**
> <@U09D64LA420> <@U08V6A47PKN>

bzgl b) - sprecht da gern auch mit Basti, der filmt ja und ggf mit Marvin

2026-02-16T17:44:29.923709 - **Julia:**
> Yes, sollten wir hinkriegen :slightly_smiling_face: Genau, dazu brauch ich Basti auf jeden fall


---

### marie (24 messages, 10 from Julia)

**Participants:** marie
**Folder:** `mpdm-julia.hopper--marie--anna-1`

2025-11-21T14:09:20.586109 - **Julia:**
> Hier unsere Gruppe! :slightly_smiling_face:

2025-11-21T14:35:27.130139 - **Marie Gottschall:**
> Bis 15:30 Uhr haben wir die Liste mit den Leading Beauty Brands und den Median Werten Likes/Post fertig. Bis ca. 16:15 müssten wir die SuperUser haben und bis 16:45 haben wir dann wahrscheinlich auch analysiert welche Formate für die Top 10 am besten performed haben :slightly_smiling_face:

2025-11-21T15:20:51.197099 - **Julia:**
> Wie gesagt, Screenshots + alles was ihr über die Super-Fans noch spannendes rausfinden könnt (arbeitet bei MAC oÄ), wäre super. Danke euch! :slightly_smiling_face:

2025-11-21T16:18:26.607899 - **Marie Gottschall:**
> Hier ist jetzt endlich die Liste mit den Median Werten <https://boldcreators-my.sharepoint.com/:x:/g/personal/marie_gottschall_boldcreatorsclub_com/ET4BSKx62fhMpiswGgNC9sEBDR16D0Kim2f3GmQsqcmgrQ?e=gs5SU2>

2025-11-21T16:18:50.384409 - **Marie Gottschall:**
> Sorry dass es so lange gedauert hat es ist super nervig, weil das immer so lange läd:sweat_smile:

2025-11-21T16:39:50.705219 - **Julia:**
> all good, danke schon mal!

2025-11-21T16:50:00.145539 - **Julia:**
> Sind das die Instagram oder TikTok Kanäle?

2025-11-21T17:24:52.251399 - **Marie Gottschall:**
> TikTok :slightly_smiling_face:

2025-11-21T17:24:56.100099 - **Marie Gottschall:**
> <https://docs.google.com/document/d/1t04tJSyVL0e2TAE2H277MDg7mhF4fi3uN5bBYDQCAgs/edit?usp=sharing>

2025-11-21T17:26:12.878329 - **Marie Gottschall:**
> Wir arbeiten gerade noch etwas dran aber das meiste haben wir schon. Bei Maccosmetics funktioniert Apify nicht so richtig deswegen müssen wir das die ganze Zeit neu laufen lassen aber wir versuchen unser bestes:sweat_smile:

2025-11-21T17:29:15.365199 - **Julia:**
> Ach super, das sieht doch schon mal gut aus

2025-11-21T17:29:40.573929 - **Julia:**
> alles gut, hab Flo schon Bescheid gegeben, dass es heute etwas knapp wird

2025-11-21T18:00:49.393049 - **Marie Gottschall:**
> Und hier auch noch die ganzen Excel Dateien mit den Daten:

2025-11-21T18:00:52.589839 - **Marie Gottschall:**
> <https://drive.google.com/drive/folders/1jxccnuQ8RY-et_z6thNXnixY-TvkHDio?usp=sharing>

2025-11-21T18:01:01.725849 - **Marie Gottschall:**
> <https://drive.google.com/drive/folders/16XoGvShB_HogZBtipVE7hw4oYY0vmrub?usp=drive_link>

2025-11-21T18:18:03.057989 - **Julia:**
> danke euch! :slightly_smiling_face: habt ein tolles Wochenende

2025-11-24T16:38:53.813569 - **Julia:**
> Hi! :slightly_smiling_face: Eine Frage: habt ihr zu ihr noch mehr Infos rausgefunden oder könntet da nochmal recherchieren? Amy kommentiert ja wirklich jede Marke, da wäre interessant was ihr Background ist

  📎 Bildschirmfoto 2025-11-24 um 16.38.04.png

2025-11-24T16:41:01.785039 - **Marie Gottschall:**
> ich kann mal ihren Feed durchschauen und Infos suchen :slightly_smiling_face:

2025-11-24T16:50:18.339419 - **Marie Gottschall:**
> Tatsächlich gibt sie garnichts von ihr privat preis sondern postet nur ca. 10 min lange MakeUp Tutorials:sweat_smile: Ich weiß nicht ob dir das so viel hilft

2025-11-24T16:54:07.070409 - **Julia:**
> haha okay. Sind da noch andere Marken außer "unsere" dabei?

2025-11-24T16:54:31.742109 - **Marie Gottschall:**
> Ja alle möglichen

2025-11-24T16:56:49.459649 - **Julia:**
> ah okay, also einfach krasser Beauty Fan

2025-12-05T18:16:49.905399 - **Anna Arndt:**
> Hallo Juli und Marie! Für die Lidl-Wohnwagen-Kampagne habe ich ganz viel rumtelefoniert und angefragt, allerdings gibt es einige Anbieter, die ich nicht erreicht habe und einige, die wir spezifisch am Montag nochmal fragen sollen. Ich schicke euch Listen durch, wäre super, wenn ihr da nochmal anrufen könntet!

1. Wohnwagen-Vermieter:
<https://roadsurfer.com/>
<https://camper.check24.de/wohnmobil-mieten/ci/deutschland/hamburg>
<https://www.reinschgmbh.de/autovermietung/wohnmobilvermietung/>

2. Parken
<https://elbecamp.de/>
<https://wohnmobilstellplatz-wedel.de/> *Montag nochmal probieren,* Fragen nach Herrn Niss (Badleitung) -&gt; eigentlich machen die das nicht aber ganz evtl. gibt es eine Chance wegen Sonderanfrage

3. Außenfolierung: Da kommen Angebote per Email rein, <@U09D64LA420> du bist im CC

4. Inneneinrichtung:
Habe die komischerweise alle nicht erreicht, bis auf einen, der meinte es würde gehen und er ruft zurück, hat sich aber noch nicht gemeldet: <https://hp-camper.de/>
Bitte nochmal fragen, ansonsten z.B. die hier:
(Noch) nicht erreicht
<https://vanme.de>
<https://solutionsfornomads.de/>
<https://www.freaksoffashion.com/>
<https://www.hamburger-holzschmiede.de/>

5. Genehmigung
Wir brauchen eine Genehmigung, um mit Wohnwagenkollonne durch die Stadt zu fahren
-&gt; anscheinend vom LVB, die kümmern sich wohl um Polizei etc.
-&gt; habe trotzdem alle möglichen Stellen angefragt (Stadt, Ämter, Polizei), wurde nur herum geschickt, niemand ist verantwortlich anscheinend hahah,
folgende Nummer wurde mir jetzt für Montag gegeben:
040 428582492 (Sonderggenehmigungsstelle des LVB, 9-13 Uhr erreichbar)

2025-12-05T18:20:13.219329 - **Anna Arndt:**
> So, Schluss mit dem langen Text, wäre super, wenn ihr da nochmal anfragen könntet. <@U09TJSTN85B>, Juli kann dir sowieso nochmal genauer sagen worum es geht, ich habe am Telefon bisher immer gesagt ich bin von BCC, wir brauchen/haben für ein Kundenprojekt Anfang Mai 2026 in Hamburg 40-50 Wohnwägen und brauchen dafür Branding außen/innen/Parkplätze/Genehmigung etc.
Sie sollen gerne sagen, ob das möglich ist und was wir beachten müssen, Preisvorschläge machen etc.


---

### marvin (65 messages, 16 from Julia)

**Participants:** marvin
**Folder:** `mpdm-julia.hopper--marvin--florian-1`

2026-01-15T13:10:42.138929 - **Julia:**
> Hi, hab erste Format Ideen für SIXT hier gesammelt:
<https://docs.google.com/document/d/1fI3JcT0WHICFJ_oo6li7B8t22ezx9aWenC8AeXIjVSo/edit?tab=t.0>

Lasst mich gern wissen, ob's in die richtige Richtung geht!

2026-01-15T13:11:25.329619 - **Marvin Hammerschmidt:**
> Super Danke
Ich schaue sofort drüber

2026-01-15T13:18:55.963139 - **Marvin Hammerschmidt:**
> 1 &amp; 2 und ich super, haben wir ja schon darüber gesprochen. Müssen nur schauen, wie wir Idee 1 mit engem Budget, relativ echt, umsetzen.

Idee 3 hatte ich vor ’nem Jahr schon mal, ich weiß nicht, warum wir es nicht gemacht haben.  Das Ding ist, da wir international sein müssen, müsste das in den USA stattfinden und wäre auch dementsprechend teuer. Ich gebe dir auch recht, dass der Interviewer essenziell wichtig ist. Auch das ist in den USA zumindest mal eine Herausforderung.

Idee 4 hatten wir auch schon mal als Vorschlag und haben es dann nicht finalisiert.  Wenn wir das noch einmal vorschlagen, müssen wir präziser sein und zumindest mal ein Beispielskript vorlegen.

Idee 5 finde ich richtig witzig. So in Richtung Kesslers Knigge  <https://www.youtube.com/watch?v=DM2lML7IbCc>. Müssen nur auch hier aufpassen, dass wir keine negativen Aktionen triggern. Der Kunde möchte nicht selbstironisch sein und auch kein Rasen oder Zerstören von Autos promoten etc.

Idee 6 von der Grundidee gut, da der Fokus aber auf International und vor allem US liegt, wieder etwas schwerer umzusetzen.

2026-01-15T15:42:04.590719 - **Julia:**
> Danke für deine Einschätzung und das Feedback!
Das international Thema war mir noch nicht ganz klar, aber macht jetzt natürlich Sinn.
Ich denke Idee 3 wäre dann wirklich nur in den USA dann umsetzbar oder mit jemanden der in DE &amp; USA bekannt ist (so viele gibts da nicht..)
Idee 6 könnte man trotzdem machen aber dann DE + USA oder DE + ESP – Fokus einfach auf die internationalen Unterschiede, was ja auch super witzig sein kann

2026-01-15T15:42:32.137569 - **Marvin Hammerschmidt:**
> Fairerweise ist das mit dem Internationalen auch sehr schwammig aber ist schon highly prefered

2026-01-15T15:42:49.452779 - **Marvin Hammerschmidt:**
> ja, geh ich mit

2026-01-27T12:27:12.789909 - **Julia:**
> Just FYI: Higgsfield ist mit Nana Banana Pro heute fast nicht benutzbar. Habs jetzt paar mal versucht aber wird immer abgebrochen. Die anderen Tools sind einfach im Vergleich nicht gut genug. Heißt also: wird alles etwas länger dauern

  📎 Bildschirmfoto 2026-01-27 um 12.24.59.png

2026-01-27T12:27:51.662569 - **Florian Listl:**
> oh mann :disappointed: Das haben die Peruaner auch schon mal gesagt, dass Nano Banana bei HF nicht gut lief

2026-01-27T12:28:46.993429 - **Julia:**
> ja sehr ärgerlich, ich probiers weiter

2026-01-27T13:08:42.869859 - **Florian Listl:**
> Hi ihr beiden :slightly_smiling_face:

<@U09D64LA420> lass uns beide vor Ort hinkommen, dementsprechend sollte Juli auch zumindest ihre Ideen vorstellen, ggf sogar etwas mehr

So zeigen wir Präsenz und Juli kann alle kennenlernen :slightly_smiling_face:

  📎 image.png

2026-01-27T17:09:16.813689 - **Julia:**
> also das klappt heute wirklich garnicht – vllt Love is Blind mit 2 Autos und sie muss sich entscheiden? :smile:

  📎 Bildschirmfoto 2026-01-27 um 17.08.20.png

2026-01-27T17:09:48.598069 - **Julia:**
> können wir gerne vor Ort machen. ich denke wir teilen es dann je nach Idee auf oder? <@U05LQB4GTC1> :slightly_smiling_face:
Bzw. hat Marvin ja auch nochmal mehr Gespür was sie dann anfechten, anzweifeln etc.

2026-01-27T17:10:03.994589 - **Florian Listl:**
> Is fair! Und eine Werkstudentin macht ein Video aus Sicht der Frau 

2026-01-27T17:10:36.723199 - **Marvin Hammerschmidt:**
> Können wir sie denn in der post production in so eine kabine setzen?

2026-01-27T17:10:42.166579 - **Florian Listl:**
> Genau, besprecht das gern unter euch, ich komme vor allem für smalltalk mit 

2026-01-27T17:11:36.630359 - **Florian Listl:**
> Das weiß Basti besser als ich, aber wir haben ja sogar so ein Sofa wie es in den Pods ist, dann müsste man nur den Hintergrund anpassen

  📎 IMG_9976.jpg

2026-01-27T17:11:57.855949 - **Marvin Hammerschmidt:**
> Wenns billig und nicht nah am original aussieht macht so ein video mehr kaputt als es hilft

2026-01-27T17:12:07.031619 - **Marvin Hammerschmidt:**
> spreche mit basti

2026-01-27T17:12:45.259059 - **Florian Listl:**
> Ja, also das muss jetzt noch kein finales Video sein mmn, draft-Status reicht. Je besser es aussieht desto cooler natürlich 

2026-01-27T17:12:57.387079 - **Florian Listl:**
> Aber es geht vor allem darum, dass man sich das Video Konzept vorstellen kann

2026-01-27T17:13:30.248429 - **Julia:**
> Neee ich meinte das als Witz :smile: ich probier es weiter, aber die Ausgabe ist heute einfach nicht gut. Hatte auch schon ein Video bei dem die Frau spricht, aber es klappt nicht so wie es sein soll

2026-01-27T17:13:48.697079 - **Julia:**
> Und Jana stellt es aber generell vor, oder?

2026-01-27T17:15:07.785169 - **Florian Listl:**
> Ich würde es euch überlassen, wer was vorstellt. Aber von den Kompetenzen her sollte es so sein:
Jana macht den Anfang und den reporting Teil von Paid Ads.
Alles was Ideen und Konzepte sind, sollte von euch kommen. Der letzte Teil mit Thumbnails und co kann wieder von Jana kommen

2026-01-27T17:15:33.621629 - **Florian Listl:**
> Jana hat keine kreative Authority, deshalb wäre es nicht gut, wenn sie kreative Konzepte vorstellt

2026-01-27T17:16:24.020709 - **Marvin Hammerschmidt:**
> Wir setzten zu 3. einen call auf wenn die präsi fertig ist und stimmen das ab

2026-01-27T17:16:29.599869 - **Marvin Hammerschmidt:**
> würde jana möglichst wenig geben

2026-01-27T17:16:40.089759 - **Florian Listl:**
> Agee!

2026-01-27T17:16:57.873429 - **Marvin Hammerschmidt:**
> Und Juli möglichst viel auch um sie als Insta experten besser zu positionieren

2026-01-27T17:17:13.121309 - **Marvin Hammerschmidt:**
> Wenn sie denken da ist viel von mir ist das für sie auch weniger dieses "frischer wind" gefühl

2026-01-27T17:17:13.456719 - **Florian Listl:**
> Agree :) ausserdem sind wir vor Ort

2026-01-28T11:37:17.838399 - **Florian Listl:**
> Hey :slightly_smiling_face: Ich würde uns für Februar/ März noch eine Werkstudentin organisieren, die *nur* SIXT macht, damit wir die Stunden von Marvin besser auffangen

2026-01-28T11:37:36.581479 - **Florian Listl:**
> Recherche, Trends, ggf Support bei Kamera

2026-01-28T12:34:26.536489 - **Julia:**
> Hello! Unterstützung ist schon mal super! Evtl. könnten wir zu 3. einmal sprechen? Ehrlicherweise ist mein Gefühl es braucht jemand anderen als eine Werkstudentin

2026-01-28T12:45:56.707699 - **Julia:**
> Wann habt ihr zeit?

2026-01-28T12:46:21.828909 - **Marvin Hammerschmidt:**
> Bis zum Lao Meeting um 14:30 bin ich flexibel

2026-01-28T12:49:51.029079 - **Florian Listl:**
> Lass uns 14 uhr machen

2026-01-28T14:01:32.872809 - **Julia:**
> bin in 1 min da

2026-01-28T14:21:32.288879 - **Florian Listl:**
> 

  📎 WORKSHOP 2.0 - v1 JK.pptx

2026-01-29T15:54:41.331649 - **Julia:**
> FIY: Marvin und ich haben Jana den Content Teil geschickt, den Rest den Präsi kennen wir auch noch nicht. Je nachdem können wir es gut präsentieren oder eben nicht

2026-01-29T15:59:30.150009 - **Florian Listl:**
> okay, habt ihr geklärt, wer was macht?

2026-01-29T16:00:03.973859 - **Marvin Hammerschmidt:**
> Super schwer ohne die aktuelle Präsi zu kennen
Aber ja im groben schon

2026-01-29T16:00:18.101599 - **Julia:**
> unseren Teil jetzt, ja

2026-01-30T10:30:32.624359 - **Florian Listl:**
> Hi Leute :slightly_smiling_face:
lasst uns heute nachmittag nochmal alle zusammen den gesamten Pitch durchgehen, inklusive Alex

2026-01-30T10:30:40.719429 - **Florian Listl:**
> Termin hab ich uns eingestellt

2026-01-30T10:31:17.350579 - **Marvin Hammerschmidt:**
> Wir hatten diese Woche wirklich keinerlei Zeit dadran zu arbeiten

2026-01-30T10:31:31.953679 - **Florian Listl:**
> es geht um decathlon

2026-01-30T10:31:32.274239 - **Julia:**
> Hello! Ne, null leider

2026-01-30T10:31:40.591219 - **Florian Listl:**
> da ist doch schon alles fertig?

2026-01-30T10:31:44.131249 - **Marvin Hammerschmidt:**
> Könnten wir das bitte am Montag machen
Ich brauche das Wochenende dafür

2026-01-30T10:31:45.997269 - **Florian Listl:**
> und der ist am Dienstag

2026-01-30T10:32:25.602399 - **Julia:**
> Geht eher darum, dass wir bisher noch nicht üben konnten. Oder <@U05LQB4GTC1> das meinst du?
Also ich hab mich noch keine Sekunde mehr damit befasst

2026-01-30T10:32:30.805179 - **Marvin Hammerschmidt:**
> Genau

2026-01-30T10:33:04.920249 - **Florian Listl:**
> nein, lasst es uns heute machen - ihr müsst es euch nur 2-3 mal durchlesen dann klappt das.

So haben wir den Vorteil, dass ihr mit dem Feedback von heute ins Wochenende gehen könnt und wir ggf am montag nochmal sprechen können

2026-01-30T10:33:46.733269 - **Florian Listl:**
> de facto müsst ihr das was ihr gesagt habt nur etwas anders betonen

2026-01-30T10:35:37.814589 - **Florian Listl:**
> hier mal als inspo, das war ein aufgenommener pitch für LIDL <https://drive.google.com/file/d/1Am8tevScRNp03MmmD274Jaua9uboLZU1/view?usp=sharing>

aber für heute reicht es, wenn ihr's euch 2-3 mal durchlest. das sind ja nur 3 Slides oder so pro Person

  📎 Lidl Talkability 2026 Pitch.mp4

2026-01-30T10:40:56.912449 - **Julia:**
> es macht 100% Sinn, das nochmal zusammen durchzugehen, keine Frage! Das Timing ist einfach super schwierig für heute auch noch.
Marvin und ich sind einfach grad gedanklich SO tief in allen anderen Themen und am abarbeiten – correct me if I'm wrong. Ich persönlich springe von SIXT zu Hisense/ Gorenje, zu Mini und dann noch Decathlon. Ich persönlich kann nicht am Tag für 4 Kunden arbeiten um dann bei allen abliefern

2026-01-30T10:46:24.070889 - **Florian Listl:**
> Verstehe ich, dann schaut, dass ihr andere Sachen depriorisiert.
Das ist euer erster Pitch, bei so einem Pitch geht es um viel.

Wir können das nicht am letzten Tag proben leider.

Wenn da etwas noch nicht passt, dann habt ihr keine Zeit das anzupassen.

Wir gesagt, schaut es euch 2-3 mal an, das reicht für heute. Am Montag können wir nochmal sprechen

2026-01-30T11:11:28.568199 - **Florian Listl:**
> Um den Druck etwas rauszunehmen - lasst uns heute syncen, damit wir wissen was status quo ist, last rehearsal Montag 12-13 Uhr

2026-01-30T11:11:47.604059 - **Florian Listl:**
> habe ich euch eingestellt

2026-02-02T12:02:19.932969 - **Florian Listl:**
> Bin in 60 sek da :partying_face:

2026-02-03T21:07:12.237209 - **Florian Listl:**
> <https://x.com/infoluencer/status/2018673945793241454>

:joy: IBES überall aktuell

2026-02-03T21:07:36.314229 - **Florian Listl:**
> <@U05LQB4GTC1> Juli hatte ne coole Idee - glaube das könnte bei SIXT gut klappen als tagesaktuell

2026-02-03T21:08:02.209309 - **Marvin Hammerschmidt:**
> Ja ist Crazy aktuell 




2026-02-03T21:08:13.540589 - **Marvin Hammerschmidt:**
> Sprechen wir morgen Mittag zusammen mit allen anderen Themen drüber :sweat_smile:

2026-02-05T07:20:31.868039 - **Florian Listl:**
> Kling 3.0 kam gestern raus (auch bei Higgsfield) <https://x.com/PJaccetturo/status/2019072637192843463/mediaViewer?currentTweet=2019072637192843463&amp;currentTweetUser=PJaccetturo|https://x.com/PJaccetturo/status/2019072637192843463/mediaViewer?currentTweet=2019072637192843463&amp;currentTweetUser=PJaccetturo>

Sieht sehr realistisch aus, auch was character consistency angeht.

Das gibt uns neue Möglichkeiten, aber wir sollten im Kopf haben dass selbst ein pro wie der creator für 1:15 min 2 Tage gebraucht hat.

Das ist immer noch viel günstiger und schneller als wenn man das drehen müsste, aber es geht nicht in 15 min so wie manche Kunden sich das vielleicht vorstellen :sweat_smile:


---

### mert (2 messages, 1 from Julia)

**Participants:** mert
**Folder:** `mpdm-julia.hopper--mert--anna-1`

2025-11-28T09:33:03.069849 - **Julia:**
> Hi zusammen :slightly_smiling_face: Hier ein kurzer Connect – Anna kann uns heute bei Hisense/ Gorenje unterstützen! Am besten besprecht ihr euch einmal kurz was die offenen To-Do's sind (Stichwort Creator Suche). Dankee!

2025-11-28T09:35:59.886849 - **Mert Koc:**
> Hallo Anna :slightly_smiling_face:
Ich schaue mal kurz, wo du mir helfen kannst und melde mich gleich


---

### mert, florian, marvin (1 messages, 1 from Julia)

**Participants:** mert, florian, marvin
**Folder:** `mpdm-julia.hopper--mert--florian--marvin--jose-1`

2025-12-23T16:55:53.446569 - **Julia:**
> Hi guys! Sorry my internet just crashed and I’m looking for a new spot :pray:


---

### mert, julia.hallhuber (106 messages, 9 from Julia)

**Participants:** mert, julia.hallhuber
**Folder:** `mpdm-mert--julia.hallhuber--julia.hopper--laetitia-1`

2025-09-08T17:20:25.625679 - **Mert Koc:**
> Die Mail kam gerade von Emmy aber bei mir wird es richtig angezeigt auf IG...

  📎 image.png

2025-09-08T17:20:48.751029 - **Mert Koc:**
> Kann jemand auch noch schauen, was sie meint ? Evtl. hat sie einen Anzeigebug oder ich versteh es nicht!

2025-09-08T17:25:41.993419 - **Mert Koc:**
> OK, jetzt versteh ich was sie meint!
Das Story Highlight im Profil passt nicht.
Da müsste jemand von euch mit IG Zugang das bitte richtig und in der richtigen Reihenfolge rein posten!
<@U093J763E5A> maybe you ? :grin:

  📎 image.png

2025-09-08T17:26:44.262329 - **laetitia:**
> yes klar mach ich! 

2025-09-18T11:43:47.490469 - **laetitia:**
> Mert hat ja morgen viel zu tun, und Basti ist auch noch im Urlaub oder? <@U08V6A47PKN> Vielleicht können wir kurz priorisieren, weil das Anlieferungsreel muss ja dann morgen noch geschnitten werden. Wenn Mert zu viel aufm Tisch hat kann ich Julien fragen, ob er es direkt schneiden kann, aber dann muss ich ihm einen ganzen Tagessatz geben und nicht nur einen halben. Müsst ihr sagen wie es am besten für euch passt!

2025-09-18T11:45:26.524389 - **Julia H.:**
> <@U093J779DAQ> das Thema hätte im Grunde Prio vor den anderen würde ich sagen.

2025-09-18T11:45:53.602699 - **Julia H.:**
> Falls du sagst du schaffst das zeitlich nicht, musst du <@U093J763E5A> das mit Flo klären, weil das ein Budget Thema ist

2025-09-18T11:47:19.962339 - **Mert Koc:**
> Hat der Julien schon mal so ein Video geschnitten für uns? <@U093J763E5A>

2025-09-18T11:47:58.247419 - **laetitia:**
> Ja die beiden vom Roadtrip

2025-09-18T11:48:27.111939 - **laetitia:**
> aber ich weiß nicht, ob er das schafft zeitlich weil er Nachmittags einen anderen Dreh hat

2025-09-18T11:48:42.448569 - **laetitia:**
> fragen kann ich aber wenn du es nicht schaffst

2025-09-18T11:50:03.853469 - **Julia H.:**
> Ist vor allem eine Budgetfrage

2025-09-18T11:50:18.652049 - **laetitia:**
> ja das auch

2025-09-18T11:51:51.522229 - **Mert Koc:**
> Ich werds natürlich schneiden, wir haben ja keine andere Möglichkeit sonst. Ich kann das zeitlich nicht so gut einschätzen tbh.
Wir bekommen das Material ja erst um Mittag und dann soll das bis Abend raus. Aber wird schon irgendwie

2025-09-18T12:38:49.097419 - **laetitia:**
> Update Sommerfest Konzept hier: <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7B4D6C66A4-616A-40AD-AF31-A368ECCF5E4B%7D&amp;file=250908_Porsche_BS_Sommerfest.pptx&amp;action=edit&amp;mobileredirect=true&amp;previoussessionid=f4ef33a1-14c3-a230-5bf2-25a1e534cdcf|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7B4D6C66[…]ue&amp;previoussessionid=f4ef33a1-14c3-a230-5bf2-25a1e534cdcf>

Habe noch für Freitag das Anlieferungsreel + Storyankündigung hinzugefügt, Posting Timeline erstellt, Hannas Feedback eingebaut und eine Shotlist erstellt.

2025-09-18T12:39:43.494609 - **laetitia:**
> Dieses Video soll auf S. 5 als Beispiel Video. Kann es nicht reinladen, kann es jemand von euch mal probieren pls?

  📎 ScreenRecording_09-18-2025 11-29-02_1.mov

2025-09-18T12:42:42.328199 - **laetitia:**
> <@U093J779DAQ> schickst du mir einen Link wo du die Videos haben willst morgen und in was für einem Format etc.?

2025-09-18T12:53:10.818229 - **Julia H.:**
> Super, danke dir!! Magst du bitte direkt noch die fehlenden Sachen in den BS Redaktionsplan eintragen?

2025-09-18T12:55:37.505539 - **Julia:**
> Könntet ihr mir darauf Zugriff geben? :slightly_smiling_face:

2025-09-18T12:56:22.966139 - **Mert Koc:**
> Gerne in die zwei Ordner hier: <https://drive.google.com/drive/folders/1QYGRlBYvI6NJN4UGBSfOiAVBR-R2Wrr3?usp=drive_link>
Einmal Raw für Video und einmal für Fotos. *Bei den Fotos BITTE NICHT Raw.* Das ist voll unnötig für Instagram und viel zu Zeitaufwändig! Ganz wichtig sagen bitte!!!
Auch wichtig, genug Material vertikal zu shooten für IG. Ich weiß nicht, wie Basti das immer gebrieft hat aber einfach daran orientieren. Nur kein Raw bei Fotos!

2025-09-18T12:59:52.362309 - **Julia H.:**
> Eventuell muss das Hanna machen… schreib ihr mal auf Teams 

2025-09-18T13:00:33.428199 - **laetitia:**
> Ja Fotos vielleicht sogar am besten einfach gleich in Picdrop? Finde ich irgendwie am sinnvollsten, dann kann Porsche da direkt flaggen und wir haben auch ne bessere Übersicht für die Auswahl

2025-09-18T13:01:15.971699 - **laetitia:**
> yes trage das noch in den Redaktionsplan ein

2025-09-18T13:01:27.956999 - **Mert Koc:**
> Ja er soll aufjedenfall schon eine Vorauswahl treffen und keine Raws hochladen, das erspart uns sehr viel

2025-09-18T13:01:34.323399 - **laetitia:**
> ja voll!

2025-09-18T13:04:49.822409 - **laetitia:**
> Hat sich der Picdrop Code geändert <@U08V6A47PKN>? komme mit dem der in asana steht nichtmehr rein

2025-09-18T13:07:02.603929 - **Julia H.:**
> Eigentlich nicht 
<https://www.picdrop.com/porsche-deutschland|https://www.picdrop.com/porsche-deutschland>

2025-09-18T13:08:01.913079 - **Julia H.:**
> kd79us

2025-09-18T13:08:35.205649 - **Julia H.:**
> Geht das?

2025-09-18T13:17:42.442119 - **laetitia:**
> jaaa das geht

2025-09-18T13:17:43.361689 - **laetitia:**
> danke

2025-09-18T13:18:03.091859 - **laetitia:**
> hab das mal in Asana rein

2025-09-18T16:04:19.635699 - **Julia:**
> Hello <@U093J763E5A>! :slightly_smiling_face: Hab nun auch Zugriff. Ging die Präsentation schon an Prosche raus?
Mir ist aufgefallen, dass wir teilweise unterschiedliche Typo auf den Slides haben und die Textblöcke springen (Slide 7,8,9).  Außerdem wäre es super, wenn wir Bilder/ Beispiele immer ungefähr auf der gleichen Höhe ablegen.
Könntest du das ganzheitlich noch anlegen?  Dankee dir

  📎 Bildschirmfoto 2025-09-18 um 15.59.06.png

2025-09-18T16:17:57.692919 - **Julia H.:**
> Schaffen wir es, das alles in der nächsten halben Stunde an Hanna zu schicken? Auch noch Retro Sunday?

2025-09-18T16:18:06.984769 - **Julia H.:**
> Sonst wird sie keine zeit mehr haben zu feedbacken

2025-09-18T16:19:27.435649 - **Mert Koc:**
> das mit der Schrift ist oft ein Sharepoint Fehler leider. Bei mir lädt die manchmal auch nicht aber dann plötzlich irgendwann schon.

2025-09-18T16:21:09.295069 - **Julia H.:**
> Ja same....

2025-09-18T16:21:19.408749 - **Julia H.:**
> Wir lieben den Sharepoint

2025-09-18T16:22:45.006899 - **Julia:**
> retro sunday liegt ab!

2025-09-18T16:23:08.797479 - **laetitia:**
> yes auch die Kästen etc. schieben sich leider immer wieder wenn man es hochläd. Hab jetzt direkt in Sharepoint weiter gearbeitet also Hanna hat alle Updates. Hab ihr auch Bescheid gegeben

2025-09-18T16:23:33.742399 - **laetitia:**
> Habe Hanna schon Bescheid gegeben, dass die Präsi geupdatet ist aber noch keine Rückmeldung

2025-09-18T16:53:31.973719 - **Julia H.:**
> Bitte immer in CC nehmen, damit wir bescheid wissen

2025-09-18T17:29:42.542059 - **Mert Koc:**
> Ich wäre out für heute :grin::sunny: spazieren gehen und Sonne genießen

2025-09-18T17:29:49.288919 - **Mert Koc:**
> Außer ihr braucht mich noch

2025-09-18T17:38:46.148729 - **Julia:**
> Danke diiir :heart: happy feierabend

2025-09-19T09:29:56.869419 - **laetitia:**
> die Fragen ob wir das Video verwenden wollen. Was denkt ihr? Gibt ed inzwischen einen UGC Prozess?

  📎 ScreenRecording_09-19-2025 09-28-44_1.MP4

2025-09-19T09:36:34.106039 - **Mert Koc:**
> Ist das echt oder ?

2025-09-19T09:40:06.145289 - **laetitia:**
> kp tbh 

2025-09-19T09:40:09.832839 - **laetitia:**
> Thank you very much and I'm glad you liked it. :blush:

I uploaded the video for you in original quality, of course it's two videos. The music and video are made exclusively. It's a joint work of Dima and me. We are happy to be with you.

<https://drive.google.com/file/d/1z-FPn7t-LQCH0iQqESJRM99WaDoDSWdU/view?usp=drivesdk|https://drive.google.com/file/d/1z-FPn7t-LQCH0iQqESJRM99WaDoDSWdU/view?usp=drivesdk>

<https://drive.google.com/file/d/1yxoDjpHrByryKsK-jrdLHJQro98bx_He/view?usp=drivesdk|https://drive.google.com/file/d/1yxoDjpHrByryKsK-jrdLHJQro98bx_He/view?usp=drivesdk>

2025-09-19T09:40:13.673119 - **laetitia:**
> das war seine nachricht

2025-09-19T09:46:10.263549 - **Mert Koc:**
> Das liegt irgendwo, wo ich keinen Zugriff habe :thinking_face:

2025-09-19T09:54:56.185829 - **Julia H.:**
> Ne uns schicken ja viele leute ihren Content. Wäre jetzt nicht sicher für was wir das verwenden sollten. Ist halt auch ein altes Modelll... Könnte man mal in die UGC Liste aufnehmen

2025-09-19T10:12:52.688019 - **Julia:**
> das ist ja wirklich so dämlich gemacht :smile:

Aber dann lasst uns gerne in Zukunft nur noch PDFs an Porsche schicken bzw. präsentieren? Der Kunde sollte dieses Typo-Chaos nicht zu sehen bekommen

2025-09-19T10:14:11.196699 - **laetitia:**
> Das versuchen wir schon die ganze Zeit. Dürfen wir das inzwischen? <@U08V6A47PKN> 

2025-09-19T10:24:10.866769 - **Julia H.:**
> Wir müssen einen sinnvollen Vorschlag machen. Flo will PPT's ich sehe auch nur PDF eigentlich und Porsche soll kommentieren

2025-09-19T13:11:18.467899 - **laetitia:**
> <@U08V6A47PKN> <@U09D64LA420> habe die vorläufigen Captions in die Präsentation gepackt und Fact check ist auch durch. Habe die links immer unter die jeweiligen Posts gepackt und ansonsten einen Kommentar hinterlassen. 
<@U093J779DAQ> Video &amp; Foto upload für den Targa hat gestartet, also gerne im Blick behalten und dann direkt starten

2025-09-19T13:11:45.632939 - **laetitia:**
> Die Fotoauswahl schaue ich durch, also Prio hat erstmal das Video <@U093J779DAQ> 

2025-09-19T13:16:00.845139 - **Julia H.:**
> Super, vielen Dank! Sind die Fotos schon da?

2025-09-19T13:26:25.514549 - **laetitia:**
> ne noch nicht

2025-09-19T13:27:21.263339 - **laetitia:**
> läd grade noch

2025-09-19T13:28:28.389209 - **Julia:**
> cool danke! :slightly_smiling_face: komme heute noch nicht dazu mir die anzugucken aber am montag dann direkt!

2025-09-19T13:39:58.040109 - **Mert Koc:**
> <@U093J763E5A>
kannst du mir Bescheid geben, wenn alle Videos online sind? Weil das weiß ich ja nicht, ob noch was hochlädt oder nicht.

2025-09-19T13:41:09.194349 - **laetitia:**
> ja genau gebe dir bescheid

2025-09-19T14:01:29.790019 - **laetitia:**
> fotos sind online 

2025-09-19T14:24:21.387399 - **Julia H.:**
> Wer hat diesmal die Fotos gemacht?

2025-09-19T14:24:41.169129 - **Julia H.:**
> Finde man sollte auch die unbearbeiteten bereinigen

2025-09-19T14:25:59.990709 - **Julia H.:**
> <@U093J763E5A> hast du schon  grün selektiert?

2025-09-19T14:42:57.248499 - **laetitia:**
> ja für die Story von heute für Mert

2025-09-19T14:44:00.021379 - **Julia H.:**
> Okay. Finde die Bildauswahl nicht ganz so stark <@U09D64LA420> magst du auch einmal drauf schauen bitte? <@U093J779DAQ> Bis wann denkst du, hast du was zum zeigen?

2025-09-19T14:44:11.206739 - **Julia H.:**
> Haben wir schon Reel Material bekommen?

2025-09-19T14:56:08.005809 - **laetitia:**
> okay, wir brauchen halt was wo am besten beide Autos irgendwie drauf sind und die anderen Fotos sind für das Carousal nächste Woche

2025-09-19T15:14:06.586319 - **Julia:**
> habe noch ein paar orange markiert die man gut einsetzen könnte. ich denke 2 Slides mit jeweilig dem anderen Auto im Fokus könnte auch cool sein, oder? :slightly_smiling_face:

2025-09-19T15:37:33.122729 - **laetitia:**
> Hello danke euch! Hanna hat sich schon für etwas entschieden also Story ist fertig 

2025-09-19T15:37:42.623949 - **laetitia:**
> es wird das hier 

  📎 IMG_7669.jpg

2025-09-19T15:38:55.812039 - **laetitia:**
> <@U093J779DAQ> Hanna will ein Timing haben für‘s Video, wie weit bist du? hast du eine Einschätzung?

2025-09-19T15:39:29.891019 - **Mert Koc:**
> Leute ich bin noch am Feedback fürs Gipfeltreffen :melting_face:

2025-09-19T15:39:36.637139 - **Mert Koc:**
> Kann kein Timing geben sorry

2025-09-19T15:40:24.791919 - **laetitia:**
> achso aber das Video hat doch Prio dacht ich oder? Weil das muss heute noch raus 

2025-09-19T15:40:32.196509 - **Julia H.:**
> Und wer hat das gebaut?

2025-09-19T15:41:19.349729 - **Mert Koc:**
> <@U093J763E5A> Hab hier eine bessere Version

  📎 250919_Porsche_60-Jahre-Targa_Story_S01_9x16_v3.jpg

2025-09-19T15:41:25.402219 - **laetitia:**
> würde ihr gerne bis 17 uhr etwas schicken, vielleicht kannst du das vorziehen? 
<@U08V6A47PKN> gib gerne mal Bescheid wegen Prios 

2025-09-19T15:41:50.053939 - **laetitia:**
> Mert hat das gebaut

2025-09-19T15:45:31.108859 - **Julia H.:**
> Gipfeltreffen hat auch Prio, das muss auch raus leider

2025-09-19T15:53:13.984999 - **laetitia:**
> ok also habe mit julien telefoniert, er hätte die Kappa für 150€ extra sich jetzt an das Video zu setzen und zu schneiden

2025-09-19T15:53:31.170369 - **laetitia:**
> müsst ihr entscheiden, wie es mit Kappas aussieht

2025-09-19T15:54:13.931679 - **laetitia:**
> muss nur Hanna etwas sagen, damit wir rechtzeitig mit dem Video rausgehen.

2025-09-19T15:54:31.766069 - **laetitia:**
> <@U093J779DAQ> <@U08V6A47PKN> 

2025-09-19T15:57:40.914599 - **Julia H.:**
> Budget Entscheidungen trifft immer Flo. Ich kann nicht einschätzen wie lang Mert für das video braucht

2025-09-19T15:58:28.833099 - **Mert Koc:**
> Ich bin jetzt dran

2025-09-19T16:15:19.929359 - **laetitia:**
> Okay dachte wir hatten gestern festgelegt, dass die Anlieferung Prio hat. Müsste am besten gleich Bescheid wissen, wenn es zeitlich sich nicht ausgeht weil Gipfeltreffen doch auch so hohe Prio hat heute. Brauche einfach eine Rückmeldung, bis wann ich Hanna was schicken kann. Habe jetzt nochmal mit Mert und Flo telefoniert, Julien übernimmt das jetzt weil‘s schneller ist :+1::skin-tone-3: 

2025-09-19T16:21:35.443629 - **Mert Koc:**
> Danke fürs schnelle umorganisieren, das nimmt mir so den Stress ab, das glaubst du nicht :joy: :pray::skin-tone-4:

2025-09-22T12:27:56.761569 - **laetitia:**
> <@U08V6A47PKN> <@U09D64LA420> wollt ihr auf S. 7 noch meine Bildauswahl checken bevor ich es an Hanna weitergebe? habe auch einen Kommentar noch hinterlassen. Leider gibt es auch nicht sooo viel Bildauswahl finde ich <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7B4D6C66A4-616A-40AD-AF31-A368ECCF5E4B%7D&amp;file=250908_Porsche_BS_Sommerfest.pptx&amp;action=edit&amp;mobileredirect=true|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7B4D6C66[…]orsche_BS_Sommerfest.pptx&amp;action=edit&amp;mobileredirect=true>

2025-09-22T13:26:35.633989 - **laetitia:**
> gerne kurze Info, sonst gebe ich ihr schonmal Bescheid. Muss ja heute raus

2025-09-22T13:30:29.287069 - **Julia:**
> hab keinen Zugriff leider 

2025-09-22T13:31:21.963429 - **Julia H.:**
> 

  📎 image.png

2025-09-22T13:35:00.052529 - **laetitia:**
> und noch comment

  📎 image.png

2025-09-22T14:16:44.840669 - **Julia:**
> <@U093J763E5A>
Ich würde die Reihenfolge noch etwas anpassen:
1. So lassen – oder gibt es noch ein Alternativ Bild von der gleichen Situation?
2. Junge mit Handy
3. Slide 2
4. lassen
5. Slide 7
6. Food
7. Targa (Slide 5)
8. lassen
9. lassen
Caption: Targa ohne Porsche?
Dankee dir :slightly_smiling_face:

2025-09-22T15:18:53.367089 - **laetitia:**
> <@U093J779DAQ> Ich habe auch mal die Bilder rausgesucht für die alt/neu Gegegnüberstellung die morgen raus muss. Finde die Bildbearbeitung aber noch nicht optimal, finde den neuen Targa oft sehr dunkel. Kannst du da vielleicht mal über die Bilder schauen, ob du da noch was nach bearbeiten kannst? Habe dir alle Bilder hier schwarz markiert: <https://www.picdrop.com/porsche-deutschland/SU36qbsTkK?file=4228895124989bf990eb0b4b58241703>

  📎 image.png

2025-09-22T15:21:11.806629 - **Mert Koc:**
> Ja verstehe was du meinst. Ich kann sie etwas heller machen. Gibts dazu eine Aufgabe in Asana? Kannst du mich bitte Taggen, damit ich das direkt mache

2025-09-23T13:21:29.428449 - **laetitia:**
> Hey kurze Übergabe, weiß nicht wann ich hier auch rausfliege:

• Postings Sommerfest: Das Alt/Neu Carousel ist fertig und konnte ich jetzt aber nichtmehr in Sprinklr einplanen. Das muss wie in der Präsi steht für heute 15 Uhr eingeplant werden noch. 
• Die Stories für morgen hat Mert fertig gemacht, sind auch in der Präsentation, da muss bitte jemand Hanna noch Bescheid geben, ob die Stories für sie so passen und dann händisch posten wegen Antwort Sticker. 
• CM ist von heute morgen noch aktuell. DM´s müssen immer hier in diese Liste eingetragen werden mit Antwortvorschlag, dann von Porsche freigegeben werden und dann kann man antworten: <https://porsche.sharepoint.com/:x:/r/sites/PDMK/_layouts/15/guestaccess.aspx?isSPOFile=1&amp;ovuser=56564e0f-83d3-4b52-92e8-a6bb9ea36564%2Claetitia.rupp%40boldcreatorsclub.com&amp;clickparams=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIxNDE1LzI1MDczMTE3NDEwIiwiSGFzRmVkZXJhdGVkVXNlciI6ZmFsc2V9&amp;share=EUy71bc_ZQtNv8PO5Pmb8SQBO0MqDfrhi7RQs-gbYo0P_Q|https://porsche.sharepoint.com/:x:/r/sites/PDMK/_layouts/15/guestaccess.aspx?isSPOFile=1[…]c2V9&amp;share=EUy71bc_ZQtNv8PO5Pmb8SQBO0MqDfrhi7RQs-gbYo0P_Q>
• Redaktionsplan habe ich gecheckt und in Asana kommentiert gehabt. Bzgl. weiterer Themen habe ich keinen Überblick mehr. 
Bin echt sprachlos gerade. Viel Erfolg euch bei der weiteren Arbeit, hat Spaß gemacht mit euch zusammenzuarbeiten:heart:

2025-09-23T13:59:40.851839 - **Julia H.:**
> :disappointed:
können wir dazu noch einen kurzen Call machen irgendwie heute?

2025-09-23T14:15:02.672719 - **laetitia:**
> bin schon ausgeloggt über all und von einer Minute auf die nächste raus. Das hat Flo entschieden so zu regeln, auf ganz blöde Art und Weise meiner Meinung nach.

möchte euch auf keinen Fall hängen lassen, aber hab darauf keinen Einfluss leider.

Also CM kann ich nicht mehr zu sagen noch als dass man die DM´s immer kopiert, dann in die Liste reinläd mit dem Namen des Accounts, dann macht man einen Antwortvorschlag und schreibt jana auf teams wenn es aktuell ist, wenn sie ganz rechts als Status schriebt "freigegeben" Könnt ihr die Antwort wieder rauskopieren, der person schicken und den Status auf "abgesetzt" ändern und das Feld grün markieren. Alles was noch nicht abgeschickt wurde, bleibt gelb.

2025-09-23T14:15:56.861629 - **laetitia:**
> BS Nachrichten schicke ich wenn welche da sind einfach Hanna so zu, die kommen nicht in die Liste rein

2025-09-23T14:16:12.207039 - **laetitia:**
> und ihr könnt euch ja vielleicht an meinen vorherigen Antwortvorschlägen orientieren

2025-09-23T14:16:53.782349 - **laetitia:**
> hab auch keine Mail mehr oder zugriff auf drive, calender, oder meet

2025-09-23T14:19:56.539349 - **laetitia:**
> Und CM muss immer jeden Tag morgens und Abends gemacht werden. Storyerwähnungen liken wir einfach aber wenn wir antworten müssen wir uns leider immer über die excel Liste freigeben lassen. I´m so sorry, ich hoffe damit ist es einigermaßen klar, ich hab ja auch nie richtig ne Übergabe bekommen leider!! Wundert mich jetzt auch nicht. Würd´s gern anders machen aber hab damit auch nicht gerechnet. Ganz viel Erfolg euch und wenn noch etwas nicht klar ist müsst ihr euch am besten auf WA bei mir melden:heart:


---

### mert, sebastian (23 messages, 11 from Julia)

**Participants:** mert, sebastian
**Folder:** `mpdm-julia.hopper--mert--sebastian--julia.hallhuber-1`

2025-09-04T17:40:51.691639 - **Julia:**
> Hello! Hab hier den Styleguide mal in PPT aufgesetzt für Porsche. Schaut gerne mal rein. Youtube würde ich nachziehen, aber vllt können wir ihnen diesen Status Quo ja schon mal schicken: <https://docs.google.com/presentation/d/1NYJecXqmY5G5_olYJcMTLr-bH7ToODD0/edit?slide=id.p1#slide=id.p1>

<@U0929T1BG0G> ich habs jetzt extrem runter gekürzt seitens den Premiere Einstellungen, weil das für die Porsche Freigabe nicht relevant sein sollt3e.

<@U08V6A47PKN> kannst du die Fußzeile bearbeiten? Oder mir gerne kurz sagen, wie das geht :smile:

2025-09-04T17:49:57.645879 - **Julia:**
> btw: ändert sich die Font bei euch auch, wenn ihr die Präsi online öffnet statt runterladet? Hatte eigentlich alles in der Hausschrift angelegt

2025-09-04T17:53:20.586099 - **Julia H.:**
> Anzeigen -&gt; Master -&gt; Auf 1. Slide die Fußzeile ändern, Master schließen

2025-09-04T17:54:11.656429 - **Mert Koc:**
> Bei mir ist die Schrift Arial

2025-09-04T17:54:34.249979 - **Julia:**
> ja genau in der Onlineversion

2025-09-05T15:34:35.053069 - **Basti:**
> Wollen wir wirklich Headlines so anbieten? Das passt doch safe nicht in die Safezone?

  📎 Bildschirmfoto 2025-09-05 um 15.34.10.png

2025-09-05T15:35:26.961749 - **Julia:**
> Das ist an die PAG angelehnt und auch nur bei direkten Übersetzungen

2025-09-05T15:35:51.411519 - **Basti:**
> hm...okay :smile:

2025-09-05T15:38:32.530369 - **Mert Koc:**
> echt machen die noch sowas?
Meins war eigentlich auch an die PAG angelehnt. Also die 24PT hatte ich von kürzlichen SoS Stories der PAG.

2025-09-05T15:39:32.478709 - **Basti:**
> Aber schön aufbereitet danke dir :slightly_smiling_face: für jetzt egal aber für uns würd ich hier noch hinzufügen "oder beides" :smile: eigentlich machen wir nämlich immer oben und unten gradient hin nur unterschiedlich ausgeprägt. Gerade in dem Fall kann man die VBW´s so nämlich nicht mehr lesen

  📎 Bildschirmfoto 2025-09-05 um 15.38.10.png

2025-09-05T15:40:06.315509 - **Julia H.:**
> Vielleicht nehmen wir das PAG ding hier noch raus, das ist zumindest während IAA nicht relevant, damit die Blink media nicht verwirrt sind

2025-09-05T15:43:48.924949 - **Julia:**
> ah perfekt. das wusste ich noch nicht :slightly_smiling_face:

2025-09-05T15:44:03.980469 - **Julia:**
> <@U08V6A47PKN> hast dus schon abgeschickt oder soll ich das noch anpassen?

2025-09-05T15:45:00.221179 - **Julia H.:**
> ist abgeschickt, aber an Vincent ging es ja noch nicht

2025-09-05T15:48:12.926459 - **Julia:**
> Blink Version PDF liegt ab!
<https://drive.google.com/drive/folders/1Uqfsv2dzOxUL2lpnQUGXIqSmga7tscPP>

2025-09-08T09:30:45.621619 - **Basti:**
> Hab mir gerade das Feedback von Charly zum Styleguide angeschaut. Kann mir jemand von euch vielleicht erklären was sie damit meint? Wie kann man denn ein Reel nicht in 9:16 sehen :smile:? Ich sehe wenn ich nicht drauf klicke nur das Thumbnail...

  📎 Bildschirmfoto 2025-09-08 um 09.29.41.png

2025-09-08T09:31:33.515529 - **Julia:**
> Ja hatte ich Julia auch schon gesagt. Ich glaube sie hat hier etwas verwechselt. Es ist ja auch die Slide zu den Stories

2025-09-08T09:31:53.040519 - **Basti:**
> lol :smile:

2025-09-08T09:32:40.822609 - **Julia:**
> Hatte extra nicht das iPhone Mockup genommen. Jetzt wollen sie es doch haha

2025-09-08T09:43:09.693649 - **Julia H.:**
> :stuck_out_tongue:

2025-09-08T11:26:53.509309 - **Julia:**
> Das hattest du eigentlich an PAG angepasst <@U093J779DAQ> oder?

  📎 Bildschirmfoto 2025-09-08 um 11.26.35.png

2025-09-08T11:29:10.136259 - **Julia:**
> das ist nämlich gleich, der Text ist nur länger

  📎 Bildschirmfoto 2025-09-08 um 11.28.57.png

2025-09-08T11:29:27.160249 - **Mert Koc:**
> Ja genau


---

### sebastian (61 messages, 29 from Julia)

**Participants:** sebastian
**Folder:** `mpdm-julia.hopper--sebastian--marvin-1`

2026-01-28T11:29:59.350529 - **Julia:**
> Hello! :slightly_smiling_face: Basti ich hab dir eine Asana Task erstellt für's Editing von verschiedenen Assets für den IG Workshop am Montag mit SIXT.
Nach und nach füge ich die weiteren Ideen und Tasks für dich hinzu.

Ist das soweit verständlich? Sonst können wir gerne gleich mal dazu sprechen! Danke dir

2026-01-28T16:21:35.802239 - **Basti:**
> Hi Juli, ne denke das is klar danke dir :slightly_smiling_face: Möchtest du es als 9:16 Video mit Insta Mockup oder in Handyformat also mit dem Kommentarbalken vom Handy in 1080x2337?

2026-01-28T16:22:38.975839 - **Julia:**
> super, danke! :slightly_smiling_face: Evtl. kommt noch was Kleines, sonst versuchen wir jetzt viel über Stills abzubilden

2026-01-28T16:22:47.329449 - **Julia:**
> Wäre mir egal – das was wir sonst bei SIXT auch verwenden?

2026-01-28T16:23:37.100479 - **Basti:**
> Puh ich glaub ich hab das für sixt noch nie genutzt ehrlich gesagt :smile: aber wenns nur für ne Präsentation is und nicht gepostet wird oder so würd ich das größere Format mit richtigen Handy-Look nehmen

2026-01-28T16:25:55.158989 - **Julia:**
> Ah okay

2026-01-28T16:25:56.177079 - **Julia:**
> ja gerne

2026-01-28T17:38:56.599609 - **Basti:**
> <@U09D64LA420> hast dus dir so in etwa vorgestellt?: <https://f.io/xeAq9ugX>
<https://app.asana.com/1/1199360402832734/task/1212991424663406?focus=true>

2026-01-28T17:40:45.573229 - **Basti:**
> Bei SIXT | IG Workshop | Idee "Carpool" - steht noch nichts in der Beschreibung.

2026-01-28T17:42:16.980259 - **Julia:**
> Nice! Beste aus dem Material rausgeholt, danke dir :slightly_smiling_face:

2026-01-28T17:42:35.870939 - **Basti:**
> Hahah habs ja nur aneinander geschnitten :smile:

2026-01-28T17:42:44.873539 - **Julia:**
> yes, da bin ich grad noch nicht so weit.
Bei Personality change lege ich dir gerade die Snippets ab

2026-01-29T09:21:04.626899 - **Julia:**
> Hello! <@U0929T1BG0G> bist du heute auf einem Dreh? Ich meine da etwas gehört zu haben :slightly_smiling_face:

2026-01-29T09:21:23.148719 - **Marvin Hammerschmidt:**
> Nop
Der wurde spontan gestern abend abgesägt :slightly_smiling_face:

2026-01-29T09:21:33.489499 - **Julia:**
> Oh no

2026-01-29T09:21:41.811499 - **Julia:**
> Aber gut für mich :stuck_out_tongue:

2026-01-29T09:21:43.130539 - **Basti:**
> Yop was Marvin sagt :joy:

2026-01-29T09:42:27.598589 - **Basti:**
> Hier noch das Asset mit Insta-overlay: <https://f.io/YanY7-h1>



 <https://app.asana.com/1/1199360402832734/task/1212991179974329?focus=true>

2026-01-29T10:05:44.109769 - **Julia:**
> danke dir :slightly_smiling_face: hab in Asana kommentiert – wir haben uns überschnitten!

• Personality change
• Things you shouldn't do
sind noch ready for you!

2-3 weitere kommen noch, da gebe ich asap Bescheid

2026-01-29T10:05:55.130189 - **Basti:**
> Yes schon gesehen, bin schon dran :slightly_smiling_face:

2026-01-29T10:06:10.912459 - **Julia:**
> ein Traum hier

2026-01-29T10:48:22.332049 - **Basti:**
> <@U09D64LA420> Untertitel sind eingefügt: <https://app.asana.com/1/1199360402832734/task/1212991179974329?focus=true>

2026-01-29T10:50:18.364459 - **Julia:**
> danke dir! Hast du das IG Mockup zufälligerweise als PNG? Dann würde ich das für die Stills auch direkt nutzen

2026-01-29T10:56:44.587839 - **Basti:**
> Einmal eine PSD falls du irgendwas ändern willst (Text,Grafikelemente etc.) und einmal als PNG.

  📎 IG_PhoneMockup.png
  📎 IG_PhoneMockup.psd

2026-01-29T10:58:56.352179 - **Basti:**
> Kleine Randinfo, in all den Videos is immer das alte SIXT-Logo drin. Das mögen die nicht so gerne :smile: Leider hat AI n bisschen ein Problem damit das neue zu nehmen zumindest laut meiner Erfahrung, aber es geht :slightly_smiling_face:

2026-01-29T10:59:33.127669 - **Marvin Hammerschmidt:**
> Wenn Flo das sieht möchte er das man das mit Fotoshop ändert
Haben wir die Möglichkeit da einen Prakti dran zu setzen?

2026-01-29T10:59:52.209189 - **Basti:**
> Das sind Videos...

2026-01-29T11:00:07.550029 - **Marvin Hammerschmidt:**
> Das war ihm in der Vergangenheit auch egal :smile:

2026-01-29T11:00:19.779229 - **Marvin Hammerschmidt:**
> Also: Geht nicht
Passt auch können wir dann ja so sagen:)

2026-01-29T11:00:38.220609 - **Marvin Hammerschmidt:**
> WIll nur vorbereitet sein, weil das garantiert als Feedback kommt

2026-01-29T11:00:55.764889 - **Julia:**
> Okay, welcher Unterschied ist bei den Logos? Wenn ich es google kommt nur das eine

2026-01-29T11:01:08.091029 - **Marvin Hammerschmidt:**
> 

  📎 image.png

2026-01-29T11:01:14.405919 - **Marvin Hammerschmidt:**
> Das S geht in den I punkt über

2026-01-29T11:01:17.796909 - **Basti:**
> Pass auf das ist ein signifikanter Unterschied!

2026-01-29T11:01:36.111779 - **Marvin Hammerschmidt:**
> das ist deshalb so wichtig, weil der der Eliah der VP of Brand gemacht hat und der dem Flo ja recht nahe steht

2026-01-29T11:01:46.363299 - **Basti:**
> <@U09D64LA420> hier findest du die richtigen Logos: <https://drive.google.com/drive/folders/18vV0u11GaZaXKAVsBTyHJvABswIA-HC2?usp=drive_link>

2026-01-29T11:02:10.031819 - **Julia:**
> ahh jetzt

2026-01-29T11:02:11.841539 - **Julia:**
> okay wow

2026-01-29T11:02:35.683889 - **Julia:**
> dann achte ich bei der Erstellung den nächsten Assets jetzt drauf :slightly_smiling_face: danke!

2026-01-29T11:04:03.062639 - **Marvin Hammerschmidt:**
> Das bekommt die KI leider nicht so wirklich hin
Zumindest war das in der Vergangenheit so

2026-01-29T11:04:30.425809 - **Julia:**
> ich versuchs mal, sonst sagen wir es dazu. danke Basti für den Hinweis :slightly_smiling_face: wäre mir so nicht aufgefallen

2026-01-29T11:12:41.220129 - **Julia:**
> danke dir! :slightly_smiling_face:

2026-01-29T12:54:54.903569 - **Basti:**
> Next one: <https://app.asana.com/1/1199360402832734/project/1210571698487014/task/1213012351604971?focus=true>

2026-01-29T13:01:20.833119 - **Julia:**
> :joy: liebs

2026-01-29T13:13:11.483429 - **Basti:**
> next one here: <https://app.asana.com/1/1199360402832734/project/1210571698487014/task/1212991179974324?focus=true>

2026-01-29T13:13:52.597389 - **Julia:**
> dankeee!

2026-01-29T13:14:17.178189 - **Basti:**
> Fehlt noch was? - "AI Modus" kommt noch?

2026-01-29T13:14:26.882459 - **Julia:**
> Hab noch eine weitere Task angelegt, da lädt das Video Snippet gerade los. Bis dahin wars es erstmal. Kann sein, dass Flo heute Abend doch noch ein paar Visualisierungen will, aber da melde ich mich

2026-01-29T13:15:13.942029 - **Basti:**
> Alles klar. Hab mit Flo ab 17 Uhr ein Meeting, sprich ab da geht nix mehr für heute

2026-01-29T13:15:27.143239 - **Julia:**
> ja klar, wir davor

2026-01-29T13:33:06.036459 - **Basti:**
> <@U09D64LA420> vielleicht so ne Mischung?

<https://app.asana.com/1/1199360402832734/task/1213024814714292?focus=true>

2026-01-29T13:41:13.829859 - **Julia:**
> Ja, why not! Danke dir :slightly_smiling_face:

2026-01-30T10:25:47.732949 - **Basti:**
> <@U09D64LA420> Huhu kurze Frage, wegen dem "Love is blind" soll ich trotzdem beim letzten Shot nach dem "l´m turning left or right" raus schneiden oder soll ich den Rest jetzt drin lassen?

2026-01-30T10:27:33.952199 - **Julia:**
> Hello! Die neuen Videos sind noch nicht fertig :slightly_smiling_face: melde mich asap. Evtl. krieg ich es evtl länger hin und du musst am Ende nichts cutten

2026-01-30T11:32:49.516409 - **Basti:**
> okaaay

2026-01-30T11:45:56.851459 - **Julia:**
> Wenn ich dir die Video Snippets ohne Voiceover schicke, meinst du, du kannst diese dann von den "falschen" Videos nehmen? Ich hoffe es klappt, aber IDK

2026-01-30T11:56:26.304639 - **Julia:**
> liegen ab, hat sogar geklappt!

2026-01-30T12:58:59.722909 - **Basti:**
> Klar kann ich machen :call_me_hand:

2026-01-30T13:06:08.866489 - **Julia:**
> Danke dir 

2026-01-30T14:13:19.358339 - **Basti:**
> <@U09D64LA420> Check this ;): <https://app.asana.com/1/1199360402832734/task/1212991424663406?focus=true>

2026-01-30T14:28:04.923299 - **Julia:**
> super, vielen Dank! :slightly_smiling_face:


---

