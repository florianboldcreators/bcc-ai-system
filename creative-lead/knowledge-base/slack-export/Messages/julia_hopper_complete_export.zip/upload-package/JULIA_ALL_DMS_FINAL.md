# Julia Hopper - All Direct Messages

**Total 1:1 DMs:** 9
**Total Messages:** 7442

---

## Julia H. (2848 messages)

**Julia sent:** 1486 | **Julia H. sent:** 1362

**Folder:** `D09CY8U2AGK`

**2025-09-02 10:47:50** - Julia H.:
> <https://calendar.google.com/calendar/u/0?cid=Y19lYzJmZjc4MzBmZTI2NTc0ZmYwZTIyMzg4ZmYwMzYzYWQ5ZDQ3ODVjZmU4M2MzYjM0OGQ4N2I1NGFiZjU3ODEyQGdyb3VwLmNhbGVuZGFyLmdvb2dsZS5jb20|https://calendar.google.com/calendar/u/0?cid=Y19lYzJmZjc4MzBmZTI2NTc0ZmYwZTIyMzg4ZmYwM[…]YjM0OGQ4N2I1NGFiZjU3ODEyQGdyb3VwLmNhbGVuZGFyLmdvb2dsZS5jb20>

**2025-09-02 10:48:03** - Julia H.:
> <https://calendar.google.com/calendar/u/0?cid=Y18xOWVhY2ViODU5ODk2OGUxZGJiYzg5MTRkZWVjNjAyMTJlMjFmNmVlOTAwMGUxZmFhZmM4ZmFiYWNmM2FiNTQzQGdyb3VwLmNhbGVuZGFyLmdvb2dsZS5jb20|https://calendar.google.com/calendar/u/0?cid=Y18xOWVhY2ViODU5ODk2OGUxZGJiYzg5MTRkZWVjN[…]ZmFhZmM4ZmFiYWNmM2FiNTQzQGdyb3VwLmNhbGVuZGFyLmdvb2dsZS5jb20>

**2025-09-02 10:57:43** - Julia H.:
> <https://newsroom.porsche.com/de.html>

**2025-09-02 10:57:48** - Julia H.:
> <https://vmmedia.porsche.de/prod/vmmedia/Resources.nsf>

**2025-09-02 11:03:38** - Julia H.:
> <https://press.de.porsche.com/prod/presse_pag/PressBasicData.nsf/WebConsumptionData?ReadForm>

**2025-09-02 11:11:22** - Julia H.:
> <https://porsche.sharepoint.com/:x:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7B5467DF8F-C89C-486C-8CFF-887B6C91507F%7D&amp;file=2025-06-13_IG_PD_Redaktionsplanung.xlsx&amp;fromShare=true&amp;action=default&amp;mobileredirect=true|https://porsche.sharepoint.com/:x:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7B5467DF[…]ng.xlsx&amp;fromShare=true&amp;action=default&amp;mobileredirect=true>

**2025-09-02 11:14:31** - Julia H.:
> <https://porsche.sharepoint.com/sites/PDMK/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FPDMK%2FShared%20Documents%2FGeneral%2FUMZUG%2FDigitales%20Marketing%2FSocial%2FInsta%2F08%5FRedaktionsplanung%2FContents&amp;viewid=6340b967%2Dd3d5%2D401d%2D9687%2D73af93fd1ecf&amp;csf=1&amp;web=1&amp;e=YdzFfu&amp;CID=7e2a435d%2D2939%2D41fb%2D9048%2D5ab214ca428f&amp;FolderCTID=0x012000B0A40330D7B2464BB054061397BEF042|https://porsche.sharepoint.com/sites/PDMK/Shared%20Documents/Forms/AllItems.aspx?id=%2Fs[…]a428f&amp;FolderCTID=0x012000B0A40330D7B2464BB054061397BEF042>

**2025-09-02 11:16:59** - Julia H.:
> <https://porsche.sharepoint.com/sites/PDMK/Shared%20Documents/Forms/AllItems.aspx?csf=1&amp;web=1&amp;e=ofJAdD&amp;CID=38033eb8%2Df40e%2D408d%2Da7a4%2De393c7e25338&amp;FolderCTID=0x012000B0A40330D7B2464BB054061397BEF042&amp;id=%2Fsites%2FPDMK%2FShared%20Documents%2FBrand%20Store%2F08%20Social%20Media%2FKonzepte|https://porsche.sharepoint.com/sites/PDMK/Shared%20Documents/Forms/AllItems.aspx?csf=1&amp;w[…]ocuments%2FBrand%20Store%2F08%20Social%20Media%2FKonzepte>

**2025-09-02 13:00:53** - Julia H.:
> 

**2025-09-02 13:13:21** - Julia:
> Kurze Frage: ppt und Co. sind noch nicht auf meinem Laptop – haben wir hier Lizensen? Irgendwie kann ich es sonst nicht runterladen

**2025-09-02 13:18:10** - Julia H.:
> Ahh das geht auch mit der .com Email

**2025-09-02 13:18:10** - Julia H.:
> Bin soooo froh, dass du da bist

**2025-09-02 13:31:17** - Julia:
> ahjaa okay klappt. danke!

**2025-09-02 13:31:32** - Julia:
> ich mich auch, aber bin noch etwas "überfahren" ha ha

**2025-09-02 14:51:42** - Julia:
> nochmal kurz: soll ich mir zu der Präsi von Flo &amp; Alex Gedanken machen/ Ideen weiterspinnen oder ein neues Konzept überlegen?
Oder Fotografen usw. checken
Also für den Termin morgen

**2025-09-02 15:21:09** - Julia H.:
> Ich glaube theoretisch alles davon. Also so viel wie möglich.
Ich denke wir könnten 2-3 Konzepte der beiden picken und feinschleifen.
Wenn du eigene Ideen hast, gern her damit!
Fotografen und Videografen kannst du dir mal grob anschauen.
Schau mal, was du schaffst, ich kann hier auf jeden Fall helfen.

**2025-09-02 17:35:35** - Julia:
> Ich weiß gerade nicht, wo ich das am besten ablegen soll. Deshalb erstmal hier - sorry!

Ich hab Kommentare &amp; Ideen abgelegt in Flo's Präsi. Wollte diese jetzt erstmal nicht zerschießen-
Unten hab ich noch 2 Kampagnenideen neben dem "La Famiglia" Thema reingelegt – welches ich super finde, allerdings mit kleinen Anpassungen (siehe Kommentare).

Ist natürlich noch komplett WIP, aber sollte als Grundlage für uns schon mal dienen :slightly_smiling_face:
Bezüglich Fotograf kommt es mMn total auf das Konzept am Ende an, denn Mario ist für mich eher beim Thema "Opera" (groß, bildgewaltig, dramatisch) aber sehe ihn nicht unbedingt bei einem nahbaren, menschlichen Content. Wie siehst du das?

**2025-09-02 18:25:40** - Julia H.:
> Huhuuuu
Ich hab nur gerade kurz überflogen. Ich finde die opera Idee ziemlich nice!! 
Hier ganz ungefiltert ein paar gedanken:
• wie stellen wir sicher dass Bezug zu Deutschland bleibt mit so viel Italien content
• Bei familia würde ich eventuell die Bilder mit der hilfiger Ralph Lauren Family anreichern. Gefühlt ist das auch etwas sportlicher und nahbarer. Ich schau auch nochmal nach Bildern.
• Ich denke für morgen müssen wir alle Ideen einmal glatt ziehen und die Folien schön aufbereiten, es muss auch nicht viel sein, aber das was wir zeigen sollte Hand und Fuß haben.
• Wie stellen wir uns die content Strategie bei beiden Ideen vor? 
• Haben wir vielleicht auch Ideen wie man das key visual cool Social spielen kann ohne die CI zu sehr zu vernachlässigen 
• 

**2025-09-02 18:26:46** - Julia H.:
> 

**2025-09-02 18:27:14** - Julia H.:
> 

**2025-09-02 18:27:30** - Julia H.:
> Vielleicht wäre auch irgendwo die Arbeit mit stereotypen cool

**2025-09-02 18:28:07** - Julia H.:
> 

**2025-09-02 18:28:44** - Julia H.:
> Sozusagen Porsche Typen innerhalb der Family:
Der schnelle der wenig packt
Der overpacker
Der elegante 

**2025-09-02 18:29:51** - Julia H.:
> Natürlich nicht zu überspitzt sein 

**2025-09-02 20:16:59** - Julia:
> Danke fürs Drübergucken! :slightly_smiling_face: Die Kommentare hast du gesehen? Die Idee mit Fahrzeuge = la Famiglia ist rqaus, oder?

Präsentation zieh ich glatt und formatier alles schön. Deine Punkte schau ich mir an und versuch so gut es geht schon einzubauen. Schicks dir dann natürlich sobald ich was anschauliches hab

**2025-09-03 08:55:52** - Julia:
> Guten Morgen! Wie heißt nochmal die Aufgabe, bei der du alle Infos hinterlegt hast? Finde sie in Asana nichtmehr

**2025-09-03 09:00:47** - Julia:
> Und vllt könntest du mir noch die aktuelle PPT Präsi schicken, die ich benutzen kann. Hatte gesehen, die von Roxanne war ohne Porsche Logo Tag unten

**2025-09-03 09:17:18** - Julia:
> Ah die "Master Gipfeltrffen" ist die richtige, right?

**2025-09-03 09:32:04** - Julia H.:
> Yes, genau!!

**2025-09-03 09:32:05** - Julia H.:
> <https://app.asana.com/1/1199360402832734/project/1210522556460283/task/1210555969111912?focus=true>

**2025-09-03 09:32:18** - Julia H.:
> Hier. Aber ich muss das in Asana noch sortieren, das ist noch bisschen durcheinander

**2025-09-03 09:32:41** - Julia H.:
> Ich hab kurz eine Bitte, könntest du schnell was anderes priorisieren? Geht nochmal um das Carousel von Golf/Schweiz
Schicke es dir per Mail.

**2025-09-03 09:33:00** - Julia H.:
> Porsche würde da gerne schon in ner Stunde einen Vorschlag haben und ich hab gleich wieder ein Meeting

**2025-09-03 09:33:39** - Julia:
> Alles gut, ich arbeit mal in den Master rein, dann haben wir es zentral &amp; wir können später nur die einzelnen Slides ab "Konzept" präsentieren

**2025-09-03 09:33:40** - Julia:
> Okay

**2025-09-03 09:35:56** - Julia H.:
> thank you

**2025-09-03 09:43:04** - Julia:
> hab zugriff angefordert

**2025-09-03 09:48:10** - Julia:
> 

**2025-09-03 09:51:39** - Julia H.:
> Bei Bildern oder Präsi?

**2025-09-03 09:52:53** - Julia:
> der Link in deiner Mail

**2025-09-03 09:54:47** - Julia H.:
> Okay das ist dann die Präsi

**2025-09-03 09:54:59** - Julia:
> Ahja genau

**2025-09-03 09:55:01** - Julia:
> Bilder seh ich

**2025-09-03 09:55:59** - Julia H.:
> Schau mal obs jetzt geht?

**2025-09-03 09:58:08** - Julia:
> yeees

**2025-09-03 09:58:08** - Julia:
> danke

**2025-09-03 10:00:43** - Julia H.:
> top danke!!

**2025-09-03 10:54:27** - Julia:
> hab die. seite dupliziert und einen content vorschlag + caption reingelegt

**2025-09-03 10:56:45** - Julia:
> okay jetzt hat sich alles abgeändert

**2025-09-03 10:58:51** - Julia:
> okay wir müssen ganz dringend ein anderes tool finden, der löscht einfach alle inhalte raus :smile:

**2025-09-03 11:02:22** - Julia:
> okay puh, liegt ab mit einer Note. Passt das für dich?

**2025-09-03 11:02:37** - Julia:
> 

**2025-09-03 11:22:35** - Julia H.:
> oh nein du arme... kenne das spiel

**2025-09-03 11:25:21** - Julia H.:
> Danke!! Habs an Charly geschickt

**2025-09-03 11:25:51** - Julia:
> okay, bin gespannt :slightly_smiling_face:

**2025-09-03 11:26:11** - Julia H.:
> Saaame

**2025-09-03 11:28:25** - Julia H.:
> FYI
Cayenne Wireless wurde so fast übernommen:
<https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BFD503293-7C34-4EC5-A1CC-9333AB56D17C%7D&amp;file=250902_Wireless%20Charging%20Carousel.pptx&amp;action=edit&amp;mobileredirect=true|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BFD5032[…]0Charging%20Carousel.pptx&amp;action=edit&amp;mobileredirect=true>

Die Übersetzungen für SoS hab ich gestern schnell gemacht, liegt auch schon bei Porsche
<https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1211205975769455?focus=true>

Nur falls du irgendwann nochmal drüber schauen willst

**2025-09-03 12:01:53** - Julia H.:
> Wie kommst du mit Gipfeltreffen voran?

**2025-09-03 12:04:06** - Julia:
> schau ich mir an!

**2025-09-03 12:04:08** - Julia:
> schick ich dir gleich

**2025-09-03 12:23:24** - Julia H.:
> niiice, danke!!

**2025-09-03 12:24:16** - Julia:
> Soo, wo darf ich das nochmal ablegen?

**2025-09-03 12:25:39** - Julia:
> habs! sorry, finde mich noch nicht soo gut zurecht

**2025-09-03 12:29:09** - Julia:
> lädt hoch. schick dir gleich den Link

**2025-09-03 12:30:33** - Julia:
> noch ein paar Fragen: Marie hat in die Präsi kommentiert – wie geh ich jetzt weiter vor? antwortest du?
Um 14Uhr sprechen wir intern oder schon mit Porsche? Soll ich das präsentieren? Kann Flos Ideen nicht 100% nachvollziehen, deshalb etwas schwierig teilweise
Kann ich bis dahin noch kurz Mittagspause machen mit Coco oder schwierig? :smile:

**2025-09-03 12:41:47** - Julia H.:
> In welche wurde kommentiert?

**2025-09-03 12:42:11** - Julia H.:
> Ja mit Flo's Ideen gute Frage. Du könntest ihn mal anrufen. 14 uhr ist tatsächlich schon meeting mti Porsche...

**2025-09-03 12:50:23** - Julia:
> liegt ab!

**2025-09-03 12:51:10** - Julia:
> die <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BC39F3BC9-57D0-49EF-88A5-B797BD28F00A%7D&amp;file=2025-08-22%20Konzept%20Golf%20%40porsche_de_LR.pptx&amp;action=edit&amp;mobileredirect=true|hier>

okay. Also ich kanns schon vorstellen. Frage wäre nur, ob ich ihm halt was wegnehme oder zu sehr ändere

**2025-09-03 12:54:17** - Julia H.:
> Ne denke ich eigentlich nicht

**2025-09-03 12:54:56** - Julia H.:
> danke dir!

**2025-09-03 12:54:59** - Julia H.:
> schau ich mir an

**2025-09-03 13:18:08** - Julia H.:
> Ich schau mit grad die Präsi noch schnell durch.
kurz noch zur Info (muss ich mir auch erst wieder abgewöhnen) Porsche gendert nicht (LOL)

**2025-09-03 13:19:00** - Julia H.:
> Wenn du dich Marie gleich vorstellst, bleib High-Level und nenne erstmal keine Firmen bei denen du warst. Eine ehemalige Mitarbeiterin hatte es sich am Anfang direkt mal verkackt, als sie meinte sie hatte mal ein Praktikum bei BMW gemacht haha

**2025-09-03 13:19:11** - Julia H.:
> also einfach professional seniorig. aber das kannst du ja eh easy

**2025-09-03 13:24:08** - Julia:
> oh okay :smile: hab ich jetzt

**2025-09-03 13:24:25** - Julia:
> i try

**2025-09-03 13:24:36** - Julia:
> :smile:

**2025-09-03 13:29:28** - Julia:
> soll ichs abändern?

**2025-09-03 13:29:45** - Julia:
> kannst du die präsentation direkt online öffnen? ich muss sie downloaden, anpassen und wieder hochladen

**2025-09-03 13:41:01** - Julia:
> sollen wir nochmal kurz sprechen?

**2025-09-03 13:50:41** - Julia:
> ich hatte nochmal ein paar Typo Fehler ausgebessert – Version 0309 lädt in den Drive hoch

**2025-09-03 14:04:43** - Julia H.:
> OMGGGG

**2025-09-03 14:04:47** - Julia H.:
> direkt guter start

**2025-09-03 14:05:06** - Julia:
> puh, was heißt das denn genau? super viel budget weg oder?

**2025-09-03 14:16:18** - Julia H.:
> ich bin nicht ganz sicher

**2025-09-03 14:18:19** - Julia:
> ahhhh

**2025-09-03 14:18:34** - Julia:
> manno :fearful:

**2025-09-03 14:18:59** - Julia H.:
> ich ruf kurz flo an

**2025-09-03 14:19:11** - Julia:
> okay

**2025-09-03 14:19:13** - Julia H.:
> melde mich gleich

**2025-09-03 14:22:55** - Julia H.:
> 

**2025-09-03 14:23:25** - Julia H.:
> das geht super oft nicht, moment lass in den daily von morgen

**2025-09-03 14:23:41** - Julia H.:
> 

**2025-09-03 18:20:06** - Julia H.:
> huhu bist du noch da?

**2025-09-04 08:45:55** - Julia:
> Hello!

**2025-09-04 08:47:48** - Julia:
> Kurze Info und ich klopfe auf Holz – bin morgens mit einem riesigen Knubbel am Nacken aufgewacht, wunderbare Verspannung. Hab Voltaren drauf und intus. Nooormalerweise wenn ich das hab, wirds irgendwann so eklig, dass ich mich nimma bewegen kann. Wenns so schlimm wird (ich hoffe nicht..) muss ich dann evtl. zum Arzt heute und mir paar Spritzen reingeben lassen

**2025-09-04 08:53:37** - Julia H.:
> Oh nooooo das ist nicht gut. Ich hoffe du bist zuhause geblieben wenigstens zum worken?

**2025-09-04 08:54:28** - Julia:
> Neee bin im Büro. Bisher gehts ja voll aber ich wollts nur mal vorwanen, es könnte passieren

**2025-09-04 08:56:12** - Julia H.:
> Shiiit

**2025-09-04 08:57:17** - Julia H.:
> Ja ich bin einfach noch so halb im Schlafanzug, weil Charly mich gebeten hatte ihr schon früh zu helfen LOL

**2025-09-04 08:57:54** - Julia:
> oh wow

**2025-09-04 08:58:02** - Julia:
> muss ich noch was wissen für unser meeting gleich?

**2025-09-04 08:58:21** - Julia H.:
> Würde heute gerne da gemeinsam drüber schauen

**2025-09-04 08:58:40** - Julia H.:
> 

**2025-09-04 09:17:28** - Julia H.:
> Ahhh eine Sache: Samstag ist auch eingeplant. Kannst du da?

**2025-09-04 09:17:46** - Julia:
> 13. oder?

**2025-09-04 09:18:33** - Julia H.:
> yes

**2025-09-04 09:18:43** - Julia:
> ja geht klar

**2025-09-04 09:18:52** - Julia H.:
> top!!

**2025-09-04 09:18:58** - Julia H.:
> Hat vincent dich freigeschaltet?

**2025-09-04 09:19:37** - Julia:
> bisher hab ich keine mail bekommen

**2025-09-04 09:20:35** - Julia H.:
> Sagen wir ihm gleich nochmal, weil ich glaub er hat mich nochmal freigeschaltet

**2025-09-04 09:20:36** - Julia H.:
> LOL

**2025-09-04 09:20:49** - Julia:
> glaub er ist noch im schlummerland

**2025-09-04 09:22:28** - Julia H.:
> 100

**2025-09-04 09:45:41** - Julia H.:
> wenn du das Wireless ding nicht schaffst, kann es ja schnell mert machen

**2025-09-04 09:46:19** - Julia:
> Habs jetzt

**2025-09-04 09:46:27** - Julia:
> gibts ne asana task dazu?

**2025-09-04 09:46:30** - Julia:
> sonst hier: <https://drive.google.com/drive/folders/1hyq-ZZIQcYFhrnpZMFVwPBScT9TdUvOF>

**2025-09-04 09:47:11** - Julia:
> hab für die 1. slide zwei Versionen angelegt. weil ich nicht wusste, ob sie immer mit einer HL einsteigen oder nicht

**2025-09-04 09:47:15** - Julia H.:
> haha woooow das ist so random

**2025-09-04 09:47:27** - Julia H.:
> also nicht deine layouts sondern das was die PAG macht zu IAA

**2025-09-04 09:47:34** - Julia:
> hab das konzept nicht verstanden :smile:

**2025-09-04 09:48:01** - Julia:
> jaa

**2025-09-04 09:48:28** - Julia:
> passen die slides? dann meld ich mich wieder ab. Kann Flo uns da eine 3. Lizens anlegen?

**2025-09-04 09:50:21** - Julia H.:
> ja passt so!

**2025-09-04 09:50:25** - Julia H.:
> Ja bestimmt, schreib ihm gerne

**2025-09-04 09:53:10** - Julia:
> das Reel kommt heute auch online. Zum Repost in die Story oder?

**2025-09-04 09:55:20** - Julia H.:
> Das für Wireless? Das ist schon on. das hab ich heute früh gemacht

**2025-09-04 09:55:36** - Julia:
> ahh okay perfekt

**2025-09-04 09:55:50** - Julia:
> also ich hab das gefühl bezüglich IAA ich versteh garnichts :smile:

**2025-09-04 09:56:12** - Julia H.:
> Ich auch nicht mehr. Ich hol dich dazu heute noch ab irgendiwe

**2025-09-04 09:56:40** - Julia H.:
> Hab dich zu unserem Meeting um 10 kurz mit eingeladen mit Charly wegen Insta Zugang und Kennenlernen

**2025-09-04 09:56:58** - Julia:
> Okay

**2025-09-04 09:57:06** - Julia H.:
> Gibt auch kein Konzept. I am not kidding.

**2025-09-04 09:57:17** - Julia:
> noch eine detaillierte frage, warum mussten die VBWs jetzt nicht in die Captions/ Slides?

**2025-09-04 09:59:57** - Julia H.:
> bei wireless?

**2025-09-04 10:00:32** - Julia H.:
> Das Auto gibt es noch nicht, ist nur ein prototyp daher not needed. Auch bei Klassik Fahrzeugen braucht es keine. Nur quasi die, die aktuell im Verkauf sind

**2025-09-04 10:01:47** - Julia:
> ahh okay ja macht sinn

**2025-09-04 10:28:07** - Julia:
> die slide mit einzeiligem Text ist abgelegt mit _v2

**2025-09-04 10:37:32** - Julia:
> wann gibts die info ans team?

**2025-09-04 11:11:36** - Julia H.:
> welche info?

**2025-09-04 11:14:11** - Julia:
> gipfeltreffen :slightly_smiling_face: hattest es dann schon gesagt

**2025-09-04 11:20:47** - Julia H.:
> Kannst du mir bitte kurz hier helfen bei der Caption?
Hier sollen wir was neues machen

**2025-09-04 11:22:19** - Julia:
> yees, moment

**2025-09-04 11:24:23** - Julia:
> da gehts um die SoS richtig?

**2025-09-04 11:25:08** - Julia:
> und wo finde ich das reel? würde es mir gerne kurz ans background anschauen

**2025-09-04 11:26:28** - Julia:
> bzw. müsstest du mich in asana einmal zu der Dublin Überaufgabe freischalten, dann finde ich alles :slightly_smiling_face:

**2025-09-04 11:31:29** - Julia H.:
> <https://drive.google.com/drive/folders/1RjTeZ60YGEnssCGFEO-dKJxXM4WO6z-l>

**2025-09-04 11:34:48** - Julia:
> Hier mal Vorschläge:

Ein Meisterwerk, zweimal neu interpretiert: Der 911 Turbo S als Coupé und Cabriolet. Kraft, Eleganz und ikonische DNA in zwei faszinierenden Formen.
----

Zwei Ikonen, ein Statement. Der neue 911 Turbo S – als Coupé und Cabriolet, kraftvoll und elegant bis ins kleinste Detail.
----

Offen den Wind spüren oder geschlossen die volle Power genießen – der neue 911 Turbo S verwandelt jede Fahrt in ein unvergleichliches Erlebnis.

**2025-09-04 11:50:11** - Julia H.:
> Juuuuli ich schaffs glaub ich nicht ins büro... Keine ahnung wann. Ich werde beballert von Porsche und bin noch immer im schlafanzug

**2025-09-04 11:51:15** - Julia:
> Alles guut, ich würds dann evtl auch mittags wieder heim packen. kann ich mich etwas gemütlicher auf die couch setzen

**2025-09-04 11:51:47** - Julia H.:
> Klaro

**2025-09-04 11:52:33** - Julia:
> wenn du dann einmal noch kurz paar minuten hast wegen dem Sommer event Konzept, sag Bescheid

**2025-09-04 11:59:51** - Julia H.:
> <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BE57B0967-DF14-4D65-A137-58646F317C64%7D&amp;file=250903_IAA_Hospitality_FD.pptx&amp;fromShare=true&amp;action=edit&amp;mobileredirect=true&amp;previoussessionid=20d66ef3-1ebb-a089-5495-29624ee936cb&amp;wdOrigin=TEAMS-MAGLEV.p2p_ns.rwc&amp;wdExp=TEAMS-TREATMENT&amp;wdhostclicktime=1756979978446&amp;web=1|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BE57B09[…]wdExp=TEAMS-TREATMENT&amp;wdhostclicktime=1756979978446&amp;web=1>
Hier können wir alle weiteren IAA Sachen ergänzen

**2025-09-04 12:41:48** - Julia H.:
> Puhhh ja ich hoffe bald 

**2025-09-04 12:49:53** - Julia:
> alles gut! sonst morgen? :slightly_smiling_face:

**2025-09-04 13:31:31** - Julia H.:
> This one it is

**2025-09-04 13:32:12** - Julia H.:
> Kannst du mir das schicken dann lad ich direkt hoch

**2025-09-04 14:01:48** - Julia:
> there you go!

**2025-09-04 14:08:56** - Julia H.:
> daaaanke :heart:

**2025-09-04 14:10:56** - Julia H.:
> Ja ich schau mal, wie ich durchkomme

**2025-09-04 14:11:00** - Julia H.:
> heute ist horror

**2025-09-04 14:25:19** - Julia:
> gerne!

**2025-09-04 14:25:49** - Julia:
> Soll ich Charly später einfach via Teams anrufen oder möchtest du dabei sein?

**2025-09-04 14:26:08** - Julia:
> Styleguide sitze ich jetzt gleich dran

**2025-09-04 14:30:28** - Julia:
> ich glaubs dir..

**2025-09-04 14:41:06** - Julia H.:
> Du kannst sie gern direkt anrufen ich schaffs einfach nicht :pleading_face: 

**2025-09-04 15:53:35** - Julia H.:
> FYI: das ist es geworden:

Der neue 911 Turbo S als Coupé und Cabriolet. Kraft, Eleganz und ikonische DNA in zwei faszinierenden Formen.

**2025-09-04 15:55:51** - Julia:
> Ah okay :slightly_smiling_face: ist das dann von Porsche oder von dir?

**2025-09-04 16:01:35** - Julia H.:
> Von Porsche.

**2025-09-04 16:21:29** - Julia H.:
> How are you? Erstens mti deinem Knubbel und 2. mit Porsche? :slightly_smiling_face: Kommst du zurecht? Sorry, dass heute so wild ist, ich hatte mir so vorgestellt, dass wir im office zusammen alles durchgehen.

**2025-09-04 16:38:47** - Julia H.:
> Könntest du bitte kurz checken, ob die Files in der INDD Datei die in dem Ordner sind? Wenn ja bräuchte ich da nur die beiden Story Slides ohne dieses Sticker-Link Element?
<https://drive.google.com/drive/folders/1If29keEzgwbXQd8od47KZRnIjONRlcFq>

**2025-09-04 16:39:43** - Julia:
> es wird nicht schlimmer, das ist schon mal gut :slightly_smiling_face:

jaa es ist viel &amp; verstehe auch noch nicht alles aber wird.

**2025-09-04 16:39:49** - Julia:
> All good, machen wir ja eh noch

**2025-09-04 16:39:53** - Julia:
> mooment

**2025-09-04 16:40:16** - Julia H.:
> Ahhh moment ich hab sie jetzt bekommen anscheinend. moment

**2025-09-04 16:40:24** - Julia:
> okee

**2025-09-04 16:42:01** - Julia:
> hier noch kurze eine Frage von mir: hattest du das dann angepasst? Weil ich das gerade in den Styleguide packen wollte und wenn Porsche die HL aber nicht so will wie wir sie setzen, schwierig :smile:

**2025-09-04 16:58:07** - Julia H.:
> Das sollten wir 1:1 von der PAG übernehmen....

**2025-09-04 16:58:16** - Julia H.:
> das ist alles etwas wirr i know

**2025-09-04 17:00:23** - Julia:
> Okay PAG ist so wie geposted wurde?

**2025-09-04 17:00:36** - Julia:
> Dann ist es in der Vorlage nämlich falsch :face_with_peeking_eye:

**2025-09-04 17:01:27** - Julia:
> komme nichtmehr mit :smile:

**2025-09-04 17:02:20** - Julia:
> weil Mert sagt in seiner Vorlage ist es wie bei PAG

**2025-09-04 17:02:32** - Julia H.:
> Ja bei Porsche DE ist es immer ein bisschen anders, aber wenn die PAG postet, dann adaptieren wir das oft so wie es ist...

**2025-09-04 17:03:13** - Julia:
> okay got it

**2025-09-04 17:41:12** - Julia:
> Ich muss tatsächlich um Punkt 18Uhr raus, ist das okay?

**2025-09-04 17:44:08** - Julia:
> Mir ist noch nicht ganz klar, wo wir dabei sind und wo nicht

**2025-09-04 17:52:28** - Julia H.:
> Ja voll okay.

**2025-09-04 17:52:34** - Julia H.:
> Ich glaub irgendwie überall tbh.

**2025-09-04 17:52:42** - Julia H.:
> Orlando Bloom? :stuck_out_tongue:

**2025-09-04 17:53:09** - Julia:
> Ja, da bleib ich die ganze Nacht. Mein Jugendschwarm

**2025-09-04 17:53:28** - Julia H.:
> hahaha

**2025-09-04 17:53:40** - Julia H.:
> Dein guter Freund Ersin freut sich dann

**2025-09-04 17:53:50** - Julia:
> :shushing_face:

**2025-09-04 18:04:29** - Julia:
> 

**2025-09-04 20:35:23** - Julia:
> Falls dus noch brauchst: <https://drive.google.com/drive/folders/1Uqfsv2dzOxUL2lpnQUGXIqSmga7tscPP>

**2025-09-05 09:47:06** - Julia H.:
> Good moooorning, ich hab das gestern noch nicht rausgeschickt. Sollten wir gleich asap machen.

**2025-09-05 09:49:05** - Julia:
> Hello :slightly_smiling_face: yees

**2025-09-05 09:59:52** - Julia H.:
> Ich schau gerade drüber:
Sollte hier nicht auch der Schriftschnitt mit rein? Also Regular?
Ich überleg auch, ob wir noch aus dem Cheat Sheet 1-2 Infos übernehmen sollten

**2025-09-05 10:03:49** - Julia H.:
> Würde auf jeden Fall noch das Thema VBW als einzelne ergänzen, sprich mit dem Link zu den VBW,

**2025-09-05 10:05:06** - Julia H.:
> Und vielleicht machen wir ein Slide für Blink Media, wie wir die Daten brauchen. Sprich wenn sie ein Reel anliefern benötigen wir das TN dazu. Und da gab es glaub ich Vorgaben für Sprinklr (das müsste Mert wissen)

**2025-09-05 10:05:20** - Julia H.:
> mit welcher Email bist du nochmal bei Teams registriert?

**2025-09-05 10:14:30** - Julia H.:
> Soll Roxanne schon mal anfangen mit IAA Captions?

**2025-09-05 10:14:44** - Julia H.:
> Sie hat heute bis 13 Uhr zeit zu supporten

**2025-09-05 10:16:58** - Julia:
> Soo war grad mit Mert im Meeting

**2025-09-05 10:17:13** - Julia:
> oh ja klar, füg ich hinzu

**2025-09-05 10:18:00** - Julia:
> ja das kann ich gerne machen.
Wäre jetzt wie gesagt erstmal so für Porsche intern gewesen

**2025-09-05 10:18:16** - Julia:
> <mailto:julia.hopper@boldcreatorsclub.com|julia.hopper@boldcreatorsclub.com>

**2025-09-05 10:18:32** - Julia H.:
> Sorrryyy, direkt morgens schon beballert mit Slack :stuck_out_tongue:

**2025-09-05 10:18:57** - Julia:
> Ja da wollte ich dich jetzt nochmal fragen. Hast du vllt vor unserem Call kurz Zeit mit einen Überblick zu geben? Bin gerade etwas lost was alels dafür schon vorbereitet werden soll

**2025-09-05 10:19:09** - Julia:
> haha alles gut

**2025-09-05 10:20:01** - Julia H.:
> Lass mal kurz jetzt schon ins Huddle?

**2025-09-05 10:20:12** - Julia:
> ja gerne, bin in 2 Minuten da

**2025-09-05 12:09:42** - Julia H.:
> Was denkst du, bis wann wir Grid und Styleguide und die Teaser Caption zeigen können?

**2025-09-05 12:33:37** - Julia:
> Styleguide lädt gerade hoch. Packs dann gleich wieder in ein pdf und schick dir den Link

**2025-09-05 12:33:49** - Julia:
> Bei der Caption, hab ich keinen Zugriff mehr auf die Präsi..?

**2025-09-05 12:33:54** - Julia:
> Wollte das Video nochmal anschauen

**2025-09-05 12:39:59** - Julia H.:
> Das Video liegt uns eh noch nicht vor

**2025-09-05 12:41:55** - Julia H.:
> Bzw eine alte Version. Ist evtl. hier drin <https://docs.google.com/file/d/1hsAzCF83n6Q_tu_2MjW8qQSradl_J06c/edit?usp=docslist_api&amp;filetype=mspresentation|https://docs.google.com/file/d/1hsAzCF83n6Q_tu_2MjW8qQSradl_J06c/edit?usp=docslist_api&amp;filetype=mspresentation>

**2025-09-05 13:33:06** - Julia:
> kann leider das Grid gerade noch bearbeiten weil Mert &amp; basti noch in Adobe sind.. ahh

**2025-09-05 13:49:19** - Julia:
> okay jetzt. bin dran

**2025-09-05 13:51:32** - Julia H.:
> Hast du die Nachricht in Teams gesehen

**2025-09-05 13:52:02** - Julia:
> hab keine bekommen :fearful:

**2025-09-05 13:52:03** - Julia:
> moment

**2025-09-05 13:52:18** - Julia:
> glaub das mit der Mailadresse klappt nicht so wie Flo sich das vorgestellt hat

**2025-09-05 13:52:47** - Julia H.:
> Wie ist es, wenn du dich mit der Mail von der anderen JULIA anmeldest?

**2025-09-05 13:53:10** - Julia:
> das hier?

**2025-09-05 13:53:19** - Julia H.:
> Yess

**2025-09-05 13:53:21** - Julia:
> ne das geht nicht. er springt immer

**2025-09-05 13:53:25** - Julia H.:
> Da ist der Teaser verlinkt

**2025-09-05 13:53:48** - Julia:
> AH nicee

**2025-09-05 13:54:04** - Julia:
> Ja gut würde auch so passen. habe jetzt halt längere captions geschrieben. Sind in Asana

**2025-09-05 13:54:08** - Julia:
> Soll ich einen Satz draus machen?

**2025-09-05 13:54:50** - Julia H.:
> Schaue mir gleich an

**2025-09-05 13:55:02** - Julia:
> okay, danke fürs flaggen!

**2025-09-05 13:56:49** - Julia H.:
> Happy to help

**2025-09-05 14:01:25** - Julia H.:
> Ich mag deine kurze caption Variante am liebsten machst du das noch ganz kurz anpassen, was Porsche in Teams gesagt hat und dann kannst du es ihnen eigentlich auch direkt schicken

**2025-09-05 14:14:26** - Julia:
> So?

IAA 2025: Porsche live.
Von Klassik bis Zukunft – im Open Space am Wittelsbacherplatz (WB200) erwartet euch ein Erlebnis, kein Messestand.

**2025-09-05 14:15:03** - Julia H.:
> Und die englische subline noch oder?

**2025-09-05 14:49:05** - Julia:
> Aso ja klar:

*IAA 2025: Porsche live.*
*Von Klassik bis Zukunft – im Open Space am Wittelsbacherplatz (WB200) erwartet euch ein Erlebnis, kein Messestand.*

*Join the spectacle – Porsche at IAA'25*

Oder wollen sie den Abbinder als HL? Sorry ich checks nicht ganz.

*Join the spectacle – Porsche at IAA'25*
*Von Klassik bis Zukunft: im Open Space am Wittelsbacherplatz (WB200) erwartet euch ein Erlebnis, kein Messestand.*

**2025-09-05 14:54:41** - Julia:
> 

**2025-09-05 15:09:50** - Julia:
> PDF ist abgelegt: <https://drive.google.com/drive/folders/1Uqfsv2dzOxUL2lpnQUGXIqSmga7tscPP>

**2025-09-05 15:10:05** - Julia H.:
> thank you!!

**2025-09-05 15:15:30** - Julia:
> Noch eine Frage:

**2025-09-05 15:15:55** - Julia:
> Soll ich die Hintergrundfarbe vom KV an das IG Highlight anpassen? Das ist ja heller. Oder muss ich bei der Farbe bleiben?

**2025-09-05 15:17:18** - Julia:
> wie ist denn der code? komme nicht ins meeting

**2025-09-05 15:20:38** - Julia H.:
> Jetzt an der Besprechung teilnehmen&lt;<https://teams.microsoft.com/l/meetup-join/19%3ameeting_MzRhYjE3YzEtNWRhYS00ZjExLWI2MzAtY2YwMTE2YTFmODg4%40thread.v2/0?context=%7b%22Tid%22%3a%2256564e0f-83d3-4b52-92e8-a6bb9ea36564%22%2c%22Oid%22%3a%22069f44dc-12d5-4b74-b981-85c42934b025%22%7d>&gt;
Besprechungs-ID: 394 298 083 006
Kennung: VM2AW9aq
______________________

**2025-09-05 15:20:44** - Julia H.:
> Schau mal ob es so geht

**2025-09-05 15:20:59** - Julia H.:
> Ja gute Frage... Bin ehrlichgesagt not sure... Würde bei der Farbe vom KV bleiben

**2025-09-05 15:22:56** - Julia:
> es geht nicht

**2025-09-05 15:23:07** - Julia H.:
> Strange...

**2025-09-05 15:23:17** - Julia H.:
> Dann scheiß drauf, ich geb die Infos dann halt weiter

**2025-09-05 15:23:25** - Julia:
> standbild

**2025-09-05 15:23:34** - Julia:
> ich versuchs noch dauernd

**2025-09-05 15:26:41** - Julia H.:
> ok chillig.

**2025-09-05 15:27:10** - Julia:
> :face_with_peeking_eye: farbattacken super

**2025-09-05 15:28:35** - Julia H.:
> Hanna hat dir den Invite nochmal weitergeleitet glaub ich

**2025-09-05 15:29:52** - Julia H.:
> 

**2025-09-05 15:29:54** - Julia H.:
> wow

**2025-09-05 15:30:04** - Julia H.:
> ich weiß nicht wieso, aber hiermit hab ich nicht gerechnet

**2025-09-05 15:34:27** - Julia:
> ne ich komme einfach nicht rein

**2025-09-05 15:34:40** - Julia:
> nee ich auch nicht

**2025-09-05 15:36:13** - Julia H.:
> egal, ist wirklich nciht so wild.

**2025-09-05 15:36:16** - Julia H.:
> ich hol dich ab

**2025-09-05 15:36:23** - Julia H.:
> ist wirklich nur fluchtwege etc.

**2025-09-05 15:36:49** - Julia:
> okay.. sorry!

**2025-09-05 15:36:57** - Julia H.:
> <https://boldcreators-my.sharepoint.com/:x:/g/personal/roxanne_rittmann_boldcreatorsclub_com/EeybJfTf8tRGmbMYw6FKGgMBTa6vHhrizt_rK7wBmB92hg?rtime=A6kAHIHs3Ug|https://boldcreators-my.sharepoint.com/:x:/g/personal/roxanne_rittmann_boldcreatorsclub_com/[…]GmbMYw6FKGgMBTa6vHhrizt_rK7wBmB92hg?rtime=A6kAHIHs3Ug>
Schau mal Roxanne hat Captions schon gemacht, ich schau mal drüber und würde es in die Google Präsi packen. Oder willst du zuerst auch noch drüber schauen?

**2025-09-05 15:38:24** - Julia H.:
> viel trinken!!

**2025-09-05 15:41:00** - Julia H.:
> 

**2025-09-05 15:42:00** - Julia:
> Manno, wollte Karussell fahren

**2025-09-05 15:44:34** - Julia H.:
> same. sehr enttäuschend

**2025-09-05 15:59:56** - Julia:
> <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BE57B0967-DF14-4D65-A137-58646F317C64%7D&amp;file=250903_IAA_Hospitality_FD.pptx&amp;fromShare=true&amp;action=edit&amp;mobileredirect=true&amp;previoussessionid=3b44bf06-5a18-7b53-8dd8-95b1918d23dd&amp;wdOrigin=TEAMS-MAGLEV.p2p_ns.rwc&amp;wdExp=TEAMS-TREATMENT&amp;wdhostclicktime=1756982116144&amp;web=1|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BE57B09[…]wdExp=TEAMS-TREATMENT&amp;wdhostclicktime=1756982116144&amp;web=1>

**2025-09-05 16:00:49** - Julia:
> Die Grafik fehlt uns leider. wir haben zwar die Indesign Datei aber ohne ins Detail gehen zu wollen: die Indesign Datei ist nicht verpackt (so nennt man das). Wodurch alle Verknüpfungen fehlen und diese nur pixelig sind.
Können wir die Grafik von der Agentur bekommen?

**2025-09-05 16:07:12** - Julia:
> aber nur ab und zu oder?

**2025-09-05 16:41:10** - Julia H.:
> niiice danke! Ich frag es an, aber so würd ich es mal rausschicken.

**2025-09-05 16:41:28** - Julia H.:
> Ja ich glaub sie hat nicht alles geschafft, sie hatte ja nur 2 stunden

**2025-09-05 16:54:41** - Julia H.:
> Wie machen wir weiter mit den Captions?

**2025-09-05 16:54:58** - Julia H.:
> Teaser Reel ist schon gescheduled für morgen, hab ich auch in die Präsi gepackt,

**2025-09-05 16:55:46** - Julia:
> bin dran. würde es mit orange markieren was ich verbessert hab

**2025-09-05 17:00:16** - Julia:
> hier versteh ich den Inhalt nicht. Das ist ja nicht das Grid, das ich eben erstellt habe, oder?

**2025-09-05 17:09:49** - Julia H.:
> Top, dann kann ich die ja schon mal hinzufügen

**2025-09-05 17:10:50** - Julia:
> bei den lila markierten weiß ich nicht von wem diese sind

**2025-09-05 17:17:03** - Julia:
> okay bin durch

**2025-09-05 17:36:06** - Julia:
> Mert legt seine Slides gleich ab

**2025-09-05 17:41:31** - Julia:
> brauchst du noch was von mir? sonst würde ich mich langsam ausloggen

**2025-09-05 17:42:08** - Julia H.:
> Danke dir!!

**2025-09-05 17:42:13** - Julia H.:
> Ich füge gerade in die andere Liste ein

**2025-09-05 17:42:21** - Julia H.:
> ab jetzt arbeiten wir wieder hier rein.

**2025-09-05 17:42:53** - Julia H.:
> <https://docs.google.com/spreadsheets/d/1BfBrmXqyH3hJpWj9pltp6rzgNouuSk0JTR1sLH3c5W0/edit?gid=506520990#gid=506520990>
FYI, ich hab beim Copy Paste auch noch hier und da Anpassungen gemacht. Ich denke wir können ruhig etwas lockerer sein ab und zu.

**2025-09-05 17:43:08** - Julia H.:
> Montag müssen wir direkt in der früh weiter machen, wenn du jetzt keine Zeit mehr hast,

**2025-09-05 17:43:28** - Julia H.:
> Roxanne hat auch viel "nicht nötig" markiert, wo sicher was gebraucht wird.

**2025-09-05 17:43:54** - Julia:
> ah okay verstehe

**2025-09-05 17:44:24** - Julia:
> mach ich!

**2025-09-05 17:57:24** - Julia:
> Charly's Kommentare in der Präsi sind teilweise falsch, weils dann garnicht um Reel usw. geht :face_exhaling:

**2025-09-05 17:58:31** - Julia H.:
> which one?

**2025-09-05 18:09:33** - Julia:
> Seite 8

**2025-09-05 18:09:55** - Julia:
> Antwortest du oder soll ich? Würde dann sagen, dass wir es nochmal überarbeiten und in Ruhe durchschauen

**2025-09-05 18:40:45** - Julia H.:
> mach ich!! Danke dir

**2025-09-05 19:01:28** - Julia H.:
> Huhu eine Sache noch dann für MO: Das konnte man nicht aus den offenen Daten ziehen oder?

**2025-09-08 07:51:04** - Julia:
> Hello! :slightly_smiling_face: Ne eben nicht. Das meinte ich damit:
Die Grafik fehlt uns leider. wir haben zwar die Indesign Datei aber ohne ins Detail gehen zu wollen: die Indesign Datei ist nicht verpackt (so nennt man das). Wodurch alle Verknüpfungen fehlen und diese nur pixelig sind.
Können wir die Grafik von der Agentur bekommen?

**2025-09-08 07:53:30** - Julia:
> Würde mir jetzt die Caption Texte anschauen, oder hast du schon alle verbessert?

**2025-09-08 09:22:09** - Julia:
> Bin durch :slightly_smiling_face: habs wieder in orange markiert.

**2025-09-08 09:24:34** - Julia H.:
> Good morning,
In der Liste von Roxanne oder in dem google sheet?

**2025-09-08 09:25:09** - Julia H.:
> Wann kommst du ins office?

**2025-09-08 09:25:15** - Julia H.:
> Oder kommst du direkt zur IAA?

**2025-09-08 09:26:16** - Julia:
> hier <https://docs.google.com/spreadsheets/d/1BfBrmXqyH3hJpWj9pltp6rzgNouuSk0JTR1sLH3c5W0/edit?gid=506520990#gid=506520990>

**2025-09-08 09:26:43** - Julia:
> Sitze im Bus und komme ins Büro :slightly_smiling_face: wollte heute morgen zuerst die Texte ready machen

**2025-09-08 09:27:07** - Julia:
> Bin in ca. 20 Minuten im Office

**2025-09-08 09:42:25** - Julia H.:
> Niiiice bis gleich

**2025-09-08 11:26:14** - Julia:
> ich weiß leider nicht welche das ist

**2025-09-08 11:28:38** - Julia H.:
> this one

**2025-09-09 11:46:43** - Julia:
> Porsche @ IAA 2025: Unter einem überdimensionalen Wappen wartet ein *echtes Festival-Feeling* – Weltpremiere des 911 Turbo S, neue Cayenne & Taycan Black Edition, limitierter 911 Spirit 70, Probefahrten mit Taycan & Macan, Family-Area mit Karussell & Coffee-Bar, Sonderwunsch-Unikat & exklusive Lifestyle-Kollektion. *Wittelsbacherplatz wird zum Porsche-Playground für Groß & Klein*

**2025-09-09 11:50:00** - Julia:
> Porsche macht den Wittelsbacherplatz zum Erlebnis: Unter dem ikonischen Wappen feiern wir die Weltpremiere des 911 Turbo S, zeigen Black Editions, exklusive Unikate &amp; laden zu Taycan- und Macan-Probefahrten ein. Mit Family-Area, Coffee-Bar &amp; Festival-Vibes wird die IAA zum Treffpunkt für alle Porsche Fans

**2025-09-09 16:06:10** - Julia H.:
> 911 Turbo S (WLTP, vorläufige Werte) Kraftstoffverbrauch kombiniert: 11,8 – 11,6 l/100 km; CO2-Emissionen kombiniert: 266 – 262 g/km; CO2-Klasse: G

**2025-09-09 16:09:39** - Julia H.:
> Cayenne E-Hybrid Black Edition (WLTP): Kraftstoffverbrauch gewichtet kombiniert: 4,5 – 4,1 l/100 km; Kraftstoffverbrauch bei entladener Batterie kombiniert: 10,6 – 10,1 l/100 km; Stromverbrauch gewichtet kombiniert: 19,7 – 19,3 kWh/100 km; CO₂-Emissionen gewichtet kombiniert: 101 – 93 g/km; CO₂-Klasse gewichtet kombiniert: C – B; CO₂-Klasse bei entladener Batterie: G; Stand 09/2025

**2025-09-09 16:25:38** - Julia H.:
> 911 Spirit 70 (WLTP): Kraftstoffverbrauch kombiniert: 10,9 – 10,7 l/100 km; CO₂-Emissionen kombiniert: 246 – 242 g/km; CO₂-Klasse: G; Stand 09/2025

**2025-09-09 16:26:05** - Julia H.:
> Taycan GTS (WLTP): Stromverbrauch kombiniert: 20,1 – 17,7 kWh/100 km; CO₂-Emissionen kombiniert: 0 g/km; CO₂-Klasse: A; Stand 09/2025

**2025-09-09 16:26:19** - Julia H.:
> 911 Spirit 70 (WLTP): Kraftstoffverbrauch kombiniert: 10,9 – 10,7 l/100 km; CO₂-Emissionen kombiniert: 246 – 242 g/km; CO₂-Klasse: G;
Taycan GTS (WLTP): Stromverbrauch kombiniert: 20,1 – 17,7 kWh/100 km; CO₂-Emissionen kombiniert: 0 g/km; CO₂-Klasse: A; Stand 09/2025

**2025-09-09 17:30:31** - Julia H.:
> Macan 4 (WLTP): Stromverbrauch kombiniert: 21,1 – 17,9 kWh/100 km; CO₂-Emissionen kombiniert: 0 g/km; CO₂-Klasse: A; Stand 09/2025

**2025-09-09 17:31:05** - Julia H.:
> 911 GT3 mit Touring-Paket (WLTP): Kraftstoffverbrauch kombiniert: 13,8 l/100 km; CO₂-Emissionen kombiniert: 312 g/km; CO₂-Klasse: G; Stand 09/2025

**2025-09-09 18:39:54** - Julia:
> <https://drive.google.com/drive/folders/1Uqfsv2dzOxUL2lpnQUGXIqSmga7tscPP>

**2025-09-09 18:54:49** - Julia:
> Closing Dienstag: <https://drive.google.com/drive/folders/1wRGutm1H6dYpnA3OHCiiqF0LpldogWVR>

Daily Mittwoch: <https://drive.google.com/drive/folders/1w7yZgrv6YibPDeNBCIjEh1cRc23UfO2A>

**2025-09-09 20:29:24** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/jA3b9Y9UHj?filterflags=orange&amp;file=24c7d0802e2269dae7c203530842771e>

**2025-09-09 20:41:32** - Julia:
> CONTENT FÜR MORGEN FRÜH:
<https://drive.google.com/drive/folders/1w7yZgrv6YibPDeNBCIjEh1cRc23UfO2A>

**2025-09-10 10:40:34** - Julia:
> 

**2025-09-10 11:16:31** - Julia:
> TINS DAY Reminder

**2025-09-10 11:26:39** - Julia:
> <https://drive.google.com/drive/folders/1r4jfvm_vTiPiAiCv0-YFPIHCNZpq6pWk>

**2025-09-10 12:12:25** - Julia:
> 

**2025-09-10 12:16:24** - Julia:
> 

**2025-09-10 12:19:28** - Julia:
> 

**2025-09-10 12:31:03** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland:collections/vcQLJQR7KD>

**2025-09-10 12:38:19** - Julia H.:
> 

**2025-09-10 13:58:09** - Julia:
> Background Picture Repost Story

**2025-09-10 14:01:36** - Julia:
> 

**2025-09-10 15:00:53** - Julia:
> 

**2025-09-10 15:03:42** - Julia H.:
> 911 Turbo S Cabriolet (WLTP, vorläufige Werte) Kraftstoffverbrauch kombiniert: 11,8 – 11,7 l/100 km; CO2-Emissionen kombiniert: 267 – 265 g/km; CO2-Klasse: G

**2025-09-10 15:04:34** - Julia:
> 

**2025-09-10 15:06:57** - Julia:
> 

**2025-09-10 15:32:52** - Julia:
> 

**2025-09-10 16:17:34** - Julia H.:
> Das Turbo-Gefühl fürs Handgelenk

**2025-09-10 16:18:34** - Julia H.:
> Chronograph 911 Turbo S Exclusive Series

**2025-09-10 16:20:54** - Julia:
> 

**2025-09-10 16:27:35** - Julia:
> 

**2025-09-10 16:30:03** - Julia:
> Vorschlag: Charly hier vorwarnen, dass es getrennt werden musste

**2025-09-10 16:30:58** - Julia:
> 

**2025-09-10 16:37:41** - Julia H.:
> Für Notiz: gibt noch kein Konzept für recap reel 

**2025-09-10 17:02:22** - Julia H.:
> Vielleicht auch am Ende mal recapped wie viele Bilder wir am Ende von Flo benutzt haben und wie viele von vincent 

**2025-09-10 17:02:38** - Julia:
> ICH HAB ES MIR GERADE GEDACHT

**2025-09-10 17:02:47** - Julia:
> "ich benutze nur bilder von flo"

**2025-09-10 17:15:00** - Julia H.:
> Naja to be fair es gibt ja auch Nicht viele andere 

**2025-09-10 17:29:38** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/pg9NMJNaXr?file=496bf016b0aed1eb252be4f7c1aa2107>

**2025-09-10 17:37:14** - Julia:
> Thumbnail Ersatz Vorschlag --&gt; Das dunkle geht nicht, auch nicht zum verlängern

**2025-09-10 17:38:51** - Julia:
> Closing heute:

**2025-09-10 17:55:56** - Julia:
> thumbnail reel

**2025-09-10 18:14:33** - Julia H.:
> *IAA-Showcar mit innovativem Leuchtlack*

**2025-09-10 18:35:20** - Julia:
> 

**2025-09-10 18:49:10** - Julia:
> Die souveränste Art Porsche 911 zu fahren: der neue 911 Turbo S.
_
911 Turbo S (WLTP, vorläufige Werte) Kraftstoffverbrauch kombiniert: 11,8 – 11,6 l/100 km;
CO2-Emissionen kombiniert: 266 – 262 g/km; CO2-Klasse: G; Stand 09/2025

**2025-09-10 18:57:40** - Julia:
> Der Einzige der sich mit einem 911 messen kann: der neue 911 Turbo S.
_
911 Turbo S (WLTP, vorläufige Werte) Kraftstoffverbrauch kombiniert: 11,8 – 11,6 l/100 km;
CO2-Emissionen kombiniert: 266 – 262 g/km; CO2-Klasse: G; Stand 09/2025

**2025-09-11 10:23:52** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/5pfYY518DE?file=06aca4330f66e9cfc4575722acc70db9>

**2025-09-11 10:26:18** - Julia H.:
> haben die nicht gestern auch gesagt sie haben soo viele coole kinder fotos? das sind halt 3

**2025-09-11 10:33:54** - Julia H.:
> <https://newsroom.porsche.com/de/2025/produkte/porsche-wireless-charging-induktives-laden-40408.html>

**2025-09-11 11:24:00** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/Jowy4qmLZY?file=3a4d9cfc95b5a0a20224d8a99cc54ca6> --> Fahrrad für heute noch Probefahrten

**2025-09-11 11:25:03** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/Jowy4qmLZY?file=09c7bf8f56dfc08e26753bc9bdb83fbe> Macan

**2025-09-11 11:25:19** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/Jowy4qmLZY?file=fe8a5ac7c3d2429ac42ca0e49d1fd410>

**2025-09-11 11:27:38** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/jA3b9Y9UHj?file=274a6d0806683bed84bcdaba78e4c426>

**2025-09-11 11:29:42** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/5pfYY518DE?file=b7bb1fc24ece9cbfc11aab8ec544a7eb>

**2025-09-11 11:35:42** - Julia:
> 

**2025-09-11 11:42:17** - Julia H.:
> Macan 4 (WLTP): Stromverbrauch kombiniert: 21,1 – 17,9 kWh/100 km; CO₂-Emissionen kombiniert: 0 g/km; CO₂-Klasse: A; Stand 09/2025

Taycan GTS (WLTP): Stromverbrauch kombiniert: 20,1 – 17,7 kWh/100 km; CO₂-Emissionen kombiniert: 0 g/km; CO₂-Klasse: A; Stand 09/2025

**2025-09-11 11:51:52** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/RYNG8Ti72A?file=631f104fa127db20c56fd1256f01edae>

**2025-09-11 12:01:15** - Julia H.:
> <https://drive.google.com/drive/folders/1TJ7t7LvplEXn0FWsdLJRCU031AoUo1VS>

**2025-09-11 12:07:32** - Julia:
> 

**2025-09-11 12:12:25** - Julia:
> 

**2025-09-11 12:35:32** - Julia:
> Überraschendes Feature zum neuen Cayenne Electric Prototyp.

**2025-09-11 12:41:50** - Julia H.:
> 

**2025-09-11 15:02:29** - Julia:
> 

**2025-09-11 17:07:00** - Julia:
> zeigen wir jetzt am handy das Atmo Schnitt video? was wir gut fänden?

**2025-09-11 18:27:43** - Julia H.:
> <https://docs.google.com/document/d/1hQJ7vNH93pcsNBzZ4LXTsW259HACQD-f3MnQd4y5lxQ/edit?tab=t.0>

**2025-09-11 19:31:32** - Julia H.:
> Mehr als Individualisierung – Sonderwunsch ist pure Personality auf Rädern.“
    a. „Standard war gestern. Sonderwunsch ist, wenn dein Porsche so einzigartig wird wie du.“
    b. „Sonderwunsch = Teamwork, Persönlichkeit und ein klares Statement auf vier Rädern.“
    c. „Dein Traum, kein Serienmodell. Sonderwunsch macht’s möglich.“

**2025-09-12 10:39:47** - Julia:
> Pure Personality: Der 911 Spirit und der GT3 zeigen, was Sonderwunsch bedeutet. Aus Ikonen werden Unikate – und beweisen, dass Perfektion immer noch persönlicher geht.

**2025-09-12 10:48:31** - Julia:
> Ob Tasten oder PS – Hauptsache Gefühl.

**2025-09-12 10:48:43** - Julia:
> Performance hat viele Formen.
Keys &amp; Curves

**2025-09-12 10:58:02** - Julia H.:
> 911 Spirit 70 (WLTP): Kraftstoffverbrauch kombiniert: 10,9 – 10,7 l/100 km; CO₂-Emissionen kombiniert: 246 – 242 g/km; CO₂-Klasse: G;
Taycan GTS (WLTP): Stromverbrauch kombiniert: 20,1 – 17,7 kWh/100 km; CO₂-Emissionen kombiniert: 0 g/km; CO₂-Klasse: A; Stand 09/2025

911 GT3 mit Touring-Paket (WLTP): Kraftstoffverbrauch kombiniert: 13,8 l/100 km; CO₂-Emissionen kombiniert: 312 g/km; CO₂-Klasse: G; Stand 09/2025

**2025-09-12 11:20:31** - Julia H.:
> bringt nun der 911 Spirit 70 den Vibe der Seventies und frühen Eighties zurück.

**2025-09-12 11:21:23** - Julia H.:
> Inspiriert von wehenden Zielflaggen ist das Pascha-Muster ein unverwechselbares Markenzeichen, das die Seele von Porsche in jeder Faser mit sich trägt. Erstmals zierte es 1977 das Interieur des Porsche 928 – jetzt feiert es im 911 Spirit 70 ein Comeback.

**2025-09-12 12:01:34** - Julia H.:
> Luxemburger Löwe, Hymnenzeilen, „Vive“ im Detail – Sonderwunsch at its finest.

**2025-09-12 12:03:08** - Julia H.:
> :fire: 700 Stunden, ein Löwe: die aufwendigste Sonderwunsch-Lackierung aller Zeiten.

2.
Von Hand aufgetragen, über 20 Schritte – ein Löwe in Eisgrau &amp; Feuerrot. :lion_face::sparkles:

3.
Exterieur als Kunstwerk: Löwen-Grafik über Haube, Türen und Dach.

**2025-09-12 12:08:37** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/Jowy4qmLZY?file=783e036c8806a94a4e7127cf80023cc8>

**2025-09-12 12:09:32** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/jA3b9Y9UHj?file=73429c3b4d17cc39de331c7387d29865>

**2025-09-12 12:16:53** - Julia H.:
> 

**2025-09-12 12:28:46** - Julia H.:
> Beats, Lights, Porsche Nights.

**2025-09-12 12:41:00** - Julia H.:
> Porsche Lëtzebuerg Legacy GT3 Touring

**2025-09-12 14:36:10** - Julia:
> 70s Vibes bis ins kleinste Detail.

-
911 Spirit 70 (WLTP): Kraftstoffverbrauch kombiniert: 10,9 – 10,7 l/100 km; CO₂-Emissionen kombiniert: 246 – 242 g/km; CO₂-Klasse: G; Stand 09/2025

**2025-09-12 14:38:23** - Julia:
> Lackiert, bestickt, geprägt: Sonderwunsch at its finest.

-
911 GT3 mit Touring-Paket (WLTP): Kraftstoffverbrauch kombiniert: 13,8 l/100 km; CO₂-Emissionen kombiniert: 312 g/km; CO₂-Klasse: G; Stand 09/2025

**2025-09-12 15:25:26** - Julia:
> Post Malone: (Intro too long) <https://www.tiktok.com/@lifeonfilm.27/video/7480270365785132319>

**2025-09-12 15:26:40** - Julia:
> Ed Sheeran: <https://www.tiktok.com/@lifeonfilm.27/video/7415306562585054494>

**2025-09-12 17:17:52** - Julia H.:
> Passt alles?

**2025-09-12 17:45:03** - Julia:
> Handwerkskunst trifft Handwerkskunst: Porsche x Steinway

-
911 Spirit 70 (WLTP): Kraftstoffverbrauch kombiniert: 10,9 – 10,7 l/100 km; CO₂-Emissionen kombiniert: 246 – 242 g/km; CO₂-Klasse: G; Stand 09/2025

**2025-09-12 17:50:14** - Julia:
> WAS WAR MIT D

**2025-09-13 13:37:17** - Julia:
> 911 Spirit 70 (WLTP): Kraftstoffverbrauch kombiniert: 10,9 – 10,7 l/100 km; CO₂-Emissionen kombiniert: 246 – 242 g/km; CO₂-Klasse: G; Stand 09/2025

**2025-09-13 13:40:37** - Julia H.:
> @forddeutschland
@bmw
@mercedesbenzmuseum
@smart_worldwide
@vw
@ford
@porschedesign
@audi_de
@audi
@iaamobility
@audi_de
@audi
@iaamobility
@volkswagen
@lucidmotors
@mercedesbenz_de
@bmwdeutschland
@mercedesmaybach
@porsche.lifestyle
@denza.europe

**2025-09-13 15:51:12** - Julia:
> #PorscheFamily Portrait @ PORSCHE. THERE IS NO SUBSTITUTE. DAY
POV: Giving a camera to a stranger.

-
911 Spirit 70 (WLTP): Kraftstoffverbrauch kombiniert: 10,9 – 10,7 l/100 km; CO₂-Emissionen kombiniert: 246 – 242 g/km; CO₂-Klasse: G; 911 Turbo S Cabriolet (WLTP, vorläufige Werte): Kraftstoffverbrauch kombiniert: 11,8 – 11,7 l/100 km; CO₂-Emissionen kombiniert: 267 – 265 g/km; CO₂-Klasse: G; Stand 09/2025

**2025-09-13 19:05:30** - Julia:
> <https://www.figma.com/design/7P5fTRcISCX1xDyTeA0TCr/IAA-Content?node-id=129-91&amp;t=RQkcagZei8IkHDjj-1>

**2025-09-13 19:15:32** - Julia H.:
> Cayenne Turbo E-Hybrid (WLTP): Kraftstoffverbrauch gewichtet kombiniert: 5,3 – 4,8 l/100 km; Kraftstoffverbrauch bei entladener Batterie kombiniert: 11,9 – 11,3 l/100 km; Stromverbrauch gewichtet kombiniert: 20,4 – 20,0 kWh/100 km; CO₂-Emissionen gewichtet kombiniert: 119 – 108 g/km; CO₂-Klasse gewichtet kombiniert: D – C; CO₂-Klasse bei entladener Batterie: G; Stand 09/2025

911 Spirit 70 (WLTP): Kraftstoffverbrauch kombiniert: 10,9 – 10,7 l/100 km; CO₂-Emissionen kombiniert: 246 – 242 g/km; CO₂-Klasse: G; 911 Turbo S Cabriolet (WLTP, vorläufige Werte): Kraftstoffverbrauch kombiniert: 11,8 – 11,7 l/100 km; CO₂-Emissionen kombiniert: 267 – 265 g/km; CO₂-Klasse: G; Stand 09/2025

718 Cayman GT4 RS (WLTP): Kraftstoffverbrauch kombiniert: 13,0 l/100 km; CO₂-Emissionen kombiniert: 295 g/km; CO₂-Klasse: G; Stand 09/2025

**2025-09-13 20:13:02** - Julia H.:
> OOOOPFER

**2025-09-13 20:13:57** - Julia H.:
> 

**2025-09-13 20:14:18** - Julia H.:
> 

**2025-09-13 20:42:03** - Julia:
> Im Rahmen der IAA beim Porsche. There is no substitute. Day. hat die #PorscheFamily gezeigt, was sie ausmacht.
Porsche Klassiker, gute Gespräche, Zusammenhalt. Einfach - good vibes only.

-
911 Spirit 70 (WLTP): Kraftstoffverbrauch kombiniert: 10,9 – 10,7 l/100 km; CO₂-Emissionen kombiniert: 246 – 242 g/km; CO₂-Klasse: G; 911 Turbo S Cabriolet (WLTP, vorläufige Werte): Kraftstoffverbrauch kombiniert: 11,8 – 11,7 l/100 km; CO₂-Emissionen kombiniert: 267 – 265 g/km; CO₂-Klasse: G;
Cayenne Turbo E-Hybrid (WLTP): Kraftstoffverbrauch gewichtet kombiniert: 5,3 – 4,8 l/100 km; Kraftstoffverbrauch bei entladener Batterie kombiniert: 11,9 – 11,3 l/100 km; Stromverbrauch gewichtet kombiniert: 20,4 – 20,0 kWh/100 km; CO₂-Emissionen gewichtet kombiniert: 119 – 108 g/km; CO₂-Klasse gewichtet kombiniert: D – C; CO₂-Klasse bei entladener Batterie: G; Stand 09/2025

**2025-09-13 21:15:18** - Julia H.:
> *STORIES MONDAY*

*OMR; Side Events, Basti, Robert, BTS*


<https://www.picdrop.com/porsche-deutschland/g7RXYSxF1U?file=0eae4345efdb0ae6050a58fd974adce0>

**2025-09-13 21:29:30** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/jA3b9Y9UHj?file=0a74cf6cd73ac85d025652977f1ba101>

**2025-09-14 09:01:21** - Julia:
> GuMooo

**2025-09-14 18:30:31** - Julia:
> <https://drive.google.com/drive/folders/1MzsPnc1S_2OJ68Em_3xM_jcbcjXmdrNO>

**2025-09-17 11:57:49** - Julia:
> Hilfe, was soll ich hier machen?

**2025-09-17 12:00:41** - Julia H.:
> Erstmal kurz durchlesen, ganz untern steht ein potenzielles to do.

**2025-09-17 12:01:12** - Julia:
> Aso wegen Content entwickeln

**2025-09-17 12:01:17** - Julia:
> Ja hab ich in der mail gelesen :slightly_smiling_face:

**2025-09-17 12:06:23** - Julia H.:
> Ja genau.... Aber ist auch einfach nur wichtig, dass wir alle den Wechsel und die neuen Infos auf dem Schirm haben. Glaub aber da kommt momentan eh ncihts

**2025-09-17 12:09:20** - Julia:
> okee

**2025-09-17 12:30:45** - Julia:
> Und was wir halt bei slide 1 haben - bitte achtet darauf dass das Bild ausgerichtet ist. Aktuell ist es links nicht parallel.

Was meint sie hier?

**2025-09-17 12:37:25** - Julia:
> geklärt

**2025-09-17 12:41:15** - Julia:
> Hier schon mal die Slides, je nachdem, ob Charly noch etwas angepasst haben will oder nicht:
<https://drive.google.com/drive/folders/1RNzMHprIul_wKUoMmvm8KHdLbuLVJPUQ>

**2025-09-17 13:44:17** - Julia:
> Juliaaaa

**2025-09-17 13:44:25** - Julia:
> Das ist der "normale" Cayenne oder?

**2025-09-17 13:44:36** - Julia:
> 

**2025-09-17 13:48:41** - Julia H.:
> 

**2025-09-17 13:49:32** - Julia:
> hab dich gehört, oh maaan

**2025-09-17 13:49:47** - Julia H.:
> Ich dich auch 

**2025-09-17 13:49:54** - Julia H.:
> Egal slack call ist doof

**2025-09-17 13:50:07** - Julia H.:
> Cayenne hab ich null idea

**2025-09-17 13:50:11** - Julia H.:
> Eventuell kann Flo helfen 

**2025-09-17 13:50:32** - Julia:
> okay ich frag ihn

**2025-09-17 13:50:36** - Julia H.:
> Ich glaub da müssen auch eigentlich keine drauf weil man nicht erkennt welcher er ist

**2025-09-17 13:51:10** - Julia:
> Hatte sie in whatsapp geschrieben

**2025-09-17 13:52:06** - Julia H.:
> Hab ich gesehen aber ich bin da unsicher 

**2025-09-17 13:52:17** - Julia H.:
> 

**2025-09-17 13:52:24** - Julia:
> ich sowieso :smile:

**2025-09-17 13:52:26** - Julia H.:
> ich mein eventuell erkennt man da was am heck aber ich glaube nicht

**2025-09-17 13:52:44** - Julia:
> ich hab keine Ahnung

**2025-09-17 13:55:33** - Julia:
> Soll ich es mal mit VBWs einfach reinschicken?

**2025-09-17 13:55:37** - Julia:
> sicher ist sicher

**2025-09-17 13:56:02** - Julia H.:
> Ja können wir machen aber ich frag mal

**2025-09-17 13:59:12** - Julia:
> dankeee!!

**2025-09-17 14:04:20** - Julia:
> Hier nochmal mit den Updates: <https://drive.google.com/drive/folders/1RNzMHprIul_wKUoMmvm8KHdLbuLVJPUQ>

**2025-09-17 14:09:28** - Julia H.:
> welcher sticker kommt wo genau hin?

**2025-09-17 14:11:28** - Julia:
> hier. hätte jetzt den Fragesticker genommen und geschrieben:

Dein Tipp:

**2025-09-17 14:12:33** - Julia H.:
> Was war mit ihr besprochen als Sticker?

**2025-09-17 14:12:47** - Julia H.:
> Ja/Nein wäre leichter denk ich, dann müssen wir nicht monitoren was die leute schreiben

**2025-09-17 14:13:00** - Julia:
> Ne sie wollte den "offenen"

**2025-09-17 14:13:03** - Julia H.:
> bzw will sie bei frage stickern immer eine auflösung

**2025-09-17 14:13:09** - Julia H.:
> oh mann ok

**2025-09-17 14:13:10** - Julia:
> Also wo Leute ihre Antworten reinschreiben

**2025-09-17 14:13:36** - Julia H.:
> yep ok

**2025-09-17 14:13:59** - Julia:
> "Umfragesticker offen"

**2025-09-17 14:14:06** - Julia H.:
> ok

**2025-09-17 14:16:32** - Julia H.:
> charly ist ganz schlimm mit korrekturschleifen, da müssen wir mal schauen, wie wir das optimieren können

**2025-09-17 14:17:02** - Julia:
> das ist echt HART

**2025-09-17 14:17:05** - Julia:
> Also

**2025-09-17 14:17:16** - Julia:
> ich bin der deutschen Sprache mächtig

**2025-09-17 14:17:30** - Julia:
> :smile:

**2025-09-17 14:18:56** - Julia:
> ich glaubs nicht

**2025-09-17 14:20:48** - Julia H.:
> ja sie ist halt auch immer so übertrieben akkurat wir müssen ihr das austreiben

**2025-09-17 14:20:58** - Julia H.:
> denke mal jetzt neue routine und mehr vertrauen werden helfen

**2025-09-17 14:22:32** - Julia:
> ich glaube die brauchen mehr input.
Also sowas wie:

Visuell: Bildausschnitt wurde gedreht, Ansicht nur so möglich wegen Lesbarkeit
Slide 7: unserer Meinung nach keine VBWs notwendig, aber checkt das gerne nochmal
Texte: alle grammatikalisch durch GPT gejagt – passt alles

**2025-09-17 14:22:49** - Julia H.:
> ich stell jetzt onlne prüfst du bitte kurz mit? ich war jetzt nur so halb am mitlesen weil ich heute ja eigentlich off bin

**2025-09-17 14:22:51** - Julia:
> Also, dass man ihnen zu jeder einzelnen Slide erklärt wieso, weshalb, warum

**2025-09-17 14:23:07** - Julia:
> Achsooo du bist off? Das hab ich nicht verstanden sorry

**2025-09-17 14:25:11** - Julia H.:
> no pron

**2025-09-17 14:25:16** - Julia H.:
> alles online jetzt tagge ich noch

**2025-09-17 14:25:31** - Julia:
> perfekt, danke!

**2025-09-17 14:25:42** - Julia:
> Bist du morgen dann wirklich off, oder?

**2025-09-17 14:28:13** - Julia H.:
> ich bin eigentlich nur morgens mal 1-2 stunden on damti ich blicke was so ansteht

**2025-09-17 14:28:26** - Julia H.:
> mit bildanschnitten ist sie super empfindlich

**2025-09-17 14:28:34** - Julia:
> ich check garnichts mehr

**2025-09-17 14:28:38** - Julia:
> das ist doch nicht ihr ernst

**2025-09-17 14:29:56** - Julia H.:
> das ist bei ihr immer so

**2025-09-17 14:29:58** - Julia H.:
> imemr

**2025-09-17 14:30:11** - Julia H.:
> 2000 mal hin und her uns anschnitt und gerade und akkurat

**2025-09-17 14:30:24** - Julia:
> ich bin gerade wirklich, wirklich sprachlos

**2025-09-17 14:30:25** - Julia H.:
> obwohl sie es schon gesehen hatte und dann schickt sie ihr feedback immer nur gestückelt

**2025-09-17 14:32:43** - Julia:
> krass

**2025-09-17 14:32:49** - Julia:
> wirklich krass

**2025-09-17 14:33:00** - Julia H.:
> yup

**2025-09-17 14:33:18** - Julia H.:
> da muss sich dringend was ändern. vor allem mit Prozess wie wir feedbacken

**2025-09-17 14:33:31** - Julia H.:
> hilft auch wenn du das flo nochmal aus deiner perspektive sagst

**2025-09-17 14:33:39** - Julia:
> ja mach ich

**2025-09-17 14:33:44** - Julia:
> bin wirklich schockiert :smile:

**2025-09-17 14:34:04** - Julia:
> Also sorry to say: aber wir sind ja nicht nur irgendwelche Pixelschubser

**2025-09-17 14:34:14** - Julia H.:
> Doch für Charly schon.

**2025-09-17 14:34:33** - Julia:
> puh

**2025-09-17 14:34:43** - Julia H.:
> :stuck_out_tongue: Aber das wird sich sicher ändern

**2025-09-17 14:35:04** - Julia:
> :exploding_head:

**2025-09-17 14:36:09** - Julia:
> Vllt wäre es auch ganz smart, wenn ich sobald Charly wieder da ist, was zum Feedback Prozess sage und in einem meeting halt sage wie das sonst abläuft, eine Feedback Runde und nicht hin und her, da wir da garnicht die Kapazität haben..?

**2025-09-17 14:37:45** - Julia H.:
> Ja wir wollten da eh mal einen prozess aufsetzen...

**2025-09-17 14:39:27** - Julia:
> krass krass krass

**2025-09-18 09:46:25** - Julia H.:
> Good morning, how are you? Hättest du evtl Zeit ein Meeting mit Hanna um 10:30 zu joinen? Denke mal wir sprechen evtl über die Events.

**2025-09-18 09:50:34** - Julia:
> Hello! ja klar

**2025-09-18 09:50:51** - Julia:
> ich komme zum Termin jetzt evtl. 5 min später

**2025-09-18 09:50:57** - Julia H.:
> no prob

**2025-09-18 10:25:23** - Julia H.:
> Microsoft Teams Need help?&lt;<https://aka.ms/JoinTeamsMeeting?omkt=en-US>&gt;
Join the meeting now&lt;<https://teams.microsoft.com/l/meetup-join/19%3ameeting_ZTM0MTEzN2UtYzc4ZC00YzIwLWE0YzAtZDA5NTUyNTFmNTM3%40thread.v2/0?context=%7b%22Tid%22%3a%2254545b25-e3ed-4f76-9665-e6a7a09c0152%22%2c%22Oid%22%3a%22cf70d133-896d-4716-9f30-21f8765a4a52%22%7d>&gt;
Meeting ID: 375 872 326 056 1
Passcode: HX6JF7dt

**2025-09-18 10:38:45** - Julia H.:
> Präsi sieht wild aus, müssen wir unbedingt mit Laetitia besprechen

**2025-09-18 10:38:56** - Julia:
> jaaa

**2025-09-18 11:17:24** - Julia H.:
> Also du siehst wir haben viele offene Themen, die wir endlich angehen müssen. Sag bescheid, wie ich dich auch supporten kann

**2025-09-18 11:17:48** - Julia:
> ja voll

**2025-09-18 11:19:27** - Julia H.:
> Müssen wir irgendwie mal priorisieren

**2025-09-18 11:19:50** - Julia:
> ich muss mich bei den themen noch bisschen reinfinden – hab dann oft keine Ahnung wovon ihr sprecht :joy:

**2025-09-18 11:20:42** - Julia H.:
> Ja verstehe, sag bitte bescheid, wenn du noch hilfe brauchst und wo ich supporten kann. Auch bei Konzepten etc... das wirst du sonst gar nicht schaffen.

**2025-09-18 11:21:09** - Julia H.:
> Würde mal versuchen heute und morgen die Sachen die relativ straight forward sind runterzuarbeiten und dann Fokus auf allgemeinere Konzepte

**2025-09-18 11:24:16** - Julia:
> mach ich

**2025-09-18 11:25:38** - Julia:
> ich würde jetzt mal die ganzen asana tasks bearbeiten und dann kann ich gerne mit den themen von gerade weitermachen (Konfiguration, Targa Geheimnisse, Grundrauschen --&gt; muss ich mir nochmal anschauen was das ist)

Retro Sunday macht wer? Da hatten wir doch eigentlich die Präsi mit 4 Wochen, oder?

**2025-09-18 11:26:16** - Julia H.:
> Yes, Retro Sunday kann ich auch sonst kurz machen

**2025-09-18 11:27:45** - Julia:
> kann ich auch – müsste nur wissen, wo so retro bilder usw. abliegen

**2025-09-18 11:27:48** - Julia:
> oder was noch fehlt

**2025-09-18 11:28:28** - Julia:
> und noch eine Frage – so diese caption (Malmedie Must Drives) die ich für Flo geschrieben hab, kommt das dann auch bei dir an? nicht, dass das jetzt unter gegangen ist

**2025-09-18 11:28:47** - Julia:
> weil er hatte mich da in der mail drum gebeten, hab ihm geantwortet und aber nochmal im asana reingeschrieben

**2025-09-18 11:29:06** - Julia:
> hab noch nicht ganz den Durchblick was Flo übernimmt und was eigentlich du etc. etc.

**2025-09-18 11:29:43** - Julia H.:
> Ne sowas kommt bei mir nicht an. Daher will ich ja auch alles über Asana machen eigentlich

**2025-09-18 11:30:01** - Julia H.:
> Ja würde ich auch gern wissen LOL

**2025-09-18 11:30:20** - Julia H.:
> Ich hatte mal eine Content Sammlung angelegt, <https://docs.google.com/spreadsheets/d/1k7r2BrvUlSJt2bcf2vKyUh8v9zd6GJRCxY47ez5oC6Q/edit?gid=0#gid=0>

**2025-09-18 11:43:12** - Julia H.:
> <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/doc2.aspx?sourcedoc=%7BA5F304E8-09BC-47AB-A30A-5A86F7C81AD3%7D&amp;file=250904_Porsche_BS_RetroSunday.pptx&amp;action=edit&amp;mobileredirect=true|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/doc2.aspx?sourcedoc=%7BA5F30[…]rsche_BS_RetroSunday.pptx&amp;action=edit&amp;mobileredirect=true>

**2025-09-18 11:43:41** - Julia H.:
> Ich hab einfach mal ein paar passende Poster reingeschmissen. Weil einige haben wir schon verwendet....

**2025-09-18 11:43:46** - Julia H.:
> Mert soll nochmal sortieren.

**2025-09-18 11:43:53** - Julia H.:
> Ich kann auch gern bei den Captions helfen

**2025-09-18 11:45:32** - Julia:
> schau ich mir gleich an, versuch kurz Christo zu verstehen :smile:
War denn dieser Look (schwarzer Schatten-Rahmen) so gewollt?

**2025-09-18 11:46:50** - Julia H.:
> keine ahnung ehrlichgesagt, aber kann ich mir nicht vorstellen, das hat eventuell Basti so gemacht

**2025-09-18 11:51:22** - Julia:
> ich erstelle mir jetzt mal kurz ein Asana Board – bin ich noch nicht dazu gekommen. muss mich mal sortieren

**2025-09-18 11:52:56** - Julia H.:
> Kein Problem, sag bescheid wenn du hilfe brauchst ja?

**2025-09-18 12:09:24** - Julia:
> 

**2025-09-18 12:17:10** - Julia H.:
> Ja du kannst Basti gerne Feedback geben!! Das ist absolut in Ordnung.

**2025-09-18 12:17:30** - Julia H.:
> Ich finde, du darfst dir das auf jeden Fall rausnehmen

**2025-09-18 12:17:39** - Julia H.:
> Ist schwierig am Anfang, i know

**2025-09-18 12:23:44** - Julia:
> okeee

**2025-09-18 12:23:46** - Julia:
> danke!

**2025-09-18 12:43:18** - Julia:
> hab Christo gefeedbackt – kannst ja gerne mal schauen :slightly_smiling_face: bin bei Feedback geben nicht unsicher, aber muss die Leute dafür einschätzen können &amp; das konnte ich bisher noch nicht.

<https://app.asana.com/1/1199360402832734/project/1211393508341245/task/1210556034500746?focus=true>

**2025-09-18 12:49:01** - Julia:
> weiß gerade nicht was es für eine aufgabe ist aber FYI:
Mache mit Mert gerade diese Posts ready + schreibe die Captions
<https://www.canva.com/design/DAGuwILJwac/V8FYbooOUuKrZbdwEwno7w/edit>

**2025-09-18 12:50:30** - Julia H.:
> Sieht super aus danke!

**2025-09-18 12:50:53** - Julia H.:
> Yess, danke!! Das ist diese hier: <https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1210932151778138?focus=true>

**2025-09-18 12:51:26** - Julia:
> paaaasst danke :slightly_smiling_face:

**2025-09-18 12:54:01** - Julia H.:
> Ich bin jetzt dann so halb off bis zum Gipfeltreffen Meeting später. Wenn du noch was brauchst dann gerne bald

**2025-09-18 12:54:16** - Julia H.:
> Ich denke Prio hätte Konzept von Laetitia und das Sunday Poster, damit Hanna das noch freigeben kann

**2025-09-18 12:55:00** - Julia:
> alright! happy day :slightly_smiling_face:
Schau ich mir an

**2025-09-18 16:16:52** - Julia H.:
> Bin wieder da

**2025-09-18 16:22:07** - Julia:
> juhuu

**2025-09-18 16:22:15** - Julia:
> hab dich in asana bei paar sachen markiert :)

**2025-09-18 16:22:42** - Julia H.:
> daaaanke schau ich mir gleich nach dem meeting an.

**2025-09-18 16:22:51** - Julia:
> perfekt :slightly_smiling_face:

**2025-09-18 16:22:53** - Julia H.:
> ich komme morgen ins büro, aber du bist ja eh noch angeschlagen :disappointed:

**2025-09-18 16:23:14** - Julia:
> ich vllt auch!

**2025-09-18 16:29:19** - Julia:
> Ne ist wieder weg, bisher immer nur morgens

**2025-09-18 16:29:20** - Julia:
> :smile:

**2025-09-18 16:43:26** - Julia:
> hab retro sunday nochmal bissl angepasst – timing

**2025-09-18 17:28:42** - Julia H.:
> Juli, ich brauch ganz kurz schnell deine Hilfe

**2025-09-18 17:28:52** - Julia:
> ja

**2025-09-18 17:29:25** - Julia H.:
> Ich hab voll vergessen, dass heute ein Post für den brandstore gescheduled wurde

**2025-09-18 17:29:37** - Julia H.:
> Da gingen gerade Stories. Raus mit Walter Röhrl. Ich habe schon überall bezahlte Werbepartner hinzugefügt.

**2025-09-18 17:29:52** - Julia:
> okay

**2025-09-18 17:30:03** - Julia H.:
> Ich glaube aber, dass wir da noch ein weiteres Story slide geplant hatten. Ich sitze jetzt nur leider im Auto.

**2025-09-18 17:30:15** - Julia H.:
> Das müsste auf dem SharePoint Brand Store unter GT drei liegen

**2025-09-18 17:30:21** - Julia:
> okay moment

**2025-09-18 17:30:41** - Julia H.:
> Also die Präsentation dazu oder glaubst du ist Mert noch da?

**2025-09-18 17:31:10** - Julia:
> hab ihm parallel geschrieben und ich suche auch, ob ich es finde

**2025-09-18 17:31:32** - Julia H.:
> Das asset müsste es geben auf unserem Drive unter Brand Store GT drei und dann Walter Konfiguration oder sowas

**2025-09-18 17:31:41** - Julia H.:
> Sorry, ich hab das total verpeilt das sollte ursprünglich gestern schon rausgehen

**2025-09-18 17:31:43** - Julia:
> okay moment

**2025-09-18 17:31:48** - Julia:
> mert schaut auch

**2025-09-18 17:32:25** - Julia H.:
> Danke danke danke

**2025-09-18 17:34:12** - Julia:
> tasten uns ran

**2025-09-18 17:35:20** - Julia:
> HABS

**2025-09-18 17:35:27** - Julia:
> 

**2025-09-18 17:36:01** - Julia:
> das wars, nur das hier fehlt

**2025-09-18 17:36:03** - Julia H.:
> OMG yay 

**2025-09-18 17:36:21** - Julia H.:
> Link schätze ich mal sowas wie hier Termin buchen

**2025-09-18 17:36:43** - Julia:
> das weiß ich nicht, hier ist nur das Asset in Drive ahhh

**2025-09-18 17:37:22** - Julia H.:
> Jetzt buchen 

**2025-09-18 17:37:35** - Julia:
> ja passt doch da voll rein

**2025-09-18 17:37:44** - Julia H.:
> Der Link geht eigentlich immer auf die gleiche Seite Daher mache ich jetzt einfach das

**2025-09-18 17:38:00** - Julia:
> kannst du es posten? ja oder? zum brand store hab ich nämlich keinen zugriff damals bekommen

**2025-09-18 17:38:39** - Julia H.:
> Ich hab’s gemacht danke. Danke

**2025-09-18 17:38:44** - Julia H.:
> Stehe im Stau

**2025-09-18 17:38:50** - Julia:
> okay

**2025-09-18 17:38:53** - Julia:
> puh

**2025-09-18 17:39:06** - Julia H.:
> Das hat mir sehr geholfen danke 

**2025-09-18 17:39:13** - Julia:
> Wie kann ein Kunde so viel Druck ausüben auf uns hahah

**2025-09-18 17:39:27** - Julia H.:
> Normalerweise schaue ich immer in der Woche nach, was alles gepostet wird und lade mir das schon mal aufs Handy, aber dadurch dass ich diese Woche nur so halb arbeite hab ich das irgendwie verpeilt

**2025-09-18 17:39:42** - Julia:
> ja vollkommen verständlich

**2025-09-18 17:39:45** - Julia H.:
> Ja gute Frage ich glaube es ist gar nicht mal der Kunde selbst, sondern auch, dass wir aktuell den Wünschen einfach nicht gerecht werden können. Zeitlich

**2025-09-18 17:39:56** - Julia H.:
> Naja, normalerweise bin ich besser vorbereitet

**2025-09-18 17:40:11** - Julia:
> wahrscheinlich eine kombi :disappointed:

**2025-09-18 17:45:41** - Julia:
> Passen die Sachen soweit von heute? Modelle der Woche, Retro Sunday, Captions für Malmedie Teaser?

Grid und Cayenne Extreme bin ich noch dran. Beim Cayenne Extreme aber unsicher, ob Mert hier mit 3 Posts geplant hat

**2025-09-19 09:40:26** - Julia:
> Guten Morgen hier nochmal :slightly_smiling_face: GIbt es eine Teams Gruppe in die ich nochmal bezüglich des Sharepoints Zugriff fragen kann? Bei mir ist da keine oder wem soll ich am besten schreiben?

**2025-09-19 09:41:02** - Julia:
> bekomme nach wie vor diese Meldungen und wollte eben die Präsi fürs Gipfeltreffen (Highlight und Grid --&gt; hab die Version trotzdem schon fertig) ablegen

**2025-09-19 09:41:40** - Julia H.:
> Mist.... Normalerweise macht das Marie.

**2025-09-19 09:41:49** - Julia H.:
> Aber ich kann es erstmal gern für dich ablegen

**2025-09-19 09:42:04** - Julia:
> okay schade

**2025-09-19 09:42:14** - Julia:
> dann schick ich dir unseren Drive link:

**2025-09-19 09:43:45** - Julia:
> mit heutigem Datum: <https://drive.google.com/drive/folders/1XrdiqskAo9Ql_hkYkH3MbaFym7L36bzM>

**2025-09-19 09:43:46** - Julia:
> danke!

**2025-09-19 09:46:14** - Julia H.:
> Klaro!! Lade ich hoch und gebe Franzi Bescheid, oder sollen wir vielleicht zuerst noch Copy Entwürfe einarbeiten?

**2025-09-19 09:47:41** - Julia:
> Also liegen ja schon seit Beginn drin und eigentlich auch genau das was Denise gestern meinte "starten wieder rein, mit der Family"
Deshalb war ich mir nicht sicher, was sie anders haben möchten. Hast du eine Idee?

**2025-09-19 09:52:51** - Julia H.:
> Ne ich meine was wir gestern besprochen haben. Sprich schon erste Bausteine für Reels etc... Sprich auf dieser basis

**2025-09-19 09:55:48** - Julia:
> Achso!

**2025-09-19 09:56:35** - Julia:
> Ja kann ich gerne mit reinnehmen, aber dauert noch kurz

**2025-09-19 10:03:09** - Julia H.:
> Ja easy,

**2025-09-19 10:03:17** - Julia H.:
> Das hat ja auch bis Montag Zeit

**2025-09-19 10:12:19** - Julia H.:
> Wie kann ich dich am besten noch supporten heute?

**2025-09-19 10:13:22** - Julia:
> Also die "Task" von Flo versteh ich nicht ganz, aber sprechen wir ja gleich dazu :smile:

**2025-09-19 10:15:04** - Julia:
> Ansonsten hab ich auf meinem Zettel:
• Brand Store: Grundrauschen anschauen
• TINS Konzepte 
• Brand Store: Konfiguration 3-4 Wochen Content
• Bezahlte Werbelabel bei Gipfeltreffen Personen checken


**2025-09-19 10:21:48** - Julia H.:
> Ja Reporting betrifft auch eigentlich mich nicht dich

**2025-09-19 10:22:22** - Julia H.:
> TINS können wir next week machen.
Paid Partnership hab ich gestern erledigt :slightly_smiling_face:

**2025-09-19 10:23:26** - Julia H.:
> <https://app.asana.com/1/1199360402832734/project/1211017007394565/task/1210983935124110?focus=true>
Hier liegt der Input zum Brand Store

**2025-09-19 10:27:59** - Julia:
> juhuu danke!

**2025-09-19 10:31:53** - Julia H.:
> kommst du ins meet?

**2025-09-19 10:56:51** - Julia:
> eine Frage beim Cayenne: es gibt noch keine VBWs weil der noch nicht draußen ist, oder?

**2025-09-19 10:58:47** - Julia H.:
> yes genau

**2025-09-19 11:01:40** - Julia:
> okay super

**2025-09-19 11:01:58** - Julia:
> also Mert hat glaub ich gerade keine Zeit zum gucken, deshalb kannst du es ja auch so rausschicken

**2025-09-19 11:03:21** - Julia H.:
> Theoretisch ja, in der PPT werden jetzt nur die videos nicht angezeigt, aber ich übernehme schnell von der alten

**2025-09-19 11:04:15** - Julia:
> höö? also wenn man drauf klickt dann gehts nicht?

**2025-09-19 11:04:53** - Julia:
> das mit diesem online bearbeiten ist echt so doof

**2025-09-19 11:05:23** - Julia H.:
> No worries. Ich habs eingefügt und lade jetzt hoch

**2025-09-19 11:07:52** - Julia:
> okay, sorry und danke!

**2025-09-19 11:09:34** - Julia H.:
> no worries.

**2025-09-19 11:09:34** - Julia H.:
> ich will canva zurück :disappointed:

**2025-09-19 11:27:31** - Julia:
> also wegen brand store: es geht einfach um generelle content ideen. keinen bezug zum sommerfest, right?

**2025-09-19 11:32:19** - Julia H.:
> Ja genau. Also im Grunde brauchen wir mal ein dedicated konzept und befüllung für den redaktionsplan. Da können wir die sunday retro poster integrieren, vielleicht nochmal grundsätzlich den Store und alle highlights vorstellen, uns eigene sachen überlegen, auch mal die weekly highlights neu machen etc... mert hatte da glaub ich auch schon mal angefangen und roxanne ja auch erste ideen

**2025-09-19 11:32:36** - Julia H.:
> + grundrauschen für Konfiguration und Probefahrten alle 3 wochen

**2025-09-19 11:33:45** - Julia:
> okay okay

**2025-09-19 11:33:54** - Julia:
> ich arbeite mal in der präsentation weiter, oder?

**2025-09-19 11:34:29** - Julia:
> "ongoing konzepte"

**2025-09-19 11:46:56** - Julia H.:
> Yes genau!! Danke

**2025-09-19 11:47:30** - Julia H.:
> Können gern gleich mal alles durchgehen. auf dem Insta kanal kann man in den alten posts auch coole sachen finden, die man recyceln könnte um mehr über den store zu informieren

**2025-09-19 11:57:47** - Julia:
> okay got it. ja schau ich mir gerade an

**2025-09-19 12:47:03** - Julia:
> 

**2025-09-19 12:57:15** - Julia H.:
> ja klar, das wird dauern. wir könnten eventuell auch montag alles finalisieren.

**2025-09-19 12:58:07** - Julia H.:
> was beim styleguide wichtig wäre, dass wir noch erklären, dass wir das ändern mussten

**2025-09-19 13:00:29** - Julia:
> yes

**2025-09-19 14:30:08** - Julia:
> Kurze Frage

**2025-09-19 14:30:14** - Julia:
> welches Buch wird nochmal im BS vorgestellt? :smile:

**2025-09-19 14:32:08** - Julia H.:
> <https://app.asana.com/1/1199360402832734/project/1211017007394565/task/1211205975769497?focus=true>

**2025-09-19 14:32:13** - Julia H.:
> Hier ist es drin. Zum Targa

**2025-09-19 14:32:19** - Julia:
> ahja

**2025-09-19 14:32:19** - Julia:
> dankee

**2025-09-19 14:53:20** - Julia:
> content der nicht stark ist --&gt; meinst du videos oder? <https://drive.google.com/drive/folders/1j4meRvzjK7Zm8UKYxHGQ_JVVk76t3qk7>

**2025-09-19 14:53:48** - Julia:
> schau ich mir an

**2025-09-19 14:56:10** - Julia H.:
> Ne ich mein die Fotos auf Picdrop: <https://www.picdrop.com/porsche-deutschland/SU36qbsTkK>

**2025-09-19 15:02:03** - Julia:
> schau ich mir an, bin mit flo im call

**2025-09-19 16:14:29** - Julia:
> posten wir jeden tag auf dem BS?

**2025-09-19 16:31:24** - Julia H.:
> Nein 3 mal pro woche

**2025-09-22 10:25:03** - Julia:
> Hellooo :slightly_smiling_face:

**2025-09-22 10:26:05** - Julia:
> Hast du die Captions von Laetitia schon gesehen? oder könntest du sie mir schicken? Würde ich jetzt mal direkt fertig machen

**2025-09-22 10:27:13** - Julia H.:
> Huhuuuuu good morning! Ne hab sie mir auch noch nicht angeschaut

**2025-09-22 10:27:14** - Julia H.:
> <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BD34F1198-EC53-4375-9BF5-91763EC5882A%7D&amp;file=250919_Gipfeltreffen_JH.pptx&amp;action=edit&amp;mobileredirect=true|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BD34F11[…]919_Gipfeltreffen_JH.pptx&amp;action=edit&amp;mobileredirect=true>

**2025-09-22 10:27:22** - Julia H.:
> Ab wann bist du heute im office?

**2025-09-22 10:38:19** - Julia:
> Ich hab da immer noch keinen Zugriff. Das kann dann nur Marie oder? Könntest du mir eine Kopie schicken oder so?

**2025-09-22 10:38:52** - Julia:
> Ich habs totaaaal vergessen, dass wir unser Essen haben. Bin noch im Schlafi :joy: Also irgendwie nach mittags rum?

**2025-09-22 10:39:13** - Julia H.:
> Ja same :stuck_out_tongue:

**2025-09-22 10:40:13** - Julia H.:
> 

**2025-09-22 10:43:50** - Julia:
> dankeee

**2025-09-22 10:44:10** - Julia:
> Achso sie hats doch direkt bei uns rein, got it

**2025-09-22 10:45:46** - Julia H.:
> yes

**2025-09-22 10:53:58** - Julia H.:
> Hast du schon mal ein Reporting gemacht?

**2025-09-22 10:55:25** - Julia:
> nicht wirklich ne

**2025-09-22 10:59:09** - Julia H.:
> Ja same. Flo meinte du solltest das übernehmen, sehe ich wirklich als so null sinnvoll an. Ich hatte am Freitag mal angefangen alles zu bauen, aber komme nicht weiter, weil ich mich auch nicht auskenne. Und jetzt hat er vorgeschlagen, dass du es machen sollst.

**2025-09-22 10:59:29** - Julia H.:
> Können wir ja gleich im meeting besprechen aber macht halt für mich null sinn.

**2025-09-22 10:59:49** - Julia:
> Ehm okay?

**2025-09-22 11:00:20** - Julia:
> Also ich kann natürlich gerne irgendwie helfen, aber ich weiß ja gefühlt garnicht von was

**2025-09-22 11:32:56** - Julia H.:
> Bin schon am rein kommentieren in die Brand Store Präsi falls du parallel schon umsetzen magst

**2025-09-22 11:34:03** - Julia:
> okidoki, mache kurz die gipfeltreffen captions fertig und dann schau ich rein

**2025-09-22 11:43:22** - Julia H.:
> Top! Bin auch durch. Finde alles super. Hab hier und da noch kleine Rechtschreibfehler korrigiert.

**2025-09-22 11:43:47** - Julia:
> okay :slightly_smiling_face: dankee dir

**2025-09-22 11:44:26** - Julia H.:
> Ich glaube es wäre wichtig, dass wir ein paar Folien die ganz hinten erst kommen vor ziehen und vielleicht auch schon 1-2 Posts konkretisieren. Bildmaterial aus dem Store haben wir ja ohne Ende. Und ab kommender Woche ist der Redaktionsplan komplett leer

**2025-09-22 11:44:35** - Julia:
> 

**2025-09-22 11:46:19** - Julia H.:
> <https://porsche.sharepoint.com/sites/PDMK/Shared%20Documents/Forms/AllItems.aspx?csf=1&amp;web=1&amp;e=5%3A7843c416cdb749a8a41366a2ad525502&amp;CID=0252f416%2D8640%2D4222%2Db387%2D127327bf30ed&amp;FolderCTID=0x012000B0A40330D7B2464BB054061397BEF042&amp;id=%2Fsites%2FPDMK%2FShared%20Documents%2FBrand%20Store%2F07%20Programming%2FBilder%20Pool%5FGesamt|https://porsche.sharepoint.com/sites/PDMK/Shared%20Documents/Forms/AllItems.aspx?csf=1&amp;w[…]Brand%20Store%2F07%20Programming%2FBilder%20Pool%5FGesamt>

**2025-09-22 11:46:23** - Julia H.:
> Hast du hier Zugriff?

**2025-09-22 11:46:34** - Julia:
> neee :sleepy:

**2025-09-22 11:50:49** - Julia H.:
> <https://www.picdrop.com/roserbrothers/UcybkS1Ehk>

**2025-09-22 11:51:50** - Julia H.:
> <https://drive.google.com/drive/folders/1-sUjou3r4OVgViDtfTTK0ZLYlLTNmSrZ>

**2025-09-22 11:58:09** - Julia:
> dankee, schau ich mir an!

**2025-09-22 11:58:19** - Julia:
> Gipfeltreffen Captions: <https://drive.google.com/drive/folders/1XrdiqskAo9Ql_hkYkH3MbaFym7L36bzM>

**2025-09-22 12:08:18** - Julia:
> Wann fährst du ins Büro?

**2025-09-22 12:08:39** - Julia:
> Hast du sonst kurz paar Minuten, dass wir die Präsi nochmal kurz durchgehen?

**2025-09-22 12:09:21** - Julia H.:
> wollte so fahren, dass ich zum meeting da bin, also gegen 14:15 oder so

**2025-09-22 12:09:29** - Julia H.:
> yes können wir machen

**2025-09-22 12:09:33** - Julia H.:
> sollen wir ins meet von vorher

**2025-09-22 12:09:59** - Julia:
> gernee

**2025-09-22 12:10:29** - Julia:
> bin da

**2025-09-22 12:42:59** - Julia H.:
> hab gerade nochmal gipfeltreffen geprüft. caption 2 macht für mich keinen sinn:
Von den ersten Coffee Talks bis
zum Dinner über den Dächern –
Tag 2 war pure Porsche
Performance

**2025-09-22 12:43:13** - Julia H.:
> Ich passe hier und da mal noch was an bevor ich raus schicke ok?

**2025-09-22 12:43:22** - Julia:
> ja klar, bitte

**2025-09-22 12:43:46** - Julia:
> Die Tage haben bestimmte Themes laut Produktion

**2025-09-22 12:44:25** - Julia H.:
> Yes, nur das Performance Theme finde ich nicht im Text mit Coffee und Dinner, oder?

**2025-09-22 12:48:39** - Julia H.:
> Die Captions waren mir noch zu steif... Emotionen, Momente, etc. das mögen sie überhaupt nicht, das macht Laetitia immer :stuck_out_tongue:

**2025-09-22 12:48:44** - Julia H.:
> Pure Emotionen

**2025-09-22 12:48:45** - Julia H.:
> LOL

**2025-09-22 12:49:11** - Julia:
> ja versteh ich

**2025-09-22 12:49:14** - Julia:
> okay

**2025-09-22 12:49:36** - Julia:
> also ich hatte sie schon super krass angepasst, wir hatten 3er Text Blöcke von Laetitia abliegen

**2025-09-22 12:49:41** - Julia:
> soll ich nochmal drüber?

**2025-09-22 12:49:54** - Julia H.:
> ne all good. ich hab schnell hier und da angepasst

**2025-09-22 12:50:07** - Julia H.:
> nur halt diese bestimmten wörter raus die sie nicht mögen

**2025-09-22 12:53:06** - Julia:
> okay!

**2025-09-22 15:56:59** - Julia:
> okay, wild :smile:

**2025-09-22 16:02:44** - Julia H.:
> what?

**2025-09-22 16:02:53** - Julia H.:
> OMG lol

**2025-09-22 16:03:00** - Julia:
> in unserem suchverlauf :smile:

**2025-09-22 16:03:04** - Julia:
> also nicht meiner

**2025-09-22 16:03:27** - Julia H.:
> yes ich seh's.... Vielleicht Laetitia?

**2025-09-22 16:03:35** - Julia H.:
> aber kann ich mir irgendwie auch nicht vorstellen

**2025-09-22 16:04:01** - Julia:
> Keine Ahnung – ist auch egal, aber ich würds mal löschen. Find ich schwierig, wenn das Flo sieht

**2025-09-22 16:04:39** - Julia H.:
> Ja absolut! oder porsche halt

**2025-09-22 16:04:43** - Julia H.:
> oder die waren es selbst

**2025-09-22 16:10:07** - Julia:
> kündigung ist raaaus

**2025-09-22 16:10:15** - Julia:
> kommst du jetzt zum ppm ins büro?

**2025-09-22 16:14:28** - Julia H.:
> Ich komm erst danach leider. charly hatte mich vorher ne stunde in nem ungeplanten call leider das hat meinen ganzen plan durcheinander gebracht

**2025-09-22 16:17:04** - Julia:
> ah okay, ja alles gut!

**2025-09-22 16:17:25** - Julia:
> hat sie dir schon feedback zu den Grid Themen gegeben?

**2025-09-22 16:17:39** - Julia:
> AH jetzt seh ich die Mail

**2025-09-22 16:33:28** - Julia:
> Dateien liegen hier für dich zum Upload:
<https://drive.google.com/drive/folders/1tIQugcxuigtB1ukTFc55O-zUavxvx580>


Bezüglich der Caption: Ne die Reihenfolge ist so gewollt. Damit wir bei "Amore Motore" auch das Wort Gipfeltreffen in der Caption haben --&gt; ist ja der erste Post der rausgeht.
Beim Visual "Gipfeltreffen" haben wir dann analog auch wieder Amore Motore textlich aufgegriffen. So haben wir überall alles drin

**2025-09-22 16:50:42** - Julia:
> ich glaube nicht, dass ich das bis Mittwoch schaffe tbh
<https://app.asana.com/1/1199360402832734/project/1210522556460296/task/1210703906249623?focus=true>

**2025-09-22 16:52:52** - Julia H.:
> Ne das muss auch nicht Mittwoch sein, wir müssen es nur asap nach brand store fokus angehen, weil charly nächste woche dazu was sehen will

**2025-09-22 16:57:05** - Julia H.:
> not sure was wir in diesem call sollen lol

**2025-09-22 16:57:38** - Julia:
> :fast_parrot:

**2025-09-22 17:03:37** - Julia H.:
> bin so froh, dass wir das nicht planen gerade

**2025-09-22 17:06:04** - Julia H.:
> Notiz an uns für Bildselektion:
Hände/Lenkrad Position
Fahrbahnüberschreitung

**2025-09-22 17:06:14** - Julia:
> ich glaube Hanna versteht das mit der Caption nicht. hier nochmal:
Wir posten ja zuerst das "Amore Motore" Visual – damit das nicht alleine steht, gehen wir textlich auf Gipfeltreffen.
Die Community liest natürlich erst die Caption 3 ("... seid gespannt"), wenn sie drauf klicken. Aber dadurch, dass es sich Visual erklärt, zieht sich inhaltlich ein roter Faden

**2025-09-22 17:11:53** - Julia:
> total. das noch on top ciaaaao

**2025-09-22 17:34:43** - Julia H.:
> 

**2025-09-22 17:35:21** - Julia H.:
> 

**2025-09-22 17:36:04** - Julia:
> zorri das ist halt das KV :smile:

**2025-09-22 17:36:10** - Julia:
> Wegmachen dann einfach?

**2025-09-22 17:36:20** - Julia:
> von wem kam das feedback?

**2025-09-22 17:40:10** - Julia H.:
> charly natürlich

**2025-09-22 17:40:23** - Julia H.:
> ja würde es dann wegmachen

**2025-09-22 17:40:32** - Julia:
> okay

**2025-09-22 17:40:46** - Julia:
> ich mach es sobald ich adobe nutzen kann

**2025-09-22 17:41:07** - Julia H.:
> ok

**2025-09-22 17:41:17** - Julia:
> hungeeeeer :smile:

**2025-09-22 17:41:19** - Julia H.:
> same

**2025-09-22 17:41:30** - Julia H.:
> wenn das so weiter geht komm ich ja nie von daheim los

**2025-09-22 17:41:58** - Julia:
> wir können ja beim essen den laptop aufhaben – porsche würde es lieben

**2025-09-22 17:42:19** - Julia H.:
> sicher

**2025-09-22 17:42:21** - Julia H.:
> nicht

**2025-09-22 17:42:23** - Julia H.:
> :stuck_out_tongue:

**2025-09-22 18:04:04** - Julia:
> <https://drive.google.com/drive/folders/1tIQugcxuigtB1ukTFc55O-zUavxvx580>

**2025-09-22 18:04:19** - Julia:
> 

**2025-09-22 18:12:40** - Julia H.:
> Bist du da?

**2025-09-22 18:15:16** - Julia:
> wooo?

**2025-09-22 18:15:19** - Julia:
> im büro?

**2025-09-22 18:15:22** - Julia:
> jaa

**2025-09-22 18:16:00** - Julia H.:
> Hab dir ne WhatsApp geschrieben 

**2025-09-22 18:16:03** - Julia H.:
> Grid passt nicht 

**2025-09-22 18:16:06** - Julia H.:
> Ich Checks nicht 

**2025-09-22 18:16:21** - Julia H.:
> Hab die Vorschau geschoben aber es stimmt nicht überein 

**2025-09-22 18:16:36** - Julia H.:
> Hat die Vorschau ein anderes Format?

**2025-09-22 18:17:16** - Julia H.:
> 

**2025-09-23 09:15:05** - Julia:
> Guten Morgen, mich hats heute nacht mit Migräne erwischt :face_with_peeking_eye: ich bin immer noch nicht fit und hab soo starke Kopfschmerzen, aber versuche später wieder weiter zu machen mit Reporting, Social Media etc.

**2025-09-23 09:23:22** - Julia H.:
> Good morning
Oh nooo du arme!!! Kurier dich aus 

**2025-09-23 12:38:30** - Julia:
> hallo :slightly_smiling_face: dankee, so ätzend.. aber ich versuch gerade das reporting wenigstens fertig zu bekommen mit flo's änderungswünschen. zwei Fragen kamen gestern bei Flo dann auf:
• ob die 33% wirklich stimmen
• was war am 14.8. --&gt; so viele Follower bekommen

**2025-09-23 12:43:05** - Julia H.:
> Weiß nicht mit den 33% whrlichgesagt müsste ja aus dem Screenshot stammen 

**2025-09-23 12:43:43** - Julia H.:
> 14.8. gab es keine Posts… am 13. gingen die malmedie Assets online also vielleicht deswegen 

**2025-09-23 12:43:50** - Julia H.:
> Aber Zero Plan

**2025-09-23 13:32:23** - Julia H.:
> Wie machen wir denn das mit brand store? Morgen sollten wir ja nochmal was präsentieren 

**2025-09-23 14:21:50** - Julia:
> I know, ich geb mein Bestes aber wird gerade nicht besser. Versuche heute abend noch was zu schaffen. Ich hab Mert versucht ales zu erklären, ob er schon erste Drafts machen kann. Ich bearbeite die Präsi nochmal mit dem Contenthaus Themen was Hanna wollte.
Wann ist der Termin? hab keinen im Kalender

**2025-09-23 14:38:01** - Julia H.:
> tut mir so leid. was kann ich machen?

**2025-09-23 14:38:12** - Julia H.:
> ich hab flo schon gesagt, dass er dich einladen muss. 10:30 ist der termin

**2025-09-23 17:06:08** - Julia:
> hab die inhalte nochmal etwas angepasst, je nach feedback und eben diese contenthaus themen zugeordnet und gegliedert. die inhalte die ich als weekly inhalte sehe sind auch markiert. rest noch tbd :face_with_spiral_eyes:

**2025-09-23 17:28:57** - Julia H.:
> 

**2025-09-23 17:35:10** - Julia H.:
> Das können wir noch bei den Posting Zeiten ergänzen.

**2025-09-23 17:37:25** - Julia H.:
> Denkst du wir schaffen da morgen noch ein bisschen was? Mit den Highlights zum beispiel?
Ich würde auch sagen, wir ergänzen schonmal grob den Plan zum Posten:
Montags: Store Rundgang
Dienstags: Konfi
Sonntag: Heritage/Retro Sunday

**2025-09-24 07:47:10** - Julia:
> Hello, mich hats dann komplett zerlegt. Hab plötzlich hohes Fieber bekommen abends. Bin immer noch fiebrig.. :sob: also kann heute eher nichts präsentieren - können wir den Call auf morgen legen?  

**2025-09-25 09:44:24** - Julia H.:
> Gleich mal kurzer Update Call vor dem Huddle?

**2025-09-25 09:45:21** - Julia:
> jaaa bitte. Um 10?

**2025-09-25 09:48:52** - Julia H.:
> yesss

**2025-09-25 10:00:28** - Julia:
> call von später?

**2025-09-25 10:01:23** - Julia H.:
> yess

**2025-09-25 10:28:24** - Julia H.:
> <https://porsche.sharepoint.com/:x:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7B5467df8f-c89c-486c-8cff-887b6c91507f%7D&amp;action=edit&amp;activeCell=%27%40porsche_de%27!B643&amp;wdinitialsession=ebaf3e33-ab72-fcae-efae-38e66747f62d&amp;wdrldsc=13&amp;wdrldc=1&amp;wdrldr=AccessTokenExpiredWarningUnauthenticated%2CRefreshin|https://porsche.sharepoint.com/:x:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7B5467df[…]rldr=AccessTokenExpiredWarningUnauthenticated%2CRefreshin>

**2025-09-25 10:45:36** - Julia:
> so bad was ich gesagt habe? :smile:

**2025-09-25 10:46:12** - Julia H.:
> hahaha

**2025-09-25 10:46:14** - Julia H.:
> ich komm nicht mehr rein

**2025-09-25 10:46:32** - Julia:
> mist

**2025-09-25 10:46:32** - Julia H.:
> Never mind. Ich sortier mal die Aufgaben und wir müssen nur überlegen wie wir uns aufteilen

**2025-09-25 10:47:58** - Julia:
> jaa, ich würde mal damit starten:

• Artur Kar Carousel/ Content check
• Intro Store: Grundriss bei Hanna anfragen
• Präsi BS | Präsi Porsche DE aufbauen
• UGC Prozess Asana angucken --&gt; Porsche Family challangen
• Targa Event --&gt; Fotografen/ Videografen checken

**2025-09-25 10:48:15** - Julia H.:
> Yess, und sobald du Hilfe brauchst irgendwo let me know

**2025-09-25 10:48:21** - Julia:
> bestimmt :smile:

**2025-09-25 10:48:54** - Julia:
> kannst du mir noch die Artur Kar Präsi schicken?

**2025-09-25 10:52:31** - Julia:
> Und ist Marie wieder da? Wegen dem Sharepoint Zugriff..

**2025-09-25 10:52:44** - Julia H.:
> Liegt in Asana, <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7B7D85BAF2-D5AD-4927-9DD3-1A9CC246F422%7D&amp;file=2025_CarreraGT_Rollout_MARKET_DECK%20(1).pptx&amp;action=edit&amp;mobileredirect=true&amp;previoussessionid=bbaa610d-a214-87dd-79a2-71e0b103afcf|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7B7D85BA[…]ue&amp;previoussessionid=bbaa610d-a214-87dd-79a2-71e0b103afcf>
Hast du da Zugriff?

**2025-09-25 10:52:44** - Julia H.:
> Nope

**2025-09-25 10:52:51** - Julia H.:
> leider nein

**2025-09-25 10:58:06** - Julia:
> doch?

**2025-09-25 10:58:08** - Julia:
> komisch

**2025-09-25 10:58:20** - Julia H.:
> haha nice

**2025-09-25 10:58:25** - Julia:
> dankee!

**2025-09-25 11:11:09** - Julia H.:
> <https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1211450829020501?focus=true>

**2025-09-25 11:11:20** - Julia H.:
> Ah wir sollen für next week mit den Herzen einen Feedpost zur Wiesn machen

**2025-09-25 11:12:39** - Julia:
> Süß, mach ich

**2025-09-25 11:13:30** - Julia:
> Könntest du mir die einzelnen Arthur Kar Ordner schicken? Ich bau es grad in Figma, damit wir dann alles ready haben. Aber ich hab nur hierauf Zugriff:

**2025-09-25 11:13:43** - Julia:
> 

**2025-09-25 11:13:46** - Julia:
> und das video hab ich

**2025-09-25 11:16:21** - Julia H.:
> <https://drive.google.com/drive/folders/1bfviRSqyo3o64hNC_oIk6thjgkEgeIig>
Hab eigentlich alles hier rein geworfen glaub ich

**2025-09-25 11:17:10** - Julia:
> ahh okay, also du lädst das dann auch immer direkt bei uns in den drive?

**2025-09-25 11:17:14** - Julia:
> perfekt danke!

**2025-09-25 11:17:55** - Julia H.:
> also wenn die von der anderen Agentur geschickt werden und nicht auf dem Sharepoint liegen ja

**2025-09-25 12:29:06** - Julia:
> 

**2025-09-25 12:35:38** - Julia H.:
> I know, keine ahnung wie wir das lösen sollen. das war halt mit canva so viel einfacher.

**2025-09-25 12:35:54** - Julia H.:
> hab sie gestern für hanna auf den Sharpoint geladen (auch in asana drin): <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BE33428F9-BF0F-4720-B9FE-D8EDF165E52E%7D&amp;file=250924_Porsche_BS_SoMe_Konzepte_JH.pptx&amp;action=edit&amp;mobileredirect=true|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BE33428[…]_BS_SoMe_Konzepte_JH.pptx&amp;action=edit&amp;mobileredirect=true>

**2025-09-25 12:36:20** - Julia H.:
> Hoffe der Zugriff klappt

**2025-09-25 12:36:27** - Julia:
> jaaa

**2025-09-25 12:36:39** - Julia:
> ich weiß auch nicht wieso das manchmal geht und manchmal nicht

**2025-09-25 12:36:40** - Julia:
> dankee

**2025-09-25 13:14:28** - Julia:
> <https://www.instagram.com/svencich?utm_source=ig_web_button_share_sheet&amp;igsh=ZDNlZDc0MzIxNw==>

<https://www.nicolasbaer.de/projects>

<https://www.instagram.com/maxxholley?utm_source=ig_web_button_share_sheet&amp;igsh=ZDNlZDc0MzIxNw==>

<https://www.instagram.com/yannikmichael?utm_source=ig_web_button_share_sheet&amp;igsh=ZDNlZDc0MzIxNw==>

**2025-09-25 13:14:45** - Julia:
> Fotografen/ Videografen. Super schwierig da gute für Events zu finden..

**2025-09-25 13:15:04** - Julia:
> Yannik könnte cool sein

**2025-09-25 14:05:41** - Julia H.:
> Sehen eigentlich alle ganz gut aus finde ich. Ist dann halt ne Kostenfrage

**2025-09-25 14:05:48** - Julia H.:
> Kann ich Montag mal anschreiben

**2025-09-25 14:08:07** - Julia:
> Okee 

**2025-09-25 14:21:18** - Julia:
> Ich schreib gleich wegen caption 

**2025-09-25 14:41:02** - Julia:
> Gipfeltreffen Tag 1 – Mehr als nur ein Wiedersehen. Das ist Herzblut auf vier Rädern mit @axelstein4real und @matthiasmalmedie
-

911 GT3 (PDK) (WLTP): Kraftstoffverbrauch kombiniert: 13,8 l/100 km; CO₂-Emissionen kombiniert: 312 g/km; CO₂-Klasse: G;
911 GT3 mit Touring-Paket (MT) (WLTP): Kraftstoffverbrauch kombiniert: 13,7 l/100 km; CO₂-Emissionen kombiniert: 310 g/km; CO₂-Klasse: G; Stand 09/2025

**2025-09-25 14:41:55** - Julia:
> Oder soll ich posten?

**2025-09-25 14:42:25** - Julia H.:
> bei mir läd das reel gerade runter

**2025-09-25 14:42:45** - Julia H.:
> sind das verschiedene?

**2025-09-25 14:42:53** - Julia:
> ne das eine ist das thumbnail

**2025-09-25 14:44:15** - Julia H.:
> ahh seh ich gerade, danke

**2025-09-25 14:44:33** - Julia H.:
> Normalerweise müssen wir in die UT immer schreiben 911 GT3 auch wenn sie nur GT3 sagen.

**2025-09-25 14:44:38** - Julia H.:
> aber mir jetzt egal

**2025-09-25 14:44:45** - Julia:
> ahh okay

**2025-09-25 14:44:59** - Julia:
> nee lass das doch reinschreiben, oder? gut für uns :smile:

**2025-09-25 14:45:51** - Julia H.:
> sagt er irgendwas zur schaltung oder so ne oder?

**2025-09-25 14:49:12** - Julia:
> ne

**2025-09-25 14:51:35** - Julia H.:
> ok gut, weil da müssen nämlich sonst als ausnahme die VBW ins video rein

**2025-09-25 14:51:46** - Julia:
> :face_with_peeking_eye:

**2025-09-25 14:52:39** - Julia:
> Wenn du morgen off bist: bezüglich Freigabe/ Feedback von Hanna usw. soll ich dann einfach über Mail machen, oder?

**2025-09-25 14:57:25** - Julia H.:
> mein insta stürzt gerade zum 3 mal ab wenn ich auf teilen drücke

**2025-09-25 14:57:32** - Julia H.:
> kannst du mal probieren ist in den reel entwürfen

**2025-09-25 14:57:37** - Julia:
> yes moment

**2025-09-25 14:57:38** - Julia H.:
> ist alles hinterlegt man muss nur posten

**2025-09-25 14:58:10** - Julia:
> Entwürfe sind nur bei dir am handy

**2025-09-25 14:58:32** - Julia H.:
> wtf ey

**2025-09-25 14:58:44** - Julia:
> ich kanns auch posten

**2025-09-25 14:58:57** - Julia:
> bzw probieren, aber dann dürfen wir nicht gleichzeitig :smile:

**2025-09-25 14:59:15** - Julia H.:
> ne ich bin dran

**2025-09-25 14:59:18** - Julia H.:
> ich versuchs neu

**2025-09-25 14:59:21** - Julia H.:
> wenns nciht geht musst du

**2025-09-25 14:59:29** - Julia:
> yes, bin ready

**2025-09-25 15:00:44** - Julia:
> bei mir auch!!!

**2025-09-25 15:00:47** - Julia H.:
> nein stürzt ab

**2025-09-25 15:00:53** - Julia:
> komplett abgestürzt

**2025-09-25 15:00:57** - Julia H.:
> wtf

**2025-09-25 15:01:23** - Julia H.:
> kann das am video liegen

**2025-09-25 15:01:31** - Julia:
> weils wahrscheinlich riesig ist

**2025-09-25 15:01:43** - Julia:
> 

**2025-09-25 15:01:58** - Julia H.:
> bei mir wird auch alles schwarz aber dann gehts wieder

**2025-09-25 15:02:03** - Julia H.:
> wie groß ist das video

**2025-09-25 15:02:19** - Julia:
> 175 mb

**2025-09-25 15:02:30** - Julia H.:
> ist das zu groß? :stuck_out_tongue: ich kenn mich nicht aus

**2025-09-25 15:02:46** - Julia H.:
> ich versuch nochmal weil app upgedated gerade

**2025-09-25 15:02:56** - Julia:
> nee hab geguckt. kann 4gb sein

**2025-09-25 15:02:56** - Julia:
> okay

**2025-09-25 15:03:01** - Julia:
> ich versuch auch weiterhin

**2025-09-25 15:04:03** - Julia:
> bei mir liegts am titelbild

**2025-09-25 15:04:46** - Julia:
> versuchs mal damit:

**2025-09-25 15:05:15** - Julia:
> 

**2025-09-25 15:06:22** - Julia H.:
> ne das stürzt sofort ab

**2025-09-25 15:08:03** - Julia H.:
> boah nerven sie mich schon wieder

**2025-09-25 15:08:08** - Julia H.:
> was soll das, als wären wir dumm

**2025-09-25 15:08:12** - Julia:
> ja

**2025-09-25 15:08:46** - Julia H.:
> ich krieg die krise wenn es bei denen funktioniert ih sags dir

**2025-09-25 15:10:38** - Julia:
> vooooll

**2025-09-25 15:10:39** - Julia:
> was ist das

**2025-09-25 15:10:45** - Julia:
> kann flo es versuchen? ist der daß

**2025-09-25 15:10:51** - Julia H.:
> kein plan wo der ist

**2025-09-25 15:13:25** - Julia H.:
> Als TN ist es.

**2025-09-25 15:13:29** - Julia H.:
> das läd gerade

**2025-09-25 15:13:46** - Julia:
> okay

**2025-09-25 15:14:34** - Julia H.:
> schweißausbruch ey

**2025-09-25 15:15:16** - Julia H.:
> mir fällt auch gerade auf dass der text auf dem TN "Reunion" ja gar nciht passt. letztes jahr waren weder malmedie noch axel dabei soweit ich weiß

**2025-09-25 15:15:17** - Julia H.:
> LOL

**2025-09-25 15:16:26** - Julia:
> ja was weiß ich :smile:

**2025-09-25 15:16:32** - Julia:
> die wissen ja alles besser haha

**2025-09-25 15:41:51** - Julia H.:
> Hast du heute nochmal 10 min für Sprinklr?

**2025-09-25 15:42:26** - Julia:
> Klar

**2025-09-25 15:44:48** - Julia H.:
> sag bescheid wann es passt

**2025-09-25 16:07:10** - Julia:
> wenn du magst, gerne jetzt. fange danach den reminder an

**2025-09-25 16:22:11** - Julia H.:
> Yes, wieder ins huddle?

**2025-09-25 16:40:06** - Julia:
> yeees moment. hab reminder jetzt nochmal gemacht - legs jetzt in die Präsi ab und du schickst es an Hanna oder soll ich?

**2025-09-25 16:42:29** - Julia H.:
> ich schicks

**2025-09-25 16:42:31** - Julia H.:
> danke!

**2025-09-25 16:44:05** - Julia:
> so reminder liegt ab :slightly_smiling_face:

**2025-09-25 16:44:23** - Julia:
> slide 9

**2025-09-25 16:44:38** - Julia H.:
> whoop danke

**2025-09-25 16:46:01** - Julia H.:
> kommst du ins meet

**2025-09-25 16:46:31** - Julia:
> yes

**2025-09-25 17:00:37** - Julia H.:
> Dein Soundtrack fürs Wochenende: Saturday Tunes im Porsche Brand Store, wir freuen uns auf euch.

**2025-09-25 17:17:34** - Julia H.:
> 

**2025-09-25 17:17:35** - Julia H.:
> Da ist noch ein typo

**2025-09-25 17:18:02** - Julia:
> danke!

**2025-09-25 17:18:13** - Julia H.:
> logo

**2025-09-25 17:21:58** - Julia H.:
> Bitte bei Arthur dann überall porsche.lifestyle und arthur hidden taggen in story und auf post

**2025-09-26 12:06:25** - Julia:
> hallooo, bist du da? Falls ja, hab ich nur eine kurze Frage

**2025-09-29 12:27:49** - Julia:
> wann fliegst du heute? :face_holding_back_tears:

**2025-09-29 12:33:09** - Julia H.:
> 19:00 aber muss dann so gegen 16:30 zum flugi

**2025-09-29 12:33:28** - Julia:
> ahh krass

**2025-09-29 12:33:29** - Julia:
> ja klar

**2025-09-29 13:21:04** - Julia H.:
> Wie kann ich dich heute supporten?

**2025-09-29 13:28:01** - Julia:
> das ist eine gute frage :smile:

**2025-09-29 13:28:32** - Julia:
> ich glaube das UGC thema fällt bei mir heute runter

**2025-09-29 13:29:01** - Julia:
> BS Stories hab ich Hanna jetzt das Update geschickt. Nach der Mittagspause kümmere ich mich um diese Insider Single Posts

**2025-09-29 13:29:05** - Julia:
> für Charly

**2025-09-29 13:29:22** - Julia:
> die hat zwar eh einen haufen an Content zum feedbacken, aber für uns ja auch mal nicht schlecht :slightly_smiling_face:

**2025-09-29 13:29:43** - Julia:
> Modell des Monats hab ich noch nicht in die Präsi --&gt; wusste nicht, ob Flo das jetzt rausschicken wollte oder nicht

**2025-09-29 13:29:59** - Julia H.:
> Yes wollte er. Kann ich dir gern in die Präsi packen

**2025-09-29 13:33:32** - Julia:
> 

**2025-09-29 13:37:10** - Julia H.:
> Schau mal hier sind die Captions zum Sonderwunsch

**2025-09-29 13:38:31** - Julia H.:
> Ja total, also wir können da ja auch bisschen struktur reinbringen in den Redaktionsplan und das ganze mal etwas formen. die festen formate gibt es ja per se schon, sprich Porsche Points, Family und Insider... können wir aber gern morgen auch nochmal besprechen, auch TINS.

**2025-09-29 14:27:23** - Julia:
> gerne

**2025-09-29 14:27:39** - Julia:
> Bin wieder da!

**2025-09-29 14:28:45** - Julia H.:
> supii

**2025-09-29 14:36:51** - Julia:
> Hab leider noch keinen Zugriff zur Präsi – könntest du es einfügen?

Caption 1:
Jeder Traum hat einen Ursprung. Die Sonderwunsch-Doku begleitet Persönlichkeiten von der ersten Idee bis zum einzigartigen Fahrzeug.
Mutige Farben, edle Materialien, feine Details – hier entstehen Unikate mit Charakter.
Sonderwunsch – wenn Träume fahren lernen.

Caption 2:
Episode 2: Aus Ideen werden Skizzen, aus Skizzen ein Konzept.
Kreativität trifft Präzision – der Beginn einer Vision startet hier: Sonderwunsch bei Porsche.

Caption 3:
Episode 3 der Sonderwunsch-Serie: Der nächste Schritt zum Unikat.
Wie aus Ideen Design wird – und aus Persönlichkeit ein Porsche.

Caption 4:
Aus Vision wird Realität: Das ist Sonderwunsch. Fahrzeuge, die zu 100 % Unikat sind: geprägt von Ideen, Präzision und Mut. Was als Traum begann, steht jetzt auf eigenen Rädern.

**2025-09-29 14:39:28** - Julia H.:
> Nice danke!! Die Titel sind okay?

**2025-09-29 14:41:32** - Julia:
> Finde nur den 2. etwas sehr hochgestochen "was die Welt noch nicht gesehen hat"
--&gt; Vllt eher so:

Etwas Einzigartiges entsteht: Ein Unikat nimmt Form an

**2025-09-29 14:43:24** - Julia:
> Wie würdest du diese "Insider" Posts zusammenfassen? Das sind einfach coole, starke Schnappschuss-Single Posts oder?

Mir ist das "Insider" in dem Fall irgendwie noch unschlüssig :smile:

**2025-09-29 14:45:39** - Julia H.:
> Ich hab das konzept dahinter nicht ganz kapiert...

**2025-09-29 14:51:29** - Julia:
> wunderbar haha

**2025-09-29 14:56:42** - Julia:
> also ich bin da jetzt auf jeden Fall mal dran und mach ein paar vorschläge (inklusive Gipfeltreffen)

**2025-09-29 15:02:12** - Julia H.:
> ich kann dir gern helfen, kannst mir ja mal schicken

**2025-09-29 15:26:30** - Julia:
> klar gerne: <https://www.figma.com/design/902cDjeQLIyg77xt49VdZg/Porsche-DE-%F0%9F%8F%8E%EF%B8%8F?node-id=20-2&amp;t=pzFNwcu432DhhC9W-1>
Unter "Insider"

**2025-09-29 15:27:01** - Julia:
> 

**2025-09-29 15:27:07** - Julia:
> schnapsschuss – bräuchte ich jetzt aus :smile:

**2025-09-29 15:41:45** - Julia H.:
> Aber was hat denn das mit Insider zu tun das kapier ich nicht

**2025-09-29 15:41:55** - Julia H.:
> Oder meint sie das Format: Porsche Insider

**2025-09-29 15:42:11** - Julia:
> wahrscheinlich das Format

**2025-09-29 15:42:16** - Julia H.:
> 

**2025-09-29 15:42:56** - Julia:
> und da meinte flo zu mir das sind so schnappschüsse.
Charly meinte da sind die captions ja immer auch etwas "lustig"

**2025-09-29 15:43:12** - Julia H.:
> LOL wirklich

**2025-09-29 15:43:12** - Julia:
> deswegen weiß ich jetzt nicht was da bei sylt lustig ist :smile:

**2025-09-29 15:43:24** - Julia H.:
> die regt mich auch gerade wieder dermaßen auf

**2025-09-29 15:43:36** - Julia H.:
> es triggert mich, dass sie die Liste triggert.

**2025-09-29 15:43:44** - Julia H.:
> soll mal bisschen chillen, immer so aggro

**2025-09-29 15:43:53** - Julia:
> ja

**2025-09-29 15:43:57** - Julia:
> als ob das Prio hat

**2025-09-29 15:48:21** - Julia H.:
> Aber wirklich. Dann geht halt ein Post mal 10 min nach online. chill bitte

**2025-09-29 15:48:30** - Julia H.:
> sorry, muss mal kurz raus

**2025-09-29 15:48:33** - Julia H.:
> :stuck_out_tongue:

**2025-09-29 15:48:42** - Julia H.:
> Immer so viel drama um nix

**2025-09-29 15:48:48** - Julia H.:
> wir machen instagram ey

**2025-09-29 15:49:01** - Julia:
> Ja "ISSO"

**2025-09-29 15:49:16** - Julia:
> deswegen war ich auch kurz geschockt: DAILY? haha

**2025-09-29 15:49:30** - Julia H.:
> haha, keine sorge, ab mittwoch bin ich wieder dabei

**2025-09-29 15:51:15** - Julia H.:
> So ich hab jetzt mal die Insider Posts angeschaut, sind doch ganz coole Ideen dabei

**2025-09-29 15:52:25** - Julia:
> joa, ich mach noch eine halbe std. und dann lad ichs in die präsi

**2025-09-29 16:32:49** - Julia H.:
> Caption etc von Leonie Beck müsste in einer Präsi in der asana task sein

**2025-09-29 16:33:31** - Julia:
> ah okay, schau ich gleich

**2025-09-29 16:33:34** - Julia:
> danke!

**2025-09-29 16:37:00** - Julia H.:
> Gibt auch noch ein carousel post dazu

**2025-09-29 16:59:17** - Julia:
> puh, das ist aber irgendwie alt. Da ist das Reel garnicht eingeplant. Ich sortier mal..

**2025-09-29 17:27:44** - Julia H.:
> Hmm okay schicks mir sonst gern nochmal 

**2025-09-29 17:28:08** - Julia H.:
> Bin jetzt am Flughafen und kann gleich wieder helfen 

**2025-09-29 17:28:47** - Julia:
> ich habs charly jetzt geschickt

**2025-09-29 17:28:50** - Julia:
> hoffe das war okay

**2025-09-29 17:49:45** - Julia:
> Guuuten Flug dann! :heart:

**2025-09-29 17:51:00** - Julia H.:
> Hab grad nochmal kurz drüber geschaut. Hatte gesehen,sie wollte als startbild den Cayenne das hab ich getauscht

**2025-09-29 17:51:06** - Julia H.:
> die Daten angepasst und auch die VBW

**2025-09-29 17:51:32** - Julia H.:
> Nicht, dass sie noch Schnappatmung bekommt :stuck_out_tongue:

**2025-09-29 17:53:04** - Julia:
> ahh okay gut

**2025-09-29 17:53:44** - Julia:
> danke!

**2025-09-29 17:58:53** - Julia H.:
> Ich check halt nicht, wieso das beim Export dann wieder auf jeder Seite anders aussieht

**2025-09-29 17:59:15** - Julia H.:
> Ich gleich das nochmal an, damit auch alles die gleichen schriftgrößen hat etc.

**2025-09-29 17:59:57** - Julia:
> ja eben, ich auch nicht..

**2025-09-29 18:03:21** - Julia:
> also Hanna hatte auch nochmal feedback zur BS Präsi.. sie hängt sich da gerade so am Wording auf. Ich passe das gleich nochmal an aber langsam raucht mir der kopf :smile:

**2025-09-29 18:04:52** - Julia H.:
> Ja kann ich mir denken. Wir können auch immer intern nochmal drüber schauen, ich kenne sie ja ganz gut und weiß oft, was sie mögen

**2025-09-29 18:06:24** - Julia:
> jaa wollte dir nicht noch mehr Arbeit machen :smile:

**2025-09-29 18:06:26** - Julia H.:
> Ich glaub es ist auch wichtig, dass wir die folien immer gleich aufziehen. Bildgrößen inkl.

**2025-09-29 18:06:58** - Julia H.:
> Das war bei Canva so easy, aber das will flo nicht mehr. Vielleicht können wir ihn ja irgendwann gemeinsam überzeugen. Sieht jetzt in PPT auch nicht immer besser aus und Sharepoint zerhaut eh

**2025-09-29 18:07:25** - Julia:
> ja unbedingt. ich hab einfach grad von allen folien 3 verschieden varianten? wegen den versionen

**2025-09-29 18:07:27** - Julia:
> genau

**2025-09-29 18:07:54** - Julia:
> ah willst dus auseinander ziehen? hatte gedacht so wärs kompakter

**2025-09-29 18:07:59** - Julia:
> aber mach ich nächstes mal dann natürlich

**2025-09-29 18:08:09** - Julia H.:
> Ja i know... Ich ziehs auseinander, könnte mir vorstellen, dass Charly das nicht gut findet.

**2025-09-29 18:08:17** - Julia H.:
> Ich würde jetzt mal auch kurz die vorderen Folien rausnehmen

**2025-09-29 18:09:02** - Julia:
> okay got it

**2025-09-29 18:09:10** - Julia H.:
> und hast du vielleicht noch die Halloween PPT für mich? Ich hau das da jetzt auch noch dazu

**2025-09-29 18:09:14** - Julia:
> jaa bitte. hätte es erst ab 4. geschickt – rest muss ich noch machen

**2025-09-29 18:09:32** - Julia:
> ja so doof, ich hab das nur noch als pdf :sob: ich weiß nicht wieso

**2025-09-29 18:09:48** - Julia:
> 

**2025-09-29 18:13:54** - Julia:
> kann ich dir da grad noch was helfen?
Sonst geh ich jetzt mal einkaufen etc. und mach danach noch die BS Slides

**2025-09-29 18:14:08** - Julia H.:
> Ne alles gut, ich mach das nur schnell fertig

**2025-09-29 18:14:39** - Julia:
> okay dankeee und sag mir das gerne auch in Zukunft, was du anpassen würdest, dann mach ich das

**2025-09-29 18:16:00** - Julia:
> guten entspannten Flug und bis morgen! :heart_hands:

**2025-09-29 18:58:15** - Julia H.:
> Daaanke!! Bis morgen

**2025-09-30 11:13:51** - Julia:
> Wie fertig bist du? Hoffe es war alles okay!

**2025-09-30 11:22:58** - Julia H.:
> Ja ich hab tatsächlich gn

**2025-09-30 11:23:03** - Julia H.:
> ganz gut geschlafen

**2025-09-30 11:23:04** - Julia H.:
> also geht

**2025-09-30 11:23:18** - Julia H.:
> reg mich nur grad so über diese CM nachricht auf.

**2025-09-30 11:23:28** - Julia H.:
> gibt es wichtige updates die ich wissen muss

**2025-09-30 11:28:07** - Julia:
> ach sehr gut

**2025-09-30 11:33:57** - Julia:
> schick dir gleich eine sprachi

**2025-09-30 11:34:10** - Julia:
> ja.. die war heute wieder krass drauf auch

**2025-09-30 11:38:31** - Julia H.:
> okee

**2025-09-30 11:38:46** - Julia H.:
> Das ist für mich halt nicht ne zusammenarbeit auf augenhöhe.

**2025-09-30 11:39:06** - Julia H.:
> Dann ist das eindeutig ein internes Problem und nicht ein blaming schon wieder an uns. Ich habe eins zu eins die Texte von vorherigen Antworten übernommen beziehungsweise passe dann sinngemäß an wie in diesem Fall.
Ich werde jetzt sicherlich nicht als Senior anfangen, einzelne CM Nachrichten an 15-jährige jeden Tag mit Charly abzusprechen.

**2025-09-30 11:39:14** - Julia H.:
> Hab ich auch flo gerade gesagt

**2025-09-30 11:39:21** - Julia H.:
> hoffe er nimmt es mir nicht übel

**2025-09-30 11:41:29** - Julia:
> 

**2025-09-30 11:42:27** - Julia:
> ja versteh ich voll!

**2025-09-30 11:43:01** - Julia:
> Ne, da ist nix auf Augenhöhe und vor allem sind wir jetzt zu dumm auf nachrichten zu antworten?

**2025-09-30 11:44:09** - Julia:
> und ich muss auch sagen mit Kunden/ Dienstleistern über WhatsApp UND Sprachnachricht zu kommunizieren, find ich auch ein no go

**2025-09-30 11:47:01** - Julia H.:
> Ich finds auch gerade so unmöglich. Ich will mich eigentlich nicht aufregen über so einen quatsch, aber ich will wirklich nicht gern für dumm gehalten werden.

**2025-09-30 11:51:20** - Julia:
> ja, sowas lässt einen halt auch nicht immer kalt

**2025-09-30 11:53:42** - Julia H.:
> Meld mich gleich

**2025-09-30 12:32:23** - Julia H.:
> sooo jetzt bin ich mal endlich durch damit. Ich sag dir auf jeden fall nächstes mal bescheid, wenn was mit ner präsi nicht passt. Ging dann nur etwas schneller ich war ja eh dran...

Ich glaub Roxanne hat die Bilder auch nicht, hab sie jetzt ja aber angefragt.

Was kann ich sonst noch supporten?

**2025-09-30 12:41:19** - Julia:
> ja sie hatte mir auch schon geantwortet

**2025-09-30 12:41:27** - Julia:
> Ich bastel jetzt so gut es geht. Danke fürs Anfragen!

**2025-09-30 12:41:53** - Julia:
> Ehm TINS PAG kann ich heute nicht starten, das schaff ich alles nicht

**2025-09-30 12:42:53** - Julia H.:
> Ich versuch es mir anzuschauen... Und UGC würde ich heute auch gern fest machen

**2025-09-30 12:43:30** - Julia:
> okay danke. aber andererseits haben wir für Charly diese Insider Posts vorgezogen (Wollte sie am Donnerstag) also vllt beruhigt sie das :smile:

**2025-09-30 12:43:45** - Julia:
> Sobald ich Leonie fertig hab, mach ich BS weiter und dann Anpassungen für Charly von allen Posts

**2025-09-30 13:27:07** - Julia H.:
> Magst du mir Leonie bitte kurz als PDF schicken? Bin schnell im Supermarkt 

**2025-09-30 13:27:41** - Julia:
> yes!

**2025-09-30 14:26:05** - Julia H.:
> Ich hab Basti mal gefragt wegen dem voice over aber ich gehe mal davon aus dass das Leonie selbst ist 

**2025-09-30 14:59:57** - Julia:
> okay danke

**2025-09-30 15:07:20** - Julia:
> Hab die Leonie <https://drive.google.com/drive/folders/138q0OD_QNMJwZ_o2xd6yH8yOCT8ZdWcv|Bilder im Drive >abgelegt – das sind aber nicht alle die wir brauchen. Wir benötigen noch die vom PDF "CMP416_LeonieBeck_verwendet"

**2025-09-30 15:19:05** - Julia H.:
> Hab ihr geschrieben

**2025-09-30 15:19:15** - Julia:
> dankeee

**2025-09-30 15:19:58** - Julia H.:
> oh well....

**2025-09-30 15:20:28** - Julia:
> oh manno, ich mag das VO aber eigentlich

**2025-09-30 15:20:57** - Julia:
> Wenn wir es weglassen, brauchen wir halt "Untertitel"

**2025-09-30 15:21:26** - Julia H.:
> Sie hat ja gemeint ob wir die ersetzen können... Ich glaub auch ohne Text wird es komisch... not sure

**2025-09-30 15:21:41** - Julia:
> ja

**2025-09-30 15:21:43** - Julia:
> voll

**2025-09-30 15:22:49** - Julia H.:
> soll ich basti bescheid geben oder machst du?

**2025-09-30 15:23:14** - Julia:
> ich schreibs ihm in die asana task noch dazu

**2025-09-30 15:25:26** - Julia:
> dann antworte ich Charly auch gleich dazu

**2025-09-30 16:08:30** - Julia:
> lieb ich auch: Charly hatte paar mal Feedback zu den ausgewählten Bildern der Insider Posts und meinte "da gibts viiiel bessere in Picdrop, sie hat die alle markiert"
Joa, ne hat sie nicht und gibts auch nicht :smile:

**2025-09-30 16:13:45** - Julia H.:
> LOL

**2025-09-30 16:13:56** - Julia H.:
> Kann ich irgendwie suchen helfen oder so?

**2025-09-30 16:14:09** - Julia H.:
> Ich glaub ich pack heute nicht mehr mit TINS anzufangen, lass uns das morgen machen zusammen

**2025-09-30 16:14:14** - Julia H.:
> Ich stell uns ein meeting ein

**2025-09-30 16:14:48** - Julia:
> nene alles gut, ich hab paar *VIEL BESSERE* bilder gefunden :smile:

**2025-09-30 16:14:53** - Julia:
> jaa klar, gerne

**2025-09-30 16:17:46** - Julia H.:
> hahaha

**2025-09-30 16:20:55** - Julia:
> 

**2025-09-30 16:32:42** - Julia H.:
> Jaaa logo, ich helfe dir

**2025-09-30 16:33:15** - Julia:
> okay vllt bräuchte ich doch noch jetzt einmal deine Suchhilfe :smile:
--&gt; sie wollte stärkeren Tunnel Bilder v.a. mit Taycan

**2025-09-30 16:33:33** - Julia H.:
> On it!

**2025-09-30 16:33:45** - Julia:
> danke danke danke

**2025-09-30 16:38:36** - Julia:
> das find ich einfach uncool :smile:

**2025-09-30 16:43:30** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/a5f6NA7LQr?file=99e6085ec83bb4f1e18300e5dbbb4419>

<https://www.picdrop.com/porsche-deutschland/a5f6NA7LQr?file=4078324f09f80a5b66095ea1d487bb23>

<https://www.picdrop.com/porsche-deutschland/Wz2uJUMYqw?file=816be6647f2073b0a018fd203cd81114>

**2025-09-30 16:43:42** - Julia H.:
> Bisher finde ich bloß keinen Taycan im Tunnel....

**2025-09-30 16:45:15** - Julia H.:
> Die hier hilft

**2025-09-30 16:45:49** - Julia:
> ahh

**2025-09-30 16:45:52** - Julia:
> cool!

**2025-09-30 16:46:00** - Julia H.:
> Aber lass mich gern beim raussuchen helfen

**2025-09-30 16:48:05** - Julia:
> yes, schicks dir sobald ichs hab

**2025-09-30 16:54:12** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/byiPthgMWn?file=1607def4c9e3b9b54e9b627e4f86ebd7>

**2025-09-30 16:56:45** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/m4Fx865H8x?file=86463496ba68b30b7cf8db336c1d9e23>

**2025-09-30 16:56:58** - Julia H.:
> Hab jetzt nochmal doppelt alle ordner gescreent finde keine taycan tunnel bilder

**2025-09-30 16:57:28** - Julia:
> ja oder? aber danke! ich nehme mal eins von denen

**2025-09-30 16:57:40** - Julia H.:
> Außer sie meint das: <https://www.picdrop.com/porsche-deutschland/m4Fx865H8x?file=d14189d19af8be6043978fcdc751d2ad> Aber das ist halt kein tunnel :stuck_out_tongue:

**2025-09-30 16:58:14** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/m4Fx865H8x?file=3a37554ea09f73f3b2297a8d54b55e75>

**2025-09-30 16:58:24** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/m4Fx865H8x?file=d8831be68cd1aaa6e323c087014c8ed9>

**2025-09-30 16:58:34** - Julia:
> das eine hatte ich, wollte sie nicht :smile:

**2025-09-30 16:58:40** - Julia H.:
> das waren jetzt alle tunnelbilder

**2025-09-30 17:02:42** - Julia:
> vorher - nachher NAJA :smile:

**2025-09-30 17:13:42** - Julia H.:
> Joaaa.... mich stört bisschen, dass die eine hälfte wärmer sind und die andere kälter

**2025-09-30 17:14:00** - Julia H.:
> aber ob das wohl unsere insta follower stört? i daut it

**2025-09-30 17:21:38** - Julia:
> i daut it 2. aber ist als auswahl gedacht, nicht carousel

**2025-09-30 17:24:10** - Julia:
> hab Basti die Mail von Charly weitergeleitet

**2025-09-30 17:28:24** - Julia H.:
> ah ok dann passt es doch

**2025-09-30 17:28:26** - Julia H.:
> lets see

**2025-09-30 17:31:27** - Julia:
> hier das Update. Hab immer dazu geschrieben, wenn und was angepasst wurde oder ich es komplett neu hinzugefügt habe

**2025-09-30 17:33:14** - Julia:
> VBWs noch tbd.

**2025-09-30 17:33:54** - Julia H.:
> Supi, schau ich mir asap an. Haben wir noch Links zu den Reels, die du in die UGC gepackt hast?

**2025-09-30 17:35:07** - Julia:
> ehm nee. hab nur screenshots gemacht :face_with_peeking_eye: soll ich sie raussuchen?

**2025-09-30 17:36:29** - Julia H.:
> Sonst kann ich auch raussuchen

**2025-09-30 17:37:42** - Julia:
> ich suche

**2025-09-30 17:42:54** - Julia:
> links auf slide 16 sind hinzugefügt

**2025-09-30 17:44:14** - Julia:
> Das Reel von Slide 15 hab ich wieder rausgenommen – da hatte Charly heute noch paar mal erwähnt, dass es auf keinen Fall sein darf, dass die StVo nicht eingehalten werden. ok

**2025-09-30 18:01:56** - Julia:
> Ist basti jetzt weg?

**2025-09-30 18:09:23** - Julia H.:
> Kann gut sein

**2025-09-30 18:15:59** - Julia:
> oh ne ich habs ihm ja gesagt..?

**2025-09-30 18:16:36** - Julia H.:
> Sollte das heute noch fertig werden?

**2025-09-30 18:16:41** - Julia H.:
> Sonst kannst du mal Flo fragen

**2025-09-30 18:16:45** - Julia H.:
> ich muss jetzt nämlich wegh

**2025-09-30 18:21:52** - Julia:
> ja

**2025-09-30 18:22:00** - Julia:
> sie hatte halt geschrieben sie will es heute EOB

**2025-09-30 18:22:34** - Julia:
> ich kann Flo schreiben, aber will jetzt nicht "petzen"

**2025-09-30 18:25:04** - Julia:
> ich schreib ihm. happy feierabend und hoffe du bist gedanklich jetzt auch wieder in kapstadt angekommen :slightly_smiling_face::heart:

**2025-09-30 18:58:34** - Julia H.:
> Danke Juli :kissing_heart: :kissing_heart: :kissing_heart: 

**2025-09-30 19:01:11** - Julia H.:
> 

**2025-10-01 07:40:40** - Julia:
> Oh wie schön :heart_eyes: 

**2025-10-01 08:33:17** - Julia H.:
> Good morning, kommst du heute mit in das Brand Store meeting um 10:30? Bin nicht sicher, ob du eingeladen bist von flo.

**2025-10-01 08:33:24** - Julia H.:
> Bin nur grad beim BS bisschen außen vor

**2025-10-01 09:09:48** - Julia:
> Hello! Kann ich machen, klar

**2025-10-01 09:10:18** - Julia:
> bin nicht eingeladen

**2025-10-01 09:10:37** - Julia:
> muss nur um 11.30 raus und los zum arzt

**2025-10-01 09:10:41** - Julia H.:
> ________________________________________________________________________________
Microsoft Teams Need help?&lt;<https://aka.ms/JoinTeamsMeeting?omkt=en-US>&gt;
Join the meeting now&lt;<https://teams.microsoft.com/l/meetup-join/19%3ameeting_ZTM0MTEzN2UtYzc4ZC00YzIwLWE0YzAtZDA5NTUyNTFmNTM3%40thread.v2/0?context=%7b%22Tid%22%3a%2254545b25-e3ed-4f76-9665-e6a7a09c0152%22%2c%22Oid%22%3a%22cf70d133-896d-4716-9f30-21f8765a4a52%22%7d>&gt;
Meeting ID: 375 872 326 056 1
Passcode: HX6JF7dt
________________________________
For organizers: Meeting options&lt;<https://teams.microsoft.com/meetingOptions/?organizerId=cf70d133-896d-4716-9f30-21f8765a4a52&amp;tenantId=54545b25-e3ed-4f76-9665-e6a7a09c0152&amp;threadId=19_meeting_ZTM0MTEzN2UtYzc4ZC00YzIwLWE0YzAtZDA5NTUyNTFmNTM3@thread.v2&amp;messageId=0&amp;language=en-US>&gt;
________________________________________________________________________________

**2025-10-01 09:12:46** - Julia H.:
> 10:30

**2025-10-01 09:18:37** - Julia:
> passt, danke!

**2025-10-01 09:35:39** - Julia:
> hab die bilder von leonie wieder abgelegt

**2025-10-01 10:02:28** - Julia H.:
> Huhu, sorry, kurz etwas zusammenhangslos aus dem Meeting, gleich mehr dazu:

Halloween: Black &amp; White Bilder Gipfeltreffen oder evtl Oranges Auto?
--&gt; <https://www.instagram.com/p/DO5i8gpDJDe/?igsh=MXN2aTcyanFxbW15Mw==> sowas könnte man machen mit AI für Halloween. mit Fledermäusen, Pumpkins.... Solange wir am Fahrzeug nicht verändern, ist das okay.
Porsche Points auf Gipfeltreffen --&gt; Auf Roads App verlinken

**2025-10-01 10:03:13** - Julia H.:
> Und FYI

**2025-10-01 10:05:51** - Julia:
> halloween hab ich auf dem schirm und bin ich eh für heute dran, da noch mehr zu machen. gestern nicht geschafft

**2025-10-01 10:06:19** - Julia:
> kannst mich gerne kurz anrufen, wenn du vorm meeting sprechen willst

**2025-10-01 10:06:47** - Julia H.:
> easy, geht ja nicht alles auf einmal.

**2025-10-01 10:18:23** - Julia:
> soll ich dann in den BS Call überhaupt mit rein?

**2025-10-01 10:29:32** - Julia H.:
> Ja wäre gut, ich bin da gerade null up to date und die sachen stehen noch nicht im redaktionsplan

**2025-10-01 10:46:58** - Julia:
> sprechen wir nach 11 noch kurz?

**2025-10-01 10:56:39** - Julia H.:
> <https://www.picdrop.com/roserbrothers/UcybkS1Ehk?file=9df8e108ed16e0be65f37b5f7c0a5cf6>

**2025-10-01 10:56:41** - Julia H.:
> yes

**2025-10-01 11:01:46** - Julia H.:
> Schau mal wie fändest du das noch zum Oktoberfest post?

**2025-10-01 11:01:58** - Julia:
> joooa

**2025-10-01 11:02:06** - Julia H.:
> <https://meet.google.com/gwf-zuzb-jvi>

**2025-10-01 11:24:16** - Julia:
> was hat charly denn überhaupt gesagt zu den updates

**2025-10-01 11:24:48** - Julia H.:
> Zu welchen Updates meinst du?

**2025-10-01 11:25:53** - Julia:
> oh sorry, das war noch meine nachricht von vorhin, wurde nicht abgeschickt :smile:

**2025-10-01 11:42:19** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/a5f6NA7LQr?file=2ef97073f97e2f1e9a5d9efe3a5b41cb>

<https://www.picdrop.com/porsche-deutschland/a5f6NA7LQr?file=a27f05ae9ba1724c9d95f64eadcbd7e0>

<https://www.picdrop.com/porsche-deutschland/a5f6NA7LQr?file=c48491a47731fa1b2d9b3dd7b32b0a2a>

<https://www.picdrop.com/porsche-deutschland/a5f6NA7LQr?file=e131270629e55ea1b0ed8ba001de71c5>

<https://www.picdrop.com/porsche-deutschland/a5f6NA7LQr?file=029000f23e9c22cf012a0b4635eedeed>

<https://www.picdrop.com/porsche-deutschland/m4Fx865H8x?file=8f5d712ac17af6ddb4429c807e33d856>

<https://www.picdrop.com/porsche-deutschland/m4Fx865H8x?file=48e4953e3d1de9733544bf25257cd8d2>

<https://www.picdrop.com/porsche-deutschland/gEYiuo19xM?file=d4a41d5a2f43c5e2a6e592a816f414f1>

<https://www.picdrop.com/porsche-deutschland/gEYiuo19xM?file=a63609580086d9673cbbd740e2b8663e>

<https://www.picdrop.com/porsche-deutschland/gEYiuo19xM?file=5729e6fb304ba5bada31ca39c2bd6a25>

**2025-10-01 11:42:35** - Julia H.:
> Ich hab mal hier noch rausgesucht.... Können wir glecih mal zusammen durchgehen

**2025-10-01 11:44:39** - Julia:
> hab meine auch da raus. 
Cool danke! Ja bei manchnen war ich unsicher, ob orange dann „so lala“ ist, weil es ja auch grün markierte gibt 

**2025-10-01 14:19:36** - Julia:
> so witzig --&gt; das hatte ich Charly gesagt wegen Halloween :smile:

**2025-10-01 14:30:59** - Julia H.:
> haha wow

**2025-10-01 14:48:07** - Julia:
> Hast du die Themen von Hanna gesehen? Puh, das ist viel

**2025-10-01 15:12:33** - Julia H.:
> ne noch nicht... Mach jetzt mal kurz _de fertig und dann kommt der BS

**2025-10-01 17:18:58** - Julia:
> ich muss kurz zum tierarzt, schicke das GIF heute noch raus! Da werden sie ja eh Feedback haben

**2025-10-01 17:19:19** - Julia:
> Bezüglich der Foto/Videografen --&gt; was ist unser Budget?

**2025-10-01 17:32:45** - Julia H.:
> Oh ist alles ok mit coco??

**2025-10-01 17:32:52** - Julia H.:
> eigentlich nur 500 € am tag

**2025-10-01 18:55:56** - Julia H.:
> Charly hat schon für das carousel Feedback in die Präsi, müssten wir nur morgen früh anpassen 

**2025-10-01 19:59:29** - Julia:
> jaa alles okay. Musste nur für Ersin gehen, weil der doch nicht konnte  

**2025-10-01 20:26:04** - Julia:
> ich sehs leider nicht. du müsstest mir das morgen kurz schicken. dankee :slightly_smiling_face:

**2025-10-02 08:46:19** - Julia:
> GuMooo

**2025-10-02 08:47:21** - Julia H.:
> Good morning, ich bin gerade in der Präsi, sie hat ein paar Ideen hier runtergeschrieben. PPT slide hab ich schnell exportiert mit denen die rausgeflogen sind.

Ich hab es mal für uns aufgeteilt. Wir könnten eventuell auch zwei Posts draus machen. Wie kann ich hier am besten kurz helfen?

-Gruppenfoto über 2 Slides?
-Steven - <https://www.picdrop.com/porsche-deutschland/rR5RsPjgdg?file=d7bd2ca7dbc7895cce5bc24099b60b65|01_Charly Only_Posts> (Kann zur Not weggelassen werde, da er ja mit Robert und Basti abgebildet ist)
-Axel &amp; Malmedie - <https://www.picdrop.com/porsche-deutschland/givDRaqgqB?file=79a2258cfc68606c71008735dfc6be5e|Axel Stein und Matthias Malmedie_REST>
-Dietmar Wunder - <https://www.picdrop.com/porsche-deutschland/rR5RsPjgdg?file=93fee68e13d60922216285855fe3f27e|01_Charly Only_Posts>
-David Puentez
-Jörg Bergmeister

-Heizr
-Petrosurf - <https://www.picdrop.com/porsche-deutschland/gEYiuo19xM?file=5ca2f3203ca4b4f7c623ba48a0fafe3d|00_Rest Bilder und Red Flags>
-Onassis - <https://www.picdrop.com/porsche-deutschland/Wz2uJUMYqw?file=cde51aa89fea24dd699c2595027315d5|00_Rest Bilder und Red Flags>
-Curves - <https://www.picdrop.com/porsche-deutschland/Wz2uJUMYqw?file=be666afb356c08c7b5c4992abad870f6|00_Rest Bilder und Red Flags>
-Type 7 - <https://www.picdrop.com/porsche-deutschland/GmWN14LSFX?file=6a451746415939da1bb0e798cc8cc465|Type 7>
-Porsche Club Deutschland - <https://www.picdrop.com/porsche-deutschland/rR5RsPjgdg?file=cfebc0735a8fd29931d30f57ce2f33a4|01_Charly Only_Posts>

-PLX - <https://www.picdrop.com/porsche-deutschland/rR5RsPjgdg?file=44196005256ec7a424933cd0c085adf3|01_Charly Only_Posts>
-Mobil 1 - <https://www.picdrop.com/porsche-deutschland/rR5RsPjgdg?file=e100f4dd9514a4123a971604570de1e9|01_Charly Only_Posts> ODER <https://www.picdrop.com/porsche-deutschland/rR5RsPjgdg?file=c57154b1d24d4c302876f8f86f6e815a|01_Charly Only_Posts>
-Leica - <https://www.picdrop.com/porsche-deutschland/7VunB6Avw5?file=e105233c9f87ca0ef7106fb1ca517f87|Leica_Rest> ODER <https://www.picdrop.com/porsche-deutschland/7VunB6Avw5?file=b2f322b48722be2310cfc431afce4eef|Leica_Rest>
-OMR - <https://www.picdrop.com/porsche-deutschland/m4Fx865H8x?file=48e4953e3d1de9733544bf25257cd8d2|00_Rest Bilder und Red Flags> ODER <https://www.picdrop.com/porsche-deutschland/m4Fx865H8x?file=ea20eaaf8205e6ff3d9e14152d3568d2|00_Rest Bilder und Red Flags> (OMR muss auch nicht zwingend)
-Automotorsport
-
-Basti - <https://www.picdrop.com/porsche-deutschland/rR5RsPjgdg?file=e1b18b6b9e3c14e0bbd0252f35311f31|01_Charly Only_Posts> (Kann zur Not weggelassen werden, da er auf anderen Bildern ist)
-Robert – nur bitte richtig zuschneiden
-
-Girls - <https://www.picdrop.com/porsche-deutschland/rR5RsPjgdg?file=2ba01a5ce17dedfc22b4a075e72f6c27|01_Charly Only_Posts>
-
-*Muss nicht, kann:* 
-Gruppe - <https://www.picdrop.com/porsche-deutschland/rR5RsPjgdg?file=2e9dc3c388d6d2f88edcf1b83efc4563|01_Charly Only_Posts>
-Content crew - <https://www.picdrop.com/porsche-deutschland/rR5RsPjgdg?file=be9dcc71e180c9a69da80f01aed9c9dd|01_Charly Only_Posts>
-Hug - <https://www.picdrop.com/porsche-deutschland/Wz2uJUMYqw?file=147bdc475500d3ee7c3b385ef53ab527|00_Rest Bilder und Red Flags>

**2025-10-02 08:48:41** - Julia:
> kannst du mir einen screenshot schicken?

**2025-10-02 08:49:18** - Julia H.:
> Logo

**2025-10-02 08:49:21** - Julia H.:
> 

**2025-10-02 08:49:33** - Julia H.:
> Sag bescheid, wie ich am besten helfen kann

**2025-10-02 08:50:09** - Julia:
> okay danke! Und die notizen von oben sind von dir?

**2025-10-02 08:50:48** - Julia:
> Bzw. ist die Auflistung von oben jetzt für das family carousel oder für das partner carousel?

**2025-10-02 08:50:48** - Julia H.:
> Ne von Charly, sie hatte uns geholfen, dass wir finden, wer noch rein sollte

**2025-10-02 08:50:54** - Julia H.:
> Family Carousel

**2025-10-02 08:51:12** - Julia:
> ah okay. also sollen die partner dann auch ins family?

**2025-10-02 08:52:42** - Julia H.:
> Da sind im Grunde die Personen drauf, gar nicht nur ein Becher z.B.

**2025-10-02 08:56:45** - Julia H.:
> okay gut!!

**2025-10-02 08:59:30** - Julia:
> --&gt; aber jetzt nochmal:

PLX - <https://www.picdrop.com/porsche-deutschland/rR5RsPjgdg?file=44196005256ec7a424933cd0c085adf3|01_Charly Only_Posts>
-Mobil 1 - <https://www.picdrop.com/porsche-deutschland/rR5RsPjgdg?file=e100f4dd9514a4123a971604570de1e9|01_Charly Only_Posts> ODER <https://www.picdrop.com/porsche-deutschland/rR5RsPjgdg?file=c57154b1d24d4c302876f8f86f6e815a|01_Charly Only_Posts>
-Leica - <https://www.picdrop.com/porsche-deutschland/7VunB6Avw5?file=e105233c9f87ca0ef7106fb1ca517f87|Leica_Rest> ODER <https://www.picdrop.com/porsche-deutschland/7VunB6Avw5?file=b2f322b48722be2310cfc431afce4eef|Leica_Rest>
-OMR - <https://www.picdrop.com/porsche-deutschland/m4Fx865H8x?file=48e4953e3d1de9733544bf25257cd8d2|00_Rest Bilder und Red Flags> ODER <https://www.picdrop.com/porsche-deutschland/m4Fx865H8x?file=ea20eaaf8205e6ff3d9e14152d3568d2|00_Rest Bilder und Red Flags> (OMR muss auch nicht zwingend)
-Automotorsport

Die Bilder sind auch ohne Personen: die sind doch dann fürs Partner Carousel? Das macht ja keinen Sinn das 2x zu zeigen

**2025-10-02 09:00:55** - Julia H.:
> Hmm moment

**2025-10-02 09:01:22** - Julia:
> was hat sie denn bei der 2. slide geschrieben? sonst schick mir das gerne auch mal

**2025-10-02 09:01:23** - Julia H.:
> Okay jetzt macht es Sinn

**2025-10-02 09:01:53** - Julia:
> okay danke

**2025-10-02 09:02:08** - Julia:
> ja beide/3 schaffe ich jetzt nicht

**2025-10-02 09:03:42** - Julia H.:
> Also das zweite fällt ja so raus wie ich das verstehe oder?

**2025-10-02 09:04:17** - Julia:
> Ne da wollte sie dann quasi reine Collab-Posts 2x

**2025-10-02 09:09:38** - Julia H.:
> Okay verstehe. Der muss aber nicht jetzt heute morgen ready sein, nur der andere People Post

**2025-10-02 09:11:43** - Julia:
> ist das die gleiche Person? hahaha

**2025-10-02 09:14:10** - Julia:
> glaube ja

**2025-10-02 09:15:10** - Julia H.:
> Yes

**2025-10-02 09:15:14** - Julia H.:
> das ist der jörg bergmeister

**2025-10-02 09:15:16** - Julia:
> jaa

**2025-10-02 09:15:24** - Julia:
> war mir nur unsicher, weil den hatte ich schon drin

**2025-10-02 09:15:26** - Julia:
> danke :smile:

**2025-10-02 09:15:28** - Julia:
> es ist noch zu früh

**2025-10-02 09:18:28** - Julia:
> Ich hab kein Bild von Heizr --&gt; weißt du wer das ist?

**2025-10-02 09:19:29** - Julia:
> ah ne stop, hab ich. ist der dude im beigen

**2025-10-02 09:19:36** - Julia H.:
> Moment das weiß ich

**2025-10-02 09:20:08** - Julia H.:
> Felix

**2025-10-02 09:20:08** - Julia H.:
> 

**2025-10-02 09:20:11** - Julia:
> der :slightly_smiling_face: habs gegoogelt

**2025-10-02 09:20:13** - Julia:
> genau!

**2025-10-02 09:23:21** - Julia H.:
> 

**2025-10-02 09:23:35** - Julia H.:
> 

**2025-10-02 09:23:35** - Julia H.:
> vielleicht hilft das

**2025-10-02 09:23:52** - Julia:
> dankeee

**2025-10-02 09:23:54** - Julia:
> sind alle drin

**2025-10-02 09:24:09** - Julia:
> also solala, gibt nicht von allen bildern

**2025-10-02 09:25:44** - Julia H.:
> Sag bescheid, wenn ich was suchen soll?

**2025-10-02 09:27:40** - Julia H.:
> Wir müssen nochmal irgendwie versuchen grundsätzlich intern zu reviewen oder dazu einen Prozess zu finden.
Es waren noch viele Fehler in der Präsi die meisten von mert. Normalerweise arbeitet er ja sehr gewissenhaft und ich hab ja auch drüber geschaut, aber das war natürlich viel und schnell, also übersieht man. Müssten wir versuchen zu vermeiden irgendwie. Aber not sure how...

**2025-10-02 09:27:55** - Julia H.:
> also fyi

**2025-10-02 09:28:41** - Julia H.:
> Wie kann ich noch supporten in Sachen Präsi

**2025-10-02 09:29:00** - Julia H.:
> weil sonst mach ich kurz CM

**2025-10-02 09:32:09** - Julia:
> Also wir sind damit jetzt bei 22 Bildern --&gt; es gehen im Carousel nur 20. Deshalb würde ich die roten rauslassen. Können es ihr ja aber gerne so zeigen und sie entscheidet dann.
Titelbild 1 oder 2 hat sie nix gesagt oder?
Magst du das so reinlegen in die Präsi? Sonst liegen alle einzelnen Bilder hier: <https://drive.google.com/drive/folders/1SDKZJ6GBvTHM4sPRqWM29IHnzdCaKxZD>

**2025-10-02 09:32:41** - Julia H.:
> Sieht doch super aus!

**2025-10-02 09:32:49** - Julia H.:
> Ich schmeiss den Screenshot so rein oder?

**2025-10-02 09:32:56** - Julia:
> verstanden. ich hab da auch nichtmehr drüber geguckt.
Ja von meiner Seite auch 100% einfach gerade die zeitliche Komponente

**2025-10-02 09:33:01** - Julia:
> gerne!

**2025-10-02 09:33:02** - Julia:
> dankee

**2025-10-02 09:34:04** - Julia H.:
> Was noch fehlt wäre das Gruppenbild

**2025-10-02 09:34:21** - Julia H.:
> oder ging das nicht

**2025-10-02 09:34:46** - Julia:
> Falls du noch Notes dazuschreiben willst:
Axel &amp; Malmedie --&gt; raus, weil eh scho Reel und viel Content
Leica --&gt; kommt dann nochmal im Partner Post
Basti --&gt; schon 2,5 mal drin

**2025-10-02 09:35:11** - Julia:
> Wie gesagt wir können nur 20 Bilder nehmen, dann müssen andere raus und dann fehlt immer irgendwer

**2025-10-02 09:35:56** - Julia:
> also das hier oder eins von der Porsche Crew?

**2025-10-02 09:36:30** - Julia H.:
> ne dieses gesamt bild aus der garage

**2025-10-02 09:36:32** - Julia H.:
> moment

**2025-10-02 09:37:11** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/m4Fx865H8x?file=8f5d712ac17af6ddb4429c807e33d856>

**2025-10-02 09:37:26** - Julia:
> ah okay

**2025-10-02 09:37:42** - Julia:
> hmm ja vllt eher in den partner post?

**2025-10-02 09:38:13** - Julia:
> 

**2025-10-02 09:41:13** - Julia:
> dann ist es so
Stephan Bogner raus
Basti &amp; Robert raus (kein schönes Bild)

**2025-10-02 09:41:18** - Julia H.:
> Besser!!

**2025-10-02 09:41:43** - Julia:
> okay

**2025-10-02 09:41:54** - Julia:
> wie gesagt rot müsste noch raus (oder andere) sonst passt es nicht

**2025-10-02 09:42:05** - Julia H.:
> Okay top, ich schick es ihr schnell

**2025-10-02 09:42:11** - Julia:
> dankee

**2025-10-02 09:42:56** - Julia H.:
> Aber 2 Posts draus zu machen findest du nicht gut oder?

**2025-10-02 09:44:10** - Julia:
> Ne

**2025-10-02 09:44:34** - Julia:
> dann haben wir 4 posts zu menschen/ partner

**2025-10-02 10:07:15** - Julia:
> <https://www.figma.com/design/902cDjeQLIyg77xt49VdZg/Porsche-DE-%F0%9F%8F%8E%EF%B8%8F?node-id=0-1&amp;t=pzFNwcu432DhhC9W-1>

**2025-10-02 10:11:55** - Julia:
> 

**2025-10-02 10:15:30** - Julia:
> 

**2025-10-02 10:16:36** - Julia:
> 

**2025-10-02 10:37:39** - Julia:
> --&gt; soundaholic mit rein

**2025-10-02 10:41:45** - Julia H.:
> Ja i know :disappointed:

**2025-10-02 11:47:04** - Julia:
> Julia, ich sags wie es ist: ich hab gerade erstmal geheult. Boah ich finde diese Zusammenarbeit (in dem Fall jetzt Charly) soo krass. Ich weiß nicht, ob und wielange ich das mitmachen kann, mal ganz transparant

**2025-10-02 11:50:16** - Julia H.:
> Oh juuuuli, tut mir so leid. :disappointed:
Ich versteh das, aber es gibt auch solche und solche tage. Ich hab das auch so oft und dann ist es wieder besser am nächsten Tag.
In der Dienstleistung zu sein ist auch wirklich schwer. Du kannst dich immer auskotzen bei mir.
Das ist auf jeden Fall nichts für die Ewigkeit. Wir nehmen das mit so lange es geht und dann bye.

**2025-10-02 11:50:25** - Julia H.:
> Und nach heute erstmal long weekend.

**2025-10-02 11:59:10** - Julia H.:
> :heart:

**2025-10-02 12:14:03** - Julia:
> Danke :heart: Ja ich weiß, ist auch tagesbedingt. Es macht mich einfach nur sehr sauer, wenn die eigene Expertise nicht gesehen wird und man mit Leuten wirklich über Basics diskutiert wie Bildfarben, Bildauswahl, Anschnitte etc. Und heute hatte ich echt den krassen Eindruck, dass sie uns dumm darstellt. Finde das so unverschämt! Alter du bist ungefähr die krasseste Frau die ich kenne und sie meint dir sagen zu müssen, wie du deinen Job machen sollst?
AHHH

**2025-10-02 12:36:34** - Julia:
> Vllt noch für UGC? schon sehr cute

**2025-10-02 12:37:12** - Julia:
> Moody.. Halloween?

**2025-10-02 12:39:13** - Julia:
> auch halloween

**2025-10-02 12:39:36** - Julia:
> ich such gerade dua lipa, deshalb :smile:

**2025-10-02 12:45:23** - Julia H.:
> Ich weiß mir geht es so oft so. Da müssen wir einfach bisschen lernen drüber zu stehen. Und ich glaube das kann auch besser werden, wenn sie uns mehr vertraut, aber dafür müssen wir auch mehr fehlerfrei arbeiten und seitens Porsche gehört natürlich auch einiges dazu.

Ist halt irgendwie auch immer harter David Trigger LOL. Aber wir schaffen das!!

Und danke für das Kompliment. Kann ich nur zurückgeben :heart:

**2025-10-02 12:45:41** - Julia H.:
> cuuuute

**2025-10-02 12:46:33** - Julia H.:
> das ist sehr nice, aber leider kennzeichen :disappointed:

**2025-10-02 12:46:53** - Julia H.:
> Die Links zu den reels seh ich irgendwie nicht, wo hattest du die denn reingepacjt?

**2025-10-02 12:47:32** - Julia:
> von UGC?

**2025-10-02 12:47:35** - Julia H.:
> yes

**2025-10-02 12:47:42** - Julia:
> bei der Seite Reels direkt in den Text

**2025-10-02 12:47:55** - Julia:
> ahh das geht dann nicht? verstehe

**2025-10-02 14:44:14** - Julia:
> Das GIF :relaxed::heart:

**2025-10-02 14:48:40** - Julia H.:
> Meine Astro Freundin sagt immer: Menschen die uns so aufregen und triggern sind unsere größten Lehrer...

**2025-10-02 14:53:12** - Julia:
> Wahrscheinlich echt so

**2025-10-02 14:53:42** - Julia:
> Soll ich bezüglich der Prio die GIFs heute noch erstellen oder Targa Event?

**2025-10-02 15:01:53** - Julia H.:
> Ich hab gerade alle Fotografen Anfragen rausgeschickt. Ich denke Event hätte an sich Prio, damit wir das heute ncoh abstimmen können. Hab heute erst erfahren dass Hanna Montag nicht da ist

**2025-10-02 15:02:11** - Julia H.:
> Ja ich struggle auch noch damit :stuck_out_tongue:

**2025-10-02 15:55:34** - Julia H.:
> 

**2025-10-02 15:55:50** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/rR5RsPjgdg?file=e1b18b6b9e3c14e0bbd0252f35311f31>

**2025-10-02 15:56:06** - Julia H.:
> Das soll noch rein. Für den Asiaten brauchen wir vielleicht eins mit mehr leuten drauf, wenn es das nciht gibt okay

**2025-10-02 15:56:28** - Julia H.:
> Hier bitte den Taycan nciht wegschneiden

**2025-10-02 16:01:13** - Julia:
> es sind einfach super viele neue bilder in picdrop wow

**2025-10-02 16:03:17** - Julia H.:
> really??

**2025-10-02 16:03:34** - Julia H.:
> ich bin jetzt kurz auf dem heimweg aber dann wieder erreichbar

**2025-10-02 16:07:38** - Julia:
> 

**2025-10-02 16:24:20** - Julia H.:
> Danke Juli :heart:

**2025-10-02 16:24:29** - Julia:
> gernee

**2025-10-02 16:34:19** - Julia H.:
> Was ist denn er für ne maus. das ist der eine fotograf :slightly_smiling_face:

**2025-10-02 16:34:28** - Julia H.:
> so sweet sieht der aus

**2025-10-02 16:39:03** - Julia:
> haha voooll

**2025-10-02 16:40:12** - Julia H.:
> sooo ne maus....

**2025-10-02 16:40:22** - Julia H.:
> :face_holding_back_tears:

**2025-10-02 16:40:54** - Julia:
> hab dir in Asana die BS Stories + Feedpost abgelegt

**2025-10-02 16:43:19** - Julia H.:
> coool, also das kann heute gepostet werden oder wurde da nochmal was mit Hanna besprochen

**2025-10-02 16:43:42** - Julia:
> Ich weiß nur bei einer Slide nicht, welche Version sie will. Hatte ihr ne Mail dazu geschickt

**2025-10-02 16:43:53** - Julia:
> aber ihre kommentare in präsi waren: finaler input

**2025-10-02 16:43:58** - Julia H.:
> okay...

**2025-10-02 16:57:34** - Julia H.:
> Würde jetzt die Stories posten, passt das so mit ihrer mail dann?

**2025-10-02 16:57:51** - Julia:
> ich lösche die story variante schnell raus

**2025-10-02 16:58:17** - Julia H.:
> hab schon runtergeladen. Also wir nehmen was neues?

**2025-10-02 16:58:30** - Julia H.:
> Schicks mir sonst einfach gern hier rein

**2025-10-02 16:58:50** - Julia:
> ne wir nehmen das mit der headline: Willkommen im BS

**2025-10-02 16:58:50** - Julia H.:
> bzw es bleibt einfach bei dem?

**2025-10-02 16:58:55** - Julia:
> genau

**2025-10-02 16:59:10** - Julia H.:
> top!!

**2025-10-02 16:59:17** - Julia H.:
> und die highlights bleiben erstmal die alten oder?

**2025-10-02 17:00:13** - Julia:
> hat sie kein finales feedback gegeben, also ja

**2025-10-02 17:00:57** - Julia H.:
> bin gerade am posten schau gerne parallel rein ob alles ok

**2025-10-02 17:01:26** - Julia:
> on it

**2025-10-02 17:03:23** - Julia:
> okay passt

**2025-10-02 17:03:31** - Julia:
> TINS dann ja erst nächste woche

**2025-10-02 17:05:31** - Julia H.:
> Ja genau

**2025-10-02 17:07:36** - Julia:
> Community Carousel wäre hier: <https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1211508608563798?focus=true>

**2025-10-02 17:10:09** - Julia:
> Ich muss jetzt mit Coco raus, ich bin immernoch im Schlafi hier. Ich versuche später noch das für den Targa zu machen, aber ich brauche echt kurz eine Pause

**2025-10-02 17:15:29** - Julia H.:
> Thank you!!
Ja verstehe. Glaub Hanna ist dann weg. Dann müssen wir das Dienstag abstimmen. Wird schon, ist ja nur das small Reel und Foto oder?

**2025-10-02 17:16:58** - Julia:
> ja genau, also ich würde halt in das Carousel evtl. kurze Video Snippets einbauen (wenn der videograf) das kann. Sonst nur Stills und mischen mit Buch Inhalten/ Zitaten für Story + Feed

**2025-10-02 17:23:22** - Julia:
> 

**2025-10-02 17:26:41** - Julia H.:
> Kein problem Juli!! Bildauswahl passt auf jeden Fall. Relax dich, wir kriegen das hin

**2025-10-06 10:57:08** - Julia:
> Huhuu, ich hab hier von Folie 23 - 27 mal das Targa Konzept eingefügt
<https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/doc2.aspx?sourcedoc=%7BE33428F9-BF0F-4720-B9FE-D8EDF165E52E%7D&amp;file=250924_Porsche_BS_SoMe_Konzepte_JH.pptx&amp;action=edit&amp;mobileredirect=true|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/doc2.aspx?sourcedoc=%7BE3342[…]_BS_SoMe_Konzepte_JH.pptx&amp;action=edit&amp;mobileredirect=true>

**2025-10-06 13:14:03** - Julia:
> Also die Partner Carousels sind schon sehr trocken.

1. das wäre mein Vorschlag zum PLX Post --&gt; hier könnte man halt nicht nur den Random Kaffeebecher zeigen, sondern mehr, was bedeutet Porsche Lifestyle eigentlich. 
Sneaker hier zu zeigen find ich witzig wegen Sypder + Sypder Cowboy abe

**2025-10-06 13:16:25** - Julia:
> 2. Leica --&gt; Hier ist die Idee das Carousel mit Fotos die aus den Winkeln entstanden sein könnten anzureichern

**2025-10-06 14:04:01** - Julia H.:
> Huhuu,
nice, das Leica mag ich ganz gerne.
Bei PLX finde ich das 2. und 4 bild können raus.... Rest kommt auch bisschen auf die Caption an, also den Angle...

**2025-10-06 14:06:11** - Julia H.:
> I like. Einzige Sorge die ich habe, wäre hier, dass wir aktuell nur Foto&amp;Video in einem haben und er allein nicht alles abdecken kann. Wir bräuchten ja hier noch ton oder war das nur als Zitat gedacht? Wobei... Auch Zitat müsste ja jemand die Frage stellen und vermerken...

**2025-10-06 14:20:14** - Julia:
> 

**2025-10-06 14:22:30** - Julia H.:
> Hmm ja grundsätzlich denke ich ja. Nur wenn jetzt der Typ komplett neu ist... Not sure, wie er sich zurecht findet und auch wie confident er spricht/sich bewegt auch vor den Kunden...

**2025-10-06 14:22:46** - Julia H.:
> Julian hat leider keine Zeit, wir haben noch einen der ist super, aber teurer, ich sprech mal mit flo

**2025-10-06 14:23:18** - Julia:
> hmm okay

**2025-10-06 14:24:02** - Julia:
> Wir können es ihm ja mal zeigen und dann auch schauen wie er reagiert – wenn er jetzt komplett überfordert ist, gehts natürlich nicht

**2025-10-06 14:25:20** - Julia H.:
> Ja machen wir auf jeden Fall mal gleich. Ich hab mal parallel Flo gefragt. Eventuell wäre es auch ne Option, dass Basti mitkommt und Fotos macht, das haben wir schon mal so gemacht zumindest

**2025-10-06 14:25:34** - Julia:
> ahh okay, auch cool!

**2025-10-06 15:01:11** - Julia:
> kommst du auch in den call oder soll ich alleine?

**2025-10-06 15:39:06** - Julia H.:
> der ist so mausig ich kann nicht mehr

**2025-10-06 15:39:11** - Julia:
> JA

**2025-10-06 15:39:13** - Julia:
> ganz süß

**2025-10-06 15:39:20** - Julia:
> glaube der gibt sich ganz viel Mühe

**2025-10-06 15:39:42** - Julia H.:
> ich glaub auch. hoffe das wird gut

**2025-10-06 15:42:54** - Julia:
> jaa

**2025-10-06 16:20:56** - Julia:
> Ich hab dir gerade eine Präsentation geteilt --&gt; hat das geklappt? :smile:

**2025-10-06 17:19:59** - Julia:
> <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/EZ7TLT66epNKhkXArtJqiLUBlTp7hkTKor54-WuvJrIDVQ?e=KbXyXH>

**2025-10-06 17:33:29** - Julia H.:
> Das hat geklappt. Hab ich in die gesamte Präsi aufgenommen

**2025-10-06 17:40:28** - Julia H.:
> Kannst du bitte das bild von robert ader noch rausnehmen?

**2025-10-06 17:40:39** - Julia H.:
> 

**2025-10-06 17:43:21** - Julia:
> habs angepasst

**2025-10-06 17:43:24** - Julia:
> siehst dus?

**2025-10-06 17:43:34** - Julia:
> <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/EZ7TLT66epNKhkXArtJqiLUBlTp7hkTKor54-WuvJrIDVQ?e=pwBSGe>

**2025-10-06 17:50:18** - Julia H.:
> yesss danke

**2025-10-07 10:01:22** - Julia:
> Hö? Das meeting ist aus meinem Kalender

**2025-10-07 10:01:40** - Julia:
> achso sehe es jetzt

**2025-10-07 10:01:42** - Julia H.:
> wtf

**2025-10-07 10:01:42** - Julia H.:
> ich seh auch nur so...

**2025-10-07 10:02:03** - Julia:
> sie hat gerade eine mail geschickt, ob wir es um 17 Uhr machen können

**2025-10-07 10:02:12** - Julia H.:
> Ahh die ist noch nicht angekommen

**2025-10-07 10:02:32** - Julia H.:
> passt das bei dir? dann antowrte ich ihr

**2025-10-07 10:02:57** - Julia:
> Ja, dann mache ich mittags länger Pause, bin schon so lange am PC

**2025-10-07 10:25:49** - Julia H.:
> FYI, hab das gerade noch bei Porsche Family UGC ergänzt hab ich heute morgen entdeckt. Ganz cute

**2025-10-07 10:31:02** - Julia:
> ohja!

**2025-10-07 11:16:05** - Julia:
> 

**2025-10-07 11:16:09** - Julia:
> glaube das müssen wir fast ohne sie machen

**2025-10-07 11:32:52** - Julia:
> Also Nicolas:

**2025-10-07 11:34:15** - Julia:
> 

**2025-10-07 11:34:42** - Julia:
> 

**2025-10-07 11:49:23** - Julia H.:
> Dann müssen wir uns an Flo wenden denke ich

**2025-10-07 11:49:26** - Julia H.:
> Also Steinbuss

**2025-10-07 11:50:24** - Julia H.:
> Hmm also jein, wir haben halt nicht wirklich ne Alternative. Wir haben niemanden der Zeit hat. Ich muss nochmal Flo fragen

**2025-10-07 11:50:42** - Julia:
> Okay, ich schreib ihm

**2025-10-07 11:50:59** - Julia:
> Okay, sag Bescheid wenn ich ihm fix zusagen kann/ soll

**2025-10-07 14:00:09** - Julia:
> Hast du diese Mail von Flo gelesen (Hanna Abwesenheit) :smile:

**2025-10-07 14:00:19** - Julia:
> Da ist ja jemand super motiviert haha

**2025-10-07 14:29:57** - Julia H.:
> ufff woooow

**2025-10-07 14:53:29** - Julia:
> also ich erstelle das foto briefing oder?

**2025-10-07 14:53:33** - Julia:
> oder hat Flo was anderes gesagt?

**2025-10-07 15:07:06** - Julia H.:
> Gerne erstellen, machen wir jetzt einfach mit Nicolas... Flo äußert sich nicht so richtig.

**2025-10-07 15:08:46** - Julia:
> okay

**2025-10-07 15:09:01** - Julia H.:
> Der kriegt das schon hin

**2025-10-07 15:09:09** - Julia:
> ich glaube auch!

**2025-10-07 15:09:17** - Julia H.:
> Müssen ihn einfach gut briefen und ihm genau sagen, was wir nicht wollen

**2025-10-07 15:10:34** - Julia H.:
> Ich kann irgendwie leider die TINS Präsi nciht als PDF runterladen

**2025-10-07 15:10:40** - Julia H.:
> als PPT mein cih

**2025-10-07 15:10:47** - Julia H.:
> wo liegt die denn?

**2025-10-07 15:11:49** - Julia:
> oh nein

**2025-10-07 15:11:56** - Julia:
> im "drive"? :smile:

**2025-10-07 15:12:06** - Julia:
> moment

**2025-10-07 15:12:25** - Julia:
> 

**2025-10-07 15:12:43** - Julia:
> ich ziehs bei uns in Porsche_DE rein, oder?

**2025-10-07 15:13:14** - Julia:
> Das war eben das was wir so krass fanden, weil eigentlich ist das nur "lokal" bei mir gespeichert aber mit dem Link teilen verschiebt es sich in die Cloud. Frage ist nur WO genau

**2025-10-07 15:13:24** - Julia H.:
> schick sie mir gern sonst einfach hier, liegt zumindest nicht auf dem normalen Drive oder auf One Drive

**2025-10-07 15:13:39** - Julia:
> okay

**2025-10-07 15:14:46** - Julia:
> geht nicht, über 1 GB ich legs bei uns ab

**2025-10-07 15:14:53** - Julia H.:
> LOL okay

**2025-10-07 15:14:54** - Julia H.:
> danke

**2025-10-07 15:15:00** - Julia H.:
> canvaaaaaaa

**2025-10-07 15:15:38** - Julia H.:
> 

**2025-10-07 15:15:58** - Julia:
> :fast_parrot:

**2025-10-07 15:16:14** - Julia:
> lädt hier noch: <https://drive.google.com/drive/folders/1kKuzWBX1yGRm7oQWHkEPXRkvLk9ohjyG>

dauert noch paar minuten :smile:

**2025-10-07 15:20:44** - Julia:
> 3 min nooooch

**2025-10-07 15:21:02** - Julia:
> wahrscheinlich wegen den videos

**2025-10-07 15:25:30** - Julia:
> okay ist oben

**2025-10-07 15:26:33** - Julia H.:
> Thank you

**2025-10-07 16:55:23** - Julia:
> soo

**2025-10-07 16:55:29** - Julia:
> magst du dir mal das Briefing anschauen:

**2025-10-07 16:57:20** - Julia:
> <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/EX-T1XPpRrhKpPQAQa7gEg0BKf88QnAE8gI_lzJwoWZucg?e=kd2dwd>

**2025-10-07 17:03:06** - Julia:
> du bist auch noch nicht im meeting oder?

**2025-10-07 17:04:16** - Julia H.:
> Yessss. charly meinte sie kommt ein bisschen zu spät

**2025-10-07 17:04:21** - Julia:
> ah okay

**2025-10-07 17:12:50** - Julia:
> Hast du Porsche Points von Mert bekommen zum Gipfeltreffen?

**2025-10-07 17:13:08** - Julia H.:
> eventuell, hab ncoh nicht geschaut, war im CM tunnel

**2025-10-07 17:13:33** - Julia:
> ah sehe gerade, hat er noch nicht gestartet laut asana

**2025-10-07 17:42:41** - Julia:
> Also wenn ich dir das abnehmen kann, kann ich Nicolas das briefing auch schicken. Wenn dir noch was super wichtiges einfällt, ergänze ich natürlich noch

**2025-10-07 17:43:16** - Julia H.:
> Ja gerne!!! Ich schau mal kurz drüber

**2025-10-07 17:45:41** - Julia H.:
> Sieht doch super aus!! Ich hab gerade auch dem Store Manager Typ geschrieben,ob er vor ort ist.

**2025-10-07 17:45:54** - Julia:
> ahh cool!

**2025-10-07 17:46:10** - Julia:
> Soll ich das noch abwarten oder rausschicken?

**2025-10-07 17:46:25** - Julia H.:
> ne hau gern raus, sonst kann man ja morgen noch ergänzen

**2025-10-07 17:53:30** - Julia:
> Wenn du mich beim meeting morgen um 9 brauchst, sag gerne bescheid. Ich komme ungern gern dazu :smile:

**2025-10-07 17:53:55** - Julia H.:
> haha ich denke es wäre an sich nicht schlecht tbh.

**2025-10-07 17:54:49** - Julia:
> :zipper_mouth_face:

**2025-10-07 17:54:57** - Julia:
> 9Uhr oder?

**2025-10-07 17:55:03** - Julia H.:
> yes.

**2025-10-07 17:55:09** - Julia H.:
> dann jetzt feierabend :heart:

**2025-10-07 17:55:27** - Julia:
> ich werde da sein :saluting_face:

**2025-10-07 17:56:14** - Julia:
> yeees! Dir auch! Und ein RIESIGES Danke für die immer gute Energie und das auf-uns-Aufpassen! :heart_hands:

**2025-10-07 17:56:49** - Julia H.:
> aww juli, sonst heul ich wieder!! obacht

**2025-10-07 17:56:50** - Julia H.:
> :heart:

**2025-10-08 09:00:47** - Julia:
> GuMo! Teams spinnt gerade wieder..

**2025-10-08 09:00:50** - Julia:
> dauert noch kurz

**2025-10-08 09:47:19** - Julia H.:
> yaaay

**2025-10-08 10:43:04** - Julia H.:
> 

**2025-10-08 11:08:00** - Julia:
> Red dot ist doch schon in der Präsi :slightly_smiling_face:

**2025-10-08 11:09:19** - Julia H.:
> Ahh nice, hatte cih noch nicht gesehn

**2025-10-08 11:21:27** - Julia:
> Ich auch nicht, hatte ich grad im pdf entdeckt :slightly_smiling_face:

**2025-10-08 11:21:34** - Julia H.:
> Nice!!

**2025-10-08 11:21:59** - Julia H.:
> Sollen wir die TINS PAG Postings in die große Präsi packen?

**2025-10-08 11:22:32** - Julia:
> Ja gerne --&gt; aber wegen den Videos wirds dann so groß :smiling_face_with_tear:

**2025-10-08 11:22:51** - Julia H.:
> Ahh damn.... Dann vielleicht erstmal aussortieren und updaten

**2025-10-08 11:23:13** - Julia:
> Also ich kann die Posts mit Dua usw. auch erstmal in der bestehenden TINS Präsi von "mir" bearbeiten und dir dann wieder die geupdateten Folien schicken?

**2025-10-08 11:23:19** - Julia H.:
> Aber den Herbst post kann ich schon mal rüber packen und ich ergänze wieder die PAG Posts für charly

**2025-10-08 11:23:31** - Julia:
> cool danke!

**2025-10-08 11:24:13** - Julia:
> wegen dem Dua Herbst Post --&gt; da gibts das Material ja leider nicht in der Datenbank. Ich kann das gerne anfragen, nur wo?

**2025-10-08 11:24:55** - Julia H.:
> Ich schau einfach. Finde ich schon

**2025-10-08 11:28:05** - Julia H.:
> <https://www.instagram.com/p/DMmvTh6s0T3/?img_index=5&amp;igsh=MWRwd2Jsa3U2ejlsZQ==>
Videos gabs darin ja auch. Yay or nay?

**2025-10-08 11:28:09** - Julia:
> <https://www.instagram.com/p/DMmvTh6s0T3/?img_index=1>

**2025-10-08 11:28:18** - Julia H.:
> hahaha

**2025-10-08 11:30:03** - Julia:
> ja hätte eigentlich schon mit videos geplant, wenn wir an den content kommen. das von mir waren eben nur screenshots weils nur aus IG gezogen ist

**2025-10-08 11:30:23** - Julia H.:
> Okay, dann zieh ich die Videos aus Sprinklr und pack sie rein

**2025-10-08 11:30:32** - Julia:
> mega :heart_eyes:

**2025-10-08 11:31:11** - Julia:
> hatten eben nur etwas die reihenfolge geändert und ein paar fotos rausgenommen

**2025-10-08 11:31:48** - Julia H.:
> Easy. Wo soll ich die ablegen?

**2025-10-08 11:35:09** - Julia:
> für wann wäre das eingeplant? dann erstell ich schnell den ordner

**2025-10-08 11:36:08** - Julia:
> <https://drive.google.com/drive/folders/1bawyVNCvbVCQttJnBaSOS_IlHeE4EQk9?usp=drive_link>

**2025-10-08 11:41:07** - Julia H.:
> 27.10. hatten wir mal

**2025-10-08 13:44:13** - Julia:
> PAG Teaser von Dua Lipa Post:
<https://www.instagram.com/p/C9sGMMWtpcZ/?img_index=1>

Originalpost bei PAG von Dua:
<https://www.instagram.com/p/C9xPmThsmxl/>


BTS bei PAG von Dua:
<https://www.instagram.com/p/C-F3grutWI4/?img_index=1>

mehr gibts garnicht --&gt; also wäre unseres garnicht so gesehen. ich passe es trotzdem an so gut es geht

**2025-10-08 14:33:24** - Julia H.:
> Thank you. Hab ich ergänzt.

**2025-10-08 14:38:29** - Julia:
> Update Dua Lipa Slides Halloween:
<https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/EZhFNWYjtcNHs2uK9STo3ykBzWp2qycKxZGBNlpn8z13xw?e=hmgM7S>

**2025-10-08 14:38:38** - Julia H.:
> Leonie Beck ist freigegeben!! Whoop! Sollten nur beim Carousel das erste Bild anpassen:

**2025-10-08 14:39:05** - Julia:
> Uhh nice, okay. Schau ich mir jetzt direkt an – dauert bisschen, muss noch die ganzen finalen Fotos einsetzen :slightly_smiling_face:

**2025-10-08 14:41:25** - Julia H.:
> liebs :heart:

**2025-10-08 14:46:30** - Julia H.:
> Sag mal die Dateien sind doch nicht so riesig, bei mir bleibt alles hängen irgendwie mit den TINS assets

**2025-10-08 14:47:39** - Julia:
> ich glaub das sind diese Malmedie Videos

**2025-10-08 14:48:11** - Julia H.:
> hmm,....Wenn ich die Dua Assets in die Andere Präsentation kopiere wird die auch lahmgelegt

**2025-10-08 14:48:20** - Julia H.:
> Aber vielleicht generell gerade ein Sharepoint Problem

**2025-10-08 14:48:32** - Julia:
> :face_exhaling:

**2025-10-08 14:48:38** - Julia:
> ich hab keine ahnung.. so doof

**2025-10-08 14:55:04** - Julia:
> ich dreh durch. hast du hierauf zugriff?
<https://porsche.sharepoint.com/sites/PDMK/_layouts/15/AccessDenied.aspx?Source=https%3A%2F%2Fporsche%2Esharepoint%2Ecom%2F%3Ap%3A%2Fr%2Fsites%2FPDMK%2FShared%20Documents%2FGeneral%2FUMZUG%2FDigitales%20Marketing%2FSocial%2FInsta%2F08%5FRedaktionsplanung%2FContents%2F2025%2F09%5FSeptember%2FChristo%5FLeonie%20Beck%2F250930%5FCHRISTO%20X%20LEONIE%20BECK%5FSM%20ASSETS%5FJH%2Epptx%3Fd%3Dw7bdded1f44e94b6cb2287b372dcee960%26csf%3D1%26web%3D1%26e%3DfEA8cj&amp;correlation=0561cda1%2Df0c2%2De000%2D0c5a%2D2e788cb55751&amp;Type=item&amp;name=0cd39bae%2D6d68%2D48b4%2Dac8e%2Dbb7c2e24de30&amp;listItemId=234961&amp;listItemUniqueId=7bdded1f%2D44e9%2D4b6c%2Db228%2D7b372dcee960|https://porsche.sharepoint.com/sites/PDMK/_layouts/15/AccessDenied.aspx?Source=https%3A%[…]ItemUniqueId=7bdded1f%2D44e9%2D4b6c%2Db228%2D7b372dcee960>

**2025-10-08 14:55:31** - Julia:
> 

**2025-10-08 15:15:16** - Julia H.:
> Da hab ich auch keinen Zugriff drauf, ich check mal ob ich die richtige finde

**2025-10-08 15:15:26** - Julia:
> :face_exhaling: ich versteh das einfach nicht

**2025-10-08 15:16:03** - Julia H.:
> Das hier?

**2025-10-08 15:16:05** - Julia H.:
> 

**2025-10-08 15:16:22** - Julia:
> super danke!

**2025-10-08 15:16:53** - Julia H.:
> Logo

**2025-10-08 15:16:58** - Julia:
> Noch eine Sache – siehst du auch gleich, die eingesetzen Bilder sind ja die finalen von Lattke und haben die Bearbeitung von deren Lithografen drauf – ich finds pesönlich ganz furchtbar aber...

**2025-10-08 15:27:52** - Julia H.:
> Okay... Können wir ja anmerken

**2025-10-08 15:35:58** - Julia:
> There you go: <https://app.asana.com/1/1199360402832734/project/1210522556460237/task/1211585708869497?focus=true>


Basti hab ich wegen dem Reel geschrieben

**2025-10-08 16:16:54** - Julia H.:
> Daaanke. Nur das erste Bild im Carousel ist ja nicht das gewünschte oder?

**2025-10-08 16:35:36** - Julia:
> Meinten sie da nicht nur das TN? Weil sie hatten halt geschrieben "TN im Carousel"
Dachte sie reden da vom reel

**2025-10-08 16:37:26** - Julia H.:
> Ich dachte sie meinen einfach das Startbild vom Carousel weil auf dem TN vom Reel ist sie ja eh drauf. So maybe?

**2025-10-08 16:37:50** - Julia H.:
> Ist ja eigentlich das einzige wo sie mit Auto richtig drauf ist oder? Kann sich dann eh charly aussuchen so...

**2025-10-08 16:38:45** - Julia:
> Also ich hatte das Reel TN jetzt angepasst. Da hatten wir eigentlich das hier:

**2025-10-08 16:39:41** - Julia:
> du meinst, wo sie hinterm steuer sitzt?

**2025-10-08 16:40:00** - Julia:
> ja ist okay

**2025-10-08 16:40:40** - Julia:
> 

**2025-10-08 16:41:55** - Julia:
> FYI: Basti ist heute auf Dreh. evtl morgen wieder da?

**2025-10-08 16:42:34** - Julia H.:
> dadurch dass das alles so freigegeben ist jetzt würd ich nicht neues hinzufügen

**2025-10-08 16:42:51** - Julia H.:
> Ich glaub er ist morgen zurück er muss auch für mich was für YT fertig machen

**2025-10-08 16:43:26** - Julia:
> oke

**2025-10-08 16:43:32** - Julia:
> okay

**2025-10-08 16:43:53** - Julia:
> dann leg ich dir das "alte" Reel TN nochmal ab, oder?

**2025-10-08 16:44:07** - Julia H.:
> Gerne!

**2025-10-08 16:46:58** - Julia:
> <https://drive.google.com/drive/folders/1smTGTryRlgR28HeZKZbRUWAPBn3EvR-R>

sorry für die Verwirrung

**2025-10-08 16:47:34** - Julia H.:
> Noooo, alles gut. Heute war viel

**2025-10-09 08:44:27** - Julia:
> GuMo! ich hab noch 2 Trends gefunden. Euer Termin ist mittags ge? Bereite ich dir bis dahin auf, dann kannst du es einfügen :slightly_smiling_face:

**2025-10-09 09:13:42** - Julia H.:
> Gooood morning, yay very nice, danke juli!!!

**2025-10-09 09:14:05** - Julia H.:
> schau mal das hier hat uns ein fotograf geschickt, hab ich mal in die UGC präsi rein als vorschlag für ostern
Fand ich cute

**2025-10-09 09:21:02** - Julia:
> Jaaa stimmt! Das hatten wir mal gesehen. Voll :smiling_face_with_3_hearts:

**2025-10-09 09:58:24** - Julia H.:
> Hast du seit vorgestern auch nix mehr von flo gehört?

**2025-10-09 09:58:40** - Julia H.:
> ich hab gestern in der früh nur mal kurz die nachricht bekommen, dass er nicht ins meeting kommt

**2025-10-09 10:00:00** - Julia:
> ne..

**2025-10-09 10:00:21** - Julia H.:
> mega strange

**2025-10-09 10:00:28** - Julia:
> ja halt uncool

**2025-10-09 10:00:35** - Julia H.:
> vollkommen.

**2025-10-09 11:11:23** - Julia H.:
> 

**2025-10-09 11:23:10** - Julia H.:
> ja, die speaker kommen um 17 uhr und haben dann wie immer gleich ihren technik check und vorbesprechung. das ist erst 18 uhr durch

**2025-10-09 11:23:13** - Julia H.:
> okay top

**2025-10-09 11:23:29** - Julia:
> okay, passt ja

**2025-10-09 11:23:38** - Julia:
> dann ich ihm gleich alles

**2025-10-09 11:23:48** - Julia H.:
> perfekt danke y3

**2025-10-09 11:40:18** - Julia H.:
> Das kam gerade auch noch.

**2025-10-09 11:41:19** - Julia:
> ja. im briefing bei fokus

**2025-10-09 11:45:19** - Julia H.:
> Vielleicht sollten wir ihr das Briefing schicken

**2025-10-09 11:47:36** - Julia:
> 

**2025-10-09 11:49:02** - Julia H.:
> Danke :heart:

**2025-10-09 11:51:46** - Julia:
> caption für playmobil hab ich angepasst

**2025-10-09 11:51:55** - Julia H.:
> danke :heart:

**2025-10-09 13:01:08** - Julia H.:
> Jetzt an der Besprechung teilnehmen&lt;<https://teams.microsoft.com/l/meetup-join/19%3ameeting_ZjQ1YzI4MTEtODUxZS00OTg3LWI0MmEtOThmYmRlYjIwYzBl%40thread.v2/0?context=%7b%22Tid%22%3a%2256564e0f-83d3-4b52-92e8-a6bb9ea36564%22%2c%22Oid%22%3a%22a848e120-f8f0-4674-ba5b-a0035d623246%22%7d>&gt;
Besprechungs-ID: 372 183 803 267 6
Kennung: iB2MD3GE
______________________

**2025-10-09 13:08:40** - Julia:
> soll ich noch rein?

**2025-10-09 13:08:48** - Julia:
> was ist das für ein termin? :slightly_smiling_face:

**2025-10-09 13:11:20** - Julia H.:
> Huhuuuu sorry, ich war nciht sicher ob du mitkommst

**2025-10-09 13:11:21** - Julia H.:
> aber ist super auch wegen trends

**2025-10-09 13:11:51** - Julia:
> okay. hab eigentlich solche termine nicht im kalender, aber passt ja

**2025-10-09 13:26:38** - Julia H.:
> I know... Ich kann dich da immer nicht einladen leider

**2025-10-09 13:35:31** - Julia:
> unten ist halloween, das nicht zeigen

**2025-10-09 13:35:32** - Julia:
> <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/ERREl-jY--RClqmGmwnOPWoBGZc7HXKQ63EHw9JKuy1MSg?e=f50V64&amp;nav=eyJzSWQiOjMwMSwiY0lkIjoyNTg2MTU0NDN9|https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/ERRE[…]MSg?e=f50V64&amp;nav=eyJzSWQiOjMwMSwiY0lkIjoyNTg2MTU0NDN9>

**2025-10-09 14:03:55** - Julia H.:
> Jetzt an der Besprechung teilnehmen&lt;<https://teams.microsoft.com/l/meetup-join/19%3ameeting_ODk2MjY2YmEtYjA5Yi00YzQzLTg3ZjctMzM5NjA2N2IzMzZl%40thread.v2/0?context=%7b%22Tid%22%3a%2256564e0f-83d3-4b52-92e8-a6bb9ea36564%22%2c%22Oid%22%3a%22bdb3867c-5a4f-41b7-a39c-65066679ce4f%22%7d>&gt;
Besprechungs-ID: 395 711 277 291 0
Kennung: bo34767e

**2025-10-09 14:03:58** - Julia H.:
> hier noch fürs daily

**2025-10-09 15:26:37** - Julia:
> ich bin sooo auf die fotos/ videos gespannt

**2025-10-09 15:26:41** - Julia:
> :face_with_peeking_eye:

**2025-10-09 15:26:43** - Julia:
> vom event

**2025-10-09 15:26:51** - Julia H.:
> ich auch. angst

**2025-10-09 15:26:59** - Julia:
> :face_with_spiral_eyes:

**2025-10-09 16:07:46** - Julia H.:
> Schau mal Juli, ich hab hier mit dem BS Reporting angefangen. Super schwierig nach wie vor. Alles ist gelb, wo ich keine Ahnung hatte. Die Zahlen sind auch nicht so gut im September, daher finde ich es super schwer hier Learnings zu ziehen. Die Basis steht aber schon mal, vielleicht hast du ja morgen zeit hier mal mit Flo drüber zu schauen?

**2025-10-09 16:21:15** - Julia:
> schau ich mir an!

**2025-10-09 16:29:52** - Julia H.:
> :heart:

**2025-10-09 16:30:13** - Julia H.:
> Hatte Flo auch die beiden Reportings für DE und YouTube Geschickt und bekomm nicht so richtig ne Antwort... Mei sonst halt next week

**2025-10-10 09:26:26** - Julia H.:
> 

**2025-10-10 09:26:55** - Julia H.:
> Good morning liebe Juli, hab gerade in den Account geschaut wegen CM. Wollten ja die besten Antworten teilen

**2025-10-10 09:28:38** - Julia:
> Hello! :slightly_smiling_face:

**2025-10-10 09:28:45** - Julia:
> Cool danke

**2025-10-10 09:28:52** - Julia:
> Muss ich das nochmal freigeben lassen oder einfach machen?

**2025-10-10 09:29:12** - Julia H.:
> Freigeben lassen leider.... Not sure wer das übernimmt, vielleicht mal Jana fragen

**2025-10-10 09:30:02** - Julia:
> Okay mach ich

**2025-10-10 09:30:59** - Julia:
> Also Event Content.. Bilder okay. Videos weiß ich noch nicht. Aber Reel Katastrophe --&gt; vllt wollte Hanna das so und die Statements/ Zitate der Speaker haben scheinbar alle nicht geklappt

**2025-10-10 09:32:08** - Julia H.:
> shit... aber Katastrophe wegen Quali?

**2025-10-10 09:32:22** - Julia H.:
> oder edit? Sonst könnte er ja die daten hochladen und wir schneiden selbts?

**2025-10-10 09:33:05** - Julia:
> Ne einfach die Idee nicht verstanden. Also es ist einfach nur ein Bildausschnitt der genau gleich bleibt und dann groß wird :smile:

**2025-10-10 09:34:25** - Julia H.:
> shit... aber weiteres footage hat er nicht, so dass wir das basteln können

**2025-10-10 09:34:34** - Julia:
> ich schau gerade noch durch

**2025-10-13 09:32:29** - Julia:
> Guten Morgen! :heart_hands:

**2025-10-13 09:35:50** - Julia:
> ich würde den 10 Uhr Termin mit Porsche skippen, wenn das für dich auch passt? Ich denke Charly muss sich eh erstmal noch alles angucken

**2025-10-13 10:02:31** - Julia H.:
> Huhuuu, also wir wollten ja eigentlich die TINS unterlage vorstellen

**2025-10-13 10:02:38** - Julia H.:
> daher wäre es gut wenn du dabei wärst

**2025-10-13 10:02:43** - Julia H.:
> weil hanna auch dabei it

**2025-10-13 10:49:56** - Julia:
> Ach Mist, das hatte ich nicht auf dem schirm

**2025-10-13 10:57:30** - Julia H.:
> ist okay, ich habs irgendwie hinbekommen

**2025-10-13 10:57:37** - Julia:
> sorryyy

**2025-10-13 10:57:45** - Julia:
> ich steh bissl neben mir :face_with_spiral_eyes:

**2025-10-13 16:38:49** - Julia:
> Also mit Nicolas und der Rechnung bin ich mal gespannt :smile: da hat ja wirklich garnichts geklappt

**2025-10-13 17:19:48** - Julia H.:
> Ja fuck ey 

**2025-10-13 17:19:50** - Julia H.:
> So nervig 

**2025-10-14 09:22:38** - Julia H.:
> Hab dich nochmal hinzugefügt beim huddle termin :heart:

**2025-10-14 09:50:08** - Julia:
> dankeeee

**2025-10-14 09:56:56** - Julia:
> ich komme nicht bei teams rein

**2025-10-14 09:56:58** - Julia:
> es ist so zum kotzen

**2025-10-14 09:59:24** - Julia:
> glaube jetzt geht es

**2025-10-14 10:01:30** - Julia H.:
> sooo nervig... sorry juli :disappointed:

**2025-10-14 10:02:04** - Julia:
> bin im warteraum :slightly_smiling_face:

**2025-10-14 10:02:10** - Julia H.:
> same

**2025-10-14 10:37:00** - Julia:
> das bild von dem hund ist halt nicht cool :smile:

**2025-10-14 11:03:34** - Julia:
> 

**2025-10-14 11:14:35** - Julia:
> SYLT CONTENT MIT HUUUUUND!!!

**2025-10-14 11:21:40** - Julia H.:
> LOL, mit dem random dude

**2025-10-14 11:21:54** - Julia H.:
> aber wie cute ist der hundi

**2025-10-14 14:49:06** - Julia:
> hab noch einen gefunden :smile:

**2025-10-14 14:51:15** - Julia H.:
> Cool. danke!!

**2025-10-14 14:52:30** - Julia H.:
> Ich hab gerade noch zu Racing gesehen, dass sie ja auch die Carousel Reihenfolge anders haben wollte plus story slides... Da bist du dran, oder? Dann sag ich ihr, dass wir das asap schicken?

**2025-10-14 14:58:48** - Julia:
> genau. Also Story Slides + Bildauswahl für das Image Carousel --&gt; yes (aber wie gesagt, wenn da eh noch Content kommt..?)
Carousel Reihenfolge hab ich jetzt nicht gesehen

**2025-10-14 14:59:42** - Julia:
> deswegen dachte ich, dass man sagt: hey visuelle sachen kommen sobald wir die ganzen Fotos haben, aber hier sind schon mal unsere Anmerkungen + Caption Überarbeitungen

**2025-10-14 14:59:52** - Julia:
> Soll ich das sonst einfach in eine Präsi packen?

**2025-10-14 15:02:16** - Julia H.:
> Okay, verstehe. Ich bin nicht ganz sicher ob sie meinte dass diese beiden Carousels die sie geschickt hatten final sind und noch weiterer content kommt, weil wir für 3 tage eingeplant haben. Aber ich schicke ihr schon mal die Anmerkungen und captions mit der info.

**2025-10-14 15:02:23** - Julia H.:
> präsi können wir schon mal anlegen

**2025-10-14 15:03:11** - Julia:
> Ah okay verstehe

**2025-10-14 15:03:16** - Julia:
> danke!

**2025-10-14 15:03:18** - Julia:
> mach ich dann

**2025-10-14 15:03:26** - Julia H.:
> easy!! danke :heart:

**2025-10-14 16:57:38** - Julia H.:
> Ist der BS Post ready/freigegeben? Soll ich das  in Sprinklr packen?

**2025-10-14 16:57:56** - Julia:
> sie antwortet nicht :weary:

**2025-10-14 16:58:06** - Julia:
> ich exportier aber tatsächlich gerade alles

**2025-10-14 17:04:10** - Julia:
> <https://drive.google.com/drive/folders/1h54uGA71DwQjwOnnNk0bvayxR03DqEn5?usp=drive_link>

**2025-10-14 17:08:48** - Julia H.:
> ich stell es einfach schon auf sprinklr

**2025-10-14 17:09:59** - Julia H.:
> schon das hier oder?

**2025-10-14 17:12:00** - Julia:
> gerne

**2025-10-14 17:12:09** - Julia:
> genau und teil 2 mit den varianten halt

**2025-10-14 17:17:51** - Julia H.:
> welche findest du am besten? dann nehm ich unseren Fav schon mal rein.

**2025-10-14 17:20:42** - Julia:
> das 3.

**2025-10-14 17:20:47** - Julia:
> du?

**2025-10-14 17:20:50** - Julia H.:
> Haha genau das hab ich auch rein

**2025-10-14 17:20:51** - Julia H.:
> top

**2025-10-14 17:20:55** - Julia:
> juhuu

**2025-10-14 17:21:25** - Julia H.:
> Stories muss man ja händisch machen

**2025-10-14 17:23:45** - Julia:
> genau. also ich bin heute nichtmehr so lange da, bin von 18Uhr bis 19.30 unterwegs :smiling_face_with_tear: hoffe sie antwortet bald

**2025-10-14 17:24:40** - Julia H.:
> Ja same..lets see

**2025-10-14 17:26:36** - Julia:
> sonst könnte man story direkt morgens machen

**2025-10-14 17:43:11** - Julia H.:
> hast du hannas nachricht gesehen?

**2025-10-14 17:43:21** - Julia:
> ja aber es gibt nix

**2025-10-14 17:44:26** - Julia H.:
> Was sollen wir ihr sagen?das erste ist ja auch nicht unscharf

**2025-10-14 17:44:27** - Julia:
> es macht mich echt sauer

**2025-10-14 17:44:34** - Julia:
> das liegt da seit tagen

**2025-10-14 17:44:36** - Julia:
> seit freitag ab

**2025-10-14 17:44:43** - Julia H.:
> sondern halt nur der VG im fokus

**2025-10-14 17:45:03** - Julia:
> ja

**2025-10-14 17:45:11** - Julia:
> ich hab noch eins gefunden, das ist von der belichtung besser

**2025-10-14 17:45:30** - Julia H.:
> für das erste? oder für grant?

**2025-10-14 17:45:36** - Julia:
> grant finde ich kein anderes keine ahnung

**2025-10-14 17:46:02** - Julia:
> obwohl auch nicht besser

**2025-10-14 17:46:38** - Julia H.:
> und wenn wir fakt 7 auf ein anderes bild setzen also ohne ihn halt drauf?

**2025-10-14 17:47:09** - Julia:
> 

**2025-10-14 17:47:25** - Julia:
> unten ist neu

**2025-10-14 17:47:33** - Julia H.:
> Ahh verstehe... sorry, war da nciht so involved leider

**2025-10-14 17:48:04** - Julia H.:
> magst du mir das untere kurz schicken pls? dann hau ich das in sprinklr

**2025-10-14 17:49:40** - Julia:
> 

**2025-10-14 17:50:01** - Julia:
> 

**2025-10-14 17:51:12** - Julia H.:
> Ja macht total sinn!

**2025-10-14 17:51:14** - Julia H.:
> yay freigabe

**2025-10-14 17:51:18** - Julia:
> ich schicke dir das jetzt einfach mal

**2025-10-14 17:51:20** - Julia:
> 

**2025-10-14 17:51:49** - Julia:
> juhuuuu

**2025-10-14 17:51:57** - Julia H.:
> stories sind freigegeben so?

**2025-10-14 17:52:25** - Julia:
> hatte alles angepasst

**2025-10-14 17:52:50** - Julia H.:
> yay :heart: danke juli

**2025-10-14 17:52:52** - Julia:
> 

**2025-10-14 17:53:20** - Julia H.:
> Dann nehm ich ein anders Startbild :slightly_smiling_face: danke

**2025-10-14 17:53:44** - Julia H.:
> Und der Sticker ist immer Wahr/Lüge?

**2025-10-14 17:54:32** - Julia:
> genau

**2025-10-14 17:54:39** - Julia:
> oder lieber

**2025-10-14 17:54:41** - Julia:
> Wahr / Falsch

**2025-10-14 17:54:47** - Julia:
> Lüge ist bisschen hart :smile:

**2025-10-14 17:54:52** - Julia H.:
> yes!! stimmt. besser

**2025-10-14 17:55:09** - Julia:
> ahhh sowas macht mich wahnsinnig

**2025-10-14 17:55:24** - Julia H.:
> ich poste jetzt schon mal schnell die stories, eventuell kannst du mitdrüber schauen bevor du off bist

**2025-10-14 17:55:27** - Julia H.:
> ja super nervig

**2025-10-14 17:55:30** - Julia:
> ja klar mach ich

**2025-10-14 17:56:32** - Julia:
> bin dran und gucke

**2025-10-14 17:57:20** - Julia:
> moment

**2025-10-14 17:57:32** - Julia:
> also ich hatte die sticker eigentlich immer bei der frage direkt platziert

**2025-10-14 17:57:49** - Julia H.:
> da wär es dann halt über dem auto

**2025-10-14 17:57:54** - Julia:
> weißt du wie ich meine?

**2025-10-14 17:58:25** - Julia:
> ja fand ich jetzt in dem fall nicht schlimm aber mach gerne wie du meinst

**2025-10-14 17:58:36** - Julia H.:
> Der Sticker ist nur nach unten drin viel größer weil es den nebeneinnder nicht mehr gibt

**2025-10-14 17:58:41** - Julia H.:
> aber ich mach wie in der präsi

**2025-10-14 17:58:59** - Julia:
> jaa ich weiß schon, hab ich auch gesehen leider

**2025-10-14 17:59:00** - Julia:
> okay

**2025-10-14 18:01:10** - Julia:
> läuft

**2025-10-14 18:01:59** - Julia H.:
> :heart:

**2025-10-14 18:02:07** - Julia H.:
> nur das mit dem Titelbild jetzt nicht :disappointed:

**2025-10-14 18:03:03** - Julia:
> Ich bin schon mit dem Handy drin. Dann das buch als Titelbild?

**2025-10-14 18:03:08** - Julia:
> Das Bild ist scharf

**2025-10-14 18:03:22** - Julia:
> Eigentlich das von Außen, weiß nicht was sie hier hat

**2025-10-14 18:03:27** - Julia:
> Sonst kann ich es morgen früh machen

**2025-10-14 18:03:47** - Julia:
> Oder später. Ich kann nicht jeden Termin wegen der ihren Feedbackprozessen verschieben

**2025-10-14 18:03:55** - Julia:
> Finde Buch als Bild auch gut

**2025-10-14 18:04:21** - Julia H.:
> Ja auf keinen fall.

**2025-10-14 18:04:29** - Julia H.:
> also deinen Termin nicht verschieben

**2025-10-14 18:05:10** - Julia:
> Also Vorschlag 1: Buch als Titelbild nehmen
oder Vorschlag 2: morgen früh posten und wir schauen nochmal. Dann läuft das Quiz jetzt erstmal so – auch gut!

**2025-10-14 18:05:19** - Julia H.:
> morgen :heart:

**2025-10-14 18:05:22** - Julia H.:
> happy evening und danke

**2025-10-14 18:26:49** - Julia:
> oke. Danke und ahhh

**2025-10-14 18:26:52** - Julia:
> :heart_hands:

**2025-10-15 09:43:18** - Julia:
> hello! legs jetzt auch nochmal in die Präsi rein. Es gibt sonst kein anderes Bild – das ist die Lichtstimmung, die streut natürlich Licht und macht diesen leichten "grisligen Effekt". Habs hier raus bekommen

**2025-10-15 09:43:39** - Julia:
> Aber unscharf sind die Bilder nicht, ich würde wohl kein unscharfes Bild hochladen als studierte Grafikdesignerin

**2025-10-15 09:47:37** - Julia:
> liegt ab slide 21 + 22

**2025-10-15 10:04:25** - Julia H.:
> Ja I know... Da fehlt es einfach an Verständnis... Ist bald vorbei :heart:

**2025-10-15 10:04:33** - Julia H.:
> Danke Juli :heart:

**2025-10-15 10:46:02** - Julia:
> sehr gerne – danke fürs klären :heart:

**2025-10-15 10:56:40** - Julia H.:
> Freigegeben. :slightly_smiling_face:

**2025-10-15 11:12:04** - Julia:
> juhuuu. hast dus schon in sprinklr rein? sonst kann ich

**2025-10-15 11:26:19** - Julia H.:
> yes ist schon drin

**2025-10-15 11:55:43** - Julia:
> dankeee

**2025-10-15 11:55:57** - Julia:
> war sonst alles oke in den Meetings?

**2025-10-15 12:05:53** - Julia H.:
> Joa war okay soweit. werde von tag zu tag trauriger irgendwie

**2025-10-15 12:08:24** - Julia:
> ja versteh ich..

**2025-10-15 12:08:48** - Julia:
> ich hab übrigens schon die präsi für Racing erstellt – ich muss jetzt noch die Stories machen

**2025-10-15 12:08:55** - Julia:
> also bis 13 Uhr schaff ich das eh

**2025-10-15 12:09:24** - Julia H.:
> cooool :heart:

**2025-10-15 12:09:29** - Julia H.:
> danke Juli

**2025-10-15 12:11:02** - Julia:
> so geil auch, die bilder sind alle so schlecht :smile:

**2025-10-15 12:12:38** - Julia H.:
> lel

**2025-10-15 12:51:40** - Julia:
> so there you go:

**2025-10-15 12:54:14** - Julia:
> <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/EVaeQqoPythFgsfrqdTs6w0BKdQL9bmpEdFaxE30pVeZHA?e=tgnwjl>

**2025-10-15 12:54:44** - Julia:
> • captions angepasst
• Carousel Bildauswahl /ergänzt sich dann mit Story Slides
• 2x Varianten der Stories


**2025-10-15 15:35:02** - Julia:
> Hab grad mit Flo gesprochen, er ist einfach ne Maus. Glaub dem war einfach nicht bewusst, dass wir auf Updates warten. Würde ja gerne sagen TYPISCH MANN...

**2025-10-15 15:35:22** - Julia H.:
> Really? LOL

**2025-10-15 15:35:34** - Julia H.:
> also er hat mir auch ein meeting eingestellt für 16 uhr

**2025-10-15 15:35:45** - Julia:
> ahh perfekt

**2025-10-15 15:35:54** - Julia H.:
> also gabs news die gut sind?

**2025-10-15 15:36:04** - Julia:
> schick dir eine Sprachi

**2025-10-15 15:36:30** - Julia H.:
> okee

**2025-10-15 16:21:24** - Julia H.:
> Carrera Cup here you go

**2025-10-15 16:28:00** - Julia:
> dankeee

**2025-10-15 16:29:15** - Julia:
> lieb ich ja, wenn das Feedback ist: einfach nur Sätze umdrehen

**2025-10-15 16:32:36** - Julia H.:
> Sie ist die Queen im Feedback geben

**2025-10-15 16:38:07** - Julia:
> übrigens hat das mit dem Huddle Termin nicht geklappt – bin nicht drin :sleepy:

**2025-10-15 16:40:28** - Julia H.:
> Hääää

**2025-10-15 16:40:41** - Julia H.:
> Ich versuchs nochmal

**2025-10-15 16:40:43** - Julia:
> jaa vllt muss ich nochmal komplett raus gelöscht werden?

**2025-10-15 16:40:44** - Julia:
> dankee

**2025-10-15 16:41:33** - Julia H.:
> Hatte dich gelöscht und neu eingeladen aber du wirst trotzdem als X angezeigt.

**2025-10-15 16:41:51** - Julia H.:
> Du müsstest im Google Kalender den Termin aber noch sehen können

**2025-10-15 17:16:51** - Julia:
> das ist doch so komisch

**2025-10-15 17:17:24** - Julia:
> ne ich hab ihn nichtmehr drin :disappointed:

**2025-10-15 17:18:02** - Julia:
> egal, ich leg mir den selbst rein als reminder

**2025-10-15 17:18:06** - Julia:
> aber danke fürs probieren :slightly_smiling_face:

**2025-10-15 17:24:12** - Julia H.:
> Mega komisch

**2025-10-16 09:14:32** - Julia H.:
> Good morning, Leica lad ich dir gerade runter, wo soll ich das ablegen?

**2025-10-16 09:46:19** - Julia:
> hello!

**2025-10-16 09:46:20** - Julia:
> <https://drive.google.com/drive/folders/1H67fGzGr11_PAO3OczjRrRNUnjBXOAuR>

**2025-10-16 09:46:23** - Julia:
> gerne hier, dankeee

**2025-10-16 09:47:18** - Julia H.:
> Läd hoch!

**2025-10-16 09:49:37** - Julia H.:
> Mir hat auch der Nicolas per Whatsapp geschrieben... was sollen wir dem sagen

**2025-10-16 09:49:51** - Julia H.:
> 

**2025-10-16 09:55:58** - Julia:
> Echt? Hä wie komisch 

**2025-10-16 09:56:14** - Julia:
> Also ich hab keine Mail bekommen. Aber wollte ihn eh heute Feedback geben :melting_face:

**2025-10-16 09:58:03** - Julia H.:
> Ich hatte die Mail gesehen, aber i swear sie ist weg?? häää

**2025-10-16 09:58:56** - Julia H.:
> Jetzt hab ich sie... Gmail Posteingang auch weird. hab sie dir weitergeleitet

**2025-10-16 10:01:52** - Julia:
> okay dankeee.

**2025-10-16 10:03:31** - Julia:
> finds einfach strange, dass er dir dann in whatsapp schreibt. ich hatte ja mit ihm kontakt

**2025-10-16 10:49:19** - Julia:
> ah ja

**2025-10-16 10:49:39** - Julia:
> dann antworte ich Nicolas jetzt? Würde schon ehrlich sein aber natürlich trotzdem nett

**2025-10-16 11:05:11** - Julia H.:
> Ja gerne!! Chatgpt? :stuck_out_tongue:

**2025-10-16 11:14:04** - Julia H.:
> Dua und Mark Captions sind angepasst

**2025-10-16 11:30:50** - Julia:
> dankeee

**2025-10-16 11:33:31** - Julia H.:
> happy to help

**2025-10-16 12:04:12** - Julia H.:
> Super nachricht an Nicolas!! Danke Juli

**2025-10-16 15:06:50** - Julia H.:
> Soll ich noch helfen mit Translations

**2025-10-16 15:09:33** - Julia:
> gerneee

**2025-10-16 15:09:44** - Julia:
> bin beim letzten :slightly_smiling_face: du kannst aber gerne durchschauen was du meinst

**2025-10-16 15:09:54** - Julia:
> bezüglich Youtube hab ich vergessen was sie gesagt haben, ups

**2025-10-16 15:10:54** - Julia H.:
> Den Teaser wolltest du nicht reinmachen?

**2025-10-16 15:11:14** - Julia:
> doch habs nur angepasst

**2025-10-16 15:11:30** - Julia:
> Das Video ist halt auf englisch

**2025-10-16 15:11:55** - Julia:
> hab das hier überlegt

**2025-10-16 15:12:41** - Julia H.:
> Hmm okay verstehe, weil es ist ja schon ganz cool oder? Sonst könnte man das ja mit UT lösen?

**2025-10-16 15:12:48** - Julia H.:
> YouTube machen wir auch

**2025-10-16 15:13:39** - Julia:
> ja ich finds auch cool. ich hatte nur im kopf (mit Dua zB) das Charly, dass halt garnicht mag mit englischen Videos auf dem Kanal

**2025-10-16 15:14:09** - Julia H.:
> mit UT gehts eigentlich, haben wir schon öfters gemacht

**2025-10-16 15:14:36** - Julia:
> okay dann nehm ich es wieder mit rein

**2025-10-16 15:17:09** - Julia:
> habs drin und wieder in den plan oben mit rein

**2025-10-16 15:24:15** - Julia H.:
> Das mit dem Kopieren funktioniert kaum, die präsi bricht die ganze zeit ab

**2025-10-16 15:24:19** - Julia H.:
> das nervt so ghart

**2025-10-16 15:24:25** - Julia:
> Ne hör auf

**2025-10-16 15:24:44** - Julia:
> das ist echt mit den Videos glaub ich

**2025-10-16 15:25:07** - Julia:
> Was kann ich tun?

**2025-10-16 15:25:54** - Julia H.:
> Ich lad deine Version runter und lad sie charly neu hoch. wird sie nicht mögen aber ist halt so

**2025-10-16 15:27:14** - Julia H.:
> Kann sie nicht runterladen

**2025-10-16 15:27:21** - Julia H.:
> kannst du mit die PPT hier schicken bitte?

**2025-10-16 15:27:26** - Julia:
> oh manno

**2025-10-16 15:27:27** - Julia:
> ja klar

**2025-10-16 15:31:00** - Julia:
> okay lädt hoch. wird dauern

**2025-10-16 15:31:52** - Julia H.:
> thank uuu

**2025-10-16 15:33:28** - Julia:
> 

**2025-10-16 15:38:11** - Julia H.:
> daaanke, ist raus!!

**2025-10-16 15:38:45** - Julia:
> juhuuuu

**2025-10-16 15:38:51** - Julia:
> bin grad an den racing sachen dran

**2025-10-16 15:41:27** - Julia H.:
> :heart:

**2025-10-16 16:20:30** - Julia:
> für Charly – ihre "Vorschläge" liegen noch mit drin

**2025-10-16 16:35:28** - Julia:
> habs ihr geschickt

**2025-10-16 17:33:59** - Julia H.:
> Thank you Juli!!!

**2025-10-20 09:34:25** - Julia:
> GuMoo

**2025-10-20 09:36:21** - Julia:
> Puh VBWs am Freitag waren nochmal ein Highlight – Hanna hatte mir privat dann noch paar mal geschrieben wegen den Story Slides "sie hätte die ja garnicht gesehen in Sprinklr" etc.
Müssen wir aber händisch posten wegen Stickern. Dann hatte sie mich so verwirrt und ich bin am Samstag aufgewacht und war so: ne irgendwas passt nicht. Die Story ist erst heute bei der PAG, also für uns ja dann auch. Dann hab ich ihr das kurz geschrieben am Samstag, hat sie nicht verstanden :joy: Irgendwann dann doch und jetzt geht es normal wie geplant heute online

**2025-10-20 09:36:56** - Julia:
> da hab ich richtig gemerkt, wieviel Druck da ist

**2025-10-20 09:55:53** - Julia H.:
> Oh gotttt du arme

**2025-10-20 09:55:57** - Julia H.:
> was für ein horror....

**2025-10-20 09:56:04** - Julia H.:
> hättest dich ruhig auch bei mir melden können

**2025-10-20 09:58:08** - Julia:
> ne alles gut, es war ja nur super nervig weil sie es nicht verstanden hat oder was auch immer

**2025-10-20 10:01:56** - Julia:
> bin im warteraum

**2025-10-20 10:01:59** - Julia H.:
> same

**2025-10-20 10:03:23** - Julia H.:
> war bisher auch nur busy mit community management, sprich bin noch gar nicht up to date

**2025-10-20 10:03:41** - Julia:
> okay

**2025-10-20 10:04:01** - Julia:
> ja also die ganzen SOS Postings können wir heute auf Sprinklr packen

**2025-10-20 10:04:54** - Julia:
> Hanna hatte am freitag eben noch in die SOS Präsi (von Charly) kommentiert und wir haben angepasst – bei einem Posting hat sie geschrieben "Neue Caption" -&gt; Müssen sich die 2 jetzt drum streiten

**2025-10-20 10:05:10** - Julia H.:
> haha okay

**2025-10-20 10:05:49** - Julia:
> aber weißt du, ob das meeting jetzt stattfindet?

**2025-10-20 10:06:20** - Julia:
> Pauschal einfach immer zu spät kommen, ist auch eine Leistung

**2025-10-20 10:06:24** - Julia H.:
> Kein plan hab ihr gerade geschrieben

**2025-10-20 10:32:32** - Julia H.:
> So dumm die Antwort von Nicolas

**2025-10-20 10:59:41** - Julia:
> ja :smile:

**2025-10-20 11:39:34** - Julia:
> 

**2025-10-20 11:41:54** - Julia H.:
> Yesss

**2025-10-20 11:42:10** - Julia H.:
> Vielleicht kann Mert das direkt in die große Präsi packen

**2025-10-20 11:45:04** - Julia:
> sag ich ihm

**2025-10-20 11:49:34** - Julia:
> liegt ab

**2025-10-20 12:38:44** - Julia:
> Mert findet leider die neueste PP Präsi nicht, da ich dir eigentlich die Reihenfolge gerne nochmal schicken wollte (bin mir nichtmehr sicher, ob es analog Figma ist), aber dann leider nur so:

**2025-10-20 12:39:09** - Julia:
> 

**2025-10-20 12:39:22** - Julia:
> die 2 passen nicht

**2025-10-20 13:22:41** - Julia H.:
> Moment schick ich euch gleich

**2025-10-20 13:27:19** - Julia:
> okay. ich würde jetzt in die pause – würdest du dann die story + repost reel posten? :slightly_smiling_face:

**2025-10-20 13:34:07** - Julia H.:
> Yes klaro!! Schick mir einfach den content 

**2025-10-20 14:55:33** - Julia H.:
> Schau mal so?

**2025-10-20 14:58:35** - Julia:
> ich finde halt das 2. passt garnicht aber glaube Charly wollte das ja oder?

**2025-10-20 14:59:27** - Julia H.:
> Ja glaub schon....

**2025-10-20 14:59:35** - Julia H.:
> Ich kanns mal noch mehr in die mitte legen moment

**2025-10-20 15:00:16** - Julia H.:
> So ist es etwas weniger prominent?

**2025-10-20 15:01:03** - Julia:
> jaa find ich besser!

**2025-10-20 15:09:43** - Julia:
> Also

**2025-10-20 15:09:54** - Julia:
> Das hab ich dir damals geschickt und du an Charly:

**2025-10-20 15:10:12** - Julia:
> 

**2025-10-20 15:12:11** - Julia H.:
> Ich schätze Hanna hat dann vielleicht die Texte geändert? Also wenn du es nicht warst?

**2025-10-20 15:12:20** - Julia H.:
> Dann sag ich Charly sie soll hier nochmal drüber schauen

**2025-10-20 15:12:34** - Julia:
> also die texte die jetzt in dieser Präsi liegen: <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7B387B2853-0A04-42DC-8E07-D1D802AA1A6E%7D&amp;file=251016_Porsche_DE_Copenhagen_BCC-Intern.pptx&amp;nav=eyJzSWQiOjIxNDc0ODM1MzUsImNJZCI6MjEzMzQ5ODMwMX0&amp;action=edit&amp;mobileredirect=true|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7B387B28[…]UsImNJZCI6MjEzMzQ5ODMwMX0&amp;action=edit&amp;mobileredirect=true>
hab ich jetzt eingefügt

**2025-10-20 15:12:40** - Julia:
> davor waren diese wieder englisch..?

**2025-10-20 15:12:56** - Julia:
> Ich füge jetzt nochmal die alte Folie von oben rein, dann kann sie die texte aussuchen

**2025-10-20 15:13:02** - Julia:
> das ist ganz komisch

**2025-10-20 15:13:06** - Julia H.:
> Hä ne also jetzt kapier ich nix mehr

**2025-10-20 15:13:22** - Julia:
> kurz huddle? :smile:

**2025-10-20 15:13:24** - Julia H.:
> ja

**2025-10-20 15:38:52** - Julia:
> falls Asana bei dir noch nicht geht: <https://drive.google.com/drive/folders/12XyomhvZuG-Vlnz60qlUF3DhD5Y6lULy>

**2025-10-20 15:40:53** - Julia H.:
> Daaanke. Pack ich in die Präsi zur Freigabe

**2025-10-20 15:43:00** - Julia:
> hab 2 versionen der letzten Slide gemacht. Weil sich Porsche sonst doppelt

**2025-10-20 15:43:08** - Julia:
> Aber wahrscheinlich will sie es so :new_moon_with_face:

**2025-10-20 15:43:22** - Julia H.:
> Ja hab's gesehen. Nehme mal das mit dem doppelten rein

**2025-10-20 16:19:04** - Julia H.:
> Freigegeben mit der Doppelten Variante :slightly_smiling_face:

**2025-10-20 16:26:16** - Julia:
> spannend

**2025-10-21 10:00:26** - Julia:
> there you go:

**2025-10-21 10:00:52** - Julia:
> 

**2025-10-21 10:01:29** - Julia H.:
> Thank you :heart:

**2025-10-21 10:01:31** - Julia H.:
> gute Reise

**2025-10-21 10:05:37** - Julia:
> dankee :slightly_smiling_face: bis gleich!

**2025-10-21 10:16:53** - Julia H.:
> ahh VBW machen wir immer mittig bei wallpaper

**2025-10-21 10:24:04** - Julia H.:
> Das hätte sie auch übrigens gern noch im Styleguide geändert, Ich weiß wir hatten mal dafür plädiert, dass es links sein soll, aber ich wollte jetzt kein fass mehr aufmachen

**2025-10-21 10:52:51** - Julia:
> oh okay, hier nochmal:

**2025-10-21 10:53:07** - Julia:
> alles klar, passe ich an

**2025-10-21 10:53:07** - Julia:
> 

**2025-10-21 11:31:17** - Julia H.:
> Supi, danke

**2025-10-21 11:36:43** - Julia:
> die rechnungsadresse ist die mandlstr. oder?

**2025-10-21 11:36:53** - Julia:
> für Nicolas

**2025-10-21 11:43:52** - Julia H.:
> Yes genau!! danke

**2025-10-21 13:33:02** - Julia:
> ich hab jetzt Figma angefangen aufzuräumen, können die Links dann easy in die Übergabe mit aufnehmen :slightly_smiling_face:

**2025-10-21 13:34:19** - Julia:
> Ich schreib Flo noch aber sonst hatte ich mal überlegt, ob ich dann wegen nächster Woche oder der ersten November Woche wegen Urlaub frage – nur schon mal FYI

**2025-10-21 13:34:40** - Julia:
> je nachdem wieviel jetzt noch ansteht

**2025-10-21 13:35:58** - Julia H.:
> Super!! Danke!

**2025-10-21 13:36:23** - Julia H.:
> Wegen mir safe. Porsche ist ja dann weg und ich bin wahrscheinlich auch erstmal im Urlaub weil die Sixt übergabe dann noch nicht ist

**2025-10-21 13:36:33** - Julia H.:
> Sprich das wäre doch ein guter zeitpunkt meiner meinung nach

**2025-10-21 13:48:55** - Julia:
> okay :slightly_smiling_face:

**2025-10-21 13:49:24** - Julia:
> yes, ich frag ihn mal. Mir wäre auch egal wann - Hauptsache Ruhe :joy:

**2025-10-21 14:02:59** - Julia:
> macht voll Sinn. Weißt du wann die ist?

**2025-10-21 14:04:06** - Julia H.:
> hahaha

**2025-10-21 14:04:20** - Julia H.:
> Ne keine Ahnung, Anfang November irgendwann

**2025-10-21 14:07:55** - Julia:
> okee

**2025-10-22 10:00:49** - Julia H.:
> Huhu, ich hab gerade gesehen, dass das Halloween Ding ein UGC Post war. Den müssen wir ja erst anfragen. Wie ist das bei den anderen? Kannst du da kurz schauen bitte?

**2025-10-22 10:00:57** - Julia H.:
> Da muss ich Charly bescheid geben

**2025-10-22 10:01:08** - Julia:
> Genau, das hab ich dir in Asana reingelegt

**2025-10-22 10:01:22** - Julia:
> Das ist ja nur das eine Bild das wir nutzen von diesem Post

**2025-10-22 10:01:36** - Julia:
> bei den anderen nicht. Das eine ist vom Gipfeltreffen, das andere ist von der Datenbank

**2025-10-22 10:01:40** - Julia H.:
> Yes, aber wir müssen da trotzdem die Rechte anfragen bei dem Dude leider

**2025-10-22 10:02:41** - Julia:
> <https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1211381756541688?focus=true>

**2025-10-22 10:02:43** - Julia:
> Okay

**2025-10-22 10:02:49** - Julia:
> ja wie gesagt die anderen sind keine UGCs

**2025-10-22 10:03:05** - Julia H.:
> Okay gut. Ich check mit Charly.

**2025-10-22 11:43:37** - Julia H.:
> Okay, das dürfen wir leider nicht verwenden. Haben wir ein ähnliches Bild auf der Datenbank?

**2025-10-22 11:54:44** - Julia:
> ah okay. nichts so cooles, hatte alles dir haucht. Und muss sagen, das war sehr aufwendig mit den Augen 

**2025-10-22 12:12:56** - Julia H.:
> :disappointed:

**2025-10-22 12:12:58** - Julia H.:
> super sad

**2025-10-22 12:13:05** - Julia H.:
> den mochte ich mit am liebsten

**2025-10-22 12:17:41** - Julia H.:
> das erste hier ist nix oder?

**2025-10-22 13:17:05** - Julia:
> Ich auch. Aber warum denn eigentlich?

Ich kann’s gerne probieren, wird mit der Perspektive aber nicht so leicht 

**2025-10-22 13:24:53** - Julia H.:
> Hmm und das letzte? 

**2025-10-22 13:27:06** - Julia H.:
> Keine Ahnung sie meinte weil PAG und UGC wird nicht verändert will Mich da nicht rumstreiten mit ihr ehrlichgesagt . 

**2025-10-22 13:29:10** - Julia:
> Ich probier beides einfach aus 

**2025-10-22 13:29:15** - Julia:
> verständlich 

**2025-10-22 13:49:46** - Julia H.:
> :heart: wenns zu viel Aufwand ist lassen wir das auch einfach

**2025-10-22 14:10:55** - Julia:
> jooooa

**2025-10-22 14:17:01** - Julia:
> hab dir die 2 hier reingelegt: <https://drive.google.com/drive/folders/1l6DgO7T8_SZmXVacAs0sL9n2QbZA9fsf>

**2025-10-22 14:28:13** - Julia:
> ging meine Nachricht in Teams durch? Das spinnt schon wieder

**2025-10-22 14:43:03** - Julia H.:
> Die an Hanna ist angekommen, yes!!

**2025-10-22 14:43:16** - Julia:
> super danke

**2025-10-22 14:44:20** - Julia H.:
> Finds eigentlich ganz cool, ich schicks Charly

**2025-10-22 15:59:48** - Julia H.:
> Hattest du meinen Comment gesehen zu Halloween Thumbnail und Größe vom Fledermaus Video?=

**2025-10-22 16:03:12** - Julia:
> oh ne, schau ich mir an 

**2025-10-22 16:27:04** - Julia:
> ich crop grad alles. ich dachte tatsächlich bei den Videos kann man das auch in Sprinklr dann direkt machen

**2025-10-22 16:28:04** - Julia:
> soweit war die AI dann nicht mit auch noch zuschneiden :smile:

**2025-10-22 16:34:18** - Julia H.:
> Alles gut kein Problem :relaxed:

**2025-10-22 16:46:56** - Julia:
> lädt alles gerade rein. Beim Fledermaus Video reicht das TN ja aus dem Video oder?

**2025-10-22 16:57:38** - Julia H.:
> coool danke

**2025-10-22 16:57:57** - Julia H.:
> Ja das mit dem TN Bei Fledermaus müsste ich über Sprinklr machen können

**2025-10-22 17:02:11** - Julia H.:
> Also ich kann in Sprinklr kein Video als einzel-Feedpost anlegen. weiß nciht ob das generell nicht geht und dann als reel gepostet werden muss?

**2025-10-22 17:02:50** - Julia:
> ja also es wird bei IG als "Reel" behandelt

**2025-10-22 17:03:22** - Julia:
> heißt es wird zwar in 1080x1350 gepostet und bleibt auch in dem Format aber wird in der Kategorie Reel angezeigt

**2025-10-22 17:03:26** - Julia:
> super umständlich

**2025-10-22 17:03:41** - Julia:
> hatte ich chatgpt damals auch nochmal gefragt

**2025-10-22 17:03:48** - Julia H.:
> ahhh okay, also würde ich es jetzt als Reel reinladen

**2025-10-22 17:04:01** - Julia:
> genau

**2025-10-22 17:04:11** - Julia:
> eigentlich darf mit dem format nix passieren

**2025-10-22 17:04:44** - Julia H.:
> puuhhh bin etwas unsicher, in Sprinklr sieht es in der Vorschau so aus:

**2025-10-22 17:04:55** - Julia H.:
> Wieso machen wir es nicht im normalen Reel Format dann?

**2025-10-22 17:04:57** - Julia:
> 

**2025-10-22 17:05:38** - Julia H.:
> Aber hast du explizit nach sprinklr gefragt?

**2025-10-22 17:06:34** - Julia:
> ne das nicht. also ich kann sie auch in 9x16 anlegen – ich persönlich finde so kurze videos in dem format nicht gut

**2025-10-22 17:06:57** - Julia:
> Also dann lieber in 9x16 oder was meinst du?

**2025-10-22 17:07:13** - Julia:
> genau, das ist dieser reel tab

**2025-10-22 17:07:43** - Julia H.:
> Sonst müsste man es mal kurz testen eventuell, oder wir laden es an dem Tag händisch hoch

**2025-10-22 17:08:25** - Julia:
> wir haben doch so einen BCC Fake account – da hatten wir das Gipfeltreffen Grid hoch geladen. Hast du den Zugriff?

**2025-10-22 17:08:42** - Julia H.:
> Ne, aber das ist ja auch nicht mit Sprinklr connected.

**2025-10-22 17:08:46** - Julia:
> Ich leg sie jetzt nochmal in 9x16 ab, dann haben wir es. ist ja egal

**2025-10-22 17:10:35** - Julia:
> dann lieber so, bevor es ihnen dann so nicht gefällt

**2025-10-22 17:10:39** - Julia H.:
> Reicht ja auch die Tage...

**2025-10-22 17:10:41** - Julia H.:
> Okay

**2025-10-22 17:15:16** - Julia:
> oke liegt wieder ab

**2025-10-22 17:15:27** - Julia:
> es wird bei 9x16 halt immer so gequetscht

**2025-10-23 09:18:09** - Julia H.:
> Danke Juli :heart:

**2025-10-23 09:22:09** - Julia H.:
> Sie wollte bei der Fledermaus auch noch eine andere Caption haben.
Hab überlegt da was von Dua zu recyceln? Hast du ne bessere Idee?

**2025-10-23 09:58:55** - Julia:
> nee find ich cool :slightly_smiling_face: danke

**2025-10-23 10:22:23** - Julia H.:
> ok mag sie nicht :stuck_out_tongue:

**2025-10-23 10:22:26** - Julia H.:
> Irgendwas mit nacht?

**2025-10-23 10:28:09** - Julia:
> • Gespenster jagen – bei XY km/h.
• Night drive, ghost mode on.
• Der Asphalt gehört Porsche.
• Schneller als jeder Schatten.
• Nachtschwärmer.
• Schattenflug auf Asphalt.
• Wenn der Asphaltjäger erwacht..

**2025-10-23 11:38:52** - Julia:
> weils mir gerade aufgefallen ist: wir haben für den Rundgang 1x das Werkscafé und 1x die Poster Wall gemacht – nicht die Fitting Lounge :slightly_smiling_face:

**2025-10-23 11:40:31** - Julia H.:
> Ah ja true 

**2025-10-23 11:40:50** - Julia H.:
> Muss ich auch im Redaktionsplan dann anpassen 

**2025-10-27 10:38:29** - Julia:
> Also von Hanna kam bisher echt keine Nachricht mehr

**2025-10-27 10:51:03** - Julia H.:
> dann warten wir

**2025-10-27 10:51:17** - Julia H.:
> Hast du hier zufällig Zugriff?

**2025-10-27 10:51:18** - Julia H.:
> <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BB0975E99-8559-4DB7-AAA3-7B39CDDC1F6C%7D&amp;file=2025%20Post%20Parkplatz%20Open%20Topics.pptx&amp;action=edit&amp;mobileredirect=true|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BB0975E[…]latz%20Open%20Topics.pptx&amp;action=edit&amp;mobileredirect=true>

**2025-10-27 10:51:38** - Julia:
> ne, hab angefordert

**2025-10-27 10:51:40** - Julia H.:
> nevermind hab schnell ein PDF gemacht

**2025-10-27 10:51:48** - Julia H.:
> Hier müssen wir auch noch die Assets ablegen

**2025-10-27 10:55:40** - Julia:
> ah ich hatte nur die 3: <https://drive.google.com/drive/folders/1UAtEfDEuxK-DoqSDqF_LRzSALd_BTfpv>

**2025-10-27 10:56:37** - Julia:
> dachte slide 3 ist raus tbh

**2025-10-27 10:56:52** - Julia:
> die ab Slide 8 kenne ich nicht

**2025-10-27 10:56:55** - Julia H.:
> Ne genau, nur der fehlt noch und oktoberfest

**2025-10-27 10:57:08** - Julia H.:
> die hinteren sachen waren vor deiner zeit die such ich

**2025-10-27 10:57:34** - Julia:
> okay passt, leg ich ab

**2025-10-27 11:05:14** - Julia:
> liegt alles ab, habs nochmal in unterordner abgelegt

**2025-10-27 11:05:30** - Julia H.:
> daaanke!

**2025-10-27 11:05:40** - Julia:
> klaroo

**2025-10-27 13:20:40** - Julia H.:
> Huhu vielleicht kannst du mir gleich kurz was helfen was sich auf dieses Paid Guide Dokument bezieht, wenn du aus der Pause zurück bist

**2025-10-27 13:29:35** - Julia:
> Na klar, bin in 20 min wieder an PC

**2025-10-27 13:46:08** - Julia:
> bin daaa

**2025-10-27 13:52:22** - Julia H.:
> Okay supi, kurz ins huddle maybe? das ist leichter

**2025-10-27 13:52:44** - Julia:
> Ja klar

**2025-10-27 14:30:55** - Julia H.:
> Please check

**2025-10-27 14:32:13** - Julia:
> jaa gut! Evtl nur noch ergänzen: 2 Stills die thematisch zu den Gipfeltreffen Videos passen innerhalb dieser Kampagne

**2025-10-27 14:33:20** - Julia H.:
> _Da wir im Engagement-Strang ja Probleme mit den Carousels haben, müssen wir auf Single Dark Ads in 1:1 und 9:16 gehen. Dadurch sind wir komplett unabhängig vom Feed bzw. bestehenden Postings und können uns einfach die favorisierten Assets raussuchen. Daher empfehlen wir 2 Stills zu nehmen, die thematisch zu den Gipfeltreffen Videos passen innerhalb dieser Kampagne. Alternativ könnten wir natürlich auch jedes andere 911 Image aus dem Gipfeltreffen Pool verwenden._

_Es würde sich daher anbieten, einfach zwei Bilder aus dem Dolomiten Carousel zu nehmen (ohne die Graphics). Sprich im Redaktionsplan müssten wir auch gar nichts verschieben._

**2025-10-27 14:33:37** - Julia:
> pörfekt

**2025-10-27 14:33:47** - Julia:
> hoffe sie versteht es

**2025-10-27 14:33:51** - Julia:
> aber es ist super erklärt

**2025-10-27 14:40:04** - Julia H.:
> Danke!!

**2025-10-27 14:40:20** - Julia H.:
> ChatGPT empfiehlt folgendes in deren Guide zu ergänzen:
:gear: *Was du noch ergänzen oder klarer machen könntest*
1. *Slideshow-Erklärung bei Organic*
Der Satz
&gt; „Alternativ: Slideshow aus Images, welches als Video hochgeladen wird“
&gt;  ist technisch richtig, aber unklar für weniger erfahrene Teams.
&gt;  Ich würde ergänzen:
&gt;  „(Meta behandelt Slideshows als Video-Ads, daher sind diese _nicht als organischer Post_ anlegbar – nur als Dark Ads nutzbar.)“
So vermeidest du Missverständnisse à la „wir machen einfach eine Slideshow im Feed“.

2. *Textbegrenzungen / Copy-Check*
Du schreibst:
&gt; „Schaut hierzu bitte in die folgenden Specs, was die Zeichenlängen betrifft.“
&gt;  Ich würde ergänzen, dass _Captions und Headlines_ in Meta je nach Placement variieren – Beispiel:
&gt; Primary Text: bis zu 125 Zeichen (empfohlen)
&gt; Headline: bis zu 40 Zeichen
&gt; Description: optional, max. 30 Zeichen
Das hilft, wenn Designer:innen oder Copywriter:innen mitarbeiten.

3. *Technischer Zusatz bei Carousel Ads*
Da du unten noch einen Abschnitt mit „Zusätzliche Infos zu Carousel Ads“ hast, würde ich dort ergänzen:
&gt; „Bitte beachten: Carousels sind aktuell _nur noch im Conversion- oder Traffic-Ziel_ möglich – nicht bei Engagement oder Reach.“
Das ist die _praktische Ursache_ der Einschränkung und macht das Ganze nachvollziehbarer.

4. *Empfehlung zu Safezones*
Der Hinweis ist gut („Safezone vom 1x1-Format muss eingehalten werden“),
 ich würde ergänzen:
&gt; „Empfohlen: 250 px oben/unten freilassen bei 9x16, damit kein Text durch UI-Elemente verdeckt wird (z. B. Profilname, CTA-Button).“


**2025-10-27 14:53:02** - Julia:
> Ja macht Sinn. die safezone könnte man Mann weglassen, weil wir ja nie Text auf Bild als auf schalten werden (oder?) also somit werden k nur Bilder abgeschnitten die natürlich sowieso gut platziert sein müssen 

**2025-10-27 14:53:28** - Julia:
> Ja die Info von 3. hat uns gefehlt :zany_face:

**2025-10-27 15:12:54** - Julia H.:
> LOL

**2025-10-27 15:12:55** - Julia H.:
> gude laune mal wieder

**2025-10-27 15:13:38** - Julia H.:
> 

**2025-10-27 15:14:16** - Julia:
> oh schön 

**2025-10-27 15:14:19** - Julia H.:
> Also den Gt3 Dolo können wir schon mal preppen. 1x1 und 9x16 und ne caption dazu

**2025-10-27 15:14:26** - Julia H.:
> immer wieder fun einfach

**2025-10-27 15:14:49** - Julia:
> stills sind nicht dämlich :no_mouth: 

**2025-10-27 15:14:54** - Julia:
> Leg ich ab 

**2025-10-27 15:15:22** - Julia H.:
> Danke :heart:

**2025-10-27 15:16:24** - Julia:
> können wir denn irgendwie an die video captions der Kampagne kommen? 

**2025-10-27 15:17:20** - Julia H.:
> Moment le me check

**2025-10-27 15:22:42** - Julia H.:
> <https://www.picdrop.com/porsche-deutschland/a5f6NA7LQr?file=35c8c3f1cfb224db91c500ed23769ae4>
Charly hatte noch den vorgeschlagen.

**2025-10-27 15:22:58** - Julia H.:
> Bitte bei den Captions die Zeichenlängen von meta beachten, sind in dem Guide verlinkt

**2025-10-27 15:23:38** - Julia H.:
> 

**2025-10-27 15:23:43** - Julia H.:
> Also wir sollen das mal so vorbereiten und sonst bei PHD nachfragen.

**2025-10-27 15:24:04** - Julia H.:
> VBW ist halt noch so ein Thema. Im Guide steht sie sollen aufs Asset oder in die Caption (bei 1x1 halt super ugly oder?)

**2025-10-27 15:24:39** - Julia:
> okay 

**2025-10-27 15:25:02** - Julia:
> Ja voll, ich schau mal im ads Manager wie Porsche global das macht 

**2025-10-27 15:31:12** - Julia H.:
> danke :heart:

**2025-10-27 15:37:13** - Julia H.:
> My dear, könntest du eventuell bei Dana von PHD anrufen und nachfragen? Ich kann ja hier keine direkten Calls machen. Honestly ich glaub eh nicht, dass sie rangeht, weil da Montags immer keiner da ist (lol)

**2025-10-27 15:37:18** - Julia H.:
> aber dann haben wir es wenigstens probiert

**2025-10-27 15:48:02** - Julia H.:
> Sorry, das sich dich so mit Screenshots zuballer, aber ich bin sonst auch bisschen lost wie ich das alles erklären soll. Hab ihr jetzt mal das geschrieben

**2025-10-27 15:51:37** - Julia:
> okay mach ich

**2025-10-27 15:51:43** - Julia:
> ne alles gut

**2025-10-27 15:51:56** - Julia H.:
> Danke :heart:

**2025-10-27 15:53:19** - Julia:
> find ich super

**2025-10-27 15:53:47** - Julia H.:
> <tel:+491737952721|+491737952721>
Das ist die Nummer von Katharina Gross. Die ist Director auf der Porsche Kampagne. Diese Dana hat keine Nummer in der Signatur.... Wir müssen einfach im Namen von Charly da anrufen und sagen wir brauchen ne Emfpehlung.

**2025-10-27 15:53:52** - Julia H.:
> :heart:

**2025-10-27 15:53:59** - Julia H.:
> Das können wir auch so an PHD herantragen

**2025-10-27 15:54:20** - Julia:
> Ahh wollte grad suchen

**2025-10-27 15:54:29** - Julia H.:
> Danke :heart:

**2025-10-27 15:54:49** - Julia H.:
> als ich das letzte mal dachte: Wird schon nicht so schlimm sein und ich 5 min telefoniert hab, war meine Handyrechnung 170E

**2025-10-27 15:55:34** - Julia:
> was ich bei Charly einfach liebe ist, dass sie es so hindreht mit "für mich ist das parallel jetzt echt schwer"
Als wären WIR schuld an dem ganzen hin und her. Weißt du wie ich meine? Wir unterstützen sie nur bei etwas netterweise und sie dreht es so hin als ob wir dumm sind :smile:

**2025-10-27 15:56:04** - Julia H.:
> 100%. Kann kein Mensch was dafür, dass du krank bist und nen Workshop hast.

**2025-10-27 15:56:15** - Julia H.:
> Ich hätte auch sagen können: Ne machen wir nicht, ist nicht mehr unsere Verantwortung

**2025-10-27 15:56:24** - Julia H.:
> Die wird mit jeder weiteren Agency probleme haben

**2025-10-27 15:56:34** - Julia:
> omg

**2025-10-27 15:56:55** - Julia:
> ne geht keiner ran

**2025-10-27 15:58:48** - Julia:
> habs jetzt mal versucht und jetzt auf die VM gesprochen

**2025-10-27 15:59:04** - Julia:
> diese Katharina wird auch denken es brennt

**2025-10-27 15:59:44** - Julia:
> ja voll

**2025-10-27 16:00:05** - Julia:
> auch das "bleibt das Thema halt weiterhin liegen" ja okay, we dont care? :smile:

**2025-10-27 16:02:43** - Julia:
> dann bereite ich jetzt aber keine assets vor, oder? :smile:

**2025-10-27 16:03:02** - Julia H.:
> yep 100

**2025-10-27 16:03:55** - Julia H.:
> Ich frag Charly mal noch ob sie ne nummer hat und sonst schreib ich ne mail

**2025-10-27 16:04:06** - Julia H.:
> Danke juli

**2025-10-27 16:04:08** - Julia H.:
> so dumm ey

**2025-10-27 16:04:11** - Julia:
> ja klar

**2025-10-27 16:04:20** - Julia:
> sag bescheid, wenn ich noch etwas tun kann

**2025-10-27 16:04:28** - Julia H.:
> und dann kommt immer noch diese doofe prakti die mir irgendwie aufgaben gibt, könnte in meinen laptop hauen heute

**2025-10-27 16:04:39** - Julia:
> wer??

**2025-10-27 16:04:45** - Julia H.:
> diese jana

**2025-10-27 16:04:48** - Julia:
> schieb rüber, ich kann alles übernehmen

**2025-10-27 16:04:56** - Julia:
> ah

**2025-10-27 16:05:01** - Julia H.:
> Ja easy, ist CM und dann noch das YT Video

**2025-10-27 16:05:24** - Julia:
> okay

**2025-10-27 16:05:37** - Julia:
> fühle mich so schlecht, wenn man so garnichts zutun hat :smile:

**2025-10-27 16:17:28** - Julia H.:
> Ja same, aber genieß es

**2025-10-27 16:17:31** - Julia H.:
> so gut es geht

**2025-10-27 16:27:24** - Julia H.:
> Du könntest mir tatsächlich noch helfen diese mail an PHD zu schreiben

**2025-10-27 16:27:28** - Julia H.:
> ich krieg den need nicht so richtig rüber

**2025-10-27 16:27:31** - Julia:
> ja klar

**2025-10-27 16:27:48** - Julia H.:
> Hallo Dana,

leider konnten wir euch telefonisch nicht erreichen. Wir wollten uns mal kurz telefonisch mit euch abstimmen und euch um eine klare Handlungsempfehlung bitten, wie wir die beiden noch offenen Posts am schnellsten live stellen können, idealerweise so, dass es auch wirklich Sinn macht und kein Budget verpufft?

Charly's klare Präferenz wären organische Posts (am liebsten Carousel-Posts), sofern das irgendwie möglich ist. Laut Asset Guide und aktuellen Meta Bestimmungen kann man das ja ausprobieren, richtig? Wie schnell ginge das, oder sprechen wir auch hier von den üblichen 3 Tagen?
Falls das nicht geht, bleibt uns ja lediglich übrig auf zwei Still Dark Ads zu gehen.

Euer Asset Guide ist zwar technisch ist hilfreich, aber sehr allgemein und uns ist ehrlich gesagt immer noch nicht klar, was davon aktuell tatsächlich am besten funktioniert und welche Variante ihr empfehlen würdet. Könntet ihr uns daher bitte anhand des konkreten Needs der zwei fehlenden Assets für die 911 Engagement Kampagne zwei Varianten nennen, die ihr für unsere Kampagne am sinnvollsten haltet.
 deswegen wäre mir wichtig zu wissen, welche Option ihr performance-seitig bevorzugt und was ihr für realistisch haltet.

Danke euch &amp; viele Grüße

**2025-10-27 16:27:57** - Julia H.:
> Danke ich mach gerade zu viel gleichzeitig

**2025-10-27 16:30:27** - Julia:
> ich bin dran

**2025-10-27 16:37:50** - Julia H.:
> ich sterbe

**2025-10-27 16:37:55** - Julia H.:
> ich mag nimmer

**2025-10-27 16:37:59** - Julia:
> Hallo Dana,

wir haben euch leider telefonisch nicht erreicht und wollten uns deshalb kurz auf diesem Weg mit euch abstimmen. Ansonsten auch gerne direkt morgen in einem kurzen Meeting?

Konkret geht es um eine klare Empfehlung, wie wir die beiden noch offenen Posts der 911 Engagement Kampagne am schnellsten und sinnvollsten live stellen können – idealerweise so, dass das Budget effizient genutzt wird.
Charly’s Favorit wäre es organische Posts zu nehmen (am liebsten im Carousel-Format). Laut Asset Guide und den aktuellen Meta-Richtlinien scheint das grundsätzlich machbar aber muss getestet werden – könnt ihr uns sagen, wie schnell das realistisch umsetzbar wäre? Müssen wir hier mit der üblichen 3-Tage-Umsetzungszeit rechnen?

Falls das nicht praktikabel ist, bliebe als Alternative ja nur die Schaltung von 2 Still Dark Ads (in 1x1 und 9x16). Oder?
Könntet ihr uns bitte für die zwei fehlenden Assets der 911 Engagement Kampagne also zwei konkrete Varianten nennen, die ihr performance-seitig für am geeignetsten haltet?


Euer Asset Guide ist zwar technisch hilfreich, ist aber tatsächlich etwas knapp gehalten – uns fehlt die klare Einordnung, was für unsere aktuelle Situation tatsächlich am meisten Sinn macht, damit wir direkt entscheiden können und die Kampagne online gehen kann.

Falls wir kurz dazu sprechen sollen, könnt ihr gerne direkt morgens unter <tel:+15229018774|+15229018774> anrufen.

**2025-10-27 16:38:36** - Julia:
> also ne

**2025-10-27 16:38:40** - Julia:
> Charly hat doch keine ahnung

**2025-10-27 16:38:44** - Julia:
> die bringt so viel verwirrung rein

**2025-10-27 16:38:54** - Julia H.:
> ja hat sie auch nicht das ist ja das problem

**2025-10-27 16:40:12** - Julia:
> frage ist "was ist die aktuelle"?
Weil dann müssen es ja die gleichen assets sein, die "in der aktuellen sind". dann brauchen wir auch nichts neues reinnehmen, sonst ist der Vergleich ja komplett vrefälscht

**2025-10-27 16:40:35** - Julia:
> soll ich die Mail abschicken? Kann ich gerne maachen

**2025-10-27 16:41:22** - Julia H.:
> 

**2025-10-27 16:41:24** - Julia H.:
> schau mal das passt so oderß

**2025-10-27 16:41:35** - Julia H.:
> die aktuelle ist eigentlich profile visits und dann ab 5.11. engagement

**2025-10-27 16:41:50** - Julia H.:
> warten wir mal kurz ab was jetzt noch kommt

**2025-10-27 16:41:52** - Julia:
> moment ich vergleiche kurz

**2025-10-27 16:42:22** - Julia H.:
> danke

**2025-10-27 16:43:20** - Julia H.:
> laut chat gpt stimmt das so :stuck_out_tongue:

**2025-10-27 16:43:26** - Julia:
> ja passt

**2025-10-27 16:43:58** - Julia:
> vogelwild, dass du ihr jetzt performance marketing erklären sollst

**2025-10-27 16:45:15** - Julia H.:
> Sowas von bescheuert. Und im Worstcase bin ich der Arsch

**2025-10-27 16:45:23** - Julia H.:
> aber frag doch bitte deine kack paid agentur dafür hast du doch eine

**2025-10-27 16:45:25** - Julia H.:
> WTF ey

**2025-10-27 16:45:31** - Julia H.:
> Naja, also anyway: Sprich jetzt bei Profile Visit haben wir nur die eine Option: Single Image (empfohlen 9x16).

**2025-10-27 16:45:43** - Julia:
> genau

**2025-10-27 16:45:52** - Julia H.:
> Ich schau mal was da jetzt zurück kommt

**2025-10-27 16:46:04** - Julia H.:
> Sie hatte die ganze zeit von engagement gesprochen

**2025-10-27 16:46:27** - Julia H.:
> Und fun fact: Eigentlich hat ihr kollege andres das thema übernommen

**2025-10-27 16:48:08** - Julia:
> unglaublich

**2025-10-27 16:48:20** - Julia:
> die soll doch einfach mal netflix anmachen und chillen

**2025-10-27 16:48:25** - Julia:
> wenn sie schon krank ist

**2025-10-27 16:52:03** - Julia H.:
> 100%

**2025-10-27 16:52:08** - Julia H.:
> so annoying das ganze

**2025-10-27 16:52:14** - Julia H.:
> mir reichts für heute ich sags euch

**2025-10-27 16:54:57** - Julia:
> T -4 !!!

**2025-10-27 16:55:25** - Julia H.:
> 100!!!

**2025-10-27 17:14:35** - Julia H.:
> LOL, also wir schicken erstmal die Mail nicht ab. Und verbleiben wie von mir vorgeschlagen

**2025-10-27 17:15:32** - Julia H.:
> Wir müssen also vorbereiten 9x16 und 1x1 und würde die VBW bei allen mit aufs Asset nehmen. Warte noch auf finale Bestätigung welche Assets wir nehmen

**2025-10-27 17:15:35** - Julia H.:
> was für ein krimi

**2025-10-27 17:17:57** - Julia H.:
> • Dolomiten 911 Starter Bild 
• beim zweiten eins von den beiden. <https://www.picdrop.com/porsche-deutschland/a5f6NA7LQr?file=35c8c3f1cfb224db91c500ed23769ae4> oder <https://www.picdrop.com/porsche-deutschland/a5f6NA7LQr?file=f931030544e5c140af9bd3b54331d846>

**2025-10-27 17:18:16** - Julia H.:
> VBW check ich morgen :heart:

**2025-10-27 17:19:17** - Julia:
> okay :smile:

**2025-10-27 17:19:44** - Julia:
> mach ich haha

**2025-10-28 09:36:15** - Julia H.:
> Huhuuuu

**2025-10-28 09:37:34** - Julia H.:
> kommst du zu uns?

**2025-10-28 09:37:36** - Julia H.:
> are ou ok?

**2025-10-28 09:38:51** - Julia:
> Hallooo

**2025-10-28 09:38:59** - Julia:
> Ahh ich hab keinen Termin drin

**2025-10-28 09:39:10** - Julia H.:
> <https://meet.google.com/gwf-zuzb-jvi>

**2025-10-28 09:39:11** - Julia H.:
> haha

**2025-10-28 09:43:50** - Julia:
> 

**2025-10-28 10:26:35** - Julia:
> Hast du hierauf zugriff?

**2025-10-28 10:26:37** - Julia:
> <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/EaiOjQqrU7pGuG9Uh1HoPnYBcTMdT3cFpeBT1QC5Z3cmWw?e=TkNX08>

**2025-10-28 10:36:39** - Julia H.:
> yes!!

**2025-10-28 10:36:59** - Julia H.:
> Hammer danke! Schicke ich an Charly

**2025-10-28 14:04:33** - Julia H.:
> Huhu Juli, schau mal das kam von Charly zurpück

**2025-10-28 14:04:37** - Julia H.:
> 

**2025-10-28 14:38:31** - Julia:
> Hä aber genau deshalb liefert man ja 2 Formate an 

**2025-10-28 14:39:29** - Julia H.:
> wie meinst du mit den 2 Formaten

**2025-10-28 14:40:58** - Julia:
> also weil sie meint ja, dass 9x16 auf 1x1 gecropped wird. Aber das stimmt ja nicht: wir liefern 2 fertige Formate an, da wird bei Meta nichts mehr gecropped

**2025-10-28 14:41:20** - Julia H.:
> Ahh so meinst du

**2025-10-28 14:41:29** - Julia H.:
> und ich nehm an der Safe space ist beachtet :stuck_out_tongue:

**2025-10-28 14:41:37** - Julia H.:
> Zone mein ich

**2025-10-28 14:41:42** - Julia:
> Deshalb gibt es ja 2 von euch Bänder unterschiedliche Formate 

**2025-10-28 14:42:03** - Julia:
> Das besteht sie nicht. Es sind unterschiedliche einzelne Assets, das muss sie mal kapieren :zany_face:

**2025-10-28 14:42:12** - Julia H.:
> Also aber bei der Profile Visit kommt ja eh nur die 9x16 in Frage

**2025-10-28 14:42:20** - Julia H.:
> das 1x1 ist ja dann für die andere kampagne

**2025-10-28 14:43:03** - Julia:
> Ja. Ich hab schon <tel:1000000|1000000> c ads in meinem Leben gemacht - bei 1x1 gibt es keinen Safe Space, hier kann nichts zugeschnitten werden und bei 9x16 ist es der gleiche Space wie bei einer story

**2025-10-28 14:43:27** - Julia H.:
> okeee makes sense

**2025-10-28 14:43:28** - Julia:
> Ja genau. Ich hab’s ja direkt für beide Kampagnen angelegt 

**2025-10-28 14:43:37** - Julia H.:
> ich glaub ich kapier auch einfach ihre message nicht.

**2025-10-28 14:43:43** - Julia H.:
> wieso sollte das denn gecropped werden?

**2025-10-28 14:43:52** - Julia H.:
> ich kann das alles nicht mehr

**2025-10-28 14:44:56** - Julia:
> Ja 

**2025-10-28 14:45:48** - Julia:
> Also mehr als das kann ich nicht sagen :joy: es wird bei 9x16 was ich in die Präsi gelegt habe NIX zugeschnitten weil das als Story ausgespielt wird  

**2025-10-28 14:49:13** - Julia:
> ja genau

**2025-10-28 14:49:31** - Julia H.:
> Ja makes sense now danke :heart:

**2025-10-28 14:50:11** - Julia:
> Du kannst ihr auch gerne sagen, ich kann ihr :sparkles:sehr sehr:sparkles: gerne morgen früh mal Paid Ads erklären und deren ausspielung 

**2025-10-28 14:50:18** - Julia:
> Damit es klarer wird für sie 

**2025-10-28 14:50:43** - Julia H.:
> Sicher dass du dir das antun willst :stuck_out_tongue:

**2025-10-28 14:50:49** - Julia:
> ahhh die macht mich wahnsinnig :joy:

**2025-10-28 14:51:12** - Julia:
> wenn sie uns dann damit in Ruhe lässt ja 

**2025-10-28 14:52:02** - Julia H.:
> sehen wir mal was jetzt zurück kommt

**2025-10-28 14:52:14** - Julia H.:
> same. und Flo auch

**2025-10-28 14:55:20** - Julia:
> und wir dann auch einfach mal nicht dumm dastehen

**2025-10-28 14:55:38** - Julia:
> sie ihn oder er dich? 

**2025-10-28 14:55:40** - Julia:
> Oder beides 

**2025-10-28 15:05:29** - Julia:
> ah noch was anderes: die Rechnung von :mouse: war ja schon in der Mail. Aber ich schicke es Flo lieber nochmal oder? 

**2025-10-28 15:22:28** - Julia H.:
> 

**2025-10-28 15:22:36** - Julia H.:
> also ich weiß auch nicht mehr langsam

**2025-10-28 15:22:45** - Julia H.:
> hatte ich schon weitergeleitet

**2025-10-28 15:23:08** - Julia H.:
> reagiert einfach wieder auf keine meiner nachrichten

**2025-10-28 15:24:27** - Julia:
> puh

**2025-10-28 15:25:43** - Julia:
> also wenn das so ist, dann ist das was neues

**2025-10-28 15:25:47** - Julia:
> oder die agentur redet quatsch

**2025-10-28 15:26:10** - Julia:
> Also ich hab wie gsagt bis vor 2 Monaten noch tagtäglich Ads gemacht und da liefert man 2 Formate an die nicht zugeschnitten werden oder sonst was

**2025-10-28 15:27:39** - Julia:
> ahh danke!

**2025-10-28 15:27:41** - Julia:
> wow

**2025-10-28 15:30:16** - Julia:
> weißt ich würde das ja nicht so stocksteif behaupten, wenn ich nicht wüsste, dass es so ist ODER war

**2025-10-28 15:30:51** - Julia H.:
> Ich weiß jetzt gar nicht mehr was ich dazu sagen soll

**2025-10-28 15:30:58** - Julia H.:
> Ich kapier es auch einfach nicht 

**2025-10-28 15:31:12** - Julia H.:
> Wenn wir nur ein Format machen können be Profile visits?

**2025-10-28 15:31:33** - Julia:
> ich hab das auch noch nie gehört

**2025-10-28 15:31:51** - Julia:
> ABER dann ist es 9x16 und bleibt 9x16, weil das wird ja von PHD empfohlen

**2025-10-28 15:31:59** - Julia H.:
> Wie finden wir das jetzt raus 

**2025-10-28 15:32:11** - Julia H.:
> Aber der eine Text im screeny kommt ja vom PHD

**2025-10-28 15:33:29** - Julia:
> ja, dann schieb ich das jetzt hoch + VBWs damit 9x16 auch für 1x1 zuschnitt passt (HAB ICH NOCH NIE GEHÖRT)
und die 1x1 assets liegen dann schon für die nächste Kampagne ab

**2025-10-28 15:39:38** - Julia H.:
> Okay danke 

**2025-10-28 15:39:45** - Julia:
> <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/EaiOjQqrU7pGuG9Uh1HoPnYBcTMdT3cFpeBT1QC5Z3cmWw?e=bK4FuL>

**2025-10-28 15:39:49** - Julia:
> liegen ab

**2025-10-28 15:39:51** - Julia H.:
> Sollten wir nochmal chat gpt fragen?

**2025-10-28 15:41:51** - Julia:
> 

**2025-10-28 15:42:21** - Julia:
> das ist wirklich neu

**2025-10-28 15:42:53** - Julia:
> hab dir den neuen ausschnitt in die präsi gelegt – sobald Go, leg ichs dann auch ab

**2025-10-28 16:01:37** - Julia H.:
> Danke Juli :heart:

**2025-10-28 17:10:07** - Julia:
> kam nochmal was? 

**2025-10-28 17:10:19** - Julia H.:
> ne bisher nicht

**2025-10-28 17:10:23** - Julia H.:
> :disappointed:

**2025-10-28 17:10:40** - Julia:
> finds aber auch krass, diese Katharina hat nicht zurück gerufen  

**2025-10-28 17:10:51** - Julia H.:
> ne zero fucks sind die

**2025-10-28 17:10:57** - Julia H.:
> aber sie sind wohl bei dem workshop heute dabei

**2025-10-28 17:12:18** - Julia:
> Aber dann ganz ehrlich: warum kackt Charly uns/ dich dann an, dann soll sie das doch mit denen direkt klären? anstatt komplette Verwirrung zu stiften :smile:

**2025-10-28 17:13:17** - Julia H.:
> Yep i know. sie meinte dann vorher: ich frag sie mal direkt

**2025-10-28 17:13:20** - Julia H.:
> haha

**2025-10-29 08:52:54** - Julia H.:
> Good morning, gehst du mit mir ins Porsche Meeting um 9?

**2025-10-29 08:53:10** - Julia H.:
> Charly wollte ja auch die übergabe besprechen, denke das wäre nicht schlecht

**2025-10-29 09:13:29** - Julia:
> Guten Morgen! klar, kann reinkommen. Aber ohne Kamera – liege, das fände ich komisch :smile:

**2025-10-29 09:15:28** - Julia:
> ich komme nicht rein

**2025-10-29 09:17:07** - Julia:
> 

**2025-10-29 09:17:20** - Julia H.:
> kein problem

**2025-10-29 09:17:25** - Julia H.:
> charly ist hart heute

**2025-10-29 09:17:28** - Julia H.:
> lass es lieber

**2025-10-29 09:18:09** - Julia:
> dann komm ich auf jeden fall und unterstütze dich. aber es lädt einfach nicht, ich probiere solange es geht!!

**2025-10-29 09:20:12** - Julia:
> das ist so ein scheiß – kann nichts drücken, garnichts

**2025-10-29 09:20:52** - Julia:
> Tut mir leid :fearful: aber ich bin da, wenn du was brauchst und ich so schnell helfen soll

**2025-10-29 09:21:53** - Julia H.:
> Ne alles gut, brauchst nicht mehr reinkommen

**2025-10-29 09:25:54** - Julia:
> oke

**2025-10-29 09:46:24** - Julia H.:
> puhhhh

**2025-10-29 09:46:27** - Julia H.:
> also meeting ist over

**2025-10-29 09:49:29** - Julia:
> soo schlimm?

**2025-10-29 09:49:34** - Julia:
> sollen wir kurz sprechen?

**2025-10-29 09:49:42** - Julia:
> mach mir noch schnell einen kaffee und wäre da

**2025-10-29 09:51:59** - Julia H.:
> Ich mach noch schnell was fertig ja?

**2025-10-29 09:52:21** - Julia H.:
> Hier brauchen wir noch ne neue CAption pls, wir posten das jetzt unabhängig von karneval am 4.12.

**2025-10-29 09:55:27** - Julia:
> okidoki

**2025-10-29 10:03:07** - Julia:
> Träume sind kein Zufall. Sie sind Sonderwunsch.
--
Träume baut man nicht von der Stange.
 Man erschafft sie – mit Porsche Sonderwunsch.
--
Kein Mainstream. Kein Zufall. Porsche Sonderwunsch.

**2025-10-29 10:03:26** - Julia H.:
> I like, danke!!

**2025-10-29 10:06:34** - Julia:
> also ich komme immer noch nicht in teams, falls hanna was geschrieben hat

**2025-10-29 10:06:58** - Julia H.:
> Okay, bisher kam nichts

**2025-10-29 10:07:09** - Julia:
> okee

**2025-10-29 10:10:40** - Julia:
> was planen sie dann an Karneval? die 911/ 11.11.?

**2025-10-29 10:15:44** - Julia H.:
> ja genau

**2025-10-29 11:27:05** - Julia:
> sonst gabs kein to do mehr wahrscheinlich oder?

**2025-10-29 11:38:30** - Julia H.:
> Ne nichts akutes. Die Paid sachen hab ich mal an PDH geschickt
Reportings muss Flo final drüber schauen.

**2025-10-29 11:38:41** - Julia H.:
> Sie meinte eventuell schickt sie uns die Gobi Assets, damit wir die auf Sprinklr packen

**2025-10-29 11:51:44** - Julia:
> okay ja

**2025-10-29 11:51:46** - Julia:
> ja hab ich gesehen

**2025-10-29 11:51:57** - Julia:
> wieso war sie dann blöd? also welchen grund gab es denn?

**2025-10-29 11:52:17** - Julia H.:
> Ach gestern abend schon beim Porsche Points Post ging es 100 mal hin und her....

**2025-10-29 11:52:24** - Julia H.:
> habt ihr die VBW gecheckt?

**2025-10-29 11:52:27** - Julia H.:
> Stimmt die Caption?

**2025-10-29 11:52:47** - Julia H.:
> Heute auch um 9:10 uhr für das Wallpaper um 9:11 - ist das überhaupt der dakar?

**2025-10-29 11:52:55** - Julia H.:
> war alles schon seit ewig freigegeben

**2025-10-29 11:52:58** - Julia:
> Oh gott

**2025-10-29 11:53:00** - Julia:
> ne haben wir nicht

**2025-10-29 11:53:02** - Julia:
> natürlich nicht

**2025-10-29 11:53:05** - Julia H.:
> saß da gestern bestimmt 30 min dran nur für die 3 story slides

**2025-10-29 11:53:14** - Julia H.:
> ich hätte sie am liebsten angeschrieen

**2025-10-29 11:53:23** - Julia H.:
> "hast du geprüft ob der link funktioniert"

**2025-10-29 11:53:27** - Julia H.:
> sowas von degrading

**2025-10-29 11:53:34** - Julia:
> boah exy

**2025-10-29 11:53:43** - Julia:
> schlimmer als jeder David L. dieser Welt

**2025-10-29 11:53:56** - Julia:
> echt als wären wir dumm

**2025-10-29 11:54:03** - Julia:
> tut mir leid :fearful:

**2025-10-29 11:57:29** - Julia H.:
> 

**2025-10-29 12:00:35** - Julia H.:
> so fühl ich mich

**2025-10-29 12:00:35** - Julia H.:
> haha

**2025-10-29 12:17:41** - Julia:
> jaa

**2025-10-29 12:17:47** - Julia:
> versteh ich :face_exhaling:

**2025-10-29 14:29:10** - Julia H.:
> Hab News zu Paid: Könnt ihr mir bitte die Assets 911 Gipfeltreffen jeweils nur mit den 911 GT3 VBW (ohne GT4) zusenden/ablegen?

**2025-10-29 14:29:31** - Julia:
> okay

**2025-10-29 14:29:39** - Julia:
> hab grad die Mail gelesen von Dana

**2025-10-29 14:29:45** - Julia:
> in 9x16 dann?

**2025-10-29 14:29:56** - Julia H.:
> yes genau

**2025-10-29 14:29:59** - Julia:
> und VBW von November?

**2025-10-29 14:30:15** - Julia H.:
> VBW dürfen von 10/2025 sein, müssen wir auch nicht ändern im November, aber wäre cool, wenn wir die nochmal mit November VBW hätten für die folgende Engagement Kampagne

**2025-10-29 14:30:25** - Julia H.:
> moment du warst zu schnell

**2025-10-29 14:32:16** - Julia:
> haha oke

**2025-10-29 14:36:06** - Julia:
> 

**2025-10-29 14:36:11** - Julia:
> also ich hab nochmal alles probiert, laptop aus an aber ich komme nicht in teams

**2025-10-29 14:36:33** - Julia:
> ob ichs Flo schon 15x gesagt hab? :melting_face:

**2025-10-29 14:39:22** - Julia H.:
> Daaanke! Kannst du das direkt an Charly schicken per mail pls?

**2025-10-29 14:39:30** - Julia:
> ja klar

**2025-10-29 14:39:34** - Julia H.:
> :heart:

**2025-10-29 14:40:19** - Julia H.:
> Hab gleich noch ein meeting mit hanna

**2025-10-29 14:40:51** - Julia:
> genau, sie hatte mich da auch mit eingeladen aber ich komme einfach nicht rein

**2025-10-29 14:41:00** - Julia H.:
> hast du gleich nochmal zeit für mich?

**2025-10-29 14:41:08** - Julia:
> klar

**2025-10-29 14:41:09** - Julia H.:
> bis 16 uhr?

**2025-10-29 14:41:20** - Julia H.:
> huddle?

**2025-10-29 14:41:30** - Julia H.:
> <https://meet.google.com/gwf-zuzb-jvi>

**2025-10-29 14:41:34** - Julia:
> jetzt oder nach dem call mit hanna?

**2025-10-29 14:41:55** - Julia H.:
> jetzt wär supi

**2025-10-29 14:56:07** - Julia:
> <https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1211465610715674?focus=true>

**2025-10-29 14:57:12** - Julia:
> <https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1211408893442141?focus=true>

**2025-10-29 14:57:30** - Julia H.:
> <https://docs.google.com/presentation/d/1uJx_LoaNymBB1qkIUF3tGpVu0i_J5cT2/edit?slide=id.p55#slide=id.p55>

**2025-10-30 10:04:19** - Julia:
> also bei den Rundgang Stories können wir halt nichts schedulen – die müssen alle händisch gepostet werden FYI

**2025-10-30 10:04:45** - Julia H.:
> Yes genau. Legen wir einfach ab

**2025-10-30 10:16:36** - Julia:
> okay

**2025-10-30 10:17:01** - Julia:
> sollen wir so um 12Uhr wegen reporting sprechen oder lieber nachmittags? :slightly_smiling_face:

**2025-10-30 10:17:05** - Julia:
> mir ist es total egal

**2025-10-30 10:17:39** - Julia H.:
> Lass doch direkt um 12 Machen why not

**2025-10-30 10:31:56** - Julia:
> ich bin wieder in teaaaaams!

**2025-10-30 10:32:23** - Julia:
> Weiß leider nicht was Hanna meint mit Leica Fotos sind quer..?
wollte eben ein update zu den stories geben

**2025-10-30 10:34:46** - Julia H.:
> whoooop, hab das gerade in Asana gepackt. Gestern war wieder diese Leica Foto Experience mit 6 Teilnehmern und das sind deren Fotos. Sollen wir in ein Carousel packen für heute

**2025-10-30 10:35:24** - Julia:
> ah okay!

**2025-10-30 10:35:45** - Julia H.:
> Ich glaube wir haben das schon mal gemacht, let me check

**2025-10-30 10:36:47** - Julia H.:
> 

**2025-10-30 10:36:50** - Julia H.:
> Daran kannst du dich anlehnen

**2025-10-30 10:37:05** - Julia H.:
> Soll wie der Post Lieblingsfoto sein.

**2025-10-30 10:37:20** - Julia:
> alright

**2025-10-30 12:00:45** - Julia H.:
> Gib mir noch 5 min pls

**2025-10-30 12:00:52** - Julia:
> klaro

**2025-10-30 13:06:33** - Julia:
> done

**2025-10-30 13:06:43** - Julia:
> also IG Insights sind bei mir jetzt WIEDER andere

**2025-10-30 13:06:53** - Julia H.:
> LOL

**2025-10-30 13:07:12** - Julia:
> deswegen, ob das stimmt i daut it

**2025-10-30 13:13:47** - Julia H.:
> Also wirklich wild

**2025-10-30 13:25:13** - Julia:
> Falls du die Rundgang Carousels schon mal auf Sprinklr laden willst, die sind ja fertig
<https://drive.google.com/drive/folders/1Mzzke_INP34Rxgt-Z-Wwnbx05ZHZOr5Y|Poster Gallery>
<https://drive.google.com/drive/folders/1uXMnS32dr8KAL8s9eNeNA_O72G4h0Hri|Café>

Bei den Stories warte ich noch auf Hanna's Antwort in Teams

**2025-10-30 14:11:16** - Julia:
> ich hab dir jetzt jeden Content den ich erstellt hab geschickt in asana. Wenn du heute zu busy bist, kann ich das morgen/ später auch gerne auf sprinklr stellen, garkein Problem :slightly_smiling_face: nur für das Übergabe Sheet kann ich das ja nicht machen

**2025-10-30 14:12:35** - Julia:
> voll die gute antwort, danke :smile:

**2025-10-30 14:13:56** - Julia H.:
> Super danke!! Stell ich ein

**2025-10-30 14:14:44** - Julia H.:
> Ich denke ich krieg das alles noch hin.

**2025-10-30 14:15:00** - Julia H.:
> LOL so dumm

**2025-10-30 14:16:48** - Julia:
> ja sag einfach bescheid!

**2025-10-31 09:06:29** - Julia:
> Huhuu, falls du kurz da bist: was soll ich zu Flo sagen bezüglich Reporting? Was hattest du Hanna jetzt kommuniziert? Sonst würde ich einfach sagen "ne haben wir noch nicht" – weil das ist ja eh ein Witz, was wir da reingepackt haben.

**2025-10-31 12:19:54** - Julia H.:
> Ja vollkommen fine für mich. Hab mit Hanna darüber nicht mehr gesprochen

**2025-10-31 12:20:14** - Julia H.:
> Charyly hat mich gerade gefragt, ob wir das Bild vom Hexenvideo vom Gipfeltreffen haben?

**2025-10-31 12:20:38** - Julia H.:
> Kannst du ihr dazu eine Info geben später?

**2025-10-31 12:28:09** - Julia:
> das Blurry?

**2025-10-31 12:28:24** - Julia H.:
> yes

**2025-10-31 12:28:38** - Julia:
> kann ich ihr schicken, ja. aber liegt ja auf picdrop?

**2025-10-31 12:32:54** - Julia:
> done

**2025-10-31 12:34:11** - Julia:
> warum schreibt sie dir da, die weiß doch, dass du off bist. ah nervig

**2025-10-31 12:49:56** - Julia H.:
> weil ich kurz wegen CM online war

**2025-10-31 12:50:09** - Julia:
> :face_with_peeking_eye:

**2025-10-31 12:51:06** - Julia H.:
> last day :heart:

**2025-10-31 12:51:11** - Julia:
> yeeees

**2025-11-10 09:56:17** - Julia:
> <https://docs.google.com/document/d/1PbEVpTroRccqnCrtHg53hsJWhv4qibQldX2fX5jIRyY/edit?usp=sharing>

**2025-11-10 10:07:02** - Julia:
> <https://applink.larksuite.com/client/chat/chatter/add_by_link?link_token=991o284b-52af-4104-a9d1-8582ecj085qd>

**2025-11-10 10:27:56** - Julia:
> Hier wäre die Agenda für den Hisense-Termin.

*AGENDA HISENSE – Jour Fixe (heute)*
1. *Vorstellung neues BCC-Team*
    ◦ Einführung *Julia, Juli und Mert*
    ◦ Rollen &amp; Verantwortlichkeiten
    ◦ Ziel: volle Fokussierung auf Hisense &amp; effizientere Content-Prozesse
1. *Shoots 2025 – Planung &amp; Timeline*
• *BCC stellt heute* die *Timeline mit konkreten Terminen* für:
        ▪︎ 2x Shooting *Gorenje (Produktverfügbarkeit in München klären)*
        ▪︎ 2x Shootings *Hisense (Produktverfügbarkeit in München klären)*
        ▪︎ 1x Shooting mit *Pascal Hens (18.11., Berlin)*
        ▪︎ *1x Shooting Laser Studios (falls gewünscht 10.12. in München)*
1. *Konzept &amp; Highlight-Produkte*
    ◦ BCC stellt erste Konzepte für die Highlight-Ideen &amp; Shootings vor.
    ◦ *Nächster Schritt: Freigabe durch Hisense am 12.11.*
• Fokus-Produkte:
        ▪︎ *Hisense:* <http://RGB.TV|RGB.TV>, Crossdoor with Ice Maker, 5s Washing Machine, Microwave (Inverter without plate)

    ◦ *Gorenje:* Pizza Oven, Dishwasher
1. *Next Steps &amp; Verantwortlichkeiten*
    ◦ *Hisense:* Feedback zu Produktverfügbarkeit in München &amp; Freigabe der Shootings
    ◦ *Gemeinsam:* Feinschliff Shootingplanung + Vorbereitung Berlin-Shoot
    ◦ Hisense schickt BCC eine Standortübersicht der Laser Studios (07.11.)


**2025-11-10 10:47:06** - Julia:
> habs ihr geschickt

**2025-11-10 10:47:54** - Julia H.:
> Thank you Juli

**2025-11-10 10:55:55** - Julia H.:
> Das hier sind ja 2 mal die gleichen produktionen, das macht ja dann viel mehr Sinn das direkt hinter einander zu shooten, damit man alles an Setup so lassen kann oder?

**2025-11-10 11:31:27** - Julia H.:
> *FYI, hab gerade bei der Suche herausgefunden, dass die EHF Europe*  in Dänemark, Schweden, Norwegen stattfindet.
Vielleicht macht man dazu einen Bezug? Die Köttbullar aus dem Kühli werfen und was deutsches rein oder so? haha

**2025-11-10 11:44:44** - Julia:
> ja die Daten sind von uns – gerade Antwort von Jana bekommen moment

**2025-11-10 11:45:02** - Julia:
> der Produkionsplan für mich so auch noch keinen Sinn

**2025-11-10 11:45:54** - Julia:
> Was ist die EHF? :face_with_peeking_eye:

**2025-11-10 11:46:33** - Julia H.:
> European Handball Federation

**2025-11-10 11:46:40** - Julia:
> Ich hab tatsächlich noch ein paar Fragen, die mir von letzter Woche noch fehlen:
• wie ist der Kommunikationsstand mit dem Kunden gerade --&gt; die letzte Mail von Ray am 5.11. noch aktuell? Wie sieht es mit Produktverfügbarkeiten aus? Falls nicht, könntest du uns bitte alle Mails weiterleiten :slightly_smiling_face:
• die Termine der Produktionen sind noch uns festgelegt oder woher kommen diese? Final und mit Kunden abgestimmt?
• Wie gehts weiter mit dem Content Upload? Wo liegen diese Dateien und wer postet? Die Ordner im Drive sind teilweise leer
• CI Unterlagen fehlen uns noch
• Reportings sind teilweise noch offen, finalisiert ihr diese noch bis Oktober?
• Ist Marvin wieder da? Bezüglich CM
• Wird der Pascal Hens Content auch auf TikTok geposted oder ist das komplett getrennt?
• noch eine detaillierte Frage zum Produktionsbudget: wie ist hier die Abstimmung, also sind wir komplett frei in der Aufteilung oder spricht der Kunde da mit? Gibt der Kunde alles frei oder haben wir freie Hand?
*Jana Antworten:*
• Ich schicke dir noch mal alles weiter
• Sind von uns, Feedback von Kunden steht noch aus, ob tiny House und Produkte verfügbar sind
• Content Upload ist ja im Editorial Plan, da kannst du es dann hochladen.
• CI und CM spreche ich gleich mit Marvin
• Pascal Hens wird mit uns gedreht dementsprechend auch für TikTok
• Produktionsbudget bitte mit Flo klaren


*Meine erneuten Rückfragen:*
Okay danke dir!
• du meinst über <http://Frame.io|Frame.io> downloaden? Bis wohin lädst du denn hoch oder ab wann sollen wir? Das müssten wir ja festlegen
• Pascal Hens: was heißt genau "wird mit uns gedreht"? Wir sollen ja nur noch eine Content Idee liefern – läuft die Kampagne nicht über die Instagram Agentur?
• Budget: yes, aber hast du in der Vergangenheit die anfallenden Kosten mit dem Kunden besprochen also zB Kosten für Statisten oder gabs einfach das Budget und macht was ihr wollt damit?


**2025-11-10 11:46:41** - Julia H.:
> das ist das wieso Pascal Hens gebucht wurde

**2025-11-10 11:48:08** - Julia H.:
> Wären jetzt genau meine gleichen Fragen gewesen

**2025-11-10 11:48:16** - Julia H.:
> Danke Juli und sooo sorry, dass du das übernehmen musst

**2025-11-10 11:49:17** - Julia H.:
> Schau mal, das hat Hanna gerade geschrieben kannst du mal schauen pls?

**2025-11-10 11:52:42** - Julia:
> Ach quatsch

**2025-11-10 11:53:14** - Julia:
> Shit, ich hab da mit dem neuen Benutzer auch keinen Zugriff  :melting_face: muss ich mich nochmal einloggen, dauert kurz

**2025-11-10 11:55:59** - Julia:
> :joy: wow okay

**2025-11-10 11:56:05** - Julia:
> ja verstehe, gute Idee!

**2025-11-10 11:59:29** - Julia:
> die 2 Anfragen sind freigegeben

**2025-11-10 12:03:41** - Julia H.:
> Super danke dir!

**2025-11-10 12:06:59** - Julia:
> Reportings hab ich nochmal nachgehackt

**2025-11-10 12:07:46** - Julia:
> also es gibt wirklich nicht viel was mich auf die Palme bringt, aber halbherzige Antworten/ Infos machen mich wortwörtlich zum Stier :triangular_flag_on_post:

**2025-11-10 12:20:25** - Julia H.:
> Ich verstehs!! Finds auch unmöglich und sooo unprofessionell

**2025-11-10 12:22:43** - Julia:
> 

**2025-11-10 12:34:32** - Julia H.:
> Ahh super okay mach ich 

**2025-11-10 12:34:35** - Julia H.:
> Danke Juli 

**2025-11-10 13:34:08** - Julia H.:
> Ich mach jetzt mal ne größere Pause, gibt ja eh eigentlich nichts zu tun so richtig odder?

**2025-11-10 13:35:20** - Julia:
> nee, hab eh noch keine antworten. bin an dem Pascal ding dran

**2025-11-10 13:35:23** - Julia:
> happy break :slightly_smiling_face:

**2025-11-10 13:38:10** - Julia H.:
> dankeee

**2025-11-11 10:30:35** - Julia:
> Lark:
Julia Hopper hat Sie zu einer Gruppe in Lark eingeladen, klicken Sie auf <https://applink.larksuite.com/client/chat/chatter/add_by_link?link_token=befu6419-b9b0-4875-90e2-ab1326jcbal6>, um beizutreten！

**2025-11-11 10:36:37** - Julia:
> Jana Kordt invited you to a group on Lark, click <https://applink.larksuite.com/client/chat/chatter/add_by_link?link_token=991o284b-52af-4104-a9d1-8582ecj085qd> to join!

**2025-11-11 11:32:39** - Julia:
> ahh ich bin noch nicht in der Roadmap in Asana :slightly_smiling_face: magst du mich da noch hinzufügen?

**2025-11-11 11:33:51** - Julia H.:
> Done!

**2025-11-11 11:38:24** - Julia:
> also jetzt wollte mir Jana blöd kommen

**2025-11-11 11:38:35** - Julia:
> wir sollen uns doch bitte mit dir abstimmen

**2025-11-11 11:38:45** - Julia:
> weil du ja jetzt schon mit Marvin parallel alles abstimmst

**2025-11-11 11:38:53** - Julia:
> :smile:

**2025-11-11 11:56:52** - Julia H.:
> Ich hab ihn nach CM und der CI gefragt da gibt’s Nix zu abstimmen

**2025-11-11 11:57:04** - Julia H.:
> Lass dir bitte Nix gefallen

**2025-11-11 17:02:52** - Julia:
> weißt du was dieser Slash Termin morgen ist? wahrscheinlich die IG Agentur?

**2025-11-11 17:04:41** - Julia H.:
> Ja genau so hab ich’s verstanden 

**2025-11-11 17:04:59** - Julia H.:
> Ich denke jetzt mal auch dass Jana bei den Terminen noch dabei ist. :face_vomiting:

**2025-11-11 18:17:59** - Julia:
> echt meinst du? oh man ey

**2025-11-11 18:18:13** - Julia:
> hätte man auch echt alles einfach letzte Woche machen können, versteh ich nicht

**2025-11-11 18:23:44** - Julia H.:
> Ich weiß nicht, aber ich glaub es ist Absicht. Sie macht es sich damit ja selbst unnötig kompliziert 

**2025-11-12 10:12:35** - Julia:
> alsooooo

**2025-11-12 10:12:43** - Julia:
> sie ist beim termin heute schon mal nicht dabei

**2025-11-12 10:13:00** - Julia H.:
> OMG thank gooooood

**2025-11-12 10:13:05** - Julia H.:
> Danke Juli

**2025-11-12 10:13:07** - Julia:
> :fast_parrot:

**2025-11-12 10:25:11** - Julia H.:
> Du kannst dir nicht vorstellen wie erleichtert ich bin, die letzten beiden Tage waren psychisch schon hart für mich

**2025-11-12 10:25:22** - Julia:
> ich glaubs dir

**2025-11-12 10:25:31** - Julia:
> hab ganz beifläufig gefragt :slightly_smiling_face:

**2025-11-12 10:27:06** - Julia H.:
> :heart_eyes::heart_eyes::heart_eyes:

**2025-11-12 10:28:56** - Julia:
> auch so krass, dass manche Menschen echt so einen Stress bei einem auslösen können. also ich kenn das. ganz unangenehm

**2025-11-12 10:49:43** - Julia H.:
> Ja total, nervt mich auch dass es mich so tangiert muss ich sagen, aber ist nächste Woche auch wieder vorbei 

**2025-11-12 13:24:34** - Julia H.:
> Mir tut das sooo leid, dass du dich jetzt mit dem scheiss rumschlagen musst

**2025-11-12 13:25:11** - Julia H.:
> Aber honestly ich hätte nicht unbedingt gedacht, dass ihre arbeit so schlecht ist. unabhängig davon was ich menschlich von ihr halte, hab ich zumindest professionell mehr erwartet

**2025-11-12 13:26:15** - Julia:
> ach du alles gut. ich kanns einfach nur nicht verstehen, wie man so arbeiten kann und vorallem aber auch dauernd so tun, als wäre alles super und erledigt

**2025-11-12 13:26:33** - Julia:
> jaaaa glaub ich dir

**2025-11-12 13:27:46** - Julia:
> also ich könnte dir echt den ganzen chat schicken, sie antwortet mit einem kurzen satz. thats it. da ist weder meine frage beantwortet, noch irgendwas

**2025-11-12 13:28:30** - Julia H.:
> Ja schrecklich.... Irgendwie die Work Version von Gaslighting :stuck_out_tongue:

**2025-11-12 13:29:26** - Julia:
> :joy:

**2025-11-13 09:31:40** - Julia H.:
> OMG sie ist im Meeting

**2025-11-13 09:32:18** - Julia H.:
> Kommst du?

**2025-11-13 09:32:39** - Julia:
> NEIN wieso???

**2025-11-13 09:33:16** - Julia:
> die kotzt mich so an, kackt mich einfach in der gruppe mit flo an. aber arbeitet selbst nichts

**2025-11-13 09:41:20** - Julia H.:
> same!!! Auch ohne Cam finde ich immer maximal unprofessionell

**2025-11-13 09:41:37** - Julia:
> ja vorallem wir wissen ja wieso

**2025-11-13 09:43:46** - Julia H.:
> liegt wahrscheinlich noch im bett

**2025-11-13 09:44:30** - Julia:
> :rage:

**2025-11-13 09:45:05** - Julia H.:
> macht mich so aggroooooo

**2025-11-13 09:45:11** - Julia H.:
> labert nur scheiße

**2025-11-13 09:48:11** - Julia H.:
> Der Ton schon allein

**2025-11-13 09:48:21** - Julia:
> ja alles so ätzend

**2025-11-13 16:36:09** - Julia:
> Wenn du morgen off bist, soll ich dann antworten, falls Laureen/ Ray antworten auf unsere Fragen oder bis Montag liegen lassen?

**2025-11-13 16:38:07** - Julia H.:
> Wir können ja schreiben morgen einfach und schauen wie dringend es ist? 

**2025-11-13 16:38:16** - Julia:
> okay :slightly_smiling_face:

**2025-11-18 16:02:03** - Julia:
> alles gut soweit?

**2025-11-18 16:02:10** - Julia H.:
> Nope.

**2025-11-18 16:02:28** - Julia H.:
> So wie die Nachricht klingt seitens Flo im Chat soll wohl mehr Zusammenarbeit stattfinden, aber lets see

**2025-11-18 16:02:31** - Julia H.:
> hab herzrasen

**2025-11-18 16:02:40** - Julia:
> ja, hab ich mir auch gedacht

**2025-11-18 16:02:44** - Julia:
> :melting_face:

**2025-11-18 16:02:48** - Julia H.:
> Mach ich nicht

**2025-11-18 16:02:54** - Julia:
> ne

**2025-11-18 16:02:57** - Julia:
> weiß er ja auch

**2025-11-18 16:04:08** - Julia H.:
> jaaa not sure

**2025-11-18 16:07:16** - Julia H.:
> mir ist schlecht

**2025-11-18 16:07:18** - Julia H.:
> :disappointed:

**2025-11-18 16:07:30** - Julia:
> ich weiß.. :face_with_spiral_eyes:

**2025-11-18 16:08:55** - Julia:
> also ich versteh bis heute nicht wieso man in so einer menschlichen beziehung beim gleichen arbeitgeber startet

**2025-11-18 16:09:10** - Julia H.:
> ich auch nicht. kein scherz ich zitter so krass

**2025-11-18 16:09:26** - Julia:
> willst du lieber raus?

**2025-11-18 16:09:42** - Julia H.:
> geht schon, ich versuch nicht hinzuschauen

**2025-11-18 16:09:50** - Julia:
> kann ja sagen, dein internet war weg oder so

**2025-11-18 16:09:53** - Julia:
> okay

**2025-11-18 16:09:55** - Julia H.:
> haha

**2025-11-18 16:10:36** - Julia H.:
> Ja also ich bin gespannt, wie es weitergeht...

**2025-11-18 16:11:26** - Julia H.:
> klingt nach viel

**2025-11-18 16:12:14** - Julia:
> voll. Flo meinte vorhin BitPanda ist schon mega happy jetzt im ersten Schritt – also kann mir gut vorstellen, dass die auch noch dazu kommen

**2025-11-18 16:12:24** - Julia H.:
> crazy

**2025-11-18 16:18:39** - Julia H.:
> Problem 1: Jana

**2025-11-18 16:18:54** - Julia:
> ich wollte es gerade sagen haha

**2025-11-18 16:19:00** - Julia H.:
> lol

**2025-11-18 16:19:08** - Julia H.:
> versteh den sinn des channels null

**2025-11-18 16:19:16** - Julia:
> ich auch nicht

**2025-11-18 16:19:23** - Julia:
> also es ist ein Kummerkasten ohne Kummer?

**2025-11-18 16:19:25** - Julia H.:
> wenn ich schon ne lösung parat hab, wieso muss das in den cahnnel

**2025-11-18 16:20:40** - Julia:
> ich glaube, das hat er extra schon geschrieben

**2025-11-18 16:20:46** - Julia:
> PM oder CL

**2025-11-18 16:20:48** - Julia:
> genau

**2025-11-18 16:20:59** - Julia H.:
> Yep... gut dass ich freitags off bin

**2025-11-18 16:21:08** - Julia H.:
> ich will auch nicht, dass jana einblicke hat in meine projekte

**2025-11-18 16:21:24** - Julia:
> ja voll

**2025-11-18 16:21:31** - Julia H.:
> ich hab keine ahnung, wie ich ihm das klarmachen soll, damit er das kapiert und es nicht unprofessionell rüberkommt

**2025-11-18 16:21:45** - Julia:
> sie kackt Mert und mich auch fast täglich gerade an wegen Hisense noch. super unnötig

**2025-11-18 16:22:20** - Julia:
> ich glaube bei ihm, muss man das echt oft sagen muss

**2025-11-18 16:22:29** - Julia H.:
> wirklich??? wegen was denn

**2025-11-18 16:23:10** - Julia H.:
> ohnehin so ein stimmungsbarometer für den client so unnötig, was soll das bringen

**2025-11-18 16:27:26** - Julia:
> weil das Video nur 70 views hat und wird es nicht gepusht haben. hab ihr dann natürlich gesagt, wir haben jetzt mit Flo gesprochen und alles geklärt
Ne reicht ihr nicht, sie meinte dann: ja aber das Video können wir nicht mit 700 Views stehen lassen!??!?!

Ja sorry, dann mach besseren Content

**2025-11-18 16:27:30** - Julia:
> :smile:

**2025-11-18 16:27:48** - Julia:
> ja ist ja eigentlich nur für die chefs

**2025-11-18 16:28:09** - Julia H.:
> Soll erstmal lernen wie man normal kommuniziert

**2025-11-18 16:28:56** - Julia H.:
> professional as ususal

**2025-11-18 16:29:18** - Julia:
> so, geh halt kurz – nobody will notice

**2025-11-18 17:04:09** - Julia:
> glaub wir bleiben doch in kleinen teams

**2025-11-18 17:04:29** - Julia:
> und ich kann ja freitags oder auch generell das immer übernehmen, ist ja garkein problem

**2025-11-18 17:07:31** - Julia H.:
> Ja ich schreib Flo nochmal heute 

**2025-11-18 17:07:35** - Julia H.:
> Danke für deine Support 

**2025-11-18 17:08:05** - Julia:
> Okay

**2025-11-18 17:08:09** - Julia:
> ja ist doch klar

**2025-11-21 13:32:10** - Julia:
> Kosten Heimkinoraum :melting_face:

**2025-11-21 13:35:05** - Julia H.:
> War zu erwarten :stuck_out_tongue:

**2025-11-24 12:11:50** - Julia:
> also

**2025-11-24 12:20:50** - Julia H.:
> :melting_face:

**2025-11-27 12:57:04** - Julia H.:
> Hello, sorry, ich hab grad irgendwie aus Versehen das Meeting abgelehnt statt angenommen

**2025-11-27 12:57:11** - Julia H.:
> :sweat_smile:

**2025-11-27 14:50:01** - Julia H.:
> die ist immer so angeknipst ey

**2025-11-27 14:50:30** - Julia:
> JA :smile:

**2025-11-27 14:52:35** - Julia H.:
> jesus

**2025-11-27 14:52:38** - Julia H.:
> anstrengend

**2025-11-27 14:52:43** - Julia H.:
> wie kann man so schnell reden auch

**2025-11-27 14:53:25** - Julia H.:
> die können sich doch die videos aus dem plan direkt runterladen oder?

**2025-11-27 14:59:41** - Julia:
> ja genau, aber da muss mert nochmal sagen, ob er die finalen schon abgelegt hat mit Emoji Austausch. ich frag

**2025-11-27 17:16:54** - Julia:
> bevor ich es vergesse:

**2025-11-27 17:17:48** - Julia:
> 

**2025-11-27 17:19:27** - Julia H.:
> Jaa klaroo!! Mach ich gerne ich schreib ihr

**2025-11-28 10:08:24** - Julia:
> 

**2025-11-28 11:05:59** - Julia H.:
> 

**2025-11-28 12:00:47** - Julia:
> jap, männer i mean.. :smile:

**2025-11-28 12:02:18** - Julia:
> 

**2025-11-28 13:11:47** - Julia H.:
> Ich finde da kannst du auf jeden Fall ne Grenze setzen mit Whatsapp... Und wir kennen das ja alle, mal nervt das alles mehr, mal weniger. War ja auch ne harte Woche bei dir

**2025-11-28 13:12:23** - Julia H.:
> Also mit Bitpanda bin ich gespannt, wenn dann Lidl und Estee Lauder auch noch kommt, wer soll das alles machen? Die sollen mal gleichzeitig hiren wenn sie pitchen :stuck_out_tongue:

**2025-11-28 13:12:41** - Julia H.:
> Hab ihnen gestern aber die PM Stellenausschreibung mal angepasst, hoffe das passiert bald mal

**2025-11-28 13:20:44** - Julia:
> ja total

**2025-11-28 13:21:10** - Julia:
> das frag ich mich auch. Team MAC :point_up_2::point_up_2::point_up_2::point_up_2::point_up_2::point_up_2::point_up_2::point_up_2:

**2025-11-28 13:21:22** - Julia:
> ahh wollen sie da noch ausschreiben? also müssen sie ja

**2025-11-28 13:25:35** - Julia H.:
> Yes genau, also eine Midlevel PM in Festanstellung

**2025-11-28 13:42:05** - Julia:
> uii oke

**2025-12-01 09:33:59** - Julia:
> Hallo :blush:hättest du schon paar Minuten vor 10 Zeit? 

**2025-12-01 09:51:16** - Julia H.:
> Klaro!!

**2025-12-01 09:51:18** - Julia H.:
> Moment

**2025-12-01 09:53:22** - Julia:
> okeee

**2025-12-01 09:54:01** - Julia H.:
> bin im meet

**2025-12-01 12:43:17** - Julia:
> so krass, er versteht einfach nicht, dass weder Marie noch ich Ahnung davon haben. Oder will es nicht verstehen

**2025-12-01 12:43:25** - Julia:
> Genau wie damals bei den Reportings

**2025-12-01 12:44:10** - Julia H.:
> No way

**2025-12-01 12:44:38** - Julia:
> "einfach" ja ne, für uns nicht einfach

**2025-12-01 12:44:40** - Julia:
> ich kotze :smile:

**2025-12-01 12:44:41** - Julia:
> NAJA

**2025-12-01 12:45:16** - Julia H.:
> .... uff

**2025-12-01 12:45:45** - Julia H.:
> kurz andere Frage: hatten wir von marinas küche fotos eigentlich

**2025-12-01 12:46:32** - Julia:
> schickt sie mir heute

**2025-12-01 12:46:39** - Julia H.:
> ok cool

**2025-12-01 12:48:54** - Julia:
> bisher nur das – aber die anrichte ist quasi links

**2025-12-01 12:50:58** - Julia:
> also es ist super hell, komplett Motel a Miio ausgestattet, beige, cosy

**2025-12-01 12:52:10** - Julia H.:
> Okay nice danke!!

**2025-12-01 12:52:25** - Julia H.:
> Überleg gerade eher praktisch wegen platz, wo filmen und wo vielleicht parallel vorbereiten

**2025-12-01 12:52:51** - Julia H.:
> mert und ich haben ideen und rezepte gesammelt, aber logistisch wird das ein nightmare glaub ich.

**2025-12-01 12:53:55** - Julia:
> ja verstehe. also der tisch ist gegenüber der anrichte und neben dem ofen ist noch so eine anrichte – da kann man easy vorbereiten. ansonsten haben sie einen 2m langen Esstisch im Wohnzimmer, was wir 100% auch benutzen dürfen

**2025-12-01 12:54:21** - Julia:
> mega! aber ja das glaub ich wirklich auch. denke bei dem aufwand ist es wirklich cool, wenn wir mit leuten drehen die wir kennen

**2025-12-01 12:57:06** - Julia H.:
> Denke ich auch, aber ich denke wir brauchen zusätzlich eine erfahrene Person, die viel koch content macht. Sprich zwei Creator*innen. Vielleicht Merts Mitbewohnerin und noch jemand der Koch/back affin ist

**2025-12-02 08:55:37** - Julia:
> Gestern wurde der Peak erreicht

**2025-12-02 08:55:43** - Julia:
> Whatsapp um 23.30

**2025-12-02 08:55:48** - Julia:
> :joy:

**2025-12-02 08:56:25** - Julia H.:
> Nooooo Juliiiii

**2025-12-02 08:56:28** - Julia H.:
> das geht nicht

**2025-12-02 08:56:31** - Julia:
> ja

**2025-12-02 08:56:44** - Julia H.:
> Soll ich dir helfen ihm eine nachricht zu formulieren?

**2025-12-02 08:56:49** - Julia H.:
> oder machst du das im meeting mit ihm?

**2025-12-02 08:57:40** - Julia:
> ja ich sags im meeting. will nur die 2 pitches von heute und morgen abwarten, damit die stimmung etwas entspannter ist

**2025-12-02 08:57:43** - Julia:
> danke :heart_hands:

**2025-12-02 08:58:16** - Julia H.:
> ja das macht sinn

**2025-12-02 11:01:30** - Julia H.:
> Bist du auch im warteraum?

**2025-12-02 11:01:36** - Julia:
> jaa

**2025-12-02 11:02:51** - Julia H.:
> Wenn ich gleich wieder teile kannst du mitschreiben pls?

**2025-12-02 11:02:58** - Julia:
> ja klar

**2025-12-02 11:09:28** - Julia:
> also sie wollen Tiny House

**2025-12-02 11:09:35** - Julia H.:
> lets see

**2025-12-02 11:36:28** - Julia:
> einfach süß

**2025-12-02 11:37:32** - Julia H.:
> jaaa voll

**2025-12-03 15:54:24** - Julia:
> ah jetzt kam Teams - dann springen wir dort rein oder

**2025-12-03 15:57:22** - Julia:
> ah ne sie haben google zugesagt

**2025-12-03 15:59:31** - Julia H.:
> Ahhh okeee, ich hab noch keinen für Teams bekommen glaub ich. sonst schick mir einfach den link

**2025-12-03 15:59:45** - Julia:
> wurd wieder gelöscht :smile:

**2025-12-03 15:59:52** - Julia:
> <http://meet.google.com/mfw-ahfi-ysx|meet.google.com/mfw-ahfi-ysx>

**2025-12-03 15:59:59** - Julia H.:
> LOL

**2025-12-03 16:15:52** - Julia:
> wieso spricht Conny eigentlich nicht mal mit uns?

**2025-12-03 16:16:03** - Julia H.:
> ich hab keine ahnung

**2025-12-03 16:26:18** - Julia:
> du schreibst wahrscheinlich eine nachricht/ mail oder?

**2025-12-03 16:26:25** - Julia H.:
> Yes genau!!

**2025-12-03 16:26:31** - Julia H.:
> Willst du einmal kurz drüberlesen?

**2025-12-03 16:26:46** - Julia:
> klar gerne

**2025-12-03 16:26:47** - Julia H.:
> hier kommen wie gewünscht die beiden *Kosten-Aufstellungen* für die Shootings kommende Woche. Lasst uns gerne morgen im Termin gemeinsam drüber schauen und alles final abstimmen.
Da die Logistik und Produktverfügbarkeiten im Dezember nach wie vor herausfordernd sind, würden wir die für dieses Jahr erwarteten Shooting-Kosten gerne bereits einplanen, die Umsetzung selbst aber gebündelt mit mehreren Produkten im Januar bzw. spätestens im Frühjahr realisieren. Sprich Flo wird euch noch wie gewünscht im *Dezember die Rechnung* hierzu stellen.
Außerdem haben wir heute nochmal mit Rückenwind wegen des *Tiny Houses* gesprochen. Conny und Flo hatten dazu ja bereits kurz telefoniert. Tatsächlich handelt es sich hier um ein Missverständnis: Die „Halle“ ist im Angebot von Rückenwind nicht enthalten, es ist lediglich ein weißes Zelt, das über das Tiny House gespannt werden kann. Für ein Winter-Shooting ist das nicht ideal: Regen oder Schnee wären ein Risiko, es wäre sehr kalt, und ein vollständiges Licht-Setup von außen müsste zusätzlich gebucht werden. Wir würden daher davon abraten, unter diesen Bedingungen zu shooten, und empfehlen stattdessen, das Shooting im Frühjahr ohne Zelt/Halle durchzuführen, das wäre deutlich sinnvoller und kostensparender.
*Gute News* aber: Rückenwind hat uns informiert, dass sie aktuell ohnehin prüfen, das Tiny House ab Januar dauerhaft in oder um München zu lagern, idealerweise so, dass dort auch direkt produziert werden könnte. Das wäre für ein Shooting natürlich perfekt, da wir uns damit unnötige Zusatzkosten sparen und deutlich flexibler planen könnten.
Wir müssen Rückenwind sowie dem Logistiker hierzu bitte möglichst morgen eine finale Info geben. Denkt ihr das ist machbar?

Viele liebe Grüße,
Julia

**2025-12-03 16:27:42** - Julia:
> Ja mega!

**2025-12-03 16:28:07** - Julia H.:
> Ist raus-

**2025-12-03 16:28:13** - Julia:
> ich denke nicht, dass es machbar ist von ihrer seite aber well :smile:

**2025-12-03 16:28:27** - Julia H.:
> hahaha

**2025-12-04 10:58:25** - Julia:
> 

**2025-12-04 10:58:29** - Julia:
> ich bin hier:
<https://docs.google.com/presentation/d/1hCn3KbyAlmOzdpS0aAdcerl52U-l4EYm/edit?slide=id.g3a92d12bed8_1_36#slide=id.g3a92d12bed8_1_36>

**2025-12-04 13:16:23** - Julia H.:
> sorry irgendwie hab ich deine sprachi übersehen....

**2025-12-04 13:16:30** - Julia H.:
> du hast das ja mittlerweile gefunden oder?

**2025-12-04 13:16:50** - Julia:
> alles gut

**2025-12-04 13:16:53** - Julia H.:
> Ist es okay, wenn ich die Gorenje Skripte mache und du schaust dann drüber?

**2025-12-04 13:16:56** - Julia:
> also ich bin immer noch in der präsi oben drin

**2025-12-04 13:17:28** - Julia:
> ach klar! aber bitte keinen Stress. Ich hab später ja auch noch Zeit

**2025-12-04 13:18:06** - Julia H.:
> Ja easy, wollte heute bisschen früher schluss machen aber bin eh nicht sicher ob das geht. Auch noch mit dem Versicherungsthema

**2025-12-04 13:33:24** - Julia:
> weißt du jetzt, ob die Technik ready im Büro ist?

**2025-12-04 13:33:34** - Julia:
> alles gut, wir haben morgen ja auch noch

**2025-12-04 13:34:53** - Julia:
> also ich

**2025-12-04 13:35:09** - Julia H.:
> ne keine ahnung leider

**2025-12-04 13:36:01** - Julia:
> okay

**2025-12-04 13:47:46** - Julia:
> ich bin jetzt kurz Pause machen!

**2025-12-04 13:56:22** - Julia H.:
> :heart:

**2025-12-04 14:06:22** - Julia H.:
> Ich leg jetzt auch mal ne späte Pause ein

**2025-12-04 14:34:50** - Julia:
> soo bin wieder da und schau mal die Gorenje skripte an oder? da hast du ja eh schon mega viel!

**2025-12-04 14:38:09** - Julia H.:
> hihi ja danke chat gpt

**2025-12-04 14:48:32** - Julia:
> also ich füge jetzt noch Kamera usw. hinzu

**2025-12-04 14:49:33** - Julia:
> Weil das ist was ich auch gestern meinte:
wir haben ja video, bei denen man Sequenzen mit Julia hat (Start der Videos) und dann schneiden wir ja B-Roll rein, während sie weiterspricht. Heißt wir haben ja viele Videos nicht mit anschließendem VoiceOver sondern muss ja währenddessen passieren

**2025-12-04 14:56:49** - Julia H.:
> Ahhh ja very good, das hatte ich vergessen

**2025-12-04 15:03:48** - Julia:
> boah da fällt es mir total schwer, weil ich gefühlt in den videos garnicht mit drin war

**2025-12-04 15:04:10** - Julia:
> ich kümmere mich "kurz" um Ikea und kann dir dann mehr Infos zum Timing geben

**2025-12-04 15:06:36** - Julia H.:
> Okay super

**2025-12-04 15:19:09** - Julia H.:
> SChau mal ich hab den Zeitplan mal grob aufgesetzt: <https://docs.google.com/spreadsheets/d/16asKjHfqeoKWliec5qV0cUYJ82Q59G8aj9Bd5QAsThM/edit?gid=1315625978#gid=1315625978>
Denke man muss mit den komplizierteren Sachen anfangen...

**2025-12-04 15:19:20** - Julia H.:
> Wie siehst du das?

**2025-12-04 15:22:19** - Julia:
> okay

**2025-12-04 15:22:39** - Julia:
> das eine talking head video ist extra, wo siehst du die anderen dann?

**2025-12-04 15:28:46** - Julia H.:
> Wie meinst du?

**2025-12-04 15:29:46** - Julia:
> du hast ja von 17-17.30 Talking Head eingetragen. Aber wir haben ja noch mehr Takling Heads. Sind die dann im jeweiligen Themenblock? Das meinte ich

**2025-12-04 15:30:09** - Julia H.:
> Ja genau, die sind in den Themenblocks drin, wir könnten das hier natürlich in den Block drüber integrieren.

**2025-12-04 15:30:25** - Julia H.:
> done.

**2025-12-04 15:30:36** - Julia H.:
> Ich bin nicht ganz sicher, ob es Sinn macht das noch ausführlicher zu machen

**2025-12-04 15:31:07** - Julia H.:
> Callsheet auf Seite 1 hab ich auch ready.

**2025-12-04 15:31:39** - Julia H.:
> Ich könnte die beiden Sachen schon mal an Julia schicken und ihr dann den Rest morgen mit den fehlenden Skripten?

**2025-12-04 15:32:14** - Julia:
> okay

**2025-12-04 15:32:23** - Julia:
> ja gerne

**2025-12-04 15:36:50** - Julia:
> also Abholung morgen Ikea geht klar – 10-11 Uhr

**2025-12-04 15:40:40** - Julia:
> Hast du noch den Kontakt zu Julia? Oder magst du ihr unsere Kontaktdaten weiterleiten? Ich glaube morgen Nachmittag wird irgendwie super knapp aber idk :smile:

**2025-12-04 15:45:02** - Julia H.:
> Ja hab alles ins call sheet gepackt. sie hat heute leider eine produktion daher kann sie nicht eher

**2025-12-04 15:45:20** - Julia:
> ahh sorry

**2025-12-04 15:45:22** - Julia:
> perfekt danke

**2025-12-04 15:56:44** - Julia H.:
> schau mal hier auch schon exportiert für Marina &amp; David

**2025-12-04 15:58:08** - Julia:
> So IKEA ist mehr oder weniger bestellt. Warte noch auf Flo's pushTan und dann gehts looooos

**2025-12-04 15:58:12** - Julia:
> danke!

**2025-12-04 15:59:04** - Julia:
> hab irgendwie ein komisches Bauchgefühl für morgen mit den Besorgungen

**2025-12-04 15:59:47** - Julia H.:
> Ohnoo, really? was kann ich machen?

**2025-12-04 16:03:18** - Julia:
> ne keine Ahnung, weiß auch nicht warum :smile:

**2025-12-04 16:03:25** - Julia:
> Hat man ja manchmal. Wird schon alles klappen :slightly_smiling_face:

**2025-12-04 16:03:42** - Julia:
> Kann das immer nicht, wenn quasi noch so viel unerledigt ist

**2025-12-04 16:03:57** - Julia H.:
> Also morgen zwischen 12 und 13 uhr passt bei meinem brudi ihr könnt dann auch aufbauen

**2025-12-04 16:04:24** - Julia:
> okay :slightly_smiling_face:

**2025-12-04 16:04:56** - Julia:
> Hat er zufälligerweise Werkzeug? eigentlich braucht man bei Ikea meistens nix anderes außer diesen Schlüssel der eh dabei ist, aber who knows.
Unser ganzes Werkzeug ist in Berlin und Mert hatte nichtmehr geantwortet

**2025-12-04 16:05:52** - Julia H.:
> Ich denk schon

**2025-12-04 16:06:10** - Julia H.:
> Ich bin morgen auch erreichbar für euch.

**2025-12-04 16:06:16** - Julia H.:
> würde jetzt dann mal schluss machen ist das ok?

**2025-12-04 16:06:30** - Julia:
> okay, danke :heart_hands:

**2025-12-04 16:06:33** - Julia:
> ja klar, bitte!

**2025-12-04 16:06:36** - Julia H.:
> :heart:

**2025-12-04 16:06:44** - Julia H.:
> Danke euch und sorry dass ich nicht dabei sein kann

**2025-12-04 16:06:52** - Julia:
> Also nochmal letzter Check: die Lebensmittel Bestellung machst/ hast du gemacht?
Flink bestellen wir dann am Montag morgen

**2025-12-04 16:07:16** - Julia:
> alles guuut. Aber vllt sehen wir uns ja in der Weihnachtszeit dann mal? Content Xmas und soo

**2025-12-04 16:07:38** - Julia:
> Danke für deine Hilfe und bis (hoffentlich nicht) morgen hehe :heart_hands:

**2025-12-04 16:07:55** - Julia H.:
> Lebensmittel kann ich machen, das geht immer erst 2-3 Tage vorher

**2025-12-04 16:08:14** - Julia H.:
> Habs aber mal in den Warenkorb alles gepackt und müsste ich dann samstag/sonntag machen

**2025-12-04 16:08:16** - Julia H.:
> pls remind me

**2025-12-04 16:08:22** - Julia H.:
> aber denke wir hören uns am WE eh

**2025-12-04 16:08:33** - Julia:
> ahh okay, good to know!

**2025-12-04 16:08:43** - Julia H.:
> Auf jeden Fall!!! :heart:

**2025-12-04 16:08:45** - Julia:
> Easy, sonst machen wir das einfach morgen, falls das dann schon geht

**2025-12-04 16:08:52** - Julia:
> happy weekend schon mal :slightly_smiling_face:

**2025-12-04 16:09:21** - Julia H.:
> Ja genau, ich komm morgen auf jeden Fall online und kann bisschen worken

**2025-12-04 16:09:26** - Julia H.:
> Gar kein problem

**2025-12-04 16:09:28** - Julia H.:
> :heart:

**2025-12-04 16:09:35** - Julia H.:
> danke für alles und happy evening

**2025-12-05 09:59:40** - Julia:
> hello! :slightly_smiling_face: könntest du mich noch bei dem Vertrags Dokument freischalten? Dann kann ich das für David und Marina erstellen

**2025-12-05 10:02:50** - Julia H.:
> Hatte ich eigentlich gemacht gestern 

**2025-12-05 10:02:55** - Julia H.:
> Mach ich gleich 

**2025-12-05 16:20:30** - Julia:
> Also irgendwie klappt das leider nicht. Würdest du das sonst am Montag an die beiden schicken? :slightly_smiling_face: dankeee

Ist ja doch nur der Name:
Marina Danner – <mailto:info@marinadanner.de|info@marinadanner.de>
David Heimann – <mailto:Heimann_david@web.de|Heimann_david@web.de>

**2025-12-05 17:11:09** - Julia H.:
> Klaro mach ich!!!

**2025-12-08 10:27:30** - Julia H.:
> Ich mach schnell die Verträge fertig, hatten wir jetzt 800 oder1000 pro person?

**2025-12-08 10:28:59** - Julia:
> 800 hatten wir!

**2025-12-08 10:29:00** - Julia:
> danke dir

**2025-12-08 10:34:53** - Julia H.:
> Done.

**2025-12-11 12:43:31** - Julia:
> 800€, dass wir in der Küche unten drehen??? :smile:

**2025-12-11 12:44:09** - Julia:
> Bodenlos

**2025-12-11 12:53:30** - Julia H.:
> WTF ich komm auch nicht drauf klar. Wir brauchen ja aber auch die Küche nicht exklusiv da ist doch eh nie jemand unten oder? 

**2025-12-15 08:30:26** - Julia H.:
> Good morning my dear, könntest du bitte mal checken, ob du in der uber app auch steuerrechnungen laden kannst?

**2025-12-15 09:39:33** - Julia:
> Hello! :slightly_smiling_face: Hab leider nichts gefunden..

**2025-12-15 09:45:44** - Julia H.:
> easy, lassen wir so

**2025-12-15 14:27:26** - Julia:
> hello! hast du mit Mert schon gesprochen wegen den Videos? sonst kann ich es dir auch kurz "erklären"

**2025-12-15 14:31:46** - Julia H.:
> Ne noch nicht, gerne kurz erklären wenn du magst

**2025-12-15 14:37:46** - Julia:
> klaro

**2025-12-15 14:37:47** - Julia:
> huddle?

**2025-12-15 14:38:08** - Julia H.:
> yess

**2025-12-17 15:31:56** - Julia:
> Sorry, dass ich so doof nochmal fragen muss: die Schriften von HiGo haben wir per Mail Zugang bekommen, oder?

**2025-12-17 15:37:10** - Julia H.:
> Yes, liegen aber auch auf dem Drive: <https://drive.google.com/drive/folders/1bYDDYZ09tMmhmB6T5NOLCgDf-WssT0Qs>

**2025-12-17 16:45:56** - Julia:
> dankeeee

**2025-12-18 10:17:25** - Julia:
> Hello :slightly_smiling_face:

**2025-12-18 10:17:37** - Julia:
> Welches video hat Peru noch bearbeitet? Sehe nur das interactive Video tbh

**2025-12-18 10:17:55** - Julia:
> ah habs!!

**2025-12-18 10:19:26** - Julia H.:
> Yesss okeee 

**2025-12-18 10:19:44** - Julia:
> ui, die haben die Idee ja garnicht verstanden leider

**2025-12-18 10:23:09** - Julia:
> ich glaube Mert ist grad im überlebenskampf mit Premiere :smile: welches Video bräuchten wir denn noch für Gorenje: Hummus und/oder Ginger Wellness oder?
Das Problem ist, ich hab die Dateien noch nicht mal im Drive.. glaub das schaffe ich dann nichtmehr

**2025-12-18 10:25:25** - Julia H.:
> Yes, bzw. könnten wir uns bei Gorenje halt die leichtesten rauspicken

**2025-12-18 10:57:56** - Julia:
> ja glaub alle sind schwer

**2025-12-18 10:58:13** - Julia H.:
> :disappointed:

**2026-01-07 16:39:05** - Julia:
> glaub ich ja nicht:
<https://www.linkedin.com/jobs/view/4344776702>

**2026-01-07 16:41:33** - Julia H.:
> ihhhhhh

**2026-01-08 10:06:47** - Julia:
> Yay Powerdays auch da

**2026-01-08 10:06:51** - Julia:
> :joy:

**2026-01-08 10:14:19** - Julia H.:
> OMG. Volle Breitseite....

**2026-01-08 10:14:24** - Julia H.:
> Ab ins Bett. Wärmflasche

**2026-01-08 10:14:35** - Julia H.:
> Bei uns ist gerade die Heizung und warmes Wasser ausgefallen LOL

**2026-01-08 10:15:32** - Julia:
> Oh neeeein

**2026-01-08 10:15:39** - Julia:
> Boah das ist auch perfektes Timing

**2026-01-08 10:15:51** - Julia:
> hoffe nicht so lange wie in berlin :face_with_spiral_eyes:

**2026-01-08 10:15:59** - Julia H.:
> OMG, neeeeeee

**2026-01-08 10:16:01** - Julia H.:
> hör auf

**2026-01-08 10:16:13** - Julia H.:
> War gestern noch meeting mit sixt? alles ok soweit?

**2026-01-08 10:16:48** - Julia:
> krank, die armen Leute

**2026-01-08 10:16:58** - Julia:
> ne, sie hats 3mal verschoben und jetzt ist es heute Abend

**2026-01-08 10:21:08** - Julia H.:
> wow

**2026-01-08 10:21:10** - Julia H.:
> okay good luck

**2026-01-09 12:45:17** - Julia:
> hatte ein sehr krasses Gespräch mit Marvin :smile: also unsere Einschätzungen oder eindrücke sind alle 10000% richtig

**2026-01-09 12:48:35** - Julia H.:
> OMG zu Flo und so?

**2026-01-09 12:48:40** - Julia:
> ja genau

**2026-01-09 12:48:44** - Julia H.:
> ufff

**2026-01-09 12:48:55** - Julia H.:
> dazu brauch ich mehr infos :stuck_out_tongue:

**2026-01-09 12:52:07** - Julia:
> können gerne jederzeit in huddle

**2026-01-09 12:54:01** - Julia H.:
> Bin grad im auto, also könnte ganz gut via WhatsApp Call

**2026-01-12 09:44:33** - Julia:
> Huhuuu

**2026-01-12 09:44:56** - Julia:
> Also wegen mir könnten wir auch jetzt schon ins Meeting. Bin mir nicht sicher, ob Mert dann heute arbeitet oder nicht

**2026-01-12 09:45:15** - Julia H.:
> Yes, ich hab auch Zeit

**2026-01-12 09:46:09** - Julia:
> okay, ich schenk mir noch schnell meinen Kaffee ein und komme ins meet

**2026-01-12 09:46:23** - Julia H.:
> Yesss

**2026-01-12 09:46:33** - Julia H.:
> Meine Kaffee maschine geht gerade nicht ahhhh

**2026-01-12 09:47:23** - Julia:
> :fearful:

**2026-01-12 10:48:57** - Julia:
> hat sich Flo schon gemeldet?

**2026-01-12 10:56:01** - Julia H.:
> nö, ist auch noch offline

**2026-01-12 10:56:21** - Julia:
> ah, hat mir schon auf whatsapp geschrieben :no_mouth:

**2026-01-12 10:56:22** - Julia:
> lieben wir

**2026-01-12 10:56:33** - Julia H.:
> no way.

**2026-01-12 10:56:34** - Julia H.:
> LOL

**2026-01-12 10:56:41** - Julia:
> doch klar, immer

**2026-01-12 10:56:48** - Julia H.:
> der hat doch slack auf dem handy. was ist daran so schwet

**2026-01-12 10:56:55** - Julia H.:
> eventuell ignorieren

**2026-01-12 10:57:47** - Julia:
> keine Ahnung

**2026-01-12 10:58:05** - Julia:
> Ja, ich ignorier schon so viel :smile: Aber das passt jetzt eh, weil ich ihm jetzt sagen konnte, dass ich gleich sprechen will

**2026-01-12 10:59:23** - Julia H.:
> okay gut

**2026-01-12 11:39:46** - Julia H.:
> sollen wir gleich nochmal sprechen

**2026-01-12 11:39:59** - Julia:
> gerne, bin in 2 min ready. einmal aushusten :smile:

**2026-01-12 11:40:41** - Julia H.:
> easy mach mir noch nen kaffee, maschine geht wieder

**2026-01-12 11:43:16** - Julia:
> yay!

**2026-01-12 11:43:26** - Julia:
> bin im meeting

**2026-01-12 12:32:04** - Julia:
> okay, konnte nichts teasern. war ein sehr unangenehmes gespräch

**2026-01-12 12:35:53** - Julia H.:
> oh noooo

**2026-01-12 12:36:02** - Julia H.:
> are you okay?

**2026-01-12 12:37:27** - Julia:
> Ja

**2026-01-12 12:37:37** - Julia:
> wie gut, dass es sowas wie probezeit gibt

**2026-01-12 12:37:46** - Julia H.:
> wie seid ihr verblieben?

**2026-01-12 12:37:56** - Julia:
> ich solls trotzdem machen

**2026-01-12 12:38:01** - Julia H.:
> Also wirst du gehen?

**2026-01-12 12:38:05** - Julia H.:
> wow

**2026-01-12 12:38:10** - Julia:
> ne hab ich jetzt nicht gesagt

**2026-01-12 12:49:17** - Julia:
> 

**2026-01-12 13:08:27** - Julia H.:
> 

**2026-01-12 14:45:04** - Julia:
> vogelwild alles...

**2026-01-12 14:45:15** - Julia:
> Hat er sich schon bei dir zurück gemeldet?

**2026-01-12 14:58:55** - Julia H.:
> Nope... Noch nicht

**2026-01-12 15:00:02** - Julia H.:
> ultra weird alles

**2026-01-12 15:04:37** - Julia:
> ja. Also heute hat mir auf jeden Fall gezeigt, dass meine Zeit hier noch begrenzter ist als ich dachte :smiling_face_with_tear: 

**2026-01-12 15:23:00** - Julia H.:
> :scream::scream::scream:

**2026-01-12 15:26:18** - Julia H.:
> Ja total verständlich, ich hab mich auch die komplette letzte Woche um andere Aufträge bemüht und mal nach Jobs geschaut. Aber das war halt auch katastrophal.

**2026-01-12 15:45:29** - Julia H.:
> Okay, spreche um 16:30 mit ihm

**2026-01-12 15:52:40** - Julia:
> ja ich glaubs dir...

**2026-01-12 15:52:44** - Julia:
> bin sehr gespannt!

**2026-01-12 15:53:16** - Julia:
> hab marvin schon bescheid gegeben wegen nächster woche und er meinte nur so "ne das wird flo safe nicht zulassen" (also, dass ich da hin fahr)

**2026-01-12 15:53:18** - Julia:
> lets see

**2026-01-12 15:54:17** - Julia H.:
> Ja bin auch gespannt, aber wäre ja auch nicht schlimm, sonst sagen wir Laureen halt es geht leider nicht.

**2026-01-12 15:54:40** - Julia:
> klar aber fänd ich schon auch doof einfach

**2026-01-12 15:54:41** - Julia:
> NAJA

**2026-01-12 15:58:08** - Julia H.:
> Let's see.

**2026-01-12 15:58:18** - Julia H.:
> wäre zusätzlich geld für flo das muss ihm klar sein

**2026-01-12 16:06:25** - Julia:
> Hast du kurz zeit? Huddle?

**2026-01-12 16:06:59** - Julia H.:
> Klaro 

**2026-01-12 16:07:10** - Julia:
> okay perfekt

**2026-01-13 09:00:37** - Julia:
> Hello :slightly_smiling_face: du ich hätte was auf meiner To Do Liste was ich abgeben könnte, falls du sonst nix hast. Sag bescheid, wenns okay ist :slightly_smiling_face: will dir ungern einfach irgendwas rüber schieben

**2026-01-13 09:00:56** - Julia H.:
> Jaaaa bitte!!!

**2026-01-13 09:01:39** - Julia H.:
> FYI Taran ist leider raus wegen shooting

**2026-01-13 09:02:44** - Julia:
> okay danke :smiling_face_with_3_hearts:

**2026-01-13 09:02:54** - Julia:
> Ah okay, schade! dann lösche ich ihn aus der präsi haha

**2026-01-13 09:05:24** - Julia:
> und zwar haben Marie und ich bei <http://fastmoss.com|fastmoss.com> ein Probeabo für. 10€ abgeschlossen für Estée Lauder damals. Habs eigentlich direkt gekündigt aber jetzt wurde es uns trotzdem abgebucht. Ich hab denen schon 2mal per Whatsapp Kundensupport geschrieben, dass ich den Account kündigen will aber es reagiert niemand.
Da gibts noch eine Mail, vllt könntest du es da mal versuchen?
<mailto:info.sea@fastmoss.com|info.sea@fastmoss.com>

Unsere Konto ID:
11418184

**2026-01-13 09:07:56** - Julia H.:
> Logo kein Problem!!

**2026-01-13 09:08:41** - Julia H.:
> Kann man sich da noch einloggen?

**2026-01-13 09:13:54** - Julia H.:
> nevermind, habe ne mail geschrieben

**2026-01-13 09:15:53** - Julia H.:
> Kennst du dich mit Frame aus? Laureen kann auf die Hisense Videos nicht zugreifen, aber bei mir funktionieren die links

**2026-01-13 09:17:10** - Julia:
> ja willst du den Login noch? Bzw es ist irgendwie komisch, weil ich da einfach angemeldet bin aber ohne Passwort?!

**2026-01-13 09:17:11** - Julia:
> DANKE

**2026-01-13 09:17:14** - Julia:
> Puh neee

**2026-01-13 09:17:34** - Julia:
> Vllt weil sie verschoben wurden?

**2026-01-13 09:17:40** - Julia:
> ich checke mal kurz

**2026-01-13 09:18:41** - Julia:
> vllt so: <https://next.frame.io/share/237647d8-ead7-4345-8270-bd2b6c4bbbce/>

**2026-01-13 09:18:52** - Julia:
> oder man schickt ihr alle links der videos einzeln?

**2026-01-13 09:26:47** - Julia H.:
> Hab die ja eigentlich alle einzeln im Redaktionsplan verlinkt

**2026-01-13 10:31:41** - Julia:
> hättest du Zeit und Lust gleich kurz zu sprechen? bräuchte einmal kreativen Support :face_with_spiral_eyes:

**2026-01-13 10:37:01** - Julia H.:
> Logo, jetzt gleich?

**2026-01-13 10:37:06** - Julia:
> gerne

**2026-01-13 10:52:45** - Julia:
> 

**2026-01-13 10:53:10** - Julia:
> 

**2026-01-13 10:53:51** - Julia:
> <https://docs.google.com/document/d/1dP3eV06628rlLYVp7UBVO4DnXHoUEDkJQSThJ2X3hYI/edit?tab=t.0>

**2026-01-13 10:58:14** - Julia H.:
> 

**2026-01-13 11:03:55** - Julia:
> hahaha

**2026-01-13 11:05:49** - Julia H.:
> OMG hahaha

**2026-01-13 11:07:30** - Julia:
> also GPT sagt es ist klar 90er Streetwear

**2026-01-13 11:09:55** - Julia:
> okay ich finds immer wieder faszinierend wie GPT wirklich gedanken sammeln und weiterentwickeln kann, hat mir das hier jetzt zur Bravo Idee ausgespuckt:

Das Hero-Asset: *LIDL MAGAZIN (Print + Digital Scan)*
Ein echtes Heft (limitiert) + eine „abfotografierte/gescannte“ Digitalversion als Content-Engine.
*Heft-Rubriken (mit Kollektion eingebaut):*
• *„Festival-Urlaub Packliste“* (Outfit-Check: Bucket Hat, Weste, Bag, Schlappen, Gürtel)
• *„Crush-Alarm!“* Mini-Storys (Comedy-Skits wie eure Isar/FKK-Situation)
• *„Welcher Festival-Typ bist du?“* (Quiz → endet in Produktempfehlung)
• *„Hot or Not“* (90s Polaroid-Streetsnaps)
• *„Poster“*: 90s-Pose, großer Schriftzug „LOHNT SICH“ + Key-Look
• *„Kummerkasten: Festival-Fails“* (User-generated Storys)
*Twist:* Jede Doppelseite ist gleichzeitig ein *Shoppable Lookbook* (QR-Codes / Lidl Plus).

**2026-01-13 11:11:18** - Julia H.:
> Habs mal kurz in chatgpt gejagt und folgende sachen find ich nicht doof:

• "Dresscode: unangemessen." Claim
    ◦ Outfit-Checks an Orten, wo sie keinen Sinn machen (wohnungsbesichtigung, Vorstellungsgespräch)
• Ihr launcht *bewusst falsche Hinweise*, die sich gegenseitig widersprechen.
    ◦ „This is not a collection.“
    ◦ Unscharfe Close-ups, absurde Perspektiven (Saum, Label, Naht).
    ◦ Fake-Countdowns, die abbrechen.
    ◦ Stories mit Polls: „Real oder PR-Stunt?“
    ◦ Creator bekommen *falsche Infos* (unterschiedliche). --&gt; Kommentarspalten klären sich gegenseitig auf → Algorithmus liebt das.
    ◦ Reddit &amp; TikTok: „Ich glaube, das ist alles Fake.“
• Popkultur-Momente 90ies:
    ◦ Talkshow: Wir tun so, als würden wir eine Talkshow oder Casting Show launchen
    ◦ Viva mit Mola Adebisi und Milka
• *Früh-Internet Ästhetik*
    ◦ Pixel
    ◦ schlechte Auflösung
    ◦ Ladebalken
    ◦ Clipart
    ◦ --&gt; Passt irgendwie zum geometrischen Look?

**2026-01-13 11:11:47** - Julia H.:
> Die Foto-Love Story fehlt

**2026-01-13 11:11:50** - Julia H.:
> haha

**2026-01-13 11:12:01** - Julia:
> oh ja!

**2026-01-13 11:12:19** - Julia:
> also ich glaub unter dem 90ies Thema bleiben ist schon mal sehr cool

**2026-01-13 11:12:22** - Julia H.:
> Denke da könnte man auch drauf aufbauen

**2026-01-13 11:12:27** - Julia:
> voll

**2026-01-13 11:13:40** - Julia H.:
> Da MTV jetzt keine Musikvideos mehr ausspielt, könnten wir einen Presse-Fake leaken und sagen Lidl launcht einen Musik-Sender. Darin zeigen wir dann ein Musikvideo von SSIO im Lidl Look

**2026-01-13 11:13:41** - Julia H.:
> hahahah

**2026-01-13 11:13:55** - Julia:
> :smile:

**2026-01-13 11:13:57** - Julia:
> geil lieb ich

**2026-01-13 11:14:06** - Julia:
> ja okay mega, da haben wir doch schon eine Route

**2026-01-13 11:14:43** - Julia H.:
> :stuck_out_tongue:

**2026-01-13 11:24:57** - Julia:
> ich will Teil der Kampagne sein :rolling_on_the_floor_laughing:

**2026-01-13 11:25:18** - Julia H.:
> liebs!!!

**2026-01-13 12:42:27** - Julia:
> 

**2026-01-13 13:06:24** - Julia H.:
> Ja cool kann ich gern helfen

**2026-01-13 13:08:04** - Julia:
> ui okay :heart_eyes:

**2026-01-13 13:08:42** - Julia:
> Das ist der Dips Content:
<https://drive.google.com/drive/u/0/folders/13OE-YrygC-y3BJ0j8_h7GG588kE9VKYj>

**2026-01-13 14:47:12** - Julia:
> FYI. hab ich eben an Flo geschickt :slightly_smiling_face:

**2026-01-13 14:59:36** - Julia H.:
> liebs

**2026-01-13 14:59:40** - Julia H.:
> 

**2026-01-13 14:59:48** - Julia H.:
> würd ich kaufen

**2026-01-13 14:59:54** - Julia:
> :joy:

**2026-01-13 15:00:05** - Julia:
> dann wären wir schon mal zu 3. – perfekt!

**2026-01-13 15:00:26** - Julia H.:
> Was auch funny wäre, wenn man via dem Magazin bestellen kann, so wie beim otto katalog früher

**2026-01-13 15:00:37** - Julia H.:
> kann man an cretor schicken und sie "bestellen" die kollektion

**2026-01-13 15:01:17** - Julia:
> stiiimmt

**2026-01-13 15:01:39** - Julia:
> hahah

**2026-01-13 15:01:56** - Julia:
> wenn Flo/LIDL die Kampagne nicht machen, pitchen wir sie an andere, das sag ich dir hahha

**2026-01-13 15:02:13** - Julia H.:
> haha safe

**2026-01-13 15:03:01** - Julia H.:
> könnnten wir jetzt kurz durchgehen?

**2026-01-13 15:03:20** - Julia:
> klaro

**2026-01-13 15:04:06** - Julia:
> bin im meet

**2026-01-13 15:06:46** - Julia H.:
> <https://docs.google.com/document/d/1jht5kOqi90INN9ANJStcDbaioHtzHLHj/edit>

**2026-01-13 15:18:19** - Julia H.:
> ich find das super schwer

**2026-01-13 15:20:38** - Julia:
> jaa?

**2026-01-13 15:20:43** - Julia:
> okay, dann schau ich mir das später an

**2026-01-13 15:20:46** - Julia:
> alles gut!

**2026-01-13 15:21:20** - Julia H.:
> I tried, ich hab paar sachen rausgeworfen, aber ich glaub mir fehlt da komplett das vorstellungsvermögen für den aufbau von so einem Video.

**2026-01-13 15:21:37** - Julia H.:
> Nimmt man die Zitrone rein, oder nicht, und welche Perspektive ist beser

**2026-01-13 15:21:41** - Julia H.:
> ganz schwierig

**2026-01-13 15:21:48** - Julia H.:
> Sorry :disappointed:

**2026-01-13 15:23:29** - Julia H.:
> Ich hab andere Talente

**2026-01-13 15:23:49** - Julia:
> alles guuut

**2026-01-13 15:23:57** - Julia:
> einige!

**2026-01-13 15:30:21** - Julia:
> hier ist mir nur aufgefallen was wir gestern mit Laureen hatten: collab auf Tiktok?

**2026-01-13 15:34:42** - Julia H.:
> Miriel's Account ist noch in the making, daher collaben wir auf IG und postebn ohne collab auf tiktok

**2026-01-13 15:36:10** - Julia:
> ahh okay

**2026-01-13 15:50:36** - Julia H.:
> Ich mach jetzt mal eine coffee Break 

**2026-01-13 15:52:18** - Julia:
> Ich geh auch mal kurz raus. Mein Kopf raucht 

**2026-01-14 09:46:08** - Julia:
> Hello :slightly_smiling_face: bin da

**2026-01-14 10:35:02** - Julia:
> Hast du kurz zeit?

**2026-01-14 10:35:13** - Julia H.:
> 5 min

**2026-01-14 10:35:18** - Julia:
> yees

**2026-01-14 10:41:22** - Julia H.:
> bin im meeting

**2026-01-14 10:41:57** - Julia:
> komme!

**2026-01-14 12:24:12** - Julia:
> JULIA

**2026-01-14 12:24:14** - Julia:
> ich glaube es nicht

**2026-01-14 12:25:52** - Julia:
> 

**2026-01-14 12:26:56** - Julia H.:
> wooooow :disappointed: so unangenehm

**2026-01-14 14:20:45** - Julia:
> guck mal, das ist der Screenshot von Jana. Quasi wie und woher man welche Zahlen bekommt

**2026-01-14 14:21:20** - Julia H.:
> super danke!!!

**2026-01-14 15:04:29** - Julia:
> ich liebs ja

**2026-01-14 15:05:40** - Julia H.:
> :stuck_out_tongue:

**2026-01-14 16:38:22** - Julia H.:
> Hab dir gerade kurz ne Mail von Miriel weitergeleitet, vielleicht kannst du mal kurz deine einschätzung geben

**2026-01-14 16:50:52** - Julia:
> okay moment

**2026-01-14 16:56:34** - Julia:
> ne seh ich kein Problem

**2026-01-14 16:56:44** - Julia:
> wir dürfen den content aber online lassen für ein jahr oder?

**2026-01-14 16:57:31** - Julia H.:
> So hätte ich es auch verstanden. Danke dir!! Dann schreib ich ihr gleich morgen früh, dass das so passt. aber leicht dodgy dass sie das jetzt erst sagt oder?

**2026-01-14 16:58:36** - Julia:
> Ja schon und vorallem weil sie auch schreibt "komplikationen"

**2026-01-14 16:58:46** - Julia H.:
> ja well...

**2026-01-14 16:58:53** - Julia H.:
> nehmen wir jetzt mal an, dass das alles passt

**2026-01-14 16:59:00** - Julia:
> ich denke auch

**2026-01-14 16:59:18** - Julia:
> also früher oder später wird sie uns die videos zukommen lassen, das glaub ich auf jeden fall :smile:

**2026-01-14 17:05:50** - Julia H.:
> Super danke für deine Einschätzung

**2026-01-20 11:12:55** - Julia:
> Also es wäre einmal <http://Fastmoss.com|Fastmoss.com> zu kündigen – da hattest du auch schon mal eine Mail hingeschickt.

Login ist hierrüber:
<mailto:clients@boldcreators.club|clients@boldcreators.club>
--&gt; Anmelden über Google und dann bekomme ich einen Code aufs Handy

**2026-01-20 12:02:47** - Julia H.:
> Code angekommen? 94

**2026-01-20 12:03:16** - Julia:
> yes!

**2026-01-20 12:03:24** - Julia H.:
> super dane

**2026-01-20 12:03:28** - Julia:
> danke dir!

**2026-01-20 12:07:14** - Julia H.:
> Ich glaub das hat geklappt

**2026-01-20 12:07:49** - Julia H.:
> Wer verwaltet die email adresse, vielleicht kam da ja ne bestätigung

**2026-01-20 12:11:02** - Julia:
> okay moment, ichhab zugriff

**2026-01-20 12:11:14** - Julia:
> uhh nice! ja :slightly_smiling_face:

**2026-01-20 12:11:25** - Julia:
> vielen Dank:heart_eyes:

**2026-01-20 12:12:13** - Julia:
> Das 2. wäre bei Sprout. Da hatte ich eine Anfrage gestellt und das wurde Flo als Mail geschickt (im November?) aber bisher keine Änderung

<https://sproutsocial.com/de>
Name/Mail: <mailto:porsche.deutschland@boldcreators.club|porsche.deutschland@boldcreators.club>
PW: vG.nZGi#E83a6jm

**2026-01-20 12:16:47** - Julia H.:
> okay, mach ich

**2026-01-20 12:20:42** - Julia H.:
> 

**2026-01-20 12:20:43** - Julia H.:
> Die werden sich melden

**2026-01-20 12:21:01** - Julia:
> ja genau, das hatte ich auch. haben sie aber nicht

**2026-01-20 12:21:10** - Julia:
> aber dann muss Flo das machen. das wird ja an seine mail geschickt ge?

**2026-01-20 12:21:12** - Julia H.:
> Das muss wahrscheinlich Flo im Blick behalten weil er billing contact ist

**2026-01-20 12:21:17** - Julia H.:
> ja genau ich denke auch

**2026-01-20 12:21:22** - Julia:
> ja, hatte ich ihm auch gesagt :smile:

**2026-01-20 12:21:25** - Julia:
> gut, dankeee Julia

**2026-01-20 12:21:45** - Julia H.:
> Immer gerne, sowas kannst du mir auch immer direkt geben

**2026-01-20 12:39:42** - Julia:
> okay dankee!

**2026-01-20 12:41:25** - Julia:
> Sehen wir es falsch oder wäre es nicht klar, dass wir einen ganzen Tag Ausgleich bekommen müssten?
Gestern von 7-23 Uhr unterwegs und heute von 10-23 uhr?

**2026-01-20 13:07:13** - Julia H.:
> Ja solltet schon eine Tag eigentlich bekommen…. Aber honestly sonst mach Freitag off muss er ja nicht wissen

**2026-01-20 13:14:59** - Julia:
> ja, doof einfach 

**2026-01-22 12:40:44** - Julia:
> falls du was zur Aufmunterung willst, hab einen Rap für's SSIO Video geschrieben und mit AI vertont, packen wir ins Video :joy::joy:

**2026-01-26 09:14:28** - Julia H.:
> Hahaha love it

**2026-01-27 14:55:42** - Julia:
> 

**2026-01-27 15:01:45** - Julia H.:
> Ich Supporte dich auf jeden Fall gerne!! Ich hab ihm auch heute nochmal geschrieben ob er mir mal sagen kann wie der Outlook für mich ist

**2026-01-27 15:05:50** - Julia:
> okay, das ist gut

**2026-01-28 09:20:02** - Julia:
> Es ist so deprimierend

**2026-01-28 09:22:12** - Julia H.:
> :pleading_face:

**2026-01-28 09:31:28** - Julia:
> ja oder? Also es kann doch nicht sein, dass das so ein riesiges Thema ist und uns so "stresst", also ich hab heute wirklich nur von der Arbeit geträumt

**2026-01-28 09:42:10** - Julia H.:
> Oh Gott du arme 

**2026-01-28 12:23:14** - Julia:
> hat sich Flo bei dir gemeldet?

**2026-01-28 12:59:18** - Julia H.:
> yes jetzt gerade

**2026-01-28 12:59:24** - Julia H.:
> 

**2026-01-28 12:59:42** - Julia:
> FINALLY

**2026-01-28 16:18:52** - Julia:
> juhuuu

**2026-01-28 16:20:02** - Julia H.:
> :heart:

**2026-01-28 16:20:10** - Julia H.:
> bin auch erleichtert, dass ich helfen kann

**2026-01-28 16:22:00** - Julia:
> 

**2026-01-29 09:17:23** - Julia H.:
> Huch ich hab gestern gar nicht mehr geantwortet

**2026-01-29 09:17:33** - Julia H.:
> Bin sehr gespannt aber hab auch bisschen Angst haha

**2026-01-29 09:17:44** - Julia:
> Neee

**2026-01-29 09:19:33** - Julia:
> Also die sind wirklich nett, machen viele Späßchen und so. Problem ist nur, dass ich halt nicht viel sagen kann, weil ich Marvin's Themen nicht verstehe und ich auch ziemlich sicher bin, dass die das schon gecheckt haben. Ich hab ja von Anfang an gesagt "eher kreativ" als dieses analytische – weil Flo mich ja wieder ganz anders hinstellen wollte. Aber wenn die sofort merken, dass du jetzt bei dem Projekt ja voll den Durchblick hast und genau das dein Thema ist, dann sind die auch super froh und lassen einen machen.

**2026-01-29 09:19:36** - Julia:
> Weißt wie ich meine? :slightly_smiling_face:

**2026-01-29 09:22:54** - Julia H.:
> Ja verstehe!! Let's see, ich hab jetzt mal ein Asana Projekt aufgesetzt und taste mich voran

**2026-01-29 09:47:19** - Julia:
> hab grad Zugang angefragt :slightly_smiling_face:

**2026-01-29 09:51:58** - Julia H.:
> Yes, ist noch nicht ganz fertig

**2026-01-29 09:52:02** - Julia H.:
> Hab euch freigeschaltet

**2026-01-29 10:29:19** - Julia:
> FYI: <https://docs.google.com/document/d/1fBRHzBk5TiKvimhN7A43kSC25LLpBsDyFcwDuP30R9A/edit?tab=t.0>

**2026-01-29 10:34:31** - Julia H.:
> thank you..

**2026-01-29 11:12:10** - Julia:
> Hat sich Flo zu dem heimkinoraum vorfall geäußert?

**2026-01-29 11:14:13** - Julia H.:
> Ne, hab ihm da heute auch nochmal einen reminder geschickt

**2026-01-29 11:14:15** - Julia H.:
> so peinlich

**2026-01-29 11:14:23** - Julia:
> :face_exhaling:

**2026-01-29 11:14:24** - Julia:
> okay

**2026-01-29 11:24:09** - Julia H.:
> <https://docs.google.com/presentation/d/1Yb0QEbmHyZX5Q9jB5m2degvetx4uQIzX/edit?slide=id.p22#slide=id.p22>
weißt du ob das hier noch up to date ist?

**2026-01-29 11:24:16** - Julia H.:
> und gibt es eine moderatorenliste schon

**2026-01-29 11:25:05** - Julia:
> 

**2026-01-29 11:26:40** - Julia H.:
> LOL wow. wie kann man so sein

**2026-01-29 11:26:46** - Julia:
> ich weiß es nicht

**2026-01-29 11:26:59** - Julia H.:
> sitzt heute leider hier auch im coworking :nauseated_face:

**2026-01-29 11:27:28** - Julia H.:
> Wäre ja gut wenn das veraltet ist, weil ist ja komplett unrealistisch

**2026-01-29 11:27:43** - Julia:
> 

**2026-01-29 11:27:43** - Julia:
> NEIN

**2026-01-29 11:27:55** - Julia:
> ja schau ma mal wielange sie "worked"

**2026-01-29 11:28:09** - Julia:
> ja voll

**2026-01-29 11:28:39** - Julia:
> also Girly (mit Wimpern), Fräsen (I LOVE SIXT) und Sticker overall (?) waren scheinbar freigegeben aber das weiß keiner so genau

**2026-01-29 11:28:44** - Julia H.:
> Die ist so gaga einfach wow

**2026-01-29 11:29:07** - Julia:
> total

**2026-01-29 11:29:10** - Julia H.:
> check nicht wieso er sie denn noch einen workshop machen lässt das ist halt auch nich gerade schlau

**2026-01-29 11:36:19** - Julia:
> ja vorallem soll ich den ja präsentieren?

**2026-01-29 11:36:24** - Julia:
> das weiß sie aber noch nicht glaube ich

**2026-01-29 11:36:29** - Julia:
> also alles vogelwild mal wieder

**2026-01-29 11:36:34** - Julia:
> ich sag ja: Dramen über Dramen

**2026-01-29 11:36:57** - Julia H.:
> was für ein Chaos einfach unfassbar

**2026-01-29 11:37:55** - Julia H.:
> sie hat gerade ihre sachen gepackt und geht jetzt

**2026-01-29 11:38:10** - Julia:
> denk ich mir :smile:

**2026-01-29 12:45:43** - Julia H.:
> Oh nooo she is back 

**2026-01-29 12:45:45** - Julia H.:
> Help

**2026-01-29 12:45:49** - Julia:
> JA

**2026-01-29 12:45:54** - Julia:
> hat mir grad geschrieben

**2026-01-29 12:45:55** - Julia:
> UND?

**2026-01-29 12:46:11** - Julia:
> hab ich 2 tage auf ihre Slides gewartet hab :smile: also sowas lieb ich ja

**2026-01-29 12:51:11** - Julia H.:
> wow, so rude einfach

**2026-01-29 13:24:42** - Julia:
> total

**2026-02-03 17:33:57** - Julia:
> Hallo :slightly_smiling_face:

**2026-02-03 17:34:08** - Julia:
> ah moment ich schreib in unseren Chat mit Marvin

**2026-02-04 09:03:05** - Julia H.:
> Good morning Juli, ich hoffe du hast gestern gut überstanden? Flo hat mir ganz nett geschrieben, dass er heute noch im Stress ist aber sich nachmittags meldet

**2026-02-04 09:03:14** - Julia H.:
> Ich hab zeit für dich heute anytime, auch für Sixt

**2026-02-11 14:21:45** - Julia:
> :dotted_line_face:

**2026-02-11 14:21:47** - Julia:
> haha

**2026-02-11 14:25:11** - Julia H.:
> meeehhhh

**2026-02-11 14:25:27** - Julia H.:
> aber gut mini ist ja nice vor allem wenn das andere leute machen.

**2026-02-11 14:25:38** - Julia H.:
> denke da können wir flo auch nochmal unsererseits ne einschätzung gebe

**2026-02-16 10:18:33** - Julia:
> Hellooo!

**2026-02-16 10:18:38** - Julia:
> Hast du evtl. nochmal kurz Zeit?

**2026-02-16 10:34:05** - Julia H.:
> Logo

**2026-02-16 10:34:07** - Julia H.:
> Jetzt gleich

**2026-02-16 10:36:29** - Julia:
> Jetzt bin ich unterwegs. Aber nach der Besichtigung evtl? :) 

**2026-02-16 10:37:35** - Julia H.:
> Yes logo

**2026-02-16 12:23:11** - Julia:
> war sehr cool! Hast du um 13 Uhr Zeit oder bist du da beim lunch? 

**2026-02-16 12:28:28** - Julia H.:
> Ich hab Zeit!!

**2026-02-16 12:32:10** - Julia H.:
> Supi dann bis gleich, bin gespannt was ihr erzählt

**2026-02-16 13:01:32** - Julia:
> in huddle einfach?

**2026-02-16 13:01:42** - Julia H.:
> yes bin da schon drin

**2026-02-16 13:12:44** - Julia H.:
> AI Agentur Vergleich: <https://docs.google.com/spreadsheets/d/1wLCyVO6ANkoD3ERPtXcWMOLO06az6A13PoMHk132iNI/edit?gid=0#gid=0>

**2026-02-16 13:13:35** - Julia H.:
> <https://docs.google.com/spreadsheets/d/1u-bhLWSiWORW7_8xLXgXT-vYl3T63ejCTKPlUa0kqFA/edit>

**2026-02-16 16:25:16** - Julia:
> kurze Frage nach zu Love is blind:

**2026-02-16 16:25:38** - Julia:
> weißt du, ob die Agenturen schon an SIXT geschickt wurden oder was Marvin damit gemacht hat?

**2026-02-16 16:31:59** - Julia H.:
> Ne weiß ich leider nicht :disappointed:

**2026-02-16 17:59:47** - Julia:
> okeee. Also ich versteh nicht ganz wofür sie die Agenturen wollen, weil wir haben das ja intern schon ganz gut gelöst. Weißt du da mehr?
Sorry ich hab irgendwie gefühlt keine Infos :smile:

ABER ich hab kurz mit Ersin gesprochen und ihm auch die Clips gezeigt, er meinte für ihn ist das halt easy. Würde ihn jetzt auch mal mit aufnehmen? Marvin hatte ich schon mal erzählt, dass er das auch kann also why not?

**2026-02-16 18:10:35** - Julia H.:
> Ja klaro!! Mach das

**2026-02-16 18:14:26** - Julia H.:
> Denkst du ich kann Katharina die Kosten morgen schicken? 

**2026-02-16 18:15:38** - Julia H.:
> Keine Ahnung wann die ihr Meeting hat

**2026-02-16 18:29:08** - Julia:
> Ja keine Ahnung :face_with_spiral_eyes: geht ja auch nicht anders, oder?

**2026-02-16 18:30:23** - Julia H.:
> Kein Plan, ich schreib jetzt doch schnell ne Mail und hänge ihr die Kosten an...


---

## Mert Koc (2573 messages)

**Julia sent:** 1487 | **Mert Koc sent:** 1086

**Folder:** `D09D0E0RP9B`

**2025-09-02 10:14:47** - Julia:
> Hello :slightly_smiling_face:

**2025-09-02 10:15:11** - Mert Koc:
> Helloo :grin:

**2025-09-02 16:38:57** - Julia:
> du noch eine Frage

**2025-09-02 16:39:09** - Julia:
> ist Chris auch dabei oder sind das fake news? :smile:

**2025-09-03 12:03:48** - Julia:
> helloo :slightly_smiling_face: ich finds gerade nichtmehr: könntest du mir den Link zu den Fotos vom Gipfeltreffen letztes Jahr schicken? Das was wir gestern im Meeting gefunden haben

**2025-09-03 12:04:28** - Mert Koc:
> Yes einen Moment

**2025-09-03 12:04:53** - Mert Koc:
> <https://www.picdrop.com/porsche-deutschland>

**2025-09-03 12:05:07** - Mert Koc:
> Hier und dann links runter Scrollen zu Gipfeltreffen

**2025-09-03 12:06:01** - Julia:
> ah mist da hab ich doch noch keinen zugang

**2025-09-03 12:06:19** - Julia:
> ah gefunden!

**2025-09-04 09:29:27** - Julia:
> GuMo! :slightly_smiling_face: bin gleich ready. Nur kurz nochmal: diese Schriftgröße passt oder? 11pt

**2025-09-04 09:30:59** - Mert Koc:
> Guten Morgen :sunny:  
Ja genau, das ist die aus der neuen Vorlage oder? Dann passt das 

**2025-09-04 09:31:14** - Julia:
> genau

**2025-09-04 09:31:18** - Julia:
> Okay

**2025-09-04 09:31:21** - Julia:
> Dankee :slightly_smiling_face:

**2025-09-04 09:33:10** - Julia:
> und wir exportieren als png oder jpg?

**2025-09-04 09:42:31** - Mert Koc:
> Als jpg

**2025-09-04 09:49:27** - Julia:
> okay schmeiß mich raus

**2025-09-04 10:14:32** - Julia:
> du bist noch drin oder?

**2025-09-04 10:14:43** - Mert Koc:
> Ja :+1::skin-tone-3:

**2025-09-04 10:19:02** - Mert Koc:
> Ich habe kurz Verschnaufpause, bis Julia mir wieder Feedback gibt, bis dahin kannst du wieder rein, wenn du möchtest :grin:

**2025-09-04 10:19:29** - Julia:
> haha jaa gerne :smile:

**2025-09-04 10:19:41** - Julia:
> ich hab Flo mal wegen Figma geschrieben – würde alles erleichtern im Still bereich

**2025-09-04 10:19:41** - Mert Koc:
> Kick mich einfach wieder

**2025-09-04 10:19:55** - Mert Koc:
> Ja das stimmt

**2025-09-04 10:21:46** - Julia:
> wie machst du das? im Call meinte Charly gerade sie würd den Text einfach runtersetzen --&gt; machen wir das?

**2025-09-04 10:23:40** - Mert Koc:
> Ja du kannst es runter machen aber am besten nicht in den Schutzbereich.

**2025-09-04 10:24:10** - Mert Koc:
> Also einfach nicht in den Rosa Bereich.
Und wenn es eine VBW gibt, nicht unter den blauen Strich

**2025-09-04 10:24:19** - Julia:
> ja okay, passt

**2025-09-04 10:24:21** - Julia:
> danke :slightly_smiling_face:

**2025-09-04 10:24:27** - Mert Koc:
> Bittee

**2025-09-04 11:22:08** - Julia:
> Mert, könntest du mir einen Gefallen tun? Könntest du die Styleguide Keynote die ihr erstellt habt auf ppt zu exportieren oder "kurz" umzubauen?
Ich hab leider noch keinen Keynote Zugriff und die Porsche wills ja auch auf ppt haben

**2025-09-04 11:24:00** - Mert Koc:
> Ja kann ich machen

**2025-09-04 11:24:08** - Julia:
> ich danke dir

**2025-09-04 11:25:02** - Mert Koc:
> Nevermind, hab selber kein Keynote. Ich frag mal schnell Basti, ob er das exportieren kann. Er hat es nämlich auch angelegt.

**2025-09-04 11:27:19** - Mert Koc:
> hab ihn gefragt :slightly_smiling_face:

**2025-09-04 11:27:24** - Mert Koc:
> Er macht es für uns

**2025-09-04 11:28:17** - Julia:
> dankeee

**2025-09-04 11:44:19** - Julia:
> Hast du kurz 3 Minuten?

**2025-09-04 11:44:27** - Mert Koc:
> Ja

**2025-09-04 11:44:37** - Julia:
> dann huddle ich dich schnell an

**2025-09-04 11:45:06** - Mert Koc:
> 

**2025-09-04 11:45:49** - Mert Koc:
> <https://drive.google.com/drive/folders/1XArVzUF66CsnjfED6BlCdHXN_BOKmZFe?usp=drive_link>

**2025-09-04 11:54:18** - Mert Koc:
> Darf ich dich kurz von Adobe abmelden?

**2025-09-04 11:54:26** - Julia:
> ja klar

**2025-09-04 12:16:03** - Julia:
> irgendwie bin ich trotzdem in ps drin

**2025-09-04 12:17:20** - Mert Koc:
> auch gut haha

**2025-09-04 16:31:45** - Julia:
> haben wir irgendwo ein iphone mockup abgelegt?

**2025-09-04 16:37:09** - Mert Koc:
> Ne wir hatten mal IG Mockups aber Flo findet das nicht so ... deswegen hatten wir dann gar keine mehr irgendwann

**2025-09-04 16:37:32** - Julia:
> ah okay

**2025-09-04 16:37:35** - Julia:
> dankee

**2025-09-04 16:59:23** - Julia:
> Nochmal kurz eine dringende Frage

**2025-09-04 16:59:37** - Julia:
> Die HLs im Styleguide sind auch von der PAG übernommen?

**2025-09-04 17:00:14** - Julia:
> ich hatte es nämlich so gemacht wie die PS Vorlage und online ging es dann anders

**2025-09-04 17:01:20** - Mert Koc:
> echt? Die PS Vorlage sollte eig so sein wie PAG

**2025-09-04 17:01:45** - Julia:
> hab jetzt julia nochmal geschrieben

**2025-09-04 17:01:50** - Julia:
> chaaaaos

**2025-09-04 17:02:48** - Mert Koc:
> Aber die ändern das leider auch ständig.
Was Julia auch meint mit "Das sollten wir 1:1 von der PAG übernehmen" ist, dass wir so Assets die Global an alle Channels verteilt werden einfach 1:1 kopieren und nur den Text anpassen.
Also die Schriftgröße und wo der Text gesetzt wird einfach kopieren, auch wenn wir es nicht so machen würden.

**2025-09-04 17:03:05** - Julia:
> ahh got it

**2025-09-04 17:03:24** - Julia:
> das war dann quasi der sonderfall

**2025-09-04 17:04:02** - Mert Koc:
> Ja aber der "Sonderfall" kommt fast jede Woche vor, wenn Global was an die unteren Channels verteilt. :sweat_smile:

**2025-09-04 17:04:11** - Mert Koc:
> Und jedes mal ist alles anders als davor

**2025-09-04 17:04:27** - Julia:
> :joy:

**2025-09-04 17:04:28** - Mert Koc:
> Vielleicht haben die keine strikten Social Vorgaben, who knows

**2025-09-04 17:04:33** - Julia:
> Oh je

**2025-09-04 17:04:57** - Mert Koc:
> Und bei Porsche Deutschland will keiner Entscheidungen treffen

**2025-09-04 17:05:35** - Julia:
> lieben wir

**2025-09-05 10:04:52** - Mert Koc:
> <https://drive.google.com/drive/folders/1If29keEzgwbXQd8od47KZRnIjONRlcFq?usp=drive_link>

**2025-09-05 10:05:16** - Mert Koc:
> TINS Day: <https://drive.google.com/drive/folders/1wgwlzf5IwhLHgLYzCbx3tu-bpBSTtJFQ?usp=drive_link>

**2025-09-05 11:39:24** - Julia:
> ah jetzt wurde ich von PS abgemeldet :smile:

**2025-09-05 11:39:25** - Julia:
> komisch

**2025-09-05 15:07:45** - Mert Koc:
> Hier ist der Stand. Das "Video" mit den Fotos muss ich noch machen, ich habe keine Ahnung, welche Fotos ich dafür hernehmen soll...

**2025-09-05 15:08:42** - Mert Koc:
> Bei der dritten Slide gefällt mir der "Titel" Tagesprogramm nicht so wirklich. Vorallem, weil es random dritte Slide plätzlich nen Titel gibt. Und die CI ist anders als auf der ersten Slide. :melting_face:

**2025-09-05 15:10:46** - Mert Koc:
> So ginge auch, dass ist es wi eim Key-Visual aber halt nicht Standard CI

**2025-09-05 15:11:50** - Julia:
> Cool danke!
1. Slide: Würde ich das Visual evtl noch größer machen?
2. Slide: Ort bei der Stecknadel hinzufügen
3. Vllt lieber: Highlights am 13.09.2025

**2025-09-05 15:12:32** - Julia:
> Ja versteh was du meinst. Ich würde in dem Fall ehrlich eher dann auf das Design von der Agentur gehen als unsere CI, wenn es so nach nix aussieht.
Die hatten ja teilweise auch Orange benutzt oder?

**2025-09-05 15:13:04** - Mert Koc:
> Ja die HL waren Orange und die Texte schwarz.

**2025-09-05 15:14:01** - Julia:
> Bei dem Foto Video Ding:
2x Nahaufnahmen Porsche
3x Event Porsche (letztes Jahr IAA?)
3x Fahrzeug Modelle --&gt; Taycan, Cayenne Electric Prototyp vllt sogar?
2x Menschen/ Emotionen

**2025-09-05 15:14:36** - Julia:
> dann lass uns doch die HL auch Orange machen beim Programm

**2025-09-05 15:15:36** - Mert Koc:
> Versuche solche Fotos zu finden. Ist nicht so leicht leider.

**2025-09-05 15:16:00** - Julia:
> glaub ich dir

**2025-09-05 15:17:00** - Mert Koc:
> bei 2. der Ort ändert sich ja im Verlauf des Abends. Also das ist ja teilweise am Stand, im Koi und im P1...

**2025-09-05 15:18:34** - Julia:
> achsoo stimmt --&gt; München?

**2025-09-05 15:20:53** - Mert Koc:
> Ja genau, deswegen habe ich den Satz mit München angefangen ^^
Soll ich trotzdem noch zusätzlich München unten bei der Nadel?

**2025-09-05 15:49:21** - Julia:
> Mert kannst du mir dieses Visual schicken oder den Link zu den "Links" in Drive?

**2025-09-05 15:50:46** - Mert Koc:
> Ja, das ist hie rim InDesign Ordner: <https://drive.google.com/drive/folders/1If29keEzgwbXQd8od47KZRnIjONRlcFq?usp=drive_link>

**2025-09-05 15:51:04** - Mert Koc:
> Hier die KeyVisuels für TINS Days: <https://drive.google.com/drive/folders/1wgwlzf5IwhLHgLYzCbx3tu-bpBSTtJFQ?usp=drive_link>

**2025-09-05 15:52:15** - Julia:
> 

**2025-09-05 15:56:12** - Mert Koc:
> Ne ich habe sonst leider auch keine andere Datei :disappointed:
Das ist bei mir auch verpixelt, wenn ich es versuche raus zu speicehrn

**2025-09-05 15:56:42** - Mert Koc:
> Ich glaube wir haben das gar nicht

**2025-09-05 16:08:50** - Julia:
> okay, mist

**2025-09-05 16:08:52** - Julia:
> danke!

**2025-09-05 16:09:12** - Mert Koc:
> Eine Frage noch zu dem GIF mit Bildern für die Atmosphäre. Was soll ich da drauf schreiben?
oder einfach nur GIF ?

**2025-09-05 16:12:15** - Julia:
> In dem was live haben sie die Tickets beworben. Also entweder das "Exklusive Tickets für unsere Community"
oder sowas wie "#PorscheFamily vereint" oder "Porsche live erleben"

**2025-09-05 16:37:28** - Mert Koc:
> So siehts aus :slightly_smiling_face:

**2025-09-05 16:44:35** - Julia:
> Cool! :slightly_smiling_face: Könntest du noch eine Version machen mit Exklusive Tickets für unsere Community?

**2025-09-05 16:44:39** - Julia:
> Dann können wir beides vorstellen

**2025-09-05 17:03:57** - Mert Koc:
> 

**2025-09-05 17:10:15** - Julia:
> niiice

**2025-09-05 17:10:17** - Julia:
> danke

**2025-09-05 17:10:22** - Julia:
> find ich fast besser

**2025-09-05 17:10:24** - Julia:
> du?

**2025-09-05 17:12:25** - Mert Koc:
> Ich auch

**2025-09-05 17:12:31** - Mert Koc:
> Glaueb Porsche wirds auch besser finden

**2025-09-05 17:25:35** - Julia:
> legst du alles in die präsi oder? :slightly_smiling_face:

**2025-09-05 17:31:30** - Mert Koc:
> Kann ich gleich machen. Muss noch Daily Schedule machen

**2025-09-08 09:33:44** - Julia:
> Guten Morgen! :slightly_smiling_face:
Hier gabs schon Feedback: <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/doc2.aspx?sourcedoc=%7BE57B0967-DF14-4D65-A137-58646F317C64%7D&amp;file=250903_IAA_Hospitality_FD.pptx&amp;fromShare=true&amp;action=edit&amp;mobileredirect=true&amp;previoussessionid=77d20bb4-f210-877d-3c82-0f27d3e717a3&amp;wdOrigin=TEAMS-MAGLEV.p2p_ns.rwc&amp;wdExp=TEAMS-TREATMENT&amp;wdhostclicktime=1756982116144&amp;web=1|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/doc2.aspx?sourcedoc=%7BE57B0[…]wdExp=TEAMS-TREATMENT&amp;wdhostclicktime=1756982116144&amp;web=1>

**2025-09-08 09:37:49** - Mert Koc:
> Guten Morgen :slightly_smiling_face:
Danke für die Info

**2025-09-08 10:54:50** - Mert Koc:
> Kannst du bei Gelegenheit bitte das Feedback überprüfen, also ob ich das so richtig verstanden und umgesetzt habe: <https://porsche.sharepoint.com/:p:/r/sites/PDMK/Shared%20Documents/General/UMZUG/Kampagnen/_VKR%20MY%2025/TINS/IAA/Produktion%20%26%20Ver%C3%B6ffentlichung/Hospi%20Bewerbung/250903_IAA_Hospitality_FD.pptx?d=we57b0967df144d65a13758646f317c64&amp;csf=1&amp;web=1&amp;e=sluGR0&amp;nav=eyJzSWQiOjIxNDc0ODM0MzYsImNJZCI6MzI5NzM0OTg5OH0|250903_IAA_Hospitality_FD.pptx>

**2025-09-08 10:57:58** - Julia:
> yes, schau ich mir an

**2025-09-08 11:18:26** - Julia:
> Slide 2: Welches Video meint sie denn, also ist das Visual das Richtige?
Text noch etwas kürzen:
_*Gemeinsam auf die IAA:*_
_*Mit 20 exklusiven Tickets wollen wir mit euch den "There is no substitute Day" am Samstag verbringen.*_ 
_*#PorscheFamily*_


*Video:* Würde ich noch 1 Bild vom Catering/ Drinks/ Feiern reinnehmen
*Slide 3:* 
*Exklusive Ticket Vorteile:* 
• Zutritt zur Porsche Standparty (+ Begleitungperson)
• kostenloses, ganztägiges Parkticket (Siemens Parkhaus)
• erhältlich über die My Porsche App


**2025-09-08 11:34:24** - Julia:
> Magst du mir bescheid geben, wenn ich kurz in PS kann?

**2025-09-08 11:35:04** - Mert Koc:
> Ja, kannst du gleich ich geb dir Bescheid

**2025-09-08 11:42:08** - Mert Koc:
> Kannst rein :slightly_smiling_face:

**2025-09-08 11:42:15** - Mert Koc:
> hab dein Feedback auch umgesetzt.

**2025-09-08 11:42:49** - Mert Koc:
> Und auch das Bild mit der "Mutter Tocher" (was sie definitiv nicht waren) ersetzt.

**2025-09-08 11:44:15** - Julia:
> das war schlimm. aber wie ist es da, wenn dieses feedback kommt, setzen wir das dann auch immer 1x1 so um?

**2025-09-08 11:45:00** - Julia:
> hast du bei Slide 2 einen dunklen Gradient rein? Hab das gefühl man kanns etwas schwer lesen

**2025-09-08 11:45:08** - Mert Koc:
> Eigentlich schon aber wir können ja einen Gegenvorschlag machen

**2025-09-08 11:45:44** - Mert Koc:
> Ne habe sogar den Boden aufgehellt, damit man es besser lesen kann aber das stört mich auch nochj

**2025-09-08 11:46:32** - Mert Koc:
> Suche da gerade nach nem besseren Visual aber es gibt keine auf der IAA oder Stand ähnlich, wo das gut passen würde.
Nur so welche vom Gipfeltreffen in der Natur:

**2025-09-08 11:46:58** - Julia:
> Okay

**2025-09-08 11:47:30** - Julia:
> Und eins wo Menschen im Fokus sind &amp; die Fahrzeuge nur im Hintergrund oÄ?

**2025-09-08 11:47:47** - Julia:
> glaube das ist zu Natur-lastig

**2025-09-08 11:51:14** - Mert Koc:
> How is this one :

**2025-09-08 11:52:04** - Julia:
> ja!

**2025-09-08 11:53:02** - Mert Koc:
> Das wäre auch noch nice, wegen der Fahrzeug Farbe und der HL Farbe. :slightly_smiling_face:

**2025-09-08 11:54:06** - Julia:
> true that. würde mal das mit den lachenden Menschen vorschlagen, da das noch mehr diesen Vibe hat "gemeinsam gute Zeit"

**2025-09-08 11:54:14** - Mert Koc:
> Aber habe mal das mit den 3 Menschen in die PPt

**2025-09-08 11:54:39** - Julia:
> voll gut, danke!

**2025-09-08 11:54:53** - Julia:
> bekommen gleich figma :partying_face:

**2025-09-08 12:00:58** - Mert Koc:
> Niice :rocket:

**2025-09-08 12:01:32** - Mert Koc:
> Du hattest die Texte für das Daily Programm gemacht oder?
Die sind ja in dieser Excel für die IAA, wie komme ich da dran?

**2025-09-08 12:01:45** - Mert Koc:
> Finde in Asana keine Verlinkung dazu

**2025-09-08 12:02:55** - Julia:
> Ah moment

**2025-09-08 12:03:06** - Julia:
> Das war nochmal zum Feedback bei Porsche dachte ich aber idk

**2025-09-08 12:03:37** - Julia:
> Auch heute heißt es: einsteigen, erleben, entdecken.
Eure Daily Highlights im Überblick:

"Nichts verpassen"-Sticker?
<https://porsche.click/IG_IAA2025>

**2025-09-08 12:05:02** - Julia:
> Du Mert, Julia &amp; ich müssen gleich los. Ich würde dir noch eine Task in Asana geben. Wäre super, wenn du das erstellen kannst. Sobald ich dann wieder an den PC kann, kann ichs fertig stellen :slightly_smiling_face:

**2025-09-08 12:21:57** - Julia:
> Beim Daily haben wir glaub ich alle aneinander vorbeigeredet :smile:

**2025-09-08 12:23:36** - Julia:
> Also es soll quasi die Tagesprogramm Slide ersetzen, denn Porsche möchte es nicht so aufgelistet haben.
Eher in die Richtung die Julia schon in Asana gelegt hat
"1 Story Slide
HL: Porsche at IAA
SL: Programmhighlights &amp; Probefahrten
12-14.09.
- Bleib informiert
- Link: <https://porsche.click/IG_IAA2025>"

Also gerne Tagesprogramm Slide + Link Slide als 1 Slide

**2025-09-08 12:23:52** - Julia:
> 

**2025-09-08 12:26:15** - Julia:
> Weißt du was ich meine?

**2025-09-08 12:28:50** - Mert Koc:
> Ja verstehe ich ^^
Deswegen hatte ich die andere Slide weiter weg platziert.
Ich mache mal Iterationen

**2025-09-08 12:29:02** - Julia:
> Okay danke :smile:

**2025-09-08 12:29:06** - Julia:
> complicated

**2025-09-08 12:29:45** - Julia:
> Müssen da noch einen Prozess finden, wo zentral die Infos dann auch wirklich alle abliegen

**2025-09-08 12:41:11** - Mert Koc:
> So besser oder :slightly_smiling_face:

**2025-09-08 14:14:55** - Julia:
> ja!

**2025-09-08 14:19:21** - Julia:
> Bin bis 15Uhr da, falls du etwas brauchst

**2025-09-08 14:41:50** - Julia:
> Soo guck mal, das daily müssten wir nochmal anpassen:
<https://www.figma.com/design/7P5fTRcISCX1xDyTeA0TCr/IAA-Content?node-id=0-1&amp;t=LCBxnA2S39ryRpkn-1>

**2025-09-08 14:42:01** - Julia:
> Probier mal ob du Zugang hast? :slightly_smiling_face: Habs nur schnell gebastelt

**2025-09-08 14:45:00** - Mert Koc:
> habe Zugriff angefragt :slightly_smiling_face:

**2025-09-08 14:56:51** - Julia:
> gehen gerade die Story durch:
das und das letzte raus

**2025-09-08 15:00:00** - Mert Koc:
> Die ganze Story oder die Bilder im Video?

**2025-09-08 15:00:00** - Julia:
> Slide 2:
mit limitierten Tickets (keine Anzahl) wollen wir mit euch den
Porsche. There is no substitute. Day am Samstag verbringen.
#PorscheFamily


Slide4:
(inkl. Begleitperson)
Parkhaus raus

**2025-09-08 15:00:11** - Julia:
> Die Bilder

**2025-09-08 15:08:29** - Mert Koc:
> Sieht bisschen Leer dann aus oder nicht ?

**2025-09-08 15:10:07** - Mert Koc:
> Habe die neue Vorlage :slightly_smiling_face:
Mit Mockup im Ordner mit den Zonen.

**2025-09-08 15:57:02** - Mert Koc:
> Feedback von IAA &amp; TINS ist umgesetzt

**2025-09-08 17:13:38** - Julia:
> Cool! Magst du mir hier kurz einen Screenshot schicken? :) 

**2025-09-08 17:14:13** - Julia:
>  Ja aber war leider direkt Feedback von Hannah 

**2025-09-08 17:14:29** - Julia:
> Juhuu

**2025-09-08 17:16:01** - Mert Koc:
> 

**2025-09-08 17:17:43** - Mert Koc:
> BTW soll ich jetzt das Daily Programm zu dem ändern oder jetzt erst mal so lassen? Bin so verwirrt, was das angeht!

**2025-09-08 17:18:02** - Mert Koc:
> Oder erst mal so lassen?

**2025-09-08 17:19:25** - Julia:
> 2. slide müssten wir doch den Vorschlag von dir nehmen ohne Menschen mit orangenem Auto. Es lädt gerade nicht deshalb kann ich nicht kommentieren 

**2025-09-08 17:19:55** - Julia:
> Daily bitte zu dem von figma anpassen, genau 

**2025-09-08 17:21:10** - Julia:
> Wenn du sonst nichtmehr da bist, leg mir gern die verpackte indesign Datei ab :)

**2025-09-08 17:22:10** - Mert Koc:
> Ne, bin noch da :slightly_smiling_face: mache gerade noch Sonderwunsch aber dann mache ich kurz IAA wieder

**2025-09-08 17:25:49** - Julia:
> Okay danke. Sag einfach Bescheid 

**2025-09-08 17:26:03** - Julia:
> Wir können sonst auch kurz telefonieren wenn du eine Frage hast 

**2025-09-08 17:26:08** - Julia:
> <tel:015229018774|015229018774>

**2025-09-08 18:01:06** - Mert Koc:
> Weißt du wo ich das finde ?

**2025-09-08 18:01:16** - Mert Koc:
> Mit dem IAA groß im Hintergrund ?

**2025-09-08 18:08:34** - Julia:
> Ich hab das glaub ich noch nicht hochgeladen weil vorhin schnell schnell 

**2025-09-08 18:08:42** - Julia:
> Aber so wie das Highlight 

**2025-09-08 18:09:12** - Julia:
> Bezüglich Tins day story müssen wir textlich noch eine Sache hinzufügen, gerade Info bekommen. Legs mir gerne ab 

**2025-09-08 18:16:24** - Mert Koc:
> Hier mal die Daily Programm SLides. Kann ich leider nicht in Figma ablegen, weil nur Viewer Rechte.

**2025-09-08 18:17:24** - Mert Koc:
> 

**2025-09-08 18:17:26** - Mert Koc:
> Was soll da textlich angepasst werden ?

**2025-09-08 18:20:14** - Julia:
>  Super. Auch nicht mit dem Zugang von Flo?

**2025-09-08 18:20:42** - Julia:
> Aber egal erstmal. Hauptsache die offenen Dateien liegen ab

**2025-09-08 18:21:01** - Julia:
> Ist noch nicht fix  

**2025-09-08 18:23:38** - Mert Koc:
> Yes ich leg dir gleich alles ab :) 

**2025-09-08 18:23:49** - Mert Koc:
> Sind aber PSDs nur fyi 

**2025-09-08 18:38:09** - Mert Koc:
> Die offenen Dateien laden hier hoch: <https://drive.google.com/drive/folders/1PgA-uDtqYfh8oSDe81AX534IipAoh6wD?usp=drive_link>
Einmal Das Daily Program und das TINS Day

**2025-09-08 18:43:20** - Julia:
> suuper danke

**2025-09-09 08:33:19** - Julia:
> Guten morgen :slightly_smiling_face:

**2025-09-09 08:33:42** - Julia:
> Sorry für dieses Hin &amp; Her gestern. Porsche stand halt neben uns und wollte live Design machen, puh

**2025-09-09 08:33:57** - Julia:
> Wenn du dich mit dem Account von Flo in figma einloggst, geht es nicht?

**2025-09-09 08:59:48** - Mert Koc:
> Guten morgen :) 
Kein Problem, versteh ich 

**2025-09-09 08:59:55** - Mert Koc:
> Ich probier’s direkt mal 

**2025-09-09 09:03:20** - Mert Koc:
> Ja, hat geklappt :slightly_smiling_face:

**2025-09-09 10:00:53** - Julia:
> perfekt

**2025-09-09 10:01:20** - Mert Koc:
> Die eine Story ist echt wild geworden haha

**2025-09-09 10:01:22** - Mert Koc:
> und bunt

**2025-09-09 10:04:42** - Julia:
> Ja keine Worte :smile:

**2025-09-09 10:04:55** - Julia:
> Es kam dann die Frage woher jetzt eigentlich orange kommt? Was soll ich sagen hahaha

**2025-09-09 10:05:16** - Mert Koc:
> Du so "same"

**2025-09-09 10:05:26** - Julia:
> :joy:

**2025-09-09 10:05:27** - Julia:
> same bro

**2025-09-09 10:30:48** - Julia:
> Du eine Frage

**2025-09-09 10:31:09** - Julia:
> wo finde ich eine Vorlage für diese IG Link Grafik?

**2025-09-09 10:31:29** - Mert Koc:
> Die ist in der Vorlage

**2025-09-09 10:31:37** - Mert Koc:
> "Linksticker"

**2025-09-09 10:31:40** - Julia:
> Ahhh

**2025-09-09 10:31:41** - Julia:
> smart

**2025-09-09 10:31:43** - Julia:
> :slightly_smiling_face:

**2025-09-09 15:27:40** - Julia:
> Hast du mein Asana Ticket gesehen? :slightly_smiling_face:

**2025-09-09 15:28:30** - Mert Koc:
> Ne leider noch nicht

**2025-09-09 15:28:40** - Mert Koc:
> Muss das heute noch gemacht werden oder?

**2025-09-09 15:29:19** - Mert Koc:
> ich schaffe das nicht, weil ich komme mit meinen Aufgaben gerade nicht hinterher. Muss diese Sonderwunsch Videos endlich mal fertig machen und bin mitten drin.

**2025-09-09 15:33:19** - Julia:
> Okay, dann mach gerne erstmal das. Falls du irgendwie schneller durchkommst, sag gerne bescheid. Ist für morgen 11.30 Uhr geplant

**2025-09-09 15:39:53** - Mert Koc:
> Gibt es da schon was Konzept mäßig an Vorarbeit oder so?
Maybe kann Laetitia das Anfangen und ich mache dann die Gestaltung fertig. :smiling_face_with_tear:

**2025-09-09 15:40:31** - Julia:
> Ne nur das was ich abgelegt hab

**2025-09-09 15:40:39** - Julia:
> alles gut, vllt schaff ich es schon etwas anzufangen

**2025-09-09 17:26:12** - Mert Koc:
> Ich bin so durch, Im out für heute

**2025-09-09 17:26:20** - Mert Koc:
> Seid ihr noch auf der IAA?

**2025-09-09 18:00:25** - Julia:
> Fraaaag mal. Yes, gestern bis 23

**2025-09-09 18:49:41** - Mert Koc:
> Oh Gott 

**2025-09-09 18:49:56** - Mert Koc:
> Ich geh gleich spazieren, vielleicht sieht man sich ja da 

**2025-09-09 19:05:24** - Julia:
> Sind noch in unserem Kabuff :smile:

**2025-09-10 10:25:17** - Mert Koc:
> Falls das noch relevant ist, habe ich in Figma mal angelegt :slightly_smiling_face:

**2025-09-10 10:44:49** - Julia:
> GuMooo!

**2025-09-10 10:45:12** - Julia:
> Ahh cool :slightly_smiling_face: hab gestern auch noch was angefangen, ich fügs mal hinzu

**2025-09-11 18:31:34** - Julia:
> Hab dir eine Task rein, wäre mega, wenn du das direkt morgens anlegen kannst

**2025-09-11 18:57:11** - Mert Koc:
> All right :) 

**2025-09-12 10:18:39** - Julia:
> Hello! :slightly_smiling_face:

**2025-09-12 10:18:54** - Mert Koc:
> Hallo :slightly_smiling_face:

**2025-09-12 10:20:39** - Julia:
> Ich geb dir Bescheid sobald der Text final ist

**2025-09-12 11:23:43** - Mert Koc:
> Die neue Version liegt ab :slightly_smiling_face:

**2025-09-12 11:23:50** - Julia:
> uhh okay, moment

**2025-09-12 11:26:19** - Mert Koc:
> passt es so ?

**2025-09-12 11:46:53** - Julia:
> jaaaaa

**2025-09-12 11:46:55** - Julia:
> danke danke danke

**2025-09-17 14:49:01** - Julia:
> Meeert

**2025-09-17 14:49:06** - Julia:
> ich bin schockiert

**2025-09-17 14:49:15** - Julia:
> wie viel hast du schon mit Charly zusammen gearbeitet?

**2025-09-17 14:49:22** - Julia:
> :fearful::joy:

**2025-09-17 14:52:24** - Mert Koc:
> Oh Gott .. war sie fieß ? :sweat_smile:

**2025-09-17 14:52:36** - Mert Koc:
> Hatte zum Glück nur 1 mal mit ihr Kontakt lol

**2025-09-17 14:52:48** - Julia:
> Ne sie ist einfach, ich weiß garnicht wie ich das beschreiben soll

**2025-09-17 14:52:56** - Julia:
> Dreh das Bild um 0,5°

**2025-09-17 14:53:39** - Julia:
> "Ist das ein Leerzeichen zuviel?" - Nein, habs auch nochmal mit GPT gecheckt.
"warte ich checke nochmal"

...
passt!

Ah ne alles nochmal löschen: Das Bild ist zu angeschnitten

**2025-09-17 14:53:45** - Julia:
> waaaaas

**2025-09-17 14:53:49** - Julia:
> :face_with_peeking_eye:

**2025-09-17 14:54:25** - Mert Koc:
> Achso ja das nervt mega.
Die ist voll der Controllfreak

**2025-09-17 14:54:32** - Mert Koc:
> deswegen haben wir auch immer 28 Versionen

**2025-09-17 14:54:39** - Julia:
> das geht ja garnicht

**2025-09-17 14:54:59** - Julia:
> Da muss ein Prozess her. Feedback gesammelt und ciao

**2025-09-17 14:55:35** - Mert Koc:
> Ja hab ich schon oft gesagt aber das klappt leider bei der nicht.
Sie sagen dann immer "ihr könnt den Prozess bestimmen" aber dann halten sie sich einfach nicht dran

**2025-09-17 14:56:36** - Mert Koc:
> Ich glaube, dass Flo deswegen die "Iterationen" in Asana hinzugefügt hat, weil es ihn auch stört

**2025-09-17 14:58:04** - Julia:
> kraaass wirklich

**2025-09-17 14:58:14** - Julia:
> da reichen keine 4 iterationen

**2025-09-17 15:12:49** - Julia:
> jetzt ist diese aufgabe nicht in asana mit der caption

**2025-09-17 15:12:58** - Julia:
> kannst du mir da nochmal helfen?

**2025-09-17 15:19:15** - Mert Koc:
> Das war für das Gipfeltreffen Grid

**2025-09-17 15:19:31** - Mert Koc:
> Ich glaube, die drei Bilder brauchen jeweils eine Caption

**2025-09-17 15:19:47** - Julia:
> Ah okay.
Aber ich dachte das von Flo mit dem Lieblingsstrecke oÄ

**2025-09-17 15:19:58** - Julia:
> Hast du die Präsi für mich vom Grid? :slightly_smiling_face:

**2025-09-17 15:20:23** - Mert Koc:
> Achsoo da gibts auch noch keine ?

**2025-09-17 15:20:37** - Mert Koc:
> Das Reel wird zum Teaser für das Gipfeltreffen mit Malmedie

**2025-09-17 15:20:50** - Julia:
> Nee, laut meiner Mails nicht :smile:

**2025-09-17 15:20:57** - Mert Koc:
> Hier das Grid

**2025-09-17 15:21:55** - Mert Koc:
> Bin gleich fertig mit dem Reel

**2025-09-17 15:22:16** - Mert Koc:
> Glaub das YT Video dazu schaffe ich heute nicht aber das muss eh erst mal Approved werden

**2025-09-17 15:22:30** - Mert Koc:
> Bzw ein 40 Sek YT Video wäre auch weird aber anyway

**2025-09-17 15:23:20** - Julia:
> :smile: okay

**2025-09-17 15:23:42** - Julia:
> Könnten wir die IG Highlights noch anpassen? Kannst mir auch gern die Datei schicken, dann mach ich das

**2025-09-17 15:24:35** - Mert Koc:
> Die Datei ist der absolute Albtraum, weil ich das KeyVisual manuell aus der Datei von der anderen Agentur extrahieren musste :))))))

**2025-09-17 15:24:57** - Julia:
> :melting_face:

**2025-09-17 15:24:59** - Julia:
> lieben wir

**2025-09-17 15:24:59** - Mert Koc:
> Aber kanns trotzdem schicken, just fyi lol

**2025-09-17 15:26:11** - Julia:
> okay :smile:

**2025-09-17 15:26:12** - Julia:
> dankee

**2025-09-17 16:06:02** - Mert Koc:
> Das ist das Ende des Videos.. denkst du, dass ich einfach dazu schreiben soll bei "Porsche Gipfeltreffen 2025 mit Matthias Malmedie" :thinking_face:

**2025-09-17 16:06:07** - Mert Koc:
> Also quasi das "mit Matthias Malmedie" neu

**2025-09-17 16:06:19** - Mert Koc:
> Weil Flo wollte sowas in der Mail aber keine Details

**2025-09-17 16:15:53** - Julia:
> sorry

**2025-09-17 16:15:57** - Julia:
> hatte kurz IG Action

**2025-09-17 16:16:44** - Julia:
> Ah verstehe. wo würdest du den namen hinpacken?

**2025-09-17 16:18:16** - Mert Koc:
> Weiß nicht, dachte vielleicht hast du ne Idee :melting_face:

**2025-09-17 16:19:23** - Julia:
> würde es unter das Datum

**2025-09-17 16:19:46** - Julia:
> vllt "unter anderem mit ...."

**2025-09-17 16:22:05** - Mert Koc:
> So ?

**2025-09-17 16:22:21** - Mert Koc:
> passt eigentlich sehr gut Visuell auch

**2025-09-17 16:22:31** - Julia:
> u. a. eigentlich

**2025-09-17 16:22:53** - Mert Koc:
> also abgekürzt ?

**2025-09-17 16:23:00** - Julia:
> dann könntest du probieren
u. a. mit
Matthias

**2025-09-17 16:23:11** - Julia:
> Probiers gerne mal – aber finde es so auch schon stimmig

**2025-09-17 16:23:52** - Mert Koc:
> So wäre das dann

**2025-09-17 16:24:01** - Julia:
> ne ih

**2025-09-17 16:24:02** - Julia:
> :smile:

**2025-09-17 16:24:21** - Julia:
> w/
wäre zu social für porsche oder?

**2025-09-17 16:24:40** - Mert Koc:
> ich glaube die checken das nicht :sweat_smile:

**2025-09-17 16:24:48** - Mert Koc:
> und die Zielgruppe wahrscheinlich auch nicht

**2025-09-17 16:36:43** - Julia:
> wahrscheinlich

**2025-09-17 16:37:15** - Julia:
> wooo ist es denn? :slightly_smiling_face:

**2025-09-18 09:09:36** - Mert Koc:
> Die Gipfeltreffen PSD liegt jetzt hier: <https://drive.google.com/drive/folders/1tIQugcxuigtB1ukTFc55O-zUavxvx580?usp=drive_link>
Sorry, war gestern spät dran und konnte nicht mehr hochladen.

**2025-09-18 09:18:39** - Mert Koc:
> Ich habe dir auch noch die einzelnen EPS die ich raus extrahiert habe aus dem Keyvisual abgelegt.

**2025-09-18 09:27:49** - Julia:
> all good, Dankee! Schau ich mir jetzt gleich an :) 

**2025-09-18 09:27:53** - Julia:
> alles gut bei dir? 

**2025-09-18 09:31:11** - Mert Koc:
> Ja ^^

**2025-09-18 09:31:14** - Mert Koc:
> Und bei dir ?

**2025-09-18 09:34:26** - Julia:
> Ja auch. Immer noch schockiert über diese Feedback Prozesse :joy: 

**2025-09-18 09:36:03** - Mert Koc:
> Jaa :melting_face:

**2025-09-18 10:32:20** - Julia:
> liebeeee die Idee

**2025-09-18 10:33:33** - Mert Koc:
> Die waren so ganz anders als IAA Grid, deshalb habe ichs abandoned haha

**2025-09-18 10:34:13** - Julia:
> ja aber die Idee ist mega :heart:

**2025-09-18 11:33:13** - Mert Koc:
> Brauche deine Meinung dazu.
Denkst du wir sollten den Text aus den Stories auch in den Feedpost rein machen?
Ich finde, das passt gar nicht und gibt sehr Konzern/ AD Vibes aber was ist deine Meinung?
Und dann haben wir es halt auch doppelt, was nicht so viel Sinn macht wie ich finde. Wir könnten den Text aus der Story auch einfach in die Caption packen.

**2025-09-18 11:39:46** - Julia:
> moooment

**2025-09-18 11:40:54** - Julia:
> ne, wenn nur das titelbild mit text

**2025-09-18 11:41:21** - Julia:
> background info für dich: das Turbo Carousel von der IAA jetzt war unsere Initiative und ist der best best best performer

**2025-09-18 11:42:05** - Julia:
> wir könnten also 2 versionen für das titelbild zeigen und sagen 1x ohne Text, 1x mit Text --&gt; mit Text wäre interessant um zu gucken, ob texte wirklich so einen großem Impact haben wie beim Turbo Carousel

**2025-09-18 11:42:47** - Julia:
> Würde den Text dann visuell wie beim Carousel anlegen und vllt zweizeilig gehen
Rennlegende
911 GT3 R

**2025-09-18 11:43:05** - Mert Koc:
> Gute Idee mit dem Testen :raised_hands::skin-tone-3:
Dann haben wir die Info auch für die Zukunft

**2025-09-18 11:44:31** - Julia:
> genau!

**2025-09-18 11:44:42** - Julia:
> Pack das gerne dann mit in die Asana Task oder Präsi :slightly_smiling_face:

**2025-09-18 12:16:21** - Mert Koc:
> Sollen wir hier dann einfach den Text der Stories als Caption nutzen? :thinking_face:

**2025-09-18 12:17:26** - Julia:
> Nee. Kannst du mir die Texte nochmal schicken? Dann kürze ich es :slightly_smiling_face:

Zum Titelbild: Die Typo so wie beim Carousel setzen, sah doof aus?
Würde gerne vermeiden, dass wir jetzt mit Text arbeiten im Feed und alles anders aussieht

**2025-09-18 12:17:55** - Mert Koc:
> Ja, Moment ich schicke dir gleich alle drei

**2025-09-18 12:18:52** - Mert Koc:
> Kann ich so setzen :+1::skin-tone-3: mach ich gleich

**2025-09-18 12:19:54** - Mert Koc:
> Hier sind die Texte: <https://www.canva.com/design/DAGuwILJwac/V8FYbooOUuKrZbdwEwno7w/edit?utm_content=DAGuwILJwac&amp;utm_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton|https://www.canva.com/design/DAGuwILJwac/V8FYbooOUuKrZbdwEwno7w/edit?utm_content=DA[…]m_campaign=designshare&amp;utm_medium=link2&amp;utm_source=sharebutton>
Hier die Porsche Sharepoint PPT: <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BC17F1481-2ED8-47B7-857B-E389345FD62C%7D&amp;file=2025-07-25%20Wallpaper%20Fortsetzung%20nach%20It%60s%20911%20o%20clock.pptx&amp;action=edit&amp;mobileredirect=true|2025-07-25 Modell der Woche Weiterführung.pptx>

**2025-09-18 12:20:17** - Julia:
> canvaaaaa ahh

**2025-09-18 12:20:25** - Mert Koc:
> Ja das ist alt ^^

**2025-09-18 12:23:41** - Julia:
> hab zugriff angefordert. weißt du wer das bekommt?

**2025-09-18 12:29:28** - Julia:
> *Version "History":* 
*Seit 2006 über 100 Siege – und jetzt Kino-Star: der 911 GT3 R im Brad Pitt „F1“ Kinofilm.*

Version "Short":
Rennstrecke trifft Leinwand: Der 911 GT3 R.

Version "Legende":
Legende auf dem Asphalt, Star im F1-Film mit Brad Pitt: 911 GT3

*Version "Sieger":* 
*911 GT3 R – gebaut für Siege, gefeiert im Film: F1 mit Brad Pitt.*

**2025-09-18 12:29:37** - Julia:
> hab meine Favoriten fett markiert – you decide

**2025-09-18 12:39:51** - Mert Koc:
> Weiß ich leider nicht :confused:

**2025-09-18 12:44:36** - Julia:
> legst dus dann in die Präsi? :slightly_smiling_face:

**2025-09-18 12:47:28** - Mert Koc:
> Ja :+1::skin-tone-3:
Kannst du mir dann gleich bei den anderen Modellen auch helfen?
Da mache ich auch gerade die 3x4 Posts
Die sind auf den Seiten 4&amp;5 auf der Canva Präsi

**2025-09-18 12:48:26** - Julia:
> 959 und taycan meinst du oder?

**2025-09-18 12:49:21** - Julia:
> oder müssen alle Posts gemacht werden?

**2025-09-18 12:49:51** - Julia:
> welche asana task ist das?

**2025-09-18 12:49:58** - Julia:
> sorry so viele fragen, ich versteh so viel noch nicht :smile:

**2025-09-18 12:51:29** - Julia:
> got it!

**2025-09-18 12:57:30** - Mert Koc:
> Genau nur noch 959 und taycan, weil die anderen beiden sind nicht in der Sharepoint

**2025-09-18 12:58:00** - Mert Koc:
> Hab dich in Asana markiert.

**2025-09-18 13:16:38** - Julia:
> Hab Hanna geschrieben

**2025-09-18 13:17:42** - Julia:
> bin dran

**2025-09-18 13:21:27** - Mert Koc:
> Danke :heart_hands::skin-tone-3:

**2025-09-18 13:22:08** - Mert Koc:
> habs jetzt angeglichen

**2025-09-18 13:22:49** - Julia:
> cool! Lass uns mal kurz abwarten bis zu den anderen 2, ob das alles dann passt

**2025-09-18 13:23:00** - Julia:
> sonst war der turbo s einfach ein einzelgänger

**2025-09-18 13:26:46** - Julia:
> 959:

_*Version Traumwagen:*_
_*Ob Rennstrecke oder Straße: Der 959 ist Kult, Ikone und Traumwagen zugleich.*_

Version Unicorn:
German Unicorn – so nennt Jerry Seinfeld den 959. Eine Ikone, die Rennsport und Traumwagen-Status vereint.

Version Details:
Rennsport-Performance mit Kultstatus: der 959. Mit 317 km/h einer der schnellsten Serienwagen der 80er und einer der begehrtesten Sammelstücke bis heute.

_*Version Wortwitz:*_
_*The Last Unicorn? Der 959. Einer der begehrtesten Sportwagen seiner Zeit – und bis heute eine lebende Legende.*_

**2025-09-18 13:31:52** - Julia:
> Taycan:

Version Short:
Taqycan Turbo S: 911 DNA. Future Power.

Version Zukunft:
911-DNA trifft auf Elektropower: Der Taycan Turbo S bringt die Zukunft auf die Straße.

_*Version Feelings:*_
_*Zukunft fahren, Porsche fühlen: der Taycan Turbo S – Beschleunigung, die sich nach Zukunft anfühlt.*_

**2025-09-18 13:33:26** - Julia:
> Würde beim Taycan tatsächlich nicht wieder Performance Pionier sagen. Was meinst du?
eher Innovationstreiber, Impulsgeber, Vorreiter..

**2025-09-18 13:36:32** - Mert Koc:
> Es sind jetzt alle in der Präsi: <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BC17F1481-2ED8-47B7-857B-E389345FD62C%7D&amp;file=2025-07-25%20Wallpaper%20Fortsetzung%20nach%20It%60s%20911%20o%20clock.pptx&amp;action=edit&amp;mobileredirect=true|2025-07-25 Modell der Woche Weiterführung.pptx>
Du kannst ja mal entscheiden, was du besser fidnest Visuell von der Schrift her ^^

**2025-09-18 13:36:48** - Julia:
> Ja ich kanns leider nicht sehen.. so nervig

**2025-09-18 13:36:55** - Julia:
> magst du mir screenshots schicken?

**2025-09-18 13:36:56** - Mert Koc:
> Achsoo stimmt ja sorry

**2025-09-18 13:37:05** - Julia:
> dann schau ich noch kurz, danach muss ich mit Coco raus :slightly_smiling_face:

**2025-09-18 13:39:15** - Mert Koc:
> 

**2025-09-18 13:39:26** - Mert Koc:
> 

**2025-09-18 13:39:36** - Mert Koc:
> 

**2025-09-18 13:40:05** - Julia:
> Hmm ne da müssen wir gleich nochmal überlegen. würde max. 2 zeilig

**2025-09-18 13:41:12** - Mert Koc:
> ok :+1::skin-tone-3:
Sonst können wir auch einfach das "Performance Pionier" ändern. Keine Ahnung wieso das auch 2 mal vorkommt fällt mir gerade erst auf

**2025-09-18 13:41:23** - Mert Koc:
> Glaub das hat Roxanne gemacht

**2025-09-18 13:41:28** - Julia:
> ja genau, das meinte ich

**2025-09-18 13:41:40** - Julia:
> hier :slightly_smiling_face: <@U093J779DAQ>

**2025-09-18 13:41:53** - Julia:
> schau gerne mal was gut reinpasst. bis gleich! :slightly_smiling_face:

**2025-09-18 13:53:40** - Mert Koc:
> So jetzt haben wirs erst mal :slightly_smiling_face:

**2025-09-18 14:49:28** - Julia:
> sehr cool!

**2025-09-18 14:49:30** - Julia:
> Mag ich

**2025-09-18 14:51:43** - Julia:
> Du eine Frage

**2025-09-18 14:51:50** - Julia:
> wo sind denn noch mehr dieser Retro Bilder? <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/doc2.aspx?sourcedoc=%7BA5F304E8-09BC-47AB-A30A-5A86F7C81AD3%7D&amp;file=250904_Porsche_BS_RetroSunday.pptx&amp;action=edit&amp;mobileredirect=true|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/doc2.aspx?sourcedoc=%7BA5F30[…]rsche_BS_RetroSunday.pptx&amp;action=edit&amp;mobileredirect=true>

**2025-09-18 14:53:13** - Mert Koc:
> ähmm.. das ist ganz schlimm immer iwie in der unendlichen Welt der Porsche Datenbanken. Ich such mal

**2025-09-18 14:54:26** - Julia:
> guck mal das hattest du gemacht oder?

**2025-09-18 14:54:57** - Mert Koc:
> ja :+1::skin-tone-3:

**2025-09-18 14:55:47** - Julia:
> schicks mir gerne, dann schreib ich ihr zurück

**2025-09-18 14:56:14** - Julia:
> ach ne ich kann schauen :slightly_smiling_face: wo nochmal? :smile:

**2025-09-18 14:56:57** - Mert Koc:
> Hab ich schon

**2025-09-18 14:57:05** - Julia:
> ahh okay perfekt!

**2025-09-18 14:57:07** - Mert Koc:
> Das ist erledigt

**2025-09-18 14:57:10** - Julia:
> juhuu

**2025-09-18 14:58:38** - Julia:
> 

**2025-09-18 14:59:56** - Mert Koc:
> Ich habs gefunden: <https://porsche.sharepoint.com/sites/PDMK/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FPDMK%2FShared%20Documents%2FGeneral%2FUMZUG%2FKampagnen%2F%5FVKR%20MY%2025%2FTINS%2FAlte%20Anzeigen%2Fvon%20Museum&amp;viewid=6340b967%2Dd3d5%2D401d%2D9687%2D73af93fd1ecf&amp;csf=1&amp;web=1&amp;e=gUeQ59&amp;ovuser=56564e0f%2D83d3%2D4b52%2D92e8%2Da6bb9ea36564%2Cjulia%2Ehallhuber%40boldcreatorsclub%2Ecom&amp;OR=Teams%2DHL&amp;CT=1756120940332&amp;clickparams=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiI1MC8yNTA3MzExNzQxMCIsIkhhc0ZlZGVyYXRlZFVzZXIiOmZhbHNlfQ%3D%3D&amp;CID=3d32bfa1%2D60a3%2Dd000%2De737%2Daa92c95b626b&amp;cidOR=SPO&amp;FolderCTID=0x012000B0A40330D7B2464BB054061397BEF042|PDMK - Dokumente - von Museum - Alle Dokumente>

**2025-09-18 15:00:32** - Julia:
> liegen da welche bei dir drin? bei mir ist alles leer

**2025-09-18 15:00:36** - Julia:
> :face_exhaling: es nervt

**2025-09-18 15:01:16** - Julia:
> ah habe keine berechtigung

**2025-09-18 15:01:26** - Mert Koc:
> Das wurde gepostet. Zwar komplett abgeschnitten aber Freigegeben und gepostet.
alle anderen Vorschläge wurden jetzt noch abgeleht (obwohl wir das Material von denen haben) ?????
Anyway.

**2025-09-18 15:01:33** - Mert Koc:
> Die wurden abgeleht:

**2025-09-18 15:01:53** - Julia:
> ah okay, got it

**2025-09-18 15:01:56** - Julia:
> wow :smile:

**2025-09-18 15:02:01** - Julia:
> gut, dann mach ich neue

**2025-09-18 15:02:16** - Mert Koc:
> Deswegen müssen wir neue Vorschlagen.
Die hier hat Julia einfach mal reingezogen. Aber das sind nur Screenshots und haben keien Freigabe oder so. Nur random

**2025-09-18 15:02:23** - Julia:
> kannst du mir ein paar der fotos runterladen und schicken? sorry ey. irgendwie reagiert auch keiner auf die anfragen

**2025-09-18 15:02:35** - Julia:
> okay got it!

**2025-09-18 15:02:48** - Julia:
> dankeee für deine hilfe!

**2025-09-18 15:03:03** - Mert Koc:
> Ja das ist eigentlich voll :melting_face:
Ich kann dir alle runterladen, die in der Präsi sind, die du gut findest.

**2025-09-18 15:03:26** - Julia:
> ach mist

**2025-09-18 15:03:34** - Julia:
> oder kannst du mir den ordner runterladen und mit wetransfer schicken?

**2025-09-18 15:04:15** - Mert Koc:
> Yes

**2025-09-18 15:04:23** - Mert Koc:
> Hoffe das klappt

**2025-09-18 15:04:41** - Julia:
> dankeee

**2025-09-18 15:05:49** - Mert Koc:
> Sehr vieles davon wurde schon gepostet. Deswegen muss man immer mit Insta vergleichen :melting_face::melting_face::melting_face:
Weil die alte Agentur das angefangen hat glaube ich.

**2025-09-18 15:05:56** - Mert Koc:
> Hier:

**2025-09-18 15:06:30** - Julia:
> okay got it

**2025-09-18 15:06:38** - Julia:
> ich verarbeite mal Julia's Vorschläge und schau dann

**2025-09-18 15:06:59** - Mert Koc:
> Ja genau. Ich glaube, dass sie welche ausgesucht hat, die noch nicht gepostet wurden.

**2025-09-18 15:07:01** - Julia:
> Könntest du mir einen Gefallen tun? Bei "Asset link", könntest du da, dann die finalen Bilder ablegen?

**2025-09-18 15:08:22** - Mert Koc:
> Die bisherigen liegen da schon. Wenn man auf "Asset link" mit STRG gedrückt drauf klickt, öffnet sich der Link.

**2025-09-18 15:08:31** - Mert Koc:
> Oder was meinst du?

**2025-09-18 15:10:49** - Julia:
> ah okay

**2025-09-18 15:10:59** - Julia:
> dachte da liegt dann immer das eine ab

**2025-09-18 15:20:50** - Julia:
> weißt du wann die Turbo Woche ist?

**2025-09-18 15:21:17** - Mert Koc:
> ne sorry :confused:

**2025-09-18 15:33:17** - Julia:
> schickst du das dann immer direkt an porsche oder macht das julia?

**2025-09-18 15:33:34** - Mert Koc:
> Das macht Julia

**2025-09-18 15:33:39** - Julia:
> okay

**2025-09-18 16:09:44** - Julia:
> so konnte endlich die Präsi öffnen und bin nochmal kurz durchgegangen. Gibts hier evtl noch ein anderes Bild? Finde dieses weiße Muster so aufdringlich :smile:

**2025-09-18 16:11:19** - Julia:
> und hier: ist das 4. Bild stärker, oder?

**2025-09-18 16:15:02** - Mert Koc:
> Ich habe da nur die Fotos genommen, die ich von Roxanne so bekommen habe.

**2025-09-18 16:15:46** - Mert Koc:
> Das 4. Bild als 1. meinst du? Dann ist halt das Theme, dass das 1. Bild das Auto seitlich zeigt nicht mehr durchgängig aber an sich können wir das auch ändern.

**2025-09-18 16:22:05** - Julia:
> das stimmt, aber da wir das beim turbo auch nicht hatten, finde ich es nicht schlimm

**2025-09-18 16:56:20** - Julia:
> FYI: hatten gerade meeting mit porsche zum Gipfeltreffen. hatten 2 Anmerkungen zum Grid + Highlight --&gt; ich pass das schnell an, ja?

**2025-09-18 17:06:39** - Mert Koc:
> Ja gerne :slightly_smiling_face:
Was waren die Anmerkungen?

**2025-09-18 17:07:21** - Mert Koc:
> BTW ich habe hier das Cayenne Extreme Posts angelegt: <https://www.figma.com/design/BWwcc27PwCZj4fJhynHnmV/Cayenne-Extreme?node-id=0-1&amp;p=f&amp;t=OMOC0zUdOW7kFxCz-0>
Wollte mal ausprobieren da zu arbeiten. Für Feedposts ist das wirklich viel leichter.

**2025-09-18 17:07:46** - Mert Koc:
> Habe dafür auch 3 mini Videos geschnitten, die sind da auch drinnen aber idk wie man die abspielt

**2025-09-18 17:07:54** - Julia:
> Amore Motore nicht so präsent links und lieber dort das Gipfeltreffen
Highlight: wollten hier Variante mit nur Schriftzug. Ohne Strecke im Hintergrund - also laaaangweilig

**2025-09-18 17:08:02** - Julia:
> oh okay, schau ich mir gleich mal an :slightly_smiling_face:

**2025-09-18 17:08:24** - Julia:
> ich weiß nur noch ausm stehgreif: dafür benötigt man ein plugin :smile:

**2025-09-18 17:09:10** - Mert Koc:
> ah ok

**2025-09-18 17:25:11** - Julia:
> diese Grid Datei macht mich richtig sauer :smile: wie konntest du da überhaupt drin arbeiten

**2025-09-18 17:25:50** - Mert Koc:
> Die war anfangs noch schlimmer :joy::grin:

**2025-09-18 17:30:33** - Julia:
> ich brauch noch eine sekunde von dir

**2025-09-18 17:30:44** - Julia:
> 

**2025-09-18 17:30:49** - Julia:
> Ich kann ja nicht zugreifen

**2025-09-18 17:30:57** - Julia:
> siehst du ob da noch was liegt

**2025-09-18 17:31:43** - Mert Koc:
> Uuuh ich schau mal

**2025-09-18 17:32:54** - Mert Koc:
> Ich brauche genauere Angaben, wo das liegt, weil das ist sonst nicht auffindbar.

**2025-09-18 17:33:02** - Mert Koc:
> Im Sharepoint ist absolutes Chaos

**2025-09-18 17:33:10** - Julia:
> 

**2025-09-18 17:33:13** - Julia:
> mehr hab ich nicht. ich schau gerade bei drive

**2025-09-18 17:33:22** - Julia:
> walter und malmedie - gt3 talk

**2025-09-18 17:34:00** - Julia:
> stories sind online

**2025-09-18 17:34:09** - Julia:
> vllt kannst du es so zu ordnen?

**2025-09-18 17:34:59** - Mert Koc:
> Habs

**2025-09-18 17:35:04** - Julia:
> geil!

**2025-09-18 17:35:05** - Mert Koc:
> <https://drive.google.com/drive/folders/1HoPwLffxB6eXcSqHhbiEk-iVMx6w7wzc?usp=drive_link>

**2025-09-18 17:35:10** - Mert Koc:
> Hier fehlt die 4. Slide

**2025-09-18 17:35:28** - Mert Koc:
> Du hast Zugriff auf den Insta Acc und kannst das posten oder ?

**2025-09-18 17:35:28** - Julia:
> jaa

**2025-09-18 17:35:30** - Julia:
> perfekt

**2025-09-18 17:35:53** - Julia:
> Brand Store nicht aber glaub das kann Julia jetzt machen. Sie konnte nur nicht auf den Drive zugreifen

**2025-09-18 17:36:11** - Mert Koc:
> Ok soll ichs ihr senden ?

**2025-09-18 17:36:20** - Julia:
> habs ihr geschickt

**2025-09-18 17:36:22** - Julia:
> DANKE :smile:

**2025-09-18 17:36:28** - Mert Koc:
> Pörfekt

**2025-09-18 17:36:58** - Julia:
> im sharepoint finden wir es nicht oder? bzw in einer präsi

**2025-09-18 17:37:17** - Mert Koc:
> Quasi unmöglich :sweat_smile:

**2025-09-18 17:37:22** - Mert Koc:
> Außer man sucht ne halbe Stunde

**2025-09-18 17:37:24** - Julia:
> okay :smile: super

**2025-09-18 17:38:28** - Julia:
> happy feierabend!

**2025-09-18 17:38:51** - Mert Koc:
> Danke! Dir auch

**2025-09-19 09:41:12** - Julia:
> Guten Morgen! :slightly_smiling_face:

**2025-09-19 09:41:55** - Julia:
> Meinst du, du schaffst es mir die Styleguide Visualisierung fertig zu machen? Das wäre super, weil wir es vorm Gipfeltreffen nochmal an Porsche schicken müssen

**2025-09-19 09:45:25** - Mert Koc:
> Guten Morgen :slightly_smiling_face:
Yes ich denke, dass ich das schaffe

**2025-09-19 09:50:33** - Julia:
> juhuuuu

**2025-09-19 10:28:04** - Mert Koc:
> Brauche dein Feedback. (Sind nur Entwürfe, nicht erschrecken)
Porsche will, dass <https://drive.google.com/file/d/1Aa8Z-65h3MqCvcQ9pbjyrKlkWCcUAgYn/view?usp=drive_link|dieses Video> mit der "Gipfeltreffen CI" endet. Wie soll ich es deiner Meinung nach enden lassen? Fullscreen CI oder nur die Schrift + Infos ?

**2025-09-19 10:30:58** - Julia:
> 

**2025-09-19 10:42:55** - Mert Koc:
> All right, danke fürs Feedback.
Das mit der Straße und Auto wird schwer, wegen Schutzbereichen und IG Interface...

**2025-09-19 10:43:47** - Julia:
> ja das stimmt. wäre mMn nicht schlimm, wenn das etwas verdeckt ist weil es ja nur ein detail ist

**2025-09-19 10:44:04** - Julia:
> Vllt beommst du irgendwie unter stay tuned noch das auto?

**2025-09-19 10:51:12** - Mert Koc:
> How is this? :grimacing:

**2025-09-19 10:51:49** - Julia:
> würde den text noch etwas hochziehen. dann steht "stay tuned" sogar auf der straße, dann perfekt

**2025-09-19 10:53:46** - Mert Koc:
> 

**2025-09-19 10:57:00** - Julia:
> ich mags!

**2025-09-19 10:57:45** - Mert Koc:
> Ich auch :slightly_smiling_face:

**2025-09-19 11:12:50** - Mert Koc:
> Ich muss das IG Overlay neu machen für den Styleguide, weil das nicht abliegt, just fyi

**2025-09-19 11:26:51** - Julia:
> oh manno

**2025-09-19 11:26:57** - Julia:
> okay :face_with_peeking_eye: danke!

**2025-09-19 12:17:24** - Mert Koc:
> Ich glaube wir müssen mit Basti dann nochmal wegen Texten und größen etc. bei Reels und Shorts reden. :thinking_face:
Mir persönlich sind die Schriften zu groß und zu nah an den Sachen drum herum.

**2025-09-19 12:17:39** - Mert Koc:
> Aber für jetzt sollte es hoffentlich passen :sweat_smile:

**2025-09-19 12:17:58** - Julia:
> ja seh ich auch so

**2025-09-19 12:18:15** - Julia:
> könntest du mir einen gefallen tun? magst du einmal einen Screenshot reinlegen, von den letzten reels der IAA?

**2025-09-19 12:18:41** - Julia:
> Würde gerne kontrollieren, ob das passt. hatte nämlich das gefühl, dass hier einfach irgendwie reingesetzt wurde

**2025-09-19 12:22:01** - Mert Koc:
> Passt halbwegs

**2025-09-19 12:22:30** - Julia:
> puh, vbws passen ja garnicht :smile:

**2025-09-19 12:22:41** - Mert Koc:
> Die VBWs passen nicht aber es kann auch sein, dass die in der Vorlage von Basti nicht stimmen. Weil die Schutzlinien in seiner Vorlage mir zu nah vorkamen. Muss ich mal checken

**2025-09-19 12:24:08** - Julia:
> okay

**2025-09-19 12:24:18** - Julia:
> Magst du dir das mal anschauen?

**2025-09-19 12:24:41** - Julia:
> Das Thema ist wir sollten das fürs Gipfeltreffen jetzt einheitlich machen bzw. der Produktion liefern können

**2025-09-19 12:24:54** - Julia:
> dafür benötigen die halt dann auch die richtigen Premiere Angaben

**2025-09-19 12:26:12** - Julia:
> <https://drive.google.com/drive/folders/1Uqfsv2dzOxUL2lpnQUGXIqSmga7tscPP>

mit gestrigem Datum. schaus dir gerne mal an, weil dann müssten wir natürlich die screenshots alle nochmal austauschen für die premiere spezifikationen

**2025-09-19 12:30:04** - Mert Koc:
> 

**2025-09-19 12:32:20** - Mert Koc:
> Der blaue Würfel ist 1080 x 1920 aber das Video dahinter ist länger aber wurde auch mit 1080x1920 exportiert. :sweat_smile:
Das macht die ganze Sache etwas Tricky.
Es wird quasi alles etwas größer und auch näher an die Ränder gezogen, sobald IG das einfach langzieht und an den Seiten abschneidet

**2025-09-19 12:32:53** - Mert Koc:
> Hier sieht man jetzt, was IG abschneidet :thinking_face:

**2025-09-19 12:33:03** - Julia:
> puuh, okay got it

**2025-09-19 12:34:02** - Julia:
> okay das ist echt smart von dir. danke, dass du es gecheckt hast!

**2025-09-19 12:34:40** - Julia:
> also eigentlich bedeutet es die videos sind am ende länger als unsere vorlage, right?

**2025-09-19 12:35:57** - Mert Koc:
> Ja das was zu sehen ist, ist länger. Es bedeutet aber auch, dass wir die Schutzzonen rechts und links viel größer machen müssen, weil IG da so viel wegschneidet und die Untertitel dann fast die Like Herzen berühren und die VBWs dann im Profilbild landen...

**2025-09-19 12:38:36** - Julia:
> 

**2025-09-19 12:39:14** - Mert Koc:
> Ich werd gerade bisschen Crazy

**2025-09-19 12:39:40** - Mert Koc:
> Aber ich mache das jetzt, weil wir müssen das lösen :sweat_smile:

**2025-09-19 12:43:06** - Julia:
> :joy:

**2025-09-19 12:43:11** - Julia:
> ich verstehs so

**2025-09-19 12:49:40** - Mert Koc:
> Würde so die Schutzzonen machen.
hab auch Headline und Subline auf die gleiche Größe reduziert.
Und Untertitel kleiner gemacht.
Das Porsche Profil ist btw maximal weil oben bei dem Beispiel, also weiter gehts nicht, deshalb die VBWs so nah da unten.

**2025-09-19 12:50:24** - Julia:
> du meinst wegen caption usw.?

**2025-09-19 12:50:39** - Mert Koc:
> Genau. Ich schicke dir kurz ein Bsp

**2025-09-19 12:50:44** - Julia:
> perfekt

**2025-09-19 12:52:04** - Mert Koc:
> Hab auch gleich das neue Reposting Symbol mit rein genommen in die Schutzzone:

**2025-09-19 12:53:09** - Mert Koc:
> Die neuen Text-Platzierungen und Schutzzonen die wir Vorschlagen sind viel besser.

**2025-09-19 12:53:41** - Mert Koc:
> Weil da sieht man, wie unpassend die Texte platziert wurden.

**2025-09-19 12:56:00** - Julia:
> ahh perfekt 

**2025-09-19 12:56:21** - Julia:
> Ja stimmt 

**2025-09-19 12:56:44** - Julia:
> weil praktisch wäre es wenn es von Instagram direkt so eine Vorlage gäbe 

**2025-09-19 12:57:05** - Mert Koc:
> Das wäre ein Traum

**2025-09-19 12:57:27** - Mert Koc:
> Ich Verkauf die Vorlage dann auch bei Etsy für 15€ :joy::joy::joy:

**2025-09-19 12:57:43** - Julia:
> :joy:  

**2025-09-19 12:57:47** - Julia:
> auf jeden Fall 

**2025-09-19 13:00:43** - Julia:
> okay also setzt du dann die neuen screenshots ein?

**2025-09-19 13:01:29** - Mert Koc:
> Ja wenn ich es schaffe mache ichs gerne. Aber sobald die Videos aus dem Brandstore kommen, muss ich das machen.

**2025-09-19 13:01:39** - Mert Koc:
> Ich passe gerade noch die Vorlage an..

**2025-09-19 13:01:59** - Julia:
> ja alles gut, sag einfach bescheid

**2025-09-19 13:02:24** - Julia:
> bzw. ich kanns auch einsetzen, ich bräuchte nur von dir dann die ganzen premiere screenshots

**2025-09-19 13:39:08** - Mert Koc:
> Muss ich die Präsi vom Styleguide runterladen oder haben wir eine im Drive?

**2025-09-19 13:39:30** - Julia:
> hier <@U093J779DAQ>

**2025-09-19 13:40:32** - Mert Koc:
> Wenn ich die doppelklicke, muss ich sie runterladen

**2025-09-19 13:40:51** - Mert Koc:
> 

**2025-09-19 13:41:43** - Julia:
> oh gott das nervt so

**2025-09-19 13:41:52** - Julia:
> ja magst du das machen und dann wieder hochladen?

**2025-09-19 13:42:07** - Julia:
> ich check dann nochmal alles

**2025-09-19 13:42:15** - Mert Koc:
> Oder kannst du mir nen Link zum teilen schicken, vielleicht geht es so

**2025-09-19 13:46:21** - Mert Koc:
> Die Datei ist iwie kaputt

**2025-09-19 14:04:45** - Mert Koc:
> Bräuchte die Pr

**2025-09-19 14:04:55** - Mert Koc:
> Präsi glaube direkt von dir geschickt.

**2025-09-19 14:08:53** - Julia:
> omg

**2025-09-19 14:08:55** - Julia:
> moment

**2025-09-19 14:12:40** - Julia:
> ich weiß nicht warum aber das dauert gerade 300 jahre

**2025-09-19 14:13:50** - Julia:
> liegt jetzt sonst mt heutigem datum auch nochmal ab: <https://drive.google.com/drive/folders/1Uqfsv2dzOxUL2lpnQUGXIqSmga7tscPP>

**2025-09-19 14:15:03** - Julia:
> 

**2025-09-19 14:19:07** - Julia:
> klappts?

**2025-09-19 14:26:48** - Mert Koc:
> Ja :+1::skin-tone-3:

**2025-09-19 14:27:02** - Mert Koc:
> Ich bin nur kurz essen.. verhungere gerade

**2025-09-19 14:30:04** - Julia:
> ja klar, bitte mach das

**2025-09-19 15:11:12** - Mert Koc:
> Hier die neue Version. Habe eine Folie mit Subline durchgestrichen, weil wir die nicht mehr brauchen eigentlich.

**2025-09-19 15:15:38** - Julia:
> du bist ein Schatz!!

**2025-09-19 15:15:48** - Julia:
> WOW, danke!

**2025-09-19 15:17:21** - Julia:
> :heart:

**2025-09-19 15:17:35** - Mert Koc:
> Bitte :slightly_smiling_face:

**2025-09-22 15:49:50** - Julia:
> Helloo

**2025-09-22 15:50:05** - Julia:
> Kommst du heute zum Dinner/ Drinks? :slightly_smiling_face:

**2025-09-22 15:51:18** - Mert Koc:
> Yes :grin:

**2025-09-22 15:51:22** - Mert Koc:
> Und du ?

**2025-09-22 15:51:23** - Julia:
> juhuu

**2025-09-22 15:51:25** - Julia:
> Ja

**2025-09-22 15:51:29** - Julia:
> bin schon im Büro

**2025-09-22 15:51:36** - Mert Koc:
> Achso :slightly_smiling_face:

**2025-09-22 15:51:40** - Mert Koc:
> Sind alle schon da ?

**2025-09-22 15:51:56** - Julia:
> Fast

**2025-09-22 15:52:00** - Julia:
> Magst auch schon vorbeikommen?

**2025-09-22 15:53:38** - Mert Koc:
> Theoretisch kann ich schon gleich kommen. Hab eh nicht mehr so viel heute.
Seid ihr voll mit Arbeit?

**2025-09-22 15:54:18** - Julia:
> Ja kein Stress

**2025-09-22 15:54:30** - Julia:
> Warte ab, ich hab paar Sachen für dich :smile:

**2025-09-22 15:54:35** - Mert Koc:
> Aber ihr habt ja auch noch 16:30 Meeting

**2025-09-22 15:54:43** - Julia:
> wir haben um 16.30 - 17.30 noch einen Termin

**2025-09-22 15:54:45** - Julia:
> Ja eben

**2025-09-22 15:55:19** - Julia:
> Denke der wird nicht bis 17.30 gehen, weil eh alle krank sind

**2025-09-22 15:59:09** - Mert Koc:
> Ja ich denke ich würde so 17-17.30 kommen :slightly_smiling_face:

**2025-09-22 15:59:21** - Julia:
> juhuu oke

**2025-09-22 15:59:27** - Julia:
> hab auch schon hunger hahaha

**2025-09-22 16:34:54** - Julia:
> Mert, ich bräuchte morgen etwas von deiner Zeit. Hast du gerade Kapa?

**2025-09-22 16:36:09** - Mert Koc:
> Ja habe ich :slightly_smiling_face:

**2025-09-22 16:36:14** - Mert Koc:
> Gerne

**2025-09-22 16:37:57** - Mert Koc:
> Hab die Story Highlight Anpassung vom Brandstore gesehen.. finde ich sehr gut. Laetitia und mir ist das auch schon aufgefallen, dass die ein Update brauchen.
ich würde auch gerne die Weekly Hiighlights im gleichen Zug updaten wenn das in Ordnung ist. Finde die zum Teil auch sehr unruhig, da alles sehr groß und in Großbuchstaben ist

**2025-09-22 16:38:28** - Julia:
> Ja perfekt

**2025-09-22 16:38:30** - Julia:
> jaa total!

**2025-09-22 16:38:38** - Julia:
> Hab ich auch als nächstes auf dem Zettel stehen :slightly_smiling_face:

**2025-09-22 17:08:46** - Julia:
> diese Kommentare hast du schon gesehen oder?
<https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BC17F1481-2ED8-47B7-857B-E389345FD62C%7D&amp;file=2025-07-25%20Wallpaper%20Fortsetzung%20nach%20It%60s%20911%20o%20clock.pptx&amp;action=edit&amp;mobileredirect=true|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BC17F14[…]0s%20911%20o%20clock.pptx&amp;action=edit&amp;mobileredirect=true>

**2025-09-22 17:20:40** - Mert Koc:
> ah danke, hab keine Benachrichtigung dazu bekommen

**2025-09-22 17:21:05** - Mert Koc:
> Seid ihr schon ready to go? Oder dauerts noch bei euch? Weil sonst mache ich das mit dem Modell der Woche jetzt noch :slightly_smiling_face:

**2025-09-22 17:21:42** - Julia:
> Julia ist noch nicht da..

**2025-09-22 17:21:47** - Julia:
> die wurde dauernd aufgehalten

**2025-09-22 17:21:51** - Julia:
> sitzen aber leider noch im call

**2025-09-22 17:23:39** - Mert Koc:
> alles klar, dann fange ich mal mit dem Feedback an

**2025-09-23 09:19:52** - Julia:
> Hey, guten Morgen! Mich hats heute nacht mit Migräne erwischt :face_with_peeking_eye: ich bin immer noch nicht fit und hab soo starke Kopfschmerzen, deswegen werde ich die Calls ausfallen lassen müssen. Ich schau, dass ich später wieder fit bin.
Aber falls du sonst schon mal Zeit hast &amp; es für dich ohne eine Erklärung auch schon sinn ergibt:

Die Präsentation die ich dir angehängt hab, haben wir Hanna vorgestellt. Ideen für neue Postings und Posting Reihen, wie zB dieser Store Rundgang. Sie wollte jetzt natürlich, dass wir alles einmal checken bezüglich Content und auch schon was umsetzen. In dem Fall wäre der Store Rundgang aber wichtigsten. Ich würde mir hier für den Start der Reihe immer eine kleine eine Art Animation wünschen, bei der man den "Grundriss" vom Store als Illustration sieht und man mit einer Stecknadel/ Markierung erkennt, wo man sich befindet (Ich sag nur Karte des Rumtreibers von Harry Potter, falls du das kennst :smile:). Also die Markierung darf sich gerne zum Zielort bewegen. Dazu bräuchten wir natürlich Material von Hanna, evtl. könnte Julia das schon mal anfragen..

**2025-09-23 09:27:47** - Mert Koc:
> Oh gute Besserung!!

Ja das Ergibt Sinn, danke für die Erklärung. Dann frag ich mal via. Julia den Grundriss oder ähnliches an.
Was meinst du mit "Content checken und umsetzen" ? Denkst du, dass wir bereits Material haben, mit dem wir eines dieser Formate anfangen können?
Mir kommen die schon sehr speziell vor und evtl. brauchen wir da extra Material. Aber ichs schaus mir nochmal an..

**2025-09-23 12:39:46** - Julia:
> danke dir :heart:

**2025-09-23 12:41:23** - Julia:
> Ja genau. Man müsste echt schauen was man davon jetzt schon umsetzen kann. Also zB diese Konfigurationsthemen oder die Turbo/ Targa Posts mit Splitscreens..

**2025-09-25 12:47:25** - Mert Koc:
> 

**2025-09-25 13:04:40** - Mert Koc:
> <https://vmmedia.porsche.de/prod/vmmedia/BasicData.nsf/press/PAGdeWelcome0?OpenDocument&amp;Login|Dr. Ing. h.c. F. Porsche AG VM Mediendatenbank>
<https://newsroom.porsche.com/en/media-search.html?type=undefined&amp;page=1&amp;keyword=&amp;category=&amp;content=undefined&amp;date=&amp;dateFrom=&amp;dateTo=|Media Search - Porsche Newsroom>

**2025-09-25 13:09:18** - Mert Koc:
> 

**2025-09-25 13:39:05** - Julia:
> 

**2025-09-25 13:39:51** - Julia:
> <https://www.figma.com/design/JrbypsbvDwTvRRgwvqhdvd/Porsche-BS-%F0%9F%9B%8D%EF%B8%8F?node-id=0-1&amp;p=f&amp;t=tYh4gyFkz2fsD73m-0>

**2025-09-25 13:39:58** - Julia:
> <https://www.figma.com/design/902cDjeQLIyg77xt49VdZg/Porsche-DE-%F0%9F%8F%8E%EF%B8%8F?node-id=1-247&amp;t=AuTFbNdgZZuujMA3-0>

**2025-09-25 15:11:40** - Julia:
> figma soweit klar? :slightly_smiling_face:

**2025-09-25 15:21:42** - Mert Koc:
> Wait ich hörs mir gleich zuende an ^^
hatte aufeinmal aufhören müssen wegen irgendwas

**2025-09-25 15:27:30** - Julia:
> man kennts

**2025-09-25 15:36:45** - Mert Koc:
> Ja, finde ich sehr gut :+1::skin-tone-3:

**2025-09-25 15:42:05** - Mert Koc:
> Machen wir dann quasi zu jedem neuen Thema ne neue Page?

**2025-09-25 15:42:32** - Mert Koc:
> Weil der Wiesn Post wäre jetzt Bsw. nur eine einzige Slide :sweat_smile:

**2025-09-25 15:43:17** - Julia:
> Würde ich schon machen. Wir können uns dann überlegen, ob wir bei so Single posts das dann eher als "Lückenfüller" oder so benennen

**2025-09-25 15:45:10** - Mert Koc:
> Also eine Page für Singleposts quasi?

**2025-09-25 15:46:08** - Julia:
> genau

**2025-09-25 16:51:00** - Mert Koc:
> Hab in Figma die Templates für BS und PDE angepasst.
• sortiert
• benannt, damit man beim kopieren nur noch Datum und "Template" und nummer austauschen muss
• und Mockups mit rein :slightly_smiling_face: 

**2025-09-26 09:08:17** - Mert Koc:
> 

**2025-09-26 09:39:45** - Julia:
> dankeee

**2025-09-26 09:39:55** - Julia:
> ein traaaaaaum

**2025-09-26 09:42:17** - Julia:
> 

**2025-09-26 09:43:54** - Julia:
> <https://app.asana.com/1/1199360402832734/task/1210556034500746/comment/1211467593411918?focus=true>

**2025-09-26 09:47:41** - Mert Koc:
> Ja kann ich gerne machen, nur wo muss ich das hochladen? Hast du da zufällig nen Link für mich?

**2025-09-26 09:48:28** - Julia:
> Ja gute Frage. Kannst du einen Ordner anlegen im sharepoint? Ich kanns ja nicht sehen

**2025-09-26 09:49:34** - Mert Koc:
> Das Problem ist, das Sharepoint is absolutes Chaos und auf manche Ordner habe ich auch keinen Zugriff.
ich weiß auch gar nicht, wie Julia das immer hochgeladen hat. Aber ich suche mal kurz, vielleicht finde ich ja was.

**2025-09-26 09:50:00** - Julia:
> ja verstehe. an sich ist es evtl auch erstmal egal, hauptsache sie sehen es :smile:

**2025-09-26 09:53:35** - Mert Koc:
> Ich habs tatsächlich gefunden lol

**2025-09-26 09:54:00** - Mert Koc:
> Dieses Video soll da rein ?

**2025-09-26 10:01:11** - Mert Koc:
> Hab das Video hier hochgeladen: <https://porsche.sharepoint.com/:f:/r/sites/PDMK/Shared%20Documents/General/UMZUG/Digitales%20Marketing/Social/Insta/08_Redaktionsplanung/Contents/2025/09_September/Christo_Leonie%20Beck/250926_Porsche_DE_Leonie-BeckxChristo-Ruf%20der%20Freiheit_Video_01?csf=1&amp;web=1&amp;e=bI662F|250926_Porsche_DE_Leonie-BeckxChristo-Ruf der Freiheit_Video_01>

**2025-09-26 10:01:44** - Mert Koc:
> So nochmal ausgeschrieben: <https://porsche.sharepoint.com/:f:/r/sites/PDMK/Shared%20Documents/General/UMZUG/Digitales%20Marketing/Social/Insta/08_Redaktionsplanung/Contents/2025/09_September/Christo_Leonie%20Beck/250926_Porsche_DE_Leonie-BeckxChristo-Ruf%20der%20Freiheit_Video_01?csf=1&amp;web=1&amp;e=bI662F>

**2025-09-26 10:05:31** - Julia:
> danke dir :heart:

**2025-09-26 10:23:44** - Mert Koc:
> Machen wir Daily Huddle ? Wenn ja, können wir es auf 10:45 verschieben? Will noch vorher Videos raus schicken

**2025-09-26 10:24:33** - Julia:
> Ja gerne. Bin schon mit Flo im Call

**2025-09-26 10:45:44** - Julia:
> brauchen noch 5 min

**2025-09-26 10:45:57** - Mert Koc:
> ok :+1::skin-tone-3:

**2025-09-26 10:55:54** - Mert Koc:
> sagst du dann einfach Bescheid ?

**2025-09-26 11:23:01** - Julia:
> liebs :smile:

**2025-09-26 11:34:33** - Julia:
> <mailto:florian.listl@boldcreatorsclub.com|florian.listl@boldcreatorsclub.com>
vG.nZGi#E83a6jm

**2025-09-26 11:38:26** - Julia:
> kommst du wieder rein? :smile:

**2025-09-26 11:48:03** - Mert Koc:
> Mein Router ist abgestürzt, deswegen bin ich raus geflogen :sweat_smile: 
Und mein Handy hat dann auf 5G gewechselt lol 

**2025-09-26 11:48:08** - Mert Koc:
> Ich muss neu starten kurz 

**2025-09-26 11:48:19** - Mert Koc:
> Dann nutze ich das direkt als Pause 

**2025-09-26 11:50:14** - Julia:
> haha okay wow

**2025-09-26 11:50:17** - Julia:
> Mach das :slightly_smiling_face:

**2025-09-26 12:59:49** - Mert Koc:
> 

**2025-09-26 13:04:44** - Julia:
> <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BD3204CB4-6946-46A9-896D-D1E414A316B4%7D&amp;file=250925_UGC_Vorschla%25u0308ge_Master.pptx&amp;action=edit&amp;mobileredirect=true|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/Doc.aspx?sourcedoc=%7BD3204C[…]hla%25u0308ge_Master.pptx&amp;action=edit&amp;mobileredirect=true>

**2025-09-26 13:12:40** - Mert Koc:
> Habs gefunden, im UGC Ordner: <https://drive.google.com/drive/folders/1UP9MRHGzdrRAYvbxKor8im-ahFZb_dx-?usp=drive_link>
Unten die PDF "UGC &amp; CM Onboarding..." da ist der Prozess bisher beschrieben.

**2025-09-26 13:16:39** - Julia:
> uiuiui, obs viel ist?

**2025-09-26 13:58:46** - Julia:
> hast du zugriff auf den Link in der mail?

**2025-09-26 14:02:14** - Mert Koc:
> Ich versuche herauszufinden, wie das funktionieren soll lol

**2025-09-26 14:03:00** - Julia:
> :joy:

**2025-09-26 14:03:58** - Mert Koc:
> Ich checks nicht

**2025-09-26 14:04:26** - Mert Koc:
> Sieht das bei dir auch so aus?

**2025-09-26 14:06:25** - Julia:
> ja

**2025-09-26 14:06:51** - Julia:
> würdest du Hanna das kurz schreiben? Ich hab ja eh wieder keinen Zugriff :smile:

**2025-09-26 14:48:12** - Julia:
> Bei den BS stories hab ich gedacht, wäre es auch sinnvoll mit "driven by dreams" anzufangen

**2025-09-26 14:48:41** - Julia:
> dann könnten wir evtl. den "Rundgang/ Grundriss" noch nach hinten ziehen

**2025-09-26 14:48:48** - Julia:
> liegt in figma :slightly_smiling_face:

**2025-09-26 14:56:27** - Mert Koc:
> Wo denn in Figma ?

**2025-09-26 14:57:45** - Julia:
> weekly rundgang

**2025-09-26 14:57:48** - Julia:
> bin noch nicht fertig

**2025-09-26 15:33:03** - Julia:
> hast du hierauf zugriff?
<https://porsche.sharepoint.com/sites/PDMK/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FPDMK%2FShared%20Documents%2FGeneral%2FUMZUG%2FKampagnen%2F%5FVKR%20MY%2025%2FTINS%2FAlte%20Anzeigen%2Fvon%20Museum&amp;viewid=6340b967%2Dd3d5%2D401d%2D9687%2D73af93fd1ecf&amp;csf=1&amp;web=1&amp;e=gUeQ59&amp;ovuser=56564e0f%2D83d3%2D4b52%2D92e8%2Da6bb9ea36564%2Cjulia%2Ehallhuber%40boldcreatorsclub%2Ecom&amp;OR=Teams%2DHL&amp;CT=1756120940332&amp;clickparams=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiI1MC8yNTA3MzExNzQxMCIsIkhhc0ZlZGVyYXRlZFVzZXIiOmZhbHNlfQ%3D%3D&amp;CID=3d32bfa1%2D60a3%2Dd000%2De737%2Daa92c95b626b&amp;cidOR=SPO&amp;FolderCTID=0x012000B0A40330D7B2464BB054061397BEF042|https://porsche.sharepoint.com/sites/PDMK/Shared%20Documents/Forms/AllItems.aspx?id=%2Fs[…]R=SPO&amp;FolderCTID=0x012000B0A40330D7B2464BB054061397BEF042>

**2025-09-26 15:33:48** - Mert Koc:
> Ja das ist der Drive, den ich dir mal geschickt habe, mit den Retro Bildern

**2025-09-26 15:34:06** - Julia:
> jaa

**2025-09-26 15:34:08** - Mert Koc:
> 

**2025-09-26 15:34:09** - Julia:
> habs eben gefunden :smile:

**2025-09-26 15:35:11** - Julia:
> da ist das nämlich mehr oder weniger das TINS plakat drin hehe

**2025-09-26 15:40:13** - Mert Koc:
> Ich hatte btw den neuen UGC Post gemacht:

**2025-09-26 15:40:38** - Mert Koc:
> Hab das Foto Grid in der Mitte entfernt, weil das war einfach zu viel des Guten

**2025-09-26 15:41:08** - Julia:
> liebe ich!

**2025-09-26 15:41:16** - Julia:
> VBWs?

**2025-09-26 15:41:27** - Mert Koc:
> Ugh .. stimmt

**2025-09-26 15:47:46** - Mert Koc:
> Man erkennt halt nicht, welches Fahrzeug es ist, deshalb brauchen wir es glaube ich sogar nicht einmal :thinking_face:

**2025-09-26 15:48:25** - Julia:
> okay

**2025-09-26 15:48:31** - Julia:
> ja, ich erkenn sowieso nichts deswegen :smile:

**2025-09-26 15:53:07** - Julia:
> ich hab Flo vor 2 Stunden gefragt, ob wir hanna die BS Posts dann schon mal schicken sollen – keine Antwort

**2025-09-26 15:53:31** - Mert Koc:
> classic

**2025-09-26 16:06:21** - Julia:
> meinst du, du sdchaffst heute noch was mit Colour? ich frag nur, sonst würde ich warten bis ich Hanna das schicke

**2025-09-26 16:07:19** - Mert Koc:
> Ich mache gerade eine Porsche Turbo Konfiguration :+1::skin-tone-2: 
Aber muss es final sein? 

**2025-09-26 16:09:05** - Julia:
> Neee

**2025-09-26 16:09:19** - Julia:
> einfach so, dass wir es schon mal präsentieren können

**2025-09-26 16:24:15** - Julia:
> 

**2025-09-26 16:30:27** - Mert Koc:
> Ja gute Idee :slightly_smiling_face: vielleicht finde ich so ein Video

**2025-09-26 17:11:07** - Mert Koc:
> Ich habe meine Idee für die Konfis rein. Sehr grob noch, weil es eig schon etwas aufwändig ist. Aber wir können das an sich mega nice machen und wenn es mal sitzt, haben wir da sehr viel interaktiven Kontent

**2025-09-26 17:11:17** - Julia:
> find ich super!

**2025-09-26 17:11:26** - Julia:
> ich ziehs mal hoch "zu approval"

**2025-09-26 17:11:40** - Julia:
> Müsste noch anmerken: Feedpost wäre dann die Auflösung

**2025-09-26 17:12:00** - Mert Koc:
> Achso stimmt. Das können wir ja dann in der ersten Slide reposten :slightly_smiling_face:

**2025-09-26 17:12:33** - Mert Koc:
> Hier ist die Idee für die Trends <https://www.instagram.com/p/DOeTigHEtqg/?utm_source=ig_web_copy_link&amp;igsh=MzRlODBiNWFlZA==>

**2025-09-26 17:12:39** - Mert Koc:
> Das musst du aber am Handy öffnen

**2025-09-26 17:13:46** - Julia:
> wie meinst du?

**2025-09-26 17:13:49** - Julia:
> ah moment!

**2025-09-26 17:14:02** - Julia:
> jaa das kenn ich haha

**2025-09-26 17:15:31** - Julia:
> 

**2025-09-26 17:15:53** - Mert Koc:
> Ooh haha

**2025-09-26 17:15:59** - Mert Koc:
> kacke :sweat_smile:

**2025-09-26 17:16:07** - Mert Koc:
> Aber soll ichs trotzdem aufnehmen ?

**2025-09-26 17:17:53** - Julia:
> jaa das ist super mit dem Video!

**2025-09-26 17:18:05** - Julia:
> Hab Slide 19 erstellt. So meintest du, oder?

**2025-09-26 17:18:14** - Mert Koc:
> ich habs versucht zu erklären auf der SLide aber ich glaube, dass muss man mündlich pitchen :joy:

**2025-09-26 17:18:46** - Mert Koc:
> Ich würde es kurz überarbeiten

**2025-09-26 17:19:45** - Julia:
> habs noch ergänzt haha

**2025-09-26 17:19:51** - Julia:
> gerneeee

**2025-09-26 17:26:57** - Julia:
> ahhh got it

**2025-09-26 17:26:58** - Julia:
> nice!

**2025-09-26 17:27:09** - Julia:
> ist das alles in diesem Konfigurator erstellt?

**2025-09-26 17:27:28** - Mert Koc:
> Ja :+1::skin-tone-3:

**2025-09-26 17:27:50** - Julia:
> mega

**2025-09-26 17:27:56** - Julia:
> hab noch das mit der farbe ergänzt

**2025-09-26 17:28:03** - Julia:
> wäre smart das zu verbinden

**2025-09-26 17:28:56** - Mert Koc:
> das ist echt smart

**2025-09-26 17:29:08** - Mert Koc:
> Passt so oder ? :grin:

**2025-09-26 17:29:12** - Julia:
> voll!

**2025-09-26 17:29:14** - Julia:
> mega gut

**2025-09-26 17:29:15** - Julia:
> dankeeee

**2025-09-26 17:29:40** - Mert Koc:
> Teamwork :raised_hands::skin-tone-3::muscle::skin-tone-3:

**2025-09-26 17:29:49** - Julia:
> jaa :heart:

**2025-09-26 17:29:55** - Julia:
> ich schicks jetzt gleich mal ab

**2025-09-26 17:30:19** - Mert Koc:
> Sehr nice ^^

**2025-09-26 17:30:26** - Mert Koc:
> Ich mache dann mal Feierabend ^^

**2025-09-26 17:35:04** - Julia:
> jaaa please! happy weekend :slightly_smiling_face: Vielleicht sieht man sich ja auf der wiesn? haha

**2025-09-26 17:36:25** - Mert Koc:
> Danke dir auch happy Weekend^^
Ich geh wahrscheinlich am Sonntag

**2025-09-29 10:08:25** - Mert Koc:
> Bist du statt Julia in dem Porschex BCC Meeting? Oder Flo?
Falls sie Änderungen bei den BS Weekly Highlights ansprechen sollten, gerne sagen

**2025-09-29 10:09:02** - Julia:
> ich bin drin :slightly_smiling_face:

**2025-09-29 10:09:49** - Julia:
> glaube BS wird hier nicht besprochen

**2025-09-29 10:22:12** - Mert Koc:
> ok, manchmal kamen Änderungen bei den Meetings am Montag ^^

**2025-09-29 10:44:23** - Julia:
> sie hat in die präsi reingeschrieben :slightly_smiling_face:

**2025-09-29 10:49:40** - Mert Koc:
> Ja ich lese es mir gerade durch ^^

**2025-09-29 10:55:57** - Julia:
> feedback geben, kann auch nicht jeder :smile:

**2025-09-29 11:01:13** - Mert Koc:
> Kommst du ins Meeting ? ^^

**2025-09-29 12:08:06** - Julia:
> weißt du was sie meint mit "bleiben wir doch erstmal..."?

**2025-09-29 12:11:07** - Julia:
> 

**2025-09-29 12:15:48** - Mert Koc:
> Doch, so könnte sie es meinen

**2025-09-29 12:16:27** - Mert Koc:
> Oder war es ein Zitat von Ferry, das weiß ich auch nicht. Evtl. müssen wir hier einfach nochmal nachfragen, bevor wir extra Arbeit machen...

**2025-09-29 12:23:19** - Mert Koc:
> Das Feedback ist echt sehr interessant...

**2025-09-29 12:23:21** - Julia:
> ja das ist das zitat von ihm aber halt zusammen gefasst

**2025-09-29 12:23:25** - Julia:
> ja :smile:

**2025-09-29 12:25:15** - Mert Koc:
> 

**2025-09-29 12:26:04** - Mert Koc:
> Ich hole mir kurz was für Lunch

**2025-09-29 12:26:32** - Julia:
> hmm okay okay

**2025-09-29 12:26:57** - Julia:
> ja sie kann erst ab 14uhr telefonieren, deswegen würde ich es gerne vorher fertig machen. sonst schaff ich wieder garnichts :smile:

**2025-09-29 12:27:06** - Julia:
> aber ja kann sein, danke dir!

**2025-09-29 14:41:38** - Mert Koc:
> Hattest du schon eine Figma Seite mit Porsche Turbo Posts?

**2025-09-29 14:41:45** - Julia:
> Nee

**2025-09-29 14:45:50** - Mert Koc:
> Hat sie gesagt, was genau sie da will? Weil wir haben gefühlt schon alles aus den Social Media Assets gespielt. Also ich kann da noch was zusammenkratzen, falls das der Wunsch ist.

**2025-09-29 14:53:04** - Julia:
> 

**2025-09-29 16:14:05** - Mert Koc:
> Ich kann bei der Präsentation irgendwie keine Videos ablegen, weil das ne Drive Datei ist und keine Sharepoint :melting_face::melting_face:
<https://docs.google.com/presentation/d/1hWclXKncOdWuzmNTzkG7dQ59wDFNNl0N/edit?slide=id.p18#slide=id.p18|220929_Porsche_DE_Social-Media_Sep-Okt.pptx - Google Slides>

**2025-09-29 16:15:49** - Mert Koc:
> 

**2025-09-29 16:16:58** - Mert Koc:
> 

**2025-09-29 16:17:51** - Mert Koc:
> 

**2025-09-29 16:22:38** - Julia:
> <https://www.porsche-brandstore.de/events>

**2025-09-29 16:23:20** - Julia:
> looos gehts

**2025-09-29 16:23:53** - Mert Koc:
> Ich checke

**2025-09-29 16:26:33** - Julia:
> okay sollte alles online sein

**2025-09-29 16:26:48** - Mert Koc:
> Perfekt :slightly_smiling_face:

**2025-09-29 16:27:49** - Mert Koc:
> 

**2025-09-29 16:28:56** - Julia:
> okay mom

**2025-09-29 16:30:55** - Julia:
> okay done

**2025-09-29 16:31:04** - Julia:
> Opening Hours hab ich jetzt bei Beratung..?

**2025-09-29 16:31:17** - Mert Koc:
> Ja sollte passen denke ich :) 

**2025-09-29 16:32:19** - Julia:
> okee

**2025-09-29 16:35:51** - Mert Koc:
> Ich würde dir gerne die Turbo Posts zeigen aber idk wie. Ich habe aus den Videos paar kurze Snippets für die Feedposts geschnitten, die ich nicht hochladen kann in Porsche_DE PPt

**2025-09-29 16:36:06** - Julia:
> oh nein

**2025-09-29 16:36:17** - Julia:
> kannst dus in unseren drive hochladen?

**2025-09-29 16:36:28** - Mert Koc:
> ja :+1::skin-tone-3:

**2025-09-29 16:47:24** - Mert Koc:
> Hab sie hier hochgeladen: <https://drive.google.com/drive/folders/1554YawZWDiXV_XOaidilqQDrJAp0Ntq-?usp=drive_link>

**2025-09-29 16:49:05** - Julia:
> sehr cool!

**2025-09-29 16:49:25** - Julia:
> Man könnte sowas wie "Perspektivenwechsel" oder so als Caption nehmen

**2025-09-29 16:56:03** - Mert Koc:
> Maybe sowas wie "Offen für neue Perspektiven", weil Cabriolet + die vielen Perspektiven im Post? :thinking_face:
Oder checkt man das nicht

**2025-09-29 16:56:14** - Julia:
> jaa!

**2025-09-29 16:56:16** - Julia:
> find ich gut

**2025-09-29 16:57:34** - Mert Koc:
> Wir könnten noch stärker auf das mit dem Cariolet eingehen mit "Öffnen für neue Perspektiven" aber idk wie Porsche das findet.

**2025-09-29 16:57:54** - Julia:
> ich finds super

**2025-09-29 16:58:03** - Julia:
> lass uns denen mal paar coolere sachen vorschlagen

**2025-09-29 16:58:06** - Julia:
> die sind so trocken :smile:

**2025-09-29 16:58:11** - Mert Koc:
> Ja true

**2025-09-29 16:58:23** - Julia:
> dafür sind wir ja eigentlich da

**2025-09-29 17:10:35** - Julia:
> jetzt bräuchte ich auch nochmal deine hilfe bitte

**2025-09-29 17:10:48** - Mert Koc:
> Klar

**2025-09-29 17:11:32** - Julia:
> 

**2025-09-29 17:11:34** - Julia:
> 

**2025-09-29 17:12:57** - Julia:
> 

**2025-09-29 17:16:10** - Mert Koc:
> Habs hier hochgeladen, im Chrsto Ordner: <https://porsche.sharepoint.com/:f:/r/sites/PDMK/Shared%20Documents/General/UMZUG/Digitales%20Marketing/Social/Insta/08_Redaktionsplanung/Contents/2025/09_September/Christo_Leonie%20Beck?csf=1&amp;web=1&amp;e=hyyYpj|Christo_Leonie Beck>

**2025-09-29 17:16:50** - Mert Koc:
> Ja ich kann das Skinny Video machen, soll ichs für Gipfeltreffen oder Turbo machen? :thinking_face:
Weil das steht beides in der Präsi

**2025-09-29 17:17:22** - Julia:
> dann eher für den turbo :slightly_smiling_face:

**2025-09-29 17:29:25** - Mert Koc:
> Du kannst bei den drei links mal Freigabe anfordern, das sind die wichtigsten:
<https://porsche.sharepoint.com/sites/PDMK/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FPDMK%2FShared%20Documents%2FGeneral%2FUMZUG%2FDigitales%20Marketing%2FSocial%2FInsta%2F08%5FRedaktionsplanung%2FContents%2F2025&amp;viewid=6340b967%2Dd3d5%2D401d%2D9687%2D73af93fd1ecf&amp;csf=1&amp;web=1&amp;e=YdzFfu&amp;CID=7e2a435d%2D2939%2D41fb%2D9048%2D5ab214ca428f&amp;FolderCTID=0x012000B0A40330D7B2464BB054061397BEF042|PDMK - Dokumente - 2025 - Alle Dokumente>
<https://porsche.sharepoint.com/sites/PDMK/Shared%20Documents/Forms/AllItems.aspx?csf=1&amp;web=1&amp;e=ofJAdD&amp;CID=38033eb8%2Df40e%2D408d%2Da7a4%2De393c7e25338&amp;FolderCTID=0x012000B0A40330D7B2464BB054061397BEF042&amp;id=%2Fsites%2FPDMK%2FShared%20Documents%2FBrand%20Store%2F08%20Social%20Media%2FKonzepte|PDMK - Dokumente - Konzepte - Alle Dokumente>
<https://porsche.sharepoint.com/sites/PDMK/Shared%20Documents/Forms/AllItems.aspx?csf=1&amp;web=1&amp;e=5%3A7843c416cdb749a8a41366a2ad525502&amp;CID=0252f416%2D8640%2D4222%2Db387%2D127327bf30ed&amp;FolderCTID=0x012000B0A40330D7B2464BB054061397BEF042&amp;id=%2Fsites%2FPDMK%2FShared%20Documents%2FBrand%20Store%2F07%20Programming%2FBilder%20Pool%5FGesamt|PDMK - Dokumente - Bilder Pool_Gesamt - Alle Dokumente>

**2025-09-29 17:30:25** - Julia:
> ach süß, danke dir. das problem ist, bei vielen hab ich auch zugriff aber es kommt halt IMMER das

**2025-09-29 17:30:43** - Julia:
> Ich glaube es liegt einfach an meinem account wegen Julia Schmid. Aber Flo meint nein :smile:

**2025-09-29 17:34:09** - Mert Koc:
> Ne das bedeutet, dass du noch keinen Zugriff hast

**2025-09-29 17:34:30** - Julia:
> aber ich kann auch keinen Zugriff anfodern

**2025-09-29 17:34:58** - Mert Koc:
> Ja, das ist weird :confused:
Glaube die müssen einfach mal deine Mail freischalten da

**2025-09-29 17:35:00** - Mert Koc:
> <https://porsche.sharepoint.com/:p:/r/sites/PDMK/Shared%20Documents/General/UMZUG/Digitales%20Marketing/Social/Insta/08_Redaktionsplanung/Contents/2025/10_Oktober/220929_Porsche_DE_Social-Media_Sep-Okt.pptx?d=w1372549b96e94de7ba7ed46a7fd37fef&amp;csf=1&amp;web=1&amp;e=vqaWBu|220929_Porsche_DE_Social-Media_Sep-Okt.pptx>

**2025-09-29 17:35:08** - Mert Koc:
> Hast du darauf Zugriff?

**2025-09-29 17:35:23** - Julia:
> ne aber hier hab ich angefordert :smile:

**2025-09-29 17:35:32** - Julia:
> Okay sorry aber könntest du sonst die fonts anpassen?

**2025-09-29 17:35:45** - Julia:
> ja ist so. ich schreib Marie nochmal

**2025-09-29 17:37:48** - Mert Koc:
> Kann ich nicht :melting_face:

**2025-09-29 17:38:09** - Julia:
> fml

**2025-09-29 17:38:12** - Mert Koc:
> Gott wie nervig

**2025-09-29 17:38:14** - Julia:
> gut dann ohne porsche font :smile:

**2025-09-29 17:38:15** - Julia:
> hahaha

**2025-09-29 17:38:31** - Mert Koc:
> Oder downloaden, font ändern und schicken?

**2025-09-29 17:38:36** - Mert Koc:
> Kein Ahnung tbh

**2025-09-29 17:38:49** - Julia:
> ja ich würde eh ein pdf draus machen

**2025-09-29 17:38:50** - Julia:
> moment

**2025-09-29 17:39:05** - Mert Koc:
> vlt ist es besser wenn Julia die Präsis in Zukunft einfach anlegt, weil sie überall oder zumindest mehr Rechte hat

**2025-09-29 17:39:43** - Julia:
> das stmmt

**2025-09-29 17:43:33** - Mert Koc:
> Ich hab das mit dem Skinny jetzt ausprobiert aber das geht nicht... wir müssen das mit einem YouTube Video am besten machen.
Also ein YT Video zu einem Skinny umändern oder direkt mit der "Vision" ein Skinny zu machen Produzieren.
Wenn ich Reels (9x16) zu Skinny ändere, sieht man gar nichts mehr, weil es viel zu nah ist. :confused:

**2025-09-29 17:47:19** - Julia:
> okay verstehe

**2025-09-29 17:47:33** - Julia:
> das dauert für jetzt zu lange oder? also ein YT video zu nehmen?

**2025-09-29 17:47:45** - Julia:
> bzw. ist für Turbo dann irrelevant oder?

**2025-09-29 17:48:23** - Mert Koc:
> Turbo hatte leider keine YT Videos beim SoS

**2025-09-29 17:48:51** - Mert Koc:
> Wird fürs Gipfeltreffen eins gemacht?

**2025-09-29 17:49:02** - Julia:
> i dont know

**2025-09-29 17:52:40** - Mert Koc:
> Ich könnte aus dem Cayenne Extreme eins machen !

**2025-09-29 17:53:09** - Mert Koc:
> Idk ob das passend ist... weil die ja eigentlich kein großes ding draus machen wollten oder?

**2025-09-29 17:53:40** - Julia:
> ja wahrscheinlich unnötig in dem fall

**2025-09-29 17:56:14** - Mert Koc:
> hmm :confused:
Was anderes aktuelles haben wir nicht ...

**2025-09-29 17:56:37** - Julia:
> ja dann lassen wir es

**2025-09-29 17:56:45** - Mert Koc:
> Ich könnte aus den Sonderwunsch Videos sicherlich was machen... aber die posten wir erst im laufe des Oktobers

**2025-09-29 17:57:08** - Julia:
> okay! dann nehmen wir es doch da auf

**2025-09-29 17:57:16** - Julia:
> könnten es ja bald mal zeigen, wenn Zeit ist

**2025-09-29 18:00:28** - Mert Koc:
> Ich komme übrigens morgen kurz im Büro vorbei, wegen Arbeitsvertrag unterschreiben :slightly_smiling_face:
Würde dann aber auch gerne nicht am Meeting teilnehmen, weil ich komme einfach zu nichts. Ich brauche einfach mal Zeit zum abarbeiten lol

**2025-09-29 18:01:28** - Julia:
> ahhh wie cool! ich wollte eben noch fragen, ob du unterschreibst oder wie der Stand ist? JUHUUUUU

**2025-09-29 18:01:50** - Julia:
> also ich bin nicht im Büro – ich hab einfach immernoch halsweh :smile:

**2025-09-29 18:01:52** - Julia:
> ja versteh ich

**2025-09-29 18:06:50** - Mert Koc:
> oh shit :confused: gute Besserung

**2025-09-29 18:15:39** - Julia:
> ich geh jetzt mal off. Mach später noch die BS Slides für Hanna – irgendwas passt ihr mit dem Wording nicht :melting_face:
Wir hören uns morgen :slightly_smiling_face::heart:

**2025-09-29 18:17:57** - Mert Koc:
> Bis morgen, schönen Feierabend :slightly_smiling_face:

**2025-09-29 18:18:20** - Mert Koc:
> Ich mach nur noch ein Leica Event Video und Thumbnail und dann bin ich auch raus.

**2025-09-30 09:17:20** - Julia:
> Hallooo, ich brauch deine kreative Hilfe :smile: hast du eine Idee, was wir hier im Feed machen könnten..?
Die "Driven by Dreams" Geschichte mit Bildern von Ferry Porsche...? auch nicht cool

**2025-09-30 09:21:18** - Mert Koc:
> Hello :) 
Ich lasse mir gleich was einfallen.
Bin gleich zuhause. War gerade Arbeitsvertrag unterschreiben im Büro :partying_face: 

**2025-09-30 09:21:30** - Julia:
> Juhuuuu wie gut

**2025-09-30 09:21:35** - Julia:
> Glückwunsch! :fast_parrot:

**2025-09-30 09:22:44** - Mert Koc:
> Danke :pray::skin-tone-3:  

**2025-09-30 09:30:17** - Julia:
> hast du dann auch schon einen Laptop bekommen?

**2025-09-30 09:31:15** - Mert Koc:
> ne noch nicht leider :melting_face: aber er kümmert sich drum

**2025-09-30 09:47:54** - Julia:
> oke

**2025-09-30 09:48:25** - Mert Koc:
> sollen wir kurz call wegen Alltags Drive Carousel oder brauchst du Zeit für das Porsche Meeting ?

**2025-09-30 10:04:51** - Julia:
> sorry, hatte mit flo geschrieben

**2025-09-30 10:04:57** - Julia:
> bin jetzt im porsche call

**2025-09-30 10:05:11** - Mert Koc:
> kein Stress :slightly_smiling_face:

**2025-09-30 10:05:16** - Julia:
> gerne danach kurz?

**2025-09-30 10:05:29** - Mert Koc:
> klar

**2025-09-30 10:31:34** - Mert Koc:
> seid ihr noch im Call ?

**2025-09-30 10:33:02** - Julia:
> ja..

**2025-09-30 10:37:18** - Julia:
> geben gleich bescheid

**2025-09-30 10:46:51** - Julia:
> okay können in den call

**2025-09-30 11:07:28** - Julia:
> ich glaub du kannst raus

**2025-09-30 12:40:33** - Mert Koc:
> Wie viele Konfigurationsoptionen soll ich machen findest du ? :thinking_face:

**2025-09-30 12:40:49** - Julia:
> 4-5

**2025-09-30 13:23:07** - Julia:
> sorry ich bin so im tunnel gerade mit dem leonie thema

**2025-09-30 13:23:11** - Julia:
> :nauseated_face:

**2025-09-30 13:36:09** - Mert Koc:
> Alles gut, ich hab eh zutun mit der Konfiguration.
Das muss halt am Ende auch alles Sinn ergeben bei der Konfi, von daher gar nicht mal so easy wie ich dachte :sweat_smile:
Man kann nämlich nicht alles kombinieren aber alle unsere Optionen müssen ja kombinierbar sein. Daher musste ich das jetzt mal durchgehen und überprüfen.

**2025-09-30 13:37:06** - Mert Koc:
> Ich mache jetzt Lunch :slightly_smiling_face:

**2025-09-30 13:41:52** - Julia:
> okay okay :face_with_peeking_eye: lieben wir

**2025-09-30 13:41:53** - Julia:
> Mach das!

**2025-09-30 16:25:16** - Mert Koc:
> Ich mache gerade die neuen Weekly Highlights...
Was findest du besser, links sind die drei neuen Optionen und rechts das Alte.

**2025-09-30 16:25:41** - Julia:
> uh nice

**2025-09-30 16:25:48** - Julia:
> ganz oben!

**2025-09-30 16:26:04** - Mert Koc:
> Sehr gut, ich auch! :grin:

**2025-09-30 16:26:11** - Julia:
> :fast_parrot:

**2025-09-30 16:27:14** - Mert Koc:
> Die neuen Konfi Stories sind in der Präsi auch..
Würde dann noch die Highlights heute noch ergänzen

**2025-09-30 16:27:47** - Julia:
> ach super

**2025-09-30 16:27:55** - Julia:
> okay, ich hab BS noch nicht geschafft :sob:

**2025-09-30 16:28:16** - Julia:
> du kannst aber auch gerne einen kommentar reinschreiben und später, wenn alles ready ist schicke ich es hanna nochmal

**2025-09-30 16:29:07** - Mert Koc:
> Passt, kann ich machen :slightly_smiling_face:
Ich kann theoretisch auch noch die "Club USA Community Vorstellung" Slides in die neue BS Präsi schieben, keine Ahnung, warum die in einer extra Präsi sind!

**2025-09-30 16:29:47** - Julia:
> ja sehr sehr gerne

**2025-09-30 17:27:26** - Mert Koc:
> Hab die Highlights jetzt nach Figma übertragen und leicht angepasst :slightly_smiling_face:

**2025-09-30 17:33:48** - Julia:
> uhh ich schau mal

**2025-09-30 17:34:36** - Julia:
> mag ich sehr!

**2025-09-30 17:35:10** - Mert Koc:
> Nice :slightly_smiling_face: Hab sie schon mit Änderungskommentaren in die Präsi

**2025-10-01 10:57:42** - Julia:
> hello! :slightly_smiling_face: hattest du bei dem BS Rundgang schon das mit dem Grundriss gemacht?

**2025-10-01 11:04:31** - Mert Koc:
> Ne ich kam leider noch nicht dazu und hab da auch noch keine klare Idee für

**2025-10-01 11:15:14** - Mert Koc:
> Hast du zufällig eine Idee dafür, die nicht zu aufwändig ist?

**2025-10-01 11:17:47** - Mert Koc:
> Ich würde jetzt mit Red Dot Macan anfangen, bevor ich wieder was für den BS mache, damit Charly beruhigt ist

**2025-10-01 11:25:27** - Julia:
> 

**2025-10-01 11:27:49** - Julia:
> BS Feedback:
• Story Highlight: Fächer bitte austauschen: <https://www.picdrop.com/roserbrothers/UcybkS1Ehk?file=9df8e108ed16e0be65f37b5f7c0a5cf6>
Müssen wir wahrscheinlich croppen und bissl bearbeiten wegen diesem Look
• Story Highlight: da haben sie und Denise nicht verstanden, dass es diese Sticker sein sollen --&gt; hier bitte neues Visual überlegen, was man für #PorscheFamily nutzen kann
• Weekly Highlights: den Instagram Sticker vom Link in komplett schwarz (das ist blau mit drin) :smile: 

**2025-10-01 11:27:53** - Julia:
> daaanke dir

**2025-10-01 14:18:24** - Julia:
> 

**2025-10-01 14:34:35** - Mert Koc:
> Find ich auch ne gute Idee. 
Was meinst du mit Trend der dagegen geht? 
Ich schau‘s mir gleich an in der präsi 

**2025-10-01 14:39:56** - Julia:
> 

**2025-10-01 15:42:51** - Julia:
> Mert, kannst du mir den BS Link nochmal sdchicken? :smile:

**2025-10-01 15:44:31** - Mert Koc:
> <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/doc2.aspx?sourcedoc=%7BE33428F9-BF0F-4720-B9FE-D8EDF165E52E%7D&amp;file=250924_Porsche_BS_SoMe_Konzepte_JH.pptx&amp;action=edit&amp;mobileredirect=true|250924_Porsche_BS_SoMe_Konzepte_JH.pptx>

**2025-10-01 15:44:48** - Julia:
> :heart:

**2025-10-02 11:37:46** - Mert Koc:
> Ganz ehrlich .. sollen wir beim BS die Karte einfache weglassen? Habe Angst, dass uns das sonst auf die Füße fällt irgendwie :disappointed:

**2025-10-02 11:38:43** - Mert Koc:
> Weil ich müsste das halt gut oder gar nicht machen aber ich bekomme ständig neue Aufgaben, die "Prio" haben :sweat_smile:

**2025-10-02 11:45:19** - Julia:
> Ja können wir

**2025-10-02 17:10:24** - Mert Koc:
> Das mit dem ABC wird echt schwierig werden für 26 Tage.. da brauchen wir nen Schlachtplan lol
ich habe nämlich versucht mir was für Approved / Aerodynamik Boxermotor auszudenken aber da passt nichts und es passt generell irgendwie nicht so wirklich zu Porsche/ Adventkalender.

Ich würde A umändern zu Aufladen und dann evtl. eine Story zum Aufladen der E und hybrid Porsche? Aber selbst das ist nicht so leicht :sob:

**2025-10-02 17:10:55** - Julia:
> Hast du schon was zum Zeigen? :slightly_smiling_face:

**2025-10-02 17:11:54** - Mert Koc:
> Ne nur ein Konzept :melting_face: hab zu viel Zeit mit Approved verschwendet ...

**2025-10-02 17:12:04** - Julia:
> Okay verstehe

**2025-10-02 17:12:19** - Julia:
> Also ich hab auch eine Idee im Kopf. ich scribble es einfach mal runter

**2025-10-02 17:14:31** - Mert Koc:
> Die Idee:
• Video von einer Ladebuchse, Stecker wird in den Porsche gesteckt wird → Ladekabel „klickt“ ein (Hoffe sowas existiert überhaupt)
• Video: Ladeanzeige springt hoch (wie ein Handy Akku der Auflädt/ evtl Porsche Anzeige finden und retuschieren?)
• Textoverlay: _„Aufgeladen für die Zukunft.“ ?_
• *Story-Text:* „Aufladung ist mehr als Technik. Es ist unser Versprechen für Performance."


**2025-10-02 17:14:50** - Julia:
> okay wooow

**2025-10-02 17:15:01** - Mert Koc:
> Sag sehr gerne deine Idee.
Das "Problem" mit Ideen ist immer, dass man nichts dazu fidnet irgendwo lol

**2025-10-02 17:15:08** - Julia:
> da hast du aber sehr detailliert dran gefeilt!

**2025-10-02 17:16:17** - Julia:
> 

**2025-10-02 17:17:53** - Mert Koc:
> Ja wollte auch Story also gar kein Feed.
Aber ja wahrscheinlich ist das zu aufwändig. Hab nur Angst, dass uns Charly wieder komplett auseinander nimmt lol

**2025-10-02 17:18:57** - Julia:
> 

**2025-10-02 17:19:22** - Julia:
> sollten wir einfach direkt so nehmen :smile:

**2025-10-02 17:20:01** - Julia:
> das nimmt sie so oder so

**2025-10-02 17:21:47** - Julia:
> 

**2025-10-02 17:21:49** - Mert Koc:
> Ja halt wirklich

**2025-10-02 17:22:10** - Julia:
> <https://drive.google.com/drive/folders/1SDKZJ6GBvTHM4sPRqWM29IHnzdCaKxZD>

**2025-10-02 17:22:53** - Mert Koc:
> Ok ja passt :slightly_smiling_face:

**2025-10-02 17:23:05** - Mert Koc:
> Falls was kommen sollte kann ichs noch ausbessern

**2025-10-02 17:23:26** - Mert Koc:
> Ich bin aber auch nur noch so 30 min da, dann bin ich verabredet :melting_face:

**2025-10-02 17:23:31** - Julia:
> dankeee :heart:

**2025-10-02 17:23:39** - Julia:
> ja ist auch einfach so, irgendwann reicht es

**2025-10-02 17:23:46** - Julia:
> die haben mir heute echt den rest gegeben

**2025-10-02 17:24:03** - Mert Koc:
> Ja verständlich :disappointed:

**2025-10-02 17:24:24** - Julia:
> danke dir und schon mal happy WEEEE! :slightly_smiling_face:

**2025-10-02 17:25:41** - Mert Koc:
> Bitte und Happy Weekend :slightly_smiling_face:

**2025-10-06 17:12:32** - Julia:
> <https://boldcreators-my.sharepoint.com/:p:/g/personal/julia_hopper_boldcreatorsclub_com/EZ7TLT66epNKhkXArtJqiLUBlTp7hkTKor54-WuvJrIDVQ?e=RcfswU>

**2025-10-06 18:37:56** - Julia:
> ich mach die restlichen Präsi Sachen morgen weiter

**2025-10-06 18:38:22** - Julia:
> falls du morgens dann noch Zeit hast: vllt ein Story Highlight für TINS visualisieren wäre mega :heart_eyes:

**2025-10-06 18:38:29** - Julia:
> Hab einen schönen Feierabend!

**2025-10-06 18:41:33** - Mert Koc:
> Ja same ...
Alles klar, mache ich  :slightly_smiling_face:
Bis morgen :raised_hands::skin-tone-3:

**2025-10-07 09:33:08** - Mert Koc:
> So schnell habe ich nen Job noch nie verloren lol

**2025-10-07 09:33:12** - Mert Koc:
> Neuer Rekord

**2025-10-07 09:33:21** - Julia:
> :face_with_spiral_eyes:

**2025-10-07 09:42:40** - Julia:
> so unfair

**2025-10-07 10:33:52** - Julia:
> kommst du auch? oder brauchst du noch? :slightly_smiling_face:

**2025-10-07 11:41:23** - Mert Koc:
> Wie sollen wir das Advent ABC nennen im Highlight? :thinking_face:
hast du ne coole Idee ? :sweat_smile:

**2025-10-07 11:41:54** - Julia:
> hmmm

**2025-10-07 11:42:39** - Julia:
> 

**2025-10-07 11:42:41** - Mert Koc:
> Vorschläge von ChatGPT:
Christmas Carrera
Advent Drive
Driven by Christmas
24 Days of Drive

**2025-10-07 11:42:51** - Julia:
> es bekommt quasi nur ein neues Styling

**2025-10-07 11:43:22** - Julia:
> advent drive :heart_hands:
Aber glaube das braucht es garnicht

wir haben übrigens 26 :slightly_smiling_face: wegen 26 buchstaben

**2025-10-07 11:46:35** - Julia:
> was denkst du dazu?

**2025-10-07 11:48:23** - Mert Koc:
> Ah das ist ne sehr coole Idee!

**2025-10-07 11:55:46** - Julia:
> damit machen wir es uns leichter

**2025-10-07 11:56:25** - Mert Koc:
> Sowas maybe?

**2025-10-07 11:57:21** - Julia:
> ja das 2. oder 3.!

**2025-10-07 11:57:32** - Mert Koc:
> Die beiden rechts sind halt von unslpash, weils auf der Datenbank nichts zu Weihnachten gibt

**2025-10-07 11:57:51** - Julia:
> man kann ja drunter dann schreiben als Text "Advents ABC"

**2025-10-07 12:03:31** - Mert Koc:
> Habs in die Präsi

**2025-10-07 12:14:57** - Mert Koc:
> Wie findest du diese Captions für den Single Post?
Von der Straße inspiriert – für Bewegung gemacht.
Wir feiern das Erbe des Carrera GT am Sneaker Day.

Unsere Legende, die in Bewegung bleibt.
Von der Straße inspiriert, für die Straße geschaffen – in Form, Farbe und Spirit.
#SneakerDay

Die Legende läuft weiter.
Die Arthur Car Collection feiert das Erbe des Carrera GT am Sneaker Day.

**2025-10-07 13:33:07** - Julia:
> Die 3. find ich gut. hashtag ist mir national glaub ich 

**2025-10-07 13:34:25** - Mert Koc:
> Bin so unmotiviert jetzt, unglaublich

**2025-10-07 13:40:01** - Julia:
> Fühl ich sehr 

**2025-10-07 13:40:08** - Julia:
> Weil man so denkt, hat eh keinen Sinn 

**2025-10-07 13:44:47** - Mert Koc:
> Ja :disappointed:

**2025-10-09 11:52:47** - Julia:
> 

**2025-10-09 11:53:53** - Mert Koc:
> Ok ich mache mir auch mal Gedanken :) 
Aber ist ja eigentlich noch ewig hin 

**2025-10-09 11:54:47** - Julia:
> Nee 11.11. tatsächlich

**2025-10-09 11:54:55** - Julia:
> da ist ja quasi der startschuss

**2025-10-09 11:59:36** - Mert Koc:
> Ok wir wollen also was für den Start :thinking_face:
Ich denke mal drüber nach 

**2025-10-09 14:03:01** - Julia:
> alles gut, kein stress. wenns dir eh nicht gut geht

**2025-10-09 15:40:41** - Julia:
> magst du mir das reel sonst über slack schicken? :slightly_smiling_face:

**2025-10-09 15:41:16** - Mert Koc:
> Yes :raised_hands::skin-tone-3:

**2025-10-09 15:48:32** - Mert Koc:
> Sorry hat so lange zum hochladen gedauert :c

**2025-10-09 15:48:57** - Julia:
> ja alles gut, kenn ich

**2025-10-09 15:53:28** - Julia:
> gibts irgendeinen trick die untertitel rauszubekommen? kann premiere das mit ai oder so?

**2025-10-09 15:54:21** - Mert Koc:
> Ich glaube nicht tbh aber ist an sich auch nicht so schlimm oder?

**2025-10-09 15:55:38** - Julia:
> naja, es wirkt schon sehr abgeschnitten und random, ich schau mal vllt fliegts bei 4x5 ja raus :sunglasses:

**2025-10-09 16:22:50** - Julia:
> nur damit ich es weiß, machst du heute noch die PP? Dann würde ich dir die captions in figma legen. Kanns ja nicht in die Präsi packen :smiling_face_with_tear:

**2025-10-09 16:22:57** - Julia:
> sonst morgen :slightly_smiling_face:

**2025-10-09 16:23:55** - Mert Koc:
> oh stimmt ja :smiling_face_with_tear:
Ich mache die heute noch. Also zumindest das Feedback umsetzten

**2025-10-09 16:25:19** - Julia:
> okay. dann leg ich dir die captions noch rein – kannst dus dann in die präsi (weißt du wo?) legen? Dann kann ich charly kurz schreiben liegt auf den seiten xy

**2025-10-09 16:26:48** - Mert Koc:
> Ich mache das einfach in die präsi die ich hab und schicke sie dann immer an Julia. 
Sie hat das immer gemacht :/ 
Glaub wir können ihr das auch noch morgen schicken 

**2025-10-09 16:27:38** - Julia:
> okay

**2025-10-10 09:11:11** - Julia:
> Helloo!

**2025-10-10 09:11:13** - Julia:
> Wie gehts dir heute?

**2025-10-10 09:11:42** - Mert Koc:
> Hello guten Morgen :slightly_smiling_face:
Ganz gut eigentlich und dir ?

**2025-10-10 09:12:38** - Julia:
> jaa? also nicht schlimmer geworden?

**2025-10-10 09:12:39** - Julia:
> alles okay

**2025-10-10 09:13:34** - Mert Koc:
> Ne nicht schlimmer geworden zum Glück :slightly_smiling_face:
Hab auch Unmengen an Tee getrunken haha

**2025-10-10 09:18:54** - Julia:
> okay guut

**2025-10-10 09:19:05** - Julia:
> ey der Content vom Event gestern kam an..

**2025-10-10 09:19:26** - Mert Koc:
> Btw ich habe gestern noch das Feedback für die Porsche Points gemacht in Figma.
Und heute mache ich den Gardasee Point noch, weil sie ja anscheinend alle drei wollte.
Dann würde ich noch 1-2 aus den neuen Fotos aus der Datenbank raus suchen, dann haben wir insgesamt 4-5 neue Porsche Points für die nächsten Monate. :white_check_mark:

**2025-10-10 09:19:47** - Mert Koc:
> Und wie ist der Content? :smiling_face_with_tear:

**2025-10-10 09:20:10** - Julia:
> jaa perfekt. sag gerne dann wenn du ready bist, ich schicke es Charly trotzdem rüber. Wäre super, wenn du dann die Captions einsetzen kann

**2025-10-10 09:21:01** - Mert Koc:
> Ah zu den Captions gab es ja glaube auch Feedback

**2025-10-10 09:21:16** - Mert Koc:
> "Sie würde gern noch in allen drei Captions dann irgendwie sowas ergänzen wie: Der Weg ist das Ziel, oder die Route lief über Bozen XX und XX bis hin zu XX --&gt; Ziel ist zweitrangig es geht ums Fahren"

**2025-10-10 09:21:34** - Julia:
> genau, das mach ich dann

**2025-10-10 09:24:21** - Mert Koc:
> Wo ist denn der Content vom Event?

**2025-10-10 09:29:54** - Julia:
> <https://www.picdrop.com/nicolasbaerphotographie/2HKCbTvDUg>

Das Reel kann schon mal garnichts, Briefing war kompeltt anders. Aber kann mir auch vorstellen, dass Hanna vor Ort einiges umgeschmissen hat

Fotos teilweise okayish.
Video hab ich noch nicht angeschaut

**2025-10-10 09:32:33** - Julia:
> 

**2025-10-10 09:36:05** - Mert Koc:
> Oh nein :disappointed_relieved:

**2025-10-10 09:36:18** - Mert Koc:
> Jetzt haben wir quasi beide Konzepte nicht?

**2025-10-10 09:38:27** - Julia:
> nicht wirklich

**2025-10-10 09:44:26** - Julia:
> das wäre sooo wichtig gewesen:

**2025-10-10 09:44:27** - Julia:
> <https://www.picdrop.com/nicolasbaerphotographie/VYQ8h76w7R?file=430f63200b5499dede1819a661df2a22>

**2025-10-10 09:45:04** - Mert Koc:
> oh nein ...

**2025-10-10 09:47:04** - Mert Koc:
> Ich glaube da muss jemand von uns vor Ort sein und Anweisungen geben, sonst wird das nix

**2025-10-10 09:47:24** - Julia:
> ja ich versteh auch nicht warum das nie so eingebrieft wurde

**2025-10-10 09:47:44** - Julia:
> also Julia meinte noch evlt. kann basti hin und den content shooten – Flo hatte scheinbar keine Äußerung dazu

**2025-10-10 09:47:56** - Mert Koc:
> maybe its just my eyes aber ich finde viele Videos unscharf und fettig lol
Das licht ist viel zu soft, da mach tmeine IPhone Kamera ja schärfere Aufnahmen

**2025-10-10 09:48:06** - Julia:
> jaa ist so

**2025-10-10 09:48:09** - Julia:
> 100%

**2025-10-10 09:49:09** - Mert Koc:
> Macht Basti den Car Porn oder?

**2025-10-10 09:49:21** - Julia:
> nene

**2025-10-10 09:49:41** - Julia:
> das sind eigentlich nur stills geplant als details – aber vllt ergänzen wir mit videos

**2025-10-10 09:50:05** - Mert Koc:
> Ja Basti wäre besser gewesen, wenn der da hin wäre. Zumindest sollte Budget da sein, dass jemand von uns da hin kann in Zukunft um das zu betreuen. Damit wir am Ende alle Aufnahmen haben, die wir brauchen

**2025-10-10 09:50:21** - Mert Koc:
> Ok, so als Snippets

**2025-10-10 09:50:28** - Julia:
> genau

**2025-10-10 09:50:38** - Mert Koc:
> Ja dafür sollte es reichen denke ich

**2025-10-10 09:50:55** - Julia:
> ach manno echt, hoffe Hanna ist wenigstens mit den Stills schon mal happy. Hab ihr jetzt die orangenen geschickt

**2025-10-10 09:51:22** - Julia:
> Aber das wird spannend mit dem 5120 Reel – glaube der Fotograf hats einfach nicht verstanden was das ist

**2025-10-10 09:53:23** - Mert Koc:
> Das kann man ihr ja kaum zeigen, so peinlich ist das :joy::sob:

**2025-10-10 09:54:24** - Mert Koc:
> Finds auch krass, dass er ohne Stabilisator gedreht hat

**2025-10-10 09:54:34** - Mert Koc:
> Ok ich höre auf, bin lowkey nur am haten

**2025-10-10 09:58:39** - Julia:
> ich auuuch

**2025-10-10 09:58:46** - Julia:
> bin echt etwas geschockt :face_with_spiral_eyes:

**2025-10-10 09:59:19** - Julia:
> 

**2025-10-10 10:00:06** - Mert Koc:
> oh nicolas

**2025-10-10 10:00:34** - Julia:
> Ne das war Hanna

**2025-10-10 10:00:34** - Julia:
> Sorry

**2025-10-10 10:08:22** - Mert Koc:
> oh oke,, krass dass die das süß findet lol

**2025-10-10 10:14:40** - Julia:
> ja

**2025-10-10 10:14:55** - Julia:
> manchmal versteh ich den geschmack nicht :smile:

**2025-10-10 10:20:33** - Mert Koc:
> Ja bin auch komplett verwirrt wieder mal

**2025-10-10 10:24:40** - Julia:
> Also Hanna hat mir gerade geschrieben: wie findest du die Fotos?

**2025-10-10 10:24:42** - Julia:
> Na super

**2025-10-10 10:27:08** - Mert Koc:
> Zum Teil sehr gut (Fahrzeuge und paar Fotos vom Event+Protagonisten)
Andere etwas trüb

**2025-10-10 10:38:04** - Julia:
> :melting_face:

**2025-10-10 10:39:36** - Julia:
> ich geh kurz mit Coco raus – der Fotograf ghosted mich eh

**2025-10-10 10:39:54** - Julia:
> ich hatte dir noch eine kleine task in Asana gelegt

**2025-10-10 11:11:35** - Mert Koc:
> Die Antworten bei Leonie Beck waren echt mau ...
Das sind die "Besten" meiner Meinung nach und 4 davon sind fast gleich:

**2025-10-10 11:12:50** - Mert Koc:
> Das ist mein geheimer Favorit

**2025-10-10 11:20:50** - Julia:
> ja dann lass uns gerne nur einmal Freiheit &amp; einmal Freiheitsgefühl nehmen

**2025-10-10 11:22:13** - Mert Koc:
> Sollen wir noch schnell 2-3 Antworten faken? :sweat_smile:

**2025-10-10 11:22:25** - Julia:
> mach gerne :slightly_smiling_face:

**2025-10-10 11:22:29** - Julia:
> Adrenalin?

**2025-10-10 11:22:38** - Julia:
> Muss jetzt Flo anrufen

**2025-10-10 11:22:49** - Mert Koc:
> Oh will er telefonieren?

**2025-10-10 11:22:57** - Julia:
> ja "was heute ansteht" hä

**2025-10-10 11:24:52** - Julia:
> also wenn du mit PP etc. fertig bist, brauch ich denk ich auf jeden fall deine unterstützung mit dem event content – hanna findet alles grottig

**2025-10-10 11:28:33** - Mert Koc:
> Klar helfe gerne..
Oh Gott :disappointed_relieved:

**2025-10-10 11:35:18** - Julia:
> 

**2025-10-10 11:36:34** - Julia:
> ich hab jetzt schon 3mal geantwortet aber es erscheint nicht??

**2025-10-10 11:37:44** - Mert Koc:
> oh wow ...

**2025-10-10 11:39:05** - Julia:
> 

**2025-10-10 11:42:33** - Mert Koc:
> Haben wir Text für die letzte Slide oder einfach so?

**2025-10-10 11:43:09** - Julia:
> Stimmt. "Eure Antworten"? Oder was hast du da sonst dazu geschrieben?

**2025-10-10 11:49:04** - Mert Koc:
> Ja sowas in die Richtung

**2025-10-10 11:49:58** - Mert Koc:
> Vlt sowas wie "Ihr wisst, was Straße und Wasser gemeinsam haben. Hier sind eure Antworten:"

**2025-10-10 11:50:10** - Julia:
> ja gerne

**2025-10-10 11:52:10** - Mert Koc:
> So :slightly_smiling_face:

**2025-10-10 11:52:51** - Julia:
> oh hatten wir das beim letzten mal nicht einfach so untereinander? ich glaub das wollten sie so oder?

**2025-10-10 11:53:18** - Mert Koc:
> Ich kann beides machen aber letztes mal wollten sie durcheinander von mir

**2025-10-10 11:55:51** - Julia:
> die nerven mich

**2025-10-10 11:55:53** - Julia:
> :smile:

**2025-10-10 11:56:01** - Julia:
> dann schicken wir ihnen doch beide varianten einfach

**2025-10-10 11:56:03** - Julia:
> danke dir

**2025-10-10 12:00:22** - Mert Koc:
> 

**2025-10-10 12:00:55** - Julia:
> danke dir

**2025-10-10 12:00:59** - Mert Koc:
> Wie ist unser To Do beim Event zeug? :slightly_smiling_face:

**2025-10-10 12:01:26** - Julia:
> sollen wir kurz in den huddle? :slightly_smiling_face:

**2025-10-10 12:01:35** - Mert Koc:
> Ja

**2025-10-10 12:02:57** - Julia:
> 

**2025-10-10 12:23:49** - Mert Koc:
> Immer wenn ich denke "ok das Video snippet ist gut" läuft eine Person durchs Bild... krieg echt die Krise hier

**2025-10-10 12:24:03** - Julia:
> :face_with_spiral_eyes:

**2025-10-10 12:24:05** - Julia:
> es ist so wild

**2025-10-10 12:26:43** - Mert Koc:
> Darf ich Sachen Red Flaggen, damit ich sie mir nicht ausversehen 4 mal ansehe ?

**2025-10-10 12:27:51** - Julia:
> ja

**2025-10-10 12:27:53** - Julia:
> unbedingt

**2025-10-10 12:33:13** - Mert Koc:
> :melting_face::skull:

**2025-10-10 12:35:18** - Julia:
> hab grad mit ihm telefoniert

**2025-10-10 12:35:23** - Julia:
> er hat meine mail scheinbar nicht bekommen

**2025-10-10 12:35:25** - Julia:
> AHJA

**2025-10-10 12:35:52** - Mert Koc:
> mmhm safe

**2025-10-10 12:56:51** - Julia:
> <https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/doc2.aspx?sourcedoc=%7BE33428F9-BF0F-4720-B9FE-D8EDF165E52E%7D&amp;file=250924_Porsche_BS_SoMe_Konzepte_JH.pptx&amp;action=edit&amp;mobileredirect=true&amp;previoussessionid=3b2c90dc-2d08-64b7-17f6-e0d24a3f8d04|https://porsche.sharepoint.com/:p:/r/sites/PDMK/_layouts/15/doc2.aspx?sourcedoc=%7BE3342[…]ue&amp;previoussessionid=3b2c90dc-2d08-64b7-17f6-e0d24a3f8d04>

**2025-10-10 12:57:10** - Julia:
> ich leg hier jetzt die stills rein, magst du die video snippets – wenn es welche gibt, dazu packen? also 2 reichen pro fahrzeug

**2025-10-10 13:05:05** - Mert Koc:
> ja ich stabilisiere die erst mal

**2025-10-10 13:26:47** - Julia:
> so eine scheiße echt

**2025-10-10 13:27:34** - Mert Koc:
> besser wirds wirklich nicht :c

**2025-10-10 13:28:02** - Julia:
> aber ist okay!

**2025-10-10 13:28:09** - Julia:
> dankee

**2025-10-10 13:28:14** - Julia:
> magst dus reinlegen?

**2025-10-10 13:29:05** - Mert Koc:
> Ist der Ausschnitt am Anfang besser ?

**2025-10-10 13:29:25** - Julia:
> ja!

**2025-10-10 13:31:03** - Mert Koc:
> Hast du die Fotos etwas kühler gemacht?

**2025-10-10 13:33:22** - Julia:
> kühler nicht einfach bearbeitet

**2025-10-10 13:33:28** - Julia:
> das liegt auch etwas am screenshot

**2025-10-10 13:34:31** - Mert Koc:
> ah ok

**2025-10-10 13:34:37** - Mert Koc:
> habs jetzt in die Präsi rein

**2025-10-10 13:35:55** - Julia:
> cool!

**2025-10-10 13:36:03** - Julia:
> für den 2. hast dus noch nicht oder?

**2025-10-10 13:36:07** - Julia:
> für den orangenen

**2025-10-10 13:36:58** - Mert Koc:
> ne da sind wirklich immer Leute drauf

**2025-10-10 13:37:07** - Mert Koc:
> bin bei jedem Video aufs neue entsetzt

**2025-10-10 13:37:41** - Julia:
> 

**2025-10-10 13:42:07** - Mert Koc:
> yes

**2025-10-10 13:45:00** - Mert Koc:
> Das gibts auch nicht oder ?

**2025-10-10 13:45:25** - Julia:
> nope

**2025-10-10 13:45:40** - Julia:
> aber da meinte hanna schon das traut sie sich nicht weil das mit dem dach kompliziert st

**2025-10-10 14:00:33** - Mert Koc:
> der brownie light jetzt auch drinne

**2025-10-10 14:00:45** - Mert Koc:
> I tried sag ich nur

**2025-10-10 14:01:53** - Julia:
> okay

**2025-10-10 14:02:28** - Julia:
> ich hasse diese online präsis

**2025-10-10 14:02:36** - Mert Koc:
> same

**2025-10-10 14:03:26** - Mert Koc:
> ich passe das an

**2025-10-10 14:03:44** - Julia:
> ich finds garnicht schlecht

**2025-10-10 14:03:49** - Julia:
> ne ich habs schon online

**2025-10-10 14:03:52** - Julia:
> ich antworte da gleich

**2025-10-10 14:05:25** - Mert Koc:
> Es ging in beiden Fällen um das Medium also Straße und Wasser statt Fahren und Schwimmen .... wenn wir Straße zu Fahren machen, müssen wir auch Wasser zu Schwimmen ändern.

**2025-10-10 14:05:52** - Julia:
> omg

**2025-10-10 14:06:00** - Julia:
> ja ich weiß

**2025-10-10 14:08:50** - Julia:
> ich glaube ich bekomme heute noch einen herzinfarkt

**2025-10-10 14:10:09** - Mert Koc:
> Ich weiß ihr oder Julia kommt gut klar mit Charly aber ich halte sie für völlig inkompetent muss ich sagen. Also im Design und Marketing Bereich zumindest. No offense

**2025-10-10 14:10:52** - Julia:
> Ne ich komm garnicht mit ihr klar

**2025-10-10 14:11:12** - Julia:
> eine der schlimmsten Personen die ich je kennengelernt hab

**2025-10-10 14:11:23** - Julia:
> vollkommen

**2025-10-10 14:11:29** - Mert Koc:
> ok danke, dachte ich bin der einzige der das denkt lol

**2025-10-10 14:11:32** - Julia:
> ne

**2025-10-10 14:21:04** - Julia:
> bitte die Frage so anpassen wie sie im Fragesticker auch gestellt wurde. Also „_Ihr wisst, was Fahren und Schwimmen gemeinsam haben. Hier sind eure Antworten:_“

**2025-10-10 14:21:15** - Julia:
> es. ist. so. lächerlich.

**2025-10-10 14:22:20** - Mert Koc:
> Kann die alle nicht leiden

**2025-10-10 14:22:24** - Julia:
> ne

**2025-10-10 14:22:33** - Mert Koc:
> 

**2025-10-10 14:23:35** - Mert Koc:
> Jede Story muss komplett Aalglatt, generisch und emotionslos sein aber Hauptsache in die Marketdecks rein schreiben, wie toll Porsche ist und überall Emotionen und Leidenschaft rein schreiben lol.

**2025-10-10 14:23:45** - Mert Koc:
> Bad Storytelling 101

**2025-10-10 14:24:12** - Julia:
> 100%

**2025-10-10 14:24:32** - Julia:
> und vorallem das Hauptproblem ist ja, dass es keinen unterschied macht, ob da Wasser, schwimmen, fahren oder Straße steht

**2025-10-10 14:24:36** - Julia:
> Straße klingt lockerer, cooler

**2025-10-10 14:24:38** - Julia:
> Aber nein

**2025-10-10 14:25:30** - Mert Koc:
> Ich kann nicht glauben, dass sie es deswegen archiviert haben

**2025-10-10 14:25:36** - Mert Koc:
> Bin wirklich fassungslos

**2025-10-10 14:25:49** - Mert Koc:
> Hoffentlich werde ich die nächsten paar Wochen gefeuert LOL

**2025-10-10 14:26:10** - Julia:
> ne ich auch nicht :smile:

**2025-10-10 14:26:16** - Julia:
> vorallem ES WURDE FREIGEGEBEN

**2025-10-10 14:26:43** - Mert Koc:
> Charly ist so ein controlfreak unglaublich

**2025-10-10 14:29:44** - Julia:
> Danke, ist hiermit freigegeben und kann veröffentlicht werden.
Bitte danach dann die beiden Story Reposts von Leonie.

**2025-10-10 14:29:45** - Julia:
> ja

**2025-10-10 14:29:53** - Julia:
> und da denk ich mir auch: glaubst du ich bin dumm? :smile: ich habs verstanden

**2025-10-10 14:30:15** - Mert Koc:
> hahaaha kann nimmer :joy:

**2025-10-10 14:30:18** - Mert Koc:
> Bin so durch

**2025-10-10 14:30:40** - Julia:
> ich quch

**2025-10-10 14:30:43** - Julia:
> auch

**2025-10-10 14:30:54** - Julia:
> und der Nicolas übertreibt es gerade echt

**2025-10-10 14:31:05** - Mert Koc:
> Ich mach kurz Pause :face_with_spiral_eyes:

**2025-10-10 14:31:09** - Mert Koc:
> Warum was macht er ?

**2025-10-10 14:32:19** - Julia:
> ja mach das :slightly_smiling_face:

**2025-10-10 14:32:22** - Julia:
> Ja nichts

**2025-10-10 14:32:38** - Julia:
> 

**2025-10-10 14:45:42** - Julia:
> okay ich hab Hanna alles geschickt was in der Präsi abliegt – ich muss jetzt auch kurz was essen.
Wielange bist du denn heute da eigentlich?

**2025-10-10 14:46:07** - Mert Koc:
> Perfekt :) 

**2025-10-10 14:46:15** - Mert Koc:
> Bis so 17:30 max und du? 

**2025-10-10 14:47:11** - Julia:
> okay, ja ich auch.
Also ich würde noch die Stories gerne fertig machen die ich abgelegt hab und am Montag müsste man dann das Carousel machen.
Je nachdem was noch ansteht bei dir, könnten wir da noch zusammen dran arbeiten?

**2025-10-10 14:48:19** - Mert Koc:
> Ja können wir gemeinsam machen :+1::skin-tone-2:

**2025-10-10 14:48:32** - Mert Koc:
> Glaub das carousel hat Priorität vor anderen Sachen bei mir 

**2025-10-10 14:58:20** - Julia:
> 

**2025-10-10 15:23:13** - Julia:
> bin wieder da

**2025-10-10 15:23:25** - Mert Koc:
> Ich auch, amche gerade PP

**2025-10-10 15:25:08** - Julia:
> 

**2025-10-10 15:52:59** - Mert Koc:
> Wir müssen bei den Captions die ganzen VBWs noch eintragen fällt mir gerade auf :melting_face:

**2025-10-10 15:53:02** - Mert Koc:
> Oder ?

**2025-10-10 15:53:20** - Julia:
> bei PP?

**2025-10-10 15:53:26** - Julia:
> ja

**2025-10-10 16:00:58** - Mert Koc:
> Ja genau

**2025-10-10 16:01:16** - Mert Koc:
> Ich hab nur keine Ahnung, was das für Fahrzeuge sind :melting_face:

**2025-10-10 16:12:48** - Julia:
> hanna liebt deine video snippets

**2025-10-10 16:13:02** - Julia:
> warte ich schau auch mal rein, liegt in figma oder?

**2025-10-10 16:13:19** - Mert Koc:
> Ja genau

**2025-10-10 16:13:33** - Mert Koc:
> Kannst du mir helfen, das hier leserlicher zu machen:

**2025-10-10 16:13:38** - Mert Koc:
> Oder wir lassen es einfach weg auch ok

**2025-10-10 16:14:24** - Julia:
> moment

**2025-10-10 16:14:28** - Julia:
> mein laptop ist so langsam

**2025-10-10 16:14:42** - Julia:
> halllooo LOB?! <@U093J779DAQ> :smile: von porsche, das muss man feiern

**2025-10-10 16:15:02** - Mert Koc:
> Haha halt echt :joy:

**2025-10-10 16:15:06** - Mert Koc:
> Voll gut !

**2025-10-10 16:15:46** - Julia:
> wollen wir kurz in den huddle?

**2025-10-10 16:16:10** - Mert Koc:
> Yes

**2025-10-10 16:16:30** - Julia:
> 

**2025-10-10 16:17:09** - Julia:
> bin gleich da

**2025-10-10 16:54:28** - Julia:
> captions sind fertig :slightly_smiling_face:

**2025-10-10 16:57:30** - Mert Koc:
> perfekt, dann leg ichs jetzt ab

**2025-10-10 16:57:34** - Julia:
> dankeee

**2025-10-10 16:59:38** - Mert Koc:
> wait welche ist überhaupt die aktuelle

**2025-10-10 17:00:03** - Julia:
> ja das weiß ich nicht

**2025-10-10 17:00:58** - Mert Koc:
> same ich suche gerade

**2025-10-10 17:01:05** - Julia:
> ich auch

**2025-10-10 17:01:22** - Julia:
> Ansonsten kurz neue Präsi erstellen mit den 3 PP?

**2025-10-10 17:01:41** - Mert Koc:
> Ja lowkey beste Lösung

**2025-10-10 17:02:21** - Mert Koc:
> kann ich schnell machen

**2025-10-10 17:02:24** - Mert Koc:
> schicks dir dann

**2025-10-10 17:04:24** - Julia:
> danke!

**2025-10-10 17:04:34** - Julia:
> bin grad am Pooooosten – mehr oder weniger

**2025-10-10 17:23:56** - Mert Koc:
> Hab gerade nen Fehler entdeckt, den ich noch ausbessern muss..
Die Berge hier sind die Dolomiten, nicht Sölden

**2025-10-10 17:24:19** - Julia:
> gut, dass du es gesehen hast :smile:
hab bei den Dolomiten einen kleinen Fehler gefunden in der caption – hier nochmal richtig:

**2025-10-10 17:24:41** - Julia:
> Caption Dolomiten:

Willkommen zurück zu #PorschePoints – in Teil 2 unserer Routen des diesjährigen Porsche Gipfeltreffens nehmen wir euch mit in die majestätischen Dolomiten.

Hier treffen endlose Serpentinen auf steil aufragende Felswände, Nebelschwaden ziehen über die Pässe und jeder Kilometer fühlt sich wie ein Postkartenmotiv an – die Dolomiten sind Bühne und Abenteuer zugleich.

Und das Beste: Die nächste Route wartet schon in den Startlöchern. Was glaubt ihr – wohin geht die Reise?

Habt ihr auch Lust bekommen auf eine eigene Ausfahrt? Dann folgt dieser Route in der ROADS by Porsche App. Mehr Infos dazu findet ihr in den Stories.

-
911 GT3 (WLTP): Kraftstoffverbrauch kombiniert: 13,8 – 13,7 l/100 km; CO₂-Emissionen kombiniert: 312 – 310 g/km; CO₂-Klasse: G; Stand 10/2025

**2025-10-10 17:27:46** - Mert Koc:
> Downgrade des jahrhunderts aber passt das als ersatz Panorama ?

**2025-10-10 17:30:24** - Julia:
> ja

**2025-10-10 17:30:29** - Julia:
> wenigstens sieht man den schnee :smile:

**2025-10-10 17:31:06** - Julia:
> genau und reihenfolge ist:
• gardasee
• dolomiten
• sölden 

**2025-10-10 17:32:07** - Mert Koc:
> Yes

**2025-10-10 17:32:23** - Julia:
> yaaay. ich lads runter

**2025-10-10 17:33:11** - Julia:
> ich passe das titelbild und titel an

**2025-10-10 17:36:15** - Mert Koc:
> Yes ofc :slightly_smiling_face:

**2025-10-10 17:36:25** - Mert Koc:
> Würde mich dann auch aus dem Staub machen ^^

**2025-10-10 17:37:08** - Julia:
> Mach das!

**2025-10-10 17:37:14** - Julia:
> dankeee dir und happy weekend – so verdient

**2025-10-10 17:37:30** - Mert Koc:
> Happy Weekend !

**2025-10-13 16:14:17** - Mert Koc:
> Hab dein Feedback umgesetzt, bis auf den Kommentar, das habe ich nicht ganz verstanden. Du kannst gerne die Frames einfach raus löschen/ die Reihenfolge ändern.

**2025-10-13 16:14:50** - Julia:
> des war nur ein vorschlag, weil sie doch eigentlich dieses tunnelbild nicht so mochten aber kannst es auch gerne so lassen

**2025-10-13 16:15:30** - Mert Koc:
> ah ok, dann mahce ich das raus

**2025-10-13 16:17:21** - Mert Koc:
> Müssen wir jetzt alle VBWs der neuen Fahrzeuge in der Caption ergänzen?

**2025-10-13 16:17:24** - Mert Koc:
> Schon oder?

**2025-10-13 16:20:42** - Julia:
> ja

**2025-10-13 16:20:49** - Julia:
> :melting_face:

**2025-10-14 10:39:34** - Julia:
> ey ich sags dir

**2025-10-14 10:39:45** - Julia:
> charly am morgen bereitet mir wirklich kummer und sorgen :smile:

**2025-10-14 10:39:49** - Julia:
> ich bin so froh, wenn das vorbei ist

**2025-10-14 10:40:01** - Mert Koc:
> oh no :c

**2025-10-14 10:40:04** - Mert Koc:
> die nervt mich auch so krass

**2025-10-14 10:40:15** - Mert Koc:
> was ist jetzt ihr Problem?

**2025-10-14 10:42:24** - Julia:
> wir gehen gerade UGC durch und sie wurde LAUT, "WEIL WIR BEI DER HUNDE KATEGORIE ODER GENERELL NICHT DAS HUNDE BILD VERARBEITET HABEN AUS SYLT – DAS HATTE SIE JETZT MEHR ALS 5 MAL GESAGT...."
2 Sekunden später: "...aber kann ja auch sein, dass es sich vom Motiv nicht anbietet"

**2025-10-14 10:43:57** - Mert Koc:
> Das ist doch alles ein einziger Fiebertraum

**2025-10-14 10:44:03** - Julia:
> komplett

**2025-10-14 10:45:52** - Julia:
> sind da

**2025-10-15 10:36:11** - Julia:
> hello

**2025-10-15 10:36:20** - Julia:
> hat dir Flo immernoch nicht geantwortet?

**2025-10-15 10:36:28** - Julia:
> ich schreib ihm jetzt, ich finde das sooo frech

**2025-10-15 10:38:03** - Mert Koc:
> Ne keine Antowrt leider

**2025-10-15 10:38:14** - Mert Koc:
> weder auf Whatsapp noch auf Slack :disappointed:

**2025-10-15 10:46:15** - Julia:
> kein kommentar

**2025-10-15 11:15:47** - Julia:
> so hab ihm jetzt geschrieben

**2025-10-15 11:15:56** - Julia:
> *Juli*  [11:15 AM]
Hey, ich wollte jetzt nochmal nachfragen, ob es denn generell schon ein Update von Porsche gibt? Du meintest ja letzte Woche bis spätestens Mitte dieser Woche sollte es eine Info geben oder du meldest dich bei uns.
Mert, Julia und ich hängen schon echt sehr in der Luft und selbst, wenn es kein Update gibt weil ihr noch in den Verhandlungen seid, wäre es schon fair zu erfahren, "dass es kein Update gibt".  Porsche hat schon paar mal Andeutungen gemacht, dass es wohl nur noch bis Ende Oktober geht bezüglich Prios etc., das ist natürlich dann schon ein komisches Gefühl, wenn wir das von dir aber noch nicht erfahren haben. Und generell müssten wir uns ja dann auch in 2 Wochen nach einem neuen Job umsehen oder auch nicht..? Hast du hier eine Info für uns? Danke dir

**2025-10-15 11:17:09** - Mert Koc:
> Danke :heart_hands::skin-tone-3:

**2025-10-15 11:17:22** - Mert Koc:
> Jetzt antwortet er mir auch :sweat_smile:

**2025-10-15 11:17:32** - Mert Koc:
> also genau jetzt haha

**2025-10-15 13:10:14** - Julia:
> wow

**2025-10-15 13:10:22** - Julia:
> also Flo hat mir jetzt um 3 ein Meeting eingestellt

**2025-10-15 13:45:40** - Mert Koc:
> Ok :ok_hand::skin-tone-2: 
Keep me updated :grimacing:

**2025-10-15 13:59:51** - Julia:
> klar 

**2025-10-15 15:57:22** - Mert Koc:
> Habe die Caption zu Luganoblau an Hannas Feedback weiter angepasst:

Wir stellen vor: Die Farbe des Monats – Luganoblau.
Mehr als nur eine Farbe – eine bewusste Entscheidung. :blue_heart:
Bei der Community-Konfiguration war dieser Ton euer Favorit.
Grund genug, ihn genauer unter die Lupe zu nehmen.
Wäre Luganoblau auch deine Wahl?

Passt das so?

**2025-10-15 16:06:16** - Julia:
> Ja find ich super

**2025-10-15 16:06:25** - Julia:
> dankeee

**2025-10-15 16:22:06** - Mert Koc:
> uhm .. also gehts für uns nur noch bis ende diesen Monats weiter?

**2025-10-15 16:22:14** - Mert Koc:
> was hat er dir so gesagt?

**2025-10-15 16:29:25** - Julia:
> ich schicke dir eine Sprachi

**2025-10-15 16:29:34** - Julia:
> Aber gottseidank eyyyy

**2025-10-15 16:39:29** - Julia:
> die Luganoblau Story ist noch nicht geupdated, oder? Weil ich grad mit Hanna schreibe und nicht, dass ich falsche Infos rausgebe

**2025-10-15 16:43:01** - Mert Koc:
> ne die muss ich nochupdaten

**2025-10-15 16:43:06** - Mert Koc:
> wollte da nur die 2. Slide upodaten

**2025-10-15 16:46:32** - Mert Koc:
> Glaubst du das passt so?

**2025-10-15 17:12:31** - Julia:
> oder umdrehen? :slightly_smiling_face:
also LUGANOBLAU als HL und dann "Subline" quasi: Eure Wahl...

**2025-10-15 17:14:08** - Mert Koc:
> Ah so quasi?

**2025-10-15 17:15:59** - Julia:
> ja genau

**2025-10-15 17:16:05** - Julia:
> dann ist es präsenter

**2025-10-16 16:37:18** - Julia:
> hallo :slightly_smiling_face:

**2025-10-16 16:37:23** - Julia:
> hast du jetzt was von flo gehört?

**2025-10-16 16:37:34** - Mert Koc:
> nope :confused:

**2025-10-16 16:37:40** - Julia:
> ach komm

**2025-10-16 16:37:44** - Julia:
> das glaub ich nicht

**2025-10-16 16:37:51** - Mert Koc:
> also noch nichts zu dem weitermachen Thema

**2025-10-16 16:38:07** - Mert Koc:
> Ich frage ihn heute mal nochmal :sweat_smile:

**2025-10-16 16:38:27** - Julia:
> das ist doch ganz komisch

**2025-10-16 16:38:39** - Julia:
> ja mach das

**2025-10-16 16:39:01** - Julia:
> weil wenn es jetzt echt vorbei wäre mit 2 wochen kündigungsfrist, dann müsste er ja heute oder morgen was sagen?!

**2025-10-16 16:41:01** - Julia:
> also glaub ich eh nicht, weil dann bräuchtest du ja keinen Urlaub

**2025-10-16 16:41:06** - Julia:
> das ist doch so wild alles

**2025-10-16 16:42:43** - Mert Koc:
> Ja ich findes eh schade, dass wir nicht einfach regelmäßig vom Stand der Dinge erfahren.
I mean an sich ist es nicht schlimm, wenn ich gekündigt werde aber falls er das schon länger weiß, wäre es halt gut es mir zu sagen, weil in 2 Wochen findet man keinen neuen Job heutzutage...

**2025-10-16 16:43:26** - Julia:
> ja denke aber das wird dann auch der fall sein, weil er ja dann wieder voll in den themen drin ist. ich weiß ja nicht wie es am anfang war, aber ich denke er hatte einfach keine lust mehr auf die konfrontation mit porsche

**2025-10-16 16:43:27** - Julia:
> ja total

**2025-10-16 17:20:53** - Julia:
> ich geh jetzt auch mal offline. dann hören wir uns morgen :slightly_smiling_face: schönen abend!

**2025-10-16 17:21:29** - Mert Koc:
> Schönen Abend! :slightly_smiling_face:

**2025-10-16 17:21:43** - Mert Koc:
> (Hab noch keine Antwort nach wie vor)

**2025-10-16 17:22:36** - Julia:
> anklingeln über huddle

**2025-10-16 17:22:41** - Julia:
> dreistigkeit siegt

**2025-10-17 09:52:32** - Julia:
> von hanna

**2025-10-17 09:57:41** - Mert Koc:
> Perfekt, danke

**2025-10-17 10:03:04** - Mert Koc:
> Kriegs Kotzen von der

**2025-10-17 10:04:39** - Mert Koc:
> Die Überschrift muss größer, weil es exakt so groß sein muss wie PAG und dann das andere Assets mit schwarzem BG einfach ändern? Hä

**2025-10-17 10:07:36** - Julia:
> :smile:

**2025-10-17 10:07:41** - Julia:
> wo sind denn die kommentare?

**2025-10-17 10:07:47** - Julia:
> Kannst du die Präsi doch öffnen?

**2025-10-17 10:10:10** - Mert Koc:
> Ja

**2025-10-17 10:10:22** - Mert Koc:
> die sind in der Präsi, die wir an sie gesendet haben

**2025-10-17 10:10:25** - Julia:
> asoo

**2025-10-17 10:10:31** - Julia:
> ja ich kanns nicht öffnen

**2025-10-17 10:10:37** - Julia:
> weil sie es scheinbar verschoben hat

**2025-10-17 10:10:40** - Julia:
> kannst dus mir schicken?

**2025-10-17 10:10:45** - Julia:
> das war ja das was ich gestern meinte haha

**2025-10-17 10:11:30** - Mert Koc:
> Das sind alle kommentierten Folien

**2025-10-17 10:12:00** - Julia:
> ah okay

**2025-10-17 10:12:05** - Julia:
> aber die Texte sind teilweise unten angepasst

**2025-10-17 10:12:14** - Julia:
> deswegen bräuchte ich bitte einmal alles :face_with_peeking_eye:

**2025-10-17 10:14:17** - Mert Koc:
> ok, ist 400mb, dauert kurz nen Moment

**2025-10-17 10:15:39** - Julia:
> danke

**2025-10-17 10:15:46** - Julia:
> es ist SO nervig

**2025-10-17 10:16:05** - Julia:
> da müssen wir echt nochmal alles durchgucken, weil sie ja sogar die HLs angepasst haben will, die liebste Charly

**2025-10-17 10:16:54** - Mert Koc:
> Macht mich lowkey aggro sag ich ganz ehrlich

**2025-10-17 10:16:58** - Julia:
> ja

**2025-10-17 10:20:08** - Julia:
> siehst du ob Hanna da Zugriff hat oder die Präsi geöffnet hat?

**2025-10-17 10:20:10** - Mert Koc:
> boa kann nimmer mit der

**2025-10-17 10:20:37** - Julia:
> Weil wenn ja, wäre es ja perfekt we n du einfach das reel mit UT dort ablegst und sie kann es direkt dort approved 

**2025-10-17 10:20:50** - Mert Koc:
> Ja kann sie

**2025-10-17 10:24:50** - Julia:
> Na wunderbar 

**2025-10-17 10:25:01** - Julia:
> danke :smile:

**2025-10-17 10:25:37** - Julia:
> Soll ich einfach das Halloween Assets nehmen, dass du uns geschickt hast. 
Oder möchtest du hier nochmal was neues machen? 

**2025-10-17 10:29:14** - Mert Koc:
> Ne, du kannst das sehr gerne nehmen

**2025-10-17 10:40:08** - Mert Koc:
> Wir müssen bei dem Reel bei den UT Schatten legen. Ich weiß jetzt schon, dass die alles daran hassen werden. Finds auch kacke aber idk wie ich das handeln soll.
Normalerweiße machen wir den Schatten kaum sichtbar und super blurry aber auch komplett weißen BG finde ich, dass ein klarerer Schatten besser aussieht

**2025-10-17 10:40:29** - Julia:
> ja verstehe. und schwarze Schrift?

**2025-10-17 10:40:31** - Mert Koc:
> Ich wäre dafür, dass wir die Schrift zu schwarz ändern

**2025-10-17 10:40:56** - Mert Koc:
> Ja oder? Also eigentlich muss sie immer weiß sein laut CI aber hier passt das einfach nicht

**2025-10-17 10:42:10** - Julia:
> 

**2025-10-17 10:42:54** - Mert Koc:
> Halt viel besser

**2025-10-17 10:44:23** - Julia:
> jaa voll

**2025-10-17 10:50:58** - Mert Koc:
> Hab die UT fertig :slightly_smiling_face:
Entweder ich bilde es mir ein oder die schwarze Schrift ist dünner als die weiße, auch wenn es exakt gleich ist alles außer die Farbe:

**2025-10-17 10:52:02** - Julia:
> ja sieht dünner aus

**2025-10-17 10:52:10** - Julia:
> kannst du eine kleine kontur drum machen?

**2025-10-17 10:52:44** - Mert Koc:
> Ich mach sie ienfach zu Semibold, dann sehen sie gleich dick aus

**2025-10-17 10:52:48** - Julia:
> jaa perfekt

**2025-10-17 10:52:51** - Mert Koc:
> Passt der Rest?

**2025-10-17 10:54:40** - Julia:
> schuf Porsche --&gt; entwickelte vllt besser?
"es hat neu definiert" --&gt; wer ist es? vllt eher Porsche oder GTS

Und hatte das Gefühl es endet abrupt

**2025-10-17 11:03:26** - Mert Koc:
> Ja das Ende ist sehr abrupt aber das ist ja schon so angeliefert, ich kann da ja nichts ändern :confused:

**2025-10-17 11:04:55** - Mert Koc:
> Zu diesem Kommentar, wie soll ich das am besten anpassen?
Weil wir haben das Asset ohne schwarzen BG nicht...

**2025-10-17 11:20:51** - Mert Koc:
> Habe hier die Werte ausgeschrieben, falls du sie mal brauchen solltest:
Macan GTS (WLTP, vorläufige Werte): Stromverbrauch kombiniert: 20,5-18,5 kWh/100 km;
CO₂-Emissionen kombiniert: 0 g/km; CO₂-Klasse: A; Stand 10/2025

**2025-10-17 11:35:54** - Mert Koc:
> Sorry, dass ich dich so vollspamme haha
Brauche nochmal Hilfe ^^
Welches findest du am Besten? Ich finde die drei rechts cool:

**2025-10-17 12:08:14** - Julia:
> sorry war kurz mit coco draußen 

**2025-10-17 12:08:48** - Julia:
> Da würde ich einfach ein Screenshot aus dem Video nehmen der passt 

**2025-10-17 12:09:45** - Julia:
> ja! Sie wollte noch das mit dem Sonnenuntergang. Dann lass uns ihr 2 vorschlagen? :)

**2025-10-17 12:12:50** - Mert Koc:
> Hab jetzt einfach das hier genommen, weil es ja um das Emblem GTS geht

**2025-10-17 12:13:53** - Mert Koc:
> Ja finde die mit Sonnenuntergang alle nicht so geil wenn ich ehrlich bin.
Sollen wir ihr 2 &amp; 4 vorschlagen?

**2025-10-17 12:14:58** - Julia:
> Ich weiß aber wir wissen, dass sie es am Ende dann trotzdem will :smile:

**2025-10-17 12:16:40** - Mert Koc:
> <https://www.picdrop.com/porsche-deutschland/CAWUtbZB6R|Hier sind die Bilder>. Finde das zweite, das ich ausgesucht habe von den Sonnenuntergang Bildern persönlich am besten. Aber sag gerne, welches du noch gut findest.

**2025-10-17 12:16:42** - Julia:
> Perfekt 

**2025-10-17 12:26:57** - Julia:
> SOS liegt alles ab oder?

**2025-10-17 12:28:14** - Julia:
> Hanna fragt grad

**2025-10-17 12:28:28** - Mert Koc:
> Ja :+1::skin-tone-3:

**2025-10-17 12:28:34** - Julia:
> super, danke

**2025-10-17 12:29:12** - Mert Koc:
> Ich geh was essen :slightly_smiling_face:

**2025-10-17 12:29:19** - Mert Koc:
> Mache Gobi danach

**2025-10-17 12:29:24** - Julia:
> jaa mach das, danke

**2025-10-17 12:29:32** - Julia:
> magst du mir bloß noch kurz das Reel schicken?

**2025-10-17 12:29:58** - Julia:
> Also ablegen + TN - weil hanna ist irgendwie nur bis 14/15 Uhr da und ich muss es noch in Sprinklr hochladen

**2025-10-17 12:30:01** - Mert Koc:
> Das liegt auch schon in der Präsi, die Charly und Hanna haben

**2025-10-17 12:30:08** - Julia:
> ja genau, aber für mcih

**2025-10-17 12:31:15** - Julia:
> aber können auch noch ihre freigabe abwarten. denke mir nur, da wirds ja wohl kein feedback geben :smile:

**2025-10-17 12:32:32** - Julia:
> sorry letzte Frage, weil ichs ja nicht sehe die ganzen Texte die Charly nochmal umgeschrieben hat, hast du in den Assets ersetzt oder? Also zB statt Legende --&gt; Versprechen usw.

**2025-10-17 12:32:38** - Mert Koc:
> Falls sie es doch direkt freigibt, während ich weg bin, liegt es hier: <https://drive.google.com/drive/folders/1jv2T7B9e2ESh3Vm1ZZfU3S8OFMy5_P9s?usp=drive_link>

**2025-10-17 12:32:49** - Julia:
> okay super, danke

**2025-10-17 12:33:13** - Julia:
> wie gesagt, falls sie direkt kommentiert musst du das bitte checken. ich hab ihr wegen der schwarzen Schrift bescheid gegeben :slightly_smiling_face:

**2025-10-17 12:33:18** - Julia:
> dankee und happy lunch

**2025-10-17 12:33:19** - Mert Koc:
> 

**2025-10-17 12:33:56** - Julia:
> alles gut, ich glaubs dir. Ich frag nur, weil ich keine Lust hab Hanna alles erklären zu müssen

**2025-10-17 12:34:07** - Mert Koc:
> Ja versteh ich ^^

**2025-10-17 13:21:51** - Julia:
> Okay Hanna hat 3 Änderungswünsche beim Reel

**2025-10-17 13:22:09** - Julia:
> Sie ist bis 15 Uhr da, lieben wir

**2025-10-17 13:23:45** - Julia:
> sag mir dann gerne Bescheid, wenn du es wieder abgelegt hast in die Präsi. Hoffe es sind nur Kleinigkeiten

**2025-10-17 13:24:12** - Julia:
> Für den Sprinklr Upload bräuchte ich dann bitte auch die Caption die jetzt in der Präsi liegt

**2025-10-17 13:36:46** - Mert Koc:
> Hier hat sie kommentiert "hier brauchen wir doch VBWs?"

**2025-10-17 13:37:17** - Julia:
> ja keine Ahnung, hat PAG ja auch nicht?

**2025-10-17 13:37:23** - Mert Koc:
> Ich glaube bei der 5. Slide tatsächlich auch, da man am Heck des Fahrzeugs "Porsche Macan GTS" liest und damit direkt weiß, welches Modell es ist...

**2025-10-17 13:37:36** - Julia:
> dann packs gerne überall drauf

**2025-10-17 13:37:42** - Julia:
> hauptsache das reel ist fertig

**2025-10-17 13:37:51** - Mert Koc:
> Aber die PAG gibt auch 0 Fucks tbh. Die machen das so selten nach den Regeln gefühlt...

**2025-10-17 13:38:43** - Julia:
> ja versteh ich auch nicht

**2025-10-17 13:38:52** - Julia:
> dann kommentier das gerne, sie kanns ja von dir lesen

**2025-10-17 13:39:30** - Julia:
> kannst du noch alle kommentare von Charly abhaken die du gemacht hast?

**2025-10-17 13:39:42** - Mert Koc:
> Das Reel ist fertig, habe ihr Feedback eingearbeitet und <https://drive.google.com/drive/folders/1jv2T7B9e2ESh3Vm1ZZfU3S8OFMy5_P9s?usp=drive_link|neu hier hochgeladen>.
Das war das Feedback btw:

**2025-10-17 13:40:01** - Julia:
> okay dankeee

**2025-10-17 13:40:03** - Julia:
> ich sags ihr

**2025-10-17 13:40:15** - Julia:
> auch in der Präsi oder?

**2025-10-17 13:40:24** - Julia:
> caption please noch :slightly_smiling_face: dann kann ichs hochladen

**2025-10-17 13:40:52** - Mert Koc:
> eine Sekunde

**2025-10-17 13:41:23** - Mert Koc:
> Ich muss die VBWs noch wie in Ihrem Kommentar in das Story Video + Slide 5

**2025-10-17 13:41:46** - Julia:
> ja easy, nur reel will sie jetzt

**2025-10-17 13:42:18** - Mert Koc:
> Reel ist drinne

**2025-10-17 13:42:49** - Julia:
> :heart:

**2025-10-17 13:49:19** - Mert Koc:
> Ich hoffe sie sieht das :slightly_smiling_face:

**2025-10-17 13:50:30** - Mert Koc:
> Die Reel Caption:
GTS – eine Abkürzung mit Historie.

-
Macan GTS (WLTP, vorläufige Werte): Stromverbrauch kombiniert: 20,5-18,5 kWh/100 km;
CO₂-Emissionen kombiniert: 0 g/km; CO₂-Klasse: A; Stand 10/2025

**2025-10-17 13:51:25** - Mert Koc:
> ... müssen wir nicht theoretisch die VBWs der im Reel gezeigten Fahrzeuge noch ergänzen?

**2025-10-17 14:03:28** - Julia:
> danke dir

**2025-10-17 14:03:31** - Julia:
> ja schon

**2025-10-17 14:03:38** - Julia:
> die stehen alle oben auf der slide oder?

**2025-10-17 14:04:06** - Julia:
> also das ist ja das hier

**2025-10-17 14:04:13** - Julia:
> füg ich ein

**2025-10-17 14:05:20** - Mert Koc:
> Aah!

**2025-10-17 14:05:27** - Mert Koc:
> Hab ich übersehen

**2025-10-17 14:05:55** - Julia:
> 17 uhr ist das reel geplant?

**2025-10-17 14:06:06** - Mert Koc:
> Ja :+1::skin-tone-3:

**2025-10-17 14:06:11** - Julia:
> danke :slightly_smiling_face:

**2025-10-17 14:06:17** - Mert Koc:
> 

**2025-10-17 14:16:01** - Julia:
> so ist auf sprinklr

**2025-10-17 14:16:23** - Julia:
> ist irgendwas für montag früh in der SOS präsentation geplant?

**2025-10-17 14:16:43** - Julia:
> BS Präsi hatte ich ihr auch geschickt, aber hat sie scheinbar kein feedback reingelegt

**2025-10-17 14:17:50** - Mert Koc:
> Ja Montag soll die erste Story gepostet werden

**2025-10-17 14:17:53** - Mert Koc:
> Der teaser

**2025-10-17 14:18:13** - Julia:
> ah okay

**2025-10-17 14:18:30** - Julia:
> ja gut das muss ich eh händisch machen wegen flammen sticker

**2025-10-17 15:14:19** - Julia:
> Hast du zufälligerweise die ganzen Assets schon abgelegt? Vllt lad ich sie doch nich hoch 

**2025-10-17 15:14:56** - Mert Koc:
> ne aber dauert ja nicht lange, kann ich direk tmachen

**2025-10-17 15:17:30** - Mert Koc:
> Ah die Feed Carousels muss ich dir auch ablegen oder ?

**2025-10-17 15:18:38** - Mert Koc:
> Sorry, hab das von Hanna jetzt erst gesehen:

**2025-10-17 15:18:51** - Mert Koc:
> Aber ist erst für 22.10. von daher nicht so schlimm hoffe ich

**2025-10-17 15:31:19** - Julia:
> Ja genau

**2025-10-17 15:31:28** - Julia:
> Aber kein Stress, Montag dann meinte Hanna jetzt auch

**2025-10-17 15:31:41** - Julia:
> ja gut, da sollen sich Charly und hanna drum streiten :smile:

**2025-10-17 15:31:45** - Julia:
> danke Mert :slightly_smiling_face:

**2025-10-17 15:31:53** - Julia:
> Gobi würde ich noch rausschicken, thats it

**2025-10-17 15:41:30** - Mert Koc:
> Ich habe jetzt in Asana bei allen SoS Aufgaben den Ablageort, die Caption + Post Datum eingefügt.

**2025-10-17 15:41:47** - Mert Koc:
> Dann findest du dort immer alles und musst hier nicht im Chat suchen

**2025-10-17 15:42:40** - Julia:
> ach dankeee

**2025-10-17 15:45:09** - Mert Koc:
> Wissen wir welche Fahrzeuge in Gobi waren?

**2025-10-17 15:47:51** - Julia:
> Also Mert das MUSST du doch von den Bildern erkennen

**2025-10-17 15:47:54** - Julia:
> :joy:

**2025-10-17 15:48:03** - Julia:
> Ich hab kA. Macan wahrscheinlich, oder?

**2025-10-17 15:50:15** - Mert Koc:
> Ich hab wirklich absolut keine Ahnung hahaha

**2025-10-17 15:51:21** - Mert Koc:
> Ich glaube sogar, dass es komplett verschiedene sind und nicht nur ein Modell

**2025-10-17 15:52:22** - Julia:
> GPT?

**2025-10-17 15:53:00** - Julia:
> Brauchst du das fürs Wallpaper?

**2025-10-17 15:54:25** - Mert Koc:
> Ich glaube eigentlich nicht, da man das Derivat nicht sieht und somit die VBW nicht angeben muss.
ABER so wie ich Charly kenne, rastet sie komplett aus, wenn wir es nicht drauf machen.

**2025-10-17 15:54:58** - Mert Koc:
> Egal ich finde jetzt einfach nacheinander heraus, was das für Modelle sind:

**2025-10-17 15:56:30** - Mert Koc:
> dauert nur ein bisschen, weil ich das Aussehen mit der Datenbank abgleichen muss.

**2025-10-17 15:57:49** - Julia:
> okay

**2025-10-17 15:57:52** - Julia:
> danke dir

**2025-10-17 15:57:57** - Julia:
> sag wenn ich mit suchen soll

**2025-10-17 15:58:12** - Julia:
> Gab grad nochmal stress in whatsapp wegen reel, passt jetzt

**2025-10-17 15:58:37** - Mert Koc:
> oh gott, was war?

**2025-10-17 16:13:16** - Mert Koc:
> Hast du hier drauf Zugriff?
<https://porsche.sharepoint.com/:p:/r/sites/PDMK/Shared%20Documents/General/UMZUG/Digitales%20Marketing/Social/Insta/08_Redaktionsplanung/Contents/2025/08_August/250826_Wallpaper%20Fortsetzung%20nach%20It%27s%20911%20o%20clock.pptx?d=w35707b38107349929b84554a7288812c&amp;csf=1&amp;web=1&amp;e=hOKOdm&amp;nav=eyJzSWQiOjI3NSwiY0lkIjoxMDAzMDQyNzIzfQ|250826_Wallpaper Fortsetzung nach It's 911 o clock.pptx>

**2025-10-17 16:13:41** - Julia:
> sie meinten da wäre ein grauer rand drumrum – dachte schon sie meinen den verlauf :smile:
also nochmal alles löschen &amp; alles neu hochladen..
Immer noch grauer Rand bei ihrer Ansicht, bei mir nicht

**2025-10-17 16:13:52** - Julia:
> Ne..

**2025-10-17 16:14:07** - Mert Koc:
> Die haben echt Probleme das ist krass

**2025-10-17 16:14:25** - Julia:
> Aber kann ja den Link vllt einfach sharen? Und du sagst mir auf welchen Slides die Updates liegen

**2025-10-17 16:14:58** - Mert Koc:
> Hab die beiden mal angelegt.
Das mit dem Sonnenuntergang ist nur ein Kommentar von Julia in Asana. Außer die haben sich das wirklich gewünscht.

**2025-10-17 16:15:10** - Julia:
> Ne das war mein Kommentar :slightly_smiling_face:

**2025-10-17 16:15:20** - Mert Koc:
> AAh oke

**2025-10-17 16:16:04** - Julia:
> lieb ja Nr. 1

**2025-10-17 16:16:17** - Julia:
> Welche Slides in der Präsi sind das? Dann schreib ich das dazu

**2025-10-17 16:16:21** - Mert Koc:
> Ich auch .. hab das sogar grad als HG XD

**2025-10-17 16:17:08** - Mert Koc:
> Der Link geht direkt zur Folie mit den Gobi HG
<https://porsche.sharepoint.com/:p:/r/sites/PDMK/Shared%20Documents/General/UMZUG/Digitales%20Marketing/Social/Insta/08_Redaktionsplanung/Contents/2025/08_August/250826_Wallpaper%20Fortsetzung%20nach%20It%27s%20911%20o%20clock.pptx?d=w35707b38107349929b84554a7288812c&amp;csf=1&amp;web=1&amp;e=nowRzB&amp;nav=eyJzSWQiOjI3NSwiY0lkIjoxMDAzMDQyNzIzfQ>

**2025-10-17 16:17:10** - Julia:
> haha cool

**2025-10-17 16:17:14** - Julia:
> ah super!

**2025-10-17 16:17:39** - Mert Koc:
> Aber ist Folie 7, falls du das dazu schreiben willst.

**2025-10-17 16:18:32** - Mert Koc:
> Evlt. auch dazu, dass die Sonnenuntergang Bilder für 9x16 nich tso gut geeignet sind:
(Sonne und Fahrzeug sind nicht in einem Bild bei 9x16 Anschnitt)

**2025-10-17 16:18:46** - Julia:
> ja das ist super, danke

**2025-10-17 16:19:28** - Julia:
> mail ist raaaaus

**2025-10-17 16:20:11** - Mert Koc:
> Niiice

**2025-10-17 16:27:14** - Julia:
> dann wars das für heute

**2025-10-17 16:27:16** - Mert Koc:
> Haben wir Feierabend? :grin:

**2025-10-17 16:27:22** - Mert Koc:
> Niice haha

**2025-10-17 16:27:36** - Julia:
> ja 100%

**2025-10-17 16:27:48** - Julia:
> mir reichts mit diesem Drama für die woche haha

**2025-10-17 16:27:53** - Julia:
> Hat sich Flo gemeldet???

**2025-10-17 16:27:56** - Julia:
> wichtigste Frage

**2025-10-17 16:28:35** - Mert Koc:
> Same haha

**2025-10-17 16:28:38** - Mert Koc:
> Ne lol

**2025-10-17 16:28:47** - Mert Koc:
> Ist online aber keine Antwort

**2025-10-17 16:28:54** - Julia:
> ich versteh das nicht

**2025-10-17 16:29:01** - Julia:
> es kann doch nicht sein?

**2025-10-17 16:29:11** - Julia:
> ich würde austicken

**2025-10-17 16:29:58** - Mert Koc:
> Ich bins gewohnt

**2025-10-17 16:32:25** - Julia:
> ne also echt...

**2025-10-17 16:32:50** - Julia:
> Mert, schönes Wochenende und lass uns sonst doch am Montag wirklich Flo ins Meeting holen und das ansprechen, das geht nicht.

**2025-10-17 16:33:26** - Julia:
> :heart_hands:

**2025-10-20 11:44:40** - Julia:
> 

**2025-10-20 11:44:50** - Julia:
> könntest du es in die präsi ablegen? :slightly_smiling_face:

**2025-10-20 11:45:03** - Mert Koc:
> Yes :slightly_smiling_face:

**2025-10-20 11:45:06** - Julia:
> dankee

**2025-10-20 11:45:18** - Julia:
> hab 0,00032 grad gedreht

**2025-10-20 11:45:22** - Julia:
> :new_moon_with_face:

**2025-10-20 11:46:37** - Mert Koc:
> Sie hat übrigens mir mal verboten Bilder zu drehen oder zu spiegeln, deswegen funny, das sie das jetzt wollte

**2025-10-20 11:46:55** - Mert Koc:
> Wie immer inkonsistent in ihren Entscheidungen

**2025-10-20 11:47:07** - Mert Koc:
> Liegt in der Präsi :white_check_mark:

**2025-10-20 11:48:26** - Julia:
> perfekt

**2025-10-20 12:23:41** - Julia:
> könntest du mir kurz einen screenshot vom gardasee PP schicken?

**2025-10-20 12:23:48** - Julia:
> Also das was gerade in der Präsi liegt

**2025-10-20 12:30:25** - Mert Koc:
> Yes ich schau mal, ob ich die aktuelle Version habe

**2025-10-20 12:34:32** - Mert Koc:
> Ich glaube es wurde raus gelöscht

**2025-10-20 12:35:03** - Julia:
> echt?

**2025-10-20 12:35:25** - Julia:
> also die version die Julia/ Charly immer präsentieren ist mit einigen Screenshots fürs titelbild auf jeden falll

**2025-10-20 12:35:49** - Julia:
> aber gut, dann muss ich es Julia so schicken

**2025-10-20 12:35:51** - Julia:
> danke!

**2025-10-20 12:36:15** - Mert Koc:
> Also in der Version, die habe, gibt es keine Gardasee Slides mehr :confused:

**2025-10-20 12:36:26** - Julia:
> lieb ich

**2025-10-20 12:44:36** - Mert Koc:
> :melting_face::disappointed:...

**2025-10-20 12:44:41** - Mert Koc:
> *opens StepStone

**2025-10-20 12:44:51** - Mert Koc:
> spaß haha

**2025-10-20 12:48:01** - Julia:
> oh man

**2025-10-20 12:48:07** - Julia:
> aber wenigstens eine antwort

**2025-10-20 12:48:42** - Julia:
> ich glaube er versteht nicht, dass kommunikation auch mal bedeutet einfach keine antwort zu haben

**2025-10-20 12:49:20** - Mert Koc:
> Ja halt wirklich :sweat_smile:

**2025-10-20 13:22:29** - Mert Koc:
> Ich hab von Emmy dieses Feedback zu den Weeklies bekommen:
Wäre es vielleicht noch möglich, dass wir das „Ausgebucht“ etwas mehr hervorheben?
In meinem Kopf sieht das eher wie eine Art „Sticker“ aus. Ihr habt da sicher ein besseres Auge als ich.
Momentan geht es etwas unter und sieht aus, als würde es standardmäßig zu dem Event gehören.

**2025-10-20 13:22:52** - Mert Koc:
> Deswegen wollte ich evtl. sowas vorschlagen, was denkst du ?

**2025-10-20 13:26:25** - Julia:
> dann würde ich Nr. 2 nehmen

**2025-10-20 15:29:46** - Julia:
> soll ich schnell?

**2025-10-20 15:30:33** - Julia:
> alles so wild – die haben sie selbst umgeschrieben aber uns ja nicht bescheid gegeben und ich dachte das ist falsch, weil englisch

**2025-10-20 15:31:04** - Mert Koc:
> Ok das ist wirklich absolut insane 

**2025-10-20 15:31:11** - Mert Koc:
> Jeden Tag ein neuer Shock 

**2025-10-20 15:31:18** - Julia:
> ja

**2025-10-20 15:31:30** - Mert Koc:
> Ja du kannst das gerne machen, weil ich Check gar nichts mehr 

**2025-10-20 15:31:53** - Julia:
> ja versteh ich :smile:

**2025-10-21 12:54:04** - Julia:
> ich hab angefangen Figma aufzuräumen und es immer mit Sektionen verdeutlicht: Grün --> final/ Ready, Rot logischerweise Iterationen oder nicht ready
Würdest du das bei Porsche Points + den Single Posts + Wallpaper machen? Da hab ich nicht so den überblick :slightly_smiling_face: dankee

**2025-10-21 12:59:27** - Mert Koc:
> Yes kann ich machen :slightly_smiling_face:

**2025-10-21 13:05:47** - Julia:
> gleiches Spiel beim Brand Store

**2025-10-22 14:39:34** - Julia:
> Halloo

**2025-10-22 14:39:40** - Julia:
> wie gehts dir?

**2025-10-22 14:39:46** - Julia:
> zählst du auch die tage bis es rum ist? :smile:

**2025-10-22 14:40:48** - Mert Koc:
> Halloo ^^
Idk schon sehr depressing :confused:

**2025-10-22 14:41:08** - Mert Koc:
> Aber ja, ich warte nur darauf, dass ich die Nachricht bekomme haha

**2025-10-22 14:41:27** - Julia:
> ja voll

**2025-10-22 14:41:32** - Julia:
> also ich meine jetzt nur Porsche

**2025-10-22 14:41:34** - Julia:
> nicht generell

**2025-10-22 14:42:30** - Mert Koc:
> Ja same

**2025-10-22 14:42:55** - Mert Koc:
> hätte ein echt cooler Kunde sein können aber ich habe halt auch einfach keine Lust mehr auf die

**2025-10-22 14:43:51** - Mert Koc:
> Jede Idee, die nicht komplett langweilig ist, wird halt direkt abgelehnt ohne guten Grund

**2025-10-22 15:30:39** - Julia:
> total

**2025-10-22 15:30:45** - Julia:
> und so ein Drama um alles

**2025-10-22 15:31:01** - Julia:
> einfach nur stress und anstrengend für alle beteiligten personen

**2025-10-22 15:35:37** - Mert Koc:
> Jaa, bin auch froh, wenn es vorbei ist!

**2025-10-22 15:38:37** - Julia:
> ich sag Hanna Bescheid wegen Halloween

**2025-10-24 09:48:51** - Mert Koc:
> Wie genau machst du das mit den Zwiebeln? :sweat_smile:
Und sind es rote oder weiße?

**2025-10-24 09:49:03** - Mert Koc:
> Und guten Morgen haha :sunny:

**2025-10-24 09:59:30** - Julia:
> Guten Morgen!

**2025-10-24 09:59:32** - Julia:
> WIe gehts dir?

**2025-10-24 09:59:51** - Julia:
> Ehm glaube das ist egal, habs auch schon mit Schalotten probiert

**2025-10-24 10:00:23** - Julia:
> Also ganz klein schneiden in Würfelchen und dann eine Socke zB, die Socke zu machen und dann in den Ofen für paar Minuten

**2025-10-24 10:00:53** - Julia:
> Also die ganze Wohnung und du riecht danach nach Zwiebeln aber es hilft soo krass. Ich setze dann immer eine Mütze auf und steck diese Säckchen dann so fest :smile:

**2025-10-24 10:01:54** - Julia:
> Wollen wir so um 11 sprechen? Müsste jetzt noch kurz mit coco raus, hab voll verschlafen

**2025-10-24 10:22:44** - Mert Koc:
> ok danke für den Tipp!

**2025-10-24 10:22:59** - Mert Koc:
> Es tut halt so sau weh, ich frag jetzt mal bei meinem Hausarzt ob ich vorbei kommen kann

**2025-10-24 12:02:56** - Mert Koc:
> Hello
Ich bin wieder am Start.
Gibt es irgendwelche wichtigen Prios?
Sonst würde ich jetzt die Weekly Highlights vom BS + Macan GTS Beratungstermin machen.

**2025-10-24 12:03:10** - Julia:
> welcome back

**2025-10-24 12:03:24** - Julia:
> ne das wäre tatsächlich die Prio soweit ich es sehe

**2025-10-24 12:03:56** - Julia:
> das ist für den Brand Store ge?

**2025-10-24 12:07:21** - Mert Koc:
> Ja genau

**2025-10-24 13:43:58** - Julia:
> magst du mir bescheid geben, wenn dus abgelegt hast in dr präsi? :slightly_smiling_face: dann schicke ich es Hanna

**2025-10-24 13:45:13** - Mert Koc:
> Ja schicken wir es über die Präsi?
Weil normalerweise schicke ich Highlights immer per Mail.

**2025-10-24 13:45:57** - Mert Koc:
> Den Post dazu mache ich gerade und dachte vielleicht ist es besser, wenn wir da den Fokus nicht nur auf Fahrzeug legen sondern auch auf die Innenausstattung, da es ja um einen Beratungstermin/ Konfiguration geht :slightly_smiling_face:

**2025-10-24 13:54:44** - Julia:
> also da wir den Post in die Präsi nehmen "müssen" hätte ich sonst gesagt, packen wir beides rein

**2025-10-24 13:55:02** - Julia:
> aber kannst die highlights ja trotzdem per mail schon verschicken

**2025-10-24 13:55:03** - Julia:
> ja gerne!

**2025-10-24 14:05:14** - Mert Koc:
> Ich habe jetzt beides fertig, kannst du dir gerne ansehen und Feedback geben oder einfach ändern: <https://www.figma.com/design/JrbypsbvDwTvRRgwvqhdvd/Porsche-BS-%F0%9F%9B%8D%EF%B8%8F?node-id=58-81>

**2025-10-24 14:06:33** - Julia:
> okay moment :slightly_smiling_face:

**2025-10-24 14:10:14** - Julia:
> cool! Hab 2 kleine Sachen kommentiert

**2025-10-24 14:20:31** - Mert Koc:
> Hab das Feedback umgesetzt und hier hochgeladen: <https://porsche.sharepoint.com/:p:/r/sites/PDMK/Shared%20Documents/Brand%20Store/08%20Social%20Media/Konzepte/Konzept%20BCC%202025/250924_Porsche_BS_SoMe_Konzepte_JH.pptx?d=we33428f9bf0f4720b9fed8edf165e52e&amp;csf=1&amp;web=1&amp;e=TPU2XY&amp;nav=eyJzSWQiOjM2MywiY0lkIjoxOTQ2NTU5MDE4fQ|250924_Porsche_BS_SoMe_Konzepte_JH.pptx>

**2025-10-24 14:20:41** - Julia:
> ach mega, danke dir

**2025-10-24 14:21:50** - Julia:
> ich sags Hanna, sobald ich meine Updates auch wieder abgelegt hab

**2025-10-24 14:21:54** - Julia:
> Runde 14959392 :smile:

**2025-10-24 14:22:05** - Mert Koc:
> vielleicht eben in der Mail an Hanna noch argumentieren, dass wir Detailshots genommen haben, weil es um die Beratung / Konfiguration geht :slightly_smiling_face:

**2025-10-24 14:22:07** - Julia:
> Weiß nicht, wie man sich textlich immer so versteifen kann

**2025-10-24 14:22:22** - Mert Koc:
> Boa ja

**2025-10-24 14:22:38** - Julia:
> ja gute Idee! Du kannst es auch gerne als Info auf die Carousel Slides legen, ich pack das auch immer als Info nochmal dazu

**2025-10-24 14:31:29** - Julia:
> habs ihr geschickt

**2025-10-27 14:24:51** - Julia:
> Hallloo, kam nochmal was beim Arzt raus?

**2025-10-27 14:33:15** - Mert Koc:
> Ne sie hat gesagt, dass es nichts mit dem Ohr zutun hat :disappointed:
Sie hat gesagt, dass ich zum Zahnarzt soll und der sich meinen Kiefer anschauen soll, weil stechender Ohren Schmerz fast immer vom Kiefer kommt anscheinend

**2025-10-27 14:34:00** - Julia:
> ach mensch

**2025-10-27 14:36:48** - Mert Koc:
> Ja :confused:

**2025-10-30 12:56:16** - Julia:
> Mert bist du sehr busy heute?

**2025-10-30 13:02:15** - Mert Koc:
> Nein nicht so wieso? :) 

**2025-10-30 13:07:17** - Julia:
> uii oke :slightly_smiling_face:

**2025-10-30 13:07:26** - Julia:
> hättest du Lust mir kurz hierbei zu helfen:

**2025-10-30 13:07:42** - Julia:
> <https://app.asana.com/1/1199360402832734/project/1211017007394565/task/1211785877307249?focus=true>

**2025-10-30 13:09:05** - Julia:
> Julia meinte "soll wie der lieblingspost sein" den wir schon mal gemacht haben. Würde mir gerade total helfen, wenn du eine kurze Bildauswahl triffst und die gerne einfach in figma ziehst. kann sie dann in 4x5 ablegen und caption etc.

**2025-10-30 13:11:52** - Mert Koc:
> Was ist denn der lieblingspost ? :thinking_face:

**2025-10-30 13:14:01** - Julia:
> der liegt da in diesem pdf - siehst dus?

**2025-10-30 13:15:40** - Mert Koc:
> Ah ja :slightly_smiling_face:

**2025-10-30 13:15:58** - Mert Koc:
> Dann ziehe ich einfach die Bilder in Figma, das sind eh schon die finalen, wie es aussieht

**2025-10-30 13:16:20** - Mert Koc:
> Krass, wie die Bilder besser sind als von jedem Fotografen lol

**2025-10-30 13:17:11** - Julia:
> jaa genau! gerne deine lieblingsbilder :slightly_smiling_face: und Hanna meinte am besten soll sich der content nicht doppeln (ist ja logisch)

**2025-10-30 13:17:27** - Julia:
> _bei ein zwei sind mehrere Fotos drin, da würde ich dann zb auf den launch control knopf gehen und so wählen, dass sich bilder nicht doppeln_

**2025-10-30 13:17:35** - Julia:
> na super

**2025-10-30 13:17:42** - Julia:
> dankeee dir!

**2025-10-30 13:28:49** - Mert Koc:
> Muss von jeder Person ein Foto rein? Nicht oder ?

**2025-10-30 13:29:42** - Julia:
> ich glaube nicht

**2025-10-30 13:30:37** - Julia:
> gibts noch ein foto mit menschen drauf?

**2025-10-30 13:30:53** - Mert Koc:
> Ne in dem Ordner nicht :confused:

**2025-10-30 13:31:02** - Julia:
> ach mist

**2025-10-30 13:31:03** - Julia:
> okay :smile:

**2025-10-30 13:31:55** - Mert Koc:
> Das sind wirklich ALLE Bilder die in dem Download drinnen waren

**2025-10-30 13:32:06** - Julia:
> ist ja wild

**2025-10-30 13:32:15** - Julia:
> aber dankeee Mert, schau ich mir jetzt an :heart_hands:

**2025-10-30 13:32:24** - Mert Koc:
> Bitte :slightly_smiling_face:

**2025-10-30 14:20:22** - Julia:
> Wenn du morgen auch kannst, würden um 13Uhr den Übergabe Termin mit Jana machen

**2025-10-31 09:16:43** - Julia:
> Hallooo

**2025-10-31 09:28:56** - Mert Koc:
> Guten Morgen :grimacing:
Wir brauchen das Meeting heute nicht oder ? 

**2025-10-31 09:29:31** - Julia:
> nee :slightly_smiling_face:

**2025-10-31 09:30:19** - Julia:
> Also Jana hat sich auch nichtmehr zurückgemeldet

**2025-10-31 09:30:25** - Julia:
> Keine Ahnung, wegen dem Übergabe Termin heute

**2025-10-31 09:30:29** - Julia:
> lieb ich

**2025-10-31 09:31:55** - Mert Koc:
> Oh wow :disappointed_relieved:

**2025-10-31 09:32:25** - Mert Koc:
> Wann wäre das nochmal? Weil ich hab’s nicht im Kalender 

**2025-10-31 09:34:11** - Julia:
> hatten mal 13Uhr besprochen

**2025-10-31 09:45:23** - Mert Koc:
> Ah oke, dann haben sie ja noch Zeit zu antworten 

**2025-10-31 09:53:07** - Julia:
> yes

**2025-10-31 09:53:25** - Julia:
> könntest du mir kurz sagen, welche Highlights ich hochladen soll? in porschecore :)

**2025-10-31 11:54:08** - Julia:
> also Jana ist heute zu busy. Hab vorgeschlagen Montag 9.30 – weil um 10Uhr will Flo mit uns sprechen

**2025-10-31 12:23:38** - Mert Koc:
> Alles klar danke :pray::skin-tone-3: 

**2025-10-31 12:23:48** - Mert Koc:
> Dann haben wir heute eigentlich nichts mehr zutun oder? :sweat_smile:

**2025-10-31 12:32:56** - Julia:
> ne

**2025-10-31 12:33:04** - Julia:
> musste grad noch 2 Sachen verschicken aber sonst nixmehr

**2025-10-31 12:33:10** - Julia:
> Sind ja heute eigentlich auch eh alle off

**2025-10-31 12:33:14** - Julia:
> ganz wild

**2025-10-31 12:45:26** - Mert Koc:
> Hmm dann schönen Feierabend haha :grimacing::sun_with_face:

**2025-10-31 13:14:19** - Julia:
> haha dir auch :heart:

**2025-11-03 09:06:04** - Mert Koc:
> Guten morgen :sun_with_face: 
Wir haben heute bisher nur das Meeting mit Flo um 10 Uhr oder? 
Oder hat Jana sich gemeldet? 

**2025-11-03 09:10:36** - Julia:
> Hello! :slightly_smiling_face:

**2025-11-03 09:10:40** - Julia:
> Bisher weder noch

**2025-11-03 09:10:54** - Julia:
> Hatte Jana drum gebeten den Termin um 9.30 einzustellen

**2025-11-03 09:10:55** - Julia:
> Nichts

**2025-11-03 09:11:14** - Julia:
> Ich hab kA. ILass uns um 9.30 mal bereit sein und dann lets see

**2025-11-03 09:11:56** - Julia:
> Lieb ich schon wieder

**2025-11-03 09:14:06** - Mert Koc:
> Ok! :sweat_smile:

**2025-11-03 09:31:27** - Julia:
> Hab ihr jetzt nochmal geschrieben

**2025-11-03 09:31:49** - Julia:
> Mert, wiesooooo können wir nicht mal mit normalen menschen arbeiten :smile:

**2025-11-03 09:33:23** - Mert Koc:
> Hahaha :laughing: 

**2025-11-03 09:34:01** - Julia:
> geil sie lügt einfach

**2025-11-03 09:34:14** - Julia:
> meint sie hat einen termin eingestellt mit der falschen julia. im kalender ist nichts

**2025-11-03 09:34:18** - Julia:
> kommt jetzt gleich

**2025-11-03 09:34:41** - Mert Koc:
> Ok :sweat_smile:
Omg :face_with_peeking_eye:

**2025-11-03 09:37:09** - Julia:
> termin ich von 10.30 - 11.30

**2025-11-03 09:38:01** - Mert Koc:
> Alles klar :ok_hand::skin-tone-2: 

**2025-11-03 09:38:08** - Mert Koc:
> Dann bis später ^^ 

**2025-11-03 09:52:36** - Julia:
> hast du schon gehalt bekommen btw?

**2025-11-03 09:55:04** - Mert Koc:
> ne :( 
Und auch die Hälfte vom September fehlt bei mir noch :sweat_smile:

**2025-11-03 09:58:10** - Julia:
> na super

**2025-11-03 09:59:19** - Mert Koc:
> Jup :pensive:

**2025-11-03 09:59:26** - Mert Koc:
> Hast du’s auch noch nicht ? 

**2025-11-03 10:00:23** - Julia:
> Nee

**2025-11-03 10:00:42** - Julia:
> hatte letzten Monat Flo auch dazu geschrieben und da kams dann paar Std. später

**2025-11-03 10:14:12** - Mert Koc:
> Oh man :face_palm::skin-tone-2: 
Glaube halt wirklich, dass die keine Buchhaltung haben :sweat_smile:

**2025-11-03 10:18:52** - Mert Koc:
> Hast du im Moment etwas zutun oder wartest du auch einfach nur? :sweat_smile:

**2025-11-03 10:19:24** - Julia:
> ja aber das geht ja trotzdem nicht

**2025-11-03 10:19:26** - Julia:
> ne ich warte auch nur

**2025-11-03 10:19:51** - Julia:
> wir können ja ohne übergabe auch garnichts machen

**2025-11-03 10:19:55** - Julia:
> das muss Flo ja auch klar sein

**2025-11-03 10:20:28** - Mert Koc:
> Ja finde es auch gar nicht gut :pensive:

**2025-11-03 11:17:34** - Julia:
> guuuudde laune

**2025-11-03 12:54:51** - Julia:
> puh

**2025-11-03 12:55:11** - Mert Koc:
> sollen wir kurz Langebesprechung machen? ^^

**2025-11-03 12:55:16** - Mert Koc:
> Und danach Pause ^^

**2025-11-03 12:58:33** - Julia:
> gernee

**2025-11-03 12:58:45** - Julia:
> klappt es bei dir hier über slack?

**2025-11-03 12:59:04** - Mert Koc:
> ja

**2025-11-03 12:59:24** - Mert Koc:
> 

**2025-11-03 14:26:51** - Julia:
> Mert mit welcher Mail Adresse loggst du dich jetzt bei figma ein?

**2025-11-03 14:29:28** - Mert Koc:
> mit der porsche.deutschland ^^

**2025-11-03 14:29:51** - Mert Koc:
> machen wir alle oder ?

**2025-11-03 14:30:29** - Julia:
> okay

**2025-11-03 14:30:34** - Julia:
> ja glaub das sollten wir umstellen

**2025-11-03 14:31:06** - Julia:
> ich schreibe flo

**2025-11-03 14:31:18** - Mert Koc:
> ok

**2025-11-03 14:31:28** - Mert Koc:
> ist was passiert oder ?

**2025-11-03 14:32:41** - Julia:
> wie meinst?

**2025-11-03 14:33:41** - Mert Koc:
> warum können wir es nicht wie bisher machen?

**2025-11-03 14:35:55** - Julia:
> aso

**2025-11-03 14:36:15** - Julia:
> Flo möchte da einen zentralen benutzer haben. nicht mehr porsche

**2025-11-03 14:36:47** - Mert Koc:
> all right

**2025-11-03 14:37:00** - Mert Koc:
> aber das ist trotzdem unsere Mail oder? Also nicht die von Porsche

**2025-11-03 14:37:44** - Julia:
> ja genau

**2025-11-03 14:37:55** - Julia:
> ich versuch mal das zurückzusetzen

**2025-11-03 14:37:59** - Julia:
> falls du raus geschmissen wirst

**2025-11-03 14:41:00** - Mert Koc:
> oke

**2025-11-03 14:54:17** - Julia:
> der google login ist:

**2025-11-03 14:54:29** - Julia:
> Login via Google:
<mailto:clients@boldcreators.club|clients@boldcreators.club>
_clients@bcc2023!

**2025-11-03 14:54:52** - Julia:
> Flo kriegt da einen Code aufs handy und bittet uns das dann via App umzustellen, sodass wir die Codes selbst aufs Handy bekommen

**2025-11-03 14:55:12** - Julia:
> ich kann das gerade nicht machen, wegen meinem Update aber wenns bei dir klappt, wäre ja schon mal super

**2025-11-03 14:56:13** - Mert Koc:
> ok

**2025-11-03 14:56:25** - Mert Koc:
> ich schau mal, wie ich das umstellen kann. sodass ich das bekomme

**2025-11-03 14:56:42** - Julia:
> bitte log dich am besten an deinem handy in der gmail app auch mit <mailto:clients@boldcreators.club|clients@boldcreators.club> ein, dann kannst du's selbst verifizieren und brauchst nicht mich

**2025-11-03 14:56:46** - Julia:
> von flo

**2025-11-03 15:01:43** - Julia:
> bin übrigens hier:
<https://docs.google.com/presentation/d/1hCn3KbyAlmOzdpS0aAdcerl52U-l4EYm/edit?slide=id.g39fbe07ff9b_0_23#slide=id.g39fbe07ff9b_0_23>

**2025-11-03 15:02:03** - Mert Koc:
> soll ich flo wegen der Nummer anrufen?

**2025-11-03 15:02:10** - Mert Koc:
> Weil der antwortet nicht auf Slack ^^

**2025-11-03 15:02:17** - Julia:
> echt?

**2025-11-03 15:02:25** - Julia:
> der antwortet bestimmt gleich

**2025-11-03 15:02:40** - Mert Koc:
> ah jetzt

**2025-11-03 15:39:06** - Julia:
> ob Jana hilfsbereit ist?

**2025-11-03 15:39:08** - Julia:
> i daut it

**2025-11-03 15:39:10** - Julia:
> :smile:

**2025-11-03 15:39:55** - Mert Koc:
> Die hat so gar keinen Bock 

**2025-11-03 15:40:07** - Mert Koc:
> Glaub die ist sauer, dass wir den Kunden jetzt bekommen :sweat_smile:

**2025-11-03 15:41:01** - Julia:
> wahrscheinlich

**2025-11-03 15:42:53** - Julia:
> mit welchem account melden wir uns bei diesem lark an?

**2025-11-03 16:02:37** - Mert Koc:
> hab schon versucht aber geht iwie nicht

**2025-11-03 17:32:24** - Mert Koc:
> glaubst du ich kann Flo fragen, wann ich meinen Laptop endlich bekomme? :melting_face:

**2025-11-03 17:32:38** - Julia:
> auf jeden Fall

**2025-11-04 09:49:11** - Mert Koc:
> Hello :slightly_smiling_face:
Just fyi, bei dem Link den Jana geschickt hat einfach mit der eigenen BCC Mail anmelden, dann kommt man rein

**2025-11-04 09:54:31** - Julia:
> Hi!

**2025-11-04 09:54:36** - Julia:
> ja perfekt, danke :slightly_smiling_face:

**2025-11-04 10:37:00** - Mert Koc:
> Uhm ..

**2025-11-04 10:37:48** - Julia:
> lieb ich

**2025-11-04 10:38:07** - Mert Koc:
> Bringt ja nichts, wenn wir beitreten oder ?

**2025-11-04 10:40:57** - Julia:
> Ne

**2025-11-04 10:41:01** - Julia:
> ich weiß ja garnicht was wir da sagen sollen :smile:

**2025-11-04 10:41:54** - Julia:
> jana hat in ihrem kalender den termin auch abgesagt

**2025-11-04 10:41:55** - Mert Koc:
> Ja die Jana muss jetzt schon noch das erste Meeting dabei sein und uns vorstellen + denen sagen, dass sie uns zu den Meetings einladen sollen.

**2025-11-04 10:42:08** - Mert Koc:
> Ja habs gesehen :smiling_face_with_tear:

**2025-11-04 10:42:36** - Julia:
> genau

**2025-11-04 10:46:47** - Mert Koc:
> Weißt du wo die PPT ist, die uns Flo gestern gezeigt hat?

**2025-11-04 10:50:29** - Julia:
> yes

**2025-11-04 10:50:32** - Julia:
> in der mail moment

**2025-11-04 10:50:41** - Mert Koc:
> AAh stimmt die habe ich sogar

**2025-11-04 10:50:45** - Mert Koc:
> Hab die vergessen sorry

**2025-11-04 10:51:08** - Mert Koc:
> unangenehm ?

**2025-11-04 10:51:36** - Julia:
> okay perfekt! da hab ich die Sachen ja eh raus übernommen

**2025-11-04 10:51:56** - Julia:
> die hasst glaube ich Menschen

**2025-11-04 10:52:25** - Mert Koc:
> Ich finds ganz schlimm, gut das wir übernehmen :joy:

**2025-11-04 10:54:51** - Julia:
> ja wirklich

**2025-11-04 10:55:06** - Julia:
> wollte Julia gestern schon schreiben, aber dachte mir: ne die braucht ruhe :smile:

**2025-11-04 11:41:00** - Julia:
> Soo, schau gerne mal hier ab Seite 17 hab ich es neu erstellt:
<https://docs.google.com/presentation/d/1hCn3KbyAlmOzdpS0aAdcerl52U-l4EYm/edit?slide=id.g39fbe07ff9b_0_162#slide=id.g39fbe07ff9b_0_162>

Ich hab erste Ideen für verschiedene Content Reihen basierend auf den Content Säulen abgelegt. Daneben stehen teilweise noch Ideen für weitere Reihen. Hier hab ich entweder noch keine guten Videos gefunden oder ist noch nicht ausgereift. Magst du mal deine Ideen ergänzen/ erweitern?

**2025-11-04 11:41:29** - Julia:
> Slide 27 mit der "Roadmap" bin ich noch komplett lost

**2025-11-04 11:42:53** - Julia:
> Also dass man versteht was mit Content Reihen gemeint ist: hier zB kann man das ganze ja mit verschiedenen Rezeptideen verbinden, 3 verschiedene Belege und schon haben wir 3 Videos

**2025-11-04 11:45:09** - Mert Koc:
> Sehr nice :slightly_smiling_face:

**2025-11-04 11:45:53** - Mert Koc:
> Hab noch eine Idee für die Bold Creators Club Community Engine, die Flo auch einführen will bei den beiden Marken, die kann ich auch irgendwie ergänzen noch

**2025-11-04 11:48:47** - Julia:
> bitte alles eintragen!

**2025-11-04 11:49:13** - Julia:
> falls du für die offenen Ideen noch beispiele findest (wenn du sie auch gut findest) auch voll gerne. du bist der tiktok profi haha

**2025-11-04 11:49:35** - Julia:
> zB wicked oder Wohnzimmer Upgrade hatte ich vom Call gestern ja nur notiert

**2025-11-04 11:51:17** - Mert Koc:
> Yes die mache ich noch mit rein :slightly_smiling_face:
Glaubst du, dass wir auch die Ideen, die sie ursprünglich gut fanden mit einplanen sollten? Also die Gaming-Night und Movie/Art-Night

**2025-11-04 11:53:47** - Julia:
> Von den laser studios?

**2025-11-04 11:53:56** - Julia:
> hab ich oben jetzt mal dringelassen

**2025-11-04 12:32:31** - Mert Koc:
> Muss irgendwie das aussehen der Folien noch angleichen

**2025-11-04 13:48:21** - Julia:
> sieht doch gut aus :slightly_smiling_face:

**2025-11-04 13:48:30** - Mert Koc:
> Finde ich auch!

**2025-11-04 13:50:56** - Julia:
> ich fülle mal noch die "roadmap" etwas aus und schicke es dann flo

**2025-11-04 13:54:41** - Mert Koc:
> Perfekt :slightly_smiling_face:

**2025-11-04 13:54:54** - Mert Koc:
> Ich mache gleich Pause und Spaziergang bei dem schönen Wetter ^^

**2025-11-04 13:56:03** - Mert Koc:
> Ich kann dann noch eine Vorlage für einen Produktionsplan aus was altem machen.
Dann können wir nach Mittwoch gleich durchstarten. Wobei ich bezweifle, dass am Mittwoch große Entscheidungen getroffen werden :sweat_smile:

**2025-11-04 13:59:16** - Julia:
> klaro, mach das

**2025-11-04 13:59:21** - Julia:
> ja gerne. wo haben wir da was?

**2025-11-04 13:59:26** - Julia:
> haha same

**2025-11-04 14:00:50** - Mert Koc:
> <https://docs.google.com/spreadsheets/d/1lbssEzjk71XeHIx7SO3CypnERyot-rAyfSqQoRndDjQ/edit?gid=171262065#gid=171262065|20250828_IAA_Produktionsplan - Google Sheets>
Hier der von der IAA mit Posting Schedule etc. unten in den Reitern

**2025-11-04 14:01:08** - Mert Koc:
> Aber ich glaube, dass das für Mittwoch noch viel zu detailiert ist

**2025-11-04 14:13:13** - Julia:
> ahja also wirklich ein Call Sheet

**2025-11-04 14:13:15** - Julia:
> ja denke ich auch

**2025-11-04 14:13:28** - Julia:
> aber cool, wenn wir sowas ja schon mal als Vorlage haben :slightly_smiling_face:

**2025-11-04 16:08:10** - Mert Koc:
> sonst haben wir für heute eigentlich nichts mehr oder ?

**2025-11-04 16:25:29** - Julia:
> nee

**2025-11-04 16:25:34** - Julia:
> hab leider auch noch kein feedback

**2025-11-05 08:44:00** - Julia:
> Guten Morgen, Mert mich hats total erwischt gestern Abend, ich liege mit Fieber im Bett. Ich spreche wahrscheinlich gleich noch mit Flo bezüglich der Präsi aber, dass du es schon mal weißt

**2025-11-05 09:12:43** - Mert Koc:
> Oh Gott :cold_sweat:
Gute Besserung!! :hearts:

**2025-11-05 09:58:16** - Mert Koc:
> Hast du den Flo erreichen können?

**2025-11-05 11:00:48** - Julia:
> dankee

**2025-11-05 11:00:50** - Julia:
> ja

**2025-11-05 11:00:57** - Julia:
> er meinte die ideen stellen wir nächstes mal vor

**2025-11-05 11:01:44** - Mert Koc:
> oh achso, weiß Jana schon davon?

**2025-11-05 11:01:51** - Mert Koc:
> Wir dachten, dass wir es später schon vorstellen

**2025-11-05 11:02:08** - Julia:
> ich hab kA. ich weiß auch garnicht, ob Flo in das meeting kommt?

**2025-11-05 11:02:24** - Mert Koc:
> Ich glaube nicht tbh.

**2025-11-05 11:02:34** - Mert Koc:
> Glaub auch nicht, dass er es Jana gesagt hat

**2025-11-05 11:03:50** - Julia:
> ich schreib dem kunden auf teams

**2025-11-05 11:03:53** - Julia:
> wollte flo so

**2025-11-05 11:07:36** - Mert Koc:
> oh gott :joy:

**2025-11-05 11:07:40** - Mert Koc:
> du meinst Lark oder ?

**2025-11-05 11:16:10** - Julia:
> Nee

**2025-11-05 11:16:16** - Julia:
> wir haben ja einen teams channel

**2025-11-05 11:16:19** - Julia:
> bist du da drin?

**2025-11-05 11:20:46** - Julia:
> Hallo zusammen!
Leider kann ich bei unserem Vorstellungstermin heute nicht dabei sein, da mich die Grippe überrascht hat. Ich wollte auf diesem Weg trotzdem schon mal „Hallo“ sagen und freue mich sehr auf die zukünftige Zusammenarbeit!
 Wir haben bereits an einigen neuen Content Ideen gearbeitet und würden euch diese gerne asap genauer vorstellen, sobald ich wieder fit bin. Mein Kollege Mert wird euch heute aber schon zu den zeitnahen Themen etwas vorstellen. LG Juli

**2025-11-05 11:20:49** - Julia:
> hab ich abgeschickt

**2025-11-05 11:26:21** - Mert Koc:
> ne bin ich nicht oder? Ich schau mal

**2025-11-05 11:27:26** - Mert Koc:
> oh lol ich sehe das zum ersten mal, dachte mir schon, warum wir auf Lark so inaktiv sind :joy:

**2025-11-06 09:54:43** - Julia:
> Hallo :slightly_smiling_face: was gäbe es denn heute zutun?

**2025-11-06 09:57:21** - Mert Koc:
> Hallo ^^
Gar nicht mal so viel... wir warten ja noch auf die Freigabe der Ideen
Ich werde heute schon mal anfangen aufzuschreiben, was wir für die einzelnen Ideen brauchen

**2025-11-06 10:03:25** - Julia:
> Oke

**2025-11-06 10:03:48** - Julia:
> Sag bescheid, wenn ich unterstützen kann. Ich bin auf jeden Fall fitter als gestern :face_exhaling:

**2025-11-06 10:05:30** - Mert Koc:
> Ne alles gut, ich schaffe das heute auch noch alleine, ruh dich gerne aus

**2025-11-06 10:06:06** - Mert Koc:
> Vorallem bin ich morgen und Montag ja nicht da, da wäre es sinnvoller, wenn du morgen wieder fit bist :slightly_smiling_face:

**2025-11-06 10:12:21** - Julia:
> das stimmt

**2025-11-06 10:12:37** - Julia:
> aber gib mir gerne später mal ein update oder können sonst auch gerne sprechen :slightly_smiling_face:

**2025-11-06 13:58:07** - Mert Koc:
> Wann hast du Zeit fürs Update? ^^

**2025-11-06 15:16:34** - Julia:
> halloo, bin da

**2025-11-06 15:17:29** - Mert Koc:
> Perfekt, einen Moment

**2025-11-06 15:18:24** - Mert Koc:
> <https://meet.google.com/ecx-vdtt-sae?authuser=0|Meet - Update Juli>

**2025-11-07 09:17:23** - Julia:
> ob sie den Termin um 2.30 morgens rausgelöscht hat?

**2025-11-11 11:38:11** - Julia:
> no more fucks given

**2025-11-11 11:38:14** - Julia:
> :smile:

**2025-11-11 11:39:39** - Mert Koc:
> Komplett Fair haha

**2025-11-11 11:40:37** - Mert Koc:
> Sie beantwortet halt auch einfach nicht die Fragen.
Selbst wenn sie keine Info zu einer Frage hat, soll sie das doch wenigstens sagen und am besten dann halt einfach noch an wen wir uns für die Info wenden sollen....

**2025-11-11 11:54:02** - Mert Koc:
> Boa die ist so bodenlos

**2025-11-11 12:08:28** - Julia:
> ja genau :smile:

**2025-11-11 12:08:31** - Julia:
> die spinnt einfach

**2025-11-12 09:45:19** - Mert Koc:
> LOL der redaktionsplan der Wochen hinterher ist 

**2025-11-12 09:58:50** - Julia:
> jaa

**2025-11-12 09:59:02** - Julia:
> so ein quatsch

**2025-11-12 09:59:19** - Julia:
> hab das mit julia auch schon besprochen, die sachen die da geplant sind, stimmen ja alle nicht

**2025-11-12 10:19:36** - Julia:
> wie dieser kunde happy sein kann, versteh ich nicht

**2025-11-12 10:20:01** - Mert Koc:
> same

**2025-11-12 10:44:28** - Julia:
> hast du notes gemacht? dann schreibe ich sie schnell zusammen

**2025-11-12 10:45:21** - Mert Koc:
> nicht viel aber wir können auch kurz in einen Call, wenn du Zeit hast. Hätte paar wenige Anmerkungen zu den Sachen die sie gesagt hat :sweat_smile:

**2025-11-12 10:45:29** - Julia:
> ja klar

**2025-11-12 10:46:00** - Julia:
> <https://meet.google.com/obw-tidc-pwo?authuser=0>

**2025-11-13 17:50:07** - Mert Koc:
> Bist du noch busy oder hast du kurz Zeit ?

**2025-11-13 17:50:16** - Julia:
> beides :slightly_smiling_face:

**2025-11-13 17:50:22** - Julia:
> aber tell me

**2025-11-13 17:51:26** - Mert Koc:
> Hier hat ein Kunde kommentiert unten: <https://docs.google.com/spreadsheets/d/1e2fICmoCbS-5VlfmVpYYNa7osFn0hISLpWp6Vx3e09E/edit?gid=1056095428#gid=1056095428|(BCC) HISENSE -Editorial Plan - Google Sheets>
Hattest du das bei deinen Asana Kommentaren schon beachtet oder fliegen die alle separat raus ?

**2025-11-13 17:52:53** - Julia:
> KW37?

**2025-11-13 17:53:24** - Julia:
> ich hab das bei der Asana Übersicht alles mit einbezogen

**2025-11-13 17:53:38** - Julia:
> oder hab ich das übersehen? wenn video ist es denn genau?

**2025-11-13 18:10:54** - Mert Koc:
> Bei KW 37 das Feld B 26

**2025-11-13 18:11:48** - Mert Koc:
> Kann das aber auch morgen machen :slightly_smiling_face:

**2025-11-14 07:48:12** - Julia:
> GuMo! Ja das Video hab ich garnichtmehr mit rein genommen, weil das ja jetzt eh das nächste wäre und somit dann rausfällt

**2025-11-14 09:27:09** - Mert Koc:
> Aber glaubst du, dass sie alle mit einem M auf der Seite meint ?

**2025-11-14 09:31:11** - Julia:
> ne, das hatte ich gestern gefragt

**2025-11-14 09:31:23** - Julia:
> ist nur das Video. M sollen wir ignorieren, das war von Marvin selbst

**2025-11-14 09:32:56** - Mert Koc:
> ok, got it, dann nehme ich das nicht mit rein aber die anderen mit M schon :slightly_smiling_face:

**2025-11-14 09:33:44** - Julia:
> genau!

**2025-11-14 09:33:45** - Julia:
> dankeee

**2025-11-14 09:33:59** - Julia:
> also MINI Pitch wurde abgesagt.. so bitter

**2025-11-14 09:50:02** - Mert Koc:
> Oh :/ 
Wissen wir warum? 

**2025-11-14 10:36:58** - Julia:
> ja total krass, sie haben vorhin erst abgesagt, weil sie haben doch kein Budget mehr für eine neue Agentur

**2025-11-14 10:37:17** - Julia:
> 1 Std. vorher. Da ist ja schon soo viel Arbeit reingeflossen, hab die Präsi usw gesehen. Puh echt bitter

**2025-11-14 10:39:36** - Mert Koc:
> Boa wie krass :cold_sweat:
eine Stunde vorher ist auch sehr bitter!

Ich hab jetzt einfach mal angefangen, die Videos genauer zu unterteilen und die Ideen.
Außerdem würde ich gerne jedem "Format" einfach ein Arbeits-Kürzel geben, die heißen jetzt z.B. H-K1 und H-K2 für "Hisense-Kühlschrank-1" usw.
Wäre dann gut, wenn wir immer und überall die gleichen Namen erwähnen, damit wir immer wissen, welches Video gemeint ist :slightly_smiling_face:

**2025-11-14 10:56:48** - Julia:
> ach super, schau ich mir an.
ja das ist sehr smart :slightly_smiling_face:

**2025-11-14 10:57:27** - Julia:
> bist du noch in der alten präsi?

**2025-11-14 11:03:59** - Mert Koc:
> Achso gibt es eine neue ?

**2025-11-14 11:04:15** - Mert Koc:
> Bin hier in dieser: <https://docs.google.com/presentation/d/1hCn3KbyAlmOzdpS0aAdcerl52U-l4EYm/edit?slide=id.g3a0dffd5b5a_0_80#slide=id.g3a0dffd5b5a_0_80>

**2025-11-14 11:05:46** - Mert Koc:
> BTW ich habe den Redaktionsplan immernoch nicht fertig, weil ich ja nicht weiß, welches Video die Jana jetzt gleich hochlädt :confused: Aber ich frag sie mal, dann muss ich nicht mehr warten

**2025-11-14 11:06:19** - Julia:
> nee, ich wollte eine neue erstellen aber habs noch nicht geschafft. deshalb frag ich :slightly_smiling_face:

**2025-11-14 11:07:02** - Julia:
> jaa hab ich mir gedacht, ey so nervig.
Sag einfach bescheid, dann würde ichs Laureen weiterleiten mit der Bitte um Freigabe etc.
dankeee dir :slightly_smiling_face:

**2025-11-14 11:07:29** - Julia:
> ich warte gerade noch auf Flo's Rückmeldung wegen Bitpanda – das ist echt ein Brocken

**2025-11-14 11:08:02** - Julia:
> Aber andere Frage, hast du Lust, dass wir uns nächste Woche mal im Büro treffen? :slightly_smiling_face: Dienstag, Mittwoch wenn wir eh Termine haben?

**2025-11-14 11:11:32** - Mert Koc:
> Wir können auch einfach in der alten weiter arbeiten, wenn ich ehrlich bin. Alle Folien die wir nicht mehr brauchen können wir einfach ausblenden, dann haben wir nicht ständig neue Präsis :slightly_smiling_face:

**2025-11-14 11:12:27** - Julia:
> wegen mir gerne. Julia wollte eine neue – glaube wegen Jana :smile:

**2025-11-14 11:13:15** - Mert Koc:
> Ja voll gerne :grin:
Lieber Mittwoch, Dienstag kann ich nicht, weil ich da Mittag wieder Therapie habe

**2025-11-14 11:13:31** - Mert Koc:
> Aah oke .. aber egal oder?

**2025-11-14 11:14:15** - Julia:
> ja, lassen wir es so

**2025-11-14 12:11:44** - Julia:
> jaa perfekt, so machen wir es

**2025-11-14 13:56:01** - Mert Koc:
> Was hältst du davon, wenn wir die Kühlschrank Drink Videos zu "Rating Viral Drinks" machen?
Mein Gedankengang, warum ich denke, dass wir sowas machen sollten:
Wir brauchen für die Drinks Rezepte. Entweder wir denken uns selbst welche aus (sehr schwer meiner Meinung nach) oder wir holen uns Rezepte aus TikTok.
Wenn wir Rezepte aus TikTok benutzen sollte wir "angeben", von wo wir die Inspo haben. Da dachte ich mir dann, dass wir einfach Virale Rezepte aus TikTok nachmachen und raten können, dadurch sparen wir uns, dass wir uns selbst Rezepte ausdenken müssen. Außerdem wissen wir dann bereits, dass die Drinks gut ankommen, da es ja Virale Videos sind/waren.

**2025-11-14 14:21:26** - Julia:
> jaa find ich super

**2025-11-14 14:21:34** - Julia:
> Hätte mir jetzt auch keine selbst ausgedacht tbh :smile:

**2025-11-14 14:21:49** - Julia:
> also sehr gerne so wie du sagst

**2025-11-14 15:00:35** - Julia:
> wie geil sieht eigentlich dieser frosty winter drink aus haha

**2025-11-14 15:01:11** - Mert Koc:
> Ja gä ^^

**2025-11-14 15:01:41** - Mert Koc:
> Ich habe jetzt nur "schöne" Drinks ausgewählt ... glaub zwar nicht, dass die so geil sind aber für die Views ist es denke ich besser

**2025-11-14 15:01:58** - Julia:
> ja perfekt

**2025-11-14 15:02:07** - Julia:
> wir sagen dann einfach: Mhmmm so lecker :joy:

**2025-11-14 15:02:27** - Julia:
> Dann schnapp ich mir den Rest der Ideen zum ausformulieren?

**2025-11-14 15:24:20** - Mert Koc:
> Ja genau ^^

**2025-11-14 15:24:23** - Mert Koc:
> All righty

**2025-11-14 15:25:24** - Mert Koc:
> Du kannst mir gerne sagen, welche Idee du ausformulierst, dann mache ich eine andere weiter.
Bin gleich mit den Drinks fertig. :slightly_smiling_face:

**2025-11-14 16:48:01** - Julia:
> würde mir kühlschrank, waschmaschine und mikrowelle anschauen :slightly_smiling_face:

**2025-11-14 16:48:35** - Julia:
> bzw. würde ich sonst mit gorenje starten, weil es ja sein kann, dass der Dreh schneller geplant werden muss

**2025-11-14 16:52:33** - Mert Koc:
> ja macht Sinn!
Sollen wir es dann so aufteilen? Du Gorenje und ich Hisense und wenn jemand fertig ist, einfach beim anderen helfen :slightly_smiling_face:

**2025-11-14 16:55:02** - Julia:
> ja auch gerne

**2025-11-14 16:59:07** - Mert Koc:
> All right, ich mache dann am Montag weiter ^^
Bin jetzt mall off

**2025-11-14 16:59:19** - Mert Koc:
> Schönes Wochenende!! :grin:

**2025-11-14 17:10:51** - Julia:
> ich hab heute keine gehirnzellen mehr :smile: same here

**2025-11-14 17:10:56** - Julia:
> Dir auch Mert! :slightly_smiling_face:

**2025-11-18 11:00:14** - Julia:
> so eine blöde B

**2025-11-18 11:00:14** - Julia:
> haha

**2025-11-18 11:26:08** - Mert Koc:
> wen meinst du? ^^

**2025-11-18 11:52:58** - Julia:
> Jana haha

**2025-11-18 12:28:16** - Julia:
> Also morgen Büro? :slightly_smiling_face: Dann plane ich das ein

**2025-11-18 13:27:22** - Mert Koc:
> Die nervt mich so hart das glaubst du nicht :joy:
Bin manchmal richtig paranoid, dass sie Sachen sabotiert lol 

**2025-11-18 13:27:56** - Mert Koc:
> Ich kann morgen ins Büro, ich weiß nur nicht, ob ich sollte, weil ich noch am kränkeln bin 

**2025-11-18 15:15:54** - Julia:
> ich glaubs auch :smile:

**2025-11-18 15:15:59** - Julia:
> Asooo ja okay verstehe

**2025-11-18 15:16:07** - Julia:
> Können ja sonst morgen spontan gucken

**2025-11-18 15:29:02** - Mert Koc:
> Ok 

**2025-11-18 17:04:52** - Julia:
> was machen wir wegen dem 700 views video? packen wir das noch in das Ad Set mit Budget?

**2025-11-18 17:05:08** - Julia:
> würde Jana gerne eine saftige antwort runtertippen :smile:

**2025-11-18 17:06:12** - Mert Koc:
> Welches hat 700 views? :open_mouth:

**2025-11-18 17:06:30** - Mert Koc:
> Das von Freitag ist auch mit drinnen, also wir haben jetzt 2 Videos bei den Ads mit dabei

**2025-11-18 17:07:00** - Julia:
> ach sorry, jetzt check ich erst, dass du garnicht in dem chat drin bist

**2025-11-18 17:07:12** - Julia:
> 

**2025-11-18 17:09:13** - Mert Koc:
> Also die letzten beiden Videos werden jetzt geboostet mit der neuen Strategie, die wir entschieden haben

**2025-11-18 17:09:15** - Mert Koc:
> <https://www.tiktok.com/@hisense_germany>

**2025-11-18 17:09:34** - Julia:
> ja perfekt

**2025-11-18 17:09:40** - Mert Koc:
> Sie soll mal entspannen, wir übernehmen gerade erst lol

**2025-11-18 17:09:44** - Julia:
> dann kann ich ihr das sagen

**2025-11-18 17:09:45** - Julia:
> ja ist so

**2025-11-18 17:09:50** - Mert Koc:
> Das war das erste Video jemals WTF

**2025-11-18 17:10:30** - Mert Koc:
> Außerdem:

**2025-11-18 17:10:35** - Julia:
> JA

**2025-11-18 17:10:41** - Julia:
> Das hab ich vorhin auch gesehen hahahaha

**2025-11-18 17:10:43** - Mert Koc:
> Sie hat mir gestern in unserem 3er chatt nicht mehr geantwortet

**2025-11-18 17:11:00** - Julia:
> aber schön in den chat mit Flo reingehauen die Nachricht. Blöde Kuh ey

**2025-11-18 17:11:05** - Julia:
> naja, habs ihr jetzt geschriebenj

**2025-11-18 17:11:08** - Julia:
> Danke Mert!

**2025-11-18 17:11:31** - Mert Koc:
> Nicht ihr Ernst ??

**2025-11-18 17:11:36** - Mert Koc:
> Will die Stress ?

**2025-11-18 17:12:32** - Mert Koc:
> Du kannst ja noch dazu schreiben, dass ich nicht in dem Channel bin und sie nicht auf meine Nachricht gestern geantwortet hat

**2025-11-18 17:13:06** - Julia:
> ja will sie

**2025-11-18 17:13:14** - Julia:
> hab ich kurz überlegt, aber wir sind nicht so

**2025-11-18 17:13:26** - Mert Koc:
> Ich schon :joy:

**2025-11-18 17:13:32** - Mert Koc:
> :facepunch::skin-tone-3:

**2025-11-18 17:13:35** - Mert Koc:
> hahaha

**2025-11-18 17:15:17** - Julia:
> :joy:

**2025-11-19 11:21:42** - Julia:
> <https://docs.google.com/presentation/d/1rbYB7aLiZwdcgXMezmgL1kWXM0APEyGw64nXlBrXhpY/edit?usp=sharing>

**2025-11-19 11:51:55** - Mert Koc:
> Kurze Frage, wie hast du dir den Aufbau der Präsi vorgestellt? Soll ich einfach unter so ein UGC Feld jemanden drunter Schreiben, Channel verlinken und vielleicht noch ein Beispiel Video von der Person?

**2025-11-19 11:59:49** - Julia:
> ja genau. hab jetzt eine Slide fertig. die Übersicht können wir auch rausnehmen, wenn wir es umständlich finden, war noch wip

**2025-11-19 12:14:14** - Mert Koc:
> Ich habe dir mal eine Bearbeitungsanfrage gesendet, kanns bisher nur ansehen

**2025-11-19 12:16:25** - Julia:
> done!

**2025-11-19 12:16:41** - Julia:
> also die die ich rausgesucht hab, sind doch alle eher nicht gut

**2025-11-19 12:16:49** - Julia:
> find ich wirklich nicht leicht, wer da passen könnte

**2025-11-19 12:17:03** - Mert Koc:
> Ja ganz schwierig :confused:

**2025-11-19 12:17:22** - Mert Koc:
> Es gibt so viele aber irgendwie auch nicht :sweat_smile:

**2025-11-19 12:17:53** - Mert Koc:
> Ich folge sehr vielen Renovations Channels, die irgendwann vielleicht solche Geräte brauchen aber idk wie relevant das ist :confused:

**2025-11-19 12:23:19** - Julia:
> ja aber das wäre auf jeden fall eine coole options. nimm gerne die 2 coolsten mit rein!

**2025-11-19 12:24:04** - Mert Koc:
> Die eine, die ich gerade hinzugefügt habe ist mir total unsympathisch alleine dadurch, dass sie in Dubai lebt lol

**2025-11-19 12:24:47** - Julia:
> ach echt?

**2025-11-19 12:25:01** - Julia:
> puh ja, bin ich leider auch kein Fan von :smile:

**2025-11-19 12:49:17** - Mert Koc:
> Bei Home wäre vielleicht Westwing eine Option? Ist der eine Berater von BCC nicht von Westwing?

**2025-11-19 12:49:26** - Mert Koc:
> Aber wahrscheinlich eher für Hisense, da das Premium ist

**2025-11-19 12:49:53** - Julia:
> jaa total! Trag gerne ein welche du gut findest, müssen ja nicht 4 sein, gerne mehr

**2025-11-19 12:50:00** - Julia:
> smart you

**2025-11-19 12:50:04** - Mert Koc:
> Eine Verwandte von mir arbeitet bei Westwing im Resourcing glaube ich :thinking_face:

**2025-11-19 13:41:10** - Julia:
> das wäre ja perfekt

**2025-11-21 11:58:51** - Julia:
> und die hier ist noch wip, oder?

**2025-11-21 12:04:25** - Mert Koc:
> Ja aber das müssen wir nicht mitschicken. Das ist dann eher für uns, wie der Ablauf am Drehtag sein kann/ was ins Video kommt

**2025-11-21 12:37:33** - Mert Koc:
> Die Präsi überfordert mich leicht :joy:

**2025-11-21 13:05:40** - Julia:
> Ja sie ist so voll gepackt :smile: aber das ist eigentlich gut für den Kunden zu sehen

**2025-11-21 13:08:05** - Julia:
> aber du bist ready oder?

**2025-11-21 13:11:16** - Mert Koc:
> Ja an sich schon

**2025-11-21 13:12:07** - Mert Koc:
> nur sind unsere Folien nicht exakt gleich, weil bei dir noch oben die Tags zu den Kategorien sind + ich wusste nicht in welche "Bold", "Innovative" etc. Kategorien ich die einteilen soll, das habe ich noch nicht gemacht

**2025-11-21 13:12:32** - Julia:
> ah okay. soll ich das kurz machen?

**2025-11-21 13:12:41** - Mert Koc:
> Ja gerne

**2025-11-21 13:12:49** - Mert Koc:
> Ich hau die eine WIP Folie raus

**2025-11-21 13:12:54** - Julia:
> okay :slightly_smiling_face:

**2025-11-24 11:09:01** - Mert Koc:
> <https://drive.google.com/drive/folders/1noPlwzpgnNOny1iaadz0D6PhlFztkp7J?usp=drive_link>

**2025-11-24 14:13:22** - Mert Koc:
> Diese Modulare Küche ist immer einsatzbereit oder ?

**2025-11-24 14:19:27** - Julia:
> ja

**2025-11-24 14:19:37** - Julia:
> mehr oder weniger, steht irgendwo im münchner umland

**2025-11-24 14:20:13** - Mert Koc:
> All right :slightly_smiling_face:

**2025-11-24 17:40:21** - Mert Koc:
> Soll ich noch auf die Rückenwind Mail antworten, damit wir morgen im Besten Fall schon eine Antwort haben und dann im Meeting mit Ray einen Konkreten Plan schon aufzeigen können?

**2025-11-24 17:42:56** - Mert Koc:
> Das Mietstudio München West liegt hier btw: Benzstraße 12, 82178 Puchheim

**2025-11-25 08:51:49** - Julia:
> Hi Mert, sorry ich habs nichtmehr gelesen!

**2025-11-25 08:52:24** - Julia:
> ich antworte jetzt direkt, danke dir! ist ja jetzt eh die frage, ob wir Ray dann vorstellen sollen, dass wir das TH Shooting erstmal sein lassen

**2025-11-25 09:00:03** - Mert Koc:
> Guten Morgen :sun_with_face: 
Ja stimmt aber wahrscheinlich sagen wir’s ihm oder ? 

**2025-11-25 09:26:45** - Julia:
> Ja genau

**2025-11-25 09:26:53** - Julia:
> ich hab die 2 Models jetzt noch in unsere Präsi geladen

**2025-11-25 09:41:13** - Mert Koc:
> Flo macht auch künstlich stress gerade :disappointed:

**2025-11-25 09:41:29** - Julia:
> ja voll

**2025-11-25 09:41:32** - Julia:
> manchmal macht er das

**2025-11-25 09:42:20** - Mert Koc:
> Btw ich glaube ich kann heute entweder nicht am Hisense JF teilnehmen oder ich muss früher raus, weil ich vergessen habe, dass ich um halb 12 los muss zur Therapie. :confused:

**2025-11-25 09:44:09** - Julia:
> Ahh okay. Meinst du, du könntest dann kurz dazu kommen?

**2025-11-25 09:44:40** - Mert Koc:
> Ja :+1::skin-tone-2: 

**2025-11-25 09:48:20** - Julia:
> super danke :)

**2025-11-25 10:15:54** - Julia:
> ich würde vorschlagen, wir starten dann kurz mit Gorenje, dann kannst du danach direkt raus

**2025-11-25 10:16:04** - Julia:
> denke da gibts mehr Klärungsbedarf :smile:

**2025-11-25 10:19:07** - Mert Koc:
> Kurze Frage, welche Präsi zeigen wir und bis wohin?
Würde vorschlagen, dass wir vom Content her die Gorenje Präsi erst am Donnerstag vorstellen, quasi dass wir heute Content Hisense machen und Donnerstag Content Gorenje.
Aber das mit den Modulen +  Studio West können wir natürlich sagen.
Weil die Gorenje Präsi muss dann ja im Anschluss mit deren Infos und hoffentlich Freigabe, dass wir Pizzaofen und Staubsauger nur machen dürfen erst mal neu befüllt werden?

**2025-11-25 10:19:25** - Mert Koc:
> Btw bei Gorenje gibts keine Mikro soweit ich das sehe :thinking_face:

**2025-11-25 10:28:47** - Julia:
> Genau, Content würde ich heute garnichts vorstellen. Hisense haben sie ja schon bekommen --&gt; hier will ich nur Feedback, ob alles passt.
Also hätte quasi "beide Präsis" mit den jeweiligen neuen Inhalte gezeigt:
Hisense:
• Wohnungen
• Models
Gorenje:
• Modulare Küche + Mietstudio

**2025-11-25 10:30:20** - Julia:
> ich finde die Gorenje Präsi nichtmehr. hast du den Link?

**2025-11-25 10:30:46** - Mert Koc:
> <https://docs.google.com/presentation/d/1eSkSG1EQcXviU789pGD52LymGF7q0Uc2/edit?slide=id.g3a9320bb28d_1_1#slide=id.g3a9320bb28d_1_1>

**2025-11-25 10:31:19** - Mert Koc:
> Ok dann mache ich also einfach in der Gorenje Präsi auf Folie 7 ein paar weitere Infos zum Studio rein

**2025-11-25 10:32:44** - Julia:
> genau!

**2025-11-25 10:32:45** - Julia:
> dankeee

**2025-11-25 10:35:36** - Julia:
> Sollen wir noch kurz wegen den Videos von den Designern sprechen?

**2025-11-25 10:37:41** - Mert Koc:
> Ja können wir gerne machen :slightly_smiling_face:

**2025-11-25 10:38:03** - Mert Koc:
> sollen wir ins Weekly von gerstern ?

**2025-11-25 10:38:24** - Julia:
> yes, bin in 3 min da!

**2025-11-25 10:38:36** - Mert Koc:
> perfekt :slightly_smiling_face:

**2025-11-25 10:43:13** - Julia:
> bin daaa

**2025-11-25 10:46:34** - Mert Koc:
> • <https://f.io/rt9HPWaz>
• <https://f.io/0NPgECAo>
• <https://f.io/viqNTeFD>
• <https://f.io/JV7wjByd>

**2025-11-25 10:49:34** - Mert Koc:
> Alt (vor Anpassungen): <https://app.frame.io/reviews/95ead0a2-ad8e-49d6-ac31-18d5e767c33a/70c900e2-d532-4b2f-a3d3-3fd7b7436bfb>
Neu: <https://next.frame.io/share/c34fd7a8-cc4e-4211-82a7-564ea0ad93d1/view/0da6d6e3-5bc1-40fa-a564-47c6b7ff2d90>

**2025-11-25 10:52:24** - Julia:
> :white_check_mark:

**2025-11-25 11:01:37** - Julia:
> bin im warteraum. du?

**2025-11-25 11:04:06** - Mert Koc:
> ich auch

**2025-11-25 11:05:57** - Mert Koc:
> Glaube du musst das Meeting starten, weil Julia nicht da ist

**2025-11-25 11:06:57** - Julia:
> ja ich kann nicht, komme ja auch nicht rein

**2025-11-25 11:07:07** - Mert Koc:
> Teams lieben wir

**2025-11-25 11:07:09** - Julia:
> aber smart :smile:

**2025-11-25 15:52:23** - Julia:
> Du bezüglich der Zeitungsartikel usw. --&gt; kannst du gerne marie auch drauf ansetzen oder es aufteilen? dass sie schon mal für Gorenje startet zb?

**2025-11-25 15:52:41** - Mert Koc:
> Gute Idee

**2025-11-25 15:54:30** - Julia:
> briefst du sie dann? :slightly_smiling_face:

**2025-11-25 15:55:24** - Mert Koc:
> Ja :+1::skin-tone-3:

**2025-11-25 15:55:32** - Julia:
> dankeschön :heart_hands:

**2025-11-25 15:56:02** - Julia:
> ich fahr übrigens morgen ins büro, falls du auch Lust hättest :slightly_smiling_face:

**2025-11-25 16:33:03** - Mert Koc:
> Bitte :slightly_smiling_face:

**2025-11-25 16:35:00** - Mert Koc:
> Habe gerade das Problem, dass unser Team wieder mal nicht hilfreich ist bei dem Verifizierungsprozess ...
habe gefragt, welche Unterlagen wir bereits eingereicht haben und die haben keine Ahnung

**2025-11-25 16:35:29** - Julia:
> das ist wirklich krass

**2025-11-25 16:35:39** - Julia:
> ja Marvin wollte mir vorhin auch nicht wirklich helfen

**2025-11-25 16:36:07** - Mert Koc:
> ja ganz schlimm

**2025-11-25 16:36:18** - Mert Koc:
> "Ich würd wirklich einfach sammeln und schicken. Das ist wirklich mehr Glückspiel als alles andere" Sorry aber damit kann. ich nicht arbeiten

**2025-11-25 16:41:42** - Julia:
> und. will. ich. nicht.

**2025-11-25 17:03:49** - Mert Koc:
> Marie ist gebrieft

**2025-11-25 17:08:18** - Julia:
> juhuuu danke

**2025-11-25 17:15:30** - Mert Koc:
> oh lord die neue Mail

**2025-11-25 17:15:39** - Mert Koc:
> als ob wir nicht genug Probleme haben

**2025-11-25 17:16:03** - Julia:
> hör auf

**2025-11-25 17:16:11** - Julia:
> ich glaube das nicht!!!!

**2025-11-25 17:16:33** - Julia:
> ich schreibe es gleich Flo in unsere gruppe

**2025-11-25 17:18:46** - Julia:
> also wirklich

**2025-11-25 17:18:49** - Julia:
> das ist SO krass

**2025-11-25 17:23:05** - Mert Koc:
> Bin auch so sprachlos

**2025-11-25 17:23:28** - Mert Koc:
> Ich hoffe, dass wir uns nicht damit befassen müssen :sleepy:

**2025-11-25 17:30:00** - Mert Koc:
> oh Gott jetzt hab ich was verkackt ... habe den Call mit Julia ganz vergessen, weil ich Marie gebrieft habe :sleepy:
schlimmer Tag heute für mich

**2025-11-25 17:33:53** - Julia:
> oh neeeein

**2025-11-25 17:33:54** - Julia:
> ach mist

**2025-11-25 17:34:04** - Julia:
> also du hast ihr auch nicht geantwortet?

**2025-11-25 17:34:20** - Julia:
> schlimmer Tag? wegen Therapie meinst du oder Arbeit? oder beides? :sleepy:

**2025-11-25 17:35:41** - Mert Koc:
> Ich will ihr gerade antworten aber das geht anscheinend nur in dieser Gruppe :melting_face::melting_face:
Kann ihr privat nicht schreiben

**2025-11-25 17:36:18** - Mert Koc:
> Therapie &amp; Arbeit :sleepy:

**2025-11-25 17:36:40** - Julia:
> scheiße. hat sie sonst eine Mail?

**2025-11-25 17:36:51** - Julia:
> oder ist das da nicht drin? bin grad nicht im tool

**2025-11-25 17:37:41** - Mert Koc:
> Ne aber GMail hat ihre Mail irgendwie gefunden... auch gut

**2025-11-25 17:38:32** - Julia:
> sehr gut

**2025-11-25 17:42:35** - Mert Koc:
> So Mail ist auch raus

**2025-11-25 17:47:25** - Mert Koc:
> Ich frag gleich Hisense UK, wie sie ihren Haken bekommen haben :joy:

**2025-11-25 17:48:31** - Julia:
> mach :smile: das wäre mal ein smarter shortcut

**2025-11-25 17:57:42** - Mert Koc:
> Ich hatte gerade doch noch spontan Meeting mit Julia :slightly_smiling_face:

**2025-11-26 10:28:32** - Mert Koc:
> Haben wir die Quick Intro trotzdem?

**2025-11-26 10:29:16** - Julia:
> ja oder?

**2025-11-26 10:31:16** - Mert Koc:
> Ja

**2025-11-26 12:03:47** - Mert Koc:
> Wo hattest du das gefunden, dass Tiktok keinen Support anbietet ? 

**2025-11-26 12:04:25** - Julia:
> 

**2025-11-26 12:05:20** - Mert Koc:
> Nice danke 

**2025-11-26 13:59:51** - Julia:
> Mert, warst dus? :smiling_imp:

**2025-11-26 14:00:24** - Mert Koc:
> Ne :sweat_smile:
Hab nicht mal Zugriff auf den allgemeinen Drive, nur Hisense und Porsche 

**2025-11-26 14:01:03** - Julia:
> haha

**2025-11-27 09:59:03** - Mert Koc:
> Hattest du den Kunden irgendwie eine Übersicht von David und Marina geschickt?
Würde die beiden dann auch in die Übersicht mit rein, damit wir alles zusammen haben

**2025-11-27 10:00:19** - Julia:
> Hello!

**2025-11-27 10:00:25** - Julia:
> Ne ich habs nur präsentiert

**2025-11-27 10:00:30** - Julia:
> Liegt aber in der Hisense Präsi ab

**2025-11-27 10:02:53** - Mert Koc:
> Ah perfekt danke :blush:

**2025-11-27 11:37:01** - Julia:
> Hast du Laureen diese Checkliste geschickt? Glaube das wäre mega

**2025-11-28 09:45:32** - Julia:
> Mert

**2025-11-28 09:45:37** - Julia:
> ich bin kurz vorm ausrasten :smile:

**2025-11-28 09:47:55** - Julia:
> 

**2025-11-28 09:54:52** - Mert Koc:
> Habe professionellen mittelfinger Text geschrieben

**2025-11-28 09:57:13** - Julia:
> Danke :heart_hands:

**2025-12-03 18:04:22** - Julia:
> Also ich muss Freitag ins Büro, Flo will irgendwas besprechen. Evtl könnten wir dann die Geräte mitnehmen oder zur Location bringen :)

**2025-12-03 18:08:28** - Mert Koc:
> Yes das können wir machen

**2025-12-04 10:16:59** - Julia:
> Flo Weiss Bescheid :)

**2025-12-04 10:17:13** - Mert Koc:
> Also gehen wir morgen Vormittag? 

**2025-12-04 10:38:23** - Julia:
> genau 

**2025-12-05 16:26:20** - Julia:
> so ich bestelle jetzt mal die offenen sachen

**2025-12-05 16:27:41** - Julia:
> lieferung am gleichen tag?? wahnsinn

**2025-12-05 16:38:16** - Julia:
> Ich brauch eine Pause :face_with_peeking_eye: Aber ich setz mich entweder später oder Sonntag Abend an die UGC Skripte – wenn du einen Kopf dafür hast, wäre es mega, wenn du am Montag morgen dann nochmal drauf schaust und wir es Julia im Meeting zeigen und schicken können :slightly_smiling_face:

**2025-12-05 16:39:52** - Mert Koc:
> Nice danke :pray::skin-tone-3: 

**2025-12-05 16:40:21** - Mert Koc:
> Same ich brauche auch ne Pause aber glaube das Meeting geht noch bis 17:30 wieder :pensive::melting_face:

**2025-12-05 16:40:29** - Mert Koc:
> Yes kann am Montag drüber schauen 

**2025-12-05 16:40:41** - Julia:
> Ach komm, so lange?? Was gibts denn da so viel zu besprechen, puhh.

**2025-12-05 16:40:50** - Julia:
> Ja easy. Will nur keinen Schmarn erzählen

**2025-12-05 16:41:23** - Julia:
> danke Mert und ich hoffe du hast trotz allem ein schönes Wochenende! Und nächste Woche lenken wir dich schon mal gut ab :blush:

**2025-12-05 16:45:53** - Mert Koc:
> Es gab anscheinend bisher keinen Prozess zwischen München und Lima :sweat_smile:

**2025-12-05 16:46:04** - Mert Koc:
> Dank :blush: dir auch! 

**2025-12-08 10:55:23** - Mert Koc:
> 

**2025-12-08 10:57:52** - Mert Koc:
> <https://maps.app.goo.gl/NKj97JwGWraG2Yd86>

**2025-12-12 09:47:32** - Julia:
> Mert, ganz anderes Thema aber :smile:

**2025-12-12 09:48:14** - Julia:
> hast du evtl noch den Namen eures Putzmanns für mich?

**2025-12-12 09:52:18** - Mert Koc:
> Ja klar ^^

**2025-12-12 09:52:20** - Mert Koc:
> Moment

**2025-12-12 09:52:45** - Mert Koc:
> Soll ich 50% Rabatt Code mit dir teilen?

**2025-12-12 09:52:56** - Mert Koc:
> Für Freundesempfehlung

**2025-12-12 09:53:04** - Julia:
> Uh nice, gerne

**2025-12-12 09:54:30** - Mert Koc:
> Nochmal ein anderes Thema ^^
hast du die Briefings, die wir an die Creator geschickt haben da? Also die Präsis ?

**2025-12-12 09:54:51** - Mert Koc:
> Will die auch ans Designer Team schicken, damit sie wissen was kommt

**2025-12-12 10:06:53** - Julia:
> Also da hatte Julia nur die Präsentationen geschickt

**2025-12-12 10:07:04** - Julia:
> Hab nix anderes erstellt

**2025-12-12 10:07:08** - Julia:
> oder was meinst du genau? :slightly_smiling_face:

**2025-12-12 10:16:43** - Mert Koc:
> Ja genau das meinte ich, dann nehm ich einfach die Präsi

**2025-12-12 10:25:35** - Julia:
> jaa das war nur das 

**2025-12-15 11:26:20** - Mert Koc:
> Hast du Premiere Pro?

**2025-12-15 11:26:29** - Mert Koc:
> Zum testen mit dem Stream

**2025-12-15 11:28:44** - Julia:
> yees

**2025-12-15 11:29:01** - Julia:
> muss dazu aber zuerst den generellen File Stream downloaden, moment

**2025-12-15 11:31:01** - Julia:
> lädt und lädt

**2025-12-15 11:31:07** - Julia:
> hat das bei dir schon geklappt?

**2025-12-15 11:35:48** - Mert Koc:
> Ja :+1::skin-tone-3:

**2025-12-15 11:38:02** - Mert Koc:
> Sag Bescheid, wenns geklappt hat oder du Hilfe brauchst :slightly_smiling_face:

**2025-12-15 11:38:07** - Julia:
> 

**2025-12-15 11:38:10** - Julia:
> :no_mouth:

**2025-12-15 11:43:40** - Mert Koc:
> Achso ja da musste ich ein Workaround machen

**2025-12-15 11:43:59** - Julia:
> Okay wie?

**2025-12-15 11:45:22** - Mert Koc:
> <https://drive.google.com/drive/folders/1Tygyp-KCUMWiL9bP9_yC9P_h7dBXq1Jh?usp=drive_link>

Hier dann auf "Add Shortcut":

**2025-12-15 11:45:46** - Julia:
> ah okay

**2025-12-15 11:45:50** - Mert Koc:
> Dann auf "All Location" und "My Drive" --&gt; Add

**2025-12-15 11:46:11** - Mert Koc:
> Dann kannst du im Finder zu My Drive gehen und da sollte es dann sein :slightly_smiling_face:

**2025-12-15 11:46:19** - Julia:
> okaay nice! ach danke

**2025-12-15 11:46:53** - Julia:
> Ist es bei dir unter geteilte Ablage oder Meine Ablage?

**2025-12-15 11:47:52** - Mert Koc:
> Meine Ablage

**2025-12-15 11:48:08** - Mert Koc:
> 

**2025-12-15 11:48:38** - Julia:
> okay

**2025-12-15 11:48:45** - Julia:
> ja bei mir lädt nix rein

**2025-12-15 11:48:52** - Julia:
> ich starte den PC mal neu...

**2025-12-15 11:48:55** - Julia:
> klassiker

**2025-12-15 11:49:03** - Mert Koc:
> Oke :c

**2025-12-15 12:03:27** - Julia:
> also so einzelne andere Dateien von mir sind alle drin aber der Hisense Ordner nicht

**2025-12-15 12:03:34** - Julia:
> vllt muss es jetzt nochmal laden

**2025-12-15 12:04:18** - Mert Koc:
> Ok

**2025-12-15 12:04:31** - Mert Koc:
> Wir können es uns auch sonst kurz zusammen anschauen

**2025-12-15 12:05:46** - Julia:
> kurz in huddle?

**2025-12-15 12:05:50** - Mert Koc:
> Ja

**2025-12-15 12:06:07** - Julia:
> dankee

**2025-12-15 16:07:49** - Julia:
> ich starte jetzt mit POV Gaming night :face_with_peeking_eye:

**2025-12-15 16:08:47** - Mert Koc:
> Yes :grin:

**2025-12-15 17:54:22** - Mert Koc:
> Boa ich glaube wir schaffen das nicht heute zu briefen oder?

**2025-12-15 17:57:51** - Julia:
> Ne

**2025-12-15 17:58:31** - Julia:
> morgen mittags könnte ich mit den Cuts fertig sein

**2025-12-15 18:00:27** - Julia:
> du bist noch beim Hisense Upload oder?

**2025-12-15 18:05:22** - Mert Koc:
> 

**2025-12-15 18:08:04** - Julia:
> okay super

**2025-12-15 18:08:11** - Julia:
> ach man, das ist doch so ätzend

**2025-12-15 18:09:06** - Mert Koc:
> Dieses Authentifizierungszeug ist so nervig, kann nimmer

**2025-12-15 18:09:21** - Mert Koc:
> Und es steht einfach nie ein Grund da, warum etwas nicht klappt

**2025-12-15 18:09:29** - Mert Koc:
> Das ist sooo nervig oh man

**2025-12-15 18:20:01** - Julia:
> 

**2025-12-15 18:25:24** - Mert Koc:
> Ja finde ich gut 

**2025-12-15 18:25:43** - Mert Koc:
> Glaub das kostet uns sonst zu viel Zeit 

**2025-12-15 18:28:22** - Julia:
> okay. Dann machen wir das so 

**2025-12-16 14:40:15** - Julia:
> also dieser Mittags Termin morgen mit Flo passt mir garnicht rein :joy:

**2025-12-16 14:42:52** - Mert Koc:
> Versteh ich so sehr :joy:

**2025-12-16 14:43:10** - Mert Koc:
> Du musst mir dann bitte berichten, um was es so geht.. :sweat_smile:

**2025-12-16 14:45:34** - Julia:
> Ja voll 

**2025-12-16 14:59:03** - Mert Koc:
> 

**2025-12-16 15:05:03** - Julia:
> okee. Aber du meinst gorenje oder? da bin ich eh noch nicht 

**2025-12-16 15:12:42** - Mert Koc:
> Achso ja meinte Gorenje

**2025-12-16 15:12:50** - Mert Koc:
> bin so durch wieder :joy:

**2025-12-16 15:15:23** - Julia:
> same :smile: es ist so viel

**2025-12-16 16:34:03** - Mert Koc:
> Bruh :sleepy:
Ich hatte die Nachricht wieder gelöscht aber er will das unbedingt machen irgendwie

**2025-12-16 16:34:45** - Julia:
> Ahh wie meinst du?

**2025-12-16 16:37:26** - Julia:
> 

**2025-12-16 16:41:23** - Julia:
> wenn du gute Tipps hast für Übergänge/ Effekte, ich hasse diese Premiere effekte haha

**2025-12-16 16:42:05** - Mert Koc:
> Ich hab ihm nochmal gesagt, dass er es nicht machen soll

**2025-12-16 16:42:51** - Mert Koc:
> Da würde ich dann den jeweiligen Ton vom original YouTube Video drunter legen, während sie spricht

**2025-12-16 16:43:22** - Mert Koc:
> Ich glaub wir brauchen keine Übergänge. TikToks haben eigentlich keine

**2025-12-16 16:43:43** - Mert Koc:
> Ok, dann mache ich das Kinds Video

**2025-12-16 16:44:25** - Julia:
> also einfach schwarzblende fertig? Ja schon, ich hab nur das Gefühl bei manchen Texten wären es gut aber lets see

**2025-12-16 16:44:43** - Mert Koc:
> Ne einfach ein cut

**2025-12-16 16:45:19** - Julia:
> ahja okay. weil hier haben wir teilweise reingequatscht. Hast du die Links oder Videos noch? Falls ja, würdest du sie in die Ordner mit reinlegen? Dann mach ich es auch so

**2025-12-16 16:45:25** - Julia:
> ja meine ich

**2025-12-16 16:52:07** - Julia:
> wir müssen uns auch bei der Lichtbearbeitung abstimmen

**2025-12-16 17:03:44** - Julia:
> 

**2025-12-16 17:06:39** - Mert Koc:
> yes mache ich

**2025-12-16 17:06:50** - Mert Koc:
> ich leg sie in Asana ab und Tag dich

**2025-12-16 17:09:06** - Mert Koc:
> Ja ich glaub, dass wir uns einfach abstimmen müssen noch
Aber so Raw edits kriegen wir hin und die Details können wir noch ausfeilen

**2025-12-16 17:12:35** - Julia:
> dankeeee

**2025-12-16 17:12:41** - Julia:
> ich hasse eeeeees, alles hängt :smile:

**2025-12-16 17:12:46** - Mert Koc:
> Narnia: <https://www.youtube.com/watch?v=usEkWtuNn-w&amp;list=WL>
One Piece: <https://www.youtube.com/watch?v=yfeCCnOPqrA&amp;list=WL&amp;index=2>
Avatar: <https://www.youtube.com/watch?v=oZoZ1ivUdjU&amp;list=WL&amp;index=3>
Herr der Ringe: <https://www.youtube.com/watch?v=_nZdmwHrcnw&amp;list=WL&amp;index=4>
Harry Potter: <https://www.youtube.com/watch?v=VejnzIIFDXU&amp;list=WL&amp;index=5>
Dinner For One: <https://youtu.be/W5XhiJP4qoQ?si=8lzq2t_INhz9gy1B>
Weihnachtsmann und co: <https://youtu.be/WF0YznVowGA?si=luHnfrQGnWWmXpur>
Barbie: <https://youtu.be/1rpdGm8Ei7Q?si=ibzb8YRa6N8j8_It>
Santa: <https://youtu.be/76lSNJwPe54?si=WjF2xElMNsO1VVmr>
Grinch: <https://youtu.be/O-N8gLi20I4?si=WAcQqPj-HcEBAUyK>
Kevin: <https://youtu.be/lRDI61HMQ4E?si=kU_1P1Nz7cQRJRw1>

**2025-12-16 17:13:25** - Julia:
> danke, du bist ein Schatz!

**2025-12-16 17:18:17** - Mert Koc:
> Bitte :slightly_smiling_face:

**2025-12-16 17:19:52** - Julia:
> ah mist, du hast einen youtube premium account oder? ich kann die videos nicht downloaden (legal)

**2025-12-16 17:20:11** - Julia:
> Und ganz ehrlich: ich überlege ob ich zu Capcut wechsel :smile:

**2025-12-16 17:28:23** - Mert Koc:
> Achsoo stimmt ja :sleepy:
ich würde einfach ein downloader nutzen ehrlich gesagt...
Aber ich bin so durch, das mache ich heute nicht mehr

**2025-12-16 17:28:56** - Mert Koc:
> Versteh ich voll, nur dann können wir die Dateien nicht mehr teilen :disappointed_relieved: glaub wir müssen da durch mit Premiere

**2025-12-16 17:29:08** - Julia:
> okay

**2025-12-16 17:29:12** - Julia:
> ja hast recht

**2025-12-16 17:29:24** - Julia:
> alles gut, wir hören uns morgen :slightly_smiling_face:

**2025-12-16 17:34:51** - Mert Koc:
> Bis morgen :blush:

**2025-12-17 10:23:57** - Julia:
> also

**2025-12-17 10:25:06** - Julia:
> mit meinen 8GB Speicher komme ich grad nicht weit :smile: ich muss jetzt alle video snippets downloaden sonst geht garnichts mehr. vom drive klappt das nicht, premiere stürzt dauernd ab. heißt im nachgang (wenn du die dateien nochmal öffnets) müsstest du die clips erneut verknüpfen..

**2025-12-17 10:25:14** - Julia:
> sooo nervig aber sonst kann ich garnicht schneiden

**2025-12-17 10:35:23** - Mert Koc:
> du kannst theoretisch auch im drive rechtsklick auf das Video machen und "offline verfügbar machen" klicken, dann ist es quasi dort gedownloaded

**2025-12-17 10:35:32** - Julia:
> ja genau, das meinte ich

**2025-12-17 10:35:44** - Mert Koc:
> ich kann auch sonst weiter machen, wenn es bei dir zu sehr hakt

**2025-12-17 10:36:06** - Julia:
> du alles gut, wir müssens ja aufteilen :new_moon_with_face: aber danke :slightly_smiling_face:

**2025-12-17 10:41:17** - Mert Koc:
> ne ich mein weil das ja die Weihnachtssachen sind.. der Rest eilt ja nicht so wie das. Du hast jetzt quasi das stressige übernommen :sweat_smile:

**2025-12-17 10:54:08** - Julia:
> Aso ja aber Gorenje Xmas ist ja auch dringend

**2025-12-17 10:54:35** - Julia:
> also das mein ich mit aufteilen. Würden ja eh nicht alles alleine schaffen oder? 

**2025-12-17 11:00:47** - Julia:
> Spinnt es bei dir denn auch so? 

**2025-12-17 11:01:07** - Julia:
> Also bei mir haben die Videos halt auch alle unterschiedliche fps

**2025-12-17 11:02:53** - Mert Koc:
> oh hab das gorenje Plätzchen Video ganz vergessen... das muss ich ja machen :joy:
Ich spinne gleich, wenn Laureen nicht aufhört mich immer wieder random zu ghosten :joy:

**2025-12-17 11:05:34** - Julia:
> ja gorenje sind sogar mehr Videos :sweat_smile:

**2025-12-17 11:05:41** - Julia:
> oh man ey 

**2025-12-17 11:05:59** - Julia:
> es läuft wirklich garnicht 

**2025-12-17 11:06:12** - Julia:
> Als wenn's hart auf hart kommt schneide ich gleich mit CapCut :joy:

**2025-12-17 11:06:42** - Mert Koc:
> echt? Da haben wir doch eigentlich nur das Plätzchen Video für Weihnachten oder?

**2025-12-17 11:08:21** - Julia:
> 

**2025-12-17 11:08:55** - Julia:
> Nee. Das müssen wir ja fertig machen bis Freitag, sonst haben wir bis 7.1. keine Freigabe zum Posten 

**2025-12-17 11:10:26** - Mert Koc:
> mmh oke verstehe
Wir hätten das wahrscheinlich genau anders rum machen sollen, weil ich kann mir bspw. unter Beauty Shots Produkte nichts vorstellen und dazu haben wir ja eigentlich auch nichts gefilmt oder?

**2025-12-17 11:11:22** - Julia:
> wenig aber vllt ist was beim broll dabei. Hab allerdings auch noch keine gorenje Dateien 

**2025-12-17 11:58:36** - Julia:
> also ich schneide jetzt mit rush, sonst klappt es leider nicht. könnten wir uns in zukunft auch überlegen. brauchen für tiktok ja kein krasses premiere

**2025-12-17 12:02:34** - Mert Koc:
> hab noch nie damit geschnitten, wie ist das so?

**2025-12-17 12:05:20** - Julia:
> 

**2025-12-17 12:05:49** - Julia:
> eigentlich sehr gleich aber vom handling und aufbau viel simpler und basic

**2025-12-17 12:17:58** - Mert Koc:
> stimmt das sieht eigentlich super ähnlich aus ^^

**2025-12-17 12:18:59** - Mert Koc:
> bin jetzt mit Plätzchen videos sortieren und cutten durch und edite jetzt
da haben wir viel zu viel gedreht tbh. beim nächsten mal reichen wirklich 2 angles und fertig is das ding :sweat_smile:

**2025-12-17 12:22:50** - Julia:
> haha ja

**2025-12-17 12:23:02** - Julia:
> ich koche/ backe und filme nichtmehr gleichzeitig :smile:

**2025-12-17 12:23:16** - Julia:
> packst du typo mit drauf? oder machen wir das am ende?

**2025-12-17 12:27:46** - Mert Koc:
> am ende oder?

**2025-12-17 12:28:02** - Mert Koc:
> hat Rush ein stabilisierungseffekt?

**2025-12-17 12:28:03** - Julia:
> ja gern

**2025-12-17 12:29:10** - Julia:
> ne leider nicht

**2025-12-17 12:42:42** - Mert Koc:
> bin jetzt doch von Rush weg, weil ich ein paar tools aus premiere brauche

**2025-12-17 12:43:04** - Julia:
> ja klar

**2025-12-17 12:43:19** - Julia:
> bei den videos mit stativ gehts easy mit rush

**2025-12-17 12:48:29** - Julia:
> hast du noch den Polarexpress für mich? :slightly_smiling_face:

**2025-12-17 12:51:10** - Mert Koc:
> yes hier: <https://youtu.be/f0oyHtZiJJs?si=QiM4BTxdFczg7d5n>

**2025-12-17 13:00:52** - Julia:
> ich finds so verrückt, dass teilweise die farben so unterschiedlich sind, obwohl es genau das gleiche setting ist

**2025-12-17 13:10:06** - Mert Koc:
> Ja das ist eh wild :sweat_smile:

**2025-12-17 14:58:04** - Julia:
> Mert

**2025-12-17 14:59:02** - Julia:
> ich würde dir mal kurz in whatsapp eins der movie must watch schicken. magst du mal bitte auch am handy wegen der farben schauen?

**2025-12-17 15:00:14** - Julia:
> obs auffällt, wie unterschiedlich die teilweise sind, wenn man es normal anschaut

**2025-12-17 15:42:35** - Mert Koc:
> ja mach ich

**2025-12-17 15:42:42** - Mert Koc:
> sorry, war gerade so krass im Tunnel

**2025-12-17 15:43:16** - Julia:
> no stress

**2025-12-17 15:43:19** - Julia:
> same also :smile:

**2025-12-17 16:14:24** - Mert Koc:
> Wie hieß nochmal das <https://drive.google.com/drive/folders/1WcXhhAJn2o4WEdBMz-Wu5duKTpKcMyyi|warmup Video> auf YouTube? :sweat_smile:
Ich habe die Watch History nicht aktiviert, deswegen ist da nichts

**2025-12-17 16:17:03** - Julia:
> interactive warmup heißen die. moment ich kanns dir raussuchen

**2025-12-17 16:17:19** - Julia:
> <https://www.youtube.com/watch?v=oRr5hxr_bRA>

**2025-12-17 16:24:22** - Mert Koc:
> sollen wir das einfach als Ton benutzen? Ja oder?

**2025-12-17 16:29:21** - Julia:
> jaa würde ich auch

**2025-12-18 10:02:45** - Julia:
> Huhu :slightly_smiling_face:

**2025-12-18 10:02:53** - Julia:
> bist du morgen eigentlich auch im büro dann?

**2025-12-18 10:03:20** - Mert Koc:
> Ja :slightly_smiling_face:

**2025-12-18 10:03:24** - Julia:
> juhuuu

**2025-12-18 11:10:22** - Julia:
> liebs, dass sie nie auf mails antworten

**2025-12-18 11:11:04** - Mert Koc:
> :sweat_smile::joy:

**2025-12-18 11:19:08** - Mert Koc:
> <https://www.barrierefreiheit-dienstekonsolidierung.bund.de/Webs/PB/DE/umsetzungshilfen/Barrierefreie_Videos/Barrierefreie_Videos-node.html|Barrierefreie Videos>

**2025-12-18 17:57:39** - Mert Koc:
> Bis morgen um Büro :blush:

**2025-12-18 18:10:40** - Julia:
> Bis morgen :slightly_smiling_face: ich komme erst vormittags, wenn ich heute noch bissl weiter arbeite

**2025-12-18 19:11:14** - Julia:
> Also ich bräuchte morgen deine Hilfe, einige Videos müsstest du mir stabilisieren. dann kann ich weiter schneiden mit rush

**2025-12-18 22:32:12** - Mert Koc:
> Jap kann ich machen :) 

**2025-12-18 22:32:37** - Mert Koc:
> Ich glaub ich komme auch erst mittags 

**2025-12-19 10:24:29** - Mert Koc:
> Wann fährst du ins Office ? :) 

**2025-12-19 10:27:53** - Julia:
> Ich denke ich kann so in 30 min los. Und brauch dann 45-60 min! 

**2025-12-19 10:27:59** - Julia:
> Du? 

**2025-12-19 10:33:40** - Mert Koc:
> Oke ich kann auch um 12 da sein 

**2025-12-19 11:09:21** - Julia:
> bin unterwegs :) 

**2025-12-19 12:45:56** - Julia:
> <https://drive.google.com/file/d/1PvCnftxQisfxjtzfjXe0PWj8whVHy0te/view?usp=drive_link>

**2025-12-19 12:48:50** - Mert Koc:
> <https://f.io/i4sONNHa>

**2025-12-19 12:49:33** - Mert Koc:
> <https://f.io/1e43hOL8>

**2025-12-19 14:56:53** - Mert Koc:
> <https://drive.google.com/open?id=1hFJCjxPkDyLl-V_cbKxRG-t1ImjhC91E&amp;usp=drive_fs>

**2025-12-22 09:09:01** - Julia:
> Hellooo :slightly_smiling_face: wie gehts dir?

**2025-12-22 09:10:35** - Mert Koc:
> Hii gut und dir? 

**2025-12-22 09:10:42** - Mert Koc:
> Bin nur Sau müde :joy:

**2025-12-22 09:11:14** - Mert Koc:
> Und ich glaube ich habe ne leichte Erkältung aber das beeinträchtigt mich nicht wirklich 

**2025-12-22 09:15:51** - Julia:
> Saaaame

**2025-12-22 09:15:54** - Julia:
> also beides hahaha

**2025-12-22 09:15:58** - Julia:
> es nervt

**2025-12-22 09:46:43** - Mert Koc:
> Wir skippen das JF oder ?

**2025-12-22 09:46:56** - Julia:
> ja oder?

**2025-12-22 09:48:56** - Mert Koc:
> Was sollen wir Ray hier antworten?

**2025-12-22 09:49:08** - Julia:
> ah stimmt

**2025-12-22 09:49:24** - Julia:
> Er meint da 2 unterschiedliche Fernseher, oder?

**2025-12-22 09:49:49** - Julia:
> würde antworten "nein, das wäre ein Thema für den Brand Store Dreh – wir hatten ja nur den MiniLED beim Dreh"

**2025-12-22 09:49:52** - Julia:
> :no_mouth:

**2025-12-22 09:57:47** - Julia:
> Soll ich?

**2025-12-22 09:58:09** - Mert Koc:
> Ich hab schon ^^

**2025-12-22 10:02:23** - Mert Koc:
> Ich muss das Editing von warm up und Pov jetzt selber übernehmen, weil wir schon 4 Feedback Runden hatten und ich nicht zufrieden bin mit dem Ergebnis :c

**2025-12-22 10:14:07** - Julia:
> ah okay, dankeee

**2025-12-22 10:14:10** - Julia:
> Oh no..

**2025-12-22 10:14:14** - Julia:
> Das ist echt krass

**2025-12-22 10:14:25** - Julia:
> Also ich weiß auch nicht, wieso Flo denkt, dass das mit AI dann funktioniert aber well

**2025-12-22 10:56:27** - Mert Koc:
> Das wird so schwer werden, es alles zu erklären :sleepy:

**2025-12-22 11:00:15** - Julia:
> ja voll

**2025-12-22 11:00:40** - Julia:
> wie sollen wir uns aufteilen? also ich muss heute auf jeden fall dann den "workshop" vorbereiten und mache ein PDF mit How-To

**2025-12-22 11:00:50** - Julia:
> Aber sollen Marie und ich wieder briefings schreiben?

**2025-12-22 11:09:59** - Mert Koc:
> Ich editiere gerade die Videos einfach weiter.
Aber an sich ja, wir sollten uns aufteilen und nochmal 2-3 Videos briefen heute.
Kannst du dir das kurz anschauen: <https://f.io/24eEBsAV>

**2025-12-22 11:10:16** - Julia:
> okay

**2025-12-22 11:10:29** - Julia:
> yes, hab ich schon. dann feedbacke ich? per comments oder wie feedbackst du?

**2025-12-22 11:11:56** - Mert Koc:
> Ja ich denke in frameio ist am besten

**2025-12-22 11:13:15** - Julia:
> 

**2025-12-22 11:19:55** - Mert Koc:
> sollen wir es komplett weg lassen?

**2025-12-22 11:20:30** - Julia:
> also ich finde den start und das ende mit cheers schon gut

**2025-12-22 11:27:32** - Mert Koc:
> Ja stimmt

**2025-12-22 11:47:27** - Mert Koc:
> Juli ich weiß gerade echt nicht, ob das Sinn macht das alles zu briefen :sleepy:
Bin so Lost tbh
Schau mal wie viel Feedback ich hier schon habe und da bin ich auf den meisten Text noch nicht einmal eingegangen: <https://next.frame.io/share/f6cae42b-d45e-41a2-9f67-511bda4cbb8c/view/428851da-1a37-4ed2-b191-103ac9a0acce>

**2025-12-22 11:48:11** - Julia:
> boah ey

**2025-12-22 11:48:18** - Julia:
> okay ja ich seh es genauso

**2025-12-22 11:50:49** - Julia:
> 

**2025-12-22 11:50:59** - Mert Koc:
> Ich schicke das Feedback jetzt für diese Videos noch ab, damit uns keiner nachsagen kann, dass wir es nicht versucht hätten aber nach der Mittagspause fange ich selber an die neuen Videos zu editieren und auch morgen, weil das macht meiner Meinung nach keinen Sinn sonst. :disappointed:

**2025-12-22 11:51:42** - Julia:
> ja mach das, ich schicke es auch ab

**2025-12-22 11:52:30** - Mert Koc:
> Wir müssen ihnen auch noch sagen, dass wir Schriftgröße 100 der jeweiligen Hausschrift nutzen und ohne Schatten oder Rand

**2025-12-22 11:52:50** - Julia:
> yes, da bin ich davon ausgegangen, dass sie das wissen aber

**2025-12-22 11:52:56** - Julia:
> wir lernen hier ja gerade viel dazu

**2025-12-22 11:52:57** - Julia:
> :smile:

**2025-12-22 11:54:15** - Mert Koc:
> Bin ehrlich gesagt auch bisschen entsetzt no joke.
Ich habe ihnen am Freitag auch extra nochmal geschrieben, dass sie es langsam machen sollen und nichts vergessen etc. aber die haben nach ner Stunde wieder so ein trash Video abgeliefert, wo ich mich dafür schämen würde. Sorry aber ist so

**2025-12-22 11:56:56** - Julia:
> ja versteh ich total

**2025-12-22 11:58:03** - Julia:
> finds wirklich auch krass

**2025-12-22 11:58:22** - Julia:
> Hast du immer mit untertitel gesagt? das haben wir bei hisense ja zB nicht gemacht

**2025-12-22 12:07:31** - Mert Koc:
> Nein eigentlich nicht. Sie haben mich falsch verstanden. Ich wollte eigentlich, dass sie sich selbst Untertitel zum Verständnis beim editieren machen.
Aber ich muss das nochmal genauer erläutern. :sleepy:

**2025-12-22 12:07:46** - Julia:
> ah okay

**2025-12-22 12:08:00** - Mert Koc:
> Nur bei so Zutaten Aufzählungen finde ich es als viewer auch ganz gut 

**2025-12-22 12:08:08** - Julia:
> also einfach unter uns: ich glaube wenn wir die Videos selbst schneiden, machen wir es besserr

**2025-12-22 12:08:25** - Mert Koc:
> Ja aufjedenfall 

**2025-12-22 12:33:09** - Julia:
> Mert ne andere Frage: bist du überhaupt um 18 uhr heute noch da?

**2025-12-22 12:33:13** - Julia:
> ich eigentlich nicht haha

**2025-12-22 12:34:03** - Mert Koc:
> Ne wieso? 

**2025-12-22 12:35:06** - Mert Koc:
> Ich schau gerade random Flüge für Marokko, Indonesien und Madagaskar. Meine arbeits Motivation hält sich in Grenzen gerade

**2025-12-22 12:35:31** - Julia:
> :smile:

**2025-12-22 12:35:35** - Julia:
> FÜHL ICH

**2025-12-22 12:35:41** - Julia:
> Ja weil Flo den Workshop heute nach 18 Uhr will

**2025-12-22 12:38:12** - Mert Koc:
> Ernsthaft :sweat_smile:
Ja also wenn es nicht anders geht bin ich natürlich dabei.

**2025-12-22 12:39:10** - Julia:
> 

**2025-12-22 12:39:15** - Julia:
> es nervt mich einfach so, dieses Hin und Her

**2025-12-22 12:41:41** - Mert Koc:
> Also ich bin da 

**2025-12-22 12:42:34** - Mert Koc:
> 

**2025-12-22 12:43:49** - Julia:
> ja :smile:

**2025-12-22 12:44:14** - Julia:
> der lässt da glaub ich nicht mit sich reden

**2025-12-22 12:49:08** - Julia:
> fyi: *Marie Gottschall*
[12:48 PM] bei ACE haben Basti und so sich immer das Premiere Projekt in den Drive Ordner ablegen lassen um dann so Kleinigkeiten selbst zu verbessern falls euch das was hilft

**2025-12-22 12:51:43** - Mert Koc:
> Ja das habe ich bei "pov: nur noch eine Folge" auch machen lassen.
Ich frage mich gerade, ab wann wir das machen sollen.

**2025-12-22 13:33:34** - Julia:
> 

**2025-12-22 13:47:42** - Mert Koc:
> Ok ja klingt nach einem Plan 

**2025-12-22 13:48:15** - Mert Koc:
> Aber du musst dann ausdrücklich denen sagen, dass sie das vorher sich anschauen sollen und Fragen aufschreiben sollen, sonst machen die das nicht :sweat_smile:

**2025-12-22 13:49:24** - Julia:
> ja auf jeden fall

**2025-12-22 14:35:38** - Mert Koc:
> Ich habe jetzt selbst das pov Video editiert.  Wie findest dus? <https://drive.google.com/open?id=1MhDCAfhJvv9alPdf3ZhEZ8l77qf_qMPM&amp;usp=drive_fs>

**2025-12-22 14:55:02** - Julia:
> da steht es liegt in deinem trash

**2025-12-22 14:55:07** - Julia:
> kanns nicht anschauen leider

**2025-12-22 14:55:15** - Mert Koc:
> Na toll ^^

**2025-12-22 14:55:18** - Mert Koc:
> Es liegt hier: <https://drive.google.com/drive/folders/1Tkdqc39HsfhOfXJey_ApQyhfCMOM8Cb8>

**2025-12-22 14:55:44** - Julia:
> haha okay moment

**2025-12-22 14:55:45** - Julia:
> danke

**2025-12-22 14:56:02** - Julia:
> cool!

**2025-12-22 14:56:14** - Julia:
> Ja ist besser, wenn man die Ausgagssituation nochmal sieht

**2025-12-22 15:48:02** - Julia:
> 

**2025-12-22 15:49:51** - Julia:
> Aso und noch eine Frage:

**2025-12-22 15:50:20** - Julia:
> 

**2025-12-22 16:00:23** - Mert Koc:
> Es ist dieser Ordner: <https://drive.google.com/open?id=1BGeSJ3cnGWSffpU8nWi1IJyuHG6EE9Ub&amp;usp=drive_fs>
Du hast geschrieben "insert video 1418 as written in the briefin – we must show the Honey :)" aber da ist bei mir kein Honey shot. Und es steht auch nicht im briefing. :sweat_smile:

**2025-12-22 16:00:50** - Mert Koc:
> Ich habe ihnen ALLEN jetzt nochmal die Font Regeln gebrieft

**2025-12-22 16:31:11** - Julia:
> Nee es ist das hier: 1415: 3-6s (cut between video no. 1408)

**2025-12-22 16:35:09** - Mert Koc:
> Ok, dann hat sie das wahrscheinlich einfach nur verwirrt. Dann hast du wahrscheinlich aus versehen die Falsche Zahl hier im <https://next.frame.io/share/ee9ae89b-63c3-4d25-be09-4d78e6d4925b/view/e3f27a64-16f1-4435-bd44-3d6fb6d7fb2b?c=6bdcd93d-76f2-4bbb-8653-125f6da403de|Kommentar >geschrieben?

**2025-12-23 16:22:27** - Julia:
> ob niemand außer Flo motiviert ist und zugesagt hat :joy:

**2025-12-23 16:22:31** - Julia:
> bin gespannt 

**2025-12-23 16:26:24** - Mert Koc:
> boa ich frage mich gerade, wie wir den Posting Plan einhalten sollen. Das klappt ja nicht, alleine schon wegen der Freigabeschleife :face_with_spiral_eyes:
Ich muss wahrscheinlich am Freitag arbeiten, damit ich Ray dann den nächsten Schwung rüber schicken kann. :sweat_smile:

**2025-12-23 16:27:35** - Julia:
> ne das geht ja nicht. Dann müssen wir ihnen zumindest sagen, dass fo Bearbeitung länger dauert und wir nach den Ferien Vollgas geben? 

**2025-12-23 16:29:40** - Mert Koc:
> Ja wahrscheinlich müssen wir es so machen :pensive:
Ich dachte mir schon, dass es länger dauert als Anfänglich geplant. Aber wir grooven uns ein mit Peru.

**2025-12-23 16:29:53** - Mert Koc:
> Ich bin übrigens gleich da 

**2025-12-23 16:33:26** - Mert Koc:
> Ah das Meeting ist erst um 17 Uhr oke

**2025-12-23 16:36:23** - Julia:
> Ja eigentlich hatten wir ja auch nicht so viel direkt für Januar geplant. Julia war etwas optimistisch haha

**2025-12-23 16:37:11** - Mert Koc:
> Wir machen einfach aus dem Warum up Video ein "so beginnt man seine vorsätze" Video oder so

**2025-12-23 16:37:36** - Mert Koc:
> Weil das ist so schlimm geschnitten noch nach 3 mal Feedback, das muss ich komplett neu selber machen.

**2025-12-23 16:39:51** - Julia:
>  Genau aber wlan geht grad nichtmehr. Bin auf der Suche nach Internet :weary:

**2025-12-23 16:40:03** - Julia:
> ach manno schade 

**2025-12-23 16:41:22** - Mert Koc:
> oh lord :sweat_smile:

**2025-12-23 16:58:28** - Mert Koc:
> Habe jetzt trotzdem den Schwung an neuen Videos an Ray geschickt. Evtl arbeitet er ja irgendwann heute oder nächste Woche. :slightly_smiling_face:

**2025-12-23 17:24:06** - Mert Koc:
> kommst du ins meet ?

**2026-01-07 14:34:56** - Mert Koc:
> Ich habe gerade mit Basti geschrieben, wegen der Feedbackschleifen und sie haben nach wie vor auch Probleme. Und ca. 3-4 Schleifen.
Er hat mir geschrieben: "Yes, tu mir doch bitte den gefallen und schreib raus (am besten mit Beispielen) was nicht gut funktioniert hat. Ich versuche gerade ein Feedback an Lima zusammen zu fassen um ein paar Probleme an zu sprechen, die wir in der Zukunft vermeiden sollten, weils unnötig Feedbackschleifen mit sich zieht."

**2026-01-07 14:36:23** - Mert Koc:
> Was mir aufgefallen ist:
• Ton:
    ◦ Immer auf Beat schneiden/ Musik beachten wenn möglich
    ◦ Lautstärkepegel sollte durchgehend gleich sein und nicht zu stark schwanken
• Bild:
    ◦ Richtiges Farbmanagement in Premiere auswählen für JEDES Video
    ◦ Keine Über oder Unterbelichtung
    ◦ Das Produkt muss immer gut aussehen
    ◦ Nur interessante/ spannende Inhalte im Video behalten --> immer daran denken, wir schneiden für Social Media --> kurze Aufmerksamkeitsspanne
    ◦ Falls im Video auf deutsch gesprochen wird: Auf eigene Sprache übersetzen, damit man die Videos logisch schneiden kann

**2026-01-07 14:41:46** - Mert Koc:
> Fällt dir noch etwas dazu ein?

**2026-01-07 15:03:30** - Julia:
> okay super! Stimme allem zu noch das zusätzlich:
• Lautstärke ja super, würde noch ergänzen, dass es teilweise zu laut ist
• Schrift/ Typo immer gleiche Größe und Positionierung, außer es passt nicht in die Gesamtkomposition bezüglich Leserlichkeit etc. --&gt; gerne eigene Vorschläge
• Bildanschnitte: wenn es schief ist/ nicht ins Bild soll (zB unschöner Hintergrund) gerne so croppen, dass es ästhetisch aussieht
Man kanns ja mal versuchen mit diesem Feedback

**2026-01-07 15:47:32** - Julia:
> da wolltest du den opener mit wackligem Seidentofu oder? Also das war so gewünscht?

**2026-01-07 15:47:42** - Julia:
> finds leider so unsexy hahahah

**2026-01-07 15:50:22** - Mert Koc:
> Nur beim :recycle: Video, weil wir da nur das VO haben und ich dachte, dass man das als Hook nutzen kann :sweat_smile:

**2026-01-07 16:02:39** - Julia:
> okay, verstanden

**2026-01-08 12:08:05** - Julia:
> hello :slightly_smiling_face:

**2026-01-08 12:08:23** - Julia:
> du hast als Typo Größe auch immer 100 genommen oder?

**2026-01-08 12:08:35** - Mert Koc:
> Hello ^^
Yes

**2026-01-08 12:09:52** - Julia:
> okay, dankee

**2026-01-08 16:39:53** - Mert Koc:
> Du hattest die Gorenje Videos im Griff oder? ^^
Weil ich kam heute 0 zu den Gorenje Videos, ich briefe jetzt die nächsten 4-5 Hisense Videos ein

**2026-01-08 17:00:42** - Julia:
> yees, den ginger shot feedbacke ich jetzt noch

**2026-01-08 17:00:45** - Julia:
> voll gut!

**2026-01-09 13:49:48** - Julia:
> 

**2026-01-09 13:51:05** - Julia:
> boomer frage aber den Supertext erst später einblenden.. macht man das? Hab ich bewusst noch nie gesehen :smile:
<https://next.frame.io/share/98ab9768-d27e-498f-9637-c510663e3e60/view/154f5f36-4faa-498b-a366-297a0c095a2b>

**2026-01-09 13:56:58** - Mert Koc:
> Also sowas wie Font größe müssen sie schon selber lösen ganz ehrlich. Aber das kann ich auch kommentieren.
Und ne, das muss natürlich am Anfang stehen, damit die Zuschauer nicht wegscrollen

**2026-01-09 14:02:13** - Mert Koc:
> 

**2026-01-09 14:11:53** - Mert Koc:
> 

**2026-01-09 14:37:38** - Julia:
> ja total. ich sag nur, damit du bescheid weißt. weil ichs ja nicht öffnen kann

**2026-01-09 14:38:11** - Julia:
> hää wie strange ist das. ich verstehs auch nicht

**2026-01-09 16:43:51** - Julia:
> würde mich jetzt auch mal ausloggen

**2026-01-09 16:44:00** - Julia:
> glaube da kommt heute eh kein fertiges Video mehr raus :sleepy:

**2026-01-09 16:46:27** - Mert Koc:
> Ja alles gut :slightly_smiling_face: Ich schau noch, wie ich das mit dem Farbproblem lösen kann

**2026-01-09 16:46:32** - Mert Koc:
> Schönen Feierabend!

**2026-01-09 16:48:49** - Julia:
> okay

**2026-01-09 16:49:14** - Julia:
> ja ich versteh nicht ganz, wie sie selbst nicht sehen können, dass es halt rotstichig ist. Also ja unsere Ansprüche sind höher aber die Basics..?

**2026-01-09 16:49:24** - Julia:
> dankee dir!

**2026-01-09 16:49:37** - Julia:
> Happy weekend und hoffentlich bis Montag! :smiling_face_with_3_hearts:

**2026-01-13 17:15:27** - Julia:
> helloo, wie gehts dir?

**2026-01-13 17:15:48** - Julia:
> Hab heute wirklich 0,0 für H/G geschafft. warte jetzt gerade auf Flo's Feedback :no_mouth:

**2026-01-13 17:16:31** - Julia:
> ich würde morgen früh mal dieses 3 Dips für Handball Video einbriefen, damit du Bescheid weißt

**2026-01-13 17:22:25** - Mert Koc:
> helloo
gerade sehr schlecht tatsächlich.. mein Bauch macht mir heute nur Probleme

**2026-01-13 17:22:40** - Mert Koc:
> kein Problem, ich glaube wir haben gerade keinen Zeitdruck bei HG

**2026-01-13 17:27:52** - Mert Koc:
> Schönen Feierabend schon mal :heart_hands::skin-tone-3:

**2026-01-13 17:36:03** - Julia:
> ach mist.. das tut mir leid zu hören. gute besserung :bouquet:

**2026-01-13 17:36:28** - Julia:
> dir auch und meld dich sonst krank, bringt ja nix

**2026-01-14 17:21:33** - Mert Koc:
> Wir brauchen kein Lichtequipment oder?

**2026-01-14 17:21:46** - Mert Koc:
> Um wie viel Uhr ist das Spiel nochmal? :sweat_smile:

**2026-01-14 17:21:56** - Julia:
> Nee glaub ich nicht

**2026-01-14 17:21:57** - Julia:
> 20.30

**2026-01-14 17:22:15** - Mert Koc:
> Oke passt :slightly_smiling_face:

**2026-01-14 17:29:22** - Mert Koc:
> Wir haben anscheinend sowas: <https://www.zhiyun-tech.com/de/product/detail/690>
Das könnten wir zur Sicherheit mal mitnehmen.

**2026-01-14 18:02:00** - Julia:
> ja können wir gerne. schauen wir uns morgen mal an, obs in den koffer passt?

**2026-01-14 18:14:36** - Mert Koc:
> Ich kann es erst übermorgen checken, weil Basti das morgen noch nutzt

**2026-01-15 10:46:42** - Mert Koc:
> Haben wir bei Gorenje das "Dips fürs Handball Game" am zweiten Tag gedreht?

**2026-01-15 10:47:26** - Julia:
> Jaa

**2026-01-15 10:47:32** - Mert Koc:
> Wir haben da kein Voiceover. Weißt du noch, was da unser Plan war?

**2026-01-15 10:47:41** - Julia:
> das hab ich mit Marina dann gedreht. sind 3 Dips

**2026-01-15 10:47:43** - Julia:
> Oh echt?

**2026-01-15 10:48:00** - Mert Koc:
> Ja ich suche mal nochmal aber ich konnte eben nichts finden

**2026-01-15 10:48:35** - Julia:
> okay, kann mich gerade auch nicht mehr erinnern. ich glaube ohne funktioniert es nicht, wäre schon viel text zum lesen. sonst machen wir einfach ein VO mit AI

**2026-01-15 10:51:27** - Mert Koc:
> Ok also eigentlich müssten wir es haben, weil das Skript existiert und ich alles abgedreht hatte... muss evtl. nochmal suchen auf der SSD dann

**2026-01-15 10:52:53** - Julia:
> ich glaube ich kann mich auch dran erinnern?

**2026-01-16 15:23:02** - Julia:
> Flo hat mir geschrieben, dass “Mert dann einen ssio Beat drüber legen soll” 
Ich soll quasi nichts mit der Bearbeitung zutun haben 

**2026-01-16 15:23:32** - Julia:
> Dann geben wir es Peru wegen Montag Dienstag. Ist das okay für dich? 

**2026-01-16 15:23:52** - Mert Koc:
> Ja das ist voll in Ordnung

**2026-01-16 15:23:58** - Mert Koc:
> wann muss es denn fertig sein?

**2026-01-16 15:26:22** - Julia:
> Dienstag wäre schon super

**2026-01-16 15:26:42** - Julia:
> Denke da wirds ein paar Feedback Runden mit Flo geben 

**2026-01-16 15:41:12** - Mert Koc:
> Wir haben kein VoiceOver für die 3 Dips :sleepy:

**2026-01-16 15:41:28** - Mert Koc:
> Wenn wir die Mikrophone haben, sollen wir das einfach am Montag aufnehmen?

**2026-01-16 15:41:35** - Mert Koc:
> Ist glaube ich schneller und besser als AI

**2026-01-16 15:51:48** - Julia:
> Mist

**2026-01-16 15:51:51** - Julia:
> Können wir

**2026-01-16 15:51:57** - Julia:
> Hoffe ich bin dann nichtmehr verschnupft

**2026-01-16 15:52:07** - Julia:
> sorry der uplpad dauert so lange, mein laptop ist wieder überfordert

**2026-01-16 16:08:18** - Julia:
> videos sind oben, ich schreib schon mal die Reihenfolge mit in die Task rein

**2026-01-16 16:08:23** - Julia:
> <https://app.asana.com/1/1199360402832734/project/1211206795229799/task/1212839388986275?focus=true>

**2026-01-16 16:27:51** - Mert Koc:
> Nice danke :pray::skin-tone-3: 

**2026-01-16 16:36:50** - Julia:
> okay ist alles ready. Können wir uns sonst ja am Montag dann im Flieger anschauen :smile:

**2026-01-20 15:55:06** - Julia:
> <https://www.google.com/search?q=Manuellsen+SIXT&amp;oq=Manuellsen+SIXT&amp;gs_lcrp=EgZjaHJvbWUyBggAEEUYOTIKCAEQABiABBiiBDIHCAIQABjvBTIHCAMQABjvBTIHCAQQABjvBdIBBzU1NGowajeoAgCwAgA&amp;sourceid=chrome&amp;ie=UTF-8#fpstate=ive&amp;vld=cid:cd655258,vid:ZhPRD0-08rU,st:0|https://www.google.com/search?q=Manuellsen+SIXT&amp;oq=Manuellsen+SIXT&amp;gs_lcrp=EgZjaHJvb[…]vBTIHCAQQABjvBdIBBzU1NGowajeoAgCwAgA&amp;sourceid=chrome&amp;ie=UTF-8>

**2026-01-20 17:44:30** - Julia:
> • video generell zu lange
• teil 1: musik muss uncool sein --&gt; muss klar werden, dass nur mit LIDL cool
• rewind sound effekt +  :rewind: Icon
• pixel kleiner/ enger setzen, quasi nur pikante stellen verdeckt

**2026-01-21 14:32:44** - Julia:
> So hier kommen die Sounds:

**2026-01-21 14:40:37** - Julia:
> Rewind:

**2026-01-21 14:46:41** - Julia:
> Ich schick dir ein paar Varianten vom Rap, dann kannst du schauen was am besten passt. Es ist immer unter Vocals und Music unterteilt! Vllt passt es ja auf den ursprünglichen Beat?

Laut:

**2026-01-21 14:46:58** - Julia:
> Tiefe Stimme:

**2026-01-21 14:47:34** - Julia:
> Smooth:

**2026-01-21 14:53:02** - Julia:
> "Fail" für's Ende - aber sehr übertrieben:

**2026-01-21 14:53:40** - Julia:
> Als Background für Teil 1, so bisschen funny/ Cartoon Music – falls du hier eine andere Idee hast, gerne :smile:

**2026-01-21 14:59:33** - Mert Koc:
> Oke danke :pray::skin-tone-3: 
Ich frag dann, wenn ich nicht weiter weiß 

**2026-01-21 14:59:52** - Mert Koc:
> Ich muss mich jetzt bereit für die Heimreise machen aber ich mache im Zug weiter 

**2026-01-21 15:00:05** - Julia:
> klar

**2026-01-21 15:00:39** - Julia:
> ich bin jetzt gleich mal weg und mache eine Runde mit Coco. hab schon 1 1/2 std. Meeting mit Marvin hinter mir :stuck_out_tongue:

**2026-01-21 15:00:47** - Julia:
> Gute erneute Reise :smile:

**2026-01-21 17:32:00** - Mert Koc:
> das ist jetzt super spezifisch aber kann man das check check raus machen?

**2026-01-21 17:32:39** - Mert Koc:
> bei dem smooth ist das

**2026-01-21 17:32:49** - Mert Koc:
> ungefähr eine Sekunde lang

**2026-01-21 17:52:50** - Julia:
> Auf jeden Fall 

**2026-01-21 17:53:04** - Julia:
> also soll ich oder kannst du es schneiden? 

**2026-01-21 17:56:07** - Mert Koc:
> Also ich kann es raus schneiden aber das merkt man halt, weil ich nicht gut im mischen bin 

**2026-01-21 17:56:20** - Mert Koc:
> Dachte vielleicht geht das mit AI 

**2026-01-21 18:08:24** - Julia:
> Problem ist, dann ändert er wieder die Aussprache der Wörter 

**2026-01-21 18:08:33** - Julia:
> Das klappt nicht so gut 

**2026-01-21 18:16:35** - Mert Koc:
> oke kacke, dann muss ich es doch versuchen

**2026-01-21 18:17:23** - Julia:
> Warte ich glaub ich hab's 

**2026-01-21 18:23:37** - Julia:
> moment

**2026-01-21 18:24:37** - Julia:
> okay jetzt sagt der Strong auch besser:

**2026-01-21 18:25:22** - Julia:
> Smooth neu:

**2026-01-21 18:25:42** - Julia:
> Was meinst du wann du fertig wärst? Weil sonst, können wir es auch morgen früh direkt schicken? je nachdem

**2026-01-21 18:31:37** - Mert Koc:
> sorry hab nicht geschaut und es jetzt einfach selber geschnitten

**2026-01-21 18:31:39** - Mert Koc:
> wäre soweit fertig

**2026-01-21 18:31:59** - Mert Koc:
> was noch cool wäre vielleicht, für den "langweiligen" part am Anfang so ein Strand sound?

**2026-01-21 18:32:13** - Mert Koc:
> Also so background Menschen geräusche vielleicht?

**2026-01-21 18:32:31** - Mert Koc:
> Und beim zweiten Part setzt dann die Musik ein

**2026-01-21 18:38:08** - Julia:
> ah okay, ja moment

**2026-01-21 18:39:00** - Julia:
> there you gooo

**2026-01-21 18:39:05** - Julia:
> ah okay

**2026-01-21 18:48:30** - Mert Koc:
> Video ist da :slightly_smiling_face:

**2026-01-21 18:50:52** - Mert Koc:
> Irgenwie ist der zweite Part voll schnell ... keine Ahnugn wieso

**2026-01-21 18:51:05** - Julia:
> okay mooooment

**2026-01-21 18:52:51** - Mert Koc:
> ok nvm

**2026-01-21 18:53:00** - Mert Koc:
> mein Videoplayer war auf x1,5 haha

**2026-01-21 18:55:16** - Julia:
> geil! Also bei den Pixeln werden sie noch Feedback haben
• beim 1. Teil sieht man direkt die Unterhose von David
• bei Sekunde 8 wollen sie die Pixel nur an den pikanten Stellen, also quasi 2 Balken. Weißt du wie ich meine?
• Teil 2: Sekunde 23 können wir hier die Szene mit David komplett mit Schlappen etwas länger lassen. Das sieht man fast garnicht, weil so schnell weg 
• beim 2. Teil ist das Oberteil von Toni noch nicht verpixelt

**2026-01-21 18:55:51** - Julia:
> Willst du die Sachen noch anpassen oder soll ich es schicken mit dem Hinweis, dass wir das noch anpassen morgen früh? Für mich beides fein

**2026-01-21 18:56:18** - Julia:
> liebs wie der Text zum Bild passt! :smile:

**2026-01-21 18:57:40** - Mert Koc:
> Kann ich alles jetzt noch machen, dauert nur kurz

**2026-01-21 18:57:52** - Mert Koc:
> Wo hab ich ihr Oberteil nicht verpixelt ?

**2026-01-21 18:58:06** - Julia:
> okay

**2026-01-21 18:58:16** - Julia:
> die letzte Szene, wo sie die Isar entlang laufen

**2026-01-21 19:03:06** - Mert Koc:
> achso da habe ich nur ihre Brust zensiert, nicht den Rücken

**2026-01-21 19:03:11** - Mert Koc:
> soll ich den Rücken auch?

**2026-01-21 19:05:00** - Julia:
> jaa genau

**2026-01-21 19:05:09** - Julia:
> sie soll nackt wirken

**2026-01-21 19:07:45** - Mert Koc:
> Aber ich glaube in echt würde man einen nackten Frauenrücken nicht zensieren

**2026-01-21 19:07:49** - Mert Koc:
> sondern nur die Brust

**2026-01-21 19:07:57** - Mert Koc:
> aber ich machs trotzdem mal

**2026-01-21 19:08:20** - Julia:
> ne aber so hat sie ja was an

**2026-01-21 19:08:22** - Julia:
> weißt du was ich meine?

**2026-01-21 19:08:40** - Julia:
> deswegen müssten wir es zensieren, damit sie nackt aussieht

**2026-01-21 19:09:18** - Julia:
> Aber verstehe wie du es meinst

**2026-01-21 19:14:06** - Mert Koc:
> Ich habe bei Part 2 jetzt das Hauchen weggelassen, weil man es von der Logik auch so versteht und sonst nicht aufgeht mit der Musiklänge, weil ich ja den Anfang länger gemacht habe

**2026-01-21 19:14:53** - Mert Koc:
> Kann es auch wieder rein aber dann muss ich einen Anderen Weg finden, dass die Länge zur Musik Länge passt

**2026-01-21 19:19:12** - Julia:
> okay verstehe!

**2026-01-21 19:20:11** - Julia:
> ja funktioniert auch so :slightly_smiling_face: ich schicks den beiden

**2026-01-21 19:20:22** - Julia:
> feedback schicke ich dir morgen

**2026-01-21 19:20:33** - Julia:
> kann mir vorstellen, dass sie noch ein Abschluss Bild oder so wollen

**2026-01-21 19:24:20** - Mert Koc:
> Oke dann Feierabend oder? ^^

**2026-01-21 19:24:25** - Julia:
> auf jeden!

**2026-01-21 19:24:34** - Julia:
> danke dir und bis morgen :slightly_smiling_face: ausgeschlafen haha

**2026-01-21 19:24:44** - Mert Koc:
> Ja wirklich haha

**2026-01-21 19:24:49** - Mert Koc:
> Bis morgen

**2026-01-22 09:52:58** - Julia:
> Hello! Video finden sie super, einzig den Song wollen sie noch etwas anpassen! 
Zum 2. Video haben so noch nichts gesagt, frag ich gleich mal :)

**2026-01-22 10:11:15** - Mert Koc:
> Ok :) 
Sagen sie dann auch noch, was sie am Song angepasst haben wollen? 

**2026-01-22 10:33:21** - Julia:
> 

**2026-01-22 10:56:46** - Mert Koc:
> Machen wir gleich zu zweit das Hisense Meeting ? 

**2026-01-22 10:59:18** - Julia:
> Yes 

**2026-01-22 11:18:26** - Mert Koc:
> 

**2026-01-22 11:22:01** - Julia:
> <https://next.frame.io/auth/refresh?state=0e81f80ab70d085aeece33dafccbce2072f96e634cd770057ddba132eb520023&amp;then=%2Fshare%2Fb21355d6-c989-4839-bdad-83285ec8966d&amp;soft=true|https://next.frame.io/auth/refresh?state=0e81f80ab70d085aeece33dafccbce2072f96e634c[…]then=%2Fshare%2Fb21355d6-c989-4839-bdad-83285ec8966d&amp;soft=true>

**2026-01-22 11:25:49** - Mert Koc:
> Hisense: Du denkst dein Freund betrügt dich
Gorenje: 3 Dips --&gt; Voiceover benötigt

**2026-01-22 11:38:11** - Julia:
> die Interview Videos hast du noch garnicht, oder? Dann lad ich sie in den Drive

**2026-01-22 11:43:48** - Mert Koc:
> danke!

**2026-01-22 12:03:28** - Mert Koc:
> Bei dem Lidl Video klappt es nicht mit dem Text + andere Instrumentals ... das passt leider gar nicht zusammen

**2026-01-22 12:03:46** - Mert Koc:
> Hab jetzt mehrere Kombinationen versucht aber es ist gar nicht gut

**2026-01-22 12:03:51** - Julia:
> Okay

**2026-01-22 12:03:58** - Julia:
> Heißt, was kann ich genau tun?

**2026-01-22 12:04:20** - Mert Koc:
> Wir brauchen den Text, den sie gut finden mit neuer Musik

**2026-01-22 12:04:46** - Julia:
> okayy

**2026-01-22 12:04:53** - Mert Koc:
> Weil den Lyric fanden sie ja gut oder? es war ihnen nur zu smooth?

**2026-01-22 12:04:56** - Julia:
> Ja genau

**2026-01-22 12:05:17** - Mert Koc:
> Ja dann bräcuhten wir zum Lyric neue Hintergrund Musik

**2026-01-22 12:05:19** - Julia:
> Und lyrics (Vocals) vom bestehenden Video und nur den Beat von den alten Sounds, hast du probiert oder?

**2026-01-22 12:06:12** - Julia:
> bzw. das meinst du, das nicht klappt oder?

**2026-01-22 12:06:21** - Mert Koc:
> Welche alten Sounds meinst du? Habs mit "Laut" und "Tiefer Stimme" versucht

**2026-01-22 12:06:34** - Mert Koc:
> --&gt; mit denen klappts nicht

**2026-01-22 12:06:39** - Mert Koc:
> Die Stimme ist offbeat

**2026-01-22 12:06:51** - Mert Koc:
> Weil der Beat nicht der Gleiche ist

**2026-01-22 12:06:52** - Julia:
> 

**2026-01-22 12:07:02** - Julia:
> ja okay, passt. dann erstell ich eins komplett neu

**2026-01-22 12:07:12** - Mert Koc:
> Genau

**2026-01-22 12:08:09** - Mert Koc:
> Bsp: 

**2026-01-22 12:08:52** - Mert Koc:
> Ist weird 

**2026-01-22 12:09:10** - Julia:
> ja alles gut

**2026-01-22 12:09:14** - Julia:
> hätte ja einfach sein können :smile:

**2026-01-22 12:30:29** - Julia:
> habs gleich

**2026-01-22 12:31:19** - Mert Koc:
> Kein Stress, ich hab nebenbei angefangen, das Bauchtaschen Video

**2026-01-22 12:31:36** - Mert Koc:
> Wie startet das nochmal? Hast du da das PDF mit der Shotliste nochmal für mich?

**2026-01-22 12:32:57** - Julia:
> okay

**2026-01-22 12:33:05** - Julia:
> habs dir in Asana

**2026-01-22 12:33:18** - Julia:
> <https://app.asana.com/1/1199360402832734/project/1212808160983275/task/1212807852658836?focus=true>

**2026-01-22 12:38:53** - Julia:
> there you go:

**2026-01-22 12:45:18** - Mert Koc:
> Ist das zwei mal das gleiche?

**2026-01-22 12:45:51** - Julia:
> einmal Vocals und Beat getrennt und einmal zusammen :slightly_smiling_face:

**2026-01-22 12:47:48** - Mert Koc:
> Nur zum Lyric, weil mir das eben aufgefallen ist... "jeder Griff "Ja's" --&gt; "Ja!" ist ne Rewe Eigenmarke, ist das beabsichtigt?

**2026-01-22 12:48:28** - Julia:
> Haha okay geil. ne das ist eigentlich nur so ein Hintergrund Sound wie "wer"

**2026-01-22 12:49:52** - Mert Koc:
> Achso ne das ist im Main Lyric am Ende

**2026-01-22 12:49:59** - Julia:
> ja ich weiß

**2026-01-22 12:50:07** - Julia:
> aber sollte nur ein Background sein

**2026-01-22 12:50:56** - Julia:
> lassen wir es so, bisher kam das Feedback nicht. wenn ichs wieder anfasse, passiert wieder irgendwas anderes

**2026-01-22 12:52:07** - Mert Koc:
> Oke Video kommt

**2026-01-22 12:53:06** - Mert Koc:
> 

**2026-01-22 12:54:25** - Julia:
> geil :smile:

**2026-01-22 12:54:43** - Julia:
> sollen wir am Ende nochmal Close Up auf David machen mit dem Zwinkern? damit wir keine so lange Schwarzblende haben

**2026-01-22 12:55:10** - Julia:
> ist ja egal, wenn wir das bei beiden videos drin haben

**2026-01-22 13:20:25** - Mert Koc:
> Das war eine Scene aus dem Bauchtaschen Video aber nicht so schlimm :slightly_smiling_face:

**2026-01-22 13:21:01** - Julia:
> ist doch meeega

**2026-01-22 13:21:03** - Julia:
> Dankee :slightly_smiling_face:

**2026-01-22 13:26:31** - Julia:
> habs geschickt

**2026-01-22 13:31:01** - Julia:
> FYI, dass du dich nicht wunderst: beim Video "dein Freund betrügt dich": in der Task steht keine Background Musik --&gt; finde es ohne aber relativ lame, würde Musik hinzufügen. Weiteres Feedback packe ich einfach rein

**2026-01-22 13:33:16** - Mert Koc:
> Ja da dachte ich mir, dass wir TikTok Musik nutzen können.. generell mehr TikTok Musik nutzen ABER, was mir gerade eingefallen ist, Peru kann auch aus der Kommerziellen Musik Dings Lieder raussuchen

**2026-01-22 13:33:40** - Julia:
> ah okay, got it!

**2026-01-22 13:33:44** - Julia:
> ja können sie das?

**2026-01-22 13:34:06** - Julia:
> einfach aus TikTok selbst oder was soll ich hier sagen, wo sie Musik finden?

**2026-01-22 13:36:11** - Mert Koc:
> <https://ads.tiktok.com/business/creativecenter/music/pc/en>

**2026-01-22 13:36:13** - Mert Koc:
> Hier :slightly_smiling_face:

**2026-01-22 13:36:31** - Mert Koc:
> und nur "TikTok commercial use" benutzen

**2026-01-22 13:37:35** - Mert Koc:
> Das würde uns sehr viel Arbeit abnehmen + wenn man TikTok Sounds nutzt, kann ich mir vorstellen, dass die besser performen, weil auch nach Sounds gesucht wird

**2026-01-22 13:40:43** - Julia:
> ja cool! danke

**2026-01-22 14:01:55** - Julia:
> Okay Flo hat nochmal Feedback gegeben zum Schlappen Video:
• Teil 1 etwas kürzen (Video noch etwas zu lange)
• Teil 2: "Oberteil der Frau hautfarben machen" --&gt; denke er meint hier die Pixel, die so bisschen grau sind. Geht das?

**2026-01-22 14:06:30** - Mert Koc:
> Pain :melting_face:

**2026-01-22 14:10:36** - Julia:
> jaa..

**2026-01-22 14:16:47** - Julia:
> ich bin jetzt mal unterwegs, ich bringe die Amazon Sachen vom Lidl Dreh zur Post

**2026-01-22 15:02:21** - Mert Koc:
> das mit der Hautfarbe beim Oberteil geht nicht... ist viel zu viel Aufwand

**2026-01-22 15:15:21** - Julia:
> okay geb ich weiter 

**2026-01-22 15:45:04** - Julia:
> hatte vorhin eine Nachricht von F bekommen: ich soll noch was für morgen Abend fertig machen. Hab gesagt, ich brauche den Ausgleich morgen (sobald alle Projekte fertig sind). sorry not sorry

**2026-01-22 15:47:52** - Julia:
> hast du noch was wegen deinem meeting gesagt=

**2026-01-22 16:09:58** - Mert Koc:
> Habs online

**2026-01-22 16:10:17** - Mert Koc:
> Ich habe heute noch keine Pause gemacht und nur an diesen Lidl Videos gearbeitet

**2026-01-22 16:12:38** - Julia:
> Ich habs mir schon gedacht!!

**2026-01-22 16:12:52** - Julia:
> Dann sag ihm du musst morgen auch frei machen und das Meeting soll vormittags stattfinden

**2026-01-22 16:12:57** - Julia:
> Wir müssen Grenzen setzen

**2026-01-22 16:16:08** - Mert Koc:
> Bauchtasche V1

**2026-01-22 16:23:08** - Mert Koc:
> Schlappen V3 --&gt; 3 Sekunden kürzer am Anfang

**2026-01-22 16:26:27** - Julia:
> nice, ich schicks rüber! :slightly_smiling_face:

**2026-01-22 16:28:43** - Julia:
> bitte mach ne break!

**2026-01-22 16:29:44** - Mert Koc:
> Ja bin jetzt erst mal Pause :slightly_smiling_face:

**2026-01-22 18:02:29** - Mert Koc:
> Kam noch was? :sweat_smile:

**2026-01-22 18:23:13** - Julia:
> Sind happy :) 

**2026-01-22 18:23:15** - Julia:
> Bisher 

**2026-01-22 18:23:49** - Julia:
> Der Schnitt ist echt sehr cool, danke dir :heart_hands:

**2026-01-22 18:39:58** - Mert Koc:
> Sehr gut :+1::skin-tone-3: 

**2026-01-23 15:58:01** - Julia:
> 

**2026-01-23 15:58:14** - Julia:
> 

**2026-01-23 15:58:22** - Julia:
> there you go!

**2026-01-23 16:00:00** - Mert Koc:
> danke!

**2026-01-23 16:02:31** - Julia:
> klaroo

**2026-01-23 16:05:36** - Julia:
> falls nochmal was ist, ich bin bis 18 Uhr erreichbar (daheim) :slightly_smiling_face:

**2026-01-23 16:07:54** - Mert Koc:
> Oke :slightly_smiling_face: Ich schicke dir gleich mal das Video für Feedback

**2026-01-23 16:08:12** - Mert Koc:
> Ich hab jetzt die Fotos mal weggelassen, weil es sonst visuell einfach ablenkt

**2026-01-23 16:10:13** - Mert Koc:
> 

**2026-01-23 16:41:32** - Mert Koc:
> Ich schicks mal raus an Laureen

**2026-01-23 18:11:37** - Mert Koc:
> Das ist btw mein Stundensheet diese Woche, damit wir es evtl. ähnlich haben :sleepy:

**2026-01-26 13:39:17** - Julia:
> <https://www.linkedin.com/posts/carsten-maschmeyer_dienstreise-mitarbeiter-wertschaeutzung-activity-7421455914416750592-iYW1?utm_source=share&amp;utm_medium=member_desktop&amp;rcm=ACoAADKQUUcB3jeFwnfsLSELtQwW0gM_-NwcwF8|https://www.linkedin.com/posts/carsten-maschmeyer_dienstreise-mitarbeiter-wertschaeut[…]m=member_desktop&amp;rcm=ACoAADKQUUcB3jeFwnfsLSELtQwW0gM_-NwcwF8>

**2026-01-26 13:44:38** - Mert Koc:
> Glaub du wolltest das eig an Flo senden :stuck_out_tongue:

**2026-01-26 13:44:44** - Mert Koc:
> hahhaha

**2026-01-26 13:44:49** - Julia:
> :joy:

**2026-01-26 13:45:49** - Mert Koc:
> "Verbesserungsvorschlag"

**2026-01-26 13:46:18** - Julia:
> Wünsche, Anregungen &amp; Kommerkasten

**2026-01-26 13:46:30** - Mert Koc:
> Vorher noch fragen, ob's Boni für Verbesserungsvorschläge gibt und dann das raushauen

**2026-01-26 13:46:49** - Mert Koc:
> Also ich denke wir sollten immer businessclass fliegen, weil

**2026-01-29 13:30:56** - Julia:
> Hello!

**2026-01-29 13:31:12** - Julia:
> hast du bei der Auslagenaufstellung dann jede einzelne Position nochmal angepasst oder nur gesamt?

**2026-01-29 13:32:45** - Mert Koc:
> Die einzelnen

**2026-01-29 13:32:51** - Julia:
> :melting_face:

**2026-01-29 13:32:52** - Julia:
> okee danke

**2026-01-29 13:33:33** - Mert Koc:
> Hab den Multiplikator geändert zu * 0,13393

**2026-01-29 13:33:43** - Mert Koc:
> also jeweils

**2026-01-29 13:33:48** - Julia:
> smart, danke!

**2026-01-29 13:47:35** - Julia:
> Mert :smile: I can't

**2026-01-29 13:49:18** - Mert Koc:
> Boa die nervt mich so

**2026-01-29 13:49:22** - Mert Koc:
> werde so sauer hahaha

**2026-01-29 13:49:42** - Mert Koc:
> Sag ihr, dass sie mal lernen soll gescheit zu antworten

**2026-01-29 13:51:03** - Julia:
> JA

**2026-01-29 13:51:09** - Julia:
> ich hab jetzt eine Ansage gemacht

**2026-01-29 16:56:52** - Julia:
> glaub wir überziehen

**2026-01-29 16:57:05** - Julia:
> :no_mouth:

**2026-01-29 16:57:51** - Mert Koc:
> Also alles wie immer haha

**2026-01-29 16:58:01** - Julia:
> genau!

**2026-01-30 11:53:50** - Mert Koc:
> Hat Anna inzwischen was zutun?

**2026-01-30 11:54:01** - Mert Koc:
> Weil sie hat mir nie geschrieben und antwortet mir auch nicht

**2026-01-30 11:54:06** - Julia:
> eigentlich ja

**2026-01-30 11:54:12** - Julia:
> lieb ich

**2026-01-30 11:54:27** - Mert Koc:
> Ah hast du sie schon gebrieft?

**2026-01-30 11:54:40** - Julia:
> Nene mit anderen Tasks meinte ich

**2026-01-30 11:55:06** - Mert Koc:
> ah oke

**2026-01-30 11:55:12** - Mert Koc:
> ne dann ist in Ordnung

**2026-01-30 11:55:29** - Mert Koc:
> Ich mache jetzt Lunch :slightly_smiling_face:

**2026-02-03 10:44:38** - Julia:
> 

**2026-02-03 10:50:02** - Mert Koc:
> All right :) 

**2026-02-03 10:50:23** - Mert Koc:
> Ich schau dann, falls sie sich meldet 

**2026-02-16 13:59:55** - Julia:
> Flo ruft mich evtl. gleich an – passt es dir wenn wir bisschen später/ spontaner sprechen?

**2026-02-16 14:00:04** - Julia:
> weiß gerade nicht wann er anruft. er meinte "gleich"

**2026-02-16 14:00:21** - Mert Koc:
> Ja kein Problem 

**2026-02-16 14:00:29** - Mert Koc:
> Schreib einfach sobald du kannst 

**2026-02-16 14:00:52** - Julia:
> okay dankee!

**2026-02-16 14:23:44** - Julia:
> bin readyyy

**2026-02-16 14:35:05** - Mert Koc:
> Komme 

**2026-02-16 14:36:16** - Julia:
> 1 min

**2026-02-16 15:06:53** - Mert Koc:
> <https://docs.google.com/presentation/d/1nicKLQWV9iYJJR4wYGWkgTLjOEoMe0Tl/edit?usp=sharing&amp;ouid=112975104266410479066&amp;rtpof=true&amp;sd=true>


---

## Marvin Hammerschmidt (640 messages)

**Julia sent:** 328 | **Marvin Hammerschmidt sent:** 312

**Folder:** `D09U7C9S230`

**2025-11-20 17:54:47** - Julia:
> Hi Marvin! :slightly_smiling_face:
Wir haben den Gorenje TikTok Account jetzt auch aufgesetzt und würden hier natürlich auch gerne den blauen Haken beantragen. Könntest du mir evtl. nochmal erklären, wie und wo ihr das gemacht habt? :smile:

**2025-11-20 17:54:49** - Julia:
> danke dir!

**2025-11-20 17:56:07** - Marvin Hammerschmidt:
> Hey Juli. Kann ich dir morgen gern erklären. Bin aber bis mittags voll in Terminen 

**2025-11-20 17:56:56** - Julia:
> ja easy, kein Stress!

**2025-11-21 13:27:32** - Julia:
> Hello, hab noch eine weitere Frage: Julia meinte du hättest die Info nicht, Flo meinte doch :smile:
Es geht um die Kosten für den Dreh im Heimkinoraum. Könntest du mir hier grob sagen, wieviele Videos in welchem Zeitaufwand entstanden sind und was es ca. gekostet hat?
Danke

**2025-11-21 13:30:58** - Marvin Hammerschmidt:
> Hello :slightly_smiling_face:
Uf
Das hab ich nicht organisiert und die die das gemacht haben sind beide nicht mehr da
Es waren um die 90 Videos
Ich meine die Creator haben jeweils 500 gekostet
Der Videograph glaube ich 600

Was wir für die Nutzung des Raumes gezahlt haben weiß ich leider nicht aber kann auch umsonst gewesen sein

**2025-11-21 13:32:20** - Julia:
> Okay, aber das hilft schon mal etwas weiter. ich danke dir!

**2025-11-21 13:32:42** - Marvin Hammerschmidt:
> Kann gleich nochmal alles durchschauen

Haben gerad released und bin übel im Stress:D melde mich :slightly_smiling_face:

**2025-11-21 13:33:27** - Julia:
> alles gut, danke dir!

**2025-11-21 13:33:42** - Julia:
> wegen blauen Haken können wir auch montags sprechen – hab auch noch genügend anderes

**2025-11-21 13:35:55** - Marvin Hammerschmidt:
> Dann lieber Montag
Heute ist craaaazy :smile:

**2025-11-21 13:37:27** - Julia:
> alles klar, meld du dich dann gerne einfach oder stell mir was ein. bin wahrscheinlich flexibler

**2025-11-25 10:49:22** - Julia:
> Hey, hast du gegen 12.30 kurz Zeit?

**2025-11-25 10:50:01** - Marvin Hammerschmidt:
> Hey
Bis jetzt schon. Kann aber noch ein Termin dazwischen kommen

**2025-11-25 11:00:48** - Marvin Hammerschmidt:
> ok passt
13 Uhr hab ich den folge Termin :slightly_smiling_face:

**2025-11-25 11:01:22** - Julia:
> okay super, dann huddle ich dich an

**2025-11-25 12:32:26** - Marvin Hammerschmidt:
> 

**2025-11-25 12:34:39** - Julia:
> melde mich gleich

**2025-11-25 12:40:03** - Julia:
> sorryy, Flo ist am Telefon

**2025-11-25 12:40:19** - Marvin Hammerschmidt:
> ohje

**2025-11-25 12:51:50** - Marvin Hammerschmidt:
> 

**2025-12-22 13:26:53** - Julia:
> Hi Marvin! Hoffe dir geht es gut :slightly_smiling_face:

**2025-12-22 13:27:34** - Julia:
> Flo möchte gerne, dass ich eine kleine Intro zum Thema Higgsfield/ AI gebe. Terminlich wäre heute 18Uhr sein Wunsch – da ich mir aber vorstellen kann, dass einige da schon nichtmehr available sind, frag ich lieber einmal nach

**2025-12-22 13:27:52** - Julia:
> Sag gern Bescheid, ob dir das passt. Ansonsten würde ich morgen gegen 17 Uhr anpeilen

**2025-12-22 13:28:32** - Marvin Hammerschmidt:
> Hey Juli
oh man

**2025-12-22 13:28:40** - Marvin Hammerschmidt:
> ja dann morgen gegen 17 Uhr wenn es geht bitte

**2025-12-22 13:28:48** - Marvin Hammerschmidt:
> Nur du und ich oder er auch?

**2025-12-22 13:29:04** - Julia:
> Okay, ja hab ich mir schon gedacht :smile: Mert passt es auch nicht und mir eigentlich auch nicht (weder heute noch morgen aber well)

**2025-12-22 13:29:12** - Julia:
> er auch. Peru auch

**2025-12-22 13:29:19** - Marvin Hammerschmidt:
> Ja same haha

**2025-12-22 13:29:32** - Marvin Hammerschmidt:
> uf

**2025-12-22 13:30:00** - Marvin Hammerschmidt:
> Für wielang ist das angesetzt?

**2025-12-22 13:30:33** - Julia:
> ich hab noch keine Ahnung

**2025-12-22 13:30:52** - Marvin Hammerschmidt:
> alright
Danke fürs Bescheid geben ^^
Ich bin gespannt

**2025-12-22 13:31:19** - Julia:
> 

**2025-12-22 13:31:33** - Marvin Hammerschmidt:
> Klassiker

**2026-01-07 03:14:54** - Marvin Hammerschmidt:
> Hey Juli. Ich hoffe du hattest nen entspannten Urlaub :) lass uns heute doch mal kurz über die neue Struktur sprechen und wie wir das alles am besten organisieren. Ich hab am Morgen 2 Termine aber dann bis 14 Uhr frei. Wann würde es dir am besten passen? :)

**2026-01-07 09:12:13** - Julia:
> Hi Marvin! Happy new year :slightly_smiling_face:
Yes, wahrscheinlich hast du auch mehr Infos als ich. Also gerne. Passt es dir um 12 Uhr?

**2026-01-07 09:15:13** - Marvin Hammerschmidt:
> Das bezweifle ich stark ehrlicherweise :smile:

**2026-01-07 09:15:19** - Marvin Hammerschmidt:
> Ja können wir machen :slightly_smiling_face:

**2026-01-07 09:15:37** - Julia:
> lieb ich

**2026-01-07 09:15:41** - Julia:
> ich stell schnell was ein

**2026-01-07 09:15:46** - Marvin Hammerschmidt:
> Super
Danke dir!

**2026-01-07 12:47:20** - Marvin Hammerschmidt:
> emails nicht aber dafür um die 50 whatsapp nachrichten

**2026-01-07 12:58:21** - Julia:
> hab ich mir schon gedacht

**2026-01-07 13:50:44** - Marvin Hammerschmidt:
> Kannst du mir den Termin mit Julia noch weiterleiten?
Ich hab bisher keinen^^

**2026-01-07 13:51:12** - Julia:
> Jana meinst du oder? :slightly_smiling_face:

**2026-01-07 13:51:17** - Julia:
> Sie hat ihn jetzt auf morgen verlegt..?

**2026-01-07 13:51:35** - Julia:
> ich kann da nicht, deshalb schwierig :smile:

**2026-01-07 13:51:54** - Marvin Hammerschmidt:
> huch
Ja haha

ohman

**2026-01-07 13:53:10** - Julia:
> sieht man ja eigentlich auch im Kalender aber okay

**2026-01-07 13:53:21** - Julia:
> Wir können aber trotzdem gerne später kurz quatschen

**2026-01-08 14:21:29** - Marvin Hammerschmidt:
> Hey Juli bist du da und könntest für mich was an die Designer briefen?

**2026-01-08 14:58:13** - Julia:
> Hi, kann dir in ca. 30 min weiterhelfen 

**2026-01-08 14:59:00** - Julia:
> Bzw. Ist das dann meine Aufgabe? Oder wie lief das vorher bei euch ab?  

**2026-01-08 14:59:24** - Marvin Hammerschmidt:
> Eigentlich basti aber der muss zum arzt und bei mir brennt alles :smile:

**2026-01-08 15:00:02** - Marvin Hammerschmidt:
> ich machs gleich selber all good
Ist nicht viel

**2026-01-08 15:36:04** - Julia:
> ah mist, sorry!

**2026-01-08 15:36:18** - Julia:
> Flo wollte jetzt nochmal vorm Meeting mit mir sprechen

**2026-01-08 15:36:49** - Marvin Hammerschmidt:
> Alles gut
War wie gesagt nicht viel:)
Wenn die Designer direkt delivern, passt alles ^^

**2026-01-08 15:37:18** - Julia:
> fingers crossed!

**2026-01-08 15:58:53** - Marvin Hammerschmidt:
> Flo hat mich gebeten, dir die Kontakte von den Darsteller Agenturen durchzugeben

<mailto:cr@lachfalten-people.de|cr@lachfalten-people.de>  und <mailto:info@agentur-isarperlen.de|info@agentur-isarperlen.de> waren bisher die vielversprechensten.
Ansonsten gibt es noch <https://www.fameonme.de/kontakt/> und  <https://agenturfrehse.com/> mit einem recht großen Angebot.

**2026-01-08 16:00:31** - Julia:
> ah super, danke! :slightly_smiling_face: ja genau da haben wir eben drüber gesprochen

**2026-01-09 09:52:58** - Julia:
> Hi! Hast du so gegen 11.30 nochmal kurz Zeit für mich bezüglich SIXT?

**2026-01-09 09:54:28** - Marvin Hammerschmidt:
> Hey
Ich bin ab 11 im Call mit SIXT, wenn der dann vorbei ist meld ich mich bei dir

**2026-01-09 09:54:40** - Julia:
> okay perfekt

**2026-01-09 11:48:13** - Marvin Hammerschmidt:
> bin gleich soweit
im sorry

**2026-01-09 11:49:40** - Marvin Hammerschmidt:
> 

**2026-01-09 14:20:27** - Marvin Hammerschmidt:
> Ist mit Flo geklärt
Zum jahres Auftakt kommst nur du mit, er nicht

Wir sollen nächste WOche mal 2 längere Termine haben in denen wir more deep dive gehen :slightly_smiling_face:

**2026-01-09 14:39:45** - Julia:
> okay

**2026-01-09 14:40:15** - Marvin Hammerschmidt:
> Also nach deiner Entscheidung natürlich. Ich bleib aber beim Rat: Versuchs mal :) 

**2026-01-09 14:56:24** - Julia:
> danke :slightly_smiling_face: ja ich muss das mal kurz sacken lassen über's Wochenende und meld mich dann am Montag direkt!

**2026-01-12 12:32:45** - Julia:
> entschieden hab ich mich eigentlich nicht dafür, aber sieht Flo leider nicht so. also here I am

**2026-01-12 12:32:56** - Marvin Hammerschmidt:
> What 

**2026-01-12 12:33:28** - Marvin Hammerschmidt:
> er ruft mich gerade an

**2026-01-12 12:33:35** - Julia:
> na super :smile:

**2026-01-12 12:33:37** - Marvin Hammerschmidt:
> und sagt es liegt daran das es an meinem vortrag liegt

**2026-01-12 12:33:44** - Marvin Hammerschmidt:
> das ich zu viele probleme genannt habe

**2026-01-12 12:34:09** - Julia:
> ja hat er zu mir auch gesagt. aber ich hab 5 mal gesagt "ich will diese verantwortung nicht tragen, ich bin kein Projektmanager"

**2026-01-12 12:34:25** - Julia:
> hat er nicht akzeptiert, weil er sagt das ist basic, das kann ich und hab ich ja auch schon gemacht

**2026-01-12 12:34:45** - Julia:
> ich hab gesagt ich will nicht der Haupt-AP sein/ werden, soll ich aber nach und nach trotzdem

**2026-01-12 12:40:22** - Julia:
> jetzt ruft er mich wieder an

**2026-01-12 12:40:39** - Marvin Hammerschmidt:
> Ich habe ihm gesagt, dass wir schon besprochen haben, dass ich es eher unsinnig finde, in unserem Falle PM und Creative klar abzugrenzen
Dem hat er zugestimmt.
Auch das mit dem Hauptansprechpartner, das werde immer ich sein, gerade weil es auch super viel TikTok Expert fragen sind (eigentlich zu 95%)

**2026-01-12 12:40:51** - Marvin Hammerschmidt:
> Wir werden uns das sinngemäß´aufteilen und so machen wie du Kapazitäten hast

**2026-01-12 12:43:02** - Marvin Hammerschmidt:
> Das, wobei ich dich brauche, ist vor allem, um mit meiner unstrukturierten Art "aufzuräumen" und in Strukturen zu geben.
Das ist das große Überding, würde ich sagen.
Alles andere ist punktuell und können wir so machen, wie wir beide das am besten aufteilen wollen. Ich habe das lang genug alleine gemacht. Es ist also nicht so, dass du da mit irgendetwas alleine bist oder da Angst haben musst.
Ich habe sowieso auf alles ein Auge und würde dich da mit nichts alleine lassen. Lass uns gleich wenn Flo aufgelegt hat auch kurz sprechen, oder halt nach unserem call um 13 uhr

**2026-01-12 12:46:59** - Julia:
> 

**2026-01-12 12:49:11** - Marvin Hammerschmidt:
> Ja alles gut^^
Wir sprechen nach dem Call auch über Verantwortungen etc.
Das bekommen wir schon alles hin

**2026-01-13 12:01:28** - Julia:
> bin in 2 min da!

**2026-01-13 12:01:40** - Marvin Hammerschmidt:
> kein stress

**2026-01-13 12:07:42** - Marvin Hammerschmidt:
> <https://f.io/E6p5Lww5>

**2026-01-13 12:15:17** - Marvin Hammerschmidt:
> <https://drive.google.com/file/d/1gxZnZ63Dh4MNgFBt1QRVoL3rwrLU1hgr/view?usp=drive_link>

**2026-01-13 14:26:03** - Marvin Hammerschmidt:
> Könntest du mir die ssio Idee mal schicken? 

**2026-01-13 14:48:05** - Julia:
> klar, habs hier unter Videodreh – Skripte etc. sind noch nicht freigegeben von Flo, hab ich ihm eben geschickt. Die Grundidee mit dem FKK Video kam aber von Flo/ Alex

**2026-01-13 14:59:24** - Marvin Hammerschmidt:
> Ah danke :slightly_smiling_face:

**2026-01-14 09:05:39** - Marvin Hammerschmidt:
> GuMo Juli :slightly_smiling_face:

Hast du den Invite bekommen?

**2026-01-14 09:21:47** - Julia:
> Hi! Yes, kam an :slightly_smiling_face: danke

**2026-01-14 09:22:08** - Julia:
> Wissen sie denn schon von mir? Bzw. wurde ich schon in einer Form angekündigt? Bzgl. Vorstellung

**2026-01-14 09:22:36** - Marvin Hammerschmidt:
> Ich habe gesagt dass da jemand neues kommt
Mehr nicht

**2026-01-14 09:22:42** - Marvin Hammerschmidt:
> lass uns vorher nochmal kurz sprechen

**2026-01-14 09:23:10** - Julia:
> Okay, ja gern. Würde es dann recht knapp halten und sagen ich unterstütze jetzt auch im Team – muss ja keinen Fokus nennen

**2026-01-14 09:23:20** - Marvin Hammerschmidt:
> yes

**2026-01-14 09:23:37** - Marvin Hammerschmidt:
> Flo hat mir ein paar sachen geschickt
Darüber reden wir gleich und schauen wie wir das smart sagen

**2026-01-14 09:23:49** - Julia:
> Klar hat er das :smile:

**2026-01-14 09:23:51** - Julia:
> So machen wir es

**2026-01-14 09:41:00** - Marvin Hammerschmidt:
> Hab dir noch nen Termin geschickt
Sorry hab nicht gesehen das es 2 sind heut

**2026-01-14 09:51:30** - Julia:
> okay alles klar

**2026-01-14 09:51:44** - Julia:
> sag mal wie heißt das Sixt Projekt in Clockify? Ich finde das nicht

**2026-01-14 10:24:45** - Marvin Hammerschmidt:
> Sixt retainer.   Schaue gleich genau. Muss noch was fertig machen :)

**2026-01-14 10:43:58** - Marvin Hammerschmidt:
> 2023-SIXT-Retainer-TikTok

**2026-01-14 10:44:10** - Marvin Hammerschmidt:
> Wann sollen wir vorher noch kurz sprechen :slightly_smiling_face:?
Meeting ist um 2

**2026-01-14 10:46:56** - Julia:
> kannst du um 11.45?

**2026-01-14 10:47:31** - Marvin Hammerschmidt:
> yes

**2026-01-14 11:04:08** - Julia:
> super, ich huddle dich dann gleich an

**2026-01-14 11:45:23** - Marvin Hammerschmidt:
> 

**2026-01-14 14:01:49** - Julia:
> hänge im warteraum

**2026-01-14 15:03:01** - Marvin Hammerschmidt:
> rufe dich gleich kurz an :;

**2026-01-14 15:03:07** - Julia:
> perfekt

**2026-01-14 15:04:26** - Marvin Hammerschmidt:
> 

**2026-01-14 15:05:36** - Julia:
> 

**2026-01-14 17:39:28** - Marvin Hammerschmidt:
> ehrlicher gedanke?

Ich habe sorge dass das zu boring ist und highlights fehlen

**2026-01-14 17:40:12** - Julia:
> finde es sehr werblich

**2026-01-14 17:40:23** - Marvin Hammerschmidt:
> ich sag gleich was

**2026-01-14 17:40:44** - Julia:
> sie haben den pitch schon abgeschickt, also ändern wird eh schwierig

**2026-01-14 17:40:51** - Marvin Hammerschmidt:
> oh

**2026-01-14 17:41:07** - Marvin Hammerschmidt:
> das ist schlecht

**2026-01-14 18:04:41** - Marvin Hammerschmidt:
> Interessant

**2026-01-14 18:04:46** - Julia:
> :smile:

**2026-01-14 18:04:54** - Julia:
> Meinungen werden ja auch nicht unbedingt aufgenommen

**2026-01-14 18:05:11** - Julia:
> Naja, ich muss jetzt pünktlich los! Ich meld mich morgen gleich bei dir :slightly_smiling_face: happy evening!

**2026-01-14 18:05:37** - Marvin Hammerschmidt:
> Das ging sogar noch haha 

Yes. Machen wir.  Danke gleichfalls :)

**2026-01-15 10:09:41** - Julia:
> Hello! also ich hab jetzt die Präsi nochmal durchgelesen. Mein fav. Part wäre: 19-23 (also der Consistency Part)
Bezüglich Endslides hab ich tatsächlich das Gefühl, dass das eher bei Flo liegen sollte mit Versprechen usw. 

Hast du schon eine Meinung dazu? :slightly_smiling_face:

**2026-01-15 10:10:21** - Marvin Hammerschmidt:
> hello
Verstehe generell noch nicht zu n100% warum wir da mit einsteigen

Ich bin noch bis 12 busy und schau es mir dann an und melde mich bei dir :slightly_smiling_face:

**2026-01-15 10:12:36** - Julia:
> ja same :joy:

**2026-01-15 10:13:12** - Julia:
> klaro 

**2026-01-15 12:48:59** - Marvin Hammerschmidt:
> sorry
rede noch mit Flo

**2026-01-15 12:49:47** - Julia:
> hab ich mir schon gedacht. bin im büro und er hatte einmal deinen Namen gesagt. ist dann aber ins Nebenzimmer :smile:

**2026-01-15 12:50:15** - Marvin Hammerschmidt:
> Ja ein klein wenig beef :smile:

**2026-01-15 12:50:20** - Marvin Hammerschmidt:
> as usual
So ich schaus mir jetzt an

**2026-01-15 12:53:34** - Marvin Hammerschmidt:
> alright dann mach ich etwas den bad cop mit 13-19 :smile:

Fühlt sich an wie ein Schulreferat

**2026-01-15 12:54:02** - Marvin Hammerschmidt:
> Flo wäre es schon wcihtig wenn du mit in das jarhes kickoff kommst mit sixt und er hat da schon recht 
Meinst du das wäre irgendwie möglich oder bist du um 2 im Flugzeug?

**2026-01-15 13:10:52** - Julia:
> oh wieso bad cop?

**2026-01-15 13:11:06** - Julia:
> den schluss macht dann flo? oder sagen wir es ihm nochmal?

**2026-01-15 13:11:17** - Marvin Hammerschmidt:
> Müssen wir noch besprechen

**2026-01-15 13:12:27** - Julia:
> ich lande laut plan um 13.30. Wenn ich dazu kommen kann, klar. ich kann leider garnicht einschätzen wie es dort am Flughafen ist. Ist ein kleiner :smile:

**2026-01-15 13:12:41** - Julia:
> also im Hotel oder so sind wir da noch nicht. Brauchen dort mit dem auto nochmal eine Std.

**2026-01-15 13:29:55** - Marvin Hammerschmidt:
> Das ist natürlich tight
Meisnte mobil ohne Kamera geht dazwischen?
Ich weiß  das ist stressig :disappointed:

**2026-01-15 15:39:05** - Julia:
> ja, ich probiers aber kanns wie gesagt nicht versprechen

**2026-01-15 15:39:21** - Marvin Hammerschmidt:
> ja klar das ist voll ok

**2026-01-15 15:42:48** - Julia:
> wir könnten die option mit: wir wollen das nicht präsentieren auch mal noch versuchen :smile:

**2026-01-15 15:42:58** - Marvin Hammerschmidt:
> hahahahahah

**2026-01-15 15:43:19** - Marvin Hammerschmidt:
> ich glaub nicht das es dafür eine chance gibt:D

**2026-01-15 15:43:33** - Julia:
> :sadblob:

**2026-01-16 09:29:01** - Marvin Hammerschmidt:
> Hey Juli
Hast du zeit um 11 mit ins SIXT meeting zu kommen? Katharina ist nicht da aber wir können über Romina ein paar Zugriffe anfragen

**2026-01-16 09:32:23** - Julia:
> Hello! Leider nein, wir drehen heute ab 11.30. Ich bin gleich nichtmehr am Laptop

**2026-01-16 09:32:37** - Julia:
> ich weiß, dass Flo das super wichtig ist (und ist es ja auch) aber ich kann mich nicht 2teilen

**2026-01-16 09:32:41** - Marvin Hammerschmidt:
> Alles klar
ich schau ob die ohne dich organisieren kann :slightly_smiling_face:

**2026-01-16 09:32:50** - Marvin Hammerschmidt:
> ne verstehe ich vollkommen haha
Keine Sorge

**2026-01-16 09:33:26** - Marvin Hammerschmidt:
> Viel Spaß beim Dreh!

**2026-01-16 09:33:34** - Julia:
> okay, danke und sorry!

**2026-01-16 09:34:12** - Marvin Hammerschmidt:
> Brauchst dich da echt nicht für entschuldigen
Ich weiß wie das ist
Habs auch gestern bei Flo nochmal angesprochen
So ganz sehen tut ers nicht aber naja wir schauen mal
Das wird schon

**2026-01-16 09:34:17** - Julia:
> ja ich weiß. es ärgert mich einfach, dass da kein verständnis da ist bzw. die kapa planung einfach nicht bedacht wird oder whatever :smile: auch mit Montag

**2026-01-16 09:34:43** - Julia:
> ja ich werd da nächste Woche auch nochmal was sagen

**2026-01-16 09:34:52** - Julia:
> danke dir :heart_hands:

**2026-01-16 09:40:13** - Marvin Hammerschmidt:
> Er meinte zu mir, dass 60 % schon sehr viel von deiner Kapa ist
Ich habe ihm dann gesagt, dass das zwar stimmt, ich aber nicht glaube, dass du wirklich 60% frei hast.
Und dazu sagte er nur, dass du bei Hisense weniger mit der Produktion zu tun hast und ihr da angeblich Dinge macht, um dir Zeit freizuschaufeln. Und wenn das noch nicht reicht, solle ich mich bei ihm melden, damit ihr da noch mehr macht

**2026-01-16 09:41:47** - Julia:
> ja machen wir auch. aber trotzdem muss ich nach Dänemark hinfliegen und heute LIDL drehen, das meinte ich :slightly_smiling_face: manche Sachen muss man ja trotzdem machen

**2026-01-16 09:42:23** - Marvin Hammerschmidt:
> Wie gesagt, ich verstehs komplett :smile:
Kapazitäten werden von außen oft falsch eingeschätzt

**2026-01-16 09:53:05** - Julia:
> das ist meine neue Nummer: 015902014144
Für die whatsapp gruppen etc :slightly_smiling_face:

**2026-01-16 09:53:19** - Marvin Hammerschmidt:
> Perfekt
Danke!

**2026-01-16 09:53:29** - Julia:
> richte es gerade ein

**2026-01-16 09:54:44** - Marvin Hammerschmidt:
> Für den Workshop: Ich hab dein Sheet um 2 Ideen ergänzt
Wir müssen im Hintergrund dann die ein oder andere Idee noch etwas ausformulieren aber das muss ja erstmal nicht auf die FOlie
Ich geb sie dann so an Jana

**2026-01-16 09:55:27** - Julia:
> 

**2026-01-16 09:55:42** - Julia:
> okay cool! schau ich mir asap an :slightly_smiling_face:

**2026-01-16 09:56:33** - Marvin Hammerschmidt:
> Absolut nichts bahnbrechendes tbh:D

**2026-01-16 16:46:39** - Julia:
> Bin wieder da :slightly_smiling_face: Du hast mich noch zu keiner Gruppe eingeladen, oder? Nur falls es nicht geklappt haben sollte

**2026-01-16 16:47:04** - Marvin Hammerschmidt:
> Servus
Ne wir kamen leider zu absolut NICHTS:D

**2026-01-16 16:47:40** - Julia:
> alles gut haha

**2026-01-16 16:47:52** - Marvin Hammerschmidt:
> Wie war der Dreh?

**2026-01-16 16:47:53** - Julia:
> aber passt alles oder was passiert?

**2026-01-16 16:48:10** - Marvin Hammerschmidt:
> Nene nichts besonderes. All good.  Gab nur viel zu tun :sweat_smile:

**2026-01-16 16:48:54** - Julia:
> sehr witzig :joy:  hat alles gut geklappt und war nicht so kalt

**2026-01-16 16:49:15** - Marvin Hammerschmidt:
> Haha geil die lidletten :sweat_smile:

**2026-01-16 16:49:40** - Julia:
> richtig schön designt :smile:

**2026-01-20 11:15:24** - Marvin Hammerschmidt:
> Hey Juli
Bist du schon wieder im Land :slightly_smiling_face:?

**2026-01-20 11:26:12** - Julia:
> Hello! Ne sind heute noch in Dänemark

**2026-01-20 11:43:35** - Marvin Hammerschmidt:
> Ah mist.
Bin etwas besorgt ob wir nicht vor dem Kickoff mit Flo nochmal ein paar Dinge irgendwie "durchgehen" nicht das er das gefühl hat es ist noch nichts passiert aber bisher warst du ja auch eigentlich wirklich durchgehend in anderen Dingen eingebunden

**2026-01-20 11:49:09** - Julia:
> wir können morgen davor sprechen. Du ich mach mir da garkeinen Stress, der soll ruhig merken, dass die Planung so nicht funktioniert

**2026-01-20 11:50:02** - Julia:
> der wollte, dass Mert gestern im Flugzeug LIDL schneidet. obs ging oder ob er wie ein T-Rex dort saß? Also sorry, ich zieh ihm schon noch den Zahn von unrealistischen Erwartungen/ Timings

**2026-01-20 11:50:11** - Julia:
> Ich weiß garnicht, für was der Termin morgen sein soll?

**2026-01-20 11:54:35** - Marvin Hammerschmidt:
> Das ist ein Mammut Projekt :smile:

Ja ich hab auch extra nachgefragt: "Rollen, Prozesse, Learnings und was wir wie standardisieren können"

**2026-01-20 11:55:56** - Julia:
> okay

**2026-01-20 11:56:15** - Julia:
> ja dann lass uns gerne morgen vormittags sprechen?

**2026-01-20 11:58:13** - Marvin Hammerschmidt:
> Können wir machen 11:30 -12:00 haben wir ja eh sixt meeting

**2026-01-20 11:58:41** - Julia:
> Ah das hab ich noch nicht im Kalender :slightly_smiling_face:

**2026-01-20 12:00:17** - Marvin Hammerschmidt:
> Ich lad dich ein
Das müssen wir mit Katharina nochmal klären :slightly_smiling_face:

**2026-01-20 12:07:59** - Marvin Hammerschmidt:
> Einladung bekommen?

**2026-01-20 12:12:55** - Julia:
> yes! danke

**2026-01-20 13:00:10** - Julia:
> btw: würdest du meine neue Nummer in die BCC Creative Whatsapp Gruppe reinnehmen?

**2026-01-20 13:07:24** - Marvin Hammerschmidt:
> done :slightly_smiling_face:

**2026-01-20 13:11:34** - Julia:
> Danke!

**2026-01-20 21:42:20** - Julia:
> Für dich als Info: wir haben den Anschlussflug verpasst weil wir Verspätung hatten und sind jetzt in Amsterdam. der nächste Rückflug ist morgen Vormittag, kann also wieder nicht am Meeting um 11.30 Uhr teilnehmen. Lieben wir :face_exhaling:

**2026-01-20 21:42:57** - Marvin Hammerschmidt:
> Ach du scheiße. Ihr armen :flushed:

**2026-01-20 21:43:50** - Marvin Hammerschmidt:
> Ja alles gut. Ich mach das. Das wird Flo ja verstehen denke ich 
Habt ihr n Hotel gefunden? 

**2026-01-21 07:16:09** - Julia:
> Danke dir! 
Ja hat alles gut geklappt :) wenigstens das haha

**2026-01-21 13:20:21** - Julia:
> Hi Marvin! Ich wäre jetzt am Laptop

**2026-01-21 13:20:25** - Julia:
> Falls du etwas besprechen willst

**2026-01-21 13:20:43** - Marvin Hammerschmidt:
> Hey
Juli
Lass mich kurz was fertig mache, dann ruf ich dich an

**2026-01-21 13:20:54** - Julia:
> Okay

**2026-01-21 13:34:50** - Marvin Hammerschmidt:
> 

**2026-01-22 15:32:33** - Julia:
> Hello! Sollen wir morgen nach dem Check-In zum projektplan sprechen?

**2026-01-22 15:32:56** - Marvin Hammerschmidt:
> Jana sollte uns eigentloch vor dem Meeting was einstellen

**2026-01-22 15:33:06** - Marvin Hammerschmidt:
> hat sie leider nicht
Hab aber gleich ein gespräch mit ihr

**2026-01-22 15:34:15** - Marvin Hammerschmidt:
> Falls sie mir das einrichtet....
Also ja machen wir, hab mir aber einen überblick verschafft und gesehen das wir Jana brauchen :slightly_smiling_face:

**2026-01-22 15:34:53** - Julia:
> okay

**2026-01-22 15:34:59** - Julia:
> alles klar

**2026-01-22 15:35:06** - Marvin Hammerschmidt:
> Alles sehr ärgerlich :smile:

**2026-01-22 15:35:30** - Julia:
> ich bin morgen ab 10 Uhr ca. am laptop, davor hab ich physio

**2026-01-22 15:35:36** - Marvin Hammerschmidt:
> All good Dann danach :slightly_smiling_face:

**2026-01-22 15:45:49** - Julia:
> ja wie gesagt von 10 irgendwas -11 garkein Stress

**2026-01-22 15:45:59** - Julia:
> Oder danach, je nachdem was Jana einstellt haha

**2026-01-22 15:46:09** - Marvin Hammerschmidt:
> Wir können das auch Montag machen
Nimm dir deinen ausgleich

**2026-01-22 15:47:37** - Julia:
> Mir ist beides Recht. Ich muss da nur etwas dagegen reden, weil er meine Anfrage ja komplett ignoriert und ich seh das nicht ein :smile: irgendwann reichts auch. Sowieso gestern wieder bis 20 Uhr

**2026-01-22 15:48:02** - Marvin Hammerschmidt:
> Ich kenn das
ALl good
Ich möchte dich da nicht zusätzlich beladen!!!

**2026-01-22 15:48:25** - Marvin Hammerschmidt:
> Würde generell nochmal mit Flo sprechen weil ich den Sinn hinter über 10 STD auto fahren (wenns gut läuft) um 5 Folien vorzutragen nicht sehe

**2026-01-23 08:46:50** - Julia:
> Hello! Es gibt noch keinen Termin von Jana oder? :sweat_smile:

**2026-01-23 08:47:12** - Julia:
> Ja. Der Sinn würde mich da auch interessieren 

**2026-01-23 08:47:16** - Marvin Hammerschmidt:
> Good morning

Nop
Habs ihr gerad auch nochmal gesagt

**2026-01-23 08:48:15** - Marvin Hammerschmidt:
> Gibt da generell gerad einige Probleme
SIXT ist sehr unzufrieden damit wie unregelmäßig Jana antwortet etc.

**2026-01-23 08:48:53** - Julia:
> Ja hab ich mir schon gedacht. Hab eben alle Nachrichten durchgelesen 

**2026-01-23 08:49:20** - Marvin Hammerschmidt:
> Sie haben mich mehrfach angerufen um sich zu beschweren aber ich bekomme Jana einfach nicht in Termine
Das ist echt richtig kacke

**2026-01-23 08:49:42** - Julia:
> Aber was sagt sie dazu? Oder ignoriert sie es? 

**2026-01-23 08:50:10** - Julia:
> Das kann man einfach nicht machen 

**2026-01-23 08:50:13** - Marvin Hammerschmidt:
> Gibt immer nen Grund weswegen sie jetzt gerade nicht sprechen kann

**2026-01-23 08:50:28** - Julia:
> Ahja oke 

**2026-01-23 08:50:32** - Julia:
> :no_mouth:

**2026-01-23 09:49:50** - Marvin Hammerschmidt:
> Jetzt haben wir was drin

**2026-01-23 09:49:52** - Marvin Hammerschmidt:
> 10:15

**2026-01-23 09:52:24** - Julia:
> okay ich beeile mich 

**2026-01-23 09:52:56** - Marvin Hammerschmidt:
> Sorry dass das für Stress sorgt. Mir sind die Hände gebunden ich muss nehmen was ich kriegen kann :sob:

**2026-01-23 09:54:21** - Julia:
> Alles gut. Macht Sinn :) 

**2026-01-23 09:54:47** - Julia:
> Evtl bin ich 5 min später dran aber ich geb dir nochmal Bescheid 

**2026-01-23 09:55:07** - Marvin Hammerschmidt:
> Das ist kein Problem 

**2026-01-23 09:55:12** - Marvin Hammerschmidt:
> Müssen uns ja eh erst sortieren 

**2026-01-23 10:12:26** - Julia:
> oke, brauch noch paar Minuten! 

**2026-01-23 10:59:50** - Julia:
> liebs auch einfach

**2026-01-23 11:00:17** - Julia:
> Bin im Pitch mit drin, aber bekomme seit 2 Wochen keine Infos mehr, was die Kampagne ist oÄ. Aber den Content dazu musste ich erstellen :smile:

**2026-01-23 11:00:20** - Julia:
> wegen montag

**2026-01-23 11:01:02** - Marvin Hammerschmidt:
> Uf

**2026-01-26 10:55:58** - Marvin Hammerschmidt:
> Guten Morgen :slightly_smiling_face:
Wie sehr bist du heute eingebunden?

**2026-01-26 11:04:39** - Julia:
> Hello! Mit 2 Std. Pitch schon etwas :smile: Aber können gerne um 11.30 sprechen?

**2026-01-26 11:04:51** - Marvin Hammerschmidt:
> Machen wir :slightly_smiling_face:

**2026-01-26 11:24:05** - Julia:
> Ich ruf dich gleich an, sobald der Call rum ist

**2026-01-26 11:24:16** - Marvin Hammerschmidt:
> all good
Kein stress

**2026-01-26 11:37:29** - Marvin Hammerschmidt:
> 

**2026-01-26 12:03:40** - Julia:
> Ah ganz vergessen!

**2026-01-26 12:03:56** - Julia:
> hattest du noch mit Flo wegen Decathlon gesprochen?

**2026-01-26 12:04:02** - Julia:
> Das kommt ja heute auch noch :face_with_peeking_eye:

**2026-01-26 12:04:40** - Marvin Hammerschmidt:
> Ja
Also ich buch mir n Hotel und werd da schlafen
Aber mit muss ich

Feedback zu meinem Video hab ich noch nicht bekommen

**2026-01-26 12:05:11** - Julia:
> Ah okay, aber das ist ja schon mal gut! Bzw. besser als die Hin-und Herfahrerei

**2026-01-26 12:06:33** - Marvin Hammerschmidt:
> definitiv

**2026-01-26 12:44:12** - Julia:
> Im Plan "Fahrer" sind die gemeint, die die Sixt Autos dann in den Videos fahren..?

**2026-01-26 12:44:25** - Julia:
> oder wer soll das sein?

**2026-01-26 12:45:53** - Marvin Hammerschmidt:
> Würd ich raus nehmen. Das ist das Problem der Produktionsfirma 

**2026-01-26 12:46:01** - Julia:
> okay

**2026-01-26 12:46:09** - Julia:
> aber sind das nicht die Creator dann?

**2026-01-26 12:46:15** - Julia:
> verstehe den Punkt nicht ganz

**2026-01-26 12:46:22** - Marvin Hammerschmidt:
> Creator Sind ja an sich die Teilnehmer oder?

**2026-01-26 12:46:26** - Julia:
> ja

**2026-01-26 12:46:32** - Marvin Hammerschmidt:
> Und da würde ich auch eher actor sagen als creator 

**2026-01-26 12:46:41** - Marvin Hammerschmidt:
> Die sollten ja nicht bekannt sein 

**2026-01-26 12:46:48** - Marvin Hammerschmidt:
> Ja nimm einfach raus. Ist seltsam 

**2026-01-26 12:47:15** - Julia:
> passt

**2026-01-26 15:52:46** - Julia:
> Mir kam grad noch ein Gedanke für die sixt content reihen

**2026-01-26 15:53:06** - Marvin Hammerschmidt:
> Ah cool
Erzähl

**2026-01-26 15:53:26** - Julia:
> ihr habt ja dieses Video gemacht mit der DB

**2026-01-26 15:53:39** - Marvin Hammerschmidt:
> Das war JVM aber ja

**2026-01-26 15:55:20** - Julia:
> Ah schade

**2026-01-26 15:55:44** - Marvin Hammerschmidt:
> Egal
Erzähl trotzdem :smile: muss ja nicht wichtig dafür sein

**2026-01-26 15:57:53** - Julia:
> Idee 1: DB Abklatsch: SIXT Serie mit Mitarbeitenden
Idee 2: Herzblatt/ Speed Dating in Auto

**2026-01-26 15:59:48** - Marvin Hammerschmidt:
> Hab tatsächlich beides schonmal vorgeschlagen :smile:
Denke wenn wir das nochmal bringen wollen müssen wir das nochmal expiziter amchen

Dating show hab ich sogars ausgearbeitet aber hat flo nicht gefallen

**2026-01-26 16:00:38** - Julia:
> :no_mouth:

**2026-01-26 16:00:55** - Julia:
> Okay okay

**2026-01-26 16:01:11** - Julia:
> also Dating und Valentines Day wäre natürlich sehr passend

**2026-01-26 16:01:29** - Marvin Hammerschmidt:
> Können das gern nochmal versuchen

**2026-01-26 16:01:33** - Marvin Hammerschmidt:
> Ich fands ja auch gut

**2026-01-26 16:01:39** - Marvin Hammerschmidt:
> Und ich glaube sixt würds auchg efallen

**2026-01-26 16:02:01** - Julia:
> okay :smile: ich mach jetzt erstmal den Projektplan fertig

**2026-01-26 16:02:08** - Julia:
> LIDL war leider nicht gut

**2026-01-26 16:02:17** - Marvin Hammerschmidt:
> war nicht gut?

**2026-01-26 16:02:20** - Marvin Hammerschmidt:
> 

**2026-01-26 17:39:57** - Julia:
> So schau gerne mal in den Projektplan, obs für dich so Sinn ergibt

**2026-01-26 17:40:03** - Julia:
> Timing ist SO KNAPP

**2026-01-26 17:40:31** - Marvin Hammerschmidt:
> Dann lass uns ne 2. Version machen mit ner zeitplanung die machbarer ist 

**2026-01-26 17:40:51** - Marvin Hammerschmidt:
> Es ist halt wieder viel auf einmal
Dieser Workshop schman auch. Das werden wir ja auch umsetzen müssen 

**2026-01-26 17:41:36** - Marvin Hammerschmidt:
> Die stellen wir dann vor
Wenn sie dann sagen „ne muss schneller“ dann zeigen sie den tighten 

**2026-01-26 17:41:45** - Julia:
> ja können wir auvh

**2026-01-26 17:42:16** - Marvin Hammerschmidt:
> Lass uns da morgen drüber sprechen ich hab heut keinen Nerv mehr haha sorry 


**2026-01-26 17:42:27** - Marvin Hammerschmidt:
> Schaue es mir aber gleich sxhonmal an :)

**2026-01-26 17:42:35** - Julia:
> alles gut :smile: mache jetzt auch mal Decathlon

**2026-01-26 17:43:08** - Marvin Hammerschmidt:
> Inhalt scheinbar nicht so wichtig. Fokus eher auf klare Betonungen 

**2026-01-26 17:43:35** - Julia:
> gut, dann mach ich meine eigene Präsentation :smile:

**2026-01-26 17:43:49** - Julia:
> bau noch kurz eigene Slides ups :rolling_on_the_floor_laughing:

**2026-01-26 17:43:59** - Marvin Hammerschmidt:
> :joy:

**2026-01-26 17:51:13** - Julia:
> nicht wundern, das kann man alles aufklappen. würde es aber so gruppiert lassen, sonst erschlägt es einen

**2026-01-26 17:51:38** - Marvin Hammerschmidt:
> Ja sieht gut aus so 

**2026-01-27 09:31:23** - Julia:
> Guten Morgen!

**2026-01-27 09:31:30** - Julia:
> Können wir unser Meeting um 11.30 starten?

**2026-01-27 09:31:37** - Marvin Hammerschmidt:
> Good morning :slightly_smiling_face:
Machen wir

**2026-01-27 09:31:42** - Julia:
> Danke dir :slightly_smiling_face:

**2026-01-27 12:13:09** - Julia:
> ich hab Marie Idee 2 mal geschickt für weitere Ideen7/ Skripte "Mittelweg von matcha und Haftbefehl"

**2026-01-27 12:13:55** - Marvin Hammerschmidt:
> &gt; gute idee

**2026-01-27 12:17:19** - Julia:
> hui

**2026-01-27 12:17:28** - Julia:
> ist da immer so eine passiv aggressive stimmung?

**2026-01-27 12:17:55** - Marvin Hammerschmidt:
> Mir gegenüber selten aber gegen flo eig immer ja:D

**2026-01-27 12:18:39** - Marvin Hammerschmidt:
> drüber stehen

**2026-01-27 12:20:09** - Julia:
> 

**2026-01-27 12:25:34** - Marvin Hammerschmidt:
> Ne ist auch eig unsinn
Liegt aber daran das das workshop ding ihre aufgabe ist

**2026-01-27 12:25:38** - Marvin Hammerschmidt:
> und wir nur zuarbeiten

**2026-01-27 12:25:39** - Marvin Hammerschmidt:
> eigentlich

**2026-01-27 12:27:19** - Julia:
> okay

**2026-01-27 15:36:03** - Julia:
> Marie hat die Ideen ausformuliert --&gt; Gibt es die Autos alle bei SIXT? Da hab ich keine Ahnung und sie hatte es nicht überprüft. Weißt du das?

**2026-01-27 15:37:12** - Marvin Hammerschmidt:
> Schaue mir das gleich an
Hab hier gerad etwas baby struggle

Bin immernoch kein Fan der Art und Weise tbh

**2026-01-27 15:37:21** - Marvin Hammerschmidt:
> Hab sonst zu allem schonmal ein bisschen was geschrieben

**2026-01-27 15:38:29** - Marvin Hammerschmidt:
> außer das Prank ding
Da fällt mir bisher nichts zu sein

**2026-01-27 15:38:46** - Julia:
> oh nein, aber alles okay?

**2026-01-27 15:38:55** - Julia:
> was meinst du welche Art und Weise?

**2026-01-27 15:39:19** - Julia:
> Okay sehr gut, schau ich mir dann auch gleich an. Muss noch was anderes für Flo machen :no_mouth:

**2026-01-27 15:39:34** - Marvin Hammerschmidt:
> Joa das weiß man gerad nicht so genau:D
Das hemmt auch gerad etwas meine Gedanken

Das mit dem Singen etc
ABer ich schau da noch drüber und denk nach:)

**2026-01-27 15:39:36** - Marvin Hammerschmidt:
> natürlich :smile:

**2026-01-27 15:40:22** - Julia:
> Oh nein, ja dann nimm dich bitte raus!

**2026-01-27 15:40:31** - Marvin Hammerschmidt:
> all good

**2026-01-27 17:19:30** - Marvin Hammerschmidt:
> mach dir keine sorge wegen dem "möglichst viel" das ist ecjht smarter und vor sixt vortragen ist recht angenehm tbh

**2026-01-28 10:50:57** - Julia:
> Hello! Hast du eine Idee wer der Moderator bei Carpool Karaoke sein könnte?

**2026-01-28 10:51:26** - Marvin Hammerschmidt:
> Hab einen rausgesucht den ich extrem lustig finde <https://www.instagram.com/zachjustice/?hl=en>

**2026-01-28 10:51:28** - Marvin Hammerschmidt:
> zach justice

**2026-01-28 10:51:56** - Julia:
> Ah okay, der auch als Moderator. dachte nur für den roast aber passt

**2026-01-28 10:51:59** - Marvin Hammerschmidt:
> Lass uns gern nach dem SIXT call nochmal kurz quatschen
Evtl finden wir für das ai video und die personalities zusammen ne bessere lösung

**2026-01-28 10:52:08** - Marvin Hammerschmidt:
> nene find den generell gut da der sehr lustig und spontan ist

**2026-01-28 10:52:12** - Marvin Hammerschmidt:
> das bringt "sixtyness" rein

**2026-01-28 10:52:47** - Julia:
> du ich bin noch nicht mal so weit. ich bin bei der videoerstellung für Love is blind seit 2 std. also wie gesagt das dauert :smile:

**2026-01-28 10:53:23** - Marvin Hammerschmidt:
> für den Kunden wirds ok sein wenn wir da keine videos haben
Das ist wieder so ne extrameile

**2026-01-28 10:53:39** - Marvin Hammerschmidt:
> woran harkts denn da?
Soll ich mich da auch dran versuchen?

**2026-01-28 10:54:49** - Julia:
> 

**2026-01-28 10:55:18** - Marvin Hammerschmidt:
> Zusammenschneiden einfach an basti geben
Dafür ist er da :slightly_smiling_face:

**2026-01-28 10:55:24** - Julia:
> oder so!

**2026-01-28 10:56:10** - Marvin Hammerschmidt:
> Der mpsste auch kapazitäten haben
Also wenn du da was hast wo er helfen kann bezieh ihn gern mit ein

**2026-01-28 11:14:51** - Julia:
> kurze Frage: bisher habt ihr auch noch kein proforma Asana Board?

**2026-01-28 11:15:22** - Marvin Hammerschmidt:
> <https://app.asana.com/1/1199360402832734/project/1211046662010247/list/1211047329988574>

**2026-01-28 11:15:39** - Marvin Hammerschmidt:
> doch aber ich persönlich nutze es kaum um ehrlich zu sein
Ich organisier mich mit der sixt check in liste

**2026-01-28 11:15:49** - Marvin Hammerschmidt:
> <https://docs.google.com/spreadsheets/d/1nvQxh5qkGXqmgdXObbcezfEAk8IOAGEf2L0PU_DXLW8/edit?usp=sharing>

**2026-01-28 11:16:41** - Julia:
> okay ja da hab ich keinen Zugriff

**2026-01-28 11:16:51** - Julia:
> okay verstehe

**2026-01-28 11:16:58** - Marvin Hammerschmidt:
> auf asana?

**2026-01-28 11:16:59** - Marvin Hammerschmidt:
> moment

**2026-01-28 11:17:03** - Julia:
> ja ich erstell die Tasks für Basti dann mal so

**2026-01-28 11:17:35** - Marvin Hammerschmidt:
> Hab dir eine Einladung geschickt
Dachte Jana hat das bereits gemacht

**2026-01-28 11:17:47** - Julia:
> ne, hab sie auch schon 2 mal gefragt

**2026-01-28 11:18:00** - Julia:
> dankee habs!

**2026-01-28 11:19:24** - Marvin Hammerschmidt:
> Große Klasse :smile:

**2026-01-28 11:23:14** - Julia:
> und der verlinkte Ordner in Drive ist leer :no_mouth:

**2026-01-28 11:23:23** - Julia:
> oder ich kanns auch immer noch nicht sehen

**2026-01-28 11:23:34** - Marvin Hammerschmidt:
> Da hat Basti was geändert
Sekunde ich such den neuen

**2026-01-28 11:23:40** - Marvin Hammerschmidt:
> da gehts um generell alles was sixt angeht oder?

**2026-01-28 11:23:41** - Julia:
> okay dankee

**2026-01-28 11:23:57** - Julia:
> ja genau, ich muss ihm ja die ganzen snippets ablegen

**2026-01-28 11:24:11** - Marvin Hammerschmidt:
> <https://drive.google.com/drive/folders/19lvNlFPlsvOD0Yi0ZzJfIWp22JjbkeEY?usp=sharing>

**2026-01-28 11:24:26** - Marvin Hammerschmidt:
> Sonst auf <http://Frame.io|Frame.io>

**2026-01-28 11:56:09** - Julia:
> lass uns gleich noch sprechen, schreibe grad mit Flo

**2026-01-28 11:59:49** - Marvin Hammerschmidt:
> Yes

**2026-01-28 12:00:27** - Marvin Hammerschmidt:
> rufe dich direkt nach dem call an

**2026-01-28 12:15:47** - Marvin Hammerschmidt:
> 

**2026-01-28 12:39:46** - Julia:
> gibt es irgendeinen Promi den SIXT mega feiert? oder influencer?

**2026-01-28 12:40:21** - Marvin Hammerschmidt:
> Puh
Also  so Leute wie Opa werner undso aber das ist halt zu cringe

**2026-01-28 12:43:17** - Marvin Hammerschmidt:
> Von Romina...

**2026-01-28 12:43:27** - Marvin Hammerschmidt:
> Also wir sollten bei Flo echt pushen das Julia da helfen sollte

**2026-01-28 12:45:01** - Marvin Hammerschmidt:
> Ich fürchte das wir da mal wieder zu viel auf einmal versprechen

**2026-01-28 12:45:34** - Julia:
> Ah cool

**2026-01-28 12:46:14** - Julia:
> also ich sags dir ehrlich: ich mach das so nicht weiter :smile:

**2026-01-28 12:46:52** - Marvin Hammerschmidt:
> Wir sprechen da gleich zu 3. vernünftig drüber

**2026-01-28 12:47:01** - Julia:
> Ja

**2026-01-28 12:47:45** - Marvin Hammerschmidt:
> Ich kann dann halt keinen Vaterschaftsurlaub nehmen
ist wie es ist
Ich brauche nur in dem ersten Monat wenigstens ein paar "downtimes" damit ich dinge auch mal abends erledigen kann und nicht direkt auf abruf
Dann bekommen wir das irgendwie hin

**2026-01-28 12:48:12** - Julia:
> Ne als Marvin sorry

**2026-01-28 12:48:16** - Julia:
> Auf garkeinen Fall

**2026-01-28 12:48:32** - Julia:
> Flo soll Leute einstellen die ihre Expertise ausleben können/ dürfen fertig

**2026-01-28 12:48:44** - Marvin Hammerschmidt:
> All good
Ist nicht schlimm
Hab das schon einkalkuliert

**2026-01-28 12:48:53** - Julia:
> Ja aber das macht doch keinen Sinn?

**2026-01-28 12:49:36** - Marvin Hammerschmidt:
> Er wird dir niemanden zur Seite stellen
Und selbst zu Zweit wird das schon extrem schwierig

**2026-01-28 12:49:53** - Marvin Hammerschmidt:
> Es ist dem Kunden aber extrem wichtig daher müssen wir das irgendwie hinbekommen

**2026-01-28 12:50:41** - Julia:
> Ja

**2026-01-28 12:50:49** - Marvin Hammerschmidt:
> Was sollen wir jetzt bei Flo anbringen?
Wir haben nur 30 min
Lass uns da einen genauen schlachtplan aufsetzen und die "talking points" besprechen

**2026-01-28 12:52:32** - Julia:
> • Anything or nothing --&gt; entweder mache ich das komplett, aber dann bin ich bei allen anderen Themen raus das SIXT betrifft oder Übergabe an Julia H.
• Werkstudentin --&gt; für was? Wir brauchen erfahrene Leute, niemanden den wir ein lernen müssen

**2026-01-28 12:53:31** - Marvin Hammerschmidt:
> • Content Workshop von Instagram zieht einiges an mehrarbeit mit sich. Wir müssen den Content ja auch umsetzen und es handelt sich hierbei ja nicht um 0815 Conent den man mal schnell abdreht

**2026-01-28 12:53:40** - Julia:
> ich kann und werde dich nicht covern mit Themen die ich sowieso nicht kann/ weiß + daily business + Kampagne

**2026-01-28 12:53:49** - Julia:
> ganz genau

**2026-01-28 12:54:09** - Marvin Hammerschmidt:
> Da wird er sagen " ja warum hat marvin dir das nicht gezeigt"
Darauf müssen wir halt vorbereitet sein

**2026-01-28 12:54:58** - Marvin Hammerschmidt:
> Aber siehst du
Es läuft darauf hinaus dass das nicht klappt mit dem Vaterschaftsurlaub:D
Das ist auch oK
Wie gesagt wir brauchen da nur ne "hybride" Lösung das ich einfach mir das freier einteilen kann

**2026-01-28 12:57:36** - Julia:
> Punkt 1:

**2026-01-28 12:59:25** - Julia:
> 

**2026-01-28 13:03:12** - Marvin Hammerschmidt:
> Willkommen im Klub haha
Also ich bin froh dass du da bist!!:D

Er wird das an uns weiter geben
Für ihn ist das alles immer "nicht so schwer" das ist die problematik dahinter
Der Kunde hat aber schon nen hohen Anspruch und durchaus auch ne krasse Frequenz was den Input angeht (hast du ja gehört)
Wir bräuchten wirklich eine Julia die das organisatorische übernimmt dann du den Kreativen Part und ich den Social expert/Kreativen teil.
Das wird der Retainer halt nicht hergeben ABER das ist dann einfach nicht gut verhandelt
Ohne diesen Instagram Workshop wäre das ja auch jetzt machbar
Aber das wir für Insta noch mit Content generieren müssen ist halt einfach NOCH mehr arbeit sowohl in konzeption als auch Ausführung

**2026-01-28 13:03:43** - Julia:
> total

**2026-01-28 13:04:14** - Julia:
> also in Summe ist es ja so:
Ein Kanal on top und du für einen bestimmten Teil down --> das geht nicht :D

**2026-01-28 13:04:40** - Julia:
> muss kurz mit dem hund raus, bis gleich!

**2026-01-28 13:08:36** - Marvin Hammerschmidt:
> 

**2026-01-28 13:42:12** - Julia:
> süß

**2026-01-28 14:23:02** - Marvin Hammerschmidt:
> Das lief dann doch mal ganz gut


Also Julia mit dabei wäre massiv

**2026-01-28 14:23:25** - Julia:
> ja wirklich!

**2026-01-28 14:23:48** - Julia:
> total, wie gesagt die hat schon sooo viele Produktionen geleitet, da sind meine ein Witz dagegen und dann ist der Block einfach weg

**2026-01-28 14:24:46** - Marvin Hammerschmidt:
> Ja safe
Auf sie kann man sich zu 100% verlassen dass wenn sie das angeht das auch laufen wird
Das bringen wir auch gleich beim SIXT meeting an das wir da neue Kapazitäten für haben und eine absolute top organisatorin mit an board haben

**2026-01-28 14:26:27** - Julia:
> genau

**2026-01-28 14:26:40** - Julia:
> Oh je, Jana hat die Präsentation ja ganz anders aufgebaut :smile:

**2026-01-28 18:02:42** - Julia:
> :joy:

**2026-01-28 18:02:52** - Julia:
> Was zur Hölle, soll das für eine Sprache sein

**2026-01-28 18:03:07** - Marvin Hammerschmidt:
> aaahahahahaha

**2026-01-28 18:03:17** - Marvin Hammerschmidt:
> fast niederländisch:D

**2026-01-28 18:03:40** - Julia:
> jaa

**2026-01-28 18:03:47** - Julia:
> deutsch kann die AI einfach noch nicht :smile:

**2026-01-28 18:35:21** - Julia:
> So hier der Status Quo. Genauso hatten wir es damals bei Porsche. Siehst ja was noch frei ist bei den Content INhalten. Textlich gerne auch noch anpassen was dir fehlt etc.
Würde dann bei der finalen Version die Videos einbauen (Basti ist dran), macht jetzt mit dem Hin und Her schicken von Präsis keinen Sinn :slightly_smiling_face:

**2026-01-28 18:35:26** - Julia:
> happy feierabend!

**2026-01-28 18:35:42** - Julia:
> hier noch die Videos die basti noch bearbeitet: <https://drive.google.com/drive/folders/1ipOCItOdJLWuxEmdd24BM21TNdt5McKR>

**2026-01-28 18:36:30** - Julia:
> würde Jana gegen mittags gerne die Präsi schicken, damit sie diese Slides in ihre Version baut bzw. anpasst. Sonst macht die Präsi keinen Sinn

**2026-01-28 18:37:47** - Marvin Hammerschmidt:
> Danke dir! Schau ich mir gleich an. Muss nur eben kochen :) 

**2026-01-29 09:36:41** - Julia:
> Guten Morgen

**2026-01-29 09:37:03** - Marvin Hammerschmidt:
> Guten Morgen

**2026-01-29 09:47:40** - Julia:
> Konntest du dir schon die Präsi anschauen?

**2026-01-29 09:48:16** - Marvin Hammerschmidt:
> Hab noch was neues  reinbekommen
Gib mir 10 min dann schau ichs mir an
Sorry

**2026-01-29 09:48:31** - Julia:
> Ja alles gut, kein Stress!

**2026-01-29 09:57:05** - Marvin Hammerschmidt:
> Folie 12 muss glaub ich raus

Sonst passt das oder?

**2026-01-29 09:57:32** - Marvin Hammerschmidt:
> Er wollte halt mehr ausformuliert haben, tragen wir dass dann eher vor ? Also z.b. beim ai prank oder auch beim Love is blind

**2026-01-29 09:57:45** - Julia:
> moment ich schau kurz

**2026-01-29 09:57:49** - Marvin Hammerschmidt:
> By the way: Ai prank fällt mir absolut nichts ein
Ich hab keine Ahnung irgendwie krieg ich das nicht hin gerade...

**2026-01-29 09:58:56** - Julia:
> Das interaktive Quiz? Also sollen wir nur die Variante mit RSA nehmen?

Ja genau, würde da viel zu erzählen. Also die Beispiele dann einfach sagen. Können wir ja easy in die Besprechungsnotizen packen

**2026-01-29 09:59:16** - Marvin Hammerschmidt:
> Ne da ist doch eine slide doppelt oder nicht? 

**2026-01-29 09:59:20** - Julia:
> Du kannst auch gerne einfach Kommentare hinzufügen und ich packe die restlichen Sachen noch rein

**2026-01-29 09:59:54** - Julia:
> Ne, habs nur noch nicht visuell angepasst

**2026-01-29 10:00:13** - Julia:
> mir auch noch nicht. aber setze ich mich jetzt dran :smile:

**2026-01-29 10:00:20** - Marvin Hammerschmidt:
> Genau. Bei dem oberen steht ja der Text von dem Persönlichkeiten Video 

**2026-01-29 10:00:41** - Julia:
> ahhhh

**2026-01-29 10:00:50** - Julia:
> ist mir durchgerutscht

**2026-01-29 10:00:52** - Julia:
> danke!

**2026-01-29 10:01:00** - Marvin Hammerschmidt:
> Gibt von meiner Seite aus sonst ehrlicherweise nichts zu kommentieren 

Denke das ist fine so:) 

**2026-01-29 10:02:04** - Marvin Hammerschmidt:
> Muss leider noch einiges fürs Fat ice Race machen.  
Dann hat Romina gestern gesagt sie hat das Gefühl Katharina ist mit dem content generell unzufrieden. Da hab ich heute auch emergency Meetings und muss mal wieder alles umstoßen :sob:

**2026-01-29 10:02:17** - Julia:
> alright

**2026-01-29 10:02:20** - Julia:
> Oh nein, Mist!

**2026-01-29 10:02:36** - Julia:
> Ja klar, mach. Ich kümmere mich um die Slides

**2026-01-29 10:02:41** - Marvin Hammerschmidt:
> UND ich brauche noch schnell was für search ads da wir ja nächste Woche kaum Zeit haben :sob:

**2026-01-29 10:03:01** - Marvin Hammerschmidt:
> Wenn du partiell was brauchst Tell me ! 


**2026-01-29 10:03:10** - Marvin Hammerschmidt:
> Hab eig tu allem was geschrieben außer ai prank 

**2026-01-29 10:04:31** - Julia:
> obs stressig ist :smile:

**2026-01-29 10:04:38** - Julia:
> alles gut, ich schau mal und schicks dir dann wieder

**2026-01-29 10:04:40** - Julia:
> danke!

**2026-01-29 10:04:43** - Marvin Hammerschmidt:
> Quaaaatsch :sweat_smile:

**2026-01-29 10:42:22** - Julia:
> Fällt dir eine Persönlichkeit ein, die krass wäre für den Carpool Roast mit Zach?

**2026-01-29 10:43:17** - Marvin Hammerschmidt:
> Hm
Am besten eine polarisierende Person aus den USA
let me think

**2026-01-29 10:44:43** - Julia:
> für den normalen Carpool Talk hätte ich Bill Kaulitz gewählt. Ist ja auch in USA bekannt.
Aber für den Roast wollte ich gerne noch jemand krasseren, genau

**2026-01-29 10:45:02** - Marvin Hammerschmidt:
> Ach der geht auch dafür tbh
Der polarisiert und ist lustig

**2026-01-29 10:45:05** - Marvin Hammerschmidt:
> Ich schaue

**2026-01-29 10:45:26** - Julia:
> okay

**2026-01-29 10:45:33** - Marvin Hammerschmidt:
> Eigentlich unsinnig die ganze idee
Das ist viel zu teuer für so ein normales Format:D

**2026-01-29 10:45:48** - Marvin Hammerschmidt:
> Also für highlights ja aber niemals würden wir so viel Geld für sowas ausgeben

**2026-01-29 10:46:04** - Julia:
> Marvin!

**2026-01-29 10:46:07** - Julia:
> Sell the dream!!

**2026-01-29 10:46:10** - Julia:
> :smile:

**2026-01-29 10:46:19** - Marvin Hammerschmidt:
> Alles klar Flo :smile:

**2026-01-29 10:46:29** - Julia:
> Ja, hab's als Monthly rein

**2026-01-29 10:50:15** - Marvin Hammerschmidt:
> Vielleicht einen altern kinderstar? Könnte generell spannend sein
z.B. Josh Peck von Drake and Josh
Der macht jetzt auch noch recht viel Social media, ist ganz lustig aber bietet auch angriffsfläche

**2026-01-29 10:51:03** - Julia:
> Jaa nehm ich mit auf

**2026-01-29 10:51:09** - Julia:
> danke!

**2026-01-29 11:07:02** - Julia:
> (Flo kennt das Video von LIB schon)

**2026-01-29 11:07:22** - Julia:
> und ist ja leider auch nur paar Sekunden, dann wird es verhauen

**2026-01-29 12:44:28** - Julia:
> hatte für Pranked jetzt noch eine andere Idee

**2026-01-29 12:45:19** - Marvin Hammerschmidt:
> Das mit dem passiv aggressiv stell ich mir lustig vor :smile:

**2026-01-29 12:45:35** - Julia:
> Ja ich auch :smile:

**2026-01-29 13:27:47** - Marvin Hammerschmidt:
> :face_palm:

**2026-01-29 13:28:34** - Julia:
> puh

**2026-01-29 13:39:11** - Julia:
> 

**2026-01-29 14:24:53** - Marvin Hammerschmidt:
> Ohje ich hoffe es geht ihm gut

Ja all fine!

**2026-01-29 15:51:10** - Marvin Hammerschmidt:
> Flo will das jeder seinen Teil vorstellt

Wie teilen wirs auf?

**2026-01-29 15:51:57** - Marvin Hammerschmidt:
> Wusste nicht das er direkt in die Vortragssituation will....

**2026-01-29 15:52:03** - Julia:
> das wusste ich auch nicht

**2026-01-29 15:52:12** - Julia:
> denke das geht auch nicht, weil Jana sicher die Präsi noch nicht fertig hat

**2026-01-29 15:52:25** - Marvin Hammerschmidt:
> Na das wird spannend

**2026-01-29 15:53:26** - Julia:
> Entweder abwechselnd oder ich stell alles vor oder du stellst "deine" ideen vor:
• beat the rsa
• AI tipps
• ride n roast
• Kesslers Knigge

**2026-01-29 15:53:28** - Julia:
> you decide

**2026-01-29 15:54:43** - Marvin Hammerschmidt:
> Mir ist auch völlig egal
Ist ja eh mainly deins und so wirds ja auch vor ort sein  dann passt die Aufteilung so

**2026-01-29 15:54:57** - Julia:
> okay. dann du deine?

**2026-01-29 15:55:02** - Marvin Hammerschmidt:
> • beat the rsa
• AI tipps
• ride n roast
• Kesslers Knigge


**2026-01-29 15:55:07** - Julia:
> passt!

**2026-01-29 15:55:23** - Marvin Hammerschmidt:
> Halt natürlich hart ohne die Präsi zu kennen :smile:

**2026-01-29 15:55:24** - Julia:
> liebs ja, dass man keine Sekunde Zeit hat irgendwas zu üben :smile:

**2026-01-29 15:55:28** - Marvin Hammerschmidt:
> Ja ist top

**2026-01-29 15:55:47** - Marvin Hammerschmidt:
> Es ist halt auch leider einfach nicht das einzige Thema was es aktuell gibt:D

**2026-01-29 15:56:01** - Marvin Hammerschmidt:
> Hoffen wir mal es passt ihm so

**2026-01-29 15:58:12** - Julia:
> ne

**2026-01-29 15:58:39** - Julia:
> er wollte eigentlich auch, dass ich morgen Decathlon vor ihm nochmal präsentiere mit meiner Verbesserung – i doubt it :smile:

**2026-01-29 15:59:04** - Marvin Hammerschmidt:
> Ach krass
Hat er dir das so nochmal gesagt?
Hab seine Memos nicht ganz gehört
Nicht das ich das auch machen sollte :smile:

**2026-01-29 15:59:12** - Marvin Hammerschmidt:
> Ja eng auf jeden Fall:D

**2026-01-29 15:59:35** - Julia:
> ja, weil er meinte, ob ich ins Büro kommen kann

**2026-01-29 15:59:37** - Julia:
> ich auch nicht

**2026-01-29 16:13:26** - Julia:
> aber wie unnötig ist es auch eine Präsentation zu präsentieren, die wir uns noch nicht zusammen angeschaut haben

**2026-01-29 16:14:21** - Marvin Hammerschmidt:
> ja 10/10

**2026-01-29 16:40:00** - Julia:
> haben wir eine strategie, wenn sie alle Formate scheiße finden? :smile:

**2026-01-29 16:40:15** - Marvin Hammerschmidt:
> Nö:D

**2026-01-29 17:16:59** - Julia:
> Willst du jetzt nochmal sprechen oder lieber morgen früh direkt?

**2026-01-29 17:17:25** - Marvin Hammerschmidt:
> 

**2026-01-29 17:24:22** - Marvin Hammerschmidt:
> <https://www.youtube.com/watch?v=JLllxhfhBXg>

**2026-01-30 10:32:17** - Marvin Hammerschmidt:
> uf

**2026-01-30 10:32:35** - Julia:
> er versteht es einfach niiiicht :smile:

**2026-01-30 10:32:47** - Marvin Hammerschmidt:
> es ist so crazy

**2026-01-30 10:33:20** - Marvin Hammerschmidt:
> Es geht mir so auf den sack

**2026-01-30 10:33:25** - Marvin Hammerschmidt:
> wie man uns so vollladen kann

**2026-01-30 10:41:04** - Julia:
> ja und das geht einfach nicht

**2026-01-30 10:41:14** - Julia:
> auch die visuals in 5 minuten erstellen – nein das geht nicht

**2026-01-30 10:41:37** - Marvin Hammerschmidt:
> bringt nix zu diskutieren sag ich dir...

**2026-01-30 10:41:42** - Julia:
> ja ich weiß

**2026-01-30 10:46:51** - Marvin Hammerschmidt:
> Depriorisieren 

**2026-01-30 10:47:14** - Marvin Hammerschmidt:
> Also 
Workshop ist top prio
Decathlon ist top prio
Anything or nothing ist top prio 


**2026-01-30 10:47:16** - Julia:
> den IG Workshop vllt?

**2026-01-30 10:47:20** - Julia:
> :smile:

**2026-01-30 10:47:47** - Marvin Hammerschmidt:
> Er wird nächste Woche sagen „ wo stehen wir bei anything or nothing“. Dann wird ihm das nicht passen.  Dann wird er sagen „das war top prio“ 

**2026-01-30 10:48:12** - Marvin Hammerschmidt:
> Ja gut. Also ich les gleich einfach ab mit besseren Betonungen. That's orb

**2026-01-30 10:48:15** - Marvin Hammerschmidt:
> *it 

**2026-01-30 10:48:29** - Julia:
> ja whatever

**2026-01-30 10:48:42** - Julia:
> "euer erster Pitch" Ja ich hab nie gesagt, dass ich das machen will? :smile:

**2026-01-30 10:48:54** - Julia:
> Und ist auch nicht mein erster Pitch. Aber so wie er ihn gerne hätte

**2026-01-30 10:49:18** - Marvin Hammerschmidt:
> Same :sweat_smile:

**2026-01-30 10:49:50** - Marvin Hammerschmidt:
> Also ich würd liebend gern nicht. Ich lass meine Frau 2 Wochen vor Entbindung 2 Tage allein. Finde das generell absolut Ungeil :sweat_smile:

**2026-01-30 11:01:32** - Julia:
> Ja versteh ich zu 10000%

**2026-01-30 11:01:33** - Julia:
> Das ist so krank

**2026-01-30 11:01:43** - Julia:
> Marvin kurze andere Frage:

**2026-01-30 11:02:01** - Julia:
> sieht man hier schon, dass es kein BMW ist? ich kenne mich nicht aus :smile:

**2026-01-30 11:04:12** - Marvin Hammerschmidt:
> Ja also man kann es schon erkennen aber ich sagmal das wäre keine katastrophe :smile:

**2026-01-30 11:05:03** - Julia:
> okay, ja wenn ich es anpasse dann richtig :smile:

**2026-01-30 11:09:21** - Marvin Hammerschmidt:
> Dann musst du leider nochmal ran:D

**2026-01-30 12:07:21** - Julia:
> Muss jetzt leider nochmal zum Tierarzt, meinem Hund gehts richtig schlecht. Also mache kurz "Lunch Break" Bis gleich!

**2026-01-30 12:12:42** - Marvin Hammerschmidt:
> Scheiße :open_mouth:
Gute Besserung an den guten :disappointed:

**2026-01-30 13:19:11** - Julia:
> Danke :heart_hands:

**2026-01-30 13:19:27** - Julia:
> also Jana ist nicht ganz auf der Höhe oder? 

**2026-01-30 13:24:09** - Marvin Hammerschmidt:
> sie macht unseren kram recht halbherzig würde ich sagen

**2026-01-30 13:29:36** - Marvin Hammerschmidt:
> Gehts deinem Doggo besser?

**2026-01-30 13:34:24** - Julia:
> würd ich auch sagen :smile:

**2026-01-30 13:34:53** - Julia:
> bisher nicht, aber hat jetzt alles mögliche gespritzt bekommen, sollte also bald besser werden. War aber auch einfach eine krasse OP, also verständlich

**2026-01-30 13:34:56** - Julia:
> danke der Nachfrage!

**2026-01-30 14:00:31** - Marvin Hammerschmidt:
> Ich drück die Daumen!

**2026-01-30 14:41:22** - Julia:
> hab mir Decathlon noch nicht durchgelesen :smile: du?

**2026-01-30 14:41:31** - Julia:
> SIXT AoN – kann ich dir da schon was bauen?

**2026-01-30 14:42:29** - Marvin Hammerschmidt:
> Nö. Mach ich gleich   Werde das auch krass runterkürzen :sweat_smile:

Kann dir bisher nur den one pager zeigen der das Konzept erklärt 

**2026-01-30 14:46:04** - Marvin Hammerschmidt:
> Opening Scene
We see a participant sitting in their own car on a quiet street.
A lively, cheeky moderator (think Jimmy Fallon meets car chaos) steps in, full of energy and sarcasm.
*Host*: “Are you really happy with your car? Or do you want something bigger?”
(He points at the shiny G-Class with a massive orange bow next to him.)
“All you have to do is let us do whatever we want with your car — and in return, you’ll get the G-Wagon for half a year. Deal?”
*Participant*: “If it gets me that G-Wagon, do whatever you want!”
*Host* (smirking): “Alright then… let’s go."

The Twist – Engraving the Car
Suddenly the *host* yells: “Jay, we’ve got permission!”
A second person appears, holding a power grinder with a mischievous grin.
Without hesitation, he starts engraving a huge “I :heart: SIXT” across the side of the participant’s car.
The participant’s jaw drops in disbelief, while the host bursts into laughter.

The Reward
When the engraving is done, the *host* claps his hands dramatically: “Congratulations! That’s your new car… but not for the next six months.”
He proudly hands over the keys to the Mercedes G-Class, gleaming under the sun.
*Host*: “Your ride for the next six months!”
The participant, now half-shocked and half-thrilled, jumps into the G-Class and drives off — leaving their newly ‘decorated’ car behind.


Opening und Reward bleiben eigentlich immer gleich
Was sich ändert ist der Twist

2 weitere Möglichkeiten:
1.
A famous golfer is invited to “aim for the deal.”
He has one chance to hit a golf ball through the car’s open window — if he succeeds, the participant gets the G-Class.
The risk: even a perfect shot might leave serious dents in the car.

2.
The participant’s car becomes a fashion icon.
Fake eyelashes on the headlights, bright red lips on the grill, and full-on “bitchy” glam styling.
A beauty makeover that screams SIXT with attitude — and leaves the owner blushing when they see it on the street.

**2026-01-30 15:00:56** - Marvin Hammerschmidt:
> Die trash tv bilder find ich mega cool :joy:

**2026-01-30 15:04:20** - Marvin Hammerschmidt:
> Ideen was mit den Autos sonst noch so passiert mach ich mir am we oder montag

**2026-01-30 15:04:29** - Marvin Hammerschmidt:
> Hab Julia aber schonmal ein paar fragen beantwortet

**2026-01-30 15:11:41** - Julia:
> Sorry bin grad kurz bei MINI

**2026-01-30 15:12:03** - Marvin Hammerschmidt:
> Alles gut
AoN muss halt warten

**2026-01-30 15:12:04** - Julia:
> alles klar. Dann übernimmst du die Folie oder ich? Ich kann ja LIB erzählen und dann übernimmst du mit der Übersicht?

**2026-01-30 15:12:17** - Marvin Hammerschmidt:
> Ja Trash mach ich

**2026-01-30 15:12:23** - Julia:
> ja..

**2026-01-30 15:12:25** - Marvin Hammerschmidt:
> LIB nimmst du

**2026-01-30 15:12:28** - Julia:
> okay

**2026-01-30 16:17:01** - Marvin Hammerschmidt:
> von wegen Inhalt passt

**2026-01-30 16:30:41** - Julia:
> ja hab ich mir auch gedacht

**2026-01-30 19:02:02** - Julia:
> happy weekend trotz allem und hoffentlich ein bisschen Ruhe!

**2026-01-30 19:09:40** - Marvin Hammerschmidt:
> Das wünsche ich dir auch!!!! 

**2026-02-02 09:18:30** - Julia:
> Guten Morgen :slightly_smiling_face:

**2026-02-02 09:20:47** - Marvin Hammerschmidt:
> Good morning:)

**2026-02-02 09:28:04** - Julia:
> Hattest du ein schönes Wochenende?

**2026-02-02 09:28:38** - Marvin Hammerschmidt:
> Leider weniger erholsam als gehofft aber da muss man durch^^
Und du? Wie gehts deinem Hund?

**2026-02-02 09:30:20** - Julia:
> Ja same. Gefühlt war gestern erst Freitag :smile:

**2026-02-02 09:30:43** - Julia:
> Wird langsam, waren jeden Tag beim Tierarzt/ Klinik aber heute sieht es ganz gut aus :slightly_smiling_face:

**2026-02-02 09:31:01** - Marvin Hammerschmidt:
> was ein scheiß
Der Arme
Weiterhin gute Besserung!

**2026-02-02 09:46:33** - Julia:
> Dankeee

**2026-02-02 10:09:00** - Julia:
> also ich weiß ja nicht, ob die Präsi heute was wird :smile:

**2026-02-02 10:14:59** - Marvin Hammerschmidt:
> Die für SIXT?
Ach ja warum nicht:D

**2026-02-02 10:15:01** - Marvin Hammerschmidt:
> das wird schon

**2026-02-02 10:15:13** - Marvin Hammerschmidt:
> Ist halt kacke das wir die noch nicht vorliegen haben

**2026-02-02 11:29:51** - Julia:
> ja genau

**2026-02-02 11:48:57** - Julia:
> boah

**2026-02-02 11:49:05** - Julia:
> sie hat ja quasi garnichts gemacht

**2026-02-02 11:49:14** - Marvin Hammerschmidt:
> Klasse

**2026-02-02 11:49:25** - Julia:
> slides alle noch alt vom look her

**2026-02-02 11:49:30** - Julia:
> Texte einfach reinkopiert

**2026-02-02 11:50:19** - Marvin Hammerschmidt:
> das ist schon crazy...

**2026-02-02 12:01:26** - Marvin Hammerschmidt:
> Sie haben mich auch um eine Agenda gebeten
Habe das um 10 an sie kommuniziert. Sie meinte 30 min

**2026-02-02 12:01:29** - Marvin Hammerschmidt:
> immer noch nicht

**2026-02-02 12:01:32** - Marvin Hammerschmidt:
> 0 Verlass

**2026-02-02 12:49:08** - Julia:
> wahnsinn

**2026-02-02 12:49:21** - Julia:
> Marvin welches Auto hab ich bei Opa Werner nochmal? :smile: Bzw. was könnte das sein?

**2026-02-02 12:51:15** - Marvin Hammerschmidt:
> Let me check:D

**2026-02-02 12:51:41** - Marvin Hammerschmidt:
> Kannst du mir das video schicken?
von dem Frame würd ich sagen das ist ein vw

**2026-02-02 12:51:49** - Julia:
> yes moment

**2026-02-02 12:51:50** - Marvin Hammerschmidt:
> kanns in der pdf aber nicht abspielen^^

**2026-02-02 12:52:12** - Julia:
> <https://drive.google.com/drive/folders/1aLCz7CZkdJOu_PQiBQh9GxUdMamSHJdt>

**2026-02-02 12:52:34** - Julia:
> also ich muss nur wissen, wenn ich jetzt sag: er wird dann im Benz zum oberrapper – nicht, dass es klar erkennbar der bwm x irgendwas ist

**2026-02-02 12:52:52** - Marvin Hammerschmidt:
> Welches davon ist das?

**2026-02-02 12:53:01** - Marvin Hammerschmidt:
> ah

**2026-02-02 12:53:01** - Julia:
> ach scheiße

**2026-02-02 12:53:02** - Marvin Hammerschmidt:
> sekunde

**2026-02-02 12:53:03** - Marvin Hammerschmidt:
> habs

**2026-02-02 12:53:04** - Marvin Hammerschmidt:
> all good

**2026-02-02 12:53:07** - Julia:
> sorry dachte da kommt direkt der link

**2026-02-02 12:53:10** - Julia:
> okay

**2026-02-02 12:53:39** - Marvin Hammerschmidt:
> Also als er einsteigt ist es ein verkappter VW
Wenn er drin sitzt ist das eine alte S-Klasse

**2026-02-02 12:54:04** - Julia:
> wunderbar

**2026-02-02 12:54:45** - Marvin Hammerschmidt:
> Ist fine Benz zu sagen
Das wird ihnen nicht auffallen im ersten part

**2026-02-02 12:54:55** - Julia:
> OKAY

**2026-02-02 12:54:58** - Julia:
> sorry :smile:

**2026-02-02 12:54:58** - Marvin Hammerschmidt:
> Gleich nochmal kurzen call zum abstimmen?

**2026-02-02 12:55:02** - Julia:
> okay, ja gerne

**2026-02-02 12:55:08** - Marvin Hammerschmidt:
> Wann passt sdir?

**2026-02-02 12:55:23** - Julia:
> in 5min?

**2026-02-02 12:55:27** - Marvin Hammerschmidt:
> aight

**2026-02-02 13:02:16** - Marvin Hammerschmidt:
> 

**2026-02-02 16:27:01** - Julia:
> wie ist dein Gefühl?

**2026-02-02 16:27:41** - Marvin Hammerschmidt:
> Okay würd ich sagen
Am besten ruft ihr mich zusammen an wenn ihr raus seid:)

**2026-02-02 16:35:18** - Marvin Hammerschmidt:
> Dafür das es gut wird geben wir wieder zu viel ab 
Ich hab Sorge dass es zu cringe wird oder sie zu viel da rein geben um zu viel Werbung zu  machen 

**2026-02-02 16:35:45** - Julia:
> yes machen wir

**2026-02-02 17:36:38** - Marvin Hammerschmidt:
> Der Look &amp; Feel (Das Fundament)
• *Opening Shot:* Immer ein 1.5-Sekunden-Zoom auf das Gesicht des Protagonisten mit einem spezifischen "Hook-Satz".
• *Sound &amp; Jingle:* Ein kurzes, prägnantes Audio-Logo (z.B. ein "Pop"-Sound oder ein spezieller Bass-Riff), das bei jedem Video-Start unterlegt ist.
• *Schnitt-Stil:* Schnelle, rhythmische Schnitte (Jump-Cuts), die den "Fun &amp; Bold"-Vibe unterstreichen.
• *AI-Anteil (30-40%):* Wir filmen reale Menschen in echten Umgebungen (Brooklyn Coffee Shop Vibe) und nutzen KI nur für *Hintergrund-Enhancements, Voice-Over-Clarity oder surreale Effekte* in den "Prank"-Szenen.


**2026-02-02 17:39:51** - Marvin Hammerschmidt:
> • Wiedererkennbarkeit durch Cuts, Personen, Sounds

**2026-02-02 17:39:59** - Julia:
> Danke dir 

**2026-02-02 17:40:14** - Julia:
> Bin leider noch immer unterwegs 

**2026-02-02 17:41:02** - Marvin Hammerschmidt:
> To dos:
Love is blind weiter ausarbeiten
Erste Carousel Posts erstellen von "Not to say"
Ideen für den Text oben auf dem Insta Kanal
Wer sind die Charaktere wie sind die verfügbar, wo finden die Sachen statt, Sound &amp; Jingle, Look anf Feel
Grundaufbau soll immer gleich sein und das sollen wir detailiert in unseren Konzepten zeigen
An produktionsworkaround denken

**2026-02-11 14:17:41** - Marvin Hammerschmidt:
> Also 1-2 Videos pro woche ist tatsächlich bei entsprechendem Aufwand gar nicht wenig

**2026-02-12 10:53:50** - Julia:
> Hello! :slightly_smiling_face: Also ich richte mich nach dir wegen der Übergabe. Morgen nachmittag passt für mich auch? Also sag du gerne wann es dir passt!

**2026-02-12 11:52:26** - Marvin Hammerschmidt:
> Morgen ab 3 würde evtl gehen
Jenachdem was da noch an to dos reinkommt:)

**2026-02-13 09:06:04** - Julia:
> Guten morgen, magst du mir einfach in WhatsApp schreiben, sobald du was weißt? :slightly_smiling_face: Dann übersehe ich es nicht. Bin ja nicht dauernd am Laptop

**2026-02-13 09:09:46** - Marvin Hammerschmidt:
> Guten Morgen

Yes mach ich

Sind gerad zum
Vorgespräch im Krankenhaus dann hab ich bis 3 Meetings. Ich hoffe es geht direkt danach aber ich meld mich noch :) 

**2026-02-13 09:10:15** - Julia:
> Uhh hoffe es ist alles gut! :crossed_fingers:

**2026-02-13 09:10:46** - Julia:
> Ja sag einfach bescheid, wenns heute zu stressig ist, können wir das natürlich auch am Sonntag oder so machen. Morgen bin ich nur (endlich wieder) nicht daheim und unterwegs :slightly_smiling_face:

**2026-02-13 09:11:48** - Marvin Hammerschmidt:
> Ansonsten halt Dienstag
Ist halt wie es ist :sweat_smile:

**2026-02-13 09:12:12** - Julia:
> Nenene ab nächster Woche bist du im Baby Fokus

**2026-02-13 09:12:43** - Marvin Hammerschmidt:
> Bin die ganze Woche noch da außer Montag
Wir werden das heute nicht ansatzweise schaffen


**2026-02-13 09:12:55** - Marvin Hammerschmidt:
> Einmal reicht auch nicht um das alles allein zu machen 

**2026-02-13 09:43:48** - Julia:
> okay

**2026-02-13 14:35:21** - Julia:
> wie siehts bei dir aus? :slightly_smiling_face:

**2026-02-13 14:41:19** - Marvin Hammerschmidt:
> bin noch in meetings
Werde auf jeden Fall länger brauchen

**2026-02-13 14:42:25** - Julia:
> okay. was ist dir denn am liebsten? Sollen wir DI/ MI morgens gleich direkt halbe Tage dafür blocken?

**2026-02-13 14:43:05** - Marvin Hammerschmidt:
> Ich muss gleich eh einmal das reporting machen
Das können wir einmal kurz zusamen machen und dann machen wir am DI und MI Deep dive :slightly_smiling_face:

**2026-02-13 14:51:10** - Julia:
> okay

**2026-02-13 15:26:00** - Marvin Hammerschmidt:
> 

**2026-02-13 15:26:40** - Julia:
> hat irgendwie nicht geklappt

**2026-02-13 15:26:41** - Julia:
> moment

**2026-02-13 15:26:44** - Marvin Hammerschmidt:
> 

**2026-02-13 15:34:39** - Marvin Hammerschmidt:
> Mit einem einmaligen Link erhalten Sie sicheren Zugriff auf einen Keeper-Datensatz. Der Zugriff auf Datensätze funktioniert nur auf einem Gerät und läuft in 1 Woche ab. <https://keepersecurity.eu/vault/share/#F4b8oaZqzqQL4knOqJgzNdomVsteEOSRFQz2X6SLno4>


---

## Florian Listl (554 messages)

**Julia sent:** 253 | **Florian Listl sent:** 301

**Folder:** `D09CX8LTPGB`

**2025-09-02 06:46:44** - Julia:
> Julia Hopper accepted your invitation to join Slack — take a second to say hello.

**2025-09-04 10:18:40** - Julia:
> Hi Flo! Ich hoffe du hast einen schönen Urlaub – trotz der Nachrichten gestern!

Ich wollte einmal schon ein Thema für nächste Woche vormerken:
Es würde meiner Meinung nach sehr viel Sinn machen in Zukunft mit Figma zu arbeiten. Hier können wir den benötigten Still Content super schnell erstellen und müssen keine einzelnen Dateien anlegen, erstellen usw usw. Oder wie jetzt gerade mit Mert uns mit den Abobe Lizensen teilen. Hier kann man einen Benutzen anlegen und teilen &amp; vor allem gleichzeitig darin arbeiten – das einiges erschnellt :slightly_smiling_face:

**2025-09-04 11:06:20** - Florian Listl:
> Hi Juli :) ich finde super, dass du proaktiv die Initiative ergreifst

**2025-09-04 11:06:49** - Florian Listl:
> Ich kenn mich mit Figma nicht aus, ihr seid die Profis - lasst uns das gerne testen!

**2025-09-04 11:07:21** - Florian Listl:
> Ich hoffe deinen ersten 1-2 Tage waren schön und du hast dich beim Team gut eingelebt- einige kennst du ja auch schon :)

**2025-09-04 11:37:25** - Julia:
> Okay super :slightly_smiling_face: Dann können wir das ja am Montag besprechen

**2025-09-04 11:37:53** - Julia:
> auf jeden Fall! Ist super spannend &amp; so ganz blicke ich noch nicht durch, aber das kommt ja eh mit der Zeit

**2025-09-04 20:36:02** - Florian Listl:
> genau, das machen wir!

**2025-09-04 20:36:31** - Julia:
> Ich wollte dir eben noch den Personalfragebogen schicken. Hatte hier noch gesehen, dass das Gehalt tatsächlich falsch eingetragen ist. Also ich sag nicht  natürlich Nein haha! Aber sollte evtl. angepasst werden :)

**2025-09-05 14:09:13** - Florian Listl:
> Haha danke! stimmt!

**2025-09-05 14:09:26** - Florian Listl:
> Passe ich direkt nach dem Urlaub an!

**2025-09-08 08:07:25** - Julia:
> Guten Morgen Flo! :slightly_smiling_face: Die Anmeldung bei Teams klappt mit der Adresse irgendwie nicht wirklich. Da kommt immer eine Fehlermeldung

**2025-09-08 08:32:26** - Florian Listl:
> Guten Morgen :) lass es uns zusammen anschauen, ich bin in 20-30 min im
Office

**2025-09-08 08:50:03** - Julia:
> Gerne. Ich fahre jetzt auch los

**2025-09-08 09:30:50** - Julia:
> Würde hier "Professional" empfehlen: <https://www.figma.com/de-de/pricing/#features>

**2025-09-08 22:51:19** - Julia:
> Hallo! Magst du mir das nochmal neu schicken oder soll ichs anpassen?

**2025-09-10 09:00:34** - Julia:
> Guten Morgen, sorry es ging gestern dann doch wieder länger. Ich meld mich wenn ich gleich auf dem Weg bin

**2025-09-14 13:31:03** - Julia:
> Hello! Wir sind heute doch nochmal am arbeiten &amp; am Content finalisieren für morgen. Warten gerade auf Feedback.
Porsche will nochmal ein paar Recap Slides für morgen etc. etc. Die meisten Assets werden dann heute schon gescheduled, ansonsten denke ich wird Julia morgen den Rest posten.
Ich würde mir dann morgen schon mal als Ausgleich für Samstag nehmen und je nachdem was dir lieber ist, direkt Dienstag oder Freitag dann den halben Tag von heute – hoffe es bleibt dabei

**2025-09-14 13:32:00** - Florian Listl:
> Puh das tut mir leid, hart dass ihr heute auch noch ran müsst

**2025-09-14 13:32:09** - Florian Listl:
> Lass uns mo und di machen 

**2025-09-14 13:32:21** - Florian Listl:
> Danke!!

**2025-09-14 17:52:11** - Julia:
> Ja wirklich etwas nervig... sind noch dran. Versuchen sie von unserer Empfehlung zu überzeugen

**2025-09-14 17:52:36** - Julia:
> Passt! Bin dann Mittwoch wahrscheinlich auch im Büro

**2025-09-15 09:23:15** - Florian Listl:
> Top! :) Ich freu mich!

**2025-09-18 16:33:18** - Florian Listl:
> oh das müssen wir noch anpassen :sweat_smile:

**2025-09-18 16:33:47** - Julia:
> Jaaa. Hab auch immer Probleme mit der Anmeldung :smile:

**2025-09-18 16:33:59** - Julia:
> Kannst du als Admin das anpassen?

**2025-09-18 16:34:48** - Florian Listl:
> Ich checke mal, bei uns heißt du schon Hopper, aber auf dem Porsche Tool noch nicht. Ich checke das mal

**2025-09-18 16:35:08** - Julia:
> okay, danke :smile:

**2025-09-23 09:13:59** - Julia:
> Hi Flo, ich bin leider garnicht fit. Hab nachts Migräne bekommen, die immer noch etwas da ist. Ich versuch das Reporting auf jeden Fall fertig zu bekommen, sobald es mir besser geht.

**2025-09-23 10:08:02** - Florian Listl:
> Hi Juli, gute Besserung! Danke für's bescheid geben!

**2025-09-23 12:38:43** - Julia:
> daanke dir

**2025-09-23 12:39:27** - Julia:
> Ich versuch gerade wenigstens das Reporting fertig zu stellen. Aber noch eine Frage: Haben wir denn für den BS schon irgendwelche KPIs/ Ziele definiert? Das hatte ich gestern vergessen zu fragen

**2025-09-23 12:40:05** - Florian Listl:
> Gute Frage. Hilft es dir, wenn ich ein reporting fertigstelle und du die anderen adaptierst? Sozusagen als Blueprint

**2025-09-23 12:43:09** - Julia:
> ich würde es jetzt so erstellen wie gestern besprochen und dann schicke ich es dir eh zum checken. daraus entsteht dann wahrscheinlich der Blueprint, oder?

**2025-09-23 12:47:46** - Florian Listl:
> gerne - ich wollte dir nur anbieten, dass ich die Vorlage erstelle

**2025-09-23 12:47:52** - Florian Listl:
> weil dir geht's ja heute nicht gut

**2025-09-23 12:48:55** - Florian Listl:
> lass mich das mal machen, dann kannst du dich noch bisschen ausruhen

**2025-09-23 12:49:10** - Florian Listl:
> kannst du mir die Notes noch schnell schicken von gestern?

**2025-09-23 12:49:15** - Florian Listl:
> einfach als Foto reicht

**2025-09-23 12:57:34** - Julia:
> ach danke dir, das ist wirklich sehr lieb

**2025-09-23 12:57:42** - Julia:
> Warte ich schick dir auch schon mal was ich anfangen hab

**2025-09-23 12:57:47** - Florian Listl:
> top

**2025-09-23 13:01:41** - Julia:
> 

**2025-09-23 13:02:42** - Julia:
> 

**2025-09-23 13:09:28** - Florian Listl:
> danke!

**2025-09-23 13:09:39** - Florian Listl:
> kannst du mir auch noch kurz diese Content Haus Slide weiterleiten?

**2025-09-23 14:17:54** - Julia:
> 

**2025-09-23 23:34:54** - Florian Listl:
> FYI :slightly_smiling_face: Ich hoffe es geht dir besser!

**2025-09-24 07:47:45** - Julia:
> cool, das hilft mir auf jeden Fall für die nächsten Male! :pray: 

**2025-09-24 07:50:19** - Julia:
> Leider nein, wollte mich deshalb auch gerade melden, mich hats dann komplett zerlegt. Hab abends hohes Fieber bekommen. Bin leider  immer noch fiebrig.. :sob: ich würde mich heute dann komplett krankmelden, damit ich morgen wieder voll am Start sein kann 

**2025-09-24 08:46:10** - Florian Listl:
> Okay, wie sieht die ppt mit den Ideen von Brand Store aus?

**2025-09-24 08:46:20** - Florian Listl:
> Sind die Andeutungen schon eingearbeitet?

**2025-09-26 08:24:07** - Florian Listl:
> Guten Morgen :)

**2025-09-26 08:24:22** - Florian Listl:
> Lass uns gern mal bzgl dem reporting sprechen, sobald du available bist

**2025-09-26 08:38:13** - Julia:
> Hello!

**2025-09-26 08:38:46** - Julia:
> Vielleicht vor unserem Huddle? Oder bist du da garnicht dabei?

**2025-09-26 08:45:47** - Florian Listl:
> Gern

**2025-09-26 08:46:00** - Florian Listl:
> Normalerweise bin ich da nicht dabei, aber heute ist es vlt sinnvoll :)

**2025-09-26 08:53:59** - Julia:
> perfekt

**2025-09-26 09:10:47** - Florian Listl:
> 9:30?

**2025-09-26 09:17:09** - Florian Listl:
> Kannst du auf den Link zugreifen und die PPT bearbeiten? <https://porsche.sharepoint.com/:p:/r/sites/PDMK/Shared%20Documents/General/UMZUG/Digitales%20Marketing/Social/Insta/09_Reporting/02_Sonderreportings/2025/Gipfeltreffen/250926_PD_Social-Reporting_Gipfeltreffen.pptx?d=w3cafe52939c24a3f84b7d6395760c8e3&amp;csf=1&amp;web=1&amp;e=M3sFHU|250926_PD_Social-Reporting_Gipfeltreffen.pptx> <@U09D64LA420>

**2025-09-26 09:30:31** - Florian Listl:
> bist du ready für den Call? <@U09D64LA420>

**2025-09-26 09:39:33** - Julia:
> Nee hab leider keinen Zugriff

**2025-09-26 09:39:39** - Julia:
> Bin jetzt ready!

**2025-09-26 09:39:59** - Florian Listl:
> versuche dich mal einzuloggen mit der email - das ist wichtig, dass du zugriff hast

**2025-09-26 09:40:22** - Julia:
> welche mail?

**2025-09-26 09:40:39** - Julia:
> hab den Zugriff angefordert

**2025-09-26 09:40:42** - Florian Listl:
> <mailto:julia.hopper@boldcreatorsclub.com|julia.hopper@boldcreatorsclub.com>

**2025-09-26 09:40:58** - Julia:
> Aber kann sein, dass das wieder nicht klappt – Julia meinte Marie muss mich hier freigeben

**2025-09-26 09:41:10** - Julia:
> Hab auf viele Sharepoint Dateien keinen zugriff

**2025-09-26 09:41:30** - Julia:
> 

**2025-09-26 09:41:55** - Florian Listl:
> okay, dann logg dich mal mit meinen credentials ein

**2025-09-26 09:42:24** - Florian Listl:
> <mailto:florian.listl@boldcreatorsclub.com|florian.listl@boldcreatorsclub.com>
vG.nZGi#E83a6jm

**2025-09-26 09:42:29** - Julia:
> okay, moment

**2025-09-26 09:42:40** - Florian Listl:
> dann muss ich die zahl nur eingeben bei 2fa

**2025-09-26 09:43:09** - Julia:
> ah moment, jetzt hat mich irgendwer freigegeben und ich kanns öffnen

**2025-09-26 09:43:16** - Florian Listl:
> top

**2025-09-26 09:43:56** - Florian Listl:
> dann lass uns hier gleich rein :slightly_smiling_face:

**2025-09-26 09:43:57** - Florian Listl:
> <https://meet.google.com/gwf-zuzb-jvi?authuser=1>

**2025-09-26 10:41:02** - Julia:
> <https://app.asana.com/1/1199360402832734/project/1210556045020744/task/1211465610715674?focus=true>

**2025-09-26 14:49:34** - Julia:
> Eine Frage: soll ich Hanna später Bescheid geben, wenn Post/ Story Vorschläge in der BS Präsi ablegen oder machen wir das erst ab Montag?

**2025-09-26 14:49:41** - Julia:
> Mert und ich sind dran :slightly_smiling_face:

**2025-09-26 17:34:44** - Julia:
> habs ihr jetzt mal geschickt, hoffe das war okay

**2025-09-29 09:55:36** - Florian Listl:
> oh sorry, hab ich übersehen

**2025-09-29 09:55:38** - Florian Listl:
> aber klar!

**2025-09-29 10:21:49** - Julia:
> Also insider posts + alltagsdrive sagt mir leider garnichts

**2025-09-29 10:35:23** - Florian Listl:
> Sylt Golf: <https://www.picdrop.com/eyecatchme/porsche-golf-circle-sylt>

**2025-09-29 10:38:06** - Florian Listl:
> 4NYr5m9k

**2025-09-29 17:21:34** - Julia:
> irgendwie bin ich noch als Schmid drin :smile:

**2025-09-30 09:21:35** - Florian Listl:
> okay, ich checke das mal im Porsche Portal

**2025-09-30 09:55:16** - Julia:
> Danke 

**2025-09-30 10:07:29** - Julia:
> ich kanns nicht teilen wegen sharepoint

**2025-09-30 10:54:53** - Florian Listl:
> Ich komm gleich ins Meeting

**2025-09-30 10:55:01** - Julia:
> okay

**2025-09-30 11:34:44** - Florian Listl:
> 

**2025-09-30 11:36:08** - Florian Listl:
> 

**2025-09-30 18:23:32** - Julia:
> Hello! Bist du noch da?

**2025-09-30 18:23:41** - Florian Listl:
> hey

**2025-09-30 18:23:42** - Florian Listl:
> klar

**2025-09-30 18:26:08** - Julia:
> 

**2025-09-30 18:26:52** - Florian Listl:
> Okay, ich ruf ihn schnell an :)

**2025-09-30 18:26:55** - Florian Listl:
> Danke!

**2025-09-30 18:26:58** - Florian Listl:
> Kriegt sie

**2025-09-30 18:27:36** - Julia:
> okay!

**2025-10-07 14:05:16** - Florian Listl:
> Hi Juli :slightly_smiling_face:
Kannst du mir kurz noch sagen wie viele Stunden du insgesamt für IAA und Gipfeltreffen gearbeitet hast? Inklusive allen Meetings, am besten nach Woche geordnet:
also 1.-7.9., 8.-14., 15.-21., 22.-28., 29.-30.

**2025-10-07 14:12:07** - Julia:
> Hello! Klar, schreib ich dir runter

**2025-10-07 14:12:14** - Florian Listl:
> danke!!

**2025-10-07 15:03:47** - Julia:
> ganz grob mit Tasks, Mails usw.:

*IAA*
1.9. - 7.9.: 7 Std. (Grid, IG Highlight, Captions für alle Assets)
8.9. - 14.9.: so wie Julia 70-75 Std. (Vor Ort + Sonntag Nachbereitung GIF Vorschläge)

*Gipfeltreffen*
15.9. - 21.9.: 4 Std. (Grid, IG Highlight Vorschläge)
22.9. - 28.9.: 3 Std. (Textbausteine für Captions, Grid Anpassungen, Postings aushelfen)
29. - 30.9.: 0
1.10. - 5.10.: 4 Std. (Carousels…)
6.10. - 7.10.: 3 Std. (2x neue Carousels, tbd.)

**2025-10-07 15:04:07** - Florian Listl:
> danke!!

**2025-10-10 11:09:54** - Florian Listl:
> Hey :slightly_smiling_face: <@U09D64LA420> lass uns gern kurz sprechen, wenn du vom Hundespaziergang wieder da bist :slightly_smiling_face: über das was heute ansteht

**2025-10-10 11:22:44** - Julia:
> Hello! bin wieder da

**2025-10-10 11:32:40** - Julia:
> Aufgaben sind klar:
• Porsche Points vom Gipfeltreffen für DE – macht Mert fertig und ich schicke sie gleich Charly, inklusive Captions
• Story Antworten Leonie Beck: Abstimmung gleich per Mail, kann dann geposted werden
• der größte Brocken ist heute die Bearbeitung des Contents von Event im Brand Store gestern: Content ist nicht gut, Hanna ist garnicht happy. versuchen das beste rauszuholen aber der Fotograf ghosted mich jetzt gerade auch

**2025-10-10 11:51:07** - Florian Listl:
> super!

**2025-10-10 11:51:37** - Florian Listl:
> weißt du was hier noch fehlt? <https://docs.google.com/presentation/d/1uJx_LoaNymBB1qkIUF3tGpVu0i_J5cT2/edit?usp=drive_web&amp;ouid=110452318806524765124&amp;rtpof=true>

**2025-10-10 11:52:19** - Florian Listl:
> danke, dass du dich um das brand store event kümmerst!

**2025-10-10 11:56:24** - Julia:
> ich glaube alles was "gelb" ist meine Julia – habe es aber noch nicht geschafft, wirklich durchzugehen

**2025-10-10 11:56:46** - Julia:
> ja gerne. Aber wie gesagt, es ist echt schwierig. Der Fotograf reagiert auf keine einzige Nachricht

**2025-10-10 11:56:55** - Florian Listl:
> kannst du ihn anrufen?

**2025-10-10 12:00:34** - Julia:
> hab ich schon probiert

**2025-10-10 14:44:10** - Julia:
> 

**2025-10-13 10:25:49** - Florian Listl:
> Guten Morgen :slightly_smiling_face: Lass uns gern auch am Dienstag oder Mittwoch besprechen auf welchen anderen Projekten nach Porsche wir dich einsetzen können, damit du eine bessere Perspektive hast für die nächsten Monate

**2025-10-13 12:40:53** - Julia:
> Hi Flo, das können wir sehr gerne machen. Morgen direkt? :slightly_smiling_face:

**2025-10-15 11:15:41** - Julia:
> Hey, ich wollte jetzt nochmal nachfragen, ob es denn generell schon ein Update von Porsche gibt? Du meintest ja letzte Woche bis spätestens Mitte dieser Woche sollte es eine Info geben oder du meldest dich bei uns.
Mert, Julia und ich hängen schon echt sehr in der Luft und selbst, wenn es kein Update gibt weil ihr noch in den Verhandlungen seid, wäre es schon fair zu erfahren, "dass es kein Update gibt".  Porsche hat schon paar mal Andeutungen gemacht, dass es wohl nur noch bis Ende Oktober geht bezüglich Prios etc., das ist natürlich dann schon ein komisches Gefühl, wenn wir das von dir aber noch nicht erfahren haben. Und generell müssten wir uns ja dann auch in 2 Wochen nach einem neuen Job umsehen oder auch nicht..? Hast du hier eine Info für uns? Danke dir

**2025-10-15 11:16:08** - Florian Listl:
> Hi, nein, du bleibst auf jeden Fall bei BCC :slightly_smiling_face:

**2025-10-15 11:16:34** - Florian Listl:
> Lass uns heute um 15 Uhr sprechen

**2025-10-15 11:17:03** - Florian Listl:
> wann Porsche aufhört hat nichts mit dir zu tun

**2025-10-15 11:17:34** - Florian Listl:
> ich hab dir einen Termin eingestellt

**2025-10-15 11:55:02** - Julia:
> okay, das sind doch schöne nachrichten

**2025-10-15 11:55:08** - Julia:
> danke!

**2025-10-17 15:38:44** - Florian Listl:
> Hi :slightly_smiling_face: Kannst du das schnell checken?

**2025-10-17 15:42:20** - Julia:
> schau ich mir an

**2025-10-17 15:42:26** - Florian Listl:
> danke! :slightly_smiling_face:

**2025-10-17 15:47:12** - Julia:
> Keine Ahnung, was da war

**2025-10-17 15:47:30** - Julia:
> klar gerne, hatte mein Handy nur gerade nicht bei mir

**2025-10-17 15:51:45** - Florian Listl:
> du musst das am Sonntag nicht checken :slightly_smiling_face:

**2025-10-17 15:53:47** - Julia:
> Ja, ich bin auch fähig ein Reel hochzuladen ohne komischen Rand haha

**2025-10-17 16:11:47** - Florian Listl:
> ja...

**2025-10-21 11:13:32** - Julia:
> Hello! Die Rechnungsadresse für den Fotografen vom 60Y Targa Event ist die Mandlstraße oder?

**2025-10-24 11:21:33** - Florian Listl:
> ja :slightly_smiling_face:

**2025-10-30 13:32:35** - Florian Listl:
> so sehe ich die Aufgabenverteilung für Hisense.
Community Mgmt. kann auch bei Mert statt bei dir liegen, aber dem Kunden können wir das nicht kommunizieren, dass der Designer non-designer jobs macht :slightly_smiling_face:

**2025-10-30 13:33:23** - Florian Listl:
> Hier ist die Lohnabrechnung :slightly_smiling_face:

**2025-10-30 13:47:25** - Julia:
> danke dir! Okay, alles klar. Kann man sonst ja auch aufteilen je nach Kapa

**2025-10-30 13:47:50** - Florian Listl:
> genau

**2025-10-30 13:47:53** - Julia:
> super danke! Hast du auch noch die für September?
Eigentlich kommen diese per Post oder? Also so kenne ich das

**2025-10-30 13:48:21** - Florian Listl:
> das ist die von September, wir machen das immer digital, morgen kann ich dir die von Oktober schicken

**2025-10-30 13:48:36** - Julia:
> ahh sorry :smile: falsch gelesen

**2025-10-30 13:48:41** - Julia:
> perfekt, danke :slightly_smiling_face:

**2025-10-30 14:07:39** - Julia:
> FYI beim Brand Store hatten wir für die Rundgang Stories 4 Iterationen – falls du das für die Abrechnung brauchst

**2025-10-30 14:08:07** - Julia:
> Waren immer wieder Textanpassungen, die inhaltlich gleich geblieben sind aber sie einfach die Texte umgestellt haben :no_mouth:

**2025-10-30 14:08:46** - Florian Listl:
> :man-facepalming::man-facepalming::man-facepalming::man-facepalming:

**2025-10-30 14:08:54** - Florian Listl:
> Danke!

**2025-10-30 14:27:41** - Julia:
> Bin übrigens schon 31 – aber Danke fürs jünger machen :innocent:

**2025-10-31 10:02:53** - Florian Listl:
> haha deine Ideen waren so fresh, dass ich dich jünger geschätzt hab :stuck_out_tongue_winking_eye:

**2025-10-31 10:03:19** - Florian Listl:
> Happy Friday :slightly_smiling_face: hier die Lohnkostenabrechnung für Okt

**2025-10-31 10:06:23** - Julia:
> danke!

**2025-11-03 10:35:50** - Julia:
> Hi Flo, können wir hier sprechen? Mein Handy funktioniert leider nicht gerade

**2025-11-03 10:35:58** - Florian Listl:
> haha klar :slightly_smiling_face:

**2025-11-03 10:36:00** - Florian Listl:
> 

**2025-11-03 10:42:05** - Florian Listl:
> hier <https://drive.google.com/drive/folders/1Tygyp-KCUMWiL9bP9_yC9P_h7dBXq1Jh?usp=sharing>

**2025-11-03 14:31:02** - Julia:
> Das meinte ich vorhin, bei Figma ist der Admin Account noch der Porsche Account. Sollen wir diesen weiterhin nutzen?

**2025-11-03 14:32:10** - Florian Listl:
> sehr guter punkt, auch das will ich streamlinen, in zukunft sollen alle payments über <mailto:clients@boldcreators.club|clients@boldcreators.club> laufen - ist für die Buchhaltung viel einfacher.

Kannst man da eine andere email adresse angeben?

**2025-11-03 14:33:51** - Julia:
> ah perfekt. checke ich gerade

**2025-11-03 14:39:44** - Julia:
> yes, klappt

**2025-11-03 14:39:56** - Julia:
> soll ich die neue Mail direkt übernehmen oder ist das noch nicht final?

**2025-11-03 14:41:23** - Florian Listl:
> ist final

**2025-11-03 14:41:28** - Florian Listl:
> ich geb dir die zugangsdaten

**2025-11-03 14:41:34** - Florian Listl:
> login bitte wieder mit google

**2025-11-03 14:41:34** - Julia:
> okay super, danke

**2025-11-03 14:41:42** - Florian Listl:
> also login via google

**2025-11-03 14:41:48** - Florian Listl:
> die option gibts da beistens

**2025-11-03 14:41:49** - Florian Listl:
> meistens

**2025-11-03 14:42:01** - Julia:
> ja stimmt

**2025-11-03 14:42:07** - Florian Listl:
> login via Google:
<mailto:clients@boldcreators.club|clients@boldcreators.club>
_clients@bcc2023!

**2025-11-03 14:42:17** - Florian Listl:
> also wichtig: _clients@bcc2023! ist das google passwort :slightly_smiling_face:

**2025-11-03 14:42:31** - Julia:
> okay. ich versuchs mal

**2025-11-03 14:43:11** - Florian Listl:
> 90 24 84

**2025-11-03 14:43:40** - Florian Listl:
> bitte log dich am besten an deinem handy in der gmail app auch mit <mailto:clients@boldcreators.club|clients@boldcreators.club> ein, dann kannst du's selbst verifizieren und brauchst nicht mich

**2025-11-03 14:43:54** - Florian Listl:
> auf welche Zahl soll ich klicken? :grin:

**2025-11-03 14:44:01** - Julia:
> 84

**2025-11-03 14:44:33** - Julia:
> yes, mach ich. Stelle nur gerade auf ein neues Handy um und des backup lädt seit heute morgen, deshalb kann ich hier noch nichts umstellen

**2025-11-03 14:44:44** - Julia:
> jetzt ist es Nummer 28

**2025-11-03 14:45:51** - Florian Listl:
> kein problem, danke!

**2025-11-03 14:53:58** - Julia:
> Hat geklappt, Figma ist umgestellt :slightly_smiling_face: danke dir

**2025-11-03 14:54:03** - Florian Listl:
> top!

**2025-11-04 14:45:17** - Julia:
> Hi Flo! Hier ab Slide 17 haben wir neue Content Ideen und Reihen gesammelt, die eben auf die Content Säulen des Strategie Papers einzahlen, sowie eine grobe "Roadmap" erstellt. Das ist gerade noch etwas schwierig ohne wirklich zu wissen, wie die Produktionen sonst laufen.
Freu mich über Feedback:
<https://docs.google.com/presentation/d/1hCn3KbyAlmOzdpS0aAdcerl52U-l4EYm/edit?slide=id.g39fbe07ff9b_0_162#slide=id.g39fbe07ff9b_0_162>

**2025-11-04 17:14:47** - Florian Listl:
> Mega, danke! Ich schau es mir an :+1::+1:

**2025-11-10 10:11:22** - Julia:
> Hi Flo! Ich bin heute wieder mehr oder weniger da und mache zumindest schon mal die Übergabe mit Julia &amp; fange die Ausarbeitungen der Content Ideen an

**2025-11-10 10:11:55** - Florian Listl:
> Hi Juli, super!

**2025-11-12 14:40:46** - Julia:
> Evlt. macht das Tiny House dann garkeinen Sinn und wir suchen lieber Creator/ Studios die schon perfekt gestyled sind

**2025-11-12 14:41:08** - Florian Listl:
> verstehe, die haben im tiny house halt die ganze einrichtung

**2025-11-12 14:41:08** - Julia:
> oder direkt in Berlin

**2025-11-12 14:41:12** - Florian Listl:
> das ist ganz cool

**2025-11-12 14:41:18** - Julia:
> ja das auf jeden fall

**2025-11-13 09:51:49** - Julia:
> Hello! :slightly_smiling_face: Wann sollen wir wegen den KI Videos sprechen? Und wenn du mir noch die Infos zum Termin morgen gibst, wäre super :slightly_smiling_face:

**2025-11-13 11:31:06** - Florian Listl:
> 13 Uhr?

**2025-11-13 11:48:11** - Julia:
> yes, passt

**2025-11-13 11:52:05** - Florian Listl:
> top, hab dir eine einladung geschickt

**2025-11-13 11:52:25** - Florian Listl:
> darum wird's gehen :slightly_smiling_face:

**2025-11-13 11:53:05** - Florian Listl:
> Tobias hat die Storyline geschrieben, die müssen wir noch mit leben füllen. Ich brauche deine Social Skills und deine Video Skills dafür. Mehr erzähle ich dir um 13 uhr

**2025-11-13 11:53:43** - Florian Listl:
> das war das briefing an Tobias

**2025-11-13 11:54:32** - Julia:
> okay, schau ich mir an

**2025-11-13 11:54:43** - Julia:
> Tobias ist von BCC?

**2025-11-13 11:56:12** - Florian Listl:
> Tobias Seitz ist unser Senior Advisor, wir kennen ihn von seiner Zeit als Global CMO bei SIXT, davor hat er als CMO Westwing aufgebaut. Seit Juni ist er Global CMO von OBI <https://campaigngermany.de/news/beitrag/783-ex-sixt-cmo-tobias-seitz-heuert-bei-obi-an.html>

**2025-11-13 11:56:29** - Julia:
> Ahja genau, okay

**2025-11-13 11:56:39** - Florian Listl:
> Wir nutzen ihn oft um Marken zu verstehen und strategisch zu denken

**2025-11-13 11:56:42** - Florian Listl:
> darin ist er super

**2025-11-13 11:56:54** - Florian Listl:
> Jetzt haben wir das Gerüst, das müssen wir jetzt mit Fleisch füllen

**2025-11-13 12:11:38** - Julia:
> okay :slightly_smiling_face:

**2025-11-13 13:00:15** - Florian Listl:
> Hier noch für gleich: <https://youtu.be/0eEG5LVXdKo?t=1691> -&gt; bitte mit Stromberg-Ernie als Sparkasse/ Windows und einem von denen als Apple/ Bitpanda <https://www.tiktok.com/@hannesundjeremy/video/7345495818364816673?q=telefon%20prank&amp;t=1763035190400>

**2025-11-13 13:00:54** - Florian Listl:
> und bitte noch community stories einbauen

**2025-11-13 13:00:57** - Florian Listl:
> bis gleich :slightly_smiling_face:

**2025-11-13 13:02:01** - Julia:
> haha okay

**2025-11-13 13:02:04** - Julia:
> bin im meeting

**2025-11-13 13:42:18** - Florian Listl:
> <https://drive.google.com/file/d/1GzpyNFdmpV5BaRDDdQwXzFX91uFC_Y60/view?usp=sharing> MINI Video

**2025-11-13 13:42:41** - Florian Listl:
> Link zum Bitpanda Skript: <https://docs.google.com/document/d/1npeOaKceAB7Cxys3oTxUj2v4nRpQqFVs/edit>

**2025-11-13 13:54:53** - Florian Listl:
> mit DAZN macht Bitpanda scheinbar auch einiges :slightly_smiling_face:

**2025-11-13 14:06:19** - Florian Listl:
> ich hab dich auch in die Gruppe mit Alex und mir eingeladen, so können wir Ideen und Visuals schneller besprechen :slightly_smiling_face:

**2025-11-13 14:12:23** - Julia:
> ah cool, perfekt :slightly_smiling_face:

**2025-11-13 16:19:55** - Julia:
> noch eine Frage zu Bitpanda: alles auf deutsch oder englisch?

**2025-11-13 16:24:29** - Florian Listl:
> Deutsch passt

**2025-11-13 16:24:40** - Florian Listl:
> Aber Englisch geht auch

**2025-11-13 16:24:44** - Florian Listl:
> Eigentlich egal

**2025-11-13 16:24:49** - Florian Listl:
> Was dir lieber ist

**2025-11-13 16:24:58** - Florian Listl:
> Geht um Video creation oder?

**2025-11-13 16:25:22** - Julia:
> ja genau

**2025-11-13 16:25:43** - Julia:
> weil sie auf ihrem TikTok Account auch beides mixen, deshalb frag ich

**2025-11-14 15:20:32** - Florian Listl:
> Kannst du da rein? :slightly_smiling_face: <https://meet.google.com/sqt-cfga-irb?authuser=0> <@U09D64LA420>

**2025-11-17 12:45:11** - Julia:
> Hello! Hast du zufälligerweise den Kontakt von Rückenwind würde mal nachfragen, ob sie Infos haben

**2025-11-17 12:46:25** - Florian Listl:
> Klar, einfach die Jasmin Jasmin Kharbeiti | RÜCKENWIND <mailto:jasmin@rueckenwind.rocks|jasmin@rueckenwind.rocks>

**2025-11-17 12:47:22** - Julia:
> super danke

**2025-11-18 11:54:25** - Julia:
> 

**2025-11-18 13:35:19** - Julia:
> Hier auch nochmal, falls WhatsApp spinnt :slightly_smiling_face:

**2025-11-21 14:03:20** - Florian Listl:
> 

**2025-11-21 14:07:57** - Florian Listl:
> 

**2025-11-21 16:45:50** - Julia:
> FYI: Anna und Marie sind noch an der Liste dran

**2025-11-21 16:58:00** - Florian Listl:
> Okay, Push sie :)

**2025-11-21 17:13:49** - Julia:
> yes, es lädt alles so lange scheinbar

**2025-11-21 17:14:24** - Julia:
> ansonsten schicke ich dir den onepager morgen früh direkt, wenn das jetzt noch etwas dauert

**2025-11-21 17:14:28** - Florian Listl:
> Ok

**2025-11-21 17:14:30** - Florian Listl:
> Danke!!

**2025-11-22 11:10:23** - Julia:
> Hello Flo!
Hier die Zusammenfassung und Storyline:
<https://docs.google.com/document/d/1SByofKhnwxNEQS8nKwrzm-wT7L5-qAubuA9JX6N6XGo/edit?tab=t.0>

Hier noch die Super Fans Ausarbeitungen + Content der Konkurrenz von Marie &amp; Anna als Ergänzung:
<https://docs.google.com/document/d/1t04tJSyVL0e2TAE2H277MDg7mhF4fi3uN5bBYDQCAgs/edit?tab=t.0>

Hier die Median Likes sortiert:
<https://boldcreators-my.sharepoint.com/:x:/g/personal/marie_gottschall_boldcreatorsclub_com/ET4BSKx62fhMpiswGgNC9sEBDR16D0Kim2f3GmQsqcmgrQ?rtime=TaLwKhQp3kg|https://boldcreators-my.sharepoint.com/:x:/g/personal/marie_gottschall_boldcreatorsclub_com/[…]MpiswGgNC9sEBDR16D0Kim2f3GmQsqcmgrQ?rtime=TaLwKhQp3kg>
Hier haben mir tatsächlich die Views gefehlt, um die Engagement Rates ausrechnen zu können --&gt; bitte ich sie am Montag nochmal drum.
Happy weekend :slightly_smiling_face:

**2025-11-22 11:10:43** - Florian Listl:
> Danke! :)

**2025-11-22 11:11:02** - Florian Listl:
> Sind das die Anzahl der Videos die kommentiert wurden von den Usern?

**2025-11-22 11:11:12** - Florian Listl:
> Oder die Anzahl der Kommentare?

**2025-11-22 11:11:43** - Florian Listl:
> Hast du die excel files ggf. noch? :)

**2025-11-22 11:11:58** - Florian Listl:
> Danke!! Auch für die xtra mile

**2025-11-22 11:14:31** - Julia:
> so wie ich es gesehen die Anzahl der Videos. Amy zB kommentiert jedes Video - aber kann ich gerne nochmal nachfragen. Habe auf die Schnelle nicht gesehen, dass es doppelte Kommentare gibt

**2025-11-22 11:14:57** - Julia:
> klar, hier sind die Folder:
<https://drive.google.com/drive/folders/1jxccnuQ8RY-et_z6thNXnixY-TvkHDio>

**2025-11-22 11:15:03** - Julia:
> <https://drive.google.com/drive/folders/16XoGvShB_HogZBtipVE7hw4oYY0vmrub?usp=drive_link>

**2025-11-22 11:15:41** - Florian Listl:
> Okay, weil das würde bedeuten, dass Mac 355 Videos 2025 gepostet hat, und Amy jedes der Videos kommmtiert hat

**2025-11-22 11:15:44** - Florian Listl:
> Oder?

**2025-11-22 11:16:01** - Julia:
> gerne. Das Thema ist echt spannend, weil da eigentlich soo viel Potenzial drin ist.
bin gespannt, was du zur Storyline sagst

**2025-11-22 11:18:38** - Julia:
> insgesamt haben sie ca. 520 videos gepostet

**2025-11-22 11:18:49** - Julia:
> 522

**2025-11-22 11:18:59** - Florian Listl:
> 2025?

**2025-11-22 11:19:09** - Florian Listl:
> Das sind ja fast 2 Videos pro Tag im Schnitt 

**2025-11-22 11:19:11** - Florian Listl:
> Crazy

**2025-11-22 11:19:31** - Julia:
> ja

**2025-11-22 11:20:04** - Florian Listl:
> Okay krass 

**2025-11-22 11:20:56** - Florian Listl:
> Danke!!

**2025-11-22 11:21:34** - Julia:
> gerne! Happy weekend und viel Spaß beim Skifahren

**2025-11-22 11:37:28** - Florian Listl:
> Haha danke :) dir viel Spaß mit den Schwiegereltern :smile:

**2025-11-24 11:55:17** - Julia:
> Hi Flo! Leider kann uns Marvin die Info zur damaligen Heimkinoraum Buchung nicht geben, deshalb wollte ich dich nochmal fragen, ob du  wegen einer alten Rechnung oÄ schauen könntest?

**2025-11-24 12:02:28** - Julia:
> für die Kostenaufstellung

**2025-11-24 12:06:01** - Florian Listl:
> Here you go, die heimkino Rechnung

**2025-11-24 12:06:23** - Florian Listl:
> Konntest du schon mit Marie sprechen?

**2025-11-24 12:09:03** - Julia:
> ah das ist das Model – bräuchten vom Raum selbst

**2025-11-24 12:09:28** - Florian Listl:
> War auch 500€ glaube ich

**2025-11-24 12:09:32** - Florian Listl:
> Was braucht ihr?

**2025-11-24 12:09:36** - Florian Listl:
> Nur den Preis?

**2025-11-24 12:09:39** - Julia:
> genau

**2025-11-24 12:09:51** - Florian Listl:
> Den weiß Marvin sicher 

**2025-11-24 12:09:59** - Julia:
> ne weiß er leider nicht

**2025-11-24 12:10:06** - Julia:
> haben schon 2 mal gefragt haha

**2025-11-24 12:10:21** - Florian Listl:
> Okay

**2025-11-24 12:10:45** - Florian Listl:
> Dann ruf gern bei heimkinoraum an, sag ob wir wieder 500€ machen können, du bist die Hisense Agentur 

**2025-11-24 12:10:52** - Julia:
> hab ich schon

**2025-11-24 12:11:23** - Julia:
> das ist leider super nervig, der EINE Ansprechpartner antwortet mir nicht und alle anderen können keine auskunft geben – ich ruf da schon täglich an

**2025-11-24 12:11:41** - Julia:
> Marvin meinte halt es kann auch sein, dass es umsonst war. deshalb

**2025-11-24 15:50:28** - Florian Listl:
> ich fand die storyline zu mac gut - gebe dir noch im detail feedback

**2025-11-24 15:50:40** - Julia:
> alright

**2025-11-24 15:50:47** - Julia:
> Muss ich noch irgendwas vorm Meeting jetzt wissen?

**2025-11-24 15:52:35** - Florian Listl:
> Nein, wir möchten herausfinden wie hoch das Budget und wo wir im Prozess stehen

**2025-11-24 16:47:59** - Julia:
> sehr spannend!

**2025-11-25 10:20:21** - Florian Listl:
> Lass uns kurz zu Estée Lauder bzw MAC sprechen, wann hast du Zeit?

**2025-11-25 10:33:05** - Julia:
> ja gerne. hab um 11 das meeting mit Hisense. also gerne jetzt oder danach?

**2025-11-25 10:33:10** - Florian Listl:
> danach

**2025-11-25 10:33:15** - Florian Listl:
> lass uns 12 machen

**2025-11-25 10:33:19** - Florian Listl:
> schick mir gern eine einladung

**2025-11-25 10:33:55** - Julia:
> passt, done!

**2025-11-25 10:36:40** - Florian Listl:
> wieso fehlt bei vielen das Engagement?

**2025-11-25 10:37:31** - Florian Listl:
> und der deutsche elf Account fehlt oder? <https://www.tiktok.com/@elf_vonzehn?lang=en>

**2025-11-25 10:39:10** - Julia:
> da hatte ich Marie gestern erstmal nur um die wichtigsten Accounts gebeten

**2025-11-25 10:39:15** - Julia:
> Ah krass, den kannte ich auch nicht!

**2025-11-25 10:39:46** - Julia:
> Ja und dieses Dr. Jart vom Meeting gestern haben wir auch noch nicht drin

**2025-11-25 10:40:03** - Florian Listl:
> okay, dann sag Marie gern, dass sie das noch machen woll

**2025-11-25 10:40:04** - Florian Listl:
> soll

**2025-11-25 10:40:06** - Florian Listl:
> danke!!

**2025-11-25 10:44:44** - Florian Listl:
> hast du einen diligence check gemacht, dass L'Oréal wirklich im Median 2025 16k Likes haben kann? Erscheint mir auf den ersten Blick unwahrscheinlich, die haben barely 16k Views auf vielen der letzten Videos

**2025-11-25 13:45:50** - Florian Listl:
> Hey :slightly_smiling_face: danke für das hands-on sein.

Ich hab was für dich vorbereitet. Lass uns dazu gleich nochmal telefonieren.
Ich glaube voll an dein Potenzial und will dich in Zukunft stärker in Client Meetings einbeziehen mit CMOs &amp; Co.
Dafür möchte ich dich in deinen Stärken fördern und in deinen Schwächen challengen.

Deine Stärken sind mmn:
• gutes Social Verständnis
• hard working
Schwächen:
• du denkst nicht wirtschaftlich genug, das muss mehr in Richtung McKinsey, BCG &amp; Co. gehen - sonst bleibst du auf der Marketing Manager Ebene und CMOs hören dir nicht zu
• du solltest noch etwas durchsetzungsstärker werden, so ein Excel Sheet muss eine Zero-Mistake-Policy haben. Ich möchte, dass dir so etwas in Zukunft auffällt und du hart durchgreifst bei dem, der dir das geschickt hat
• ich wünsche mir, dass du noch mehr "high-level" denkst
Das sind aber alles Themen, die man gut lernen kann. Sobald du das gelernt hast, bist du nicht 10%, sondern 10x besser und kannst Pitches leiten.

Die Project instructions werden dir dabei helfen.

Zusammen machen wir einen game plan.

Lass mich gern wissen, wann du Zeit für einen Call hast :rocket:

**2025-11-25 13:58:30** - Julia:
> Hey Flo, danke dir! Also im Moment überfordert mich dieser Input noch sehr, also ja lass uns da gerne zu sprechen :smile: Ich muss jetzt allerdings mal kurz mit dem Hund raus.
Aber auch generell komme ich da wie gesagt gerade etwas an meine bisherigen "Grenzen", wie du ja merkst. Ich bin super kreativ und kann dir 100 Content Ideen/ Konzepte entwickeln die super fürs Brand Building sind; dieses analytische und pure "zahlenbasierte" ist einfach 100% neu für mich. Deshalb bin ich gerade sehr unsicher, ob ich das überhaupt kann? Also für mich ist es super schwer, die für dich logischen Rückschlüsse aus den Zahlen zu ziehen. Wie zB mit dem vermeintlichen Fehler in der Excel-Tabelle: wäre mir nicht aufgefallen, weil ich damit einfach nicht vertraut bin. Ich muss hier erstmal noch das Basic Grundverständnis aufbauen gefühlt, damit ich dich da so unterstützen kann wie du es gerne hättest

**2025-11-25 14:00:46** - Florian Listl:
> klar kannst du das :slightly_smiling_face:

**2025-11-25 14:01:19** - Florian Listl:
> dann lass es uns so machen, ich zeig dir diligence checks und danach machen wir eine road map, wie du's nach und nach lernst

**2025-11-25 14:48:26** - Julia:
> okay, sehr gerne. Das klingt gut 

**2025-11-25 14:52:06** - Julia:
> also ich schau mir jetzt deine instructions in ruhe an und dann können wir gerne sprechen. Oder macht es Sinn, dass wir uns morgen einmal im Büro zusammensetzen und das alles durchgehen? Auch in Bezug auf die Estée Lauder Task?

**2025-11-25 15:01:47** - Florian Listl:
> Ja, lass uns das machen :)

**2025-11-25 16:03:48** - Julia:
> Kurze Frage: ich bin gerade dabei die TikTok Shops der Beauty Brands zu vergleichen. Geht allerdings nur für DE, für UK, US usw. hab ich keinen Zugriff bzw. wird einem der TikTok Shop nicht angezeigt. GPT sagt, mit VPN + neuem TikTok Account klappt das.
Ich hab aber keinen VPN, haben wir hierfür eine Lösung?

**2025-11-25 16:04:09** - Julia:
> + das wäre ein Thema für What to fix oder? :slightly_smiling_face:

**2025-11-25 18:13:47** - Julia:
> So, hier einmal ein Update des One Pager's (Tab: One Pager Update)
<https://docs.google.com/document/d/1SByofKhnwxNEQS8nKwrzm-wT7L5-qAubuA9JX6N6XGo/edit?tab=t.phidpfv5zl1i>

Ist noch nicht das, wo wir am Ende hin müssen aber mit meinem jetzigen Verständnis/ Skills der Status Quo, ich taste mich ran :slightly_smiling_face:
Hab natürlich deinen Input aus dem Loom Video auch einbezogen. Marie hat mich super unterstützt und gute Punkte mit reingebracht! Wir sind beide morgen im Büro, dann wäre es super, wenn wir uns das einmal zusammen anschauen. Infos zu den Super Fans kommen morgen noch

**2025-11-25 22:08:44** - Florian Listl:
> Sehr cool - und don’t worry, das wird nicht von heute auf morgen perfekt sein, aber das muss es auch nicht. Da wirst du reinwachsen :muscle:

**2025-11-26 11:30:27** - Julia:
> hier schon mal das KI Tool:
<https://higgsfield.ai/>

--&gt; Hier kauft man Credits die bei jedem Draft aufgebraucht werden

**2025-11-26 11:30:39** - Florian Listl:
> ist das auch in artlist?

**2025-11-26 11:31:14** - Julia:
> das weiß ich tbh nicht

**2025-11-26 11:34:42** - Florian Listl:
> falls nicht, kannst du Higgsfield als Firmenaccount buchen

**2025-11-26 11:34:57** - Florian Listl:
> 

**2025-11-26 11:35:05** - Florian Listl:
> wichtig ist, immer die korrekte Rechnungsadresse anzugeben

**2025-11-26 11:35:22** - Florian Listl:
> eine Sache noch: kannst du sprout kündigen? Das brauchen wir nicht mehr - dnake!

**2025-11-26 15:43:57** - Julia:
> setze ich auf die to do liste

**2025-11-26 15:46:38** - Julia:
> wie lange sollen die Lidl Videos ca. sein?
Wenn es aus mehreren Snippets bestehen soll (Close Up auf Lidl Logo auf Wohnmobil, zoom out, Karawane zu sehen, fahren los, in Hamburg rum/ Drohnenaufnahme", Leute drehen sich um "WOW", Ankunft OMR) usw. usw.

**2025-11-26 16:51:04** - Florian Listl:
> Kurz, 10-20 sek oder so, man soll vor allem checken worum es geht 

**2025-11-26 17:48:32** - Julia:
> ich hab die besprochenen Cases jetzt strukturiert und mit Proofs versehen: <https://docs.google.com/document/d/1SByofKhnwxNEQS8nKwrzm-wT7L5-qAubuA9JX6N6XGo/edit?tab=t.vxamqr41n8zq>

Für die finalen Content/ Format Ideen muss ich mich mit frischem Kopf morgen früh dran setzen – aber das geht ja bei mir schneller, als dieser One Pager :smile:

**2025-11-26 17:50:04** - Julia:
> bei One Pager 26.11.

**2025-11-26 18:00:36** - Florian Listl:
> da geht mir ja ganz das herz auf bei der Situation/ Problem/ Solution Logik :heart_eyes:

**2025-11-26 18:00:55** - Florian Listl:
> Diese Art wird long-term deinen Impact stark vergrößern

**2025-11-26 18:49:13** - Julia:
> juhu :partying_face:

**2025-11-27 11:22:05** - Julia:
> Hi! Die Content Ideen liegen jetzt auch jeweils mit ab :slightly_smiling_face:
Im nächsten Schritt erstellt ihr eh das Pitch Deck oder? Hier kann ich gerne die Content Ideen ausformulieren/ visuelle Beispiele suchen usw.

**2025-11-27 11:22:27** - Florian Listl:
> Hi, ist alles hier? <https://docs.google.com/document/d/1SByofKhnwxNEQS8nKwrzm-wT7L5-qAubuA9JX6N6XGo/edit?tab=t.vxamqr41n8zq>

**2025-11-27 11:22:55** - Julia:
> genau, bei Content Formate

**2025-11-27 11:22:58** - Florian Listl:
> danke!

**2025-11-28 09:34:31** - Julia:
> Hi Flo. FYI Ich hab Anna an Mert übergeben, weil sie bei Hisense/Gorenje viel besser unterstützen kann. Die MockUps (Zeitungsartikel wahrscheinlich, oder?) erstelle ich wenn machbar direkt mit AI, da kann sie mir nicht helfen

**2025-11-28 09:36:12** - Julia:
> Oder kannst du mir kurz sagen was du genau willst, dass sie erstellt? Ich hab keine Ahnung was ich ihr briefen soll wenn ihr scheinbar schon was besprochen habt

**2025-12-01 11:51:31** - Florian Listl:
> Hi, bitte schicke dir Higgsfield Rechnung mit korrekten Zahlungsdaten an mich via email

**2025-12-01 12:19:43** - Julia:
> Du meinst bezüglich der neuen Credits? mach ich, bisher reicht es noch

**2025-12-01 12:19:55** - Florian Listl:
> nein, ich brauche die rechnung

**2025-12-01 12:19:59** - Florian Listl:
> du hast ja schon was gekauft

**2025-12-01 12:20:07** - Florian Listl:
> bzw abo abgeschlossen :slightly_smiling_face:

**2025-12-01 12:20:27** - Julia:
> achso, ja klar. leite ich dir weiter

**2025-12-01 12:20:40** - Florian Listl:
> top, bitte mit stichwort "rechnug"

**2025-12-01 12:20:42** - Florian Listl:
> rechnung

**2025-12-01 12:20:48** - Florian Listl:
> dann geht's direkt an accounting

**2025-12-01 12:21:20** - Julia:
> alright. Hatte sie vorhin schon an Moni weitergeleitet

**2025-12-01 12:21:25** - Florian Listl:
> super

**2025-12-01 12:21:28** - Florian Listl:
> danke!

**2025-12-03 10:00:49** - Julia:
> bin im warteraum

**2025-12-04 10:14:09** - Julia:
> Hi Flo! FYI wegen morgen Büro: Mert und ich müssen morgen die ganzen Erledigungen für die Shootings am Mo/Di machen. Heißt ich kann nicht genau sagen, wann wir im Büro sind und wenn dann wahrscheinlich nur kurz um die Geräte abzuholen. Sollen wir sonst in Ruhe am Mittwoch sprechen?

**2025-12-04 10:14:53** - Florian Listl:
> Klar! Stell mir gern was ein für Mittwoch :)

**2025-12-04 10:14:56** - Florian Listl:
> Danke!!

**2025-12-05 08:25:06** - Julia:
> Hi Flo! Könntest du mir hier die Vollmacht unterschreiben? Rest fülle ich dann gleich aus. Die Ikea Bestellung läuft auf deinen Namen, sonst kann ich sie nicht abholen

**2025-12-05 08:29:06** - Florian Listl:
> Guten Morgen :) hab ich in WhatsApp geschickt, da kann Mans direkt unterschreiben 

**2025-12-05 09:07:46** - Julia:
> Vielen Dank :pray: 

**2025-12-05 16:28:42** - Julia:
> Hello! Ich müsste Batterien und Verlängerungskabel bei Amazon bestellen und würde dafür die Karte nochmals nutzen

**2025-12-05 16:28:52** - Florian Listl:
> ja passt

**2025-12-05 16:33:30** - Julia:
> hat geklappt, danke

**2025-12-15 09:53:31** - Julia:
> Guten Morgen! Für das IKEA Regal bekommen wir noch 87 € zurück, wenn wir es zurück zu IKEA bringen. Jetzt hatte ich überlegt, ob ich es BCC einfach für 100€ abkaufe, da ich tatsächlich ein Neues brauche! Ist das eine Option für dich? :slightly_smiling_face:

**2025-12-15 09:54:54** - Florian Listl:
> Dann behalt es einfach und wir hüllen den Mantel des Schweigens darüber ;)

**2025-12-15 09:55:51** - Florian Listl:
> Brauchst nicht extra 100€ zahlen

**2025-12-15 11:24:09** - Julia:
> Oh wow, dankeeeee! Das ist ja super lieb :star-struck:

**2025-12-15 14:05:46** - Julia:
> noch eine andere Frage die vorhin aufkam: gibt es denn Betriebsurlaub über Weihnachten? Oder sollen wir individuell Urlaub nehmen?

**2025-12-15 14:06:57** - Florian Listl:
> Ja, verkünden wir im All Hands, wir machen von 24.-6. Jan zu. Dieses Jahr braucht man durch die ganzen Feiertage nur 4 oder 5 Urlaubstage für 14 freie Tage, da kann jeder mal runterkommen

**2025-12-15 14:07:28** - Julia:
> Ah okay!

**2025-12-15 14:07:31** - Julia:
> danke schon mal :slightly_smiling_face:

**2025-12-15 14:07:57** - Julia:
> dann könnten wir das Laureen auch schon am Donnerstag sagen, da sie danach nämlich weg ist

**2025-12-15 14:08:19** - Florian Listl:
> passt, also gepostet werden muss natürlich trotzdem

**2025-12-15 14:08:26** - Florian Listl:
> aber grundsätzlich ist frei

**2025-12-15 14:08:38** - Julia:
> ja klar, nur wegen der Post-Produktion

**2025-12-15 14:08:50** - Florian Listl:
> passt

**2025-12-15 14:09:43** - Julia:
> hatten ihr heute gesagt, dass wir bis Ende der Woche noch ein paar Videos mit weihnachtlichem Content und für EOY cutten, das passt ja dann perfekt

**2025-12-15 14:09:50** - Florian Listl:
> top!

**2026-01-07 20:05:17** - Julia:
> Hey Flo! Ich hab gerade noch den Weihnachts-Urlaub eingetragen in clockify. War das richtig so? Wollte eben noch weiteren Urlaub für dieses Jahr eintragen, aber es sind nur 8 Tage freigeschaltet bisher

**2026-01-07 20:45:13** - Florian Listl:
> Hey :)

**2026-01-07 20:45:19** - Florian Listl:
> Sorry, das ist ein Fehler

**2026-01-07 20:45:23** - Florian Listl:
> Bin gerade im gym

**2026-01-07 20:45:30** - Florian Listl:
> Reichts dir wenn ich's mir morgen anschaue?

**2026-01-08 08:57:57** - Julia:
> Guten Morgen, ja klar kein Stress

**2026-01-08 15:37:09** - Julia:
> bin da

**2026-01-08 15:58:35** - Florian Listl:
> wir können für die Hosen und BH und so auch hautfarbene kleidung kaufen

**2026-01-08 15:59:06** - Julia:
> ja voll

**2026-01-08 15:59:43** - Julia:
> es könnte auch witzig sein, wenn man sonst einen Typ nimmt der ganz anders aussieht und quasi "Pitbull" Style ihn als SSIO verkleidet. So wie im Sommer alle (frauen und männer) als Pitbull zu den konzerten sind

**2026-01-08 15:59:58** - Florian Listl:
> haha ja

**2026-01-08 15:59:59** - Florian Listl:
> stimmt

**2026-01-08 16:00:09** - Florian Listl:
> gute idee

**2026-01-08 16:07:48** - Florian Listl:
> ich warte noch auf die SIM, dann laden wir dich mit der neuen nummer in die WA Gruppen ein :slightly_smiling_face:

**2026-01-08 16:19:23** - Florian Listl:
> ich hab Anna schon mal vorgewarnt und ihr die Idee grob erklärt

**2026-01-08 16:19:30** - Florian Listl:
> dann hast du's später leichter

**2026-01-08 17:02:40** - Julia:
> okay super danke

**2026-01-08 17:03:07** - Julia:
> Also lieber SSIO Double oder absichtlich "Normalo" den wir dann so hinstylen? das müsstest du entscheiden

**2026-01-08 17:03:51** - Florian Listl:
> SSIO double ist Prio 1, wenn das nicht geht, nehmen wir einen mit SSIOs Status und stylen ihn so

**2026-01-08 17:08:23** - Julia:
> okay

**2026-01-09 10:33:01** - Julia:
> hab kurz Meeting mit Julia &amp; Mert, wollen wir danach die next steps besprechen?

**2026-01-13 11:28:00** - Julia:
> Hi, ich bräuchte bitte noch einmal den Brandguide für Sixt

**2026-01-13 11:47:02** - Florian Listl:
> hier: <https://drive.google.com/drive/folders/18vV0u11GaZaXKAVsBTyHJvABswIA-HC2?usp=sharing>

vor allem die "brand presentation" und "SIXT guide" sind für dich relevant

**2026-01-13 11:47:17** - Florian Listl:
> in dem ordner sind auch alle schriften, logos etc.

**2026-01-13 12:16:49** - Julia:
> danke!

**2026-01-14 10:39:26** - Julia:
> noch eine Info, die Marie mir gegeben hat – das "ignorieren" wir für das Video?

**2026-01-14 11:28:34** - Julia:
> <@UNUQV5R08> ich müsste Figma wieder aktivieren. Passt das?

**2026-01-14 11:28:50** - Florian Listl:
> Ja :)

**2026-01-14 11:58:25** - Julia:
> Ich bestelle jetzt mal die Props für den Lidl Dreh – falls du hier ein paar Codes bekommst

**2026-01-14 11:59:01** - Florian Listl:
> du musst es mir nur sagen, ich bekomme keine codes, das ist eine auth app

**2026-01-14 11:59:09** - Julia:
> ah okay!

**2026-01-14 12:07:53** - Julia:
> jetzt

**2026-01-14 13:07:25** - Julia:
> hab jetzt den 2. Teil bei Amazon bestellt

**2026-01-14 15:19:19** - Julia:
> ich reaktiviere gerade figma

**2026-01-14 15:19:38** - Julia:
> da solltest du etwas aufs handy bekommen

**2026-01-14 15:19:38** - Florian Listl:
> wichtig: bitte immer auf richtige rechnungsstellung etc achten

**2026-01-14 15:19:46** - Florian Listl:
> wieso?

**2026-01-14 15:19:53** - Florian Listl:
> über welche email machst du's?

**2026-01-14 15:20:05** - Julia:
> 

**2026-01-14 15:20:10** - Julia:
> hab ich. auch VAT etc.

**2026-01-14 15:20:11** - Florian Listl:
> ah

**2026-01-14 15:20:18** - Julia:
> clients als mail

**2026-01-14 15:20:28** - Florian Listl:
> super, danke!

**2026-01-14 15:20:32** - Florian Listl:
> ist freigegeben

**2026-01-14 15:20:47** - Julia:
> oh wurde abgelehnt

**2026-01-14 15:20:56** - Florian Listl:
> dann mach paypal

**2026-01-14 15:21:22** - Julia:
> gibts leider nicht, nur SEPA-lastschrift

**2026-01-14 15:21:59** - Florian Listl:
> okay:
*Bold Creators Club GmbH*
*IBAN:* DE04 1001 0010 0951 4921 04
*SWIFT (BIC):* PBNKDEFF
*Bank:* FYRST – ein Angebot der Deutschen Bank

**2026-01-14 15:22:44** - Julia:
> danke, ich probiers!

**2026-01-14 15:22:49** - Florian Listl:
> gerne

**2026-01-14 15:26:34** - Julia:
> okay, sollte geklappt haben. Da war dauernd ein Bug

**2026-01-14 19:02:54** - Florian Listl:
> oh cool sind diese ganzen naruto videos von uns? weißt du wer aus dem team die gemacht hat? sieht richtig cool aus!

**2026-01-15 08:15:38** - Julia:
> Guten Morgen, nee weiß ich leider nicht! 

**2026-01-15 14:41:24** - Florian Listl:
> <mailto:florian@boldcreators.club|florian@boldcreators.club>
eSbB15@55&lt;,q

**2026-01-15 15:58:23** - Julia:
> Also tatsächlich klappt es nicht. Mir fehlt die normale SIM-Pin aus 4 Ziffern. Steht leider auch nirgends im Konto. normalerweise so wie ich das noch kenne, kommt das auch mit der Post

**2026-01-15 16:08:26** - Julia:
> ich muss jetzt los und die restlichen sachen einkaufen und alles vorbereiten. Wenn du morgen früh kurz Zeit hast, könnten wir das ja zusammen machen? Du bekommst dann nämlich auf deine Mail adresse einen code, glaube ich hab einen Trick gefunden

**2026-01-15 16:11:45** - Florian Listl:
> Hey :)

**2026-01-15 16:12:05** - Florian Listl:
> Das ist ja nervig 

**2026-01-15 16:12:11** - Florian Listl:
> Bin heute oder morgen available!

**2026-01-16 09:35:41** - Florian Listl:
> Hey :slightly_smiling_face: Wann machen wir's? Du brauchst ja das Handy

**2026-01-16 09:35:50** - Florian Listl:
> wichtig ist, dass du heute in alle Gruppen hinzugefügt wirst

**2026-01-16 09:41:56** - Julia:
> Hi! hast du jetzt Zeit?

**2026-01-16 09:42:02** - Florian Listl:
> ja :slightly_smiling_face:

**2026-01-16 09:42:10** - Florian Listl:
> 

**2026-01-16 10:17:20** - Julia:
> kannst du mich hiermit nochmal einladen? der Link klappt nicht

**2026-01-16 10:17:30** - Florian Listl:
> klar

**2026-01-16 10:17:54** - Florian Listl:
> done

**2026-01-16 10:19:05** - Julia:
> perfekt danke

**2026-01-20 12:22:00** - Julia:
> wegen sprout: da werden sie sich bei dir melden, weil du der billing address Kontakt bist

**2026-01-27 13:01:39** - Florian Listl:
> Danke! :slightly_smiling_face:

**2026-01-27 13:02:09** - Florian Listl:
> Kurze Frage: ich hab 2 spannende Themen für dich, MINI (für diese Woche), und Pepsi (nächste Woche), können wir dazu heute kurz sprechen?

**2026-01-27 13:03:57** - Florian Listl:
> bei MINI steht schon sehr viel, aber ich bin mit den Ideen noch nicht happy, da sollten wir nochmal sprechen

**2026-01-27 13:06:12** - Florian Listl:
> ich kann immer außer 16-17:30 und 18-21 uhr

**2026-01-27 13:16:20** - Julia:
> Hello! Ja, passt es dir um 15 Uhr?

**2026-01-27 13:16:25** - Florian Listl:
> super!

**2026-01-27 14:55:39** - Julia:
> Können wir 15.15 machen?

**2026-01-27 14:55:43** - Florian Listl:
> klar

**2026-01-27 14:55:47** - Julia:
> okay, danke!

**2026-01-27 14:55:53** - Florian Listl:
> Marie nehm ich auch mit

**2026-01-27 14:55:57** - Florian Listl:
> die war ja bei MINI

**2026-01-27 14:56:01** - Florian Listl:
> soll dir helfen :slightly_smiling_face:

**2026-01-27 14:56:05** - Julia:
> perfekt

**2026-01-28 11:54:06** - Julia:
> Hello!

**2026-01-28 11:54:12** - Julia:
> ich antworte die gleich in whatsapp

**2026-01-28 11:54:12** - Florian Listl:
> hey :slightly_smiling_face:

**2026-01-28 11:54:19** - Florian Listl:
> easy

**2026-01-28 11:54:33** - Julia:
> Aber kurz hier weil Jana parallel super stresst und wir im SIXT meeting sitzen :smile:

**2026-01-28 11:54:41** - Florian Listl:
> oh nein

**2026-01-28 11:54:44** - Florian Listl:
> tut mir leid

**2026-01-28 11:55:13** - Julia:
> Die Videos/ MockUps für den Workshop werden nicht bis morgen alle fertig. ich bin dran aber das dauert einfach. Zudem die Ideen auch teilweise noch nicht final sind

**2026-01-28 11:55:29** - Julia:
> Also damit du schon mal weißt, ich bin dran aber ich kann das nicht bis morgen alles fertig machen

**2026-01-28 11:55:39** - Florian Listl:
> okay verstehe ich, dann lass es uns ganz pragmatisch machen

**2026-01-28 11:55:48** - Florian Listl:
> lass uns schauen, dass man die ideen so gut wie möglich erkennen kann

**2026-01-28 11:55:55** - Florian Listl:
> was fertig wird, wird fertig

**2026-01-28 11:56:06** - Florian Listl:
> was nicht, formulieren wir für morgen textlich aus

**2026-01-28 11:56:13** - Florian Listl:
> damit man sich was darunter vorstellen kann

**2026-01-28 11:56:20** - Julia:
> okay

**2026-01-28 11:56:21** - Julia:
> ja gerne

**2026-01-28 11:56:29** - Julia:
> ich kläre es mit Marvin und Jana

**2026-01-28 11:56:33** - Florian Listl:
> super, danke! :slightly_smiling_face:

**2026-01-28 11:56:43** - Florian Listl:
> Lass dich von Jana nicht stressen :slightly_smiling_face:

**2026-01-28 11:57:02** - Julia:
> Ne, wollte es nur mit dir absprechen bevor es wieder hin und her geht

**2026-01-28 11:57:11** - Florian Listl:
> wir brauchen deine :sparkles:Creative Energy:sparkles:

**2026-01-28 11:57:15** - Florian Listl:
> da hilft stress nicht :smile:

**2026-01-28 11:57:18** - Florian Listl:
> top, danke!

**2026-01-28 12:01:03** - Julia:
> danke!

**2026-01-28 12:02:04** - Julia:
> ich hatte jetzt love is blind soweit fertig und es basti zum schnitt gegeben:
<https://app.asana.com/1/1199360402832734/project/1211046662010247/task/1212991424663406?focus=true>

Das für alle anderen Ideen ist zu aufwendig bis morgen. Aber ich spreche gleich mit dem Team

**2026-01-28 12:02:14** - Florian Listl:
> geil!

**2026-01-28 12:03:59** - Florian Listl:
> ist super geworden - für das Meeting würde ich noch einen Screenshot mit den sprechenden Gegenständen einbauen.

Weil der Golf mit Mund und augen wäre super

**2026-01-28 12:04:06** - Florian Listl:
> ist aber für's Mockup nicht nötig

**2026-01-28 12:04:16** - Florian Listl:
> SIXT wird sehr happy sein, dass wir schon so weit sind

**2026-01-28 12:04:25** - Florian Listl:
> und es passt super zu tagesaktuell

**2026-01-28 12:06:00** - Florian Listl:
> Ich würde es sogar größer machen und sagen, dass wir in Zukunft öfter aktuelle Shows parodieren könnten

**2026-01-28 12:06:15** - Julia:
> welche Gegenstände meinst du?

**2026-01-28 12:06:18** - Florian Listl:
> weil LiB ist glaube ich schon vorbei

**2026-01-28 12:06:57** - Florian Listl:
> <https://www.tiktok.com/@wenndingereden/video/7593424277815201046>

**2026-01-28 12:07:00** - Florian Listl:
> das hier

**2026-01-28 12:07:15** - Julia:
> aso ja, das ist ja eine andere Idee nochmal!

**2026-01-28 12:07:44** - Florian Listl:
> genau, aber es wäre cool, wenn das auto mimik hat, so checkt man leichter dass es spricht

**2026-01-28 12:08:32** - Julia:
> achso meinst du

**2026-01-29 09:57:29** - Julia:
> Hello! Wir hatten da schon mal drüber gesprochen aber ich weiß es gerade nichtmehr, ob ich die selbst irgendwo her bekomme oder du mir das zu schickst. Ich hab eben meine Lohnabrechnung von Januar bekommen, mir fehlen noch die von Nov, Dez und diese Anmeldung zum Jobstart. Soll ich Julia Hillmaier danach fragen?

**2026-01-29 10:00:28** - Florian Listl:
> Hi Juli, frag gerne Fr Hillmaier für die Monate, wenn du die files jetzt brauchst. Wir haben in der Zwischenzeit Datev Arbeitnehmer Online aufgesetzt. Du solltest in den nächsten Tagen Post bekommen mit dem verification code.

Mit AO ist alles was Arbeitnehmer Dokumente angeht fully self service 
 

**2026-01-29 10:00:44** - Florian Listl:
> Heißt du bist nicht mehr darauf angewiesen, dass irgendjemand dir etwas schickt 

**2026-01-29 10:01:12** - Florian Listl:
> Aber wie gesagt, es braucht ein paar Tage bis der Code bei dir ist. Wenn du's jetz brauchst, schreib am besten der Hillmaier

**2026-01-29 10:01:13** - Julia:
> Okay passt

**2026-01-29 10:01:24** - Julia:
> Ja super, das kenne ich. Danke!

**2026-01-29 15:46:48** - Florian Listl:
> Top

**2026-01-29 17:51:23** - Julia:
> wegen MINI: Marie und ich haben ein paar Ideen ausformuliert. Ich schaff es allerdings nichtmehr das noch viel weiter zu spinnen bzw. hübsch zu visualisieren. Ich gliedere das Dokument für morgen noch, aber ich würds dir morgen eher mal "erzählen" als 1. Schritt. Passt das?

**2026-01-29 17:51:36** - Florian Listl:
> passt!

**2026-01-30 16:30:46** - Julia:
> <https://docs.google.com/document/d/1NEnlqXtQv5wCwQTJwg87O0flVR4dX0z-fwHf1-nqxH8/edit?tab=t.y41r0wyaqkw6>

**2026-01-30 16:45:52** - Florian Listl:
> 

**2026-02-02 09:48:59** - Julia:
> Hello! Ich kann die MINI Präsi leider nicht öffen, scheint "kaputt" zu sein

**2026-02-02 09:49:19** - Florian Listl:
> okay, ich schick dir einen google drive link, moment

**2026-02-02 09:50:48** - Florian Listl:
> lädt gerade hoch: <https://drive.google.com/drive/folders/16Jx-rZqfS_9qMDRbIcRmxOAPJQmN8TNd?usp=sharing>

**2026-02-02 09:51:44** - Julia:
> danke!

**2026-02-02 09:51:56** - Florian Listl:
> ist hochgeladen :slightly_smiling_face:

**2026-02-02 09:53:52** - Julia:
> Ne klappt irgendwie nicht

**2026-02-02 09:54:16** - Florian Listl:
> kannst du's einfach downloaden?

**2026-02-02 09:54:32** - Florian Listl:
> in slides würde ich eh nichts bearbeiten, die software ist nicht gut genug+

**2026-02-02 09:55:23** - Julia:
> bisher noch nicht. ich probier es gleich nach meinem Call

**2026-02-02 09:55:30** - Florian Listl:
> okay top

**2026-02-02 09:58:06** - Florian Listl:
> sonst ist hier der Link via wetransfer <https://we.tl/t-BuPZm1OE5G>

**2026-02-02 10:12:41** - Julia:
> ja so klappt es

**2026-02-02 10:13:32** - Julia:
> danke!

**2026-02-02 10:13:53** - Julia:
> der Workshop bei SIXT findet schon statt oder?

**2026-02-02 10:14:03** - Julia:
> Weil wir die Präsi ja immernoch nicht haben (fertig haben)

**2026-02-02 10:14:03** - Florian Listl:
> ja, wir beide sind vor ort

**2026-02-02 10:14:09** - Florian Listl:
> zugspitzstraße 1, pullach

**2026-02-02 10:14:21** - Florian Listl:
> ja - ich hab Jana schon geschrieben, um 11 schickt sie's

**2026-02-02 10:14:41** - Julia:
> ah okay, super

**2026-02-02 10:15:14** - Julia:
> passt, ich muss noch schauen wie ich am besten hinkomme mit dem Streik

**2026-02-02 10:16:45** - Florian Listl:
> okay, passt! ich bin in mittersendling, von da könnte ich dich mitnehmen

**2026-02-02 10:25:01** - Julia:
> da komme ich auch irgendwie nicht hin :smile: aber danke. Alles gut, ich find einen weg. Wann sollen wir uns dort treffen 14.45?

**2026-02-02 10:25:34** - Florian Listl:
> super! 14:45 klingt gut

**2026-02-02 11:42:14** - Julia:
> Ist Marie heute nicht da? Oder hab ich das falsch im Kopf?

**2026-02-02 11:42:41** - Florian Listl:
> nein, die hat gebeten, dass sie heute für ihre arbeit lernen kann

**2026-02-02 11:42:51** - Florian Listl:
> sie ist morgen früh wieder da

**2026-02-02 11:43:01** - Julia:
> ahh okay, schade! :smile:

**2026-02-02 11:43:03** - Julia:
> danke

**2026-02-02 11:43:23** - Florian Listl:
> sorry :disappointed: sie hat gestern gefragt und ich wollte dich am we nicht stören

**2026-02-02 11:44:17** - Julia:
> alles gut, ich hab mich nur gewundert, dass sie mir nicht antwortet :slightly_smiling_face: hatte ihr am Freitag 2 Tasks gegeben und wollte dazu heute sprechen

**2026-02-02 13:00:54** - Florian Listl:
> hey, ich hätte gern dass ein werki noch 5 decathlon t shirts holt für morgen, welche größe passt bei dir?

**2026-02-02 13:01:08** - Florian Listl:
> musst dich um nichts kümmern, ich brauche nur die größe

**2026-02-02 13:01:53** - Julia:
> Haha okay

**2026-02-02 13:02:01** - Julia:
> XS/S

**2026-02-02 13:02:45** - Florian Listl:
> top, danke!

**2026-02-02 20:38:47** - Julia:
> Ich hab hier unsauber mitgeschrieben – hier wolltest du einfach 3 Bilder wie diese Challanges erarbeitet werden oder?

**2026-02-02 20:39:19** - Florian Listl:
> Genau

**2026-02-02 20:39:41** - Julia:
> okay passt, danke für die schnelle Antwort!

**2026-02-02 20:39:45** - Florian Listl:
> Middle finger ist cool

**2026-02-02 20:39:50** - Florian Listl:
> Regel 6

**2026-02-02 20:40:09** - Florian Listl:
> 37 ist cool, also Rallye 

**2026-02-02 20:40:32** - Florian Listl:
> Und 2 kann man glaube ich noch gut darstellen

**2026-02-02 20:40:38** - Florian Listl:
> 1 ist bisschen ausgelutscht

**2026-02-02 20:40:51** - Julia:
> ja passt, brief ich eben ein

**2026-02-03 12:43:08** - Julia:
> FYI – eben gesehen, wurde gebucht

**2026-02-04 10:55:50** - Florian Listl:
> super! Danke

**2026-02-09 09:40:01** - Julia:
> Hi Flo, hoffe dir geht’s gut! Ich bin etwas fitter aber noch immer nicht gesund und hab wieder diesen schlimmen Husten bekommen jetzt. Ich hab leider noch keine Antwort vom Arzt, warte da nur drauf. Ich brauch heute auf jeden Fall noch den Tag und meld sobald ich mehr weiß :crossed_fingers:

**2026-02-09 09:41:01** - Florian Listl:
> Okay, gute Besserung! Ich drück die Daumen, dass es bald wieder aufwärts geht!

**2026-02-09 11:21:11** - Julia:
> danke!!

**2026-02-16 13:50:39** - Julia:
> Hi! :slightly_smiling_face: würde es dir um 4 passen? Dann stell ich uns kurz was ein

**2026-02-16 13:58:13** - Florian Listl:
> Nachmittag ist recht voll 

**2026-02-16 13:58:19** - Florian Listl:
> Lass uns jetzt gleich sprechen

**2026-02-16 13:58:22** - Florian Listl:
> Ich ruf dich an

**2026-02-16 14:02:02** - Julia:
> okay


---

## Marie Gottschall (485 messages)

**Julia sent:** 259 | **Marie Gottschall sent:** 226

**Folder:** `D09TPJ3GMSN`

**2025-11-24 10:31:09** - Marie Gottschall:
> Hi Juli :slightly_smiling_face: Flo meinte ich soll dich mal anrufen und fragen, ob ich dich irgendwie unterstützen kann

**2025-11-24 10:31:26** - Marie Gottschall:
> Hast du kurz Zeit?

**2025-11-24 10:33:39** - Julia:
> Hello! Ich bin im Meeting, melde mich danach :slightly_smiling_face:

**2025-11-24 10:34:26** - Marie Gottschall:
> Alles klar :slightly_smiling_face:

**2025-11-24 11:48:55** - Julia:
> So, hat etwas länger gedauert

**2025-11-24 11:51:06** - Marie Gottschall:
> Kein Problem :slightly_smiling_face:

**2025-11-24 11:51:45** - Marie Gottschall:
> 

**2025-11-24 12:00:38** - Marie Gottschall:
> Hey sorry nochmal mir ist gerade aufgefallen, dass in den Daten nirgends die Views sind, aber ich kann dir wenn du willst den Median von der Post Engagement Rate geben

**2025-11-24 12:20:30** - Julia:
> ja dann gerne die, danke dir!

**2025-11-24 12:28:11** - Julia:
> 

**2025-11-24 12:38:45** - Marie Gottschall:
> Mega mega gerne aber ich kann leider am 5.12. nicht :smiling_face_with_tear:

**2025-11-24 12:39:37** - Marie Gottschall:
> Also der Freitag oder? Weil du einmal kurz Montag erwähnt hast?

**2025-11-24 12:40:43** - Julia:
> Sorry, Freitag genau!

**2025-11-24 12:40:53** - Julia:
> schade aber alles gut

**2025-11-24 12:42:29** - Marie Gottschall:
> Aber sonst mega gerne wenn sonst ein Shooting geplant wird :relaxed: Würde das gerne mal live erleben

**2025-11-24 12:43:17** - Marie Gottschall:
> Die Engagement Rate ist jetzt übrigens in der Excel eingetragen sag Bescheid wenn du noch die von anderen Brands brauchst

**2025-11-24 12:44:04** - Marie Gottschall:
> Hast du sonst noch etwas für mich zum unterstützen? Sonst würde ich Flo fragen ob er etwas hat

**2025-11-24 12:45:30** - Julia:
> klar, mach ich. wir haben jetzt eh einige geplant

**2025-11-24 12:45:39** - Julia:
> super, danke! schau ich mir an

**2025-11-24 12:46:15** - Julia:
> gib mir kurz 5 Minuten, ich organisiere kurz die Tasks

**2025-11-24 12:46:22** - Julia:
> melde mich gleich :slightly_smiling_face:

**2025-11-24 12:49:47** - Marie Gottschall:
> 

**2025-11-24 12:50:33** - Marie Gottschall:
> moment mein micro geht gerade nicht

**2025-11-24 12:50:36** - Marie Gottschall:
> 

**2025-11-24 12:50:49** - Julia:
> alles gut

**2025-11-24 12:52:02** - Julia:
> <https://docs.google.com/presentation/d/1rbYB7aLiZwdcgXMezmgL1kWXM0APEyGw64nXlBrXhpY/edit?slide=id.g3a64d1ec782_0_33#slide=id.g3a64d1ec782_0_33>

**2025-11-24 12:57:19** - Julia:
> Hisense – Produktfokus (2025–2026)
*TV*
• RGB-TV
*Laser TV*
• PT1 (2025–2026)
• 
*Cooling*
• Crossdoor mit Ice Maker (RQ5P640SYKD / RQ5P470SYID / RQ5P470SYFD)
• 
• Crossdoor Smart Fridge (VIDAA Update) – TBD
• 
• KitchenFit (Q1 2026)
• 
• PureView Serie (Q3–Q4 2026)
• 
*Laundry*
• 5s (bis Q2 2026)
• 
• 3i (Q1 2026) + 5i (Mitte 2026)
• 
*Cooking*
• Einbaugeräte (XXXLutz, Q2 2026)
• 
*SDA*
• Mikrowelle (Inverter without Plate)
• 

Gorenje – Produktfokus (2025–2026)
*Cooling*
• KitchenFit (Q1 2026)
• 
*Laundry*
• Neue G600 Serie (2026)
• 
*Cooking*
• Pizzaofen &amp; Pizzaofen Matt (2026)
• 
• GEH8433BSRWF (Q2 2026)
• 
• GI6433SRWF
• 
*Dishwasher*
• GV16B
• 
• GV561C10 (Q2 2026)
• 
*SDA*
• Staubsauger NEO Series (Dez 2025)


**2025-11-24 15:41:08** - Julia:
> kurze Rückfrage zum Median Post Engagement Wert: das ist auch pro Beitrag, oder?

**2025-11-24 15:47:21** - Marie Gottschall:
> genau der ist pro Beitrag angegeben und ich hab dann von allen Posts aus 2025 den Median gerechnet

**2025-11-24 15:49:45** - Marie Gottschall:
> Ich hab jetzt btw ein paar Creator auf der Präsentation hinzugefügt du kannst ja mal drüber schauen ich denke du hast da mehr Gespür dafür ob die zur Marke passen oder ob ich auf einer ganz falschen Fährte bin :sweat_smile: Tech Influencer finde ich selbst super schwierig weil ich da auch keine kenne die passen würden.

**2025-11-24 15:50:16** - Marie Gottschall:
> Gib mir gern kurzes Feedback ob das so passt oder was ich noch verbessern könnte :slightly_smiling_face:

**2025-11-24 15:53:20** - Julia:
> super danke dir :slightly_smiling_face:
Kann sein, dass wir für eine Präsentation (wenn es soweit kommt) dann noch mehr Daten benötigen, aber da geben wir Bescheid

**2025-11-24 15:53:52** - Julia:
> Cool danke dir!

**2025-11-24 15:54:09** - Julia:
> ich übergebe hier schnell an meinen Kollegen Mert, da ich gleich wieder im Meeting bin

**2025-11-24 15:54:32** - Marie Gottschall:
> Alles klar wir haben ja die Daten alle noch im Drive Ordner sag dann einfach Bescheid :slightly_smiling_face:

**2025-11-24 15:55:03** - Marie Gottschall:
> Alles klar :slightly_smiling_face:

**2025-11-25 10:42:59** - Julia:
> Hello! Gerne den noch hinzufügen. In unserem Meeting mit EL kam noch die Marke Dr. Jart auf – benötigen wir auch noch in unserer Tabelle (Global und DE)

+ Flo hätte gerne noch die restlichen fehlenden Engagement Rates
Danke dir :slightly_smiling_face:

**2025-11-25 10:44:26** - Marie Gottschall:
> ich kümmer mich drum :slightly_smiling_face:

**2025-11-25 11:19:05** - Marie Gottschall:
> done :relaxed:

**2025-11-25 11:19:24** - Marie Gottschall:
> Brauchst du für Dr. Jart auch die Power User?

**2025-11-25 11:30:44** - Marie Gottschall:
> Das habe ich übrigens auch mal erstellt damit man einen Überblick hat welche Marken zur Estée Lauder Group gehört in welche Kategorie welche Marke fällt. Vielleicht auch hilfreich für dich/euch :slightly_smiling_face:

**2025-11-25 12:59:28** - Julia:
> Hello! :slightly_smiling_face: Hatte einen längeren Call mit Flo – meld dich gerne, wenn du Zeit hast, es gibt ein paar offene To Do's

**2025-11-25 13:09:09** - Marie Gottschall:
> 

**2025-11-25 13:10:42** - Marie Gottschall:
> Bin jetzt wieder erreichbar ruf einfach an wenn du kannst :slightly_smiling_face:

**2025-11-25 13:15:28** - Julia:
> hab dir einen invite geschickt!

**2025-11-25 13:40:13** - Julia:
> <https://docs.google.com/document/d/1SByofKhnwxNEQS8nKwrzm-wT7L5-qAubuA9JX6N6XGo/edit?tab=t.0>

**2025-11-25 14:21:11** - Marie Gottschall:
> Hab die Liste jetz aktualisiert und nochmal gecheckt. Flo hatte recht bei loreal stand der Average drin statt der Median. Ich hab das angepasst und die anderen auch nochmal gegengecheckt.

**2025-11-25 14:23:27** - Marie Gottschall:
> Mit den neuen Daten fällt auf dass die deutschen Kanäle von elf und von maybelline mehr Views bzw. Plays generieren. Damit könnte man vielleicht etwas aufbauen! Ich schau mir mal deren Superfans an :slightly_smiling_face:

**2025-11-25 14:52:14** - Julia:
> ach super, danke dir!

**2025-11-25 14:52:41** - Julia:
> als die Global Accounts meinst du? sehr cool!

**2025-11-25 14:53:05** - Marie Gottschall:
> genau :slightly_smiling_face:

**2025-11-25 14:53:54** - Marie Gottschall:
> Flo meinte auch gerade wir nehmen dann die Average Daten, weil da maybelline DE besser ist als der globale Account

**2025-11-25 14:54:03** - Julia:
> ja das macht voll Sinn

**2025-11-25 14:54:45** - Julia:
> Bezüglich: Elf, das ist wirklich interessant! Lass uns aber gerne bei etwas "hochwertigeren" Marken bleiben für die Super Fans vorallem. Elf ist doch eher etwas zu "locker" im Vergleich zu Mac

**2025-11-25 14:56:23** - Marie Gottschall:
> Okay :slightly_smiling_face: Die haben eh erst wenige Videos online und Flo meinte grad auch noch, dass der deutsche Account sehr viel Paid gemacht haben also eher etwas irrelevant ist

**2025-11-25 15:06:13** - Julia:
> ja genau, das hab ich auch gesehen

**2025-11-25 15:09:56** - Julia:
> ich fuchse mich jetzt mal in das thema tiktok shop

**2025-11-25 15:44:17** - Marie Gottschall:
> Ich hab mir jetzt mal ein bisschen den Inhalt angesehen vom Account und hab ein paar Probleme bzw. Potential herausgefunden. Ich trag sie mal ein :slightly_smiling_face:

**2025-11-25 15:46:06** - Marie Gottschall:
> Btw gib gerne jederzeit Feedback wenn etwas nicht so passt oder du anderer Meinung bist! Ich will ja etwas von euch lernen und bin vor allem am Anfang immer sehr unsicher, weil ich noch nicht so in den Themen und Workflows drin bin und krieg da gerne auch mal kritisches Feedback damit ich weiß was ich nächstes mal besser machen kann :relaxed:

**2025-11-25 15:47:55** - Julia:
> das mach ich sehr gerne! Wie gesagt in diesem analytischen/ zahlenbasierten Fakten bin ich auch eher Newbie. Aber das schaffen wir zusammen :slightly_smiling_face:
Bist du morgen zufälligerweise im Büro? Ich komme rein und gehe alles einmal in Ruhe mit Flo durch

**2025-11-25 15:48:19** - Julia:
> Wird auch Zeit, dass wir unser Vorstellungsmeeting dann haben, dann wissen wir auch mehr wer was macht und wo die Expertisen liegen

**2025-11-25 15:51:33** - Marie Gottschall:
> Yes bin morgen im Büro aber wie gesagt nur bis 14:30 Uhr aber freu mich wenn du morgen auch da bist :slightly_smiling_face:

**2025-11-25 15:52:20** - Marie Gottschall:
> Ja bis jetzt habe ich nur dich und Basti im Büro gesehen, deswegen ist es auch schwer einzuordnen, wen ich was fragen kann aber das wird sich bestimmt bald klären :relaxed:

**2025-11-25 15:53:11** - Julia:
> perfekt, dann sehen wir uns!

**2025-11-25 15:53:33** - Julia:
> ja kann ich mir vorstellen. wurden ja auch direkt ins Projekt gekippt :slightly_smiling_face: dann machen wir morgen in Ruhe die Vorstellung

**2025-11-25 15:54:23** - Julia:
> BTW: Mert meldet sich bei dir bezüglich einer Task, bei der wir gerne Unterstützung benötigen

**2025-11-25 16:20:22** - Julia:
> gute beobachtungen! :slightly_smiling_face: ich hab auch noch ein paar dinge, ich trag alles einmal zusammen

**2025-11-25 16:43:46** - Julia:
> eine Frage zu deiner These:
_Sehr niedrige Median Plays (923) im Vergleich zu Wettbewerbern_
• _- maybelline_de: 19.400_
• _- nyxcosmetics_de: 2.566_
• _- benefitgermany: 2.027_
 _→ Algorithmus verteilt kaum Reichweite, Inhalte gelangen nicht in die For You Page._

Du meinst hier, dass die Median Plays so gering sind, weil der Mac DE Account zB nicht hauptsächlich deutschsprachig ist?

**2025-11-25 16:46:09** - Marie Gottschall:
> also dadurch das maybelline und auch nyx sehr creator lastig sind und auch eigentlich komplett deutschlastig glaube ich schon daran dass es hauptsächlich daran liegt

**2025-11-25 16:46:32** - Julia:
> ja verstanden

**2025-11-25 16:47:02** - Julia:
> sehe ich auch so. MAC DE springt ja dauernd zwischen deutsch &amp; englisch

**2025-11-25 16:47:36** - Marie Gottschall:
> mir persönlich werden ja auch fast nur beauty videos in deutsch angezeigt und die creator schaffen es halt meiner meinung nach mehr auf die foryou page als brand accounts

**2025-11-25 16:49:01** - Marie Gottschall:
> ich habe btw gerade noch schwierigkeiten die super user von maybelline de herauszufinden weil die so viele Videos haben und er download immer wieder abbricht weil das budget verbraucht ist :confused:

**2025-11-25 16:55:42** - Julia:
> ah mist, wie ärgerlich

**2025-11-25 17:08:40** - Julia:
> ich fasse gerade unsere Notizen zusammen auf der 1. Seite FYI

**2025-11-25 17:47:40** - Marie Gottschall:
> super danke :slightly_smiling_face:

**2025-11-25 17:48:24** - Marie Gottschall:
> Ich habe jetzt endlich die Super User vom deutschen maybelline Account herausbekommen und hab sie in das Dokument vom letzten Mal kopiert

**2025-11-25 17:49:00** - Marie Gottschall:
> Ich würd jetzt dann allerdings Feierabend machen. Reicht es, wenn ich morgen früh analysiere, was die Super User dort ausmacht?

**2025-11-25 17:51:37** - Marie Gottschall:
> Wann sprichst du morgen mit Flo? Weil sonst können wir uns morgen früh auch nochmal zusammensetzen und realistische Ziele ausarbeiten, die du dann Flo teilen kannst :slightly_smiling_face:

**2025-11-25 17:53:02** - Julia:
> perfekt, schaue ich mir an

**2025-11-25 17:53:08** - Julia:
> klar mach das

**2025-11-25 17:54:01** - Julia:
> alles gut, keinen Stress. Ich schau was ich heute noch schaffe und dann können wir uns das morgen früh gerne zusammen im Büro direkt anschauen

**2025-11-25 17:56:04** - Marie Gottschall:
> Supi dann bis morgen :relaxed:

**2025-11-25 17:56:14** - Julia:
> Happy feierabend! danke dir für deine Hilfe :slightly_smiling_face:

**2025-12-01 10:20:00** - Julia:
> Guten Morgen! :slightly_smiling_face: Sobald du da bist, benötige ich einmal deine Hilfe

**2025-12-01 10:32:23** - Marie Gottschall:
> Morgen :slightly_smiling_face: Bin jetzt online sollen wir kurz telefonieren?

**2025-12-01 10:36:23** - Julia:
> Ich bin gerade im Meeting, evtl. schaffe ich es zwischen den 2 Meetings. Ich melde mich asap

**2025-12-01 11:03:57** - Marie Gottschall:
> 

**2025-12-01 11:05:33** - Julia:
> Sind die Daten von TikTok shop auch schon drin?
Wie viel revenue man mit wie vielen followern/ Median views macht
Dass wir da eine kausalität suggerieren

**2025-12-01 11:05:47** - Julia:
> Sonst wie besprochen Fokus auf den MAC case mit Beispielen und Zahlen, va. Bzgl TikTok shop und Zusammenhang mit followern und Live Zuschauern. Danke!!

**2025-12-01 11:32:09** - Julia:
> wie gesagt, wenn du hier auch nicht weiter kommst, dann schreiben wir Flo und er hat bestimmt ein paar Minuten Zeit sich das mit uns anzuschauen

**2025-12-01 11:33:58** - Marie Gottschall:
> Ja ich finds super schwierig weil der Tiktok Shop wirklich nicht viel aussagt

**2025-12-01 11:35:38** - Julia:
> ja versteh ich

**2025-12-01 11:36:50** - Marie Gottschall:
> Ich erkenne da auch bis jetzt noch kein Muster. Weißt du ob wir da irgendwie BCC interne Daten haben, wo der Tiktok Shop eventuell schon eingebunden wurde?

**2025-12-01 11:37:01** - Julia:
> ne weiß ich leider nicht

**2025-12-01 11:37:49** - Julia:
> Wenn du grad kannst, mach gerne einen Chat auf mit uns 3 und schreib Flo, dass wir hier einmal seine Hilfe benötigen, weil wir hier feststecken

**2025-12-01 11:39:40** - Marie Gottschall:
> Chat GPT hat mir nur ausgespuckt wie man den Revenue berechnet und welche Komponenten dafür wichtig sind: Revenue ≈ Median Views x CTR (Click-Through-Rate) x CVR (Conversion Rate) x AOV (Average Order Value)

**2025-12-01 11:42:01** - Marie Gottschall:
> Das ist finde ich an sich ein guter Ansatz, weil dann könnte man begründen (mehr likes = mehr Umsatz). Aber ich weiß nicht woher wir die Conversion Rate bekommen und wie gesagt ist von ChatGPT also auch nicht immer das verlässlichste:sweat_smile:

**2025-12-01 11:42:06** - Julia:
> okay und kommen/ haben wir diese ganzen Daten?

**2025-12-01 11:42:26** - Julia:
> ja auf jeden Fall. Müssen es nur begründen

**2025-12-01 11:44:45** - Julia:
> hab Chat GPT auch nochmal gefragt, keine Lösung ohne direkten Zugriff auf das Profil

**2025-12-01 11:55:01** - Marie Gottschall:
> Ich hoffe das ist verständlich was ich gerade geschrieben habe haha

**2025-12-01 11:57:13** - Julia:
> ja!

**2025-12-01 12:01:53** - Marie Gottschall:
> Ich rechne jetzt mal kurz den genauen Umsatz von MAC DE und Maybelline DE aus und schreibe das alles einmal kurz in unsere Notizen damit wir alles mal in einer Zeile auf Papier haben

**2025-12-01 12:04:55** - Julia:
> super danke

**2025-12-01 12:26:02** - Julia:
> ich schick dir mal ein paar Daten – außer du hast dich auch schon eingeloggt?

**2025-12-01 12:27:30** - Julia:
> 

**2025-12-01 12:30:19** - Julia:
> 

**2025-12-01 12:31:12** - Julia:
> Mac Cosmetics DE TT Shop Sold Products:

**2025-12-01 12:31:52** - Julia:
> Maybelline DE TT Shop Sold Products:

**2025-12-01 12:32:00** - Marie Gottschall:
> ne hab mich noch nicht eingeloggt

**2025-12-01 12:32:01** - Marie Gottschall:
> dankee

**2025-12-01 12:32:54** - Marie Gottschall:
> GMV ist dann quasi Umsatz oder?

**2025-12-01 12:33:18** - Marie Gottschall:
> Jetzt hab ich das Umsonst ausgerechnet :weary:

**2025-12-01 12:33:30** - Julia:
> 

**2025-12-01 12:33:39** - Julia:
> jaaa, da gibts wirklich alle daten

**2025-12-01 12:35:56** - Julia:
> Wenn du mehr Daten benötigst, gib Bescheid :slightly_smiling_face:

**2025-12-01 12:38:21** - Marie Gottschall:
> Ich denke ich logg mich selbst mal ein. Hast du ein passwort vergeben?

**2025-12-01 12:39:20** - Julia:
> 

**2025-12-01 12:39:27** - Julia:
> <mailto:clients@boldcreators.club|clients@boldcreators.club>

**2025-12-01 12:52:35** - Marie Gottschall:
> Bin drin

**2025-12-01 12:52:46** - Marie Gottschall:
> Ist ja super spannend

**2025-12-01 12:53:30** - Marie Gottschall:
> Im Vergleich zu Maybelline macht MAC es in Sachen TikTok Shop ja sogar besser

**2025-12-01 12:55:06** - Julia:
> ja, das könnte man super umformulieren zu "Potenzial ist auf jeden Fall da und es kommt schon da, da im vergleich zu Maybelline...."

**2025-12-01 12:56:06** - Julia:
> Also alle Schlussfolgerungen die dir auffallen, gerne einmal festhalten in einem Dokument :slightly_smiling_face: danke dir!

**2025-12-01 13:15:06** - Marie Gottschall:
> Habs aufgeschrieben in unseren Notizen ganz unten

**2025-12-01 13:15:28** - Marie Gottschall:
> Soll ich noch nach etwas bestimmten suchen oder etwas herausarbeiten?

**2025-12-01 13:21:58** - Marie Gottschall:
> Schade dass man da kein Beispiel hat von jemandem der es besser hat. Da könnte man sonst viel bessere Cases aufbauen weil so wie es MAC gerade macht ist es eigentlich ganz gut

**2025-12-01 13:30:12** - Julia:
> Super schau ich mir gleich nach der Mittagspause an 

**2025-12-01 13:30:46** - Julia:
> Hast du die US Marken auch angeschaut? Evtl findet man hier ein Beispiel 

**2025-12-01 13:34:07** - Marie Gottschall:
> Stimmt schau ich mir gleich nochmal an

**2025-12-01 13:39:33** - Marie Gottschall:
> Man hat leider in dem Tool keinen Zugriff auf die amerikanischen Marken, dafür bräuchte man die Pro Version

**2025-12-01 13:40:01** - Julia:
> die können wir uns gleich für einen Monat holen 

**2025-12-01 13:42:45** - Julia:
> Bzw. sollen wir um 14.30 kurz sprechen? Passt dir das? 

**2025-12-01 13:43:24** - Marie Gottschall:
> ich bin bis 14:45 in einem Call mit Julia...

**2025-12-01 13:43:54** - Marie Gottschall:
> geht 14:45 auch? sonst frag ich sie ob wir es verschieben können

**2025-12-01 13:50:04** - Julia:
> Ja klar easy 

**2025-12-01 13:50:17** - Julia:
> Meld dich einfach danach :blush:

**2025-12-01 14:28:31** - Julia:
> okay danke schon mal für die Auswertung! Ich kann mich leider gerade nicht in den Account loggen, weil du noch angemeldet bist. Lass uns gerne gleich sprechen

**2025-12-01 14:34:34** - Marie Gottschall:
> Hab mich abgemeldet sorry dachte man kann zu zweit auch rein

**2025-12-01 14:52:33** - Marie Gottschall:
> 

**2025-12-01 15:12:16** - Julia:
> *Conversion Rate = (Anzahl der Conversions ÷ Anzahl der Besucher / Klicks / Zuschauer) × 100*
Beispiele:
*1. TikTok Shop Conversion Rate*
Wenn 2.000 Live-Zuschauer reinschauen und 80 kaufen:
```
CR = (80 ÷ 2.000) × 100 = 4 %```
*2. Video → TikTok Shop Produktseite*
Wenn ein Video 10.000 Views hat und 300 Leute auf das Produkt klicken:
```
CR = (300 ÷ 10.000) × 100 = 3 %```


**2025-12-01 15:14:32** - Marie Gottschall:
> 

**2025-12-01 15:19:39** - Julia:
> TT Shop Like CR: 0,4%

**2025-12-01 15:43:46** - Marie Gottschall:
> habs eingetragen

**2025-12-01 15:44:05** - Julia:
> super danke :slightly_smiling_face: dann kopier ich das schon mal

**2025-12-01 15:45:14** - Julia:
> ich hab gerade das hier raus bekommen:

**2025-12-01 15:45:55** - Julia:
> also könnte man sagen, wenn sich die Views auf ca. 70k erhöhen, dann XY verkaufte Produkte: XY Umsatz
oder? :smile:

**2025-12-01 15:46:38** - Marie Gottschall:
> aber das sind ja auch alles nur Annahmen oder?

**2025-12-01 15:48:23** - Julia:
> genau, das wären realistische ziele

**2025-12-01 15:48:58** - Marie Gottschall:
> okay wenn man das benutzen darf ist das ja gut

**2025-12-01 15:51:20** - Julia:
> was meinte GPT nochmal zur View to Sale Rate von 0,24% – ist das gut oder nicht gut?

**2025-12-01 15:54:02** - Marie Gottschall:
> 0,24 % liegt *im typischen Beauty-Livestream-Bereich*:
• Durchschnitt Beauty DACH: *0,2 – 0,6 %*
• Gute Lives: *0,7 – 1,2 %*
• Top Seller-Lives: *1,5 %+*
Damit könnt ihr sauber argumentieren:
• Performance ist *solide*, aber mit professionellem Setup, Hosts und aktiveren Product Callouts lässt sich die Rate *leicht verdoppeln bis verdreifachen*.


**2025-12-01 15:54:11** - Marie Gottschall:
> so hat ers mir ausgespuckt

**2025-12-01 15:55:09** - Julia:
> okay

**2025-12-01 15:56:06** - Julia:
> witzig bei mir sagt er das ist schlecht

**2025-12-01 15:56:07** - Julia:
> :smile:

**2025-12-01 15:56:22** - Marie Gottschall:
> na toll :joy:

**2025-12-01 15:57:48** - Julia:
> *Wenn MAC auf gutes Beauty-Live-Niveau kommt (2,0 %)*
→ 2 % schaffen sehr viele Marken, sobald ein Creator-Host dabei ist oder klare Live-Deals laufen.
Berechnung:
24.600 × 0.02 = *492 Verkäufe pro Live*
:arrow_right: *+423 zusätzliche Verkäufe pro Live*
 :arrow_right: *~7× mehr Verkäufe*

**2025-12-01 16:05:47** - Julia:
> ah wir haben eine falsche zahl drin

**2025-12-01 16:05:48** - Julia:
> moment

**2025-12-01 16:06:08** - Marie Gottschall:
> welche falsche Zahl?

**2025-12-01 16:07:13** - Julia:
> Proof 2: 69 Sold Units bei durchschnittlichen 24.6k Views → *View to Sale Rate: 0,28%* (zu niedrig für Beauty)

**2025-12-01 16:07:17** - Julia:
> sogar etwas höher

**2025-12-01 16:07:43** - Marie Gottschall:
> ah stimmt!

**2025-12-01 16:07:53** - Marie Gottschall:
> Gut dass es dir nochmal aufgefallen ist

**2025-12-01 16:10:48** - Julia:
> ne obwohl bei den 18k als durchschnitt stimmt das nicht

**2025-12-01 16:13:23** - Marie Gottschall:
> ist ja ein durchschnittswert

**2025-12-01 16:13:41** - Marie Gottschall:
> das ist ja immer etwas abhängig vom Event

**2025-12-01 16:14:23** - Julia:
> ja genau

**2025-12-01 16:14:30** - Julia:
> aber ich lass es wie du es schon berechnet hast

**2025-12-01 16:15:20** - Marie Gottschall:
> Ich hab ja nur das eine Event als Beispiel genommen, weil das für mich durchschnittlich aussah denkst du das passt?

**2025-12-01 16:19:25** - Julia:
> ja

**2025-12-01 16:24:22** - Julia:
> 

**2025-12-01 16:27:38** - Julia:
> so und welche Metrik hat uns jetzt nochmal gefehlt? :smile:

**2025-12-01 16:31:05** - Marie Gottschall:
> Ich glaube das ist von allen Live Events die sie jemals gemacht haben

**2025-12-01 16:34:30** - Marie Gottschall:
> 

**2025-12-01 16:35:00** - Marie Gottschall:
> 

**2025-12-01 16:35:04** - Julia:
> Ah okay verstanden

**2025-12-01 16:35:12** - Julia:
> Ja gerne!

**2025-12-01 16:35:20** - Marie Gottschall:
> 

**2025-12-01 16:35:34** - Marie Gottschall:
> 

**2025-12-01 16:36:45** - Julia:
> Würdest du das bei Proof dann direkt anpassen? :slightly_smiling_face:

**2025-12-01 16:37:08** - Julia:
> muss leider noch ein supr wichtiges Lidl Video fertig bekommen

**2025-12-01 16:37:40** - Marie Gottschall:
> wir könnten dann auch eine bessere View to Sales Rate ausrechnen also 69 Produkte/24,6k Zuschauer = 0,39%

**2025-12-01 16:38:31** - Julia:
> also wenn du kannst, pass gerne die Zahlen im Word Dokument an, das wäre mir eine riesige Hilfe gerade!

**2025-12-01 16:38:52** - Julia:
> Müssten nur vermerken welche Average Live Zahl das dann ist (nur Account selbst oder mit Creatorn)

**2025-12-01 16:41:33** - Julia:
> danke dir :heart_hands:

**2025-12-01 17:05:31** - Marie Gottschall:
> hab jetzt nochmal in Excel die Shop LIVE Daten und die Creator LIVE Daten eingefügt und das Google Doc angepasst :slightly_smiling_face:

**2025-12-01 17:05:42** - Marie Gottschall:
> sollte jetzt eigentlich so passen

**2025-12-01 17:05:54** - Julia:
> super, vielen vielen dank!

**2025-12-01 17:10:45** - Marie Gottschall:
> Kein Problem :slightly_smiling_face:

**2025-12-01 17:11:20** - Marie Gottschall:
> Ich bin gespannt was Flo dazu sagt

**2025-12-01 17:18:17** - Julia:
> ich auch

**2025-12-02 09:46:13** - Julia:
> Guten Morgen! Hoffe dir geht es gut :slightly_smiling_face:

Ich würde hier im Dokument die Zahl 2,4% auf 2% ändern. Wir haben ja die View to sale rate bei 0,39% angepasst. Da man realistisch auf 2% kommen kann, passe ich das an.

Für die restlichen Fragen von Flo, buche ich uns gleich die Pro Version, damit wir an die Zahlen kommen

**2025-12-02 09:48:37** - Marie Gottschall:
> Okay perfekt :slightly_smiling_face:

**2025-12-02 10:05:42** - Julia:
> okay haben jetzt den Zugriff :slightly_smiling_face: kommst du wieder rein?

**2025-12-02 10:09:26** - Marie Gottschall:
> Ich glaub es kann immer nur einer rein weil bei mir steht : Your account is logged in on another device.

**2025-12-02 10:09:48** - Marie Gottschall:
> Wenn ich mich einlogge schmeiß ich dich wahrscheinlich wieder raus

**2025-12-02 10:35:03** - Julia:
> true

**2025-12-02 10:35:19** - Julia:
> schau mal hier: erste Daten damit wir die Vergleiche rausziehen können:

**2025-12-02 10:40:13** - Julia:
> • MAC US: Live Zahlen für View to Sale Rate (Shop + Creator Lives)
• Elf US: Live Zahlen für View to Sale Rate
• MAC DE: User bei Live am 11.11. --> Evtl hier rausziehen wielange die Zuschauer da sind? 

**2025-12-02 10:42:50** - Julia:
> • Maybelline US &amp; L'Oreals Paris machen keine eigenen Live Events --&gt; nur Creator


**2025-12-02 10:43:31** - Julia:
> 

**2025-12-02 10:48:52** - Julia:
> Hier Beauty &amp; Personal Care monatlicher Umsatz Top TT Shops

**2025-12-02 10:49:44** - Julia:
> Würdest du Flo's Fragen einmal mit den Informationen füllen? Log dich auch gerne ein, dann springe ich raus. Danke dir! :slightly_smiling_face:
Bin ab 11.45 ca wieder erreichbar, habe jetzt das Meeting mit Hisense.

**2025-12-02 10:53:36** - Marie Gottschall:
> danke dir!

**2025-12-02 10:58:56** - Julia:
> danke DIR :slightly_smiling_face:

**2025-12-02 11:49:09** - Julia:
> Soo, kamst du schon voran und wie kann ich dir helfen?

**2025-12-02 11:49:34** - Marie Gottschall:
> Musste gerade noch was anderes fertig machen hab also noch nicht viel geschafft

**2025-12-02 11:51:05** - Marie Gottschall:
> in den excel tabellen die du geschickt hast steht ja nur die dauer von den lives und nicht die zuschauer bzw. sales

**2025-12-02 11:51:17** - Marie Gottschall:
> kann ich mich kurz einloggen oder brauchst du es gerade?

**2025-12-02 11:52:45** - Julia:
> alles gut. Ja logg dich gerne ein

**2025-12-02 11:53:49** - Julia:
> oh no, ich hatte gedacht da sind alle zahlen. hab diese bei "live" insights runtergeladen

**2025-12-02 11:55:19** - Marie Gottschall:
> Ahh Flo muss den Code bestätigen

**2025-12-02 11:55:30** - Marie Gottschall:
> dann bleib lieber du drin

**2025-12-02 11:56:04** - Marie Gottschall:
> kannst du mir kurz Screenshots schicken von den Live Analytics einmal creator und einmal shop

**2025-12-02 11:56:43** - Marie Gottschall:
> dann erweitere ich die Excel mit den Daten einfach noch für ein paar brandds

**2025-12-02 11:57:27** - Julia:
> ah mist

**2025-12-02 11:58:03** - Julia:
> ich bin auch ausgeloggt :smile:

**2025-12-02 11:58:15** - Julia:
> bist du mit Flo im Büro zufälligerweise? Evtl einfacher dann

**2025-12-02 11:58:33** - Marie Gottschall:
> ne sind heute beide im HomeOffice

**2025-12-02 11:58:55** - Marie Gottschall:
> Ich schreib ihm schnell ob er das bestätigen kann

**2025-12-02 11:59:20** - Julia:
> okay super, danke

**2025-12-02 11:59:54** - Marie Gottschall:
> oder warte er meinte ja wir sollen uns die App aufs Handy runterladen das versuch ich mal bevor wir ihn immer nerven müssen

**2025-12-02 12:00:43** - Julia:
> oder so, wenn das für dich okay ist. ich logge mich dort nicht mit meinem privaten handy ein deshalb

**2025-12-02 12:01:04** - Julia:
> dann nutze ich kurz die zeit und mache eine schnelle lunch break, bin gleich wieder da!

**2025-12-02 12:14:41** - Marie Gottschall:
> Das ist so blöd weil genau diese eine Übersicht der durchschnittlichen Zahlen fehlt bei dem amerikanischen

**2025-12-02 12:14:57** - Marie Gottschall:
> 

**2025-12-02 12:15:06** - Marie Gottschall:
> Da steht dann nur das

**2025-12-02 12:16:14** - Marie Gottschall:
> Ich mach jetzt auch kurz Lunch Break falls du dich gleich einloggen willst kannst du mir auch kurz auf Whatsapp schreiben dann kann ich dir den Code bestätigen :slightly_smiling_face:

**2025-12-02 13:02:32** - Julia:
> Mist. Okay also lass es uns so machen:

1. _*Zahlen/ Screenshots der View to Sale Ratio von anderen Brands*_
--&gt; Wir benötigen die fehlenden Zahlen in unserer Excel Tabelle für Maybelline DE als Vergleich.
--&gt; Wir nehmen noch 2 US Brands als Vergleiche dazu --&gt; wie gesagt Maybelline US und L'Oreal US machen nur Creator Lives. Also hier müssen wir noch andere finden
--&gt; daraus berechnen wir die View-to-sale
--&gt; in Excel Tabelle eintragen und Flo Screenshots schicken

_*2. Anzahl Live Zuschauer von anderen Brands - ich glaube 18k ist nicht so viel, weil da wahrscheinlich alle reinzählen die eine Sekunde zuschauen und dann weiterswipen*_
--&gt; Vergleich Maybelline

_*3. Haben wir zahlen dazu wie lange leute den MAC live stream schauen? Entweder Median oder Average. Haben wir Vergleichswerte?*_
--&gt; bisher nicht. Aber können mit dem Screenshot der Grafik berechnen, wenn wir hier noch die Metrik "Users Online" einstellen:
Die Standard-Formel lautet:
Durchschnittliche Watchtime = Anzahl der Zuschauer/ Gesamte gesehene Minuten
--&gt; Vergleich mit US Brand

_*4. DE Shops mit Umsätzen*_ 
--&gt;  schicke ich Flo

**2025-12-02 13:30:16** - Marie Gottschall:
> Bin wieder back :slightly_smiling_face: Ich kümmer mich mal um Punkt 1

**2025-12-02 13:40:32** - Julia:
> super, alles was du schon schaffst wäre toll! ich bin jetzt gleich im LIDL pitch, melde ich danach

**2025-12-02 14:41:16** - Marie Gottschall:
> Kannst du mir kurz erklären wie du das meinst? "Aber können mit dem Screenshot der Grafik berechnen, wenn wir hier noch die Metrik "Users Online" einstellen:"

**2025-12-02 14:58:12** - Julia:
> ja klar, sollen wir gleich mal sprechen?

**2025-12-02 15:00:13** - Marie Gottschall:
> gern

**2025-12-02 15:00:22** - Julia:
> ich ruf dich gleich an :slightly_smiling_face:

**2025-12-02 15:04:37** - Marie Gottschall:
> 

**2025-12-02 15:05:37** - Marie Gottschall:
> 

**2025-12-02 15:07:12** - Julia:
> 

**2025-12-03 11:28:46** - Marie Gottschall:
> Wie war das Estée Lauder Meeting? :star-struck:

**2025-12-03 11:34:01** - Julia:
> Gut! Also LIDL war im Vergleich euphorischer und auch persönlicher. Aber kommt ja immer auf die Personen dahinter an, war also auch sehr gut. Bin sehr gespannt, was sie am Ende sagen

**2025-12-03 11:34:06** - Julia:
> Bei dir alles okay? :slightly_smiling_face:

**2025-12-03 11:35:20** - Marie Gottschall:
> Bin auch sehr gespannt

**2025-12-03 11:37:33** - Marie Gottschall:
> Bei mir ist alles gut :slightly_smiling_face: Falls ihr noch eine To-Do habt gerne her damit. Mach gerade noch ein bisschen was für Basti aber damit werd ich bald fertig

**2025-12-03 12:06:43** - Julia:
> sehr gut

**2025-12-03 12:07:07** - Julia:
> okay, good to know! Wir klären gerade noch ein paar Dinge bezüglich der Shootings. Wenn wir hier mehr wissen, gibts klare to-dos. ich melde mich :slightly_smiling_face:

**2025-12-04 16:29:27** - Julia:
> Hi Marie :slightly_smiling_face: viel Spaß in Dublin!
Wir würden uns sehr freuen, wenn du am Dienstag mit zum Shooting kommst und uns unterstützt:

Treffpunkt: 8 Uhr (wenn du erst ab 10.30 kannst, auch kein Problem)
Die Adresse lautet:
Chris Hallhuber
Mauerkircherstr. 130, 81925 München

Wir werden sicherlich bis 19/20 Uhr vor Ort sein

**2025-12-17 10:19:39** - Marie Gottschall:
> Hi Juli wie gehts dir? :slightly_smiling_face:

**2025-12-17 10:19:58** - Marie Gottschall:
> Hast du eine To-Do für mich? Hab grad Kappa :relaxed:

**2025-12-17 12:25:02** - Julia:
> Hi Marie! :slightly_smiling_face: sorry ich hatte leider einen kleinen Zwischenfall mit meinem Hund, deshalb war ich nicht am PC

**2025-12-17 12:25:07** - Julia:
> Alles gut bei dir?

**2025-12-17 12:38:31** - Marie Gottschall:
> Oh nein was ist passiert?

**2025-12-17 12:39:06** - Julia:
> Sie hat sich heute morgen beim gassi gehen die Pfote aufgeschnitten :face_with_spiral_eyes: aber wird jetzt wieder

**2025-12-17 12:39:23** - Marie Gottschall:
> Ja bei mir ist alles gut :slightly_smiling_face: Hab jetzt auch was zu tun für heute aber falls ihr was habt kann ich das gerne am Freitag machen

**2025-12-17 12:39:42** - Julia:
> okay! :slightly_smiling_face:

**2025-12-17 12:40:07** - Julia:
> Mert und ich schneiden gerade die Videos vom Shooting und müssen da teilweise noch den content sortieren bei den 700 videos :sweat_smile: das können wir aber gerne dann am Freitag durchgehen? :slightly_smiling_face:

**2025-12-17 12:40:16** - Marie Gottschall:
> Oh Gott die arme :pleading_face: Hoffe es wird wieder

**2025-12-17 12:40:43** - Marie Gottschall:
> Ja gerne! Seid ihr Freitag dann auch im Büro?

**2025-12-17 12:41:55** - Julia:
> yes! wollte heute eigentlich eben auch, aber bleib dadurch jetzt lieber daheim

**2025-12-17 12:42:21** - Julia:
> danke! jaa, solange es sich jetzt nicht entzündet :face_exhaling:

**2025-12-17 13:10:13** - Marie Gottschall:
> Ja verständlich

**2025-12-17 13:10:46** - Marie Gottschall:
> Flo ist heute eh nicht im Büro bin nur ich und Jie aber wir bleiben beide nichtmehr lange

**2025-12-17 18:56:16** - Julia:
> Da habt ihr recht :slightly_smiling_face: dann sehen wir uns am freitag!

**2025-12-19 11:31:40** - Marie Gottschall:
> Hi :slightly_smiling_face: Wann kommt ihr heute rein? Und kann ich bis dahin schon irgendwie unterstützen?

**2025-12-19 11:32:07** - Julia:
> hello! Ich bin in den nächsten 20 Minuten da :) 

**2025-12-19 11:32:30** - Julia:
> Können wir dann gerne gleich besprechen

**2025-12-19 11:33:09** - Marie Gottschall:
> Ah super alles klar :slightly_smiling_face:

**2025-12-19 12:04:10** - Julia:
> <https://drive.google.com/drive/folders/1vPVCF7OjrfW2PtTRfZ-66nR1xRwHJqrf>

**2025-12-19 12:47:04** - Marie Gottschall:
> Flo meinte ihr sollt zu uns in die Küche kommen :)

**2025-12-19 12:47:42** - Marie Gottschall:
> Kannst du den anderen oben von unserem Team auch Bescheid sagen? 

**2025-12-19 12:48:08** - Julia:
> okay, mach ich! :slightly_smiling_face:

**2025-12-22 09:38:29** - Julia:
> Hi Marie! :slightly_smiling_face: Hoffe dir gehts gut

**2025-12-22 09:38:47** - Julia:
> Sag mal bekommst du die Codes für Gmail aufs Handy?

**2025-12-22 09:39:35** - Marie Gottschall:
> hi :) ja hab grad was bekommen aber ist jetzt wieder weg 

**2025-12-22 09:40:06** - Marie Gottschall:
> ah jetzt 

**2025-12-22 09:40:09** - Marie Gottschall:
> welche nummer?

**2025-12-22 09:40:12** - Julia:
> 40

**2025-12-22 09:40:30** - Marie Gottschall:
> gings?

**2025-12-22 09:41:15** - Julia:
> jaaaa

**2025-12-22 09:41:18** - Julia:
> vielen Dank!

**2025-12-22 09:41:27** - Julia:
> Habs auch am Handy aber wurde irgendwie wieder ausgeloggt

**2025-12-22 09:41:37** - Marie Gottschall:
> Kein Problem :)

**2025-12-22 09:44:15** - Julia:
> danke dir :slightly_smiling_face:

**2025-12-22 09:44:23** - Julia:
> bist du heute offline oder wärst du da?

**2025-12-22 09:44:48** - Marie Gottschall:
> Bin ab 10:30 da bin grad noch in der Uni :)

**2025-12-22 09:45:01** - Julia:
> Ahh okay, oh sorry

**2025-12-22 09:45:45** - Marie Gottschall:
> alles gut ich kann euch dann auch wieder unterstützen mit den Briefings :)

**2025-12-22 11:17:10** - Julia:
> super danke dir!

**2025-12-22 11:18:21** - Julia:
> ich hab dich bei 3 Asana Tasks markiert – hier wäre es suuuper, wenn du die briefings übernehmen kannst

**2025-12-22 11:18:31** - Julia:
> wenn du Fragen hast, oder irgendwas nicht klappt, meld dich gerne!

**2025-12-22 12:33:30** - Marie Gottschall:
> Yess sorry dass ich mich jetzt erst melde wurde in der Uni aufgehalten aber mach mich jetzt gleich an die Tasks :slightly_smiling_face: Soll ich das Briefing dann erst an Mert übergeben oder direkt an die Designer?

**2025-12-22 12:37:47** - Marie Gottschall:
> oh Gott hab gerade auch die Videos von dem Humus gesehen das ist ja furchtbar :sweat_smile:

**2025-12-22 12:38:11** - Marie Gottschall:
> Dass die so offensichtliche Sachen nicht direkt fixen :sweat_smile:

**2025-12-22 12:45:19** - Julia:
> Alles gut, garkein Stress

**2025-12-22 12:45:39** - Julia:
> gerne wieder oben in die Beschreibung und dann Mert einmal taggen :slightly_smiling_face: dann kann er noch finale Anpassungen machen, wenn er möchte

**2025-12-22 12:45:47** - Julia:
> Ja wir sind leider auch gerade überfragt

**2025-12-22 12:46:32** - Julia:
> da sind so viele Fehler noch drin

**2025-12-22 12:46:47** - Marie Gottschall:
> ja voll

**2025-12-22 12:46:55** - Julia:
> ich kann das Hummus video gleich mal feedbacken. oder möchtest du? :slightly_smiling_face: das geht am besten direkt über <http://Frame.io|Frame.io>

**2025-12-22 12:47:17** - Marie Gottschall:
> und auch die subtitles sind teilweise ein bisschen random

**2025-12-22 12:48:27** - Marie Gottschall:
> bei ACE haben Basti und so sich immer das Premiere Projekt in den Drive Ordner ablegen lassen um dann so Kleinigkeiten selbst zu verbessern falls euch das was hilft

**2025-12-22 12:48:56** - Julia:
> ah okay, good to know! geb ich mal an Mert weiter

**2025-12-22 12:49:31** - Marie Gottschall:
> Basti hat aber gemeint dass sie manchmal nicht den letzten stand hochgeladen haben aber das kann man ja nochmal anmerken

**2025-12-22 12:49:55** - Marie Gottschall:
> weil ich glaube das Feedback zu schreiben dauert teilweise fast länger als es gleich selbst kurz zu fixen

**2025-12-22 12:50:33** - Julia:
> ja ist auch so. aber bei so vielen anpassungen :smile: puh

**2025-12-22 12:50:34** - Julia:
> ja voll

**2026-01-12 12:35:36** - Julia:
> Hi Marie! :slightly_smiling_face: Gehts dir guut?

**2026-01-12 12:35:48** - Julia:
> Hast du heute etwas Kapa für mich?

**2026-01-12 12:36:43** - Marie Gottschall:
> Hi Juli :slightly_smiling_face: Ja mir gehts gut und dir?

**2026-01-12 12:36:52** - Marie Gottschall:
> Klar was gibts?

**2026-01-12 12:37:03** - Julia:
> auch!

**2026-01-12 12:37:16** - Julia:
> hast du kurz Zeit, dann würde ich dich einmal anrufen?

**2026-01-12 12:38:55** - Marie Gottschall:
> Ja passt

**2026-01-12 12:49:20** - Marie Gottschall:
> 

**2026-01-12 12:56:00** - Julia:
> <http://youtube.com/watch?si=WUN0h3LPnSfYqM0b&amp;v=rR4oIJiRp-g&amp;feature=youtu.be|youtube.com/watch?si=WUN0h3LPnSfYqM0b&amp;v=rR4oIJiRp-g&amp;feature=youtu.be>

**2026-01-12 13:02:12** - Julia:
> Falls du noch Ideen hast zu Artists die cool passen könnten, außer:
• Cro
• SSIO
• Nina Chuba
• Ski Aggu
• Bill &amp; Tom (Georg + Gustav waren im Sommer bei ALDI)
• Marteria
• Zartmann
sag gern Bescheid :slightly_smiling_face: Solange sie nicht mit ALDI oÄ zusammenarbeiten

**2026-01-12 13:02:56** - Julia:
> 

**2026-01-12 13:06:27** - Julia:
> Tasks:
1) SSIO Video-Dreh: Komparsen??
2) Auswahl Artists + ggf. Konzept
3) Popcultural Moments (Späti Talk?)

**2026-01-12 13:06:56** - Julia:
> Und hier das IT Piece das sich Flo &amp; Alex ausgedacht haben:
eine Kühltasche im Body Bag Look :smile:

**2026-01-12 13:13:10** - Marie Gottschall:
> hast du das was ihr bis jetzt gesammelt habt auch noch für mich?

**2026-01-12 13:13:44** - Julia:
> in Bezug auf was? :slightly_smiling_face:

**2026-01-12 13:16:54** - Marie Gottschall:
> also eure pitch ideen

**2026-01-12 13:17:32** - Marie Gottschall:
> habt ihr da schon ein dokument wo ihr alles gesammelt habt oder sind das nur die Sachen die du gerade erzählt hast?

**2026-01-12 13:17:49** - Marie Gottschall:
> z.B. die Ideen für das Beach Shooting

**2026-01-12 13:18:19** - Julia:
> Achso ja klar, stell ich dir gleich zusammen. Gibts noch nicht sooo richtig

**2026-01-12 13:18:37** - Marie Gottschall:
> ah achso dann kein Stress :slightly_smiling_face:

**2026-01-12 13:21:59** - Julia:
> hab dir ein Dokument weitergeleitet, das waren meine ersten Ansätze/ Ideen.
Daraufhin hat Flo eine Datei erstellt --&gt; die frage ich gleich an, hab ich selbst noch nicht. (da steht auch diese Idee drin)
Du kannst bei diesem Worddokument von mir gerne weiterarbeiten und neue Tabs hinzufügen :slightly_smiling_face:

**2026-01-12 13:22:21** - Marie Gottschall:
> yes mach ich :slightly_smiling_face:

**2026-01-12 13:27:24** - Julia:
> danke dir!

**2026-01-12 14:28:41** - Julia:
> 

**2026-01-12 14:31:02** - Marie Gottschall:
> Alles klar :slightly_smiling_face:

**2026-01-12 14:44:55** - Julia:
> hier ist es von Flo:

**2026-01-12 14:51:05** - Marie Gottschall:
> Danke dir:relaxed:

**2026-01-12 18:06:27** - Julia:
> Ich hab vorerst diese gewählt, gerne deinen Input noch dazu. In deiner Artist Liste habe ich ein paar Bemerkungen gemacht. Können wir gerne morgen früh direkt sprechen :slightly_smiling_face:

**2026-01-13 09:20:11** - Marie Gottschall:
> mega!

**2026-01-13 09:25:11** - Marie Gottschall:
> Bei Zartmann hab ich nur mal mitbekommen, dass er bei der Bambi Verleihung total unsympathisch und arrogant war deswegen weiß ich nicht ob der ein bisschen gecancelt ist:sweat_smile:

**2026-01-13 09:47:01** - Julia:
> Hello! :slightly_smiling_face:

**2026-01-13 09:47:10** - Julia:
> Ah okay :smiling_face_with_tear:

**2026-01-13 09:47:33** - Julia:
> ich schreibs mal dazu

**2026-01-13 09:48:12** - Marie Gottschall:
> aber kann auch sein dass das schon wieder vergessen ist ich weiß nicht wie stark seine Fanbase ist

**2026-01-13 09:48:17** - Julia:
> Hast du evtl eine Freundin oder Bekannte die Zeit und Lust hätte unser weibliches Model für den Videodreh zu sein? Wird natürlich vergütet und geht wie gesagt sehr schnell

**2026-01-13 09:49:03** - Marie Gottschall:
> habt ihr eine Vorstellung wie sie ungefähr aussehen sollte?

**2026-01-13 09:51:22** - Julia:
> • natürlich und "klassisch schöne"/attraktive Frau
• Mitte 20
• schlank/ sportlich, groß
• Haarfarbe oder Hauttyp spielt hier keine Rolle

**2026-01-13 09:53:47** - Marie Gottschall:
> für wann habt ihr den dreh gleich nochmal gedacht?

**2026-01-13 09:54:49** - Julia:
> also entweder wäre Donnerstag/Freitag super oder gleich Anfang nächsten Mittwoch

**2026-01-13 09:55:52** - Marie Gottschall:
> ich frag mal :slightly_smiling_face:

**2026-01-13 09:56:31** - Julia:
> super danke! :slightly_smiling_face:

**2026-01-13 10:25:35** - Marie Gottschall:
> nächsten Mittwoch oder Anfang nächste Woche? :sweat_smile::joy:

**2026-01-13 10:30:11** - Julia:
> ah sorry :smile: getippt und währenddessen was anderes gedacht

**2026-01-13 10:30:47** - Julia:
> Also entweder jetzt am Donnerstag/ Freitag (15. oder 16.1.) oder Mittwoch der 21.
am besten wäre Freitag

**2026-01-13 12:12:59** - Marie Gottschall:
> Eine sehr gute Freundin von mir könnte am Mittwoch aber nur vormittags weil sie um 14 Uhr eine Präsentation hat:relaxed:

**2026-01-13 13:01:11** - Julia:
> ach cool!

**2026-01-13 13:01:31** - Julia:
> Super hübsch :slightly_smiling_face:

**2026-01-13 13:01:45** - Julia:
> Also ginge bis 12.30 sowas?

**2026-01-13 13:02:06** - Julia:
> Magst du mir ihren Namen noch verraten, dann packe ich sie mal in die Präsentation als Option

**2026-01-13 13:03:02** - Marie Gottschall:
> Ja genau je nachdem wo es ist aber bis 12:30 sollte passen

**2026-01-13 13:03:11** - Marie Gottschall:
> Antonia Seidl heißt sie

**2026-01-13 13:04:47** - Julia:
> okay perfekt

**2026-01-13 13:04:50** - Julia:
> danke dir! :slightly_smiling_face:

**2026-01-13 13:05:48** - Marie Gottschall:
> Kein Problem :slightly_smiling_face: Bis wann weißt du ca ob das klappt?

**2026-01-13 13:06:06** - Julia:
> ich schicke Flo heute die Präsi und hoffe es kommt dann direkt Feedback

**2026-01-13 13:06:09** - Julia:
> Also morgen auf jeden Fall

**2026-01-13 13:06:31** - Marie Gottschall:
> okay top :slightly_smiling_face:

**2026-01-13 13:12:17** - Julia:
> bin bei der LIDL Kampagne übrigens jetzt ein Stück weitergekommen

**2026-01-13 13:12:34** - Julia:
> nicht Flo spoilern, falls du im Büro bist haha :shushing_face:

**2026-01-13 13:13:19** - Marie Gottschall:
> hatte heute noch keine Gelegenheit ins Doc zu schauen aber bin jetzt gespannt haha

**2026-01-13 13:13:44** - Marie Gottschall:
> Jaa bin tatsächlich im Büro aber ich zeig es ihm nicht versprochen:joy:

**2026-01-13 13:14:53** - Julia:
> alles gut, ich schick dir hier gleich einen Auszug aus der Präsentation. ist leider eine offline Version, deshalb kann ich es nur so teilen

**2026-01-13 13:15:16** - Marie Gottschall:
> Kein Problem :relaxed:

**2026-01-13 13:16:13** - Julia:
> 

**2026-01-13 13:16:38** - Julia:
> wie gesagt, wenn du noch Popcultural moments/ ideen hast: gerne her damit. Da bin ich momentan etwas lost :slightly_smiling_face:

**2026-01-13 13:19:53** - Marie Gottschall:
> Das ist so eine gute Idee!

**2026-01-13 13:20:49** - Marie Gottschall:
> Kann mir auch richtig gut vorstellen dass das auf Social zieht

**2026-01-13 13:21:23** - Marie Gottschall:
> Hoffentlich bekommen wir aber SSIO das wär schon am coolsten, weil der alles immer so lustig rüberbringt

**2026-01-13 13:23:39** - Julia:
> ja? Okay das ist super. Weil genau das wär meine größte Sorge, es muss für Social passend sein 

**2026-01-13 13:23:47** - Julia:
> Danke dir! 

**2026-01-13 13:34:55** - Julia:
> Könnte deine Freundin auch Montag oder Dienstag? 

**2026-01-13 14:27:41** - Marie Gottschall:
> Ne leider nicht :confused:

**2026-01-13 14:45:58** - Julia:
> okay, danke!

**2026-01-13 14:46:18** - Julia:
> FYI – ging eben an Flo raus, damit du auch up to date bist

**2026-01-13 15:10:00** - Marie Gottschall:
> Danke dir :relaxed:

**2026-01-13 15:10:54** - Marie Gottschall:
> Die tragen aber schon einen Bademantel oder Handtuch oder? weil FKK hab ich ihr irgendwie nicht so kommuniziert :sweat_smile::joy:

**2026-01-13 15:12:23** - Marie Gottschall:
> und ist das jetzt doch nicht in dem Roberto Beach wie du mal meintest?

**2026-01-13 15:14:34** - Julia:
> ja genau, also ich würde so hautfarbene unterwäsche bestellen und wir legen dann im nachgang eh nochmal diese "Pixel" drüber :slightly_smiling_face:

**2026-01-13 15:14:58** - Julia:
> leider keine Rückmeldung und ich gehe davon aus, dass es zu teuer ist wegen Drehgenehmigung

**2026-01-13 15:15:07** - Julia:
> Ich geb dir bescheid, sobald ich Feedback von Flo hab

**2026-01-13 15:15:53** - Marie Gottschall:
> hm das weiß ich dann aber nicht ob sie das macht vor allem bei der Kälte und in der Öffentlichkeit in Unterwäsche:sweat_smile:

**2026-01-13 15:17:14** - Marie Gottschall:
> ah schade :sweat_smile: Und sowas wie Erdinger Therme habt ihr da schonmal dran gedacht? Die haben vielleicht auch so eine Strand Szene

**2026-01-13 15:18:05** - Julia:
> ja genau, das wäre von den Kosten wahrscheinlich genau das gleiche.
Also persönlich wäre auch für sowas, Flo wollte tatsächlich die leane/schnelle Variante an der Isar, let's see

**2026-01-13 15:20:31** - Julia:
> 

**2026-01-13 15:24:02** - Marie Gottschall:
> Ich gebs nochmal weiter aber so wie ich sie kenn ist sie dann da doch eher raus :sweat_smile: Sorry das war dann mein Fehler ich hab das leider irgendwie anders verstanden. Ich dachte nur das männliche Model sollte "nackt" sein und bei dem Crush ist es egal

**2026-01-13 15:24:50** - Julia:
> alles gut, dann weiß ich Bescheid!

**2026-01-13 19:50:06** - Marie Gottschall:
> Hi Juli sorry dass ich so spät noch schreib

**2026-01-13 19:51:24** - Marie Gottschall:
> Mein Freund meinte gerade dass SSIO überall den Joke aufbaut dass er nur auf Frauen über 130 kg und im mittleren Alter steht:sweat_smile:

**2026-01-13 19:51:48** - Marie Gottschall:
> Vielleicht sollte man den Plan dann nochmal ein bisschen überdenken

**2026-01-13 19:54:04** - Marie Gottschall:
> <https://vm.tiktok.com/ZGdm5vgTv/|https://vm.tiktok.com/ZGdm5vgTv/>

**2026-01-13 19:55:19** - Marie Gottschall:
> <https://vm.tiktok.com/ZGdm557UM/|https://vm.tiktok.com/ZGdm557UM/>

**2026-01-14 10:38:45** - Julia:
> Hi Marie! Danke für die Info, die Videos hatte ich auch schon mal gesehen. Ich gebs mal an Flo weiter

**2026-01-14 10:38:52** - Julia:
> danke für deine Aufmerksamkeit!

**2026-01-14 12:29:38** - Marie Gottschall:
> Kann ich dich sonst noch irgendwie unterstützen? Ich hab grad wieder Kapa :slightly_smiling_face:

**2026-01-14 12:45:00** - Julia:
> Du hast ja wahrscheinlich schon mit Marvin gesprochen oder?

**2026-01-14 12:45:10** - Marie Gottschall:
> yess

**2026-01-14 12:45:14** - Julia:
> Wir sind nämlich gerade dran neue Formate für SIXT zu überlegen

**2026-01-14 12:46:02** - Marie Gottschall:
> er hat schon ein paar von den rausgesuchten Trends für SIXT notiert und meinte er gibt etwas weiter an Basti

**2026-01-14 12:46:15** - Julia:
> okay super

**2026-01-14 12:46:35** - Julia:
> das wäre jetzt meine Task gewesen, ansonsten bin ich da auch gerade dran :slightly_smiling_face:

**2026-01-14 12:47:58** - Marie Gottschall:
> Wenn ihr schon konkrete Aufgaben dazu habt sag gerne Bescheid auch sonst für Hisense oder Gorenje

**2026-01-14 12:48:06** - Marie Gottschall:
> Bin noch bis 14:30 da :slightly_smiling_face:

**2026-01-14 12:48:35** - Julia:
> danke dir!

**2026-01-14 12:48:57** - Julia:
> Könntest du mir die offene PPT Datei der Trendanalyse schicken?

**2026-01-14 12:49:05** - Julia:
> Würde hier gerne was rauskopieren :slightly_smiling_face:

**2026-01-14 12:49:40** - Marie Gottschall:
> klar

**2026-01-14 12:52:22** - Julia:
> dankee!

**2026-01-14 12:52:25** - Julia:
> Sehr cool aufbereitet

**2026-01-14 12:52:39** - Marie Gottschall:
> Danke :relaxed:

**2026-01-14 12:53:00** - Marie Gottschall:
> Falls du auch noch Input hast was ich in Zukunft besser machen könnte einfach her damit :relaxed:

**2026-01-14 12:53:38** - Julia:
> wir planen uns das jetzt gerade ein für Gorenje. Da wir spontan nach Dänemark fliegen am Montag/ Dienstag und hier die Handball EM begleiten. Also top!

**2026-01-14 12:53:53** - Julia:
> bisher alles top :slightly_smiling_face: vielen Dank dir

**2026-01-14 12:54:38** - Marie Gottschall:
> mega!

**2026-01-14 12:55:20** - Marie Gottschall:
> fyi Marvin meinte dazu auch noch für Hisense könnte man das so adaptieren dass man es nicht in den Wolken sieht sondern auf einem Hisense Fernseher

**2026-01-14 12:56:32** - Julia:
> gute Idee aber wir wollen es klar trennen

**2026-01-14 12:56:51** - Julia:
> des mit den Wolken passt super, wenn wir ja auch im Flieger sitzen haha

**2026-01-14 13:02:55** - Marie Gottschall:
> yess

**2026-01-14 13:03:12** - Marie Gottschall:
> mega cool will auch nach Dänemark:smiling_face_with_tear::joy:

**2026-01-14 13:39:42** - Julia:
> Jaaa vooll!

**2026-01-14 13:39:57** - Julia:
> Aber wir sind tatsächlich nichtmal 24 std. da also viel werden wir nicht sehen

**2026-01-14 13:40:15** - Julia:
> Marie eine Kleinigkeit, die du mir vorbereiten könntest wäre super

**2026-01-14 13:42:40** - Julia:
> ich würde gerne auf die Schlappen &amp; die Tasche jeweils das LIDL Logo kleben (einfach aus Papier). könntest du mir das im Büro schon mal ausdrucken? Ich komme morgen rein :slightly_smiling_face:
Größe: 1x 5cm und 1x ca. 8cm

**2026-01-14 13:44:40** - Marie Gottschall:
> Alles klar mach ich

**2026-01-14 13:44:50** - Julia:
> danke dir!

**2026-01-14 13:51:16** - Marie Gottschall:
> soll ichs dir auch gleich ausschneiden?

**2026-01-14 13:52:46** - Julia:
> das wäre ein traum!

**2026-01-14 13:58:03** - Marie Gottschall:
> done :slightly_smiling_face: liegt auf dem Schreibtisch wo ich immer sitze also neben Flo

**2026-01-14 13:58:10** - Julia:
> ich danke dir :slightly_smiling_face:

**2026-01-14 13:58:17** - Marie Gottschall:
> nichts zu danken

**2026-01-27 16:11:25** - Julia:
> Hello! :slightly_smiling_face: Also wenn du magst, fang gerne schon mal an. Ich bin gedanklich heute noch bei SIXT und würde morgen mal mit MINI weitermachen

**2026-01-27 16:11:33** - Julia:
> Können gerne dann morgen dazu sprechen?

**2026-01-27 16:13:04** - Marie Gottschall:
> Alles klar ich erstelle mal ein Doc für uns :slightly_smiling_face: Flo meinte gerade noch wir sollen das gleich in die Präsentation machen aber ich finde es immer besser seine Gedanken auf einem Doc aufzuschreiben und es dann fertig in die Präsi einzufügen oder wie siehst du das?

**2026-01-27 16:13:43** - Julia:
> ja gerne erstmal trennen und für uns sortieren

**2026-01-27 16:18:07** - Marie Gottschall:
> <https://docs.google.com/document/d/1NEnlqXtQv5wCwQTJwg87O0flVR4dX0z-fwHf1-nqxH8/edit?usp=drive_link> hier schonmal der link :slightly_smiling_face:

**2026-01-27 16:18:26** - Julia:
> danke dir!

**2026-01-27 18:01:58** - Marie Gottschall:
> Ich hab schonmal für Human Mode und Spread Smiles bisschen gesammelt. Lass uns das gerne morgen früh gleich durchgehen wenn du kannst :relaxed:

**2026-01-28 09:05:35** - Julia:
> Guten Morgen! Finde die Spread Smiles Idee wirklich super :slightly_smiling_face:

**2026-01-28 09:05:57** - Julia:
> Human Mode finde ich sehr charmant gelöst – ich bin nur generell nicht von der Idee überzeugt, deshalb hänge ich hier noch etwas

**2026-01-28 09:13:15** - Marie Gottschall:
> Guten Morgen :relaxed:

**2026-01-28 09:13:45** - Marie Gottschall:
> Ja ich finde auch generell die Human Mode Idee ist noch ein bisschen lost weil das ja dann wirklich nur eine Kampagne wäre und keine Serie

**2026-01-28 09:20:59** - Marie Gottschall:
> Aber da meinte Flo ja dass Julian die Idee gut fand oder?

**2026-01-28 09:24:12** - Julia:
> ja genau

**2026-01-28 09:24:12** - Marie Gottschall:
> Ich hätte sonst noch eine andere Idee aber ich glaub das geht schneller wenn ich dir das kurz in einem Huddle erklär

**2026-01-28 09:24:23** - Julia:
> klar gerne, in 10 min?

**2026-01-28 09:24:36** - Marie Gottschall:
> passt :slightly_smiling_face:

**2026-01-28 09:31:40** - Julia:
> okay bin ready. huddle oder lieber meet?

**2026-01-28 09:32:05** - Marie Gottschall:
> was ist dir lieber?

**2026-01-28 09:33:01** - Julia:
> mit meet klappt es oft besser: <http://meet.google.com/wox-hqnm-mkh|meet.google.com/wox-hqnm-mkh>

**2026-01-28 11:09:44** - Marie Gottschall:
> Ich hab bei MINI Me ein bisschen gebrainstormed aber finde alles irgendwie nicht so 100% cool :weary:

**2026-01-28 11:30:37** - Julia:
> Alles klar, ich schau es mir nach meinem Meeting an :slightly_smiling_face:

**2026-01-28 12:38:38** - Marie Gottschall:
> Ich hatte nochmal eine coole Idee für den Human Mode (Idee 2) Da gibt es einen TikTok Kanal der macht nur so etwas und da geht jedes Video viral. Das wäre vielleicht eine Option wie man den Human Mode in den Tiktok Style bringt

**2026-01-28 12:40:55** - Marie Gottschall:
> Sonst komme ich gerade irgendwie gedanklich nicht weiter. Willst du nochmal sprechen oder wie kann ich dich sonst noch unterstützen?:sweat_smile:

**2026-01-28 13:18:17** - Julia:
> 

**2026-01-28 13:22:42** - Marie Gottschall:
> Alles klar kein Stress ich versteh das :relaxed:

**2026-01-30 18:54:57** - Julia:
> Marie, vielen lieben Dank für deine mega Arbeit für MINI! :heart_eyes: Ich hab sie hier und da noch etwas verfeinert und mit Flo besprochen – er weiß was von dir kommt &amp; ist super happy mit deiner Arbeit. Also vielen Dank dafür!

Ich bin jetzt dabei die Visuals dafür erstellen zu lassen, da ich es zeitlich auch nicht schaffe. Wenn du hier auch das ein oder andere Visual erstellen möchtest, lass uns gerne am Montag dazu sprechen.
Ansonsten hab ich dir noch eine weitere Asana Task erstellt – sag mir gern, ob du das kannst, sonst geb ich es weiter an Basti :slightly_smiling_face:

**2026-02-03 09:23:00** - Marie Gottschall:
> Guten Morgen Juli :relaxed:
Danke für dein liebes Feedback und dass du das gleich an Flo weiter gegeben hast! Das weiß ich wirklich zu schätzen:smiling_face_with_3_hearts:

Gestern hab ich mir spontan noch freigenommen wegen der Bachelorarbeit deswegen war ich da leider nicht online aber heute helfe ich dir gern noch bei allem wo ich helfen kann

**2026-02-03 09:26:06** - Marie Gottschall:
> Frage zur Asana Task: Habt ihr da ein Inspo Video von Porsche? In der Idee waren es ja dann eher nur Bilder (Einwegkamera) die gemacht wurden deswegen steh ich da ein bisschen auf dem Schlauch wie ihr euch das vorstellt.
Bin leider auch nicht soo erfahren mit Video Schnitt kanns aber versuchen. Wenn es dringend ist versteh ich es auch wenn du es lieber an Basti weiter gibst:relaxed:

**2026-02-03 09:29:54** - Julia:
> 

**2026-02-03 09:43:18** - Marie Gottschall:
> okay ich versuch es mal. sollen es nur Clips mit Hintergrundmusik sein, oder auch Szenen wo er spricht?

**2026-02-03 10:03:42** - Julia:
> Gerne wo er spricht 

**2026-02-03 14:23:39** - Marie Gottschall:
> Wie findest du das? :sweat_smile: Wie gesagt bin da leider garkein Pro drin

**2026-02-03 16:55:19** - Julia:
> Uhhh, schau ich mir gleich in Ruhe an:heart_hands: Aber sieht so schon super aus, Danke dir! 

**2026-02-03 16:55:33** - Julia:
> Mit was hast du es letzendlich geschnitten? 

**2026-02-03 16:55:43** - Marie Gottschall:
> Premiere

**2026-02-03 16:56:06** - Marie Gottschall:
> hab das Projekt auf in den MINI Ordner auf Drive geladen

**2026-02-03 16:56:55** - Julia:
> Wow okay 

**2026-02-03 16:56:59** - Julia:
> Danke dir! 

**2026-02-03 17:00:06** - Marie Gottschall:
> Kein Problem :relaxed: Sag gern Bescheid wenn ich noch bei etwas helfen kann

**2026-02-03 17:51:24** - Julia:
> Ich bin morgen im Büro – bist du auch da? :slightly_smiling_face:

**2026-02-03 17:54:59** - Marie Gottschall:
> Ah cool! Ich muss morgen spontan schauen, weil ich leider bisschen angeschlagen bin :sweat_smile:

**2026-02-03 17:55:20** - Julia:
> Ach mist, du Arme. Aber ja klar, das macht Sinn

**2026-02-03 17:59:19** - Marie Gottschall:
> Ja mir gehts jetzt schon bisschen besser als heute früh hab nurnoch eine verschnupfte Nase und Kopfschmerzen aber vielleicht geht es ja morgen für einen halben Tag trotzdem:relaxed:

**2026-02-04 10:38:53** - Marie Gottschall:
> Hi Juli kann ich dich noch unterstützen bei MINI oder bei Pepsi?

**2026-02-04 10:40:18** - Marie Gottschall:
> Bin noch bis ca 12 im Büro :slightly_smiling_face:

**2026-02-04 10:46:30** - Julia:
> Hi Marie! Sorry, mich hats heute morgen mit einer Migräne komplett zerlegt. Ich bin erstmal noch raus

**2026-02-04 10:46:32** - Julia:
> aber danke dir!

**2026-02-04 10:47:11** - Marie Gottschall:
> Ohje dann gute Besserung dir!! :heart_hands:


---

## Anna Arndt (218 messages)

**Julia sent:** 106 | **Anna Arndt sent:** 112

**Folder:** `D0A05HAPK1R`

**2025-11-28 09:28:22** - Anna Arndt:
> Hi hi! Flo meint, du hast eine Aufgabe, bei der ich dir helfen könnte? Irgendwas zu Lidl und Photoshop-Mockups? Schreib mir gerne oder ruf mich kurz an:)

**2025-11-28 09:28:32** - Julia:
> Hi Anna! wollte mich gerade melden

**2025-11-28 09:29:07** - Anna Arndt:
> Kein Stress:grin:

**2025-11-28 09:30:10** - Julia:
> Tatsächlich nein, ich weiß nicht genau was er damit meint, da kannst du mich leider nicht unterstützen. Allerdings benötigen meine Kolleginnen Julia Hallhuber und Mert Unterstützung beim Kunden Hisense/Gorenje, da ich hier heute nicht aushelfen kann

**2025-11-28 09:30:56** - Anna Arndt:
> Hmm okay, dann frag ich da mal nach:)

**2025-11-28 09:31:19** - Julia:
> Ich connecte euch

**2025-11-28 09:33:21** - Anna Arndt:
> Flo sagt Lidl first, ich brauche die Kampagne und irgendwelche Bilder von dir:joy:

**2025-11-28 09:33:38** - Anna Arndt:
> Ich soll irgendwie Artikel Snippets schreiben

**2025-11-28 09:35:14** - Julia:
> ich ruf ihn an

**2025-11-28 09:37:09** - Anna Arndt:
> 

**2025-11-28 09:48:08** - Anna Arndt:
> 

**2025-11-28 09:50:07** - Julia:
> 

**2025-11-28 09:56:42** - Julia:
> Bevorzug gerne die Bilder bei denen man das OMR Logo auch sieht oder wir photoshoppen es dann nochmal rein

**2025-11-28 09:57:43** - Anna Arndt:
> Danke dir!

**2025-11-28 10:05:12** - Anna Arndt:
> Könnte ich dann win/zwei davon (mit OMR Logo) noch 16:9 haben bitte? :slightly_smiling_face:

**2025-11-28 10:19:45** - Julia:
> yes, erstelle ich dir gleich 

**2025-11-28 11:01:07** - Anna Arndt:
> danke:)

**2025-11-28 11:11:01** - Julia:
> links müsste man wahrscheinlich etwas zuschneiden wegen den blau/gelben wohnmobilen

**2025-11-28 11:12:44** - Julia:
> 

**2025-11-28 11:13:12** - Anna Arndt:
> Vielen Dank dir Juli!

**2025-11-28 11:14:04** - Julia:
> sehr gerne! bin bis 12 Uhr in einem Meeting, melde ich danach wieder :slightly_smiling_face:

**2025-11-28 11:14:08** - Julia:
> danke dir!

**2025-11-28 11:27:19** - Julia:
> hiermit könnten wir noch social Posts faken beispielsweise

**2025-11-28 12:46:10** - Julia:
> Kommst du voran? Alles gut?

**2025-11-28 13:25:08** - Anna Arndt:
> Yes! Ich zeig dir schonmal paar Sachen, Flo hat gerade auch grob drüber geschaut, sag mir gerne, wenn etwas anders sein soll:)

**2025-11-28 13:25:40** - Anna Arndt:
> Die Zeitschriften hat übrigens auch Flo vorgegeben und um das Konzept mit dem Interview hat er auch gebeten

**2025-11-28 13:26:47** - Anna Arndt:
> 

**2025-11-28 13:28:47** - Anna Arndt:
> 

**2025-11-28 13:41:22** - Julia:
> sehr cool! Eine Kleinigkeit "Lidl" schreibt sich selbst nicht in Caps also nicht "LIDL". Würde deshalb eher bei der Schreibvariante Lidl bleiben. Bei dem Visual kann ich es leider nicht gut austauschen, aber sollten es bei den Headlines der Zeitschriften richtig haben

**2025-11-28 13:41:30** - Anna Arndt:
> 

**2025-11-28 13:41:51** - Julia:
> von Anna Arndt vllt? :slightly_smiling_face:

**2025-11-28 13:41:58** - Julia:
> 

**2025-11-28 13:42:05** - Anna Arndt:
> Oh, good to know! Danke! mach ich

**2025-11-28 13:42:15** - Anna Arndt:
> achso hahah ja kann ich auch machen

**2025-11-28 13:42:17** - Anna Arndt:
> Anna Arndt

**2025-11-28 13:42:24** - Anna Arndt:
> dachte der Autor ist erstmal egal

**2025-11-28 13:42:27** - Anna Arndt:
> aber gerne

**2025-11-28 13:43:03** - Julia:
> als kleiner Schmunzler – solche Tricks kann man immer einbauen :slightly_smiling_face:

**2025-11-28 13:54:01** - Anna Arndt:
> Ein paar LinkedIn Posts mache ich auch gleich noch

**2025-11-28 13:54:03** - Anna Arndt:
> Hier nochmal korrigiert!

**2025-11-28 13:54:15** - Anna Arndt:
> hast du denn zufällig schon was erstellen können zu den Innenräumen?

**2025-11-28 13:57:50** - Julia:
> super cool!

**2025-11-28 13:58:11** - Julia:
> leider noch nicht, aber ich schicke dir schon mal die anderen Bilder:

**2025-11-28 14:00:05** - Julia:
> 

**2025-11-28 14:00:36** - Julia:
> 

**2025-11-28 14:02:53** - Julia:
> 

**2025-11-28 14:50:33** - Anna Arndt:
> Wie cool, danke!

**2025-11-28 15:42:12** - Anna Arndt:
> Hier schonmal zwei Linkedin Mockups

**2025-11-28 15:44:06** - Julia:
> sehr cool! :slightly_smiling_face:

**2025-11-28 15:47:56** - Julia:
> du könntest noch das "Gefällt" mir als aktiviert anzeigen. Glaube das ist dann blau

**2025-11-28 15:49:16** - Julia:
> beim 2. würde ich schreiben "..Hamburg ist während der OMR komplett überlastet: nicht genügend Betten für den Ansturm

**2025-11-28 16:02:58** - Anna Arndt:
> Mach ich!

**2025-11-28 16:08:59** - Julia:
> 

**2025-11-28 16:09:08** - Anna Arndt:
> Nr 1

**2025-11-28 16:09:22** - Anna Arndt:
> woow wie cool! mercii

**2025-11-28 16:18:05** - Anna Arndt:
> Nr 2

**2025-11-28 16:34:11** - Anna Arndt:
> Hier noch einer:

**2025-11-28 16:38:12** - Anna Arndt:
> Flo möchte noch UGC-Mockups, unter anderem für diese drei Kandidaten &amp; Formate:
Opa Werner trinkt Matcha Latte im LIDL
Matthias Malmedie testet ob man mit LIDL Wohnwagen driften kann "Ich teste den LIDL OMR Wohnwagen - geht er quer?!"
 Ben Bernschneider macht "hotel vlog" aus LIDL Wohnwagen

Er meinte, ich soll dich fragen ob du dazu auch noch etwas generieren könntest bitte? Vielen Dank dir!

**2025-11-28 16:48:22** - Julia:
> Was genau sind UGC Mockups?

**2025-11-28 16:48:33** - Julia:
> Für IG, TikTok?

**2025-11-28 16:48:41** - Julia:
> Stills oder Video?

**2025-11-28 17:01:12** - Anna Arndt:
> User generated content, das heißt Mockups davon, was "normale" user und in dem Fall Influencer dazu generiert haben könnten. Für sowohl Instagram als auch Tiktok, aber eins pro Person. da kümmer ich mich drum. ich bräuchte nur bitte zu jeder Person 1 Still zum Thema:)

**2025-11-28 17:02:32** - Julia:
> Nene ich weiß was UGC ist aber ich meinte was UGC Mockups sein sollen :slightly_smiling_face: Instagram Handles also

**2025-11-28 17:04:28** - Anna Arndt:
> Naja, nicht deren handles sondern diese drei Influencer gibt es so, und einfach Bilder zu den Szenarios. Also Opa Werner, wie er Matcha trinkt in dem Wohnwagen, Matthias Malmedie am driften in einem und Ben Bernschneider, wie er einen Vlog macht. Macht das Sinn?

**2025-11-28 17:04:40** - Julia:
> wir können es probieren. Schwierigkeit liegt dabei, dass die Person von der 100% übernommen wird. Bei Matthias ist das das beste Ergebnis

**2025-11-28 17:05:37** - Julia:
> das evtl noch, richtig zugeschnitten:

**2025-11-28 17:25:28** - Julia:
> Hier Ben und Opa Werner

**2025-11-28 17:29:22** - Julia:
> hier noch innen drin, das hatte erst nicht geklappt

**2025-11-28 17:34:19** - Anna Arndt:
> Danke dir!! Sieht super aus!

**2025-11-28 17:36:10** - Julia:
> danke dir! ein tolles wochenende :slightly_smiling_face:

**2025-11-28 17:38:36** - Anna Arndt:
> dir auch!

**2025-12-04 08:43:03** - Julia:
> Guten Morgen Anna! 
Hast du um 10 Uhr Zeit für ein kurzes Meeting? 

**2025-12-04 09:19:14** - Anna Arndt:
> Hallo Juli! Yes, sehr gerne!

**2025-12-04 09:19:45** - Anna Arndt:
> Flo meinte, du hast eine Aufgabe für mich - geht es darum oder kann ich vorher schon was für dich tun?

**2025-12-04 09:59:31** - Julia:
> Ruf dich gleich an :slightly_smiling_face: Ne geht darum

**2025-12-04 10:03:37** - Anna Arndt:
> 

**2025-12-04 10:07:41** - Julia:
> 

**2025-12-04 10:12:46** - Julia:
> *WOHNWÄGEN:*
• 40 (50) Stück während der OMR 2026 in Hamburg
• Anbieter: einer oder über mehrere? --&gt; Machbar? Kosten?
• Wie sehen diese Wohnwägen im Roh Zustand aus?
• Design: Folierung (Außen) --&gt; Machbar? Kosten?
• Design: Interieur/ Umbau --&gt; Machbar? Kosten?
• Campingplatz: wo können die Wohnwägen am Ende stehen?
• Alle Infos die du findest helfen uns schon weiter :slightly_smiling_face: 
• Benötigt man eine Genehmigung für die Stadtfahrten? Wenn eine 300m lange Wohnwagen Karavane den Straßenverkehr blockiert
Danke dir!

**2025-12-04 10:59:11** - Julia:
> Könntest du bei Gelegenheit mal checken, ob ein Paket von Hisense angekommen ist? Gorenje müssten 3 Stück sein. Aber wir warten noch auf ein Produkt seitens Gorenje :slightly_smiling_face:

**2025-12-04 11:56:53** - Anna Arndt:
> Ich sehe drei Gorenje Pakete. Hisense noch keins.

**2025-12-04 11:57:44** - Anna Arndt:
> Viele der Wohnwagen-Anbieter haben Infos zu Stückzahl und Preis nur auf Anfrage (Email). Soll ich da schonmal nachfragen oder ist das zu konkret für jetzt?

**2025-12-04 12:00:47** - Julia:
> okay danke dir

**2025-12-04 12:01:21** - Julia:
> ja frag  gerne an. Hier bitte beachten: keine konkrete Nennung von LIDL, sondern eher von einem großen Kunden sprechen

**2025-12-04 12:25:46** - Anna Arndt:
> Ja klar:) Mach ich

**2025-12-04 13:47:12** - Julia:
> danke dir!

**2025-12-04 14:03:48** - Anna Arndt:
> Hier schonmal meine Übersicht: <https://docs.google.com/document/d/1f7r5ByOzHE94Fp-i_MxLFVouK_wdo4QEXB1FM4YRHig/edit?tab=t.0>
Ich mache Mittagspause und kann danach gerne nochmal anpassen, mir Sachen genauer anschauen, ergänzen etc:) Wenn du schon Anmerkungen hast lass es mich gern wissen

**2025-12-04 14:05:29** - Anna Arndt:
> Es ist teilweise etwas schwer schon genaue Angaben zu machen, ich schau mal was ich so als Antworten bekomme (und wan hahah) und kann das dann dementsprechend etwas fester machen. Bei den Stellplätzen kann ich auch mal konkreter Anfragen wenn du möchtest. Aber die genauen Summen wissen wir glaub ich echt erst wenn wir konkret was ausmachen und buchen.

**2025-12-04 14:55:42** - Julia:
> cool, danke dir!

**2025-12-04 14:56:15** - Julia:
> Die Kosten für die Außenfolierung hattest du jetzt nicht nochmal extra recherchiert, sondern über die Wohnmobil Vermietungen angefragt?

**2025-12-04 14:56:31** - Julia:
> klar verständlich

**2025-12-04 15:21:11** - Anna Arndt:
> Genau. Mach ich aber gern nochmal extra

**2025-12-04 16:18:57** - Julia:
> die erste Absage kam ja sogar schon rein

**2025-12-04 16:19:33** - Julia:
> falls du es eh noch nicht gemacht hast: markiere gerne in dem Dokument die Absagen und den Status der Anfragen

**2025-12-04 16:22:02** - Julia:
> Und könntest du nochmal zusammenrechnen (mit den Informationen die wir haben) wieviel grob ein Wohnmobil kostet mit allem (Folierung, Fahrer, Parkgebühren, generelle Gebühren...) danke! :slightly_smiling_face:

**2025-12-04 16:51:02** - Anna Arndt:
> Mach ich. Flo hatte mich eh gebeten, die alle anzurufen und da bin ich grad dabei uns sortiere dann nochmal aus.

**2025-12-04 16:52:05** - Anna Arndt:
> Meinst du bei deiner letzten Nachricht mit Wohnwagen Vermietung oder Kauf? Weil ein Gesamtpreis für das alles im Falle der Vermietung steht eigentlich schon mit drinnen...

**2025-12-04 17:14:40** - Julia:
> Ah magst du mir das einmal markieren/ mich kommentieren? Dann hab ich es übersehen. Danke dir!

**2025-12-04 17:37:25** - Anna Arndt:
> Mach ich!

**2025-12-05 09:04:23** - Anna Arndt:
> fyi- das Hisense Paket ist angekommen:)

**2025-12-05 09:05:57** - Julia:
> Guten Morgen! Danke dir :) bin auch gleich da 

**2025-12-05 17:18:33** - Anna Arndt:
> Hey, ich hab heute noch ganz viel rum telefoniert, alle Infos und Updates sind in dem Doc von gestern! Damit du Bescheid weißt und falls du auf ein neues wartest hahah:)

**2025-12-05 17:19:21** - Anna Arndt:
> Ich hab dich immer in CC gesetzt bei den Emails (auch gestern ja schon) - ich hoffe das ist okay aber so kriegst du hoffentlich die Antworten auch in der Zeit wo ich nicht da bin!

**2025-12-05 18:23:48** - Anna Arndt:
> Hier eine Zusammenfassung, die sich Flo noch gewünscht hatte, einmal auch an dich:

**2025-12-05 18:23:50** - Anna Arndt:
> *Executive Summary Anna - Wohnwagen Kampagne Lidl*

-&gt; Anrufe und Emails (da wo angefordert oder nicht erreicht)



1. *Wohnwagen*
• Wohnmobil-Vermieter in und um Hamburg
• Realistischste Option:
<https://www.schwarz-mobile-freizeit.de/vermietung/wohnmobile#/iframe/> / McRent
hätten die Anzahl da, verschiedene Fahrzeuge, Branding möglich
4 Nächte 540 Euro - 860 Euro , Sonderpreis möglich: -25%
-&gt; Broschüre an Juli und Marie geschickt



• Ansonsten:
    ◦ Vermieter mit weniger Kapazitäten:
<https://www.drm.de/de/stationen/hamburg-henstedt> höchstens ca. 6 auf einmal, Infos kommen noch
<https://naturecaravan.de/> auch weniger, melden sich zurück mit Anzahl und Preis
<https://caravanhamburg.de/de/wohnmobile-mieten> Infos kommen noch
<https://www.roehnelt-caravan.de/> 10 Stück, ca. 500 Euro für 4 Tage, Folierung möglich

• Eventfahrzeug-Anbieter <https://www.showtruck-marketing.com/>
	Kleinere Stückzahl, teurer, melden sich zurück mit Anzahl und Preis
-&gt; Machen aber auch Folierung und Interior

Next Steps:

• Warten auf weitere Antworten
• Liste mit denen, die ich nicht erreicht habe an Juli und Marie geschickt






*2. Parken*

• Realistischste Optionen:
<http://knauscamp.de|knauscamp.de> -&gt; Melden sich zurück
<https://www.elbepark-bunthaus.de/startseite-elbepark-bunthaus.html>
	-&gt; Könnte gehen, aber man muss alles manuell buchen
Online für den Zeitraum noch viel Verfügbarkeit, 26-30€ pro Fahrzeug und Nacht
<https://www.safe-depot.de/wohnmobil-stellplaetze/> evtl. möglich, ruft zurück

	Roadblocker
• Zusatzkosten für Strom, Sanitär und anwesende Personen
	Next Steps
• Auf Rückmeldungen warten
• Weitere anfragen,  Liste mit denen, die ich nicht erreicht habe an Juli und Marie geschickt




*3. Außenbranding/Folierung*

• Bei vielen Anbietern prinzipiell möglich
• Mockups per Email, melden sich mit Angeboten
	Zum Beispiel:
<https://b-branded.com/fahrzeugbeschriftung-und-flottenbeschriftung/>
<https://www.phoenixdesigns.de/fahrzeugbeschriftung-hamburg/>

Next Steps:
• Warten auf Angebote, Entscheiden für sinnvollste Option




*4. Inneneinrichtung*

• <https://hp-camper.de/> schonmal erreicht und wahrscheinlich möglich
• Liste an weiteren Optionen -&gt; Juli und Marie geschickt
Next Step:
• Weiter anfragen, Optionen vergleichen




*5. Genehmigung*

• Brauchen wir
• LBV, die klären mit Polizei etc.
• Trotzdem alle möglichen Adressen angefragt, noch keine klare Antwort
	Next Step:
• Anruf am Montag unter angeblich hilfreicher Nummer -&gt; Juli und Marie geschickt




*-&gt;* *Schätzung Gesamtprei*s (laut AI, also ungenau, aber vllt. zur groben Einschätzung): *60.000-300.000 €* (edited)

*<http://drm.de|drm.de>*
*<https://www.drm.de/de/stationen/hamburg-henstedt|Wohnmobil mieten ab Hamburg/Henstedt-Ulzburg>*
Wohnmobil &amp; Camper mieten ab Hamburg / Henstedt-Ulzburg ✓Kundenservice-Testsieger ✓Seit 1994 ✓2. Fahrer gratis ✓Inkl. KM &amp; Vollkasko Schutz ✓Hund kostenlos

*Nature Caravan | Patrick Heinze*
*<https://naturecaravan.de/|Wohnmobilvermietung Hamburg | Nature Caravan>*
Buchen Sie mit Nature Caravan Ihren Urlaub! Familiengeführtes Unternehmen seit 2021, spezialisiert auf die Vermietung von Wohnmobilen und Wohnwagen in Hamburg. Jetzt starten!

*Lisa Automobile GmbH*
*<https://caravanhamburg.de/de/wohnmobile-mieten|Caravan Hamburg – Camper mieten mit Rundum-Sorglos-Service>*
Starte deinen Roadtrip mit Caravan Hamburg – moderne Camper, individuelle Beratung &amp; flexible Mietoptionen in Börnsen &amp; Marschacht.

*<http://roehnelt-caravan.de|roehnelt-caravan.de>*
*<https://www.roehnelt-caravan.de/|Home Röhnelt Caravan GmbH in Hamburg>*
Bei uns finden Sie Beratung und Angebot zu Reisemobilen und Mobilheimen mit umfassenden Serviceleistungen, Ihr Freizeittraum individuell auf Sie abgestimmt.

**2025-12-05 18:25:18** - Anna Arndt:
> Hier noch ein PDF, was mir der eine, realistischste Anbieter geschickt hat. Von allen Fahrzeugen hat er in dem Zwitraum 2-4 Stück verfügbar, es warden also wahrscheinlich unterschiedliche, aber hier die Auswahl:

**2025-12-05 18:25:29** - Anna Arndt:
> LG und bis nächste Woche!

**2025-12-05 18:49:23** - Julia:
> Hallo Anna, vielen Dank dir für die tolle Arbeit! Sehr sehr cool. Ich kann mir das alles nach unserem Shooting in Ruhe angucken

**2025-12-05 18:49:32** - Julia:
> Hab ein schönes Wochenende :slightly_smiling_face:

**2025-12-10 15:34:12** - Anna Arndt:
> Updates Summary Wohnwagen Lidl:

-Kontakt mit noch einem Außenfolierungs- und einem Inneneinrichtungs-Unternehmen
-Außenfolierung ca. 5.500 bis 8.000 € netto pro Fahrzeug
Aber: man müsste schon im Januar anfangen
-Inneneinrichtung <https://hp-camper.de/> -> brauchen genaue Angaben zu Fahrzeugen und Maßen, müssten auch schon im Januar beginnen
-Parken bei <http://knauscamp.de|knauscamp.de> -> Ist möglich!
ca. 42€
gültig für 1 Person, inkl. Stellplatz, Strom, Sanitäranlagen
-Genehmigung: Ansprechpartner gefunden: Andre Thamm <mailto:vd51@polizei.hamburg.de|vd51@polizei.hamburg.de>

-> Wenn wir bei manchen Anbietern schon im Januar mit der Gestaltung beginnen müssen, bräuchten wir die Wohnwägen da schon und müssten sie für 5 Monate mieten

**2026-01-08 16:55:37** - Anna Arndt:
> Hello Juli! Ersteinmal frohes neues Jahr! Flo hat mir gesagt, du bräuchtest vielleicht meine Hilfe? (bzgl. Lidl Video, Kontakt mit den Schauspiel Agenturen etc.?)

**2026-01-08 17:08:47** - Julia:
> Hi Anna! :slightly_smiling_face: Dankee, das wünsche ich dir auch

**2026-01-08 17:09:23** - Julia:
> ja genau, sehr gut! War eben noch im Meeting deshalb kam ich nicht dazu

**2026-01-08 17:09:50** - Julia:
> Sollen noch kurz sprechen oder lieber morgen?

**2026-01-08 17:10:41** - Anna Arndt:
> wir können gerne jetzt noch wenn du zeit hast:) sonst passt morgen auch

**2026-01-08 17:12:25** - Julia:
> dann gerne jetzt noch!
 <https://meet.google.com/rgm-vdeq-ord>

**2026-01-08 17:12:54** - Anna Arndt:
> Sekundeee

**2026-01-08 17:12:59** - Julia:
> klaro

**2026-01-08 17:16:52** - Julia:
> 

**2026-01-08 17:19:44** - Anna Arndt:
> dankeschööön:)

**2026-01-09 09:20:05** - Anna Arndt:
> Hi Juli, wenn ich die Agenturen/Schauspieler anfrage, darf und soll ich schon sagen, für was genau? Und was soll ich als gewünschtes Datum angeben?

**2026-01-09 09:36:37** - Julia:
> Guten Morgen!

**2026-01-09 09:38:57** - Julia:
> Ne, sag gerne ein internes Pitch Video mit einer Länge von 30-40 Sekunden
Datum Mitte/Ende nächster Woche oder direkt Montag/Dienstag KW4
Dauer des Drehs schätze ich mal auf maximal 2 Std. (mit allem drum herum)

**2026-01-09 09:39:27** - Anna Arndt:
> Perfekt, danke dir!

**2026-01-09 09:39:55** - Anna Arndt:
> haben wir was die weibliche Schauspielerin angeht irgendwelche besonderen Vorstellungen und Voraussetzungen?

**2026-01-09 09:42:43** - Julia:
> "Mandy" soll ja quasi stellvertretend für einen Crush sein, deshalb würde ich sagen eine natürlich und "klassisch schöne"/attraktive Frau, Ende 20, Blond oder Brünett spielt hier jetzt keine Rolle, schlank/ sportlich, groß

**2026-01-09 09:43:23** - Julia:
> Wenn es bei den Seiten auch eine Auswahl gibt, kannst du mir sehr gerne auch ein paar Profile zur Auswahl schicken, dann suchen wir uns hier welche raus und können genau sagen, wen wir bräuchten

**2026-01-09 09:51:47** - Anna Arndt:
> Ah super, das wollte ich grade vorschlagen!

**2026-01-09 09:52:30** - Anna Arndt:
> Auf den Seiten ist tatsächlich bisher niemand dabei, der mich hundert pro überzeugt...Aber ich schick dir mal eine Auswahl

**2026-01-09 09:54:49** - Anna Arndt:
> <https://lachfalten-people.de/models/semi-h/>
<https://lachfalten-people.de/models/brian-s/>
<https://lachfalten-people.de/models/daniel-t/>
<https://lachfalten-people.de/models/joe-t/>

**2026-01-09 09:56:42** - Anna Arndt:
> <https://www.fameonme.de/kartei/komparsen/aran-s/>
<https://www.fameonme.de/kartei/extra-faces/ahmed-m/>

**2026-01-09 09:56:43** - Julia:
> Ja hast du Recht aber ich seh was du meinst, würde sagen die sind alle "okay"

**2026-01-09 09:57:08** - Julia:
> Bisheriger Favorit: Brian von Lachfalten

**2026-01-09 09:57:28** - Anna Arndt:
> <https://agenturfrehse.com/schauspieler/daniel-aminati/>

**2026-01-09 09:58:07** - Anna Arndt:
> <https://agenturfrehse.com/schauspieler/peter-post/>

**2026-01-09 09:58:58** - Anna Arndt:
> Frauen schau ich grad noch durch aber da finden wir ja safe was

**2026-01-09 09:59:01** - Julia:
> ich melde mich gleich nach meinem Meeting. Ich frage mich ob der Aufwand für zB Brian der aus Köln ist, für die 2 Std Dreh dann auch relevant ist
Also wenn wir Münchner finden, wäre super

**2026-01-09 09:59:50** - Anna Arndt:
> Kein Stress! Ah shit, hatte nicht gesehen dass der aus Köln ist:sweat_smile: ich schau ob die restlichen Münchner sind

**2026-01-09 10:00:04** - Anna Arndt:
> Sonst hab ich auf den Seiten aber alle durchgeschaut

**2026-01-09 10:07:35** - Anna Arndt:
> hmm jagut die sind alle bisschen weit weg...ich guck mal ob ich münchner agenturen finde

**2026-01-09 10:22:04** - Anna Arndt:
> <https://www.zimt-casting.com/online-kartei?tx_bsdsedcards_bsdsedcards%5Baction%5D=show&amp;tx_bsdsedcards_bsdsedcards%5Bcontroller%5D=People&amp;tx_bsdsedcards_bsdsedcards%5BcurrentPage%5D=15&amp;tx_bsdsedcards_bsdsedcards%5Bfilter%5D%5BageMax%5D=99&amp;tx_bsdsedcards_bsdsedcards%5Bfilter%5D%5BageMin%5D=0&amp;tx_bsdsedcards_bsdsedcards%5BitemsPerPage%5D=96&amp;tx_bsdsedcards_bsdsedcards%5Bpeople%5D=1504&amp;cHash=83be40d0f62c13cb0afc5143212601af|https://www.zimt-casting.com/online-kartei?tx_bsdsedcards_bsdsedcards%5Baction%5D=show&amp;[…]ds%5Bpeople%5D=1504&amp;cHash=83be40d0f62c13cb0afc5143212601af> vielleicht mit hair &amp; makeup? hahaha

**2026-01-09 10:22:26** - Anna Arndt:
> <https://www.zimt-casting.com/online-kartei?tx_bsdsedcards_bsdsedcards%5Baction%5D=show&amp;tx_bsdsedcards_bsdsedcards%5Bcontroller%5D=People&amp;tx_bsdsedcards_bsdsedcards%5BcurrentPage%5D=15&amp;tx_bsdsedcards_bsdsedcards%5Bfilter%5D%5BageMax%5D=99&amp;tx_bsdsedcards_bsdsedcards%5Bfilter%5D%5BageMin%5D=0&amp;tx_bsdsedcards_bsdsedcards%5BitemsPerPage%5D=96&amp;tx_bsdsedcards_bsdsedcards%5Bpeople%5D=1552&amp;cHash=d5330b7b2bc70140f9a4118c3ce0b8fc|https://www.zimt-casting.com/online-kartei?tx_bsdsedcards_bsdsedcards%5Baction%5D=show&amp;[…]ds%5Bpeople%5D=1552&amp;cHash=d5330b7b2bc70140f9a4118c3ce0b8fc>

**2026-01-09 10:46:29** - Anna Arndt:
> <https://lachfalten-people.de/models/monika-g/>
<https://lachfalten-people.de/models/amelia-h/>
<https://lachfalten-people.de/models/mirjam-h/>
<https://lachfalten-people.de/models/daria-w/>

**2026-01-09 10:46:51** - Anna Arndt:
> die sind zumindest alle in München:sweat_smile:

**2026-01-09 11:07:38** - Anna Arndt:
> <https://www.fameonme.de/kartei/komparsen/nathalie-b/>

**2026-01-09 11:08:35** - Anna Arndt:
> <https://www.fameonme.de/kartei/komparsen/caroline-n/>

**2026-01-09 11:09:02** - Anna Arndt:
> <https://www.fameonme.de/kartei/komparsen/laura-d/>

**2026-01-09 11:09:47** - Anna Arndt:
> bei denen steht nichts dabei aber ich wollte trotzdem mal paar von der Seite raussuchen, falls wir den Mann auch von hier nehmen macht es ja Sinn, die direkt zusammen bei einer Agentur zu buchen

**2026-01-09 11:16:08** - Anna Arndt:
> <https://agenturfrehse.com/schauspieler/electra-maier/>

**2026-01-09 11:16:48** - Anna Arndt:
> <https://agenturfrehse.com/schauspieler/darya-birnstiel/>

**2026-01-09 11:16:55** - Anna Arndt:
> hier wieder beide aus München

**2026-01-09 11:17:33** - Anna Arndt:
> Der hier vielleicht noch mit Fantasie und Makeup <https://agenturfrehse.com/schauspieler/john-vincent-ragner/>

**2026-01-09 11:31:03** - Anna Arndt:
> <https://www.p-f.tv/system/index.php?cccpage=komparsen&amp;show=165336> theoretisch aber die website sieht so bisschen...unseriös aus

**2026-01-09 12:23:16** - Julia:
> super, schau mir jetzt alle an :slightly_smiling_face:

**2026-01-09 12:37:38** - Julia:
> Lachfalten: Daria, Amelia
fameonme: Brian --&gt; der könnte genau den richtigen Humor mitbringen für diese Art von Video, Laura D., Caroline N.

--&gt; die gerne mal anfragen!

**2026-01-09 12:39:55** - Julia:
> Eckdaten:
• Halber Drehtag in München
• KW3 oder KW4
• höchstwahrscheinlich Outdoor, evtl. Indoor (sowas wie Therme Erding könnte man überlegen)
• Dreh ist für einen internen Pitch
• Social Media Format// also gerne Humor mitbringen
• gerne schon vorab sagen: Badekleidung/ Unterwäsche (wird natürlich von uns gestellt)

**2026-01-09 12:41:57** - Anna Arndt:
> Mach ich!

**2026-01-09 12:42:18** - Julia:
> danke dir!

**2026-01-09 13:08:00** - Julia:
> Kam Aran über Flo? Brian ist raus?

**2026-01-09 13:10:11** - Julia:
> ah sorry mein Fehler, habs verwechselt. Brian ist ja von Lachfalten

**2026-01-09 13:55:30** - Anna Arndt:
> Oh, Aran ist ausversehen drinn geblieben sorry! Aber macht ja nichts, wir müssen eh ein paar Leuten ggf absagen.

**2026-01-09 13:55:56** - Anna Arndt:
> Yesss, Brian hab ich gesehen und dann richtig zugeordnet

**2026-01-09 14:45:36** - Julia:
> super danke

**2026-01-09 14:48:49** - Julia:
> Magst du auf die Absage einmal antworten:
• dass der Dreh natürlich so kurz wie möglich statt findet und wir realistisch max. 2 Std benötigen
• wir natürlich für warme Mäntel, Heißgetränke usw. sorgen ("da wir ja auch nicht frieren möchten") und die Darsteller:innen immer nur kurz in Unterwäsche wären
• zudem wir gerade noch die Option mit Indoor klären
Bei fame on me:
• einmal erklären, dass das video nur für interne Zwecke genutzt wird und wir also keine SoMe Nutzung brauchen
• dann gerne einmal unverbindlich die Angebote einholen

**2026-01-09 14:50:20** - Julia:
> Bezüglich Indoor:
Würdest du bitte hier einmal anfragen, ob ein Dreh möglich wäre und was es kosten würde für einen halben Tag?
<https://robertobeach.de/home/beach-area/>

Hätte das gerne als Back-Option für Indoor :slightly_smiling_face: Könnte man ja sonst auch draußen am Beach cool drehen

**2026-01-09 15:18:12** - Anna Arndt:
> Klaro bin dran!

**2026-01-09 15:20:28** - Julia:
> danke dir!

**2026-01-09 15:23:31** - Julia:
> Falls du noch Ideen hast zu Artists die cool passen könnten, außer:
• Cro
• SSIO
• Nina Chuba
• Ski Aggu
• Bill &amp; Tom
• Marteria
• Zartmann 
sag gern Bescheid :slightly_smiling_face: Solange sie nicht mit ALDI oÄ zusammenarbeiten

Oder auch momentane "Trends" bzw. Themen die man überall mitbekommt wie Späti Talk mit Mo Douzi, auch super gerne. Weil wir daraufgehend die Kampagne bauen müssen

**2026-01-09 15:24:29** - Julia:
> <https://www.youtube.com/watch?si=WUN0h3LPnSfYqM0b&amp;v=rR4oIJiRp-g&amp;feature=youtu.be>

**2026-01-09 15:25:23** - Julia:
> Da wärs natürlich auch super einen Bezug zu Sommer/ Festival zu finden

**2026-01-09 15:33:30** - Anna Arndt:
> yesss das kenn ich

**2026-01-09 15:34:42** - Anna Arndt:
> Blöde Frage aber wieso hatten wir in erster Linie SSIO? Ich mein cool hahah aber gibt es einen bestimmten Grund passend zu Lidl oder "nur" weil er gerade so bekannt ist?

**2026-01-09 15:41:56** - Julia:
> Das kommt von Lidl selbst. Sie finden seine Memes und die Art der Launches so genial 

**2026-01-09 15:42:14** - Anna Arndt:
> Ich überleg auf jeden Fall mal aber spontaner Einfall - Wäre Ikkimel zu polarisierend?:joy:

**2026-01-09 15:42:23** - Anna Arndt:
> Ah okay spannend!

**2026-01-09 15:46:15** - Julia:
> Ja hatte ich auch kurz überlegt. Können wir auf jeden Fall mal auf die Liste setzen :joy: krasser sollten wir jedenfalls nicht mehr werden 

**2026-01-30 09:26:16** - Anna Arndt:
> Hallo Juli! Wie kann ich dich bei MINI/Pepsi unterstützen?

**2026-01-30 09:43:38** - Anna Arndt:
> 

**2026-01-30 09:57:41** - Julia:
> Hello Anna!

**2026-01-30 10:01:04** - Julia:
> Für Mini haben Marie und ich erste Ideen formuliert – allerdings habe ich diese noch nicht final gecheckt bzw. verfeinert. Du kannst es dir sehr gerne einmal durchlesen und deine Kommentare hinzufügen oder falls du andere Ideen hast einfügen!
<https://docs.google.com/document/d/1NEnlqXtQv5wCwQTJwg87O0flVR4dX0z-fwHf1-nqxH8/edit?tab=t.0>

Pepsi hab ich noch zu wenige Infos, um hier etwas kreatives zu erstellen. Falls Flo da schon was hat, kannst du auch gerne damit starten :slightly_smiling_face:
Ansonsten weiß ich, dass Mert viel auf dem Tisch hat, da ich ihn gerade nicht unterstützen kann durch SIXT. Sonst frag ihn doch gerne mal? Da geht es um Content Ideen für Instagram für die Marke Gorenje

**2026-01-30 10:06:12** - Anna Arndt:
> okie, mach ich alles! danke dir!

**2026-01-30 10:07:16** - Julia:
> danke dir :slightly_smiling_face:

**2026-01-30 10:07:35** - Julia:
> ich meld mich auch nochmal, evtl. benötige ich für SIXT deine Photoshop Skills

**2026-01-30 10:07:52** - Anna Arndt:
> ohh okay, gerne!

**2026-01-30 10:10:11** - Anna Arndt:
> kannst du mir bitte noch den zugriff freischalten für das MINI dokument?

**2026-01-30 10:10:44** - Julia:
> Glaube den müsstest du anfragen

**2026-01-30 10:10:51** - Julia:
> Dann kann ich dich freigeben

**2026-01-30 10:14:58** - Anna Arndt:
> hab ich eigentlich...

**2026-01-30 10:15:01** - Anna Arndt:
> ich schau nochmal

**2026-01-30 10:15:48** - Anna Arndt:
> ah okay, irgendwie hat mein browser gesponnen, in einem anderen gehts!

**2026-01-30 10:16:04** - Julia:
> okay

**2026-01-30 10:16:08** - Julia:
> also du hast Zugriff?

**2026-01-30 10:17:26** - Anna Arndt:
> yes, danke!!

**2026-01-30 10:18:14** - Julia:
> perfekt!

**2026-01-30 11:17:47** - Anna Arndt:
> Zu Mini habe ich Kommentare und Ideen eingefügt! Ich fand das Spreading Smiles am coolsten da seh ich sehr viel Potenzial!:star-struck:

**2026-01-30 11:18:21** - Anna Arndt:
> Zu Pepsi hab ich grade mit Flo gesprochen und ich kümmer mich drum! Er meinte das kannst du als erledigt betrachten:)

**2026-01-30 11:26:51** - Julia:
> super, schau ich mir an :slightly_smiling_face: Ja mag die Idee auch sehr gerne

**2026-01-30 11:26:56** - Julia:
> danke dir

**2026-01-30 11:32:34** - Julia:
> Jetzt zur PS Task: Könntest du bei den Bildern die ich dir nach und nach schicke bitte das SIXT Logo austauschen? Ist nur ein minimaler Unterschied aber wichtig :slightly_smiling_face:

Bild 1: Too Hot too handle
Bild 2: Dschungelcamp
Bild 3: Are you the one?

Finale PNGs bitte in diesen Ordner mit folgendem Namen ablegen:
300126_SIXT_RealityTV_TooHot
300126_SIXT_RealityTV_IBES
300126_SIXT_RealityTV_TheOne

Sixt Logo:

**2026-01-30 11:32:51** - Julia:
> 

**2026-01-30 12:02:42** - Julia:
> und last one:

**2026-01-30 12:02:49** - Julia:
> 

**2026-01-30 12:03:01** - Julia:
> sag gerne Bescheid, wenn du Hilfe benötigst :slightly_smiling_face:

**2026-01-30 12:04:11** - Julia:
> ah sorry beim Dschungelcamp gabs noch eine Anpassung:

**2026-01-30 12:06:51** - Julia:
> 

**2026-01-30 12:13:06** - Anna Arndt:
> Dankeschön! Ich mach mich gleich dran

**2026-01-30 12:34:53** - Anna Arndt:
> Sollen die kleinen Logos auf den Autos auch ausgetauscht werden?

**2026-01-30 12:52:09** - Anna Arndt:
> Kannst du mir einen Pfad schicken zu dem Ordner wo die rein sollen?

**2026-01-30 13:07:06** - Julia:
> Die großen reichen 

**2026-01-30 13:07:14** - Julia:
> Ah mist, schicke ich dir gleich!

**2026-01-30 13:08:14** - Anna Arndt:
> Top, kein Stress!

**2026-01-30 13:34:15** - Julia:
> <https://drive.google.com/drive/folders/1aLCz7CZkdJOu_PQiBQh9GxUdMamSHJdt>

**2026-01-30 13:34:18** - Julia:
> danke dir!!

**2026-01-30 13:47:49** - Anna Arndt:
> Da komme ich zu einem Instagram Workshop Ordner - ist das richtig?

**2026-01-30 13:53:08** - Julia:
> genau "ready for presentation"

**2026-01-30 14:28:44** - Julia:
> alles gut soweit? :slightly_smiling_face:

**2026-01-30 14:31:25** - Anna Arndt:
> yess! ich mach grad pepsi

**2026-01-30 14:32:16** - Anna Arndt:
> kannst du die hochgeladenen Bilder sehen?

**2026-01-30 14:33:56** - Julia:
> jaa super, vielen dank :slightly_smiling_face:


---

## Basti (77 messages)

**Julia sent:** 47 | **Basti sent:** 30

**Folder:** `D09E76RSBNF`

**2025-09-09 16:53:11** - Julia:
> Hello! :slightly_smiling_face: Es gab beim Styleguide ja einen Kommentar bezüglich der VBWs. Könntest du diese für dieses Visual Template rausnehmen und mir kurz schicken? Würde es dann im Styleguide ersetzen

**2025-09-09 16:53:25** - Julia:
> Julia möchte den Styleguide jetzt rausschicken

**2025-09-09 16:53:46** - Basti:
> Yes mach ich

**2025-09-09 16:53:50** - Julia:
> dankeee

**2025-09-09 17:22:04** - Basti:
> Passts so :slightly_smiling_face:?

**2025-09-09 17:26:31** - Julia:
> nice! Ich brauch es allerdings in der IG Vorschau :slightly_smiling_face:

**2025-09-09 17:54:58** - Julia:
> Bist du noch da? :slightly_smiling_face:

**2025-09-09 18:19:21** - Basti:
> Hey ja sorry war im Gespräch mit dem Flo

**2025-09-09 18:20:15** - Basti:
> Das war aber YouTube in dem Fall :joy: 

**2025-09-09 18:27:01** - Basti:
> 

**2025-09-09 18:34:54** - Julia:
> auch okay :smile: Dankeee

**2025-09-23 17:08:37** - Basti:
> Hey sorry nochmal aber bis wann brauchst du das Christo dings Video ding da :smile:?

**2025-09-23 17:09:12** - Julia:
> Hello :slightly_smiling_face:

**2025-09-23 17:10:16** - Julia:
> also am 25.9. kommt die Zeitschrift mit ihr aus. Wenn wir es am gleichen Tag posten könnten, wäre mega --&gt; aber da eh Gipfeltreffen ist, denk ich wirds dann erst später zum Wochenende passend

**2025-09-23 17:11:20** - Basti:
> okay aber bedeutet ich kann mich da morgen dran setzen das sollte reichen...

**2025-09-23 17:12:00** - Julia:
> Ja, morgen sollten wir Porsche mal unseren Vorschlag schicken aber die haben eh grad andere Themen :smile:

**2025-09-23 17:12:01** - Basti:
> Mir kam Marvin mit SIXT heute unerwartet mit nem dringenden Schnitt dazwischen das hat mir meine Planung für den Porsche Schnitt leider voll verhauen

**2025-09-23 17:12:15** - Julia:
> alles gut :slightly_smiling_face:

**2025-09-25 15:42:21** - Basti:
> Hey hey, hab dir das Video neu rausgerechnet und die Schwimmszenen eingebaut. Find auch die passen super rein und machen nochmal ne sehr schöne Verbindung von ihr zum Porsche: <https://drive.google.com/file/d/1_JFCYMOQpscL2Qntpl36LU3jXELUc1vi/view?usp=sharing>

**2025-09-25 17:25:38** - Julia:
> Hello! Sorry für meine späte Antwort, war etwas im Stress. Danke Basti! :slightly_smiling_face: Sieht super aus

**2025-09-25 17:26:12** - Julia:
> Wo legt ihr die Videos normalerweise für Porsche ab? Würde ihnen gerne den Sharepoint Link schicken. Magst du mir diesen einmal schicken? (Ich hab teilweise noch keinen Zugriff) Dann leite ich es direkt weiter

**2025-09-26 09:19:49** - Basti:
> Die liegen von unserer Seite aus immer auf Drive ab. Wie die dann zu Porsche kommen weis ich leider auch nicht ab dem Moment wo wir euch das finale Asset schicken sind wir bisher eigentlich immer raus gewesen :smile:

**2025-09-26 09:41:35** - Julia:
> Okay :slightly_smiling_face: Ich frag mal Mert

**2025-09-30 15:23:44** - Julia:
> Hello! :slightly_smiling_face: Bezüglich dem Leonie Video:

**2025-09-30 15:24:04** - Basti:
> huhu hab ich grad schon auf Asana gesehen :slightly_smiling_face:

**2025-09-30 15:24:58** - Julia:
> Julia hatte dich ja schon gefragt wegen der Stimme. Charly gefällt diese nicht bzw. folgendes Feedback "Diese klingt aktuell noch etwas starr. Falls es nicht Leonie ist, können wir die Stimme ersetzen oder weglassen?"

Komplett weglassen würde ich nicht. Haben wir die Möglichkeit das zu ersetzen?
Würde es dann auch nochmal in Asana aufnehmen

**2025-09-30 15:28:51** - Basti:
> Ja genau is ne KI Stimme, klar da gibts viele die können wir ersetzen, aber ich sag gleich vorab ich hab dir nicht ohne Grund genommen :smile: Die hat von der Betonung und Stimmfarbe schon recht gut zu ihr gepasst also obs wirklich besser wird werden wir sehen. Aber ja gibt auf jeden Fall Möglichkeiten :slightly_smiling_face: Mach ich dann morgen alles in einem Abwasch. Wenn du magst und/oder Zeit hast kannst du natürlich aber auch auf Artlist selbst schauen welche Stimme dir gefallen würde. Ansonsten bekommst es morgen von mir :slightly_smiling_face:

**2025-09-30 15:30:43** - Julia:
> ja denk ich mir. Aber soweit kommt Porsche natürlich nicht – als würden wir uns jemals Gedanken machen :smile:
Such du gerne aus, ich geb ihr Rückmeldung, dass wir es anpassen können

**2025-09-30 15:32:37** - Julia:
> Heute hast du keine Kapa mehr oder? Haben morgens einen kleinen Einlauf von Charly bekommen, weil das Thema schon etwas liegt..

**2025-09-30 15:34:13** - Basti:
> Doch kann mich auch heute schon drum kümmern aber was macht das für einen Sinn wenns eh noch von Leonie approved werden muss?

**2025-09-30 15:34:23** - Julia:
> ja I know

**2025-09-30 15:34:53** - Julia:
> genau das hab ich ihr jetzt auch geschrieben. Ob sie es Leonie so zeigen will oder schon mit neuer Stimme. Gebe dir asap ein Update

**2025-09-30 15:35:02** - Julia:
> Danke :face_exhaling:

**2025-09-30 15:35:39** - Basti:
> okay ja dann geb mir einfach bescheid :slightly_smiling_face:

**2025-09-30 15:36:38** - Basti:
> "Einlauf von Charly"... gibts von der überhaupt was anderes?

**2025-09-30 15:36:45** - Julia:
> :joy:

**2025-09-30 15:36:48** - Julia:
> Scheinbar nicht

**2025-09-30 17:23:47** - Julia:
> Hab dir Charly's Mail weitergeleitet

**2025-09-30 17:28:16** - Basti:
> Okay also kicken wir das VO... Also für Charlys Info, rein rechtlich dürfen wir das verwenden. Wir haben extra einen Account dafür mit Lizenzen für commercial. Wenn sie seitens Porsche das nicht dürfen ist das ne andere Geschichte, dann kann man nur sagen...bitte kommt ins Jahr 2025 :joy:

**2025-09-30 17:31:23** - Julia:
> ja wir hatten das heute auch schon mit Bildern die ich erstellt hatte – AI ist der Feind!!!

**2025-09-30 17:31:24** - Julia:
> :smile:

**2025-10-01 09:21:34** - Basti:
> Okay VBW´s sind angepasst warte nur auf euer "Go" dann rechne ich euch das Video raus.

**2025-10-01 09:21:55** - Julia:
> cool danke!

**2025-10-01 09:22:22** - Julia:
> Charly schickt heute alles an Leonie und holt ihre Freigabe. geb dir dann bescheid

**2025-10-08 15:35:41** - Julia:
> Hello! :slightly_smiling_face: bist du heute da?

**2025-10-08 15:52:40** - Basti:
> Hi ne sorry bin heute für Sixt auf Dreh 

**2025-10-08 16:41:47** - Julia:
> ah okay! Bist du morgen wieder da?

**2025-10-08 17:05:46** - Basti:
> Muss ich mal schauen bin leider am kränkeln und weis nicht wie mich der Tag heute vollends zerlegt oder nicht :grimacing: aber prinzipiell bin ich da ja 

**2025-10-08 17:28:13** - Julia:
> ach mist, dann halte gut durch! :heart_hands:

**2025-10-09 09:39:51** - Basti:
> Moin Juli, also mir gehts tatsächlich nicht schlechter als gestern also bin ich heute am Start. Wie kann ich dir helfen :slightly_smiling_face:?

**2025-10-09 09:57:07** - Julia:
> Hello! :slightly_smiling_face: okay gut

**2025-10-09 09:57:10** - Julia:
> Wie war der Dreh?

**2025-10-09 09:57:21** - Julia:
> Wir müssten heute das Leonie Video fertig bekommen

**2025-10-09 10:01:39** - Basti:
> War ganz gut, aber viel :smile: Selten gibts ne Mittagspause auf Dreh und ehe man sich versieht hat man n 10 Stunden Tag durch geballert :grimacing:

**2025-10-09 10:01:55** - Basti:
> Ja alles klar, da müssen ja nur die VBW´s angepasst werden wenn ich das richtig verstanden hatte?

**2025-10-09 10:08:01** - Julia:
> ja glaub ich dir sofort, total!

**2025-10-09 10:08:05** - Julia:
> genau :slightly_smiling_face:

**2025-10-09 10:08:24** - Julia:
> am besten verlinkst du dann in asana direkt Julia – sie übernimmt den Upload :slightly_smiling_face: danke dir

**2025-10-09 10:08:55** - Basti:
> Alles klar mach ich danke dir :slightly_smiling_face:

**2025-10-09 11:19:23** - Basti:
> Hier das Video mit den aktuellen VBW´s. Ich leite den Link und Asana an Julia H. weiter: <https://drive.google.com/file/d/1zJTmqauZITlgn17uVs9AJ44oW_I5LGBr/view?usp=drive_link>

**2025-10-09 13:19:59** - Julia:
> danke!

**2025-11-21 09:46:15** - Julia:
> Hello! :slightly_smiling_face: Bist du heute im Büro? Würde mich sonst an deinen Platz setzen – ziemlich voll heute haha

**2025-12-05 15:37:37** - Basti:
> Hey hey, denkst du bitte daran mir noch bescheid zu geben bezüglich dem Mittwoch? Merci :)

**2025-12-05 15:46:02** - Julia:
> Hello! 

**2025-12-05 15:46:14** - Julia:
> Yes, hab’s eben gelesen: Mittwoch ist der Dreh. Ist jetzt final 

**2025-12-05 15:46:24** - Julia:
> Haben dieses Licht unterm Schreibtisch bei dir gelassen 

**2025-12-05 15:51:48** - Basti:
> Alles klar danke dir

**2025-12-05 15:58:24** - Julia:
> Danke dir! 

**2025-12-11 10:43:58** - Julia:
> Hello! Sind in paar Minuten im Büro mit der Technik 

**2025-12-11 11:23:10** - Basti:
> danke euch :slightly_smiling_face:

**2026-02-10 14:27:34** - Basti:
> GUTE BESSERUNG :grin::raised_hands:

**2026-02-10 15:28:39** - Julia:
> Danke dir :heart_hands:

**2026-02-16 09:45:41** - Julia:
> Hello! Findet der CheckIn statt? :slightly_smiling_face:

**2026-02-16 10:24:59** - Julia:
> Marvin meinte du bist da mit drin, deshalb :slightly_smiling_face:
Aber alles gut. Ich hab 2 Themen die sie meinten, die offen sind und ich ihnen ein Update geben sollte:
• Car Edit Monstertruck
• Desicion Video BeamNG

**2026-02-16 12:02:49** - Basti:
> Hi Juli, ich bin leider krank 

**2026-02-16 12:22:05** - Julia:
> ach Mist! Dann gute Besserung :crossed_fingers:

**2026-02-16 12:22:26** - Basti:
> Ja danke dir :)


---

## Jose Pequeno (25 messages)

**Julia sent:** 14 | **Jose Pequeno sent:** 11

**Folder:** `D0A57U5R90E`

**2025-12-23 18:17:11** - Jose Pequeno:
> Hi Juli :slightly_smiling_face:

**2025-12-23 18:18:45** - Jose Pequeno:
> could you send me the credentials on highfield

**2025-12-23 18:27:40** - Julia:
> Hi!

**2025-12-23 18:27:47** - Julia:
> What do you mean exactly? :slightly_smiling_face:

**2025-12-23 18:35:54** - Jose Pequeno:
> Sorry, I got confused with the chat hehe :disappointed:

**2026-01-30 17:56:44** - Julia:
> Hi Jose! :slightly_smiling_face: Hope you are doing fine

**2026-01-30 17:57:43** - Julia:
> I just add some tasks into the new Asana Board &amp; will fill them now with detailed briefings! It would be awesome, if you and the team could work and that already today? :slightly_smiling_face:
We need the final assets on wednesday, so it's very tight!

**2026-01-30 17:59:16** - Jose Pequeno:
> Hi Juli, we are fine, i hope you too :slightly_smiling_face:

**2026-01-30 17:59:24** - Julia:
> I won't be able to feedback today, but I've you like I can give you a quick overview/ introduction about the project :slightly_smiling_face:

**2026-01-30 17:59:32** - Jose Pequeno:
> yes of course, tha task is already on asana?

**2026-01-30 17:59:52** - Julia:
> just the titles. I'll insert the briefings now asap

**2026-01-30 18:01:37** - Jose Pequeno:
> Perfect, will these be AI-generated videos or edited with material you provide?

**2026-01-30 18:02:35** - Julia:
> AI generated pictures

**2026-01-30 18:18:03** - Jose Pequeno:
> Perfect, we'll keep an eye out :slightly_smiling_face:

**2026-01-30 18:29:25** - Julia:
> perfect! The first briefing for 3 pictures is in Asana

**2026-01-30 18:52:09** - Julia:
> 3 briefings (out of 5) are ready. The rest will follow on monday

**2026-01-30 18:52:31** - Julia:
> Everything okay for you or should we have a quick call now?

**2026-01-30 19:04:26** - Jose Pequeno:
> can we have a call?

**2026-01-30 19:05:00** - Julia:
> sure!

**2026-01-30 19:05:22** - Jose Pequeno:
> 

**2026-02-02 13:32:45** - Julia:
> Hi! Thank you for the AI Content already :slightly_smiling_face: I commented one task and need one more iteration.
Another new task is in the Asana board. Today in the evening I will add briefing for the last task "Road Challange" in Asana

**2026-02-02 14:16:42** - Jose Pequeno:
> Hi Juli,

Perfect, now I check it with the girls for corrections and new tasks

**2026-02-02 20:50:15** - Julia:
> the last briefing is online now :slightly_smiling_face: thank you so much

**2026-02-03 15:41:41** - Jose Pequeno:
> Hi <@U09D64LA420>

we have finished our asana tasks :slightly_smiling_face:

**2026-02-03 16:54:44** - Julia:
> Thank you! I’ll have a look asap 


---

## Jana Kordt (22 messages)

**Julia sent:** 12 | **Jana Kordt sent:** 10

**Folder:** `D09NZF18J2K`

**2025-10-31 10:46:19** - Julia:
> Hi Jana! Wie wäre es, wenn wir Montag dann einfach um 9.30 Uhr starten und Flo kommt dann einfach dazu ab 10Uhr?

**2025-10-31 13:54:40** - Jana Kordt:
> Hallo.
Das können wir gerne so machen.

**2025-10-31 14:06:10** - Julia:
> Super :slightly_smiling_face: stellst du das Meeting ein?

**2025-11-03 09:31:18** - Julia:
> Hi Jana, wie sieht es mit unserem Meeting aus?

**2025-11-03 09:32:59** - Jana Kordt:
> Shame, ich glaube, ich habe die falsche Julia eingeladen - was ist dein Nachname? Bzw Email Adresse?

**2025-11-03 09:33:46** - Julia:
> <mailto:julia.hopper@boldcreators.club|julia.hopper@boldcreators.club>

**2025-11-03 09:33:55** - Julia:
> <mailto:mert@boldcreators.club|mert@boldcreators.club>

**2025-11-03 09:35:04** - Jana Kordt:
> ah perfekt.
Ich hab SIXT schon die ganze Zeit am Telefon, laut eurer Kalender würde auch 10:30-11:30 passen, Flo hatte den Inital-Termin auch abgesagt, hier haben wir alle einen Puffer. Passt das?

**2025-11-03 09:37:05** - Julia:
> okay

**2025-11-03 10:06:21** - Jana Kordt:
> Wir haben ein SIXT Kundenmeeting reinbekommen, es ist gerade etwas stressig, da Marvin nicht da ist. Ich muss noch mal etwas nach hinten schieben :disappointed: SORRY für das hin und her.

**2025-11-03 10:24:56** - Julia:
> alles gut, danke fürs Bescheid geben

**2026-01-06 11:07:09** - Jana Kordt:
> Hey hey. Happy new year. Passt es dir morgen nach dem Lunch oder Donnerstag besser für die SIXT Übergabe ?

**2026-01-07 09:21:04** - Julia:
> Hi Jana! Happy new year :slightly_smiling_face: Gerne morgen um 10Uhr? Passt dir das?

**2026-01-07 10:33:03** - Jana Kordt:
> Perfekt :) 

**2026-01-07 10:35:05** - Jana Kordt:
> Flo will, dass wir es heute machen. 

**2026-01-07 10:42:48** - Julia:
> Dann machen wir es heute. 14.30?

**2026-01-07 10:53:05** - Jana Kordt:
> Geht es auch später? 

**2026-01-07 10:53:32** - Julia:
> yes, du kannst mir gerne einfach was einstellen

**2026-01-07 12:49:17** - Julia:
> sehe grade bei Flo im Kalender, du hast die falsche Mail genommen. das ist meine richtige: <mailto:julia.hopper@boldcreators.club|julia.hopper@boldcreators.club>

**2026-01-09 10:57:50** - Julia:
> Hi Jana! Kurze Frage: kannst du mir kurz sagen, wieviele Std. du schätzungsweise für SIXT in der Woche aufgewendet hast? Damit ich das Pensum grob einschätzen kann

**2026-01-09 12:45:23** - Jana Kordt:
> Hey hey 

**2026-01-09 12:45:39** - Jana Kordt:
> Puh. Total unterschiedlich. Schicke dir später mein srubdebzettel 


---

